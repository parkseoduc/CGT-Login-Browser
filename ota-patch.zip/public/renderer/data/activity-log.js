// Activity-log store ("Nhật ký hoạt động") - records user operations (create /
// update / delete a profile, proxy, tag, …) so the log page can list them, the
// same way MKTLogin's "Nhật Ký Chung" does. Entries NAY LƯU TRÊN SERVER, cô lập
// theo workspace hiện hành, để cả nhóm (nhiều máy) thấy chung lịch sử thao tác.
// "Người thực hiện" do SERVER gán từ tài khoản đã xác thực (client chỉ hiển thị).
// Vẫn giữ cache in-memory (window-scoped) để API đọc đồng bộ không đổi cho view;
// logging là fire-and-forget và KHÔNG BAO GIỜ ném lỗi vào luồng của caller.

const vt = window.vt;
const MAX_ENTRIES = 5000; // cap in-memory copy (server cũng cap 5000 mỗi workspace)

// Catalog of loggable actions - key → Vietnamese label shown in the green pill and
// the "Hành động" filter. Order mirrors MKTLogin's action dropdown 1:1.
export const ACTIONS = {
  create_profile: 'Tạo hồ sơ',
  update_profile: 'Cập nhật hồ sơ',
  renew_profile: 'Gia hạn hồ sơ',
  duplicate_profile: 'Nhân bản hồ sơ',
  transfer_profile: 'Chuyển hồ sơ',
  move_group: 'Chuyển nhóm hồ sơ',
  delete_profile: 'Xóa hồ sơ',
  restore_profile: 'Khôi phục hồ sơ',
  update_proxy: 'Cập nhật proxy',
  update_note: 'Cập nhật ghi chú',
  transfer_workspace: 'Chuyển workspace',
  update_kernel: 'Cập nhật browser kernel',
  enable_autorenew: 'Bật tự động gia hạn',
  disable_autorenew: 'Tắt tự động gia hạn',
  auto_renew: 'Tự động gia hạn hồ sơ',
  delete_workspace: 'Xóa workspace',
  system_autodelete: 'Hệ thống tự động xóa',
  delete_proxy: 'Xóa proxy',
  delete_cookie: 'Xóa cookie',
  update_tag: 'Cập nhật tag',
  add_tag: 'Thêm tag',
  delete_tag: 'Xóa tag',
  add_tab: 'Thêm tab',
  delete_tab: 'Xóa tab',
  add_bookmark: 'Thêm bookmark',
  delete_bookmark: 'Xóa bookmark',
};
// Ordered [key, label] pairs for the filter dropdown (object key order is stable).
export const ACTION_LIST = Object.keys(ACTIONS).map((k) => ({ key: k, label: ACTIONS[k] }));
export function actionLabel(key) { return ACTIONS[key] || key || ''; }

// ---- persistence (server-backed, scoped theo workspace) ---------------------
function load() {
  if (!window.__polyActivityLog) window.__polyActivityLog = [];
  ready(); // kick off the server load once (idempotent)
  return window.__polyActivityLog;
}
// Replace the shared array IN PLACE (keep the reference; views may hold it).
function replaceInPlace(next) {
  const arr = window.__polyActivityLog || (window.__polyActivityLog = []);
  arr.length = 0;
  (Array.isArray(next) ? next : []).forEach((x) => arr.push(x));
}

let _loaded = false;
let _loadingPromise = null;

// Load the current workspace's log from server into the cache, then notify views.
export async function refresh() {
  if (!window.__polyActivityLog) window.__polyActivityLog = [];
  let list = [];
  try { list = await vt.activity.list(); } catch { list = []; }
  replaceInPlace(list);
  _loaded = true;
  emit();
  return window.__polyActivityLog;
}
// Ensure loaded once (idempotent). Views await this before their first render.
export function ready() {
  if (!window.__polyActivityLog) window.__polyActivityLog = [];
  if (_loaded) return Promise.resolve(window.__polyActivityLog);
  if (!_loadingPromise) _loadingPromise = refresh().finally(() => { _loadingPromise = null; });
  return _loadingPromise;
}
// Workspace-switch refresh hook for app.js (re-loads this workspace's log).
if (typeof window !== 'undefined') window.__activityRefresh = () => refresh();

// ---- pub/sub (live-refresh the grid the instant an action is logged) --------
const _subs = (window.__polyActivitySubs = window.__polyActivitySubs || new Set());
export function onActivityChange(cb) { _subs.add(cb); return () => _subs.delete(cb); }
function emit() { _subs.forEach((cb) => { try { cb(); } catch { /* subscriber error */ } }); }

// ---- id → name cache -------------------------------------------------------
// Views feed the current profile list here (see profiles.js loadProfiles) so a log
// entry created by id alone (duplicate/move/delete) can still show the profile name.
const _names = (window.__polyProfileNames = window.__polyProfileNames || new Map());
// id (GUID) → "Profile ID" = md5(GUID), the same value the profiles/proxies grids
// display (first 8 hex, uppercase). Lets a log entry created by GUID alone still
// show the short md5 id.
const _pids = (window.__polyProfilePids = window.__polyProfilePids || new Map());
export function rememberProfiles(list) {
  if (!Array.isArray(list)) return;
  list.forEach((p) => {
    if (!p || p.id == null) return;
    const id = String(p.id);
    _names.set(id, p.name || '');
    if (p.profileId) _pids.set(id, String(p.profileId));
  });
}
export function nameFor(id) { return id == null ? '' : (_names.get(String(id)) || ''); }
export function pidFor(id) { return id == null ? '' : (_pids.get(String(id)) || ''); }

// Current operator ("Người thực hiện") - read from the app shell's account.
function actor() {
  let acc = {};
  try { acc = (window.__vtApp && window.__vtApp.getAccount && window.__vtApp.getAccount()) || {}; }
  catch { acc = {}; }
  return { name: acc.displayName || acc.email || '-', email: acc.email || '' };
}

// ---- public API ------------------------------------------------------------
export function activities() { return load().slice(); } // newest-first (see logActivity unshift)

// Record one action. `meta` = { profileId, profileName }. Never throws.
export function logActivity(action, meta = {}) {
  try {
    if (!action) return null;
    const arr = load();
    const a = actor();
    // Store the md5 "Profile ID" (matches proxies/profiles grid) so the log's
    // "ID hồ sơ" column can show its first 8 hex. meta may hand us the md5 already
    // (32 hex) or the GUID → resolve GUID→md5 via the cache when possible.
    const rawPid = meta.profileId != null ? String(meta.profileId) : '';
    const pid = /^[0-9a-f]{32}$/i.test(rawPid) ? rawPid : (pidFor(rawPid) || rawPid);
    const entry = {
      id: 'log_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8),
      action,
      profileId: pid,
      profileName: meta.profileName || nameFor(pid) || '',
      actorName: a.name,
      actorEmail: a.email,
      ts: Date.now(),
    };
    // Optimistic in-memory insert (hiển thị tức thì); server assigns the same id
    // (we send it) so the next refresh reconciles without duplicating the row.
    arr.unshift(entry);
    if (arr.length > MAX_ENTRIES) arr.length = MAX_ENTRIES;
    emit();
    // Persist to server (actor/pid được server chốt lại từ tài khoản đã xác thực).
    try { vt.activity.add({ id: entry.id, action, profileId: entry.profileId, profileName: entry.profileName, ts: entry.ts }); }
    catch { /* offline - giữ bản in-memory */ }
    return entry;
  } catch { return null; }
}

// Log the same action for a batch of profile ids (move/delete select) - one entry
// per id so each profile's row shows in the log, like MKTLogin.
export function logActivityBatch(action, ids = [], names = {}) {
  const list = ids || [];
  if (!action || !list.length) return;
  const arr = load();
  const a = actor();
  const ts = Date.now();
  const items = [];
  list.forEach((id) => {
    const rawPid = id != null ? String(id) : '';
    const pid = /^[0-9a-f]{32}$/i.test(rawPid) ? rawPid : (pidFor(rawPid) || rawPid);
    const profileName = (names && names[id]) || nameFor(pid) || '';
    const entry = { id: 'log_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8),
      action, profileId: pid, profileName, actorName: a.name, actorEmail: a.email, ts };
    arr.unshift(entry);
    items.push({ profileId: pid, profileName });
  });
  if (arr.length > MAX_ENTRIES) arr.length = MAX_ENTRIES;
  emit();
  try { vt.activity.addBatch(action, items, ts); } catch { /* offline */ }
}

export function clearActivities() {
  replaceInPlace([]);
  emit();
  try { vt.activity.clear(); } catch { /* offline */ }
}
