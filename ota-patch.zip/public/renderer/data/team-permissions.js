// Bộ nhớ đệm quyền của người dùng hiện tại cho tính năng "Thành viên nhóm".
// Fetch một lần từ server (remote.team.permissions) rồi cache để view gọi can()
// đồng bộ khi dựng UI (ẩn/hiện nút). Server VẪN là nơi enforce thật - đây chỉ để
// UX. permissions = mảng key phẳng "cat:perm" (hoặc ['*'] khi owner/admin).
import { remote } from './remote-ds.js';

let _cache = null; // { role, teamRole, canManageMembers, permissions:[], catalog:[] }

const EMPTY = { role: null, teamRole: null, canManageMembers: false, permissions: [], catalog: [] };

// Nạp (và cache) quyền của tôi. force=true để làm mới sau khi đổi vai trò.
export async function loadPermissions(force = false) {
  if (_cache && !force) return _cache;
  try { _cache = await remote.team.permissions(); }
  catch { _cache = { ...EMPTY }; }
  return _cache;
}

// Ảnh chụp đồng bộ (null nếu chưa nạp).
export function permissionsSync() { return _cache; }

// Danh mục quyền (PERMISSION_CATEGORIES) từ server, dùng dựng ma trận nhóm.
export function permissionCatalog() { return (_cache && _cache.catalog) || []; }

// Tôi có quyền `key` không (owner/admin → luôn true nhờ '*').
export function can(key) {
  if (!_cache) return false;
  const p = _cache.permissions || [];
  return p.includes('*') || p.includes(key);
}

// Tôi có quyền `key` TRÊN HỒ SƠ `id` không. Hồ sơ được chia sẻ riêng (có trong
// sharePerms) → quyền chia sẻ là AUTHORITATIVE (không cộng quyền nhóm) → khớp đúng
// server (permissions.profilePermissions). Hồ sơ khác → dùng quyền nhóm. Mặc định khi
// chưa nạp cache = true (giống PERM mặc định, tránh chớp-khoá cho owner/admin).
export function canOnProfile(id, key) {
  if (!_cache) return true;
  const p = _cache.permissions || [];
  if (p.includes('*')) return true;
  const sp = _cache.sharePerms || {};
  if (Array.isArray(sp[id])) return sp[id].includes(key);
  const gp = _cache.groupPerms || [];
  return gp.includes(key);
}

// Tôi có được quản lý thành viên/nhóm (mời, sửa quyền, gỡ) không.
export function canManageMembers() { return !!(_cache && _cache.canManageMembers); }

// Xóa cache (gọi khi đăng xuất / đổi tài khoản).
export function clearPermissions() { _cache = null; }

// Câu giải thích chuẩn khi thao tác bị server chặn vì thiếu quyền.
export const PERM_DENIED_NOTE = 'do bạn không có đủ quyền hạn';

// Lỗi/kết quả này có phải do THIẾU QUYỀN không? Nhận cả Error (throw từ remote-ds:
// e.code/e.status) lẫn envelope thô ({ code, status } từ remoteCall/IPC).
export function isPermError(e) {
  if (!e) return false;
  return e.code === 'NO_PERMISSION' || e.status === 403;
}

// Ghép thông báo rõ ràng: nếu là lỗi thiếu quyền → "<fallback> - do bạn không có đủ
// quyền hạn"; ngược lại trả nguyên `fallback`. Dùng ở mọi chỗ toast lỗi thao tác ghi
// (lưu/xoá/sửa) để người dùng biết mình bị chặn vì quyền chứ không tưởng app lỗi.
export function describeError(e, fallback) {
  return isPermError(e) ? `${fallback} - ${PERM_DENIED_NOTE}` : fallback;
}
