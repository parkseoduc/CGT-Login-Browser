// Shared RPA task + schedule store used by the "Nhiệm vụ" (tasks.js) and
// "Lập lịch" (scheduler.js) views. Mirrors MKTLogin's model where a "Nhiệm vụ"
// is a run definition (a saved automation flow + the profiles it runs on) and a
// "Lập lịch" is a timer that fires that task on a chosen cadence.
//
// Both collections live at window scope so they survive view re-renders (the
// same in-memory approach the profiles-grid "Tự động hóa" dialog already uses;
// execution is only effective on the current device, matching MKTLogin's note).
import { el, toast, openModal, closeModal, customSelect, customDateTime } from '../ui.js';
import { icon } from '../icons.js';
import { tf } from '../i18n.js';

const vt = window.vt;

// ------------------------------------------------------------------ persistence
// Tasks + schedules + run-logs NAY LƯU TRÊN SERVER, cô lập theo workspace hiện hành
// (trước đây localStorage cục bộ mỗi máy → không chia sẻ được theo nhóm/nhiều máy).
// Vẫn giữ cache in-memory ở window scope để API đọc đồng bộ (tasks()/schedules())
// không đổi cho views; mọi mutation ghi thẳng lên server (fire-and-forget, nuốt lỗi
// mạng để không chặn UI). Runtime-only fields (_timer/_onFire) bị lược trước khi gửi
// và được dựng lại bằng arm() sau khi refresh().
const stripTask = (t) => { const { _timer, ...rest } = t || {}; return rest; };
const stripSched = (s) => { const { _timer, _onFire, ...rest } = s || {}; return rest; };

function persistTask(t) { if (!t) return Promise.resolve(); try { return Promise.resolve(vt.rpa.saveTask(stripTask(t))); } catch (e) { return Promise.reject(e); } }
function persistSchedule(s) { if (!s) return Promise.resolve(); try { return Promise.resolve(vt.rpa.saveSchedule(stripSched(s))); } catch (e) { return Promise.reject(e); } }

// Lưu MỘT nhiệm vụ lên server, trả về Promise (nơi gọi await/catch để báo lỗi rõ ràng).
// Thất bại → refresh() để đồng bộ lại đúng trạng thái server + throw (không "đứng im").
export function saveTask(t) {
  return (async () => {
    try { await persistTask(t); }
    catch (e) { try { await refresh(); } catch { /* resync best-effort */ } throw e; }
  })();
}

// Collection-level saves (callers mutate the whole array then persist). Upsert each
// item; deletes are handled explicitly in removeTask/removeSchedule via server delete.
export function saveTasks() { (window.__rpaTasks || []).forEach((t) => { Promise.resolve(persistTask(t)).catch(() => {}); }); }
export function saveSchedules() { (window.__rpaSchedules || []).forEach(persistSchedule); }
export function saveRunLogs() { /* no-op: run-logs are appended individually to server */ }

function ensureArrays() {
  if (!window.__rpaTasks) window.__rpaTasks = [];
  if (!window.__rpaSchedules) window.__rpaSchedules = [];
  if (!window.__rpaRunLogs) window.__rpaRunLogs = [];
}

// Replace an array's contents IN PLACE (profiles.js shares the window.__rpaTasks
// reference, so we must never swap the array object out from under it).
function replaceInPlace(arr, next) { arr.length = 0; (Array.isArray(next) ? next : []).forEach((x) => arr.push(x)); }

let _loaded = false;
let _loadingPromise = null;

// Load ALL RPA state from the server into the window caches and re-arm enabled
// schedules. Called at first read and on workspace switch (window.__rpaRefresh).
export async function refresh() {
  ensureArrays();
  let t = [], s = [], l = [];
  try { t = await vt.rpa.listTasks(); } catch { t = []; }
  try { s = await vt.rpa.listSchedules(); } catch { s = []; }
  try { l = await vt.rpa.listRunLogs(); } catch { l = []; }
  // Drop old timers before swapping in the workspace's schedules.
  (window.__rpaSchedules || []).forEach((x) => disarm(x));
  replaceInPlace(window.__rpaTasks, t);
  replaceInPlace(window.__rpaSchedules, s);
  replaceInPlace(window.__rpaRunLogs, l);
  window.__rpaSchedules.forEach((x) => { if (x && x.enabled) { x._timer = null; arm(x); } });
  _loaded = true;
  emitSchedules();
  emitTasks();
  return true;
}

// Ensure the store has been loaded once (idempotent). Views await this before
// rendering so they never show an empty grid while the first fetch is in flight.
export function ready() {
  ensureArrays();
  if (_loaded) return Promise.resolve(true);
  if (!_loadingPromise) _loadingPromise = refresh().finally(() => { _loadingPromise = null; });
  return _loadingPromise;
}

// Expose a workspace-switch refresh hook for app.js (re-loads this workspace's data).
if (typeof window !== 'undefined') window.__rpaRefresh = () => refresh();

// ------------------------------------------------------------------ run logs
// Each runTask() invocation appends one entry (start/end/status + per-profile
// results) so the "Nhật ký" modal can list a task's execution history.
function addRunLog(entry) {
  ensureArrays();
  window.__rpaRunLogs.unshift(entry);
  if (window.__rpaRunLogs.length > 500) window.__rpaRunLogs.length = 500;
  try { vt.rpa.addRunLog(entry); } catch { /* offline */ }
}
export function taskLogs(taskId) {
  ensureArrays();
  return (window.__rpaRunLogs || []).filter((l) => l && l.taskId === taskId).sort((a, b) => b.startedAt - a.startedAt);
}
export function clearTaskLogs(taskId) {
  ensureArrays();
  window.__rpaRunLogs = (window.__rpaRunLogs || []).filter((l) => !l || l.taskId !== taskId);
  try { vt.rpa.clearRunLogs(taskId); } catch { /* offline */ }
}

// ------------------------------------------------------------------ collections
// Tasks are shared with profiles.js openRpaPlus (window.__rpaTasks).
export function tasks() { ensureArrays(); ready(); return window.__rpaTasks; }
export function schedules() { ensureArrays(); ready(); return window.__rpaSchedules; }
export function getTask(id) { return tasks().find((t) => t && t.id === id) || null; }

// ---------------------------------------------------------------- tasks pub/sub
// Mirrors onSchedulesChange: lets the Nhiệm vụ grid re-render when tasks change
// from another view or after a workspace-switch refresh().
const _taskSubs = (window.__rpaTaskSubs = window.__rpaTaskSubs || new Set());
export function onTasksChange(cb) { _taskSubs.add(cb); return () => _taskSubs.delete(cb); }
function emitTasks() { _taskSubs.forEach((cb) => { try { cb(); } catch { /* subscriber error */ } }); }

// Xóa nhiệm vụ: cập nhật local ngay (mượt), rồi ĐỒNG BỘ server. Nếu server từ chối
// (vd thiếu quyền) → refresh() để khôi phục đúng trạng thái + throw để nơi gọi báo lỗi
// (không được "đứng im" khi xóa thất bại). Trả về Promise cho nơi gọi await/catch.
export function removeTask(id) {
  const arr = tasks();
  const i = arr.findIndex((t) => t && t.id === id);
  if (i >= 0) arr.splice(i, 1);
  // orphan schedules that pointed at it
  schedules().filter((s) => s.taskId === id).forEach((s) => { Promise.resolve(removeSchedule(s.id)).catch(() => {}); });
  emitTasks();
  return (async () => {
    try { await vt.rpa.removeTask(id); }
    catch (e) { try { await refresh(); } catch { /* resync best-effort */ } throw e; }
  })();
}

// ------------------------------------------------------------------ run a task
const shuffle = (arr) => {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
};

// ------------------------------------------------------------- running registry
// Live "which tasks are currently running" registry so the Nhiệm vụ Action cell
// can render a real Chạy/Dừng toggle. Entry = { cancelled, runIds:Set }. Kept at
// window scope so it survives view re-renders; subscribers re-render on change.
function running() { if (!window.__rpaRunning) window.__rpaRunning = new Map(); return window.__rpaRunning; }
export function isTaskRunning(id) { return running().has(id); }
const _runSubs = (window.__rpaRunSubs = window.__rpaRunSubs || new Set());
export function onRunningChange(cb) { _runSubs.add(cb); return () => _runSubs.delete(cb); }
function emitRunning(id) { _runSubs.forEach((cb) => { try { cb(id); } catch { /* subscriber error */ } }); }

// -------------------------------------------------------- schedules registry
// Live "schedules changed" pub/sub so the "Lập lịch" grid refreshes the instant a
// schedule is created/edited/deleted from ANOTHER view (e.g. the "Lên lịch" dialog
// opened from the Nhiệm vụ grid) - no Ctrl+R needed. Mirrors onRunningChange; kept
// at window scope so it survives keep-alive view re-renders.
const _schedSubs = (window.__rpaSchedSubs = window.__rpaSchedSubs || new Set());
export function onSchedulesChange(cb) { _schedSubs.add(cb); return () => _schedSubs.delete(cb); }
function emitSchedules() { _schedSubs.forEach((cb) => { try { cb(); } catch { /* subscriber error */ } }); }

// Request cancellation of an in-flight task run: flag it so no new profiles start,
// and ask the engine to stop EVERY profile currently running (task may run several
// concurrently per its "Số luồng đồng thời" config).
export function stopTask(id) {
  const entry = running().get(id);
  if (!entry) return;
  entry.cancelled = true;
  const ids = entry.runIds ? Array.from(entry.runIds) : (entry.currentRunId ? [entry.currentRunId] : []);
  ids.forEach((rid) => { try { vt.rpa.stop(rid); } catch { /* engine may already be idle */ } });
  toast('Đang dừng nhiệm vụ…', 'ok');
}

// Apply a task's "Đầu vào" values: clone the graph, overriding each declared
// variable's default `value` with task.inputs[name] (keyed by variable name).
// The executor coerces by type, so raw strings / booleans / JSON pass through.
function applyTaskInputs(graph, inputs) {
  if (!graph || !inputs || !Object.keys(inputs).length) return graph;
  const vars = Array.isArray(graph.variables) ? graph.variables : [];
  return {
    ...graph,
    variables: vars.map((v) => (v && v.name != null && Object.prototype.hasOwnProperty.call(inputs, v.name))
      ? { ...v, value: inputs[v.name] }
      : v),
  };
}

// Read a task's "Cấu hình chạy" (task.run) into normalized numbers with sane
// defaults, so an old task saved before that tab existed still runs correctly.
function readRunConfig(task) {
  const r = (task && task.run) || {};
  const posInt = (v, d) => { const n = parseInt(v, 10); return Number.isFinite(n) && n > 0 ? n : d; };
  const nonNeg = (v, d) => { const n = parseInt(v, 10); return Number.isFinite(n) && n >= 0 ? n : d; };
  const posFloat = (v, d) => { const n = parseFloat(v); return Number.isFinite(n) && n > 0 ? n : d; };
  return {
    threads: posInt(r.threads, 1),      // Số luồng đồng thời
    openDelay: nonNeg(r.openDelay, 0),  // Độ trễ mở (ms) giữa mỗi lần mở cửa sổ
    perRow: posInt(r.winCount, 4),      // Số cửa sổ mỗi hàng
    winW: posInt(r.winW, 500),          // Chiều rộng cửa sổ
    winH: posInt(r.winH, 640),          // Chiều cao cửa sổ
    scale: posFloat(r.winScale, 1),     // Tỉ lệ thu phóng cửa sổ (device-scale-factor)
    gap: nonNeg(r.gap, 0),              // Khoảng cách cửa sổ
    mouseSim: r.mouseSim !== false,     // Mô phỏng chuột
  };
}

const sleep = (ms) => new Promise((res) => setTimeout(res, ms));

// Resolve the flow graph fresh (so editor changes are picked up) and run the task
// on its profiles HONOURING the "Cấu hình chạy" tab: up to `threads` profiles run
// concurrently, each launch is spaced by `openDelay` ms, and the running browser
// windows are tiled per `winCount`×`winW`×`winH` + `gap`. `mouseSim` is forwarded
// to the engine with each run.
export async function runTask(task) {
  if (!task) return;
  if (isTaskRunning(task.id)) { toast('Nhiệm vụ đang chạy', 'err'); return; }
  let flow = null;
  try { flow = await vt.flows.get(task.flowId); } catch { flow = null; }
  if (!flow || !flow.graph) { toast('Không tải được quy trình của nhiệm vụ', 'err'); return; }
  const graph = applyTaskInputs(flow.graph, task.inputs);
  const ids = Array.isArray(task.profileIds) ? task.profileIds : [];
  const order = task.order === 'random' ? shuffle(ids) : ids;
  if (!order.length) { toast('Nhiệm vụ chưa có hồ sơ nào', 'err'); return; }

  const cfg = readRunConfig(task);
  const threads = Math.min(cfg.threads, order.length);

  const entry = { cancelled: false, runIds: new Set() };
  running().set(task.id, entry);
  emitRunning(task.id);
  toast(tf('Bắt đầu "{0}" trên {1} hồ sơ ({2} luồng)', task.name, order.length, threads), 'ok');
  const startedAt = Date.now();
  // ĐỊNH DANH LẦN CHẠY (batch): sinh MỘT lần cho cả lần bấm "Chạy" này rồi truyền xuống
  // MỌI hồ sơ/làn — để các node "chống trùng tài khoản" chia sẻ chung một hàng đợi trong
  // lần chạy (chống phát trùng giữa các hồ sơ song song) NHƯNG reset ở lần chạy kế tiếp
  // (không ghim cứng hàng đợi cũ tới khi restart app). Lần bấm Chạy sau = batchId MỚI.
  const batchId = 'batch_' + startedAt + '_' + Math.random().toString(36).slice(2, 8);
  const results = [];

  // ---------------------------------------------------------------- SMART TILING
  // Tile the run's browser windows by launching each one DIRECTLY at its grid slot
  // (passed to the launcher as winBounds). The grid has one slot per CONCURRENT window
  // (= số luồng); each worker "lane" reuses its slot wave after wave (open → run →
  // close → open next), so at most `threads` windows are on screen and they never pile
  // on top of each other.
  //
  // The grid ADAPTS to the concurrent-window count so they always tile WITHOUT overlap:
  //   • Chromium's outer window has a HARD MINIMUM WIDTH ~516px (measured: any smaller
  //     request is clamped up to 516) but almost NO minimum height (~96px). So the
  //     screen limits how many COLUMNS we can show (≈ floor(screenW / 516)); we get lots
  //     of ROWS "for free" by shrinking each window's height.
  //   • Columns = min(user's perRow, what the screen width allows, N).
  //   • Cell WIDTH  = user's winW, but shrunk to share the screen across the columns
  //     (never below the 516 hard floor).
  //   • Cell HEIGHT = user's winH, but shrunk so ALL rows fit the screen height (down to a
  //     usable floor). Growing rows just makes every window a little shorter instead of
  //     spilling off-screen or stacking - that is the "sắp xếp thông minh".
  //   • Only when there are more windows than physically fit even at the minimum size
  //     (cols × maxRows) do the extras CASCADE diagonally (offset so each title bar stays
  //     visible & grabbable) - never an exact stack.
  const GAP = Math.max(cfg.gap, 2);
  const HARD_MIN_W = 516;   // Chromium refuses to render an outer window narrower than this
  const MIN_H = 210;        // usable height floor (true floor ~96px, but keep tab+addr bar usable
                            //  AND stay above the launcher's window-finder size gate of 200px)
  const scr = (typeof window !== 'undefined' && window.screen) || {};
  const screenW = scr.availWidth || 1920;
  const screenH = scr.availHeight || 1080;
  // Số cửa sổ mở CÙNG LÚC = số luồng đồng thời (đã kẹp ≤ số hồ sơ). Lưới chỉ cần đủ
  // chỗ cho bấy nhiêu ô vì mô hình "sóng": xong cửa sổ nào ĐÓNG cửa sổ đó rồi mở hồ
  // sơ kế tiếp vào ĐÚNG vị trí (làn) đó → không bao giờ có quá `threads` cửa sổ trên
  // màn hình. (Trước đây lưới tính theo TỔNG hồ sơ nên khi mở dồn sẽ bị chật.)
  const n = threads;
  // Columns: honour the user's "Số cửa sổ mỗi hàng" but never ask for more columns than the
  // screen can hold at the 516px hard-min width (or than there are concurrent windows).
  const maxCols = Math.max(1, Math.floor((screenW + GAP) / (HARD_MIN_W + GAP)));
  const cols = Math.max(1, Math.min(Math.max(1, cfg.perRow), maxCols, n));
  const neededRows = Math.ceil(n / cols);
  // How many rows physically fit at the usable min height → capacity before we must cascade.
  const maxRows = Math.max(1, Math.floor((screenH + GAP) / (MIN_H + GAP)));
  const rowsToPlace = Math.min(neededRows, maxRows);
  // Cell size: as large as the user asked, shrunk to fit the chosen grid on screen, floored.
  const fitW = Math.floor((screenW - GAP * (cols - 1)) / cols);
  const fitH = Math.floor((screenH - GAP * (rowsToPlace - 1)) / rowsToPlace);
  const cellW = Math.max(HARD_MIN_W, Math.min(Math.max(1, cfg.winW), fitW));
  const cellH = Math.max(MIN_H, Math.min(Math.max(1, cfg.winH), fitH));
  const onScreen = cols * maxRows;      // windows that tile without overlap
  const slotBounds = (slot) => {
    if (slot < onScreen) {
      const col = slot % cols, row = Math.floor(slot / cols);
      return { x: col * (cellW + GAP), y: row * (cellH + GAP), width: cellW, height: cellH };
    }
    // Genuine overflow (more windows than fit even at the min size): cascade diagonally so
    // every window remains individually reachable instead of an exact stack.
    const k = slot - onScreen + 1;
    const STEP = 32;
    const maxX = Math.max(0, screenW - cellW), maxY = Math.max(0, screenH - cellH);
    return { x: Math.min(maxX, k * STEP), y: Math.min(maxY, k * STEP), width: cellW, height: cellH };
  };

  // Serialize launch "gate" so the moment each profile is handed to the engine is
  // spaced by openDelay (the very first passes immediately). Concurrency is still
  // `threads` - only the START instants are staggered.
  let firstGate = true;
  let gateChain = Promise.resolve();
  const passGate = () => {
    const wait = firstGate ? 0 : cfg.openDelay;
    firstGate = false;
    const p = gateChain.then(() => (wait ? sleep(wait) : undefined));
    gateChain = p;
    return p;
  };

  let cursor = 0;
  // Mỗi luồng = một "làn" cố định (lane 0..threads-1) ứng với một ô lưới trên màn.
  // Làn xử lý các hồ sơ TUẦN TỰ: mở → chạy → ĐÓNG → mở hồ sơ kế của làn đó. Nhờ vậy
  // đúng `threads` cửa sổ chạy song song, xong đợt này tự tắt rồi mở đợt tiếp theo,
  // và mọi cửa sổ của một làn đều dùng chung một vị trí (không trôi, không đè).
  const worker = async (lane) => {
    while (!entry.cancelled) {
      const myIdx = cursor++;
      if (myIdx >= order.length) return;
      const profId = order[myIdx];
      await passGate();
      if (entry.cancelled) return;
      const runId = 'rpa_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
      entry.runIds.add(runId);
      // Cửa sổ của hồ sơ mở vào ô lưới CỦA LÀN (tái sử dụng qua từng đợt) chứ không
      // theo chỉ số mở toàn cục → luôn tối đa `threads` cửa sổ, xếp gọn không đè.
      const winBounds = slotBounds(lane);
      const t0 = Date.now();
      let ok = true;
      try {
        // rpa:run KHÔNG ném lỗi khi quy trình hỏng - nó trả về { ok:false, error }
        // (hoặc { ok:true, skipped:n } khi node lỗi bị "Bỏ qua" cho đi tiếp). Trước
        // đây chỉ bắt bằng catch nên MỌI hồ sơ đều được ghi "thành công": chạy 3 hồ
        // sơ mà chỉ 1 hồ sơ làm được việc vẫn hiện 3/3 xong, không biết đường mà lần.
        const r = await vt.rpa.run({ runId, batchId, profileId: profId, graph, flowName: flow.name, flowId: flow.id, run: cfg, winBounds });
        ok = !!(r && r.ok) && !(r && r.skipped);
      }
      catch { ok = false; /* engine logs per-profile failures; keep going */ }
      finally {
        // Nhiệm vụ của hồ sơ đã xong (hoặc bị dừng) → TỰ ĐỘNG ĐÓNG cửa sổ trước khi
        // làn nhận hồ sơ kế tiếp. Đây là cốt lõi của mô hình "số luồng đồng thời":
        // 5 luồng = 5 cửa sổ, xong 5 cửa sổ này đóng lại rồi mới mở 5 cửa sổ tiếp.
        // Chờ đóng xong để cửa sổ mới của làn không chồng lên cửa sổ cũ.
        try { await vt.profiles.close(profId); } catch { /* browser may already be closed */ }
      }
      results.push({ profileId: profId, ok, startedAt: t0, endedAt: Date.now() });
      entry.runIds.delete(runId);
    }
  };

  try {
    await Promise.all(Array.from({ length: threads }, (_, lane) => worker(lane)));
  } finally {
    running().delete(task.id);
    emitRunning(task.id);
  }
  const cancelled = entry.cancelled;
  const endedAt = Date.now();
  const okCount = results.filter((r) => r.ok).length;
  const status = cancelled ? 'stopped'
    : (okCount === results.length ? 'done' : (okCount === 0 ? 'error' : 'partial'));
  addRunLog({ id: 'log_' + startedAt + '_' + Math.random().toString(36).slice(2, 6),
    taskId: task.id, taskName: task.name, flowName: flow.name, startedAt, endedAt, status, results });
  toast(cancelled ? tf('Đã dừng nhiệm vụ "{0}"', task.name) : tf('Hoàn tất nhiệm vụ "{0}"', task.name), cancelled ? 'err' : 'ok');
}

// ------------------------------------------------------------------ scheduling
const WD = { Monday: 1, Tuesday: 2, Wednesday: 3, Thursday: 4, Friday: 5, Saturday: 6, Sunday: 0 };

// Next fire timestamp (ms) at or after `from`, honouring the schedule's own
// "Thời gian bắt đầu" (startAt) lower bound. Returns null when not resolvable.
function nextFire(s, from) {
  const startMs = s.startAt ? new Date(s.startAt).getTime() : 0;
  const floor = Math.max(from, isNaN(startMs) ? from : startMs || from);
  if (s.freq === 'once') {
    const t = s.startAt ? new Date(s.startAt).getTime() : NaN;
    return (!isNaN(t) && t >= from) ? t : null;
  }
  if (s.freq === 'interval') {
    const min = Math.max(1, parseInt(s.intervalMin, 10) || 1);
    const step = min * 60000;
    let t = startMs && !isNaN(startMs) ? startMs : from;
    if (t < from) { const k = Math.ceil((from - t) / step); t = t + k * step; }
    return t;
  }
  const parts = String(s.time || '').split(':');
  const hh = parseInt(parts[0], 10), mm = parseInt(parts[1], 10);
  if (isNaN(hh) || isNaN(mm)) return null;
  const d = new Date(floor);
  d.setSeconds(0, 0);
  if (s.freq === 'daily') {
    d.setHours(hh, mm, 0, 0);
    let g = 0;
    while ((d.getTime() < from || (startMs && d.getTime() < startMs)) && g++ < 800) d.setDate(d.getDate() + 1);
    return d.getTime();
  }
  if (s.freq === 'weekly') {
    const target = WD[s.weekday] != null ? WD[s.weekday] : 1;
    d.setHours(hh, mm, 0, 0);
    let g = 0;
    while ((d.getDay() !== target || d.getTime() < from || (startMs && d.getTime() < startMs)) && g++ < 800) d.setDate(d.getDate() + 1);
    return d.getTime();
  }
  if (s.freq === 'monthly') {
    const day = Math.min(28, Math.max(1, parseInt(s.monthday, 10) || 1));
    d.setDate(day); d.setHours(hh, mm, 0, 0);
    let g = 0;
    while ((d.getTime() < from || (startMs && d.getTime() < startMs)) && g++ < 120) { d.setMonth(d.getMonth() + 1); d.setDate(day); d.setHours(hh, mm, 0, 0); }
    return d.getTime();
  }
  return null;
}

export function disarm(s) { if (s && s._timer) { clearTimeout(s._timer); s._timer = null; } }

// Arm a self-rescheduling timer. Each fire runs the task, stamps lastRun, then
// schedules the next occurrence - stopping past the optional "Thời gian kết thúc".
export function arm(s) {
  disarm(s);
  if (!s || !s.enabled) return;
  const endMs = s.endAt ? new Date(s.endAt).getTime() : NaN;
  const scheduleNext = () => {
    const now = Date.now();
    const next = nextFire(s, now + 500);
    if (next == null) return;
    if (!isNaN(endMs) && next > endMs) return;
    s._timer = setTimeout(() => {
      s.lastRun = Date.now();
      runTask(getTask(s.taskId));
      if (s.freq === 'once') { s.enabled = false; s._timer = null; persistSchedule(s); if (typeof s._onFire === 'function') s._onFire(); return; }
      persistSchedule(s);
      if (typeof s._onFire === 'function') s._onFire();
      scheduleNext();
    }, next - now);
  };
  scheduleNext();
}

export function addSchedule(s) { s.enabled = s.enabled !== false; schedules().push(s); arm(s); persistSchedule(s); emitSchedules(); return s; }
export function removeSchedule(id) {
  const arr = schedules();
  const i = arr.findIndex((s) => s && s.id === id);
  if (i < 0) return Promise.resolve();
  disarm(arr[i]); arr.splice(i, 1); emitSchedules();
  return (async () => {
    try { await vt.rpa.removeSchedule(id); }
    catch (e) { try { await refresh(); } catch { /* resync best-effort */ } throw e; }
  })();
}
// Bật/tắt lịch: đổi trạng thái + arm/disarm ngay, rồi lưu server. Server từ chối →
// hoàn tác trạng thái + timer + throw (để nơi gọi báo lỗi, không "đứng im").
export function setEnabled(s, on) {
  s.enabled = !!on; if (on) arm(s); else disarm(s);
  return (async () => {
    try { await persistSchedule(s); }
    catch (e) { s.enabled = !on; if (s.enabled) arm(s); else disarm(s); emitSchedules(); throw e; }
  })();
}

// ------------------------------------------------------------------ formatting
const MONTHS = ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12'];
export function fmtDateTime(v) {
  if (!v) return null;
  const d = new Date(v);
  if (isNaN(d.getTime())) return null;
  const pad = (n) => String(n).padStart(2, '0');
  return { date: tf('{0} tháng {1} {2}', pad(d.getDate()), MONTHS[d.getMonth()], d.getFullYear()), time: `${pad(d.getHours())}:${pad(d.getMinutes())}` };
}

const FREQ_LABEL = { once: 'Một lần', interval: 'Khoảng thời gian', daily: 'Hàng ngày', weekly: 'Hàng tuần', monthly: 'Hàng tháng' };
export function freqLabel(f) { return FREQ_LABEL[f] || f; }

// "2026-07-02 10:37:06" - full timestamp used by the Nhật ký modal.
export function fmtStamp(v) {
  const d = new Date(v);
  if (isNaN(d.getTime())) return '-';
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}
// "0h 0m 4s" - human run duration from a millisecond span.
export function fmtDuration(ms) {
  const s = Math.max(0, Math.round((Number(ms) || 0) / 1000));
  return `${Math.floor(s / 3600)}h ${Math.floor((s % 3600) / 60)}m ${s % 60}s`;
}
const RUN_STATUS = { done: 'Hoàn Thành', partial: 'Một phần', error: 'Thất bại', stopped: 'Đã dừng' };
export function runStatusLabel(st) { return RUN_STATUS[st] || st || '-'; }

// ------------------------------------------------------------------ Lên lịch dialog
const WEEKDAYS = [
  ['Monday', 'Thứ hai'], ['Tuesday', 'Thứ ba'], ['Wednesday', 'Thứ tư'], ['Thursday', 'Thứ năm'],
  ['Friday', 'Thứ sáu'], ['Saturday', 'Thứ bảy'], ['Sunday', 'Chủ nhật'],
];
const FREQS = [['once', 'Một lần'], ['interval', 'Khoảng thời gian'], ['daily', 'Hàng ngày'], ['weekly', 'Hàng tuần'], ['monthly', 'Hàng tháng']];

function schedRow(label, control, hint, required) {
  return el('div.rpp-row', {}, [
    el('div.rpp-label', {}, [required ? el('span.req', { text: '*' }) : null, document.createTextNode(label)]),
    el('div.rpp-ctrlcol', {}, [control, hint ? el('div.rpp-hint', { text: hint }) : null]),
  ]);
}

// Open the "Lên lịch" dialog for a task. `existing` (optional) pre-fills the form
// for editing. onSaved(schedule) fires after a successful create/update.
export function openScheduleDialog(task, existing, onSaved) {
  const s = existing
    ? { ...existing }
    : { id: 'sched_' + Date.now(), taskId: task.id, name: '', note: '', freq: 'once',
        intervalMin: '1', time: '', weekday: 'Monday', monthday: '1', startAt: '', endAt: '', enabled: true, lastRun: null, createdAt: Date.now() };

  const nameInput = el('input.input', { value: s.name || '', placeholder: 'Tên lịch' });
  nameInput.addEventListener('input', () => { s.name = nameInput.value; syncOk(); });
  const noteInput = el('textarea.input.rpp-textarea', { rows: '3', placeholder: '' }, [document.createTextNode(s.note || '')]);
  noteInput.addEventListener('input', () => { s.note = noteInput.value; });

  const cond = el('div.rpp-cond');
  const radio = (val, label) => {
    const input = el('input', { type: 'radio', name: 'sched-freq' });
    if (s.freq === val) input.checked = true;
    input.addEventListener('change', () => { if (input.checked) { s.freq = val; renderCond(); syncOk(); } });
    return el('label.radio', {}, [input, el('span', { text: label })]);
  };
  // Combobox date/time picker (shared with the Automation modal) instead of the
  // native <input type=datetime-local> - styled trigger + portaled calendar panel.
  const dt = (key) => customDateTime({ value: s[key] || '', mode: 'datetime', onChange: (v) => { s[key] = v; syncOk(); } });
  const timeInput = () => customDateTime({ value: s.time || '', mode: 'time', onChange: (v) => { s.time = v; syncOk(); } });

  function renderCond() {
    clear(cond);
    cond.appendChild(schedRow('Tần suất thực hiện', el('div.rpp-radios.wrap', {}, FREQS.map(([v, l]) => radio(v, l)))));
    if (s.freq === 'once') {
      cond.appendChild(schedRow('Thời gian bắt đầu', dt('startAt'), 'Phải lớn hơn thời điểm hiện tại', true));
    } else if (s.freq === 'interval') {
      const inp = el('input.input', { type: 'number', min: '1', value: s.intervalMin || '1' });
      inp.addEventListener('input', () => { s.intervalMin = inp.value; syncOk(); });
      cond.appendChild(schedRow('Khoảng thời gian (phút)', inp, 'Thời gian giữa các lần thực hiện tác vụ, đơn vị là phút', true));
      cond.appendChild(schedRow('Thời gian bắt đầu', dt('startAt'), 'Phải lớn hơn thời điểm hiện tại', true));
      cond.appendChild(schedRow('Thời gian kết thúc', dt('endAt'), 'Phải sau thời gian bắt đầu. Nếu không chọn nghĩa là nhiệm vụ không có thời gian kết thúc cụ thể.'));
    } else if (s.freq === 'daily') {
      cond.appendChild(schedRow('Thời gian thực hiện', timeInput(), null, true));
      cond.appendChild(schedRow('Thời gian bắt đầu', dt('startAt'), 'Phải lớn hơn thời điểm hiện tại', true));
      cond.appendChild(schedRow('Thời gian kết thúc', dt('endAt'), 'Phải sau thời gian bắt đầu. Nếu không chọn nghĩa là nhiệm vụ không có thời gian kết thúc cụ thể.'));
    } else if (s.freq === 'weekly') {
      const wsel = customSelect(WEEKDAYS.map(([v, l]) => ({ value: v, label: l })), { value: s.weekday, width: 150, height: 34, onChange: (v) => { s.weekday = v; } });
      cond.appendChild(schedRow('Thời gian thực hiện', el('div.rpp-inline', {}, [wsel, timeInput()]),
        'Nếu bạn muốn thực hiện một nhiệm vụ trong cùng một ngày, thời gian thực hiện nên là 10 phút sau thời điểm bắt đầu', true));
      cond.appendChild(schedRow('Thời gian bắt đầu', dt('startAt'), 'Phải lớn hơn thời điểm hiện tại', true));
      cond.appendChild(schedRow('Thời gian kết thúc', dt('endAt'), 'Phải sau thời gian bắt đầu. Nếu không chọn nghĩa là nhiệm vụ không có thời gian kết thúc cụ thể.'));
    } else if (s.freq === 'monthly') {
      const dsel = customSelect(Array.from({ length: 28 }, (_, i) => ({ value: String(i + 1), label: 'Ngày ' + (i + 1) })), { value: s.monthday, width: 130, height: 34, onChange: (v) => { s.monthday = v; } });
      cond.appendChild(schedRow('Thời gian thực hiện', el('div.rpp-inline', {}, [dsel, timeInput()]),
        'Nếu bạn muốn thực hiện một nhiệm vụ trong cùng một ngày, thời gian thực hiện nên là 10 phút sau thời điểm bắt đầu', true));
      cond.appendChild(schedRow('Thời gian bắt đầu', dt('startAt'), 'Phải lớn hơn thời điểm hiện tại', true));
      cond.appendChild(schedRow('Thời gian kết thúc', dt('endAt'), 'Phải sau thời gian bắt đầu. Nếu không chọn nghĩa là nhiệm vụ không có thời gian kết thúc cụ thể.'));
    }
  }

  const okBtn = el('button.btn.primary', { text: 'Lên lịch', onclick: submit });
  const errEl = el('div.rpp-err');
  // Two-tier validation. `missing()` = a required field not yet filled → OK stays
  // disabled but no red error (don't scold an untouched form). `conflict()` = a
  // logical error the hint texts promise to enforce (one-time run in the past,
  // end time before start / before now, non-positive interval) → shown in red.
  // A recurring schedule may still be anchored in the past: nextFire() computes
  // the next future occurrence, so we only forbid a past start for 'once'.
  function missing() {
    if (!s.name.trim()) return true;
    if (!s.startAt) return true;
    if (s.freq === 'interval') return !s.intervalMin;
    if (s.freq !== 'once') return !s.time;
    return false;
  }
  function conflict() {
    const now = Date.now();
    const startMs = s.startAt ? new Date(s.startAt).getTime() : NaN;
    if (s.startAt && isNaN(startMs)) return 'Thời gian bắt đầu không hợp lệ';
    if (s.freq === 'once' && !isNaN(startMs) && startMs <= now) return 'Thời gian bắt đầu phải lớn hơn thời điểm hiện tại';
    if (s.freq === 'interval' && s.intervalMin && !(parseInt(s.intervalMin, 10) > 0)) return 'Khoảng thời gian phải lớn hơn 0 phút';
    if (s.endAt) {
      const endMs = new Date(s.endAt).getTime();
      if (!isNaN(endMs) && !isNaN(startMs)) {
        if (endMs <= startMs) return 'Thời gian kết thúc phải sau thời gian bắt đầu';
        if (endMs <= now) return 'Thời gian kết thúc phải lớn hơn thời điểm hiện tại';
      }
    }
    return '';
  }
  function syncOk() {
    const err = conflict();
    okBtn.disabled = missing() || !!err;
    errEl.textContent = err;
    errEl.style.display = err ? 'block' : 'none';
  }
  function submit() {
    if (missing() || conflict()) return;
    if (existing) {
      const cur = schedules().find((x) => x.id === s.id);
      if (cur) { disarm(cur); Object.assign(cur, s); arm(cur); }
      persistSchedule(cur || s);
      emitSchedules();
      toast('Đã cập nhật lịch', 'ok');
      closeModal();
      if (onSaved) onSaved(cur || s);
      return;
    }
    addSchedule(s);
    toast(tf('Đã lên lịch "{0}"', s.name), 'ok');
    closeModal();
    if (onSaved) onSaved(s);
  }

  openModal({
    title: 'Lên lịch', width: 660,
    body: [el('div.rpp-form.sched-form', {}, [
      el('div.sched-taskinfo', {}, [
        el('span.sched-taskinfo-icon', { html: icon('automation') }),
        el('div.sched-taskinfo-text', {}, [
          el('span.sched-taskinfo-label', { text: 'Nhiệm vụ' }),
          el('span.sched-taskinfo-name', { text: task.name || '', title: task.name || '' }),
        ]),
      ]),
      schedRow('Tên', nameInput, null, true),
      schedRow('Ghi chú', noteInput),
      cond,
      errEl,
    ])],
    footer: [el('button.btn', { text: 'Hủy', onclick: closeModal }), okBtn],
  });
  renderCond();
  syncOk();
}

function clear(node) { while (node.firstChild) node.removeChild(node.firstChild); return node; }
