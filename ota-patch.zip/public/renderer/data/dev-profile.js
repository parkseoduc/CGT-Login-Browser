// Hồ sơ NHÀ PHÁT TRIỂN ở "Chợ" - dùng chung giữa màn Đăng chợ (Tự động hoá) và trang
// Chợ. Cung cấp:
//   getMyDevProfile()            → hồ sơ của chính mình { name, displayName, email, avatar,
//                                  hasProfile, ... } hoặc null.
//   openDevProfileEditor(profile)→ mở modal "Cập nhật thông tin cá nhân" (tên hiển thị BẮT
//                                  BUỘC, avatar tuỳ chọn, email chỉ hiển thị). Trả
//                                  Promise<profile|null> (profile MỚI khi lưu, null nếu huỷ).
//   ensureDevProfile()           → đảm bảo đã có tên hiển thị: nếu chưa → bắt cập nhật; trả
//                                  Promise<boolean> (true = sẵn sàng đăng).
//
// Tên hiển thị lưu vào accounts.display_name (đồng bộ toàn app: người đăng ở chợ, nhật ký…);
// avatar lưu accounts.avatar (data URL). Chỉ CẦN CẬP NHẬT 1 LẦN ở màn đăng chợ; muốn sửa
// sau thì vào hồ sơ nhà phát triển ở trang Chợ.
import { el, clear, toast, openModal, closeModal } from '../ui.js';
import { describeError } from './team-permissions.js';

// Chữ cái đầu cho avatar dự phòng (khi chưa tải ảnh).
const initial = (name) => (String(name || '?').trim()[0] || '?').toUpperCase();

// Giới hạn kích thước ảnh avatar (2MB) - tránh payload phình to.
const MAX_AVATAR_BYTES = 2 * 1024 * 1024;

// Biểu tượng "máy ảnh + dấu cộng" (add-a-photo) đặt giữa vòng tròn tải ảnh.
const UPLOAD_ICON = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" d="M0 0h24v24H0z"/><path fill="currentColor" d="M3 4V1h2v3h3v2H5v3H3V6H0V4zm3 6V7h3V4h7l1.83 2H21c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H5c-1.1 0-2-.9-2-2V10zm7 9c2.76 0 5-2.24 5-5s-2.24-5-5-5s-5 2.24-5 5s2.24 5 5 5m-3.2-5c0 1.77 1.43 3.2 3.2 3.2s3.2-1.43 3.2-3.2s-1.43-3.2-3.2-3.2s-3.2 1.43-3.2 3.2"/></svg>';

export async function getMyDevProfile() {
  try { return (await window.vt?.market?.me()) || null; }
  catch { return null; }
}

// Mở modal cập nhật hồ sơ. profile = hồ sơ hiện tại (có thể null). Trả Promise<profile|null>.
export function openDevProfileEditor(profile, opts = {}) {
  const title = opts.title || 'Cập nhật thông tin cá nhân';
  const email = String((profile && profile.email) || '');
  let avatar = String((profile && profile.avatar) || '');

  return new Promise((resolve) => {
    let settled = false;
    const finish = (val) => { if (settled) return; settled = true; resolve(val); };

    const nameInp = el('input.input.dvp-name', {
      value: (profile && profile.displayName) || '', placeholder: 'Nhập tên hiển thị', maxlength: '60',
    });

    // Nút xoá ảnh (chỉ hiện khi đã có ảnh) - khai báo TRƯỚC paintAva để toggle được.
    const clearBtn = el('button.dvp-ava-clear.link-btn', {
      type: 'button', text: 'Xoá ảnh',
      onclick: () => { avatar = ''; paintAva(); },
    });

    // Vòng tròn tải ảnh (bấm để chọn). Rỗng → viền nét đứt + máy ảnh + "Tải ảnh lên" (giống
    // mẫu thiết kế); có ảnh → hiện ảnh phủ kín, viền liền.
    const avaBox = el('button.dvp-ava', { type: 'button', title: 'Tải lên ảnh đại diện' });
    const paintAva = () => {
      clear(avaBox);
      if (avatar) {
        avaBox.classList.add('has-img');
        avaBox.appendChild(el('img.dvp-ava-img', { src: avatar }));
      } else {
        avaBox.classList.remove('has-img');
        avaBox.appendChild(el('span.dvp-ava-cam', { html: UPLOAD_ICON }));
        avaBox.appendChild(el('span.dvp-ava-txt', { text: 'Tải ảnh lên' }));
      }
      clearBtn.style.display = avatar ? '' : 'none';
    };
    paintAva();
    avaBox.addEventListener('click', () => {
      const fi = document.createElement('input'); fi.type = 'file'; fi.accept = 'image/*';
      fi.addEventListener('change', () => {
        const f = fi.files && fi.files[0]; if (!f) return;
        if (f.size > MAX_AVATAR_BYTES) { toast('Ảnh quá lớn (tối đa 2MB)', 'err'); return; }
        const rd = new FileReader();
        rd.onload = () => { avatar = String(rd.result || ''); paintAva(); };
        rd.readAsDataURL(f);
      });
      fi.click();
    });

    const emailRow = el('div.dvp-field', {}, [
      el('label.dvp-lbl', { text: 'Email' }),
      el('div.dvp-email', { text: email || '-' }),
    ]);

    const doSave = async (btn) => {
      const name = nameInp.value.trim();
      if (!name) { toast('Vui lòng nhập tên hiển thị', 'err'); nameInp.focus(); return; }
      if (btn) btn.disabled = true;
      let res;
      try { res = await window.vt?.market?.updateProfile({ name, avatar }); }
      catch (err) { res = { ok: false, code: err && err.code, status: err && err.status, error: err && err.message }; }
      if (res && res.ok) {
        closeModal();
        toast('Đã cập nhật thông tin cá nhân', 'ok');
        finish(res.data || { ...(profile || {}), displayName: name, name, avatar });
      } else {
        if (btn) btn.disabled = false;
        toast(describeError(res, 'Cập nhật thông tin thất bại'), 'err');
      }
    };

    openModal({
      title, width: 460,
      body: [el('div.dvp-wrap', {}, [
        el('div.dvp-ava-row', {}, [avaBox, clearBtn]),
        el('div.dvp-field', {}, [
          el('label.dvp-lbl', { html: 'Tên hiển thị <span class="dvp-req">*</span>' }),
          nameInp,
        ]),
        emailRow,
      ])],
      footer: [
        el('button.btn', { text: 'Hủy', onclick: () => { closeModal(); finish(null); } }),
        el('button.btn.primary', { text: 'Lưu', onclick: (e) => doSave(e.currentTarget) }),
      ],
    });
    setTimeout(() => { try { nameInp.focus(); } catch { /* ignore */ } }, 30);
  });
}

// Đảm bảo đã có tên hiển thị trước khi đăng chợ. Trả true nếu sẵn sàng (đã có sẵn hoặc
// vừa cập nhật xong), false nếu người dùng huỷ.
export async function ensureDevProfile() {
  const p = await getMyDevProfile();
  if (p && p.hasProfile) return true;
  const saved = await openDevProfileEditor(p || {}, { title: 'Cập nhật thông tin cá nhân' });
  return !!saved;
}
