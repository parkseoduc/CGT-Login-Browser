// Group-members store ("Thành viên nhóm") - clones MKTLogin's member-group /
// permission model. A workspace has member GROUPS; each group carries a set of
// function permissions, plus its members and pending invites. Members in the same
// group share the same permissions (exactly as MKTLogin states in the create
// dialog). Entries are DEVICE-LOCAL: localStorage + a window-scoped array so they
// survive view re-renders and app reloads (same pattern as activity-log.js /
// rpa-store.js). No server round-trip.

const STORAGE_KEY = 'polyMemberGroups';

// ---- permission catalog ----------------------------------------------------
// Categories + their permissions, mirroring MKTLogin's "Quyền truy cập" matrix
// 1:1 (labels + order captured live from MKTLogin 2.1.2). Each permission is
// addressed by the flat key `${category}:${perm}`.
export const PERMISSION_CATEGORIES = [
  {
    key: 'profile',
    label: 'Quản lý hồ sơ',
    perms: [
      { key: 'open', label: 'Mở' },
      { key: 'move_group', label: 'Chuyển nhóm hồ sơ' },
      { key: 'create', label: 'Tạo' },
      { key: 'delete', label: 'Xoá' },
      { key: 'edit_note', label: 'Chỉnh sửa ghi chú' },
      { key: 'show_note', label: 'Hiển thị ghi chú' },
      { key: 'edit_fingerprint', label: 'Chỉnh sửa dấu vân tay' },
      { key: 'edit_proxy', label: 'Chỉnh sửa proxy' },
      { key: 'renew', label: 'Gia hạn' },
      { key: 'duplicate', label: 'Nhân bản' },
      { key: 'restore', label: 'Khôi phục' },
      { key: 'enable_autorenew', label: 'Bật gia hạn tự động' },
      { key: 'disable_autorenew', label: 'Tắt gia hạn tự động' },
      { key: 'import_resource', label: 'Nhập tài nguyên' },
      { key: 'transfer', label: 'Chuyển đi' },
      { key: 'share', label: 'Chia sẻ' },
    ],
  },
  {
    key: 'profile_group',
    label: 'Quản lý nhóm hồ sơ',
    perms: [
      { key: 'create', label: 'Tạo' },
      { key: 'edit', label: 'Chỉnh sửa' },
      { key: 'delete', label: 'Xoá' },
    ],
  },
  {
    key: 'automation',
    label: 'Quản lý quy trình tự động',
    perms: [
      { key: 'create', label: 'Tạo' },
      { key: 'edit', label: 'Chỉnh sửa' },
      { key: 'delete', label: 'Xóa' },
      { key: 'share', label: 'Chia sẻ' },
      { key: 'import', label: 'Nhập quy trình' },
      { key: 'market', label: 'Đăng chợ' },
      { key: 'download', label: 'Tải về' },
      { key: 'view_source', label: 'Xem mã nguồn / luồng quy trình' },
      { key: 'run', label: 'Chạy quy trình' },
    ],
  },
];

// Roles offered in the invite dialog + their helper text (captured from MKTLogin).
export const MEMBER_ROLES = [
  { key: 'admin', label: 'Quản trị', desc: 'Có đầy đủ các quyền quản lý thành viên, nhóm thành viên trong workspace.' },
  { key: 'manager', label: 'Quản lý', desc: 'Có thể thêm thành viên và chỉnh sửa quyền truy cập của nhóm thành viên đang tham gia.' },
  { key: 'member', label: 'Thành viên', desc: 'Không thể thêm thành viên và chỉnh sửa quyền truy cập của nhóm thành viên.' },
];
export function roleLabel(key) { const r = MEMBER_ROLES.find((x) => x.key === key); return r ? r.label : (key || ''); }

// ---- persistence -----------------------------------------------------------
function load() {
  if (window.__polyMemberGroups) return window.__polyMemberGroups;
  let arr = [];
  try { const raw = localStorage.getItem(STORAGE_KEY); if (raw) arr = JSON.parse(raw) || []; }
  catch { arr = []; }
  window.__polyMemberGroups = Array.isArray(arr) ? arr : [];
  return window.__polyMemberGroups;
}
function save() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(window.__polyMemberGroups || [])); }
  catch { /* quota / disabled storage - keep the in-memory copy */ }
}

// ---- pub/sub (live-refresh the page the instant data changes) --------------
const _subs = (window.__polyMemberSubs = window.__polyMemberSubs || new Set());
export function onMembersChange(cb) { _subs.add(cb); return () => _subs.delete(cb); }
function emit() { _subs.forEach((cb) => { try { cb(); } catch { /* subscriber error */ } }); }

function uid(prefix) { return prefix + '_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8); }

// ---- groups ----------------------------------------------------------------
export function groups() { return load().slice(); }
export function getGroup(id) { return load().find((g) => g.id === id) || null; }

// permissions is an array of flat "cat:perm" keys.
export function createGroup({ name, note = '', permissions = [] }) {
  const arr = load();
  const g = {
    id: uid('mg'),
    name: name || '',
    note: note || '',
    permissions: Array.isArray(permissions) ? permissions.slice() : [],
    members: [],
    invites: [],
    createdAt: Date.now(),
  };
  arr.unshift(g);
  save(); emit();
  return g;
}

export function updateGroup(id, patch = {}) {
  const g = getGroup(id);
  if (!g) return null;
  if (patch.name != null) g.name = patch.name;
  if (patch.note != null) g.note = patch.note;
  if (patch.permissions != null) g.permissions = Array.isArray(patch.permissions) ? patch.permissions.slice() : [];
  save(); emit();
  return g;
}

export function deleteGroup(id) {
  const arr = load();
  const i = arr.findIndex((g) => g.id === id);
  if (i >= 0) { arr.splice(i, 1); save(); emit(); }
}

// ---- invites / members -----------------------------------------------------
// Invite = a pending member (lives in `invites` until accepted). Mirrors the
// MKTLogin "Mời thành viên" flow → shows up under the "Đã mời" tab.
export function inviteMember(groupId, { name, email, role = 'member', sharedGroups = [], balanceLimit = '', note = '' }) {
  const g = getGroup(groupId);
  if (!g) return null;
  const inv = {
    id: uid('inv'),
    name: name || '',
    email: email || '',
    role,
    sharedGroups: Array.isArray(sharedGroups) ? sharedGroups.slice() : [],
    balanceLimit: balanceLimit || '',
    note: note || '',
    invitedAt: Date.now(),
  };
  g.invites.push(inv);
  save(); emit();
  return inv;
}

export function removeInvite(groupId, inviteId) {
  const g = getGroup(groupId);
  if (!g) return;
  g.invites = (g.invites || []).filter((x) => x.id !== inviteId);
  save(); emit();
}

export function removeMember(groupId, memberId) {
  const g = getGroup(groupId);
  if (!g) return;
  g.members = (g.members || []).filter((x) => x.id !== memberId);
  save(); emit();
}
