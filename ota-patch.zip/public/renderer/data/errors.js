// Bộ chuyển LỖI → THÔNG BÁO cho người dùng. Mục tiêu: mọi thao tác không xử lý được
// đều PHẢI báo (toast hoặc modal), tuyệt đối không "đứng im".
//
// Nhận cả Error (throw từ remote-ds: có .code/.status/.message) lẫn envelope thô
// ({ ok:false, code, status, error }) từ IPC/remoteCall.
import { toast, alertDialog } from '../ui.js';
import { PERM_DENIED_NOTE, isPermError } from './team-permissions.js';

// Lấy message gốc dù là Error (.message) hay envelope ({ error }).
function rawMessage(err) {
  if (!err) return '';
  return err.message || err.error || '';
}

// ─── Hết thiết bị ────────────────────────────────────────────────────────────────────────
// Thông báo LUÔN gồm ĐÚNG HAI CÂU:
//   câu 1 = phần message của server TRƯỚC DẤU CHẤM ĐẦU TIÊN (chứa con số "đã dùng/mức")
//   câu 2 = DEVICE_LIMIT_HELP, nguyên văn, không sửa chữ nào
//
// Vì sao CẮT ở dấu chấm đầu thay vì hiện nguyên văn message của server: bản server cũ trả về
// một đoạn 4 câu giảng giải "đăng xuất không mở thêm chỗ, liên hệ hỗ trợ để gỡ...". App đã
// phát hành không tự cập nhật cùng lúc với server, nên nếu chỉ sửa ở server thì khách bản cũ
// vẫn đọc được lời khuyên SAI (đi mở ticket cho việc họ tự làm được ở dashboard). Cắt ở client
// làm cho mọi biến thể message - cũ, mới, hay của một bản server nào khác - đều ra đúng hai câu.
//
// ⚠️ KHÔNG viết "hãy đăng xuất ở máy không dùng nữa" (câu cũ, bỏ 2026-10-01): đăng xuất KHÔNG
// trả lại chỗ, chỉ GỠ thiết bị mới trả. Chỉ khách làm việc vô ích rồi thất bại lần nữa.
const DEVICE_LIMIT_HELP =
  'Vui lòng đăng nhập vào https://cgtdev.space/ để mua thêm thiết bị hoặc gỡ bớt thiết bị để tiếp tục sử dụng.';

export function deviceLimitMessage(raw) {
  const s = String(raw || '').trim();
  const i = s.indexOf('.');
  // Cắt TRƯỚC dấu chấm đầu tiên rồi tự thêm lại dấu chấm. i === -1 (server chỉ trả một mệnh đề
  // không có dấu chấm) vẫn phải ra câu hoàn chỉnh, nên dùng cả chuỗi chứ không trả rỗng.
  const first = (i >= 0 ? s.slice(0, i) : s).trim();
  // Không có message nào (lỗi mạng nuốt body) → vẫn phải nói ra chuyện gì đã xảy ra, không
  // được chỉ đưa câu "vui lòng đăng nhập..." trống không.
  const head = first || 'Tài khoản đã dùng hết số thiết bị được phép của gói';
  return `${head}. ${DEVICE_LIMIT_HELP}`;
}

// Câu tiếng Việt rõ ràng cho một lỗi, ghép với `fallback` (mô tả thao tác đang làm).
export function errorMessage(err, fallback = 'Thao tác thất bại') {
  if (!err) return fallback;
  const code = err.code;
  const status = err.status;
  // Hết CHỖ hồ sơ của gói: server trả message kèm CON SỐ cụ thể và chỉ luôn cách lấy lại chỗ
  // (xoá vĩnh viễn hồ sơ không dùng - mô hình quota/slot). MEMBER_QUOTA_EXCEEDED (hết ghế
  // thành viên) và MEMBER_BALANCE_EXCEEDED (cap admin đặt cho thành viên) là 403 nhưng KHÔNG
  // phải thiếu quyền → xử lý TRƯỚC isPermError.
  if (code === 'QUOTA_EXCEEDED' || code === 'MEMBER_QUOTA_EXCEEDED' || code === 'MEMBER_BALANCE_EXCEEDED') {
    return rawMessage(err) || 'Bạn đã dùng hết số chỗ hồ sơ của gói. Hãy xoá vĩnh viễn hồ sơ không dùng nữa để lấy lại chỗ, hoặc nâng cấp gói.';
  }
  // HẾT LIMIT THEO NGÀY (admin đặt): tạo/ngày và mở/ngày. KHÁC hẳn hết hạn mức gói - nâng cấp
  // gói KHÔNG giải quyết được (mai là làm tiếp được), nên tuyệt đối không dẫn sang trang Nâng
  // cấp. Message của server đã có sẵn mốc reset 00:00 giờ VN và CỐ Ý KHÔNG có con số "đã
  // dùng/limit" (user bỏ 2026-09-27) - đừng ghép số vào fallback dưới cho "khớp", vì khách không
  // mua/không nâng được cái limit đó nên in ra chỉ khiến họ đi tìm chỗ tăng không tồn tại.
  if (code === 'CREATE_RATE_EXCEEDED' || code === 'OPEN_RATE_EXCEEDED') {
    return rawMessage(err) || 'Bạn đã đạt giới hạn trong hôm nay. Limit sẽ được làm mới vào 00:00 hôm sau (giờ Việt Nam).';
  }
  // Gói thuê bao của workspace đã hết hạn → thành viên được mời bị khoá (server 403 nhưng
  // KHÔNG phải thiếu quyền). Xử lý TRƯỚC isPermError để không hiện nhầm "thiếu quyền hạn".
  if (code === 'SUBSCRIPTION_EXPIRED') return rawMessage(err) || 'Gói thuê bao của không gian làm việc đã hết hạn. Vui lòng liên hệ chủ sở hữu để gia hạn.';
  // Tài khoản chưa có gói khả dụng (vd bị chặn gói free do chống gian lận thiết bị "1 máy
  // 1 lần free"): 403 nhưng KHÔNG phải thiếu quyền → xử lý TRƯỚC isPermError.
  if (code === 'NO_ACTIVE_PLAN') return rawMessage(err) || 'Dùng thử trên thiết bị của bạn đã hết khả dụng. Vui lòng mua gói để tạo hồ sơ.';
  // Vượt GIỚI HẠN SỐ THIẾT BỊ đăng nhập: 403 nhưng KHÔNG phải thiếu quyền → trước isPermError.
  if (code === 'DEVICE_LIMIT_EXCEEDED') return deviceLimitMessage(rawMessage(err));
  // Không thể chia sẻ (email đã liên quan tới hồ sơ / trùng / tự-chia-sẻ): server trả
  // LÝ DO cụ thể → hiện nguyên văn để người dùng biết vì sao không mời được.
  if (code === 'ALREADY_RELATED' || code === 'SHARE_EXISTS' || code === 'SELF_SHARE') {
    return rawMessage(err) || fallback;
  }
  // Thiếu quyền.
  if (isPermError(err)) return `${fallback} - ${PERM_DENIED_NOTE}`;
  // Mất kết nối máy chủ.
  if (code === 'NETWORK' || status === 0) return 'Không kết nối được máy chủ. Kiểm tra kết nối rồi thử lại.';
  // Còn lại: ghép message server nếu có để người dùng biết lý do.
  const msg = rawMessage(err);
  return msg ? `${fallback}: ${msg}` : fallback;
}

// Lỗi nào nên hiện MODAL (nhấn mạnh, chặn thao tác) thay vì chỉ toast thoáng qua.
function wantsModal(err) {
  if (!err) return false;
  return err.code === 'QUOTA_EXCEEDED'
    || err.code === 'MEMBER_QUOTA_EXCEEDED'
    || err.code === 'MEMBER_BALANCE_EXCEEDED'
    // Hết limit/ngày cũng là "chặn hẳn, hôm nay không làm được nữa" → modal, không phải toast
    // thoáng qua. Nút vẫn là "Đã hiểu" (canUpgrade dưới đây chỉ nhận QUOTA_EXCEEDED).
    || err.code === 'CREATE_RATE_EXCEEDED'
    || err.code === 'OPEN_RATE_EXCEEDED'
    || err.code === 'SUBSCRIPTION_EXPIRED'
    || err.code === 'NO_ACTIVE_PLAN'
    // Vượt giới hạn thiết bị = chặn hẳn, phải đi làm việc khác (đăng xuất máy cũ) mới vào
    // được → modal, không phải toast thoáng qua rồi mất.
    || err.code === 'DEVICE_LIMIT_EXCEEDED'
    || err.code === 'ALREADY_RELATED'
    || err.code === 'SHARE_EXISTS'
    || err.code === 'SELF_SHARE';
}

// Hiển thị lỗi cho người dùng. Quota → modal; còn lại → toast. Trả về message đã hiện
// để nơi gọi log/tái dùng nếu cần. LUÔN báo - không bao giờ im.
export function notifyError(err, fallback = 'Thao tác thất bại', opts = {}) {
  // Phiên chết: app.js đã đưa về màn đăng nhập kèm một thông báo - không hiện thêm lỗi cho từng lệnh gọi dở dang.
  if (err && err.code === 'SESSION_EXPIRED') return '';
  const message = errorMessage(err, fallback);
  if (wantsModal(err)) {
    // Hết số dư hồ sơ của GÓI → nút dẫn thẳng sang trang Nâng cấp thay vì "Đã hiểu" cụt
    // ngủn. CHỈ áp cho hạn mức gói: MEMBER_BALANCE_EXCEEDED là cap do quản trị viên đặt,
    // thành viên tự nâng cấp cũng vô ích (phải xin admin nới) nên giữ nút "Đã hiểu".
    const canUpgrade = err && err.code === 'QUOTA_EXCEEDED';
    alertDialog({
      title: opts.title || 'Không thể thực hiện',
      message,
      okLabel: canUpgrade ? 'Nâng cấp gói' : undefined,
      onClose: canUpgrade ? goUpgrade : undefined,
    });
  } else {
    toast(message, 'err');
  }
  return message;
}

// Mở trang Nâng cấp gói. Dùng navigate toàn cục như plan-features.js; không có thì nhắc
// người dùng tự vào mục ở thanh bên (không được im lặng nuốt thao tác).
function goUpgrade() {
  const nav = window.__vtApp && window.__vtApp.navigate;
  if (typeof nav === 'function') nav('upgrade');
  else toast('Mở mục Nâng cấp gói ở thanh bên để nâng cấp.', '');
}
