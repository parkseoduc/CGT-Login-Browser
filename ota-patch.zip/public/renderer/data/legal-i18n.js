// Bản dịch en/ru/zh cho Điều khoản sử dụng + Chính sách bảo mật hiển thị trong modal pháp lý (views/login.js
// openLegalModal). SINH TỰ ĐỘNG từ bản dịch pháp lý đã duyệt của web landing (public/i18n-legal.js) - chỉ gồm đúng các
// đoạn app dùng; vài đoạn app viết gọn hơn landing được chỉnh tay cho khớp. Khoá = NGUYÊN VĂN chuỗi tiếng Việt trong
// TERMS_SECTIONS / PRIVACY_SECTIONS ⇒ sửa một chữ tiếng Việt ở login.js thì đoạn đó rơi về tiếng Việt cho tới khi thêm
// lại bản dịch ở đây. Bản tiếng Việt là bản có giá trị pháp lý (modal hiện LEGAL_NOTE ở EN/RU/ZH).
export const LEGAL_NOTE = "Bản dịch này chỉ nhằm mục đích tham khảo. Nếu có khác biệt giữa các bản, bản tiếng Việt là bản có giá trị pháp lý.";
export const LEGAL_TR = {
 "1. Quy định chung": {
  "en": "1. General provisions",
  "ru": "1. Общие положения",
  "zh": "1. 一般规定"
 },
 "Bản Điều khoản Sử dụng này xác lập các nội dung ràng buộc Bạn trong quá trình sử dụng Dịch vụ của CGTBrowser. Các từ “Bạn” và/hoặc “Người sử dụng” dưới đây được dùng chung để chỉ những cá nhân, tổ chức sử dụng Dịch vụ của CGTBrowser. Đề nghị Bạn đọc kỹ và giữ lại một bản Điều khoản Sử dụng này.": {
  "en": "These Terms of Use set out the provisions binding on You in the course of using the Services of CGTBrowser. The terms “You” and/or “User” below are used collectively to refer to the individuals and organizations that use the Services of CGTBrowser. You are requested to read these Terms of Use carefully and retain a copy of them.",
  "ru": "Настоящие Условия использования устанавливают положения, обязательные для Вас в процессе использования Сервисов CGTBrowser. Термины «Вы» и/или «Пользователь» ниже используются в совокупности для обозначения физических лиц и организаций, использующих Сервисы CGTBrowser. Просим Вас внимательно ознакомиться с настоящими Условиями использования и сохранить их копию.",
  "zh": "本使用条款规定了您在使用 CGTBrowser 服务过程中须受约束的内容。下文中的“您”和/或“用户”统一用于指代使用 CGTBrowser 服务的个人和组织。请您仔细阅读并保留一份本使用条款。"
 },
 "Khi Bạn sử dụng Dịch vụ của chúng tôi, Bạn đã chấp nhận chịu ràng buộc bởi bản Điều khoản Sử dụng này. Trường hợp Bạn không chấp nhận sự ràng buộc đó, Bạn cần dừng ngay việc sử dụng Dịch vụ của CGTBrowser.": {
  "en": "By using our Services, You accept to be bound by these Terms of Use. If You do not accept to be so bound, You must immediately stop using the Services of CGTBrowser.",
  "ru": "Используя наши Сервисы, Вы соглашаетесь соблюдать настоящие Условия использования и быть связанными ими. Если Вы не согласны с этим, Вам необходимо немедленно прекратить использование Сервисов CGTBrowser.",
  "zh": "当您使用我们的服务时，即表示您已接受受本使用条款的约束。如您不接受该约束，您须立即停止使用 CGTBrowser 的服务。"
 },
 "Chúng tôi áp dụng bản Điều khoản Sử dụng này theo pháp luật hiện hành, và không có nội dung nào trong đây hạn chế quyền của CGTBrowser trong việc tuân thủ các quy định hoặc yêu cầu từ chính phủ, tòa án, cơ quan thi hành án liên quan tới việc Bạn sử dụng Dịch vụ của CGTBrowser hoặc liên quan tới thông tin mà chúng tôi tiếp nhận, thu được từ quá trình sử dụng Dịch vụ của Bạn.": {
  "en": "We apply these Terms of Use in accordance with applicable law, and nothing herein limits the right of CGTBrowser to comply with any regulations or requests from the government, courts or enforcement authorities relating to Your use of the Services of CGTBrowser or relating to information that we receive or obtain from Your use of the Services.",
  "ru": "Мы применяем настоящие Условия использования в соответствии с действующим законодательством, и ничто в них не ограничивает право CGTBrowser соблюдать предписания или требования правительства, судов и органов исполнения судебных решений, связанные с использованием Вами Сервисов CGTBrowser или с информацией, которую мы получаем в процессе использования Вами Сервисов.",
  "zh": "我们依照现行法律适用本使用条款，本条款中的任何内容均不限制 CGTBrowser 遵守政府、法院、执行机关就您使用 CGTBrowser 服务或就我们从您使用服务过程中接收、获取的信息所作出的规定或要求的权利。"
 },
 "2. Từ chối bảo đảm": {
  "en": "2. Disclaimer of warranties",
  "ru": "2. Отказ от гарантий",
  "zh": "2. 不提供保证"
 },
 "Website và Dịch vụ của CGTBrowser được cung cấp theo nguyên tắc không bảo hành, dựa trên dịch vụ và tính năng hiện có, không kèm bất cứ cam kết bảo đảm nào dù dưới hình thức thể hiện rõ ràng hay ngụ ý. CGTBrowser không cam kết rằng việc vận hành phần mềm hay Dịch vụ của CGTBrowser sẽ liên tục, không gián đoạn hoặc không phát sinh lỗi.": {
  "en": "The website and Services of CGTBrowser are provided without warranty, on the basis of the services and features as currently available, without any commitment or warranty of any kind, whether express or implied. CGTBrowser does not warrant that the operation of the software or Services of CGTBrowser will be continuous, uninterrupted or error-free.",
  "ru": "Веб-сайт и Сервисы CGTBrowser предоставляются без гарантий, на основе имеющихся на данный момент сервисов и функций, без каких-либо обязательств или гарантий, будь то явных или подразумеваемых. CGTBrowser не гарантирует, что работа программного обеспечения или Сервисов CGTBrowser будет непрерывной, бесперебойной или безошибочной.",
  "zh": "CGTBrowser 的网站和服务按不提供保证的原则、基于现有服务和功能提供，不附带任何明示或默示形式的保证承诺。CGTBrowser 不保证 CGTBrowser 软件或服务的运行将持续、不中断或不出现错误。"
 },
 "CGTBrowser không nhận trách nhiệm về bất cứ sự mất mát dữ liệu, thiệt hại lợi ích hay vấn đề nào khác nảy sinh từ việc sử dụng Dịch vụ của CGTBrowser, bao gồm nhưng không giới hạn ở toàn bộ thông tin, dữ liệu, văn bản, phần mềm, âm nhạc, âm thanh, hình ảnh, đồ họa, video, thông điệp hoặc các tư liệu khác (“Nội dung”) mà Bạn lưu giữ, tải lên hay truyền tải qua Dịch vụ. Bạn chấp nhận sử dụng Dịch vụ của CGTBrowser cùng toàn bộ rủi ro đi kèm.": {
  "en": "CGTBrowser assumes no responsibility for any loss of data, loss of benefits or any other issue arising from the use of the Services of CGTBrowser, including but not limited to all information, data, text, software, music, sound, images, graphics, video, messages or other materials (“Content”) that You store, upload or transmit through the Services. You accept to use the Services of CGTBrowser together with all associated risks.",
  "ru": "CGTBrowser не несёт ответственности за какую-либо потерю данных, ущерб интересам или иные проблемы, возникающие в связи с использованием Сервисов CGTBrowser, включая, помимо прочего, всю информацию, данные, тексты, программное обеспечение, музыку, звуки, изображения, графику, видео, сообщения или иные материалы («Контент»), которые Вы храните, загружаете или передаёте через Сервисы. Вы соглашаетесь использовать Сервисы CGTBrowser со всеми сопутствующими рисками.",
  "zh": "CGTBrowser 对因使用 CGTBrowser 服务而产生的任何数据丢失、利益损失或其他问题不承担责任，包括但不限于您通过服务存储、上传或传输的全部信息、数据、文本、软件、音乐、声音、图像、图形、视频、消息或其他资料（“内容”）。您接受使用 CGTBrowser 服务并承担随之而来的全部风险。"
 },
 "3. Thay đổi điều khoản sử dụng": {
  "en": "3. Changes to the terms of use",
  "ru": "3. Изменение условий использования",
  "zh": "3. 使用条款的变更"
 },
 "CGTBrowser bảo lưu quyền thay đổi và/hoặc điều chỉnh bất cứ nội dung nào trong bản Điều khoản Sử dụng này vào từng thời điểm mà không cần thông báo trước. Các thay đổi và/hoặc điều chỉnh đó phát sinh hiệu lực ngay khi được đăng tải lên website này. Trường hợp Bạn vẫn tiếp tục sử dụng Dịch vụ của CGTBrowser sau khi những thay đổi và/hoặc điều chỉnh đã được đăng tải, điều đó có nghĩa Bạn đã chấp nhận và đồng thuận với các thay đổi, điều chỉnh ấy.": {
  "en": "CGTBrowser reserves the right to change and/or modify any provision of these Terms of Use from time to time without prior notice. Such changes and/or modifications shall take effect immediately upon being posted on this website. If You continue to use the Services of CGTBrowser after such changes and/or modifications have been posted, this means that You have accepted and agreed to such changes and modifications.",
  "ru": "CGTBrowser оставляет за собой право время от времени изменять и/или корректировать любые положения настоящих Условий использования без предварительного уведомления. Такие изменения и/или корректировки вступают в силу сразу после их размещения на этом веб-сайте. Если Вы продолжаете использовать Сервисы CGTBrowser после размещения изменений и/или корректировок, это означает, что Вы приняли такие изменения и корректировки и согласились с ними.",
  "zh": "CGTBrowser 保留随时变更和/或调整本使用条款中任何内容的权利，无需事先通知。该等变更和/或调整自发布于本网站之时起立即生效。如您在变更和/或调整发布后仍继续使用 CGTBrowser 服务，即表示您已接受并同意该等变更和调整。"
 },
 "4. Hành vi bị cấm khi sử dụng dịch vụ": {
  "en": "4. Prohibited conduct when using the services",
  "ru": "4. Запрещённые действия при использовании сервисов",
  "zh": "4. 使用服务时的禁止行为"
 },
 "Bạn có nghĩa vụ sử dụng Dịch vụ của CGTBrowser đúng với quy định hiện hành của pháp luật Việt Nam. CGTBrowser không dung túng hay chấp thuận bất cứ hành vi trái pháp luật hoặc bị cấm nào liên quan tới Dịch vụ của CGTBrowser. Sau đây là một số hành vi trái pháp luật hoặc bị cấm khi Bạn sử dụng Dịch vụ của CGTBrowser. Chúng tôi bảo lưu quyền điều tra và áp dụng các biện pháp pháp lý cần thiết với bất cứ ai, theo quyết định của CGTBrowser, vi phạm quy định này, bao gồm nhưng không giới hạn ở việc trình báo tới các Cơ quan Quản lý Nhà nước.": {
  "en": "You are obliged to use the Services of CGTBrowser in compliance with the applicable provisions of the laws of Vietnam. CGTBrowser does not tolerate or approve any unlawful or prohibited conduct in connection with the Services of CGTBrowser. The following are certain acts that are unlawful or prohibited when You use the Services of CGTBrowser. We reserve the right to investigate and take necessary legal action against anyone who, as determined by CGTBrowser, violates this provision, including but not limited to reporting to the state authorities.",
  "ru": "Вы обязаны использовать Сервисы CGTBrowser в соответствии с действующими нормами законодательства Вьетнама. CGTBrowser не потворствует и не одобряет какие-либо противоправные или запрещённые действия, связанные с Сервисами CGTBrowser. Ниже приведены некоторые действия, являющиеся противоправными или запрещёнными при использовании Вами Сервисов CGTBrowser. Мы оставляем за собой право проводить расследование и применять необходимые правовые меры к любому лицу, которое, по решению CGTBrowser, нарушает данное положение, включая, помимо прочего, сообщение в государственные органы.",
  "zh": "您有义务按照越南法律的现行规定使用 CGTBrowser 服务。CGTBrowser 不纵容或认可与 CGTBrowser 服务相关的任何违法或被禁止的行为。以下是您在使用 CGTBrowser 服务时属于违法或被禁止的若干行为。对于经 CGTBrowser 认定违反本规定的任何人，我们保留进行调查并采取必要法律措施的权利，包括但不限于向国家主管机关举报。"
 },
 "Bạn không được thực hiện các hành vi bị cấm, bao gồm nhưng không giới hạn ở việc lợi dụng Internet nhằm:": {
  "en": "You must not commit prohibited acts, including but not limited to using the Internet to:",
  "ru": "Вам запрещается совершать запрещённые действия, включая, помимо прочего, использование Интернета с целью:",
  "zh": "您不得实施被禁止的行为，包括但不限于利用互联网从事以下活动："
 },
 "Chống phá nhà nước Cộng hòa Xã hội Chủ nghĩa Việt Nam; làm phương hại tới an ninh quốc gia, trật tự, an toàn xã hội; phá hoại khối đại đoàn kết toàn dân; cổ vũ chiến tranh xâm lược; khơi dậy hận thù, mâu thuẫn, kỳ thị giữa các dân tộc, sắc tộc, tôn giáo;": {
  "en": "Oppose the State of the Socialist Republic of Vietnam; harm national security, social order and safety; undermine the great national unity bloc; propagandize wars of aggression; incite hatred, conflict and discrimination among ethnic groups, races and religions;",
  "ru": "Выступать против государства Социалистическая Республика Вьетнам; наносить ущерб национальной безопасности, общественному порядку и общественной безопасности; подрывать великое единство всего народа; пропагандировать агрессивную войну; разжигать ненависть, конфликты и дискриминацию между народами, этническими группами и религиями;",
  "zh": "反对越南社会主义共和国国家；危害国家安全、社会秩序与安全；破坏全民族大团结；宣扬侵略战争；挑起民族、种族、宗教之间的仇恨、矛盾和歧视；"
 },
 "Cổ vũ, kích động bạo lực, dâm ô, đồi trụy, tội ác, tệ nạn xã hội, mê tín dị đoan; làm tổn hại thuần phong, mỹ tục của dân tộc;": {
  "en": "Promote or incite violence, obscenity, depravity, crime, social evils or superstition; harm the fine customs and traditions of the nation;",
  "ru": "Пропагандировать насилие, непристойность, разврат, преступность, социальные пороки, суеверия или подстрекать к ним; наносить ущерб добрым обычаям и традициям народа;",
  "zh": "宣扬、煽动暴力、淫秽、堕落、犯罪、社会恶习、迷信；损害民族的优良风俗习惯；"
 },
 "Làm lộ bí mật nhà nước, bí mật quân sự, an ninh, kinh tế, đối ngoại cùng những bí mật khác mà pháp luật đã quy định;": {
  "en": "Disclose state secrets, military, security, economic and foreign affairs secrets and other secrets as prescribed by law;",
  "ru": "Разглашать государственную тайну, военную тайну, тайны в сфере безопасности, экономики и внешних сношений, а также иные тайны, предусмотренные законом;",
  "zh": "泄露国家秘密、军事、安全、经济、外交秘密以及法律规定的其他秘密；"
 },
 "Phát tán thông tin xuyên tạc, vu khống, làm tổn hại uy tín của tổ chức, danh dự và nhân phẩm của công dân;": {
  "en": "Disseminate distorted or slanderous information, or information that harms the reputation of organizations or the honor and dignity of citizens;",
  "ru": "Распространять искажённую и клеветническую информацию, наносящую ущерб репутации организаций, чести и достоинству граждан;",
  "zh": "散布歪曲、诽谤信息，损害组织的声誉以及公民的名誉和人格尊严；"
 },
 "Lợi dụng Internet nhằm quảng cáo, tuyên truyền, mua bán hàng hóa, dịch vụ nằm trong danh mục cấm theo quy định pháp luật;": {
  "en": "Use the Internet to advertise, promote or trade in goods and services on the list of items prohibited by law;",
  "ru": "Использовать Интернет для рекламы, пропаганды, купли-продажи товаров и услуг, включённых в перечень запрещённых в соответствии с законодательством;",
  "zh": "利用互联网对法律规定禁止的货物、服务进行广告、宣传或买卖；"
 },
 "Xâm hại quyền sở hữu trí tuệ;": {
  "en": "Infringe intellectual property rights;",
  "ru": "Нарушать права интеллектуальной собственности;",
  "zh": "侵犯知识产权；"
 },
 "Sản xuất, phát hành sản phẩm công nghệ thông tin trái pháp luật;": {
  "en": "Produce or distribute unlawful information technology products;",
  "ru": "Производить и распространять незаконные продукты информационных технологий;",
  "zh": "制作、发行违法的信息技术产品；"
 },
 "Thiết lập đường dẫn trái phép tới tên miền của tổ chức, cá nhân đang sử dụng hợp pháp tên miền đó;": {
  "en": "Create unauthorized links to the domain names of organizations or individuals that are lawfully using those domain names;",
  "ru": "Создавать несанкционированные ссылки на доменные имена организаций и физических лиц, правомерно использующих эти доменные имена;",
  "zh": "非法设置指向合法使用该域名的组织、个人之域名的链接；"
 },
 "Quấy rối, phá hoại hệ thống thiết bị và cản trở trái pháp luật hoạt động quản lý, cung cấp, sử dụng dịch vụ Internet cùng thông tin điện tử trên Internet;": {
  "en": "Harass or sabotage equipment systems, and unlawfully obstruct the management, provision and use of Internet services and electronic information on the Internet;",
  "ru": "Нарушать работу и выводить из строя системы оборудования, а также незаконно препятствовать управлению, предоставлению и использованию интернет-услуг и электронной информации в Интернете;",
  "zh": "骚扰、破坏设备系统，非法阻碍互联网服务及互联网电子信息的管理、提供和使用活动；"
 },
 "Chiếm đoạt và sử dụng trái phép mật khẩu, khóa mật mã, thông tin riêng của các tổ chức, cá nhân trên Internet;": {
  "en": "Misappropriate and unlawfully use passwords, cryptographic keys and private information of organizations and individuals on the Internet;",
  "ru": "Незаконно завладевать и пользоваться паролями, криптографическими ключами и личной информацией организаций и физических лиц в Интернете;",
  "zh": "窃取并非法使用互联网上组织、个人的密码、密钥及私人信息；"
 },
 "Tạo lập và cài đặt virus máy tính, phần mềm độc hại nhằm thực hiện một trong các hành vi trái pháp luật về công nghệ thông tin.": {
  "en": "Create and install computer viruses or malicious software in order to commit any of the unlawful acts relating to information technology.",
  "ru": "Создавать и устанавливать компьютерные вирусы и вредоносное программное обеспечение для совершения любого из противоправных действий в сфере информационных технологий.",
  "zh": "制作、安装计算机病毒、恶意软件，以实施任何信息技术领域的违法行为。"
 },
 "5. Quy định sử dụng dịch vụ": {
  "en": "5. Rules for using the services",
  "ru": "5. Правила использования сервисов",
  "zh": "5. 服务使用规定"
 },
 "Trong quá trình sử dụng Dịch vụ của CGTBrowser, Bạn chịu ràng buộc phải chấp thuận và tuân thủ những điều kiện dưới đây:": {
  "en": "In the course of using the Services of CGTBrowser, You are bound to accept and comply with the following conditions:",
  "ru": "В процессе использования Сервисов CGTBrowser Вы обязаны принять и соблюдать следующие условия:",
  "zh": "在使用 CGTBrowser 服务的过程中，您须接受并遵守以下条件："
 },
 "CGTBrowser trao cho Bạn quyền sử dụng miễn phí, không thu phí bản quyền, không được chuyển nhượng và không mang tính độc quyền đối với phần mềm trình duyệt CGTBrowser cùng Dịch vụ. Bạn không được phép và cũng không được để bất cứ ai khác sao chép, tạo sản phẩm phái sinh hay tìm cách trích xuất mã nguồn của phần mềm trình duyệt CGTBrowser.": {
  "en": "CGTBrowser grants You a free-of-charge, royalty-free, non-transferable and non-exclusive right to use the CGTBrowser browser software and the Services. You may not, and may not permit anyone else to, copy, create derivative works of, or attempt to extract the source code of the CGTBrowser browser software.",
  "ru": "CGTBrowser предоставляет Вам бесплатное, не предусматривающее уплаты лицензионного вознаграждения, непередаваемое и неисключительное право на использование браузерного ПО CGTBrowser и Сервисов. Вы не вправе сами и не вправе позволять кому-либо другому копировать браузерное ПО CGTBrowser, создавать производные от него продукты или пытаться извлечь его исходный код.",
  "zh": "CGTBrowser 授予您对 CGTBrowser 浏览器软件及服务免费、免版权费、不可转让且非独占的使用权。您不得且不得允许任何其他人复制 CGTBrowser 浏览器软件、创建其衍生产品或试图提取其源代码。"
 },
 "Phần mềm trình duyệt CGTBrowser mà Bạn sử dụng có thể tự động tải về và cài đặt định kỳ các bản cập nhật nhằm khắc phục lỗi, cải tiến, nâng cấp và hoàn thiện Dịch vụ của CGTBrowser. Bạn chấp thuận tiếp nhận và cho phép CGTBrowser vận hành cơ chế cập nhật phần mềm như vậy trong suốt quá trình Bạn sử dụng Dịch vụ.": {
  "en": "The CGTBrowser browser software that You use may automatically download and install updates periodically in order to fix errors, improve, upgrade and refine the Services of CGTBrowser. You agree to receive such updates and permit CGTBrowser to operate such a software update mechanism throughout Your use of the Services.",
  "ru": "Используемое Вами браузерное ПО CGTBrowser может периодически автоматически загружать и устанавливать обновления в целях исправления ошибок, улучшения, модернизации и совершенствования Сервисов CGTBrowser. Вы соглашаетесь получать такие обновления и разрешаете CGTBrowser использовать такой механизм обновления ПО в течение всего периода использования Вами Сервисов.",
  "zh": "您所使用的 CGTBrowser 浏览器软件可能会定期自动下载并安装更新，以修复错误、改进、升级和完善 CGTBrowser 服务。您同意接收更新，并允许 CGTBrowser 在您使用服务的整个过程中运行此类软件更新机制。"
 },
 "Bạn chấp thuận và thừa nhận rằng các Nội dung thuộc trách nhiệm riêng của người sở hữu Nội dung đó. CGTBrowser có quyền nhưng không mang nghĩa vụ kiểm duyệt, sàng lọc, khước từ, chỉnh sửa hay thay đổi bất cứ Nội dung nào hiện diện trên Dịch vụ của CGTBrowser. Bạn phải tự gánh chịu rủi ro khi sử dụng Dịch vụ của CGTBrowser, mặc dù trong quá trình cung cấp Dịch vụ, CGTBrowser vẫn áp dụng các công cụ nhằm sàng lọc thông tin có nội dung không phù hợp, vi phạm quy định của pháp luật Việt Nam.": {
  "en": "You agree and acknowledge that Content is the sole responsibility of the owner of such Content. CGTBrowser has the right, but not the obligation, to review, screen, refuse, edit or change any Content present on the Services of CGTBrowser. You must bear the risks of using the Services of CGTBrowser yourself, even though, in the course of providing the Services, CGTBrowser still applies tools to filter out information with content that is inappropriate or violates the laws of Vietnam.",
  "ru": "Вы соглашаетесь и признаёте, что ответственность за Контент несёт исключительно его владелец. CGTBrowser имеет право, но не обязанность, проверять, фильтровать, отклонять, редактировать или изменять любой Контент, размещённый в Сервисах CGTBrowser. Вы самостоятельно несёте риски, связанные с использованием Сервисов CGTBrowser, несмотря на то что в процессе предоставления Сервисов CGTBrowser применяет инструменты для фильтрации информации, содержание которой является неприемлемым или нарушает законодательство Вьетнама.",
  "zh": "您同意并承认，内容由该内容的所有者自行负责。CGTBrowser 有权但无义务审查、筛选、拒绝、编辑或更改 CGTBrowser 服务上出现的任何内容。您须自行承担使用 CGTBrowser 服务的风险，尽管在提供服务的过程中，CGTBrowser 仍会采用工具筛选内容不当、违反越南法律规定的信息。"
 },
 "Bạn chấp thuận rằng Bạn phải gánh trách nhiệm cho hành vi của mình và cho bất cứ Nội dung nào mà Bạn thu được, tạo lập, trưng bày hay truyền tải khi sử dụng Dịch vụ của chúng tôi, cũng như những hậu quả nếu có phát sinh từ hành vi sử dụng và Nội dung của Bạn. Bạn chấp thuận rằng Bạn chỉ sử dụng Dịch vụ của chúng tôi vào các mục đích hợp pháp, hợp lệ, đúng với quy định trong Điều khoản Sử dụng và Chính sách Bảo mật của CGTBrowser cùng những hướng dẫn hay chính sách khác mà chúng tôi ban hành.": {
  "en": "You agree that You are responsible for Your own conduct and for any Content that You obtain, create, display or transmit when using our Services, as well as for any consequences, if any, arising from Your use and Your Content. You agree that You will use our Services only for lawful and legitimate purposes, in accordance with the Terms of Use and Privacy Policy of CGTBrowser and any other guidelines or policies that we issue.",
  "ru": "Вы соглашаетесь с тем, что несёте ответственность за свои действия и за любой Контент, который Вы получаете, создаёте, демонстрируете или передаёте при использовании наших Сервисов, а также за последствия, которые могут возникнуть в связи с использованием Вами Сервисов и Вашим Контентом. Вы соглашаетесь использовать наши Сервисы только в законных и правомерных целях, в соответствии с Условиями использования и Политикой конфиденциальности CGTBrowser, а также иными руководствами или политиками, которые мы издаём.",
  "zh": "您同意，您须对自己的行为以及您在使用我们的服务时获取、创建、展示或传输的任何内容负责，并对您的使用行为及内容所产生的后果（如有）负责。您同意仅将我们的服务用于合法、正当的目的，并符合 CGTBrowser 的使用条款和隐私政策以及我们发布的其他指南或政策的规定。"
 },
 "Bạn chấp thuận rằng CGTBrowser sẽ không gánh trách nhiệm nếu bất cứ Nội dung nào của Bạn bị xóa hoặc không lưu trữ được trong quá trình chúng tôi duy trì và cung cấp Dịch vụ.": {
  "en": "You agree that CGTBrowser shall not be responsible if any of Your Content is deleted or cannot be stored in the course of our maintaining and providing the Services.",
  "ru": "Вы соглашаетесь с тем, что CGTBrowser не несёт ответственности, если какой-либо Ваш Контент будет удалён или не сможет быть сохранён в процессе поддержания и предоставления нами Сервисов.",
  "zh": "您同意，如您的任何内容在我们维护和提供服务的过程中被删除或未能存储，CGTBrowser 不承担责任。"
 },
 "Bạn chấp thuận rằng Bạn sẽ không kinh doanh, khai thác, sản xuất lại, sao chép hay sử dụng Dịch vụ của CGTBrowser vào mục đích thương mại, trừ khi có sự đồng thuận bằng văn bản của CGTBrowser.": {
  "en": "You agree that You will not trade, exploit, reproduce, copy or use the Services of CGTBrowser for commercial purposes, unless with the written consent of CGTBrowser.",
  "ru": "Вы соглашаетесь не продавать, не эксплуатировать, не воспроизводить, не копировать и не использовать Сервисы CGTBrowser в коммерческих целях без письменного согласия CGTBrowser.",
  "zh": "您同意，除非获得 CGTBrowser 的书面同意，否则您不得为商业目的经营、利用、再生产、复制或使用 CGTBrowser 服务。"
 },
 "Bạn thừa nhận rằng CGTBrowser cung cấp một số Dịch vụ có kèm nội dung quảng cáo và trưng bày các quảng cáo, khuyến mãi. Bạn chấp thuận rằng CGTBrowser được phép đặt những thông tin quảng cáo, khuyến mãi như vậy tại Dịch vụ, và CGTBrowser sẽ không gánh bất cứ trách nhiệm nào đối với thiệt hại, mất mát mà Bạn phải chịu do sự xuất hiện của các dịch vụ quảng cáo, khuyến mãi, hoặc do Bạn thường xuyên phải tiếp nhận những thông tin quảng cáo, khuyến mãi ấy khi sử dụng Dịch vụ của CGTBrowser.": {
  "en": "You acknowledge that CGTBrowser provides certain Services that contain advertising content and display advertisements and promotions. You agree that CGTBrowser may place such advertising and promotional information on the Services, and that CGTBrowser shall bear no responsibility whatsoever for any damage or loss that You suffer due to the presence of such advertising or promotional services, or due to Your regularly having to receive such advertising and promotional information when using the Services of CGTBrowser.",
  "ru": "Вы признаёте, что CGTBrowser предоставляет некоторые Сервисы, содержащие рекламные материалы, и демонстрирует рекламу и промоакции. Вы соглашаетесь с тем, что CGTBrowser вправе размещать такую рекламную информацию и информацию о промоакциях в Сервисах и что CGTBrowser не несёт никакой ответственности за ущерб или потери, понесённые Вами в связи с наличием рекламных сервисов и промоакций или в связи с тем, что Вам регулярно приходится получать такую рекламную информацию и информацию о промоакциях при использовании Сервисов CGTBrowser.",
  "zh": "您承认，CGTBrowser 提供的部分服务附带广告内容并展示广告、促销信息。您同意 CGTBrowser 可在服务中放置此类广告、促销信息，且对于因广告、促销服务的出现，或因您在使用 CGTBrowser 服务时经常须接收此类广告、促销信息而给您造成的任何损害、损失，CGTBrowser 不承担任何责任。"
 },
 "Bạn thừa nhận rằng CGTBrowser có thể liên kết hoặc cung cấp đường dẫn tới các website khác, và Bạn chấp thuận rằng CGTBrowser không kiểm soát cũng như không gánh trách nhiệm với bất cứ Nội dung, quảng cáo, dịch vụ, sản phẩm nào mà Bạn thu được hay biết tới từ những website đó. Đồng thời Bạn cũng xác nhận rằng CGTBrowser sẽ không gánh trách nhiệm với thiệt hại, mất mát mà Bạn phải chịu bắt nguồn từ hoặc do việc Bạn sử dụng Nội dung, quảng cáo, dịch vụ, sản phẩm từ những website như vậy.": {
  "en": "You acknowledge that CGTBrowser may link to or provide links to other websites, and You agree that CGTBrowser neither controls nor bears responsibility for any Content, advertisements, services or products that You obtain or learn of from such websites. You also confirm that CGTBrowser shall not be responsible for any damage or loss that You suffer arising from or due to Your use of Content, advertisements, services or products from such websites.",
  "ru": "Вы признаёте, что CGTBrowser может быть связан с другими веб-сайтами или предоставлять ссылки на них, и соглашаетесь с тем, что CGTBrowser не контролирует какой-либо Контент, рекламу, сервисы или продукты, которые Вы получаете или о которых узнаёте с таких веб-сайтов, и не несёт за них ответственности. Вы также подтверждаете, что CGTBrowser не несёт ответственности за ущерб или потери, понесённые Вами в результате или по причине использования Вами Контента, рекламы, сервисов или продуктов с таких веб-сайтов.",
  "zh": "您承认，CGTBrowser 可能链接至或提供指向其他网站的链接，且您同意 CGTBrowser 不控制您从该等网站获取或知悉的任何内容、广告、服务、产品，也不对其承担责任。同时，您亦确认，对于源于或由于您使用该等网站的内容、广告、服务、产品而给您造成的损害、损失，CGTBrowser 不承担责任。"
 },
 "Bạn chấp thuận rằng Bạn sẽ không tham gia bất cứ hoạt động hay thực hiện bất cứ hành vi nào có thể hoặc đe dọa gây gián đoạn, tạm ngừng Dịch vụ của CGTBrowser hay các dịch vụ, mạng lưới liên kết với Dịch vụ của CGTBrowser.": {
  "en": "You agree that You will not engage in any activity or perform any act that may disrupt or suspend, or threatens to disrupt or suspend, the Services of CGTBrowser or the services and networks connected with the Services of CGTBrowser.",
  "ru": "Вы соглашаетесь не участвовать в какой-либо деятельности и не совершать каких-либо действий, которые могут вызвать или угрожают вызвать сбой или приостановку работы Сервисов CGTBrowser либо сервисов и сетей, связанных с Сервисами CGTBrowser.",
  "zh": "您同意，您不会参与任何可能或威胁导致 CGTBrowser 服务或与 CGTBrowser 服务相关联的服务、网络中断、暂停的活动，也不会实施任何此类行为。"
 },
 "Bạn chấp thuận rằng CGTBrowser, với toàn quyền quyết định của mình, được phép ngừng cung cấp Dịch vụ cho Bạn nếu CGTBrowser cho rằng Bạn đã vi phạm hoặc thực hiện không đúng các điều kiện sử dụng Dịch vụ của CGTBrowser.": {
  "en": "You agree that CGTBrowser, at its sole discretion, may stop providing the Services to You if CGTBrowser considers that You have violated or failed to properly comply with the conditions of use of the Services of CGTBrowser.",
  "ru": "Вы соглашаетесь с тем, что CGTBrowser по своему исключительному усмотрению вправе прекратить предоставление Вам Сервисов, если CGTBrowser сочтёт, что Вы нарушили или ненадлежащим образом выполнили условия использования Сервисов CGTBrowser.",
  "zh": "您同意，如 CGTBrowser 认为您违反或未正确履行 CGTBrowser 服务的使用条件，CGTBrowser 可自行全权决定停止向您提供服务。"
 },
 "Bạn chấp thuận và thừa nhận rằng CGTBrowser có toàn quyền quyết định và vào bất cứ thời điểm nào chấm dứt việc cung cấp toàn bộ hay một phần Dịch vụ, có thể kèm hoặc không kèm thông báo. Bạn chấp thuận rằng mọi việc chấm dứt quyền sử dụng Dịch vụ của Bạn theo bất cứ quy định nào trong bản Điều khoản Sử dụng này đều phát sinh hiệu lực mà không cần báo trước. Đồng thời, Bạn chấp thuận rằng CGTBrowser không gánh trách nhiệm với Bạn hay với bất cứ bên thứ ba nào do việc Bạn bị chấm dứt quyền sử dụng Dịch vụ.": {
  "en": "You agree and acknowledge that CGTBrowser has full discretion to terminate, at any time, the provision of all or part of the Services, with or without notice. You agree that any termination of Your right to use the Services under any provision of these Terms of Use shall take effect without prior notice. You further agree that CGTBrowser shall not be liable to You or to any third party for the termination of Your right to use the Services.",
  "ru": "Вы соглашаетесь и признаёте, что CGTBrowser по своему полному усмотрению и в любое время вправе прекратить предоставление всех Сервисов или их части с уведомлением или без него. Вы соглашаетесь с тем, что любое прекращение Вашего права на использование Сервисов в соответствии с любым положением настоящих Условий использования вступает в силу без предварительного уведомления. Кроме того, Вы соглашаетесь с тем, что CGTBrowser не несёт ответственности перед Вами или какой-либо третьей стороной в связи с прекращением Вашего права на использование Сервисов.",
  "zh": "您同意并承认，CGTBrowser 有权全权决定于任何时候终止提供全部或部分服务，可附带或不附带通知。您同意，依据本使用条款任何规定终止您使用服务的权利，均无需事先通知即生效。同时，您同意 CGTBrowser 不因终止您使用服务的权利而对您或任何第三方承担责任。"
 },
 "6. Các điều khoản dịch vụ và chính sách bổ sung áp dụng cho một số sản phẩm, dịch vụ nhất định": {
  "en": "6. Additional terms of service and policies applicable to certain products and services",
  "ru": "6. Дополнительные условия обслуживания и политики, применимые к отдельным продуктам и услугам",
  "zh": "6. 适用于特定产品和服务的补充服务条款和政策"
 },
 "Trước hết, bản Điều khoản Sử dụng này áp dụng cho toàn bộ Dịch vụ của CGTBrowser. Bên cạnh đó, chúng tôi liệt kê dưới đây các Điều khoản dịch vụ và chính sách bổ sung áp dụng riêng cho một số dịch vụ nhất định của CGTBrowser, cụ thể:": {
  "en": "First and foremost, these Terms of Use apply to all Services of CGTBrowser. In addition, we list below the supplementary Terms of Service and policies that apply specifically to certain services of CGTBrowser, namely:",
  "ru": "Прежде всего, настоящие Условия использования применяются ко всем Сервисам CGTBrowser. Помимо этого, ниже мы перечисляем дополнительные Условия предоставления услуг и политики, применяемые отдельно к определённым сервисам CGTBrowser, а именно:",
  "zh": "首先，本使用条款适用于 CGTBrowser 的全部服务。此外，我们在下文列出专门适用于 CGTBrowser 某些特定服务的补充服务条款和政策，具体如下："
 },
 "6.1. Trình duyệt CGTBrowser": {
  "en": "6.1. CGTBrowser Browser",
  "ru": "6.1. Браузер CGTBrowser",
  "zh": "6.1. CGTBrowser 浏览器"
 },
 "Điều khoản dịch vụ - Quy định chung": {
  "en": "Terms of Service - General provisions",
  "ru": "Условия предоставления услуг - Общие положения",
  "zh": "服务条款 - 一般规定"
 },
 "Bản Điều khoản Sử dụng này xác lập các nội dung ràng buộc Bạn khi sử dụng Dịch vụ của CGTBrowser. Các từ “Bạn” và/hoặc “Người sử dụng” dưới đây được dùng chung để chỉ những cá nhân, tổ chức sử dụng Dịch vụ của CGTBrowser. Đề nghị Bạn đọc kỹ và giữ lại một bản Điều khoản Sử dụng này. Khi Bạn tải phần mềm và sử dụng Dịch vụ của chúng tôi, Bạn đã chấp nhận chịu ràng buộc bởi bản Điều khoản Sử dụng này. Trường hợp Bạn không chấp nhận sự ràng buộc đó, Bạn cần dừng ngay việc sử dụng Dịch vụ của CGTBrowser.": {
  "en": "These Terms of Use set out the provisions binding on You when using the Services of CGTBrowser. The terms “You” and/or “User” below are used collectively to refer to the individuals and organizations that use the Services of CGTBrowser. You are requested to read these Terms of Use carefully and retain a copy of them. By downloading the software and using our Services, You accept to be bound by these Terms of Use. If You do not accept to be so bound, You must immediately stop using the Services of CGTBrowser.",
  "ru": "Настоящие Условия использования устанавливают положения, обязательные для Вас при использовании Сервисов CGTBrowser. Термины «Вы» и/или «Пользователь» ниже используются в совокупности для обозначения физических лиц и организаций, использующих Сервисы CGTBrowser. Просим Вас внимательно ознакомиться с настоящими Условиями использования и сохранить их копию. Загружая программное обеспечение и используя наши Сервисы, Вы соглашаетесь соблюдать настоящие Условия использования и быть связанными ими. Если Вы не согласны с этим, Вам необходимо немедленно прекратить использование Сервисов CGTBrowser.",
  "zh": "本使用条款规定了您在使用 CGTBrowser 服务时须受约束的内容。下文中的“您”和/或“用户”统一用于指代使用 CGTBrowser 服务的个人和组织。请您仔细阅读并保留一份本使用条款。当您下载软件并使用我们的服务时，即表示您已接受受本使用条款的约束。如您不接受该约束，您须立即停止使用 CGTBrowser 的服务。"
 },
 "Bạn xác nhận và chấp thuận rằng giữa Bạn và CGTBrowser không tồn tại bất cứ quan hệ liên doanh, đối tác, quan hệ lao động hay quan hệ đại lý nào phát sinh từ bản Điều khoản Sử dụng này hoặc từ việc Bạn sử dụng Dịch vụ của CGTBrowser. Chúng tôi áp dụng bản Điều khoản Sử dụng này theo pháp luật hiện hành, và không có nội dung nào trong đây hạn chế quyền của CGTBrowser trong việc tuân thủ các quy định hoặc yêu cầu từ chính phủ, tòa án, cơ quan thi hành án liên quan tới việc Bạn sử dụng Dịch vụ của CGTBrowser hoặc liên quan tới thông tin mà chúng tôi tiếp nhận, thu được từ quá trình sử dụng Dịch vụ của Bạn.": {
  "en": "You confirm and agree that no joint venture, partnership, employment or agency relationship exists between You and CGTBrowser as a result of these Terms of Use or Your use of the Services of CGTBrowser. We apply these Terms of Use in accordance with applicable law, and nothing herein limits the right of CGTBrowser to comply with any regulations or requests from the government, courts or enforcement authorities relating to Your use of the Services of CGTBrowser or relating to information that we receive or obtain from Your use of the Services.",
  "ru": "Вы подтверждаете и соглашаетесь с тем, что между Вами и CGTBrowser не возникает каких-либо отношений совместного предприятия, партнёрства, трудовых или агентских отношений в силу настоящих Условий использования или использования Вами Сервисов CGTBrowser. Мы применяем настоящие Условия использования в соответствии с действующим законодательством, и ничто в них не ограничивает право CGTBrowser соблюдать предписания или требования правительства, судов и органов исполнения судебных решений, связанные с использованием Вами Сервисов CGTBrowser или с информацией, которую мы получаем в процессе использования Вами Сервисов.",
  "zh": "您确认并同意，您与 CGTBrowser 之间不因本使用条款或您使用 CGTBrowser 服务而存在任何合资、合伙、劳动或代理关系。我们依照现行法律适用本使用条款，本条款中的任何内容均不限制 CGTBrowser 遵守政府、法院、执行机关就您使用 CGTBrowser 服务或就我们从您使用服务过程中接收、获取的信息所作出的规定或要求的权利。"
 },
 "Từ chối bảo đảm": {
  "en": "Disclaimer of warranties",
  "ru": "Отказ от гарантий",
  "zh": "不提供保证"
 },
 "Website và Dịch vụ của CGTBrowser được cung cấp theo nguyên tắc không bảo hành, dựa trên dịch vụ và tính năng hiện có, không kèm bất cứ cam kết bảo đảm nào dù dưới hình thức thể hiện rõ ràng hay ngụ ý. CGTBrowser không cam kết rằng Dịch vụ của chúng tôi sẽ thỏa mãn các nhu cầu của Bạn, cũng không cam kết rằng việc vận hành phần mềm hay Dịch vụ của CGTBrowser sẽ liên tục, không gián đoạn hoặc không phát sinh lỗi.": {
  "en": "The website and Services of CGTBrowser are provided on a no-warranty basis, based on the services and features currently available, without any warranty whatsoever, whether express or implied. CGTBrowser does not warrant that our Services will meet Your needs, nor does it warrant that the operation of the CGTBrowser software or Services will be continuous, uninterrupted or error-free.",
  "ru": "Веб-сайт и Сервисы CGTBrowser предоставляются на условиях отсутствия гарантий, исходя из имеющихся сервисов и функций, без каких-либо гарантийных обязательств, как явных, так и подразумеваемых. CGTBrowser не гарантирует, что наши Сервисы будут удовлетворять Вашим потребностям, а также не гарантирует, что работа программного обеспечения или Сервисов CGTBrowser будет непрерывной, бесперебойной или безошибочной.",
  "zh": "CGTBrowser 的网站和服务按不提供保证的原则、基于现有的服务和功能提供，不附带任何明示或默示的保证承诺。CGTBrowser 不保证我们的服务将满足您的需求，也不保证 CGTBrowser 的软件或服务的运行将持续、不中断或不出错。"
 },
 "Thay đổi điều khoản sử dụng": {
  "en": "Changes to the terms of use",
  "ru": "Изменение условий использования",
  "zh": "使用条款的变更"
 },
 "CGTBrowser bảo lưu quyền thay đổi và/hoặc điều chỉnh bất cứ nội dung nào trong bản Điều khoản Sử dụng này vào từng thời điểm mà không cần thông báo trước. Các thay đổi và/hoặc điều chỉnh đó phát sinh hiệu lực ngay khi được đăng tải lên website của chúng tôi. Trường hợp Bạn vẫn tiếp tục sử dụng Dịch vụ của CGTBrowser sau khi những thay đổi, điều chỉnh đã được đăng tải, điều đó có nghĩa Bạn đã chấp nhận và đồng thuận với các thay đổi, điều chỉnh ấy.": {
  "en": "CGTBrowser reserves the right to change and/or amend any content of these Terms of Use from time to time without prior notice. Such changes and/or amendments take effect immediately upon being posted on our website. If You continue to use the CGTBrowser Services after such changes or amendments have been posted, this means that You have accepted and agreed to such changes and amendments.",
  "ru": "CGTBrowser оставляет за собой право время от времени изменять и/или корректировать любые положения настоящих Условий использования без предварительного уведомления. Такие изменения и/или корректировки вступают в силу немедленно с момента их размещения на нашем веб-сайте. Если Вы продолжаете пользоваться Сервисами CGTBrowser после размещения таких изменений и корректировок, это означает, что Вы приняли их и согласились с ними.",
  "zh": "CGTBrowser 保留随时变更和/或调整本使用条款中任何内容的权利，无需事先通知。该等变更和/或调整自发布于我们的网站之时起立即生效。若您在该等变更、调整发布后仍继续使用 CGTBrowser 的服务，即表示您已接受并同意该等变更、调整。"
 },
 "Hành vi cấm sử dụng dịch vụ": {
  "en": "Prohibited Conduct in Using the Services",
  "ru": "Запрещённые действия при использовании Сервисов",
  "zh": "使用服务时的禁止行为"
 },
 "Những hành vi sau đây bị xem là lạm dụng CGTBrowser và bị nghiêm cấm:": {
  "en": "The following acts are deemed to be abuse of CGTBrowser and are strictly prohibited:",
  "ru": "Следующие действия считаются злоупотреблением CGTBrowser и строго запрещены:",
  "zh": "以下行为被视为滥用 CGTBrowser，并被严格禁止："
 },
 "Giới thiệu trình duyệt CGTBrowser dưới tên gọi Chrome hoặc bất cứ tên gọi nào khác không liên quan tới tên thật của CGTBrowser;": {
  "en": "Presenting the CGTBrowser browser under the name Chrome or any other name unrelated to the real name of CGTBrowser;",
  "ru": "Представление браузера CGTBrowser под названием Chrome или под любым другим названием, не связанным с настоящим названием CGTBrowser;",
  "zh": "以 Chrome 或任何其他与 CGTBrowser 真实名称无关的名称介绍 CGTBrowser 浏览器；"
 },
 "Chi trả cho bất cứ bên thứ ba nào khác trong một chương trình hợp tác các khoản doanh thu quảng cáo thu được từ những lần nhấp chuột của người sử dụng trình duyệt CGTBrowser, nhưng không cho phép CGTBrowser tham gia chương trình hợp tác đó;": {
  "en": "Paying to any other third party in a partnership program the advertising revenue earned from clicks by users of the CGTBrowser browser, while not allowing CGTBrowser to participate in that partnership program;",
  "ru": "Выплата любой иной третьей стороне в рамках партнёрской программы доходов от рекламы, полученных от кликов пользователей браузера CGTBrowser, без предоставления CGTBrowser возможности участвовать в такой партнёрской программе;",
  "zh": "在合作计划中，将从 CGTBrowser 浏览器用户的点击中获得的广告收入支付给任何其他第三方，但不允许 CGTBrowser 参与该合作计划；"
 },
 "Khóa trình duyệt CGTBrowser hoặc thông báo sai sự thật rằng trình duyệt CGTBrowser không được hỗ trợ;": {
  "en": "Blocking the CGTBrowser browser or falsely stating that the CGTBrowser browser is not supported;",
  "ru": "Блокировка браузера CGTBrowser или ложное уведомление о том, что браузер CGTBrowser не поддерживается;",
  "zh": "屏蔽 CGTBrowser 浏览器，或虚假告知 CGTBrowser 浏览器不受支持；"
 },
 "Ngăn cản việc tải trình duyệt CGTBrowser.": {
  "en": "Preventing the download of the CGTBrowser browser.",
  "ru": "Препятствование загрузке браузера CGTBrowser.",
  "zh": "阻止下载 CGTBrowser 浏览器。"
 },
 "Quy định sử dụng dịch vụ": {
  "en": "Rules for using the services",
  "ru": "Правила использования сервисов",
  "zh": "服务使用规定"
 },
 "Giới hạn trách nhiệm": {
  "en": "Limitation of liability",
  "ru": "Ограничение ответственности",
  "zh": "责任限制"
 },
 "Bạn xác nhận và chấp thuận rằng CGTBrowser chỉ sẵn sàng cung cấp Dịch vụ nếu Bạn đồng thuận giới hạn trách nhiệm của chúng tôi đối với Bạn và các bên thứ ba. Bạn chấp thuận rằng Bạn gánh trách nhiệm bồi thường duy nhất và toàn bộ đối với bất cứ khiếu nại, tố cáo nào gửi tới CGTBrowser liên quan tới bất cứ sự vi phạm quy định sử dụng nào do việc Bạn ngừng sử dụng Dịch vụ của CGTBrowser.": {
  "en": "You confirm and agree that CGTBrowser is willing to provide the Services only if You agree to limit our liability to You and to third parties. You agree that You bear the sole and entire responsibility for indemnification with respect to any claim or complaint submitted to CGTBrowser in connection with any violation of the usage rules arising from Your ceasing to use the CGTBrowser Services.",
  "ru": "Вы подтверждаете и соглашаетесь с тем, что CGTBrowser готов предоставлять Сервисы только при условии Вашего согласия на ограничение нашей ответственности перед Вами и третьими сторонами. Вы соглашаетесь с тем, что Вы несёте единоличную и полную ответственность по возмещению в отношении любых претензий и жалоб, направленных в CGTBrowser в связи с любым нарушением правил использования, вызванным прекращением Вами использования Сервисов CGTBrowser.",
  "zh": "您确认并同意，CGTBrowser 仅在您同意限制我们对您及第三方所承担责任的前提下，才愿意提供服务。您同意，对于因您停止使用 CGTBrowser 的服务而涉及任何违反使用规定行为、向 CGTBrowser 提出的任何投诉、举报，由您承担唯一且全部的赔偿责任。"
 },
 "Bảo mật thông tin người dùng": {
  "en": "Protection of user information",
  "ru": "Защита информации пользователей",
  "zh": "用户信息保密"
 },
 "Để nắm rõ cơ chế bảo mật thông tin người dùng, đề nghị Bạn tham khảo Chính sách bảo mật của CGTBrowser tại website của chúng tôi. Chính sách này trình bày cơ chế thu thập, xử lý và bảo vệ thông tin người dùng. Khi Bạn cài đặt và sử dụng trình duyệt này, Bạn đã chấp thuận tuân theo Chính sách bảo mật của CGTBrowser.": {
  "en": "To fully understand the mechanism for securing user information, You are requested to consult the CGTBrowser Privacy Policy on our website. This Policy sets out the mechanism for collecting, processing and protecting user information. By installing and using this browser, You agree to comply with the CGTBrowser Privacy Policy.",
  "ru": "Чтобы чётко понимать механизм защиты информации пользователей, просим Вас ознакомиться с Политикой конфиденциальности CGTBrowser на нашем веб-сайте. Настоящая Политика описывает механизм сбора, обработки и защиты информации пользователей. Устанавливая и используя данный браузер, Вы соглашаетесь соблюдать Политику конфиденциальности CGTBrowser.",
  "zh": "为清楚了解用户信息安全机制，请您参阅我们网站上的CGTBrowser隐私政策。本政策阐述了用户信息的收集、处理和保护机制。当您安装并使用本浏览器时，即表示您已同意遵守CGTBrowser隐私政策。"
 },
 "Bảo vệ bản quyền và quyền sở hữu trí tuệ khác": {
  "en": "Protection of Copyright and Other Intellectual Property Rights",
  "ru": "Защита авторских прав и иных прав интеллектуальной собственности",
  "zh": "版权及其他知识产权保护"
 },
 "Dịch vụ của CGTBrowser cùng toàn bộ phần mềm cần thiết, yếu tố cấu thành Dịch vụ, bao gồm cả quyền sở hữu trí tuệ đối với Dịch vụ của CGTBrowser (“Sở hữu Trí tuệ”), được bảo hộ bởi bản quyền, quyền về thương hiệu, nhãn dịch vụ hoặc quyền tài sản khác mà CGTBrowser sở hữu, hoặc thuộc sở hữu của bên thứ ba đã cấp quyền sở hữu trí tuệ cho CGTBrowser. Bạn không có quyền sử dụng bất cứ tên thương mại, nhãn hiệu hàng hóa và dịch vụ, biểu tượng, tên miền cùng các hình thức nhận diện đặc trưng nào khác của CGTBrowser vào mục đích thương mại, trừ khi Bạn nhận được sự chấp thuận bằng văn bản của CGTBrowser.": {
  "en": "The CGTBrowser Services together with all necessary software and components of the Services, including the intellectual property rights in the CGTBrowser Services (“Intellectual Property”), are protected by copyright, trademark rights, service marks or other proprietary rights owned by CGTBrowser or owned by a third party that has licensed the intellectual property rights to CGTBrowser. You have no right to use any trade names, trademarks and service marks, logos, domain names or other distinctive identifiers of CGTBrowser for commercial purposes, unless You have obtained the written consent of CGTBrowser.",
  "ru": "Сервисы CGTBrowser вместе со всем необходимым программным обеспечением и составными элементами Сервисов, включая права интеллектуальной собственности на Сервисы CGTBrowser («Интеллектуальная собственность»), охраняются авторским правом, правами на товарные знаки, знаки обслуживания или иными имущественными правами, принадлежащими CGTBrowser либо третьей стороне, предоставившей CGTBrowser права интеллектуальной собственности. Вы не вправе использовать какие-либо фирменные наименования, товарные знаки и знаки обслуживания, логотипы, доменные имена и иные отличительные средства индивидуализации CGTBrowser в коммерческих целях, если только Вы не получили письменного согласия CGTBrowser.",
  "zh": "CGTBrowser 的服务及构成服务的全部必要软件和要素，包括对 CGTBrowser 的服务所享有的知识产权（“知识产权”），受 CGTBrowser 所拥有的、或已向 CGTBrowser 授予知识产权的第三方所拥有的著作权、商标权、服务标记或其他财产权保护。除非您已获得 CGTBrowser 的书面同意，否则您无权将 CGTBrowser 的任何商号、商品和服务商标、标志、域名及其他具有识别性的标识用于商业目的。"
 },
 "6.2. Dịch vụ đồng bộ đám mây CGTBrowser": {
  "en": "6.2. CGTBrowser Cloud Sync Service",
  "ru": "6.2. Сервис облачной синхронизации CGTBrowser",
  "zh": "6.2. CGTBrowser 云同步服务"
 },
 "Điều khoản dịch vụ.": {
  "en": "Terms of Service.",
  "ru": "Условия предоставления услуг.",
  "zh": "服务条款。"
 },
 "6.3. Dịch vụ không gian làm việc nhóm CGTBrowser": {
  "en": "6.3. CGTBrowser Team Workspace Service",
  "ru": "6.3. Сервис командного рабочего пространства CGTBrowser",
  "zh": "6.3. CGTBrowser 团队工作空间服务"
 },
 "6.4. Chương trình giới thiệu CGTBrowser": {
  "en": "6.4. CGTBrowser Referral Program",
  "ru": "6.4. Реферальная программа CGTBrowser",
  "zh": "6.4. CGTBrowser 推荐计划"
 },
 "Điều khoản tham gia.": {
  "en": "Terms of Participation.",
  "ru": "Условия участия.",
  "zh": "参与条款。"
 },
 "Chúng tôi thường ra mắt các dịch vụ mới và đôi khi cập nhật những điều khoản, chính sách của mình. Chúng tôi cố gắng hết sức để giữ cho trang này luôn được cập nhật và làm mới nó thường xuyên.": {
  "en": "We frequently launch new services and occasionally update our terms and policies. We make every effort to keep this page up to date and refresh it regularly.",
  "ru": "Мы регулярно запускаем новые сервисы и время от времени обновляем свои условия и политики. Мы прилагаем все усилия к тому, чтобы эта страница оставалась актуальной, и регулярно её обновляем.",
  "zh": "我们经常推出新服务，并不时更新我们的条款和政策。我们会尽最大努力使本页面保持最新，并定期对其进行更新。"
 },
 "7. Thanh toán và hoàn tiền": {
  "en": "7. Payment and Refunds",
  "ru": "7. Оплата и возврат средств",
  "zh": "7. 付款与退款"
 },
 "7.1. Cơ chế thanh toán. CGTBrowser hoạt động theo hình thức trả trước qua Ví. Bạn nạp tiền vào Ví của tài khoản bằng cách chuyển khoản tới tài khoản ngân hàng do CGTBrowser công bố, kèm đúng mã định danh nạp tiền hiển thị trong ứng dụng ở phần nội dung chuyển khoản. Hệ thống tự động đối soát biến động số dư ngân hàng và cộng tiền vào Ví theo mã định danh đó. Số dư trong Ví được dùng để mua, gia hạn, nâng cấp gói dịch vụ và mua các kịch bản trả phí trên Chợ kịch bản.": {
  "en": "7.1. Payment mechanism. CGTBrowser operates on a prepaid basis via the Wallet. You top up Your account's Wallet by bank transfer to the bank account published by CGTBrowser, stating in the transfer description the exact top-up identifier displayed in the application. The system automatically reconciles bank balance movements and credits funds to the Wallet according to that identifier. The Wallet balance is used to purchase, renew and upgrade service plans and to purchase paid scripts on the Script Marketplace.",
  "ru": "7.1. Порядок оплаты. CGTBrowser работает по системе предоплаты через Кошелёк. Вы пополняете Кошелёк своего аккаунта банковским переводом на банковский счёт, опубликованный CGTBrowser, указывая в назначении платежа точный идентификатор пополнения, отображаемый в приложении. Система автоматически сверяет движение средств по банковскому счёту и зачисляет средства в Кошелёк в соответствии с этим идентификатором. Остаток Кошелька используется для покупки, продления и повышения тарифных планов, а также для покупки платных сценариев на Маркетплейсе сценариев.",
  "zh": "7.1. 付款机制。CGTBrowser采用通过钱包预付的方式。您通过向CGTBrowser公布的银行账户转账为账户钱包充值，并须在转账附言中准确填写应用内显示的充值识别码。系统自动核对银行余额变动，并根据该识别码将款项计入钱包。钱包余额用于购买、续订、升级服务套餐，以及在脚本市场购买付费脚本。"
 },
 "7.2. Nghĩa vụ ghi đúng nội dung chuyển khoản. Bạn chịu trách nhiệm ghi đúng và đầy đủ mã định danh nạp tiền của mình. Trường hợp nội dung chuyển khoản thiếu, sai mã định danh hoặc chuyển tới tài khoản ngân hàng không phải tài khoản do CGTBrowser công bố, hệ thống không thể xác định giao dịch thuộc về ai và tiền sẽ không tự động vào Ví. Khi đó Bạn cần liên hệ bộ phận hỗ trợ kèm chứng từ chuyển khoản để chúng tôi tra soát; CGTBrowser sẽ nỗ lực hợp lý để đối chiếu và cộng bù vào Ví của Bạn, nhưng không cam kết thời hạn xử lý và không chịu trách nhiệm với những giao dịch không thể tra soát được.": {
  "en": "7.2. Obligation to state the transfer description correctly. You are responsible for stating Your top-up identifier correctly and in full. Where the transfer description is incomplete or contains an incorrect identifier, or the transfer is made to a bank account other than the one published by CGTBrowser, the system cannot determine to whom the transaction belongs and the funds will not be automatically credited to the Wallet. In that case, You must contact the support team and provide the transfer receipt so that we can investigate; CGTBrowser will make reasonable efforts to reconcile and credit the amount to Your Wallet, but does not commit to any processing time and is not liable for transactions that cannot be traced.",
  "ru": "7.2. Обязанность правильно указывать назначение платежа. Вы несёте ответственность за правильное и полное указание своего идентификатора пополнения. Если назначение платежа неполное или содержит неверный идентификатор либо перевод направлен на банковский счёт, не опубликованный CGTBrowser, система не может определить, кому принадлежит транзакция, и средства не будут автоматически зачислены в Кошелёк. В этом случае Вам необходимо обратиться в службу поддержки, приложив подтверждение перевода, чтобы мы провели проверку; CGTBrowser приложит разумные усилия для сверки и зачисления средств в Ваш Кошелёк, однако не гарантирует сроки обработки и не несёт ответственности за транзакции, которые невозможно отследить.",
  "zh": "7.2. 正确填写转账附言的义务。您有责任正确、完整地填写您的充值识别码。如转账附言不完整、识别码错误，或转入的银行账户并非CGTBrowser公布的账户，系统将无法确定该交易的归属，款项也不会自动计入钱包。此时，您需携转账凭证联系客服部门，以便我们进行核查；CGTBrowser将尽合理努力进行核对并补记至您的钱包，但不承诺处理时限，且对无法核查的交易不承担责任。"
 },
 "7.3. Giá dịch vụ. Giá áp dụng cho mỗi giao dịch là giá được hệ thống tính và hiển thị tại thời điểm Bạn xác nhận giao dịch. CGTBrowser bảo lưu quyền điều chỉnh bảng giá, cấu hình gói, chính sách chiết khấu và các chương trình khuyến mãi vào từng thời điểm mà không cần thông báo trước; việc điều chỉnh không làm thay đổi các giao dịch đã hoàn tất trước đó.": {
  "en": "7.3. Service prices. The price applicable to each transaction is the price calculated and displayed by the system at the time You confirm the transaction. CGTBrowser reserves the right to adjust the price list, plan configurations, discount policies and promotional programs from time to time without prior notice; such adjustments do not alter transactions completed before them.",
  "ru": "7.3. Стоимость услуг. К каждой транзакции применяется цена, рассчитанная и отображённая системой в момент подтверждения Вами транзакции. CGTBrowser оставляет за собой право время от времени изменять прейскурант, конфигурацию планов, политику скидок и акционные программы без предварительного уведомления; такие изменения не затрагивают ранее завершённые транзакции.",
  "zh": "7.3. 服务价格。每笔交易适用的价格为您确认交易时系统计算并显示的价格。CGTBrowser保留随时调整价目表、套餐配置、折扣政策及促销活动的权利，且无需事先通知；相关调整不改变此前已完成的交易。"
 },
 "7.4. CHÍNH SÁCH KHÔNG HOÀN TIỀN. CGTBrowser áp dụng chính sách KHÔNG HOÀN TIỀN. Cụ thể:": {
  "en": "7.4. NO REFUNDS POLICY. CGTBrowser applies a NO REFUNDS policy. Specifically:",
  "ru": "7.4. ПОЛИТИКА БЕЗ ВОЗВРАТА СРЕДСТВ. CGTBrowser применяет политику БЕЗ ВОЗВРАТА СРЕДСТВ. В частности:",
  "zh": "7.4. 不予退款政策。CGTBrowser实行不予退款政策。具体如下："
 },
 "Số dư đã nạp vào Ví không được hoàn lại, không rút ra tiền mặt, không quy đổi ngược thành tiền và không chuyển sang tài khoản khác. Số dư đó chỉ dùng để thanh toán các sản phẩm, dịch vụ của CGTBrowser;": {
  "en": "Balances topped up into the Wallet are non-refundable, cannot be withdrawn as cash, cannot be converted back into money and cannot be transferred to another account. Such balances may only be used to pay for CGTBrowser products and services;",
  "ru": "Средства, внесённые в Кошелёк, не подлежат возврату, выводу наличными, обратной конвертации в деньги и переводу на другой аккаунт. Эти средства могут использоваться только для оплаты продуктов и услуг CGTBrowser;",
  "zh": "已充值至钱包的余额不予退还，不得提取现金，不得反向兑换为货币，也不得转移至其他账户。该余额仅可用于支付CGTBrowser的产品和服务；"
 },
 "Số dư đã trừ khỏi Ví để mua, gia hạn, nâng cấp gói dịch vụ hoặc mua kịch bản trả phí là khoản thanh toán cuối cùng và không được hoàn lại trong mọi trường hợp, bao gồm nhưng không giới hạn ở: Bạn ngừng sử dụng hoặc không sử dụng hết thời hạn, hạn mức hồ sơ hay số ghế thành viên đã mua (cách tính hạn mức hồ sơ theo sức chứa được nêu tại Điều 7.8); Bạn thay đổi ý định sau khi đã xác nhận giao dịch; Bạn mua sai gói, sai cấu hình, sai kịch bản hoặc mua trùng lặp; Bạn tự xóa tài khoản, hồ sơ hoặc dữ liệu; hoặc tài khoản của Bạn bị tạm ngừng, chấm dứt theo Điều 4, Điều 5 và Điều 11.2 của bản Điều khoản Sử dụng này;": {
  "en": "Balances deducted from the Wallet to purchase, renew or upgrade a service plan or to purchase a paid script constitute final payment and are non-refundable under any circumstances, including but not limited to where: You stop using, or do not use up, the term, profile quota or number of member seats purchased (the capacity-based calculation of the profile quota is set out in Article 7.8); You change Your mind after confirming the transaction; You purchase the wrong plan, configuration or script, or make a duplicate purchase; You delete Your account, profiles or data yourself; or Your account is suspended or terminated pursuant to Article 4, Article 5 and Article 11.2 of these Terms of Use;",
  "ru": "Средства, списанные с Кошелька для покупки, продления или повышения тарифного плана либо для покупки платного сценария, являются окончательным платежом и не подлежат возврату ни при каких обстоятельствах, включая, помимо прочего, случаи, когда: Вы прекращаете использование или не используете полностью приобретённый срок, лимит профилей или количество мест участников (порядок расчёта лимита профилей по вместимости изложен в статье 7.8); Вы передумали после подтверждения транзакции; Вы приобрели не тот план, не ту конфигурацию, не тот сценарий или совершили повторную покупку; Вы самостоятельно удалили аккаунт, профили или данные; либо Ваш аккаунт приостановлен или прекращён в соответствии со статьёй 4, статьёй 5 и статьёй 11.2 настоящих Условий использования;",
  "zh": "为购买、续订、升级服务套餐或购买付费脚本而从钱包扣除的余额属于最终付款，在任何情况下均不予退还，包括但不限于：您停止使用或未用完所购买的期限、配置文件额度或成员席位数（按容量计算配置文件额度的方式见第7.8条）；您在确认交易后改变主意；您购错套餐、配置、脚本或重复购买；您自行删除账户、配置文件或数据；或您的账户依据本使用条款第4条、第5条及第11.2条被暂停或终止；"
 },
 "Nâng cấp gói giữa kỳ không phát sinh hoàn tiền. Khi Bạn nâng cấp trong lúc gói hiện tại còn hiệu lực, số ngày còn lại được cộng vào thời hạn mới và được tính lại theo cấu hình mới mà Bạn chọn. Phần tiền Bạn đã trả cho gói cũ không được hoàn lại dưới bất cứ hình thức nào;": {
  "en": "Upgrading a plan mid-term does not give rise to a refund. When You upgrade while Your current plan is still in effect, the remaining days are added to the new term and recalculated according to the new configuration You choose. The amount You paid for the old plan is not refunded in any form;",
  "ru": "Повышение тарифного плана в середине периода не влечёт возврата средств. При повышении плана в период действия текущего плана оставшиеся дни добавляются к новому сроку и пересчитываются в соответствии с выбранной Вами новой конфигурацией. Сумма, уплаченная Вами за прежний план, не возвращается ни в какой форме;",
  "zh": "期中升级套餐不产生退款。当您在当前套餐仍有效期间升级时，剩余天数将计入新的期限，并按您所选择的新配置重新计算。您为原套餐支付的款项不以任何形式退还；"
 },
 "Tiền khuyến mãi không phải là tiền Bạn nạp. Khoản cộng thêm từ các chương trình khuyến mãi nạp tiền là ưu đãi do CGTBrowser tặng, không được hoàn lại, không rút ra và không quy đổi thành tiền. Việc một chương trình khuyến mãi kết thúc hoặc bị hủy không ảnh hưởng tới khoản ưu đãi đã được cộng vào Ví trước đó;": {
  "en": "Promotional credit is not money You topped up. Amounts added under top-up promotional programs are incentives granted by CGTBrowser and are non-refundable, non-withdrawable and non-convertible into money. The ending or cancellation of a promotional program does not affect incentives already credited to the Wallet before then;",
  "ru": "Бонусные средства не являются средствами, внесёнными Вами. Суммы, начисленные в рамках акций на пополнение, являются бонусами, предоставляемыми CGTBrowser, и не подлежат возврату, выводу и конвертации в деньги. Завершение или отмена акции не влияет на бонусы, ранее зачисленные в Кошелёк;",
  "zh": "优惠金不属于您充值的款项。通过充值促销活动额外获得的金额是CGTBrowser赠送的优惠，不予退还、不得提取，也不得兑换为货币。促销活动结束或被取消，不影响此前已计入钱包的优惠；"
 },
 "Kịch bản trên Chợ kịch bản là sản phẩm số được cung cấp và sử dụng ngay sau khi thanh toán, do đó không được hoàn tiền, kể cả khi kịch bản sau đó bị tác giả gỡ bỏ hoặc bị CGTBrowser đưa khỏi Chợ.": {
  "en": "Scripts on the Script Marketplace are digital products delivered and usable immediately upon payment and are therefore non-refundable, even if the script is subsequently removed by its author or taken off the Marketplace by CGTBrowser.",
  "ru": "Сценарии на Маркетплейсе сценариев являются цифровыми продуктами, которые предоставляются и становятся доступными для использования сразу после оплаты, поэтому возврат средств за них не производится, даже если впоследствии сценарий будет удалён автором или снят CGTBrowser с Маркетплейса.",
  "zh": "脚本市场上的脚本属于付款后即时提供和使用的数字产品，因此不予退款，即使该脚本此后被作者下架或被CGTBrowser移出市场。"
 },
 "7.5. Điều chỉnh do sai sót hệ thống. Chính sách không hoàn tiền tại Điều 7.4 không loại trừ trường hợp lỗi kỹ thuật hoặc lỗi đối soát do phía CGTBrowser gây ra dẫn tới việc Ví của Bạn bị trừ hoặc cộng không đúng. Trong các trường hợp đó, CGTBrowser thực hiện điều chỉnh số dư Ví cho đúng, kèm ghi nhận vào sổ giao dịch của tài khoản. Đây là biện pháp điều chỉnh nội bộ trong Ví, không phải hoàn tiền ra ngoài hệ thống.": {
  "en": "7.5. Adjustments due to system errors. The no refunds policy in Article 7.4 does not exclude cases where a technical error or reconciliation error caused by CGTBrowser results in Your Wallet being debited or credited incorrectly. In such cases, CGTBrowser will make a Wallet balance adjustment to correct it, recorded in the account's transaction ledger. This is an internal adjustment within the Wallet, not a refund outside the system.",
  "ru": "7.5. Корректировка вследствие системных ошибок. Политика отказа от возврата средств, установленная статьёй 7.4, не исключает случаев, когда техническая ошибка или ошибка сверки по вине CGTBrowser привела к неверному списанию или зачислению средств в Вашем Кошельке. В таких случаях CGTBrowser производит корректировку остатка Кошелька с отражением в журнале транзакций аккаунта. Это внутренняя корректировка в пределах Кошелька, а не возврат средств за пределы системы.",
  "zh": "7.5. 因系统差错进行的调整。第7.4条的不予退款政策不排除因CGTBrowser方面造成的技术错误或对账错误导致您的钱包被错误扣款或入账的情形。在此类情形下，CGTBrowser将进行钱包余额调整予以更正，并记录于账户的交易记录中。这是钱包内部的调整措施，并非向系统外退款。"
 },
 "7.6. Sổ giao dịch. Mọi lần cộng, trừ số dư Ví đều được ghi nhận vào sổ giao dịch của tài khoản và Bạn có thể tự tra cứu trong ứng dụng. Sổ giao dịch là căn cứ để đối chiếu khi phát sinh khiếu nại về thanh toán. Bạn có nghĩa vụ kiểm tra sổ giao dịch và thông báo cho CGTBrowser trong thời gian hợp lý nếu phát hiện sai lệch.": {
  "en": "7.6. Transaction ledger. Every credit to and debit from the Wallet balance is recorded in the account's transaction ledger, which You can look up yourself in the application. The transaction ledger serves as the basis for reconciliation when payment complaints arise. You are obliged to review the transaction ledger and notify CGTBrowser within a reasonable time if You discover any discrepancy.",
  "ru": "7.6. Журнал транзакций. Каждое зачисление и списание средств Кошелька отражается в журнале транзакций аккаунта, который Вы можете самостоятельно просматривать в приложении. Журнал транзакций служит основанием для сверки при возникновении претензий по оплате. Вы обязаны проверять журнал транзакций и в разумный срок уведомлять CGTBrowser при обнаружении расхождений.",
  "zh": "7.6. 交易记录。钱包余额的每一次增减均记录在账户的交易记录中，您可在应用内自行查询。交易记录是发生付款投诉时进行核对的依据。您有义务检查交易记录，如发现差异，应在合理期限内通知CGTBrowser。"
 },
 "7.7. Bảo mật tài khoản và giao dịch. Bạn chịu trách nhiệm bảo mật thông tin đăng nhập của mình. Mọi giao dịch được thực hiện từ tài khoản của Bạn được xem là do Bạn thực hiện. CGTBrowser không hoàn lại số dư đã bị sử dụng bởi bất cứ ai truy cập được vào tài khoản của Bạn, trừ trường hợp lỗi thuộc về hệ thống của chúng tôi theo Điều 7.5.": {
  "en": "7.7. Account and transaction security. You are responsible for keeping Your login credentials secure. All transactions performed from Your account are deemed to have been performed by You. CGTBrowser does not refund balances used by anyone who gains access to Your account, except where the fault lies with our system as provided in Article 7.5.",
  "ru": "7.7. Безопасность аккаунта и транзакций. Вы несёте ответственность за сохранность своих данных для входа. Все транзакции, совершённые с Вашего аккаунта, считаются совершёнными Вами. CGTBrowser не возвращает средства, использованные любым лицом, получившим доступ к Вашему аккаунту, за исключением случаев, когда ошибка возникла по вине нашей системы согласно статье 7.5.",
  "zh": "7.7. 账户与交易安全。您有责任对您的登录信息保密。从您的账户进行的所有交易均视为由您本人进行。对于任何能够访问您账户的人所使用的余额，CGTBrowser不予退还，但依据第7.5条属于我们系统过错的情形除外。"
 },
 "7.8. Hạn mức hồ sơ tính theo sức chứa. Hạn mức hồ sơ của gói dịch vụ là số hồ sơ được phép tồn tại đồng thời trên tài khoản của Bạn, không phải số lần Bạn được tạo hồ sơ. Khi Bạn xóa vĩnh viễn một hồ sơ, chỗ của hồ sơ đó được trả lại ngay và Bạn được tạo hồ sơ mới thay thế mà không phải trả thêm tiền. Hồ sơ nằm trong Thùng rác vẫn chiếm chỗ cho tới khi bị xóa vĩnh viễn, vì dữ liệu của hồ sơ đó còn nguyên và Bạn có thể khôi phục bất cứ lúc nào. Cùng nguyên tắc này áp dụng cho “Giới hạn số dư hồ sơ” mà chủ tài khoản đặt cho từng thành viên trong nhóm: hồ sơ do thành viên tạo chiếm một chỗ trong giới hạn của chính thành viên đó và được hoàn lại khi hồ sơ bị xóa vĩnh viễn. Bạn lưu ý xóa vĩnh viễn là hành vi không thể hủy: toàn bộ cookie, phiên đăng nhập, dấu vân tay và dữ liệu duyệt web bên trong hồ sơ bị xóa cùng lúc, CGTBrowser không giữ bản sao và không có nghĩa vụ phục hồi. Riêng ghế thành viên không theo cơ chế này: một địa chỉ email đã nhận lời mời và vào không gian làm việc của Bạn được tính là đã tiêu một ghế, việc gỡ thành viên đó về sau không trả lại ghế.": {
  "en": "7.8. Capacity-based profile quota. A service plan's profile quota is the number of profiles permitted to exist simultaneously on Your account, not the number of times You may create profiles. When You permanently delete a profile, that profile's slot is returned immediately and You may create a new replacement profile without paying anything extra. Profiles in the Trash still occupy slots until permanently deleted, because the data of such profiles remains intact and You can restore them at any time. The same principle applies to the “Profile balance limit” that the account owner sets for each team member: a profile created by a member occupies one slot within that member's own limit and is returned when the profile is permanently deleted. Please note that permanent deletion is an irreversible action: all cookies, login sessions, fingerprints and browsing data within the profile are deleted at the same time, and CGTBrowser keeps no copy and has no obligation to recover them. Member seats, however, do not follow this mechanism: an email address that has accepted an invitation and joined Your workspace counts as one seat used, and subsequently removing that member does not return the seat.",
  "ru": "7.8. Лимит профилей по вместимости. Лимит профилей тарифного плана означает количество профилей, которые могут одновременно существовать в Вашем аккаунте, а не количество раз, которое Вы можете создавать профили. Когда Вы безвозвратно удаляете профиль, его место сразу освобождается, и Вы можете создать новый профиль взамен без дополнительной оплаты. Профили в Корзине продолжают занимать места до их безвозвратного удаления, поскольку данные таких профилей полностью сохраняются и Вы можете восстановить их в любое время. Тот же принцип применяется к ограничению «Лимит баланса профилей», которое владелец аккаунта устанавливает для каждого участника команды: профиль, созданный участником, занимает одно место в пределах лимита самого этого участника и возвращается при безвозвратном удалении профиля. Обращаем Ваше внимание, что безвозвратное удаление является необратимым действием: все файлы cookie, сеансы входа, отпечатки и данные просмотра внутри профиля удаляются одновременно, CGTBrowser не хранит копий и не обязан их восстанавливать. Исключение составляют места участников, на которые этот механизм не распространяется: адрес электронной почты, принявший приглашение и вошедший в Ваше рабочее пространство, считается израсходовавшим одно место, и последующее удаление этого участника не возвращает место.",
  "zh": "7.8. 按容量计算的配置文件额度。服务套餐的配置文件额度是指您账户上允许同时存在的配置文件数量，而非您可创建配置文件的次数。当您永久删除某个配置文件时，该配置文件所占的名额将立即返还，您可创建新的配置文件予以替代，无需额外付费。位于回收站中的配置文件仍占用名额，直至被永久删除，因为该配置文件的数据仍完整保留，您可随时恢复。同一原则适用于账户所有者为团队中每位成员设置的“配置文件余额上限”：成员创建的配置文件占用该成员自身上限内的一个名额，并在该配置文件被永久删除时返还。请您注意，永久删除是不可撤销的操作：配置文件中的所有Cookie、登录会话、指纹及浏览数据将被同时删除，CGTBrowser不保留副本，也无义务进行恢复。唯独成员席位不适用此机制：已接受邀请并加入您工作空间的电子邮件地址即计为已消耗一个席位，此后移除该成员不会返还该席位。"
 },
 "7.9. Giới hạn số lần tạo và mở hồ sơ theo ngày. Vì chỗ hồ sơ được hoàn lại theo Điều 7.8, CGTBrowser áp dụng thêm giới hạn số lần tạo hồ sơ và số lần mở hồ sơ trong một ngày nhằm chống lạm dụng và bảo vệ hạ tầng dùng chung. Các giới hạn này do CGTBrowser cấu hình, có thể khác nhau theo từng gói dịch vụ và có thể được điều chỉnh vào từng thời điểm mà không cần thông báo trước. Bộ đếm tính theo ngày dương lịch theo giờ Việt Nam (GMT+7) và tự đặt lại vào 00:00 mỗi ngày. Khi Bạn đạt giới hạn, thao tác tạo hoặc mở hồ sơ bị từ chối cho tới lần đặt lại kế tiếp; đây không phải sự cố dịch vụ, không làm giảm hạn mức hồ sơ Bạn đang có và không làm phát sinh quyền hoàn tiền. Số lần đã tạo, đã mở trong ngày cùng giới hạn đang áp dụng được hiển thị trong ứng dụng để Bạn tự theo dõi.": {
  "en": "7.9. Daily limits on creating and opening profiles. Because profile slots are returned under Article 7.8, CGTBrowser additionally applies limits on the number of profile creations and profile openings per day to prevent abuse and protect shared infrastructure. These limits are configured by CGTBrowser, may differ between service plans and may be adjusted from time to time without prior notice. The counters run by calendar day in Vietnam time (GMT+7) and automatically reset at 00:00 each day. When You reach a limit, profile creation or opening operations are refused until the next reset; this is not a service incident, does not reduce Your existing profile quota and does not give rise to any right to a refund. The number of creations and openings made during the day, together with the limits currently applied, is displayed in the application so that You can monitor them yourself.",
  "ru": "7.9. Суточные ограничения на создание и открытие профилей. Поскольку места профилей возвращаются согласно статье 7.8, CGTBrowser дополнительно применяет ограничения на количество созданий и открытий профилей в сутки в целях предотвращения злоупотреблений и защиты общей инфраструктуры. Эти ограничения настраиваются CGTBrowser, могут различаться в зависимости от тарифного плана и могут время от времени изменяться без предварительного уведомления. Счётчики ведутся по календарным суткам по времени Вьетнама (GMT+7) и автоматически обнуляются в 00:00 каждого дня. При достижении ограничения операции создания или открытия профилей отклоняются до следующего обнуления; это не является сбоем в работе сервиса, не уменьшает имеющийся у Вас лимит профилей и не порождает права на возврат средств. Количество созданий и открытий за сутки, а также действующие ограничения отображаются в приложении, чтобы Вы могли самостоятельно их отслеживать.",
  "zh": "7.9. 每日创建和打开配置文件的次数限制。由于配置文件名额依据第7.8条予以返还，CGTBrowser另行实行每日创建配置文件次数及打开配置文件次数的限制，以防止滥用并保护共享基础设施。上述限制由CGTBrowser配置，可能因服务套餐不同而有所差异，并可能随时调整而无需事先通知。计数器按越南时间（GMT+7）的自然日计算，并于每日00:00自动重置。当您达到限制时，创建或打开配置文件的操作将被拒绝，直至下一次重置；这不属于服务故障，不会减少您现有的配置文件额度，也不产生任何退款权利。当日已创建、已打开的次数以及当前适用的限制均显示在应用内，供您自行查看。"
 },
 "8. Giới hạn trách nhiệm": {
  "en": "8. Limitation of Liability",
  "ru": "8. Ограничение ответственности",
  "zh": "8. 责任限制"
 },
 "Bạn chấp thuận bảo vệ, bồi thường và giữ cho CGTBrowser, các công ty liên kết của CGTBrowser cùng mỗi nhân viên, giám đốc, người lao động, đại lý, đại diện, người cung cấp thông tin và bên cấp phép của CGTBrowser không phải chịu tổn hại bởi bất cứ khiếu nại, khiếu kiện, chi phí, tổn thất, thiệt hại, phán quyết của tòa án và phí tổn nào, bao gồm nhưng không giới hạn ở phí luật sư, liên quan tới hoặc phát sinh từ việc vi phạm Điều khoản Sử dụng hoặc bất cứ sự sử dụng nào của Bạn đối với Dịch vụ, hoặc bất cứ người nào khác sử dụng Dịch vụ thông qua Bạn hay sử dụng máy tính của Bạn. CGTBrowser bảo lưu quyền, bằng chi phí của mình, đảm nhận trọn vẹn việc bảo vệ và kiểm soát (nhưng không mang trách nhiệm) đối với bất cứ vấn đề nào phát sinh như vậy, tùy thuộc vào sự bồi thường của Bạn.": {
  "en": "You agree to defend, indemnify and hold harmless CGTBrowser, the affiliates of CGTBrowser and each of the officers, directors, employees, agents, representatives, information providers and licensors of CGTBrowser from and against any claims, lawsuits, costs, losses, damages, court judgments and expenses, including but not limited to attorneys’ fees, relating to or arising from a breach of the Terms of Use or any use by You of the Services, or by any other person using the Services through You or using Your computer. CGTBrowser reserves the right, at its own expense, to assume the exclusive defense and control (but without assuming liability) of any such matter, subject to indemnification by You.",
  "ru": "Вы соглашаетесь защищать CGTBrowser, аффилированные компании CGTBrowser, а также каждого из должностных лиц, директоров, работников, агентов, представителей, поставщиков информации и лицензиаров CGTBrowser, возмещать им ущерб и ограждать их от любых претензий, исков, расходов, убытков, ущерба, судебных решений и издержек, включая, помимо прочего, оплату услуг адвокатов, связанных с нарушением Условий использования или с любым использованием Вами Сервисов либо любым другим лицом, использующим Сервисы через Вас или с Вашего компьютера, или возникающих в связи с этим. CGTBrowser оставляет за собой право за свой счёт взять на себя полную защиту и контроль (но не ответственность) в отношении любого такого вопроса при условии возмещения с Вашей стороны.",
  "zh": "您同意为 CGTBrowser、CGTBrowser 的关联公司以及 CGTBrowser 的每一位管理人员、董事、员工、代理人、代表、信息提供者和许可方进行抗辩、作出赔偿，并使其免受与违反使用条款或您对服务的任何使用、或任何其他人通过您或使用您的计算机使用服务相关或由此产生的任何索赔、诉讼、费用、损失、损害、法院判决及开支（包括但不限于律师费）的损害。CGTBrowser 保留自行承担费用、全面承担任何此类事项的抗辩和控制（但不承担责任）的权利，但须以您作出赔偿为前提。"
 },
 "9. Bảo mật thông tin người dùng": {
  "en": "9. Protection of User Information",
  "ru": "9. Защита информации пользователей",
  "zh": "9. 用户信息保护"
 },
 "CGTBrowser vận hành theo nguyên tắc phân định rạch ròi giữa dữ liệu đồng bộ của Bạn và dữ liệu vận hành của hệ thống:": {
  "en": "CGTBrowser operates on the principle of a clear separation between Your sync data and the system’s operational data:",
  "ru": "CGTBrowser работает по принципу чёткого разграничения между Вашими данными синхронизации и служебными данными системы:",
  "zh": "CGTBrowser 遵循将您的同步数据与系统运营数据明确区分的原则运作："
 },
 "CGTBrowser không lưu trữ, không thu thập và không đọc dữ liệu đồng bộ của Bạn. Cookie, phiên đăng nhập, lịch sử duyệt web cùng toàn bộ dữ liệu phát sinh bên trong từng hồ sơ trình duyệt nằm trên thiết bị của Bạn. Khi Bạn bật đồng bộ, dữ liệu được mã hóa rồi chuyển thẳng tới kho lưu trữ do chính Bạn cấu hình và quản lý - không đi qua, không lưu lại trên hệ thống của chúng tôi.": {
  "en": "CGTBrowser does not store, collect or read Your sync data. Cookies, login sessions, browsing history and all data generated within each browser profile reside on Your device. When You enable sync, the data is encrypted and then transferred directly to the storage that You yourself configure and manage - without passing through or being retained on our systems.",
  "ru": "CGTBrowser не хранит, не собирает и не читает Ваши данные синхронизации. Файлы cookie, сеансы входа, история просмотра и все данные, возникающие внутри каждого профиля браузера, находятся на Вашем устройстве. При включении синхронизации данные шифруются и затем передаются напрямую в хранилище, которое Вы сами настраиваете и которым управляете, - не проходя через наши системы и не сохраняясь в них.",
  "zh": "CGTBrowser不存储、不收集、也不读取您的同步数据。Cookie、登录会话、浏览历史以及每个浏览器配置文件中产生的全部数据均保存在您的设备上。当您启用同步时，数据经加密后直接传输至由您自行配置和管理的存储，不经过我们的系统，也不在我们的系统上留存。"
 },
 "CGTBrowser quản lý dữ liệu vận hành gồm thông tin tài khoản, gói dịch vụ, cấu hình hồ sơ, thành viên trong không gian làm việc, trạng thái khóa hồ sơ và nhật ký thao tác. Đây là phần dữ liệu bắt buộc phải có để xác thực tài khoản, tính phí và vận hành các tính năng nhóm.": {
  "en": "CGTBrowser manages operational data, including account information, service plans, profile configurations, workspace members, profile lock status and activity logs. This is the data that is strictly required to authenticate accounts, charge fees and operate team features.",
  "ru": "CGTBrowser управляет операционными данными, включая информацию об аккаунте, тарифные планы, конфигурацию профилей, участников рабочего пространства, статус блокировки профилей и журналы действий. Это данные, обязательно необходимые для аутентификации аккаунтов, начисления платы и работы командных функций.",
  "zh": "CGTBrowser管理运营数据，包括账户信息、服务套餐、配置文件配置、工作空间成员、配置文件锁定状态及操作日志。这些是验证账户、计费及运行团队功能所必需的数据。"
 },
 "Để nắm rõ cơ chế bảo mật thông tin người dùng, đề nghị Bạn đọc Chính sách bảo mật của CGTBrowser tại website của chúng tôi. Chính sách này cung cấp cho Bạn cơ chế thu thập, xử lý và bảo vệ thông tin người dùng.": {
  "en": "To fully understand the mechanism for securing user information, You are requested to read the CGTBrowser Privacy Policy on our website. This Policy informs You of the mechanism for collecting, processing and protecting user information.",
  "ru": "Чтобы чётко понимать механизм защиты информации пользователей, просим Вас прочитать Политику конфиденциальности CGTBrowser на нашем веб-сайте. Настоящая Политика знакомит Вас с механизмом сбора, обработки и защиты информации пользователей.",
  "zh": "为清楚了解用户信息安全机制，请您阅读我们网站上的CGTBrowser隐私政策。本政策向您说明用户信息的收集、处理和保护机制。"
 },
 "10. Bảo vệ bản quyền và quyền sở hữu trí tuệ khác": {
  "en": "10. Protection of Copyright and Other Intellectual Property Rights",
  "ru": "10. Защита авторских прав и иных прав интеллектуальной собственности",
  "zh": "10. 版权及其他知识产权保护"
 },
 "10.1. Dịch vụ của CGTBrowser cùng toàn bộ phần mềm cần thiết, yếu tố cấu thành Dịch vụ, bao gồm cả quyền sở hữu trí tuệ đối với Dịch vụ của CGTBrowser và toàn bộ phần mềm cần thiết, yếu tố cấu thành Dịch vụ (“Sở hữu Trí tuệ”), được bảo hộ bởi bản quyền, quyền về thương hiệu, nhãn dịch vụ hoặc quyền tài sản khác mà CGTBrowser sở hữu, hoặc thuộc sở hữu của bên thứ ba đã cấp quyền sở hữu trí tuệ cho CGTBrowser. Bạn không có quyền sử dụng bất cứ tên thương mại, nhãn hiệu hàng hóa và dịch vụ, biểu tượng, tên miền cùng các hình thức nhận diện hàng hóa, dịch vụ đặc trưng nào khác của CGTBrowser vào mục đích thương mại, trừ khi Bạn nhận được sự chấp thuận bằng văn bản của CGTBrowser, hoặc việc sử dụng của Bạn không gây ảnh hưởng, cản trở, tác động xấu tới hoạt động bình thường của CGTBrowser.": {
  "en": "10.1. CGTBrowser's Service, together with all software necessary for, and elements constituting, the Service, including the intellectual property rights in CGTBrowser's Service and in all software necessary for, and elements constituting, the Service (“Intellectual Property”), is protected by copyright, trademark rights, service marks or other proprietary rights owned by CGTBrowser or by third parties that have granted intellectual property rights to CGTBrowser. You have no right to use any trade name, trademark and service mark, logo, domain name or other distinctive forms of identification of goods and services of CGTBrowser for commercial purposes, unless You obtain CGTBrowser's written consent, or Your use does not affect, obstruct or adversely impact the normal operations of CGTBrowser.",
  "ru": "10.1. Сервис CGTBrowser вместе со всем необходимым программным обеспечением и элементами, составляющими Сервис, включая права интеллектуальной собственности на Сервис CGTBrowser и на всё необходимое программное обеспечение и элементы, составляющие Сервис («Интеллектуальная собственность»), охраняется авторским правом, правами на товарные знаки, знаки обслуживания или иными имущественными правами, принадлежащими CGTBrowser либо третьим лицам, предоставившим CGTBrowser права интеллектуальной собственности. Вы не вправе использовать какие-либо фирменные наименования, товарные знаки и знаки обслуживания, логотипы, доменные имена и иные отличительные средства индивидуализации товаров и услуг CGTBrowser в коммерческих целях, если только Вы не получили письменного согласия CGTBrowser либо Ваше использование не влияет на нормальную деятельность CGTBrowser, не препятствует ей и не оказывает на неё негативного воздействия.",
  "zh": "10.1. CGTBrowser的服务及所有必要软件、构成服务的要素，包括对CGTBrowser服务及所有必要软件、构成服务的要素所享有的知识产权（“知识产权”），均受CGTBrowser所拥有的，或已向CGTBrowser授予知识产权的第三方所拥有的版权、商标权、服务标志或其他财产权利的保护。除非您获得CGTBrowser的书面同意，或您的使用不会影响、妨碍或不利于CGTBrowser的正常运营，否则您无权将CGTBrowser的任何商号、商品和服务商标、标志、域名及其他特有的商品、服务识别形式用于商业目的。"
 },
 "10.2. Việc biên tập (tức là thu thập, sắp xếp và tập hợp) toàn bộ Sở hữu Trí tuệ của Dịch vụ là tài sản độc quyền của CGTBrowser, được bảo hộ bởi pháp luật Việt Nam và các công ước quốc tế về bản quyền. Sở hữu trí tuệ của Dịch vụ cùng các dịch vụ khác mà CGTBrowser sở hữu, vận hành, kiểm soát hoặc được cấp phép không được sao chụp, sản xuất lại, tái bản, tải lên, đăng tải, truyền tải hay phân phối dưới bất cứ hình thức nào. Việc sử dụng hoặc chỉnh sửa quyền sở hữu trí tuệ của CGTBrowser dưới bất cứ hình thức nào, bao gồm nhưng không giới hạn ở bất cứ website hay môi trường được kết nối máy vi tính nào, mà không có sự chấp thuận trước bằng văn bản là hành vi vi phạm bản quyền cùng các quyền tài sản khác của CGTBrowser và bị nghiêm cấm.": {
  "en": "10.2. The compilation (that is, the collection, arrangement and assembly) of all Intellectual Property of the Service is the exclusive property of CGTBrowser and is protected by the laws of Vietnam and international copyright conventions. The intellectual property of the Service and of other services that CGTBrowser owns, operates, controls or is licensed to use may not be copied, reproduced, republished, uploaded, posted, transmitted or distributed in any form. Any use or modification of CGTBrowser's intellectual property rights in any form, including but not limited to on any website or computer-networked environment, without prior written consent constitutes an infringement of the copyright and other proprietary rights of CGTBrowser and is strictly prohibited.",
  "ru": "10.2. Составление (то есть сбор, упорядочение и объединение) всей Интеллектуальной собственности Сервиса является исключительной собственностью CGTBrowser и охраняется законодательством Вьетнама и международными конвенциями об авторском праве. Интеллектуальная собственность Сервиса, а также иных сервисов, которыми CGTBrowser владеет, которые эксплуатирует, контролирует или на которые имеет лицензию, не может копироваться, воспроизводиться, переиздаваться, загружаться, размещаться, передаваться или распространяться в какой бы то ни было форме. Использование или изменение прав интеллектуальной собственности CGTBrowser в любой форме, включая, помимо прочего, на любом веб-сайте или в любой компьютерной сетевой среде, без предварительного письменного согласия является нарушением авторского права и иных имущественных прав CGTBrowser и строго запрещено.",
  "zh": "10.2. 对服务全部知识产权的汇编（即收集、编排和整合）是CGTBrowser的专有财产，受越南法律及国际版权公约保护。服务以及CGTBrowser拥有、运营、控制或获授权的其他服务的知识产权，不得以任何形式复制、再生产、再版、上传、发布、传输或分发。未经事先书面同意，以任何形式使用或修改CGTBrowser的知识产权，包括但不限于在任何网站或计算机联网环境中使用或修改，均构成对CGTBrowser版权及其他财产权利的侵犯，并被严格禁止。"
 },
 "10.3. Theo Điều khoản này, CGTBrowser tôn trọng và không tước đoạt quyền sở hữu hay các quyền khác của Bạn đối với những Nội dung Bạn gửi, đăng, chuyển giao hoặc hiển thị trên trình duyệt của chúng tôi. Bạn chấp thuận gánh trách nhiệm bảo vệ và thi hành các quyền đó, và CGTBrowser không mang nghĩa vụ thực hiện công việc ấy nhân danh Bạn, trừ khi giữa Bạn và CGTBrowser có thỏa thuận riêng bằng văn bản về vấn đề này.": {
  "en": "10.3. Under this Article, CGTBrowser respects and does not deprive You of ownership or other rights in the Content You submit, post, transfer or display on our browser. You agree to bear responsibility for protecting and enforcing those rights, and CGTBrowser has no obligation to do so on Your behalf, unless You and CGTBrowser have a separate written agreement on this matter.",
  "ru": "10.3. В соответствии с настоящей статьёй CGTBrowser уважает и не лишает Вас права собственности или иных прав на Контент, который Вы отправляете, публикуете, передаёте или отображаете в нашем браузере. Вы соглашаетесь нести ответственность за защиту и осуществление этих прав, и CGTBrowser не обязан делать это от Вашего имени, если только между Вами и CGTBrowser не заключено отдельное письменное соглашение по данному вопросу.",
  "zh": "10.3. 根据本条，CGTBrowser尊重且不剥夺您对您在我们浏览器上提交、发布、转让或显示的内容所享有的所有权或其他权利。您同意承担保护和行使该等权利的责任，CGTBrowser无义务代表您履行此项工作，除非您与CGTBrowser之间就此事项另有书面协议。"
 },
 "10.4. Chúng tôi tôn trọng quyền sở hữu trí tuệ của người khác và yêu cầu Người sử dụng của CGTBrowser cũng làm như vậy. Bạn không được tải lên, gắn vào, đăng tải, truyền đi hoặc bằng cách khác tạo sẵn bất cứ yếu tố cấu thành nào gây ảnh hưởng tới bản quyền, thương hiệu, bí mật thương mại hay quyền tài sản khác của bất cứ tổ chức, cá nhân nào. Chúng tôi có quyền chấm dứt đường truy cập vào Dịch vụ của CGTBrowser hoặc bất cứ dịch vụ nào do CGTBrowser cung cấp đối với người bị nghi ngờ xâm phạm.": {
  "en": "10.4. We respect the intellectual property rights of others and require CGTBrowser Users to do the same. You may not upload, embed, post, transmit or otherwise make available any element that affects the copyright, trademark, trade secret or other proprietary rights of any organization or individual. We have the right to terminate access to CGTBrowser's Service or to any service provided by CGTBrowser for anyone suspected of infringement.",
  "ru": "10.4. Мы уважаем права интеллектуальной собственности других лиц и требуем того же от Пользователей CGTBrowser. Вы не вправе загружать, встраивать, размещать, передавать или иным образом делать доступными какие-либо элементы, затрагивающие авторские права, товарные знаки, коммерческую тайну или иные имущественные права любых организаций или физических лиц. Мы вправе прекратить доступ к Сервису CGTBrowser или к любому сервису, предоставляемому CGTBrowser, для лиц, подозреваемых в нарушении.",
  "zh": "10.4. 我们尊重他人的知识产权，并要求CGTBrowser的用户同样如此。您不得上传、嵌入、发布、传输或以其他方式提供任何影响任何组织或个人的版权、商标、商业秘密或其他财产权利的要素。对于涉嫌侵权的人，我们有权终止其对CGTBrowser服务或CGTBrowser提供的任何服务的访问。"
 },
 "11. Điều khoản khác": {
  "en": "11. Miscellaneous",
  "ru": "11. Прочие положения",
  "zh": "11. 其他条款"
 },
 "11.1. Luật điều chỉnh": {
  "en": "11.1. Governing Law",
  "ru": "11.1. Применимое право",
  "zh": "11.1. 适用法律"
 },
 "Bản Điều khoản Sử dụng này được điều chỉnh bởi và giải thích phù hợp với pháp luật Việt Nam. Nếu bất cứ điều khoản nào trong bản Điều khoản Sử dụng này không hợp pháp, vô hiệu hoặc vì bất cứ lý do nào không thể thực hiện được, thì điều khoản đó sẽ được xem là tách rời khỏi bản Điều khoản Sử dụng này và không ảnh hưởng tới hiệu lực cùng tính thực thi của những điều khoản còn lại.": {
  "en": "These Terms of Use are governed by and construed in accordance with the laws of Vietnam. If any provision of these Terms of Use is unlawful, void or for any reason unenforceable, that provision shall be deemed severable from these Terms of Use and shall not affect the validity and enforceability of the remaining provisions.",
  "ru": "Настоящие Условия использования регулируются законодательством Вьетнама и толкуются в соответствии с ним. Если какое-либо положение настоящих Условий использования является незаконным, недействительным или по какой-либо причине не может быть исполнено, такое положение считается отделимым от настоящих Условий использования и не влияет на действительность и исполнимость остальных положений.",
  "zh": "本使用条款受越南法律管辖并依其解释。如本使用条款的任何条款不合法、无效或因任何原因无法履行，则该条款应视为与本使用条款相分离，且不影响其余条款的效力及可执行性。"
 },
 "11.2. Chấm dứt": {
  "en": "11.2. Termination",
  "ru": "11.2. Прекращение действия",
  "zh": "11.2. 终止"
 },
 "Bản Điều khoản Sử dụng này có hiệu lực cho tới khi bị chấm dứt bởi Bạn hoặc bởi CGTBrowser theo các trường hợp sau đây:": {
  "en": "These Terms of Use remain in effect until terminated by You or by CGTBrowser in the following cases:",
  "ru": "Настоящие Условия использования действуют до их прекращения Вами или CGTBrowser в следующих случаях:",
  "zh": "本使用条款在被您或 CGTBrowser 按以下情形终止之前持续有效："
 },
 "Chấm dứt bởi Bạn: Bạn có thể chấm dứt bản Điều khoản Sử dụng này bằng cách không sử dụng Dịch vụ của CGTBrowser nữa.": {
  "en": "Termination by You: You may terminate these Terms of Use by ceasing to use the CGTBrowser Services.",
  "ru": "Прекращение Вами: Вы можете прекратить действие настоящих Условий использования, перестав пользоваться Сервисами CGTBrowser.",
  "zh": "由您终止：您可以通过不再使用 CGTBrowser 的服务来终止本使用条款。"
 },
 "Chấm dứt bởi CGTBrowser: Bản Điều khoản Sử dụng này chấm dứt ngay lập tức mà CGTBrowser không cần thông báo trước nếu (i) theo quyết định của CGTBrowser, Bạn không tuân thủ bất cứ điều khoản nào của bản Điều khoản Sử dụng này, hoặc (ii) Pháp luật hoặc quyết định của chính phủ, tòa án, cơ quan thi hành án yêu cầu CGTBrowser chấm dứt Điều khoản Sử dụng.": {
  "en": "Termination by CGTBrowser: These Terms of Use terminate immediately, without the need for prior notice from CGTBrowser, if (i) as determined by CGTBrowser, You fail to comply with any provision of these Terms of Use, or (ii) the law or a decision of the government, a court or an enforcement authority requires CGTBrowser to terminate the Terms of Use.",
  "ru": "Прекращение со стороны CGTBrowser: Настоящие Условия использования прекращают действие немедленно без необходимости предварительного уведомления со стороны CGTBrowser, если (i) по решению CGTBrowser Вы не соблюдаете какое-либо положение настоящих Условий использования либо (ii) законодательство или решение правительства, суда, органа исполнения судебных решений требует от CGTBrowser прекратить действие Условий использования.",
  "zh": "由 CGTBrowser 终止：如果（i）根据 CGTBrowser 的决定，您未遵守本使用条款的任何条款，或（ii）法律或政府、法院、执行机关的决定要求 CGTBrowser 终止使用条款，则本使用条款立即终止，CGTBrowser 无需事先通知。"
 },
 "Khi chấm dứt bản Điều khoản Sử dụng này, Bạn phải hủy bỏ toàn bộ thông tin, tư liệu nhận được từ CGTBrowser và các website của CGTBrowser, cũng như toàn bộ bản sao của những thông tin, tư liệu đó.": {
  "en": "Upon termination of these Terms of Use, You must destroy all information and materials received from CGTBrowser and the websites of CGTBrowser, as well as all copies of such information and materials.",
  "ru": "При прекращении действия настоящих Условий использования Вы обязаны уничтожить всю информацию и материалы, полученные от CGTBrowser и с веб-сайтов CGTBrowser, а также все копии такой информации и материалов.",
  "zh": "本使用条款终止时，您必须销毁从 CGTBrowser 及 CGTBrowser 网站获得的全部信息、资料，以及该等信息、资料的全部副本。"
 },
 "11.3. Liên hệ": {
  "en": "11.3. Contact",
  "ru": "11.3. Контактная информация",
  "zh": "11.3. 联系方式"
 },
 "Nếu Bạn có bất cứ câu hỏi nào về bản Điều khoản Sử dụng này, hoặc về sự kết nối của Bạn với CGTBrowser, đề nghị liên hệ với chúng tôi. Toàn bộ vấn đề hoặc mâu thuẫn sẽ được giải quyết nhanh chóng và hợp lý.": {
  "en": "If You have any questions about these Terms of Use, or about Your connection with CGTBrowser, please contact us. All issues or disputes will be resolved promptly and reasonably.",
  "ru": "Если у Вас возникнут какие-либо вопросы относительно настоящих Условий использования или Вашего взаимодействия с CGTBrowser, просим связаться с нами. Все вопросы или разногласия будут урегулированы оперативно и обоснованно.",
  "zh": "如您对本使用条款或您与CGTBrowser之间的联系有任何疑问，请联系我们。所有问题或争议都将得到迅速、合理的解决。"
 },
 "Chính sách bảo mật CGTBrowser": {
  "en": "CGTBrowser Privacy Policy",
  "ru": "Политика конфиденциальности CGTBrowser",
  "zh": "CGTBrowser 隐私政策"
 },
 "Chính sách này mô tả cách CGTBrowser thu thập, sử dụng và bảo vệ thông tin khi bạn sử dụng phần mềm và các dịch vụ liên quan. Bằng việc cài đặt và sử dụng CGTBrowser, bạn đồng ý với các nội dung dưới đây.": {
  "en": "This Policy describes how CGTBrowser collects, uses and protects information when you use the software and related services. By installing and using CGTBrowser, you agree to the provisions set out below.",
  "ru": "Настоящая Политика описывает, каким образом CGTBrowser собирает, использует и защищает информацию при использовании вами программного обеспечения и связанных с ним сервисов. Устанавливая и используя CGTBrowser, вы соглашаетесь с изложенными ниже положениями.",
  "zh": "本政策说明 CGTBrowser 在您使用软件及相关服务时如何收集、使用和保护信息。安装并使用 CGTBrowser，即表示您同意以下内容。"
 },
 "1. Nguyên tắc nền tảng": {
  "en": "1. Fundamental Principles",
  "ru": "1. Основные принципы",
  "zh": "1. 基本原则"
 },
 "CGTBrowser vận hành theo nguyên tắc phân định rạch ròi giữa dữ liệu đồng bộ của bạn và dữ liệu vận hành của hệ thống.": {
  "en": "CGTBrowser operates on the principle of a clear distinction between Your synced data and the system’s operational data.",
  "ru": "CGTBrowser работает по принципу чёткого разграничения Ваших синхронизируемых данных и эксплуатационных данных системы.",
  "zh": "CGTBrowser遵循严格区分您的同步数据与系统运营数据的原则运行。"
 },
 "1.1. Dữ liệu đồng bộ - chúng tôi không lưu, không đọc": {
  "en": "1.1. Synced data - we do not store it and do not read it",
  "ru": "1.1. Синхронизируемые данные - мы их не храним и не читаем",
  "zh": "1.1. 同步数据 - 我们不存储，也不读取"
 },
 "Hồ sơ trình duyệt, cookie, phiên đăng nhập, lịch sử duyệt web và toàn bộ dữ liệu phát sinh bên trong từng hồ sơ được mã hóa và lưu ngay trên máy của bạn. Các dữ liệu này không được gửi về máy chủ của chúng tôi.": {
  "en": "Browser profiles, cookies, login sessions, browsing history and all data generated within each profile are encrypted and stored directly on Your device. This data is not sent to our servers.",
  "ru": "Профили браузера, cookie, сеансы входа, история просмотров и все данные, возникающие внутри каждого профиля, шифруются и хранятся непосредственно на Вашем устройстве. Эти данные не передаются на наши серверы.",
  "zh": "浏览器配置文件、Cookie、登录会话、浏览历史以及每个配置文件内产生的全部数据均经过加密并直接存储在您的设备上。这些数据不会发送至我们的服务器。"
 },
 "Khi bạn bật đồng bộ, bạn tự cấu hình kho lưu trữ của riêng mình. CGTBrowser không cung cấp và không vận hành kho lưu trữ đó. Dữ liệu được mã hóa rồi chuyển thẳng từ máy bạn tới đích lưu trữ bạn chọn - không đi qua và không lưu lại trên hệ thống của chúng tôi. Khóa mã hóa do bạn giữ.": {
  "en": "When You enable sync, You configure Your own storage yourself. CGTBrowser does not provide or operate that storage. Data is encrypted and then transferred directly from Your device to the storage destination You choose — it neither passes through nor is retained on our systems. The encryption key is held by You.",
  "ru": "При включении синхронизации Вы самостоятельно настраиваете собственное хранилище. CGTBrowser не предоставляет это хранилище и не управляет им. Данные шифруются, а затем передаются напрямую с Вашего устройства в выбранное Вами место хранения — они не проходят через наши системы и не сохраняются в них. Ключ шифрования хранится у Вас.",
  "zh": "当您启用同步时，由您自行配置您自己的存储。CGTBrowser不提供也不运营该存储。数据经加密后直接从您的设备传输至您选择的存储目标，既不经过我们的系统，也不在我们的系统中留存。加密密钥由您持有。"
 },
 "Hệ quả: chúng tôi không có khả năng kỹ thuật để đọc nội dung hồ sơ của bạn. Chúng tôi không biết bạn đăng nhập tài khoản nào, truy cập website nào hay lưu dữ liệu gì trong từng hồ sơ.": {
  "en": "As a result, we have no technical ability to read the contents of Your profiles. We do not know which accounts You log into, which websites You visit or what data You store in each profile.",
  "ru": "Как следствие, у нас нет технической возможности читать содержимое Ваших профилей. Мы не знаем, в какие аккаунты Вы входите, какие веб-сайты посещаете и какие данные храните в каждом профиле.",
  "zh": "因此，我们在技术上无法读取您配置文件的内容。我们不知道您登录了哪些账户、访问了哪些网站，也不知道您在每个配置文件中存储了哪些数据。"
 },
 "1.2. Dữ liệu vận hành - chúng tôi quản lý": {
  "en": "1.2. Operational data - we manage it",
  "ru": "1.2. Эксплуатационные данные - мы ими управляем",
  "zh": "1.2. 运营数据 - 由我们管理"
 },
 "Để hệ thống hoạt động được, chúng tôi lưu trữ một số thông tin vận hành, tách biệt hoàn toàn với dữ liệu đồng bộ nêu trên. Chi tiết tại mục 2.": {
  "en": "For the system to function, we store certain operational information, kept completely separate from the synced data described above. Details are provided in Section 2.",
  "ru": "Для работы системы мы храним определённую эксплуатационную информацию, полностью отделённую от указанных выше синхронизируемых данных. Подробности приведены в разделе 2.",
  "zh": "为使系统正常运行，我们会存储部分运营信息，这些信息与上述同步数据完全分离。详见第 2 节。"
 },
 "2. Thông tin chúng tôi thu thập": {
  "en": "2. Information We Collect",
  "ru": "2. Информация, которую мы собираем",
  "zh": "2. 我们收集的信息"
 },
 "2.1. Thông tin bạn cung cấp": {
  "en": "2.1. Information You provide",
  "ru": "2.1. Информация, предоставляемая Вами",
  "zh": "2.1. 您提供的信息"
 },
 "Thông tin tài khoản: email, tên hiển thị, mật khẩu (lưu ở dạng đã băm - chúng tôi không lưu mật khẩu dạng đọc được).": {
  "en": "Account information: email, display name, password (stored in hashed form — we do not store passwords in readable form).",
  "ru": "Данные аккаунта: адрес электронной почты, отображаемое имя, пароль (хранится в хешированном виде — мы не храним пароли в читаемом виде).",
  "zh": "账户信息：电子邮箱、显示名称、密码（以哈希形式存储，我们不存储可读形式的密码）。"
 },
 "Thông tin thanh toán: được xử lý bởi đối tác thanh toán. Chúng tôi không lưu số thẻ đầy đủ.": {
  "en": "Payment information: processed by our payment partners. We do not store full card numbers.",
  "ru": "Платёжные данные: обрабатываются платёжными партнёрами. Мы не храним полные номера карт.",
  "zh": "支付信息：由支付合作伙伴处理。我们不存储完整的卡号。"
 },
 "Nội dung hỗ trợ: mô tả sự cố, ảnh chụp màn hình, tệp nhật ký bạn gửi khi liên hệ.": {
  "en": "Support content: issue descriptions, screenshots and log files You submit when contacting us.",
  "ru": "Содержимое обращений в поддержку: описания проблем, снимки экрана, файлы журналов, которые Вы отправляете при обращении к нам.",
  "zh": "支持内容：您联系我们时提交的问题描述、屏幕截图和日志文件。"
 },
 "2.2. Thông tin vận hành": {
  "en": "2.2. Operational information",
  "ru": "2.2. Эксплуатационная информация",
  "zh": "2.2. 运营信息"
 },
 "Gói dịch vụ: loại gói, thời hạn, số dư, lịch sử giao dịch.": {
  "en": "Service plan: plan type, term, balance, transaction history.",
  "ru": "Тарифный план: тип тарифа, срок действия, баланс, история транзакций.",
  "zh": "服务套餐：套餐类型、有效期、余额、交易记录。"
 },
 "Cấu hình hồ sơ: tên hồ sơ, ghi chú, nhóm, tham số vân tay, thiết lập proxy. Đây là thông số cấu hình, không phải nội dung phiên đăng nhập.": {
  "en": "Profile configuration: profile name, notes, group, fingerprint parameters, proxy settings. These are configuration parameters, not the contents of login sessions.",
  "ru": "Конфигурация профиля: название профиля, заметки, группа, параметры отпечатка, настройки прокси. Это параметры конфигурации, а не содержимое сеансов входа.",
  "zh": "配置文件设置：配置文件名称、备注、分组、指纹参数、代理设置。这些是配置参数，而非登录会话的内容。"
 },
 "Không gian làm việc: danh sách thành viên, phân quyền, hạn mức hồ sơ, trạng thái khóa hồ sơ đang được sử dụng.": {
  "en": "Workspace: member list, permissions, profile quotas, lock status of profiles currently in use.",
  "ru": "Рабочее пространство: список участников, права доступа, лимиты профилей, статус блокировки используемых профилей.",
  "zh": "工作区：成员列表、权限分配、配置文件配额、正在使用的配置文件的锁定状态。"
 },
 "Nhật ký thao tác: thời điểm tạo, mở, đóng, xóa hồ sơ - phục vụ tính năng nhật ký hoạt động và xử lý tranh chấp trong nhóm.": {
  "en": "Activity log: times at which profiles are created, opened, closed and deleted — used for the activity log feature and for resolving disputes within a team.",
  "ru": "Журнал действий: время создания, открытия, закрытия и удаления профилей — используется для функции журнала активности и урегулирования споров внутри команды.",
  "zh": "操作日志：配置文件的创建、打开、关闭、删除时间，用于活动日志功能及处理团队内部争议。"
 },
 "2.3. Thông tin kỹ thuật": {
  "en": "2.3. Technical information",
  "ru": "2.3. Техническая информация",
  "zh": "2.3. 技术信息"
 },
 "Phiên bản phần mềm, hệ điều hành, mã định danh cài đặt.": {
  "en": "Software version, operating system, installation identifier.",
  "ru": "Версия программного обеспечения, операционная система, идентификатор установки.",
  "zh": "软件版本、操作系统、安装标识符。"
 },
 "Địa chỉ IP và thời điểm truy cập, phục vụ bảo mật tài khoản và chống lạm dụng.": {
  "en": "IP address and time of access, used for account security and abuse prevention.",
  "ru": "IP-адрес и время доступа - для обеспечения безопасности учётной записи и предотвращения злоупотреблений.",
  "zh": "IP 地址和访问时间，用于账户安全和防止滥用。"
 },
 "Nhật ký sự cố khi phần mềm gặp lỗi.": {
  "en": "Crash logs when the software encounters an error.",
  "ru": "Журналы сбоев при возникновении ошибок в работе программного обеспечения.",
  "zh": "软件出错时的故障日志。"
 },
 "3. Thông tin chúng tôi KHÔNG thu thập": {
  "en": "3. Information We Do NOT Collect",
  "ru": "3. Информация, которую мы НЕ собираем",
  "zh": "3. 我们不收集的信息"
 },
 "Để tránh hiểu nhầm, chúng tôi nêu rõ những gì không bao giờ được gửi về máy chủ:": {
  "en": "To avoid any misunderstanding, we state clearly what is never sent to our servers:",
  "ru": "Во избежание недоразумений мы чётко указываем, что никогда не передаётся на серверы:",
  "zh": "为避免误解，我们明确说明以下绝不会发送至服务器的内容："
 },
 "Nội dung cookie và token đăng nhập trong các hồ sơ của bạn.": {
  "en": "The contents of cookies and login tokens in Your profiles.",
  "ru": "Содержимое файлов cookie и токенов входа в Ваших профилях.",
  "zh": "您配置文件中的 Cookie 内容和登录令牌。"
 },
 "Danh sách website bạn truy cập trong từng hồ sơ.": {
  "en": "The list of websites You visit in each profile.",
  "ru": "Список веб-сайтов, которые Вы посещаете в каждом профиле.",
  "zh": "您在各个配置文件中访问的网站列表。"
 },
 "Tên đăng nhập, mật khẩu của bạn trên các nền tảng bên thứ ba.": {
  "en": "Your usernames and passwords on third-party platforms.",
  "ru": "Ваши логины и пароли на сторонних платформах.",
  "zh": "您在第三方平台上的用户名和密码。"
 },
 "Nội dung biểu mẫu, tin nhắn, tài liệu hay bất kỳ dữ liệu nào phát sinh khi duyệt web.": {
  "en": "The contents of forms, messages, documents or any other data generated while browsing the web.",
  "ru": "Содержимое форм, сообщений, документов или любые иные данные, возникающие в процессе просмотра веб-страниц.",
  "zh": "表单、消息、文档内容，或浏览网页时产生的任何数据。"
 },
 "Ảnh chụp màn hình hoặc bản ghi thao tác bên trong hồ sơ.": {
  "en": "Screenshots or recordings of actions performed inside profiles.",
  "ru": "Снимки экрана или записи действий внутри профилей.",
  "zh": "配置文件内的屏幕截图或操作记录。"
 },
 "Nhật ký sự cố cũng không bao gồm cookie, mật khẩu hay nội dung trang web.": {
  "en": "Crash logs likewise do not include cookies, passwords or web page content.",
  "ru": "Журналы сбоев также не включают cookie, пароли или содержимое веб-страниц.",
  "zh": "故障日志同样不包含Cookie、密码或网页内容。"
 },
 "4. Cách chúng tôi sử dụng dữ liệu": {
  "en": "4. How We Use Data",
  "ru": "4. Как мы используем данные",
  "zh": "4. 我们如何使用数据"
 },
 "Cung cấp, duy trì và cải thiện phần mềm cùng các dịch vụ liên quan.": {
  "en": "To provide, maintain and improve the software and related Services.",
  "ru": "Предоставление, поддержка и улучшение программного обеспечения и связанных с ним Сервисов.",
  "zh": "提供、维护和改进本软件及相关服务。"
 },
 "Xác thực tài khoản và cấp quyền truy cập theo gói dịch vụ.": {
  "en": "To authenticate accounts and grant access according to the service plan.",
  "ru": "Аутентификация учётных записей и предоставление доступа в соответствии с тарифным планом.",
  "zh": "验证账户身份，并根据服务套餐授予访问权限。"
 },
 "Xử lý giao dịch và quản lý gói dịch vụ của bạn.": {
  "en": "To process transactions and manage Your service plan.",
  "ru": "Обработка транзакций и управление Вашим тарифным планом.",
  "zh": "处理交易并管理您的服务套餐。"
 },
 "Vận hành tính năng nhóm: mời thành viên, phân quyền, khóa hồ sơ đang được sử dụng, ghi nhật ký hoạt động.": {
  "en": "To operate team features: inviting members, assigning permissions, locking profiles that are in use, and keeping activity logs.",
  "ru": "Обеспечение работы командных функций: приглашение участников, распределение прав доступа, блокировка используемых профилей, ведение журнала действий.",
  "zh": "运行团队功能：邀请成员、分配权限、锁定正在使用的配置文件、记录活动日志。"
 },
 "Gửi thông báo quan trọng về bảo mật, cập nhật hoặc thay đổi dịch vụ.": {
  "en": "To send important notices about security, updates or changes to the Services.",
  "ru": "Направление важных уведомлений о безопасности, обновлениях или изменениях Сервисов.",
  "zh": "发送有关安全、更新或服务变更的重要通知。"
 },
 "Cung cấp hỗ trợ kỹ thuật và xử lý khiếu nại.": {
  "en": "To provide technical support and handle complaints.",
  "ru": "Оказание технической поддержки и рассмотрение жалоб.",
  "zh": "提供技术支持并处理投诉。"
 },
 "Phát hiện, ngăn chặn gian lận và bảo đảm an toàn hệ thống.": {
  "en": "To detect and prevent fraud and ensure system security.",
  "ru": "Выявление и предотвращение мошенничества, обеспечение безопасности системы.",
  "zh": "发现和防范欺诈行为，保障系统安全。"
 },
 "5. Chia sẻ dữ liệu": {
  "en": "5. Data Sharing",
  "ru": "5. Передача данных",
  "zh": "5. 数据共享"
 },
 "Chúng tôi không bán, không cho thuê, không trao đổi dữ liệu cá nhân của bạn. Dữ liệu chỉ được chia sẻ trong các trường hợp giới hạn sau:": {
  "en": "We do not sell, rent or trade Your personal data. Data is shared only in the following limited cases:",
  "ru": "Мы не продаём, не сдаём в аренду и не обмениваем Ваши персональные данные. Данные передаются только в следующих ограниченных случаях:",
  "zh": "我们不出售、不出租、不交换您的个人数据。数据仅在以下有限情形下共享："
 },
 "5.1. Nhà cung cấp dịch vụ. Đối tác thanh toán, hạ tầng máy chủ, dịch vụ gửi email - chỉ tiếp cận thông tin cần thiết cho công việc của họ, theo hợp đồng bảo mật.": {
  "en": "5.1. Service providers. Payment partners, server infrastructure and email delivery services — they access only the information necessary for their work, under confidentiality agreements.",
  "ru": "5.1. Поставщики услуг. Платёжные партнёры, серверная инфраструктура, сервисы отправки электронной почты — получают доступ только к информации, необходимой для выполнения их работы, в соответствии с соглашениями о конфиденциальности.",
  "zh": "5.1. 服务提供商。支付合作伙伴、服务器基础设施、电子邮件发送服务，仅可依据保密协议获取其工作所必需的信息。"
 },
 "5.2. Yêu cầu pháp luật. Khi có yêu cầu hợp pháp từ cơ quan nhà nước có thẩm quyền, tòa án hoặc cơ quan thi hành án.": {
  "en": "5.2. Legal requirements. Upon a lawful request from a competent state authority, a court or an enforcement authority.",
  "ru": "5.2. Требования закона. При наличии законного запроса компетентного государственного органа, суда или органа исполнительного производства.",
  "zh": "5.2. 法律要求。在有权国家机关、法院或执行机关提出合法要求时。"
 },
 "5.3. Bảo vệ quyền lợi. Khi cần phát hiện, ngăn chặn gian lận, tấn công hệ thống hoặc bảo vệ quyền lợi hợp pháp của chúng tôi và người dùng khác.": {
  "en": "5.3. Protection of rights. When necessary to detect and prevent fraud or attacks on the system, or to protect the legitimate rights and interests of us and other users.",
  "ru": "5.3. Защита прав. Когда это необходимо для выявления и предотвращения мошенничества, атак на систему или для защиты законных прав и интересов нашей компании и других пользователей.",
  "zh": "5.3. 权益保护。在需要发现、阻止欺诈行为或系统攻击，或保护我们及其他用户的合法权益时。"
 },
 "5.4. Chuyển giao doanh nghiệp. Trong trường hợp sáp nhập, mua bán hoặc tái cơ cấu, dữ liệu có thể được chuyển giao cho bên tiếp nhận với cam kết duy trì mức bảo vệ tương đương. Chúng tôi sẽ thông báo trước.": {
  "en": "5.4. Business transfer. In the event of a merger, acquisition or restructuring, data may be transferred to the receiving party with a commitment to maintain an equivalent level of protection. We will notify You in advance.",
  "ru": "5.4. Передача бизнеса. В случае слияния, купли-продажи или реорганизации данные могут быть переданы принимающей стороне при условии обязательства сохранить равноценный уровень защиты. Мы уведомим Вас заранее.",
  "zh": "5.4. 业务转让。在合并、收购或重组的情况下，数据可能会转让给接收方，且接收方须承诺维持同等水平的保护。我们将事先通知。"
 },
 "5.5. Trong phạm vi không gian làm việc. Chủ sở hữu và quản trị viên có thể xem thông tin hoạt động của thành viên trong nhóm: hồ sơ đã tạo, thời điểm truy cập, thiết bị đang giữ hồ sơ. Đây là tính năng quản lý nhóm mà bạn chấp nhận khi tham gia không gian làm việc của người khác.": {
  "en": "5.5. Within a workspace. Owners and administrators can view activity information of team members: profiles created, access times, and devices currently holding profiles. This is a team management feature that You accept when joining another person’s workspace.",
  "ru": "5.5. В пределах рабочего пространства. Владельцы и администраторы могут просматривать информацию об активности участников команды: созданные профили, время доступа, устройства, за которыми закреплены профили. Это функция управления командой, которую Вы принимаете, присоединяясь к рабочему пространству другого лица.",
  "zh": "5.5. 工作区范围内。所有者和管理员可以查看团队成员的活动信息：已创建的配置文件、访问时间、正在占用配置文件的设备。这是您加入他人工作区时即表示接受的团队管理功能。"
 },
 "6. Cookie trên website": {
  "en": "6. Cookies on the Website",
  "ru": "6. Файлы cookie на веб-сайте",
  "zh": "6. 网站上的 Cookie"
 },
 "Website của chúng tôi sử dụng cookie để duy trì phiên đăng nhập, ghi nhớ tùy chọn giao diện và phân tích lưu lượng truy cập ở dạng thống kê tổng hợp. Bạn có thể quản lý hoặc chặn cookie trong cài đặt trình duyệt.": {
  "en": "Our website uses cookies to maintain login sessions, remember interface preferences and analyze traffic in aggregated statistical form. You can manage or block cookies in Your browser settings.",
  "ru": "Наш веб-сайт использует файлы cookie для поддержания сеанса входа, запоминания настроек интерфейса и анализа посещаемости в виде обобщённой статистики. Вы можете управлять файлами cookie или блокировать их в настройках браузера.",
  "zh": "我们的网站使用 Cookie 来保持登录会话、记住界面偏好设置，并以汇总统计的形式分析访问流量。您可以在浏览器设置中管理或阻止 Cookie。"
 },
 "Lưu ý phân biệt: cookie của website CGTBrowser hoàn toàn khác với cookie bên trong các hồ sơ trình duyệt bạn tạo. Hai loại này độc lập với nhau.": {
  "en": "Please note the distinction: cookies of the CGTBrowser website are entirely different from cookies inside the browser profiles You create. These two types are independent of each other.",
  "ru": "Обратите внимание на различие: cookie веб-сайта CGTBrowser полностью отличаются от cookie внутри профилей браузера, которые Вы создаёте. Эти два типа независимы друг от друга.",
  "zh": "请注意区分：CGTBrowser网站的Cookie与您创建的浏览器配置文件内部的Cookie完全不同。这两类Cookie彼此独立。"
 },
 "7. Bảo mật": {
  "en": "7. Security",
  "ru": "7. Безопасность",
  "zh": "7. 安全"
 },
 "Chúng tôi áp dụng các biện pháp kỹ thuật và tổ chức hợp lý để bảo vệ dữ liệu:": {
  "en": "We apply reasonable technical and organizational measures to protect data:",
  "ru": "Мы применяем разумные технические и организационные меры для защиты данных:",
  "zh": "我们采取合理的技术和组织措施保护数据："
 },
 "Mã hóa dữ liệu hồ sơ khi lưu trên máy bạn.": {
  "en": "Profile data is encrypted when stored on Your device.",
  "ru": "Шифрование данных профилей при хранении на Вашем устройстве.",
  "zh": "配置文件数据存储在您的设备上时会被加密。"
 },
 "Mã hóa dữ liệu trước khi truyền khi bạn bật đồng bộ.": {
  "en": "Data is encrypted before transmission when You enable sync.",
  "ru": "Шифрование данных перед передачей при включении Вами синхронизации.",
  "zh": "您启用同步时，数据在传输前会被加密。"
 },
 "Kết nối giữa phần mềm và máy chủ được mã hóa.": {
  "en": "The connection between the software and the servers is encrypted.",
  "ru": "Соединение между программным обеспечением и серверами шифруется.",
  "zh": "本软件与服务器之间的连接经过加密。"
 },
 "Mật khẩu tài khoản lưu dưới dạng băm một chiều.": {
  "en": "Account passwords are stored as one-way hashes.",
  "ru": "Пароли учётных записей хранятся в виде односторонних хешей.",
  "zh": "账户密码以单向哈希形式存储。"
 },
 "Phân quyền truy cập nội bộ theo nguyên tắc tối thiểu cần thiết.": {
  "en": "Internal access permissions are assigned on a least-privilege basis.",
  "ru": "Внутренние права доступа распределяются по принципу минимально необходимых привилегий.",
  "zh": "内部访问权限按照最小必要原则分配。"
 },
 "Tuy nhiên, không có phương thức nào an toàn tuyệt đối. Bạn cũng cần đặt mật khẩu mạnh, không chia sẻ thông tin đăng nhập và giữ thiết bị của mình an toàn.": {
  "en": "However, no method is absolutely secure. You also need to set a strong password, not share Your login credentials, and keep Your devices secure.",
  "ru": "Тем не менее ни один метод не является абсолютно безопасным. Вам также необходимо устанавливать надёжный пароль, не передавать данные для входа третьим лицам и обеспечивать безопасность своих устройств.",
  "zh": "然而，没有任何方法是绝对安全的。您也需要设置强密码、不共享登录信息，并确保您的设备安全。"
 },
 "Với dữ liệu đồng bộ, việc bảo mật kho lưu trữ do bạn cấu hình thuộc trách nhiệm của bạn và chịu sự điều chỉnh bởi điều khoản của nhà cung cấp dịch vụ lưu trữ đó.": {
  "en": "For synced data, securing the storage that You configure is Your responsibility and is governed by the terms of that storage service provider.",
  "ru": "В отношении синхронизируемых данных обеспечение безопасности настроенного Вами хранилища является Вашей ответственностью и регулируется условиями поставщика соответствующих услуг хранения.",
  "zh": "对于同步数据，您所配置的存储库的安全由您负责，并受该存储服务提供商条款的约束。"
 },
 "8. Quyền của bạn": {
  "en": "8. Your Rights",
  "ru": "8. Ваши права",
  "zh": "8. 您的权利"
 },
 "Tùy theo quy định pháp luật áp dụng, bạn có thể có các quyền sau:": {
  "en": "Depending on applicable law, You may have the following rights:",
  "ru": "В зависимости от применимого законодательства Вы можете обладать следующими правами:",
  "zh": "根据适用法律的规定，您可能享有以下权利："
 },
 "Truy cập: yêu cầu biết chúng tôi đang lưu những thông tin gì về bạn.": {
  "en": "Access: request to know what information we hold about You.",
  "ru": "Доступ: запросить сведения о том, какую информацию о Вас мы храним.",
  "zh": "访问：要求了解我们存储了您的哪些信息。"
 },
 "Chỉnh sửa: cập nhật thông tin không chính xác.": {
  "en": "Rectification: update inaccurate information.",
  "ru": "Исправление: обновить неточную информацию.",
  "zh": "更正：更新不准确的信息。"
 },
 "Xóa: yêu cầu xóa tài khoản và dữ liệu liên quan.": {
  "en": "Erasure: request deletion of Your account and related data.",
  "ru": "Удаление: запросить удаление аккаунта и связанных с ним данных.",
  "zh": "删除：要求删除账户及相关数据。"
 },
 "Xuất dữ liệu: yêu cầu bản sao dữ liệu ở định dạng đọc được.": {
  "en": "Data export: request a copy of Your data in a readable format.",
  "ru": "Экспорт данных: запросить копию данных в читаемом формате.",
  "zh": "导出数据：要求获取可读格式的数据副本。"
 },
 "Từ chối: tắt các tính năng thu thập tùy chọn như gửi nhật ký sự cố.": {
  "en": "Opt-out: disable optional collection features such as sending crash logs.",
  "ru": "Отказ: отключить необязательные функции сбора данных, например отправку журналов сбоев.",
  "zh": "拒绝：关闭可选的收集功能，例如发送故障日志。"
 },
 "Rút lại đồng ý: tắt đồng bộ bất cứ lúc nào.": {
  "en": "Withdrawal of consent: disable sync at any time.",
  "ru": "Отзыв согласия: отключить синхронизацию в любое время.",
  "zh": "撤回同意：随时关闭同步。"
 },
 "Vui lòng liên hệ để thực hiện các quyền này.": {
  "en": "Please contact us to exercise these rights.",
  "ru": "Для реализации этих прав, пожалуйста, свяжитесь с нами.",
  "zh": "如需行使上述权利，请与我们联系。"
 },
 "9. Lưu giữ dữ liệu": {
  "en": "9. Data Retention",
  "ru": "9. Хранение данных",
  "zh": "9. 数据保留"
 },
 "Chúng tôi chỉ lưu giữ dữ liệu trong thời gian cần thiết để cung cấp dịch vụ hoặc theo yêu cầu của pháp luật:": {
  "en": "We retain data only for as long as necessary to provide the Services or as required by law:",
  "ru": "Мы храним данные только в течение срока, необходимого для предоставления Сервисов, или в соответствии с требованиями законодательства:",
  "zh": "我们仅在提供服务所需的期限内或按法律要求保留数据："
 },
 "Thông tin tài khoản: lưu trong suốt thời gian tài khoản còn hoạt động.": {
  "en": "Account information: retained for as long as the account remains active.",
  "ru": "Информация об учётной записи: хранится в течение всего срока, пока учётная запись остаётся активной.",
  "zh": "账户信息：在账户保持有效期间一直保留。"
 },
 "Sau khi bạn yêu cầu xóa tài khoản: dữ liệu cá nhân được xóa hoặc ẩn danh hóa, trừ các dữ liệu phải lưu theo nghĩa vụ pháp lý (ví dụ chứng từ giao dịch).": {
  "en": "After You request account deletion: personal data is deleted or anonymized, except for data that must be retained to meet legal obligations (for example, transaction records).",
  "ru": "После запроса Вами удаления учётной записи: персональные данные удаляются или обезличиваются, за исключением данных, которые подлежат хранению в силу требований законодательства (например, документы по транзакциям).",
  "zh": "在您申请删除账户后：个人数据将被删除或匿名化处理，但依法律义务必须保留的数据（例如交易凭证）除外。"
 },
 "Nhật ký kỹ thuật và báo cáo sự cố: lưu trong thời gian giới hạn phục vụ chẩn đoán, sau đó xóa tự động.": {
  "en": "Technical logs and crash reports: retained for a limited period for diagnostic purposes, then deleted automatically.",
  "ru": "Технические журналы и отчёты о сбоях: хранятся в течение ограниченного срока для целей диагностики, после чего автоматически удаляются.",
  "zh": "技术日志和故障报告：为诊断目的保留有限的时间，之后自动删除。"
 },
 "Dữ liệu đồng bộ nằm trong kho lưu trữ của bạn, do bạn tự quyết định thời gian lưu giữ.": {
  "en": "Synced data resides in Your own storage, and You decide how long it is retained.",
  "ru": "Синхронизируемые данные находятся в Вашем хранилище, и срок их хранения Вы определяете самостоятельно.",
  "zh": "同步数据位于您自己的存储库中，保留期限由您自行决定。"
 },
 "10. Quyền Riêng Tư của Trẻ Em": {
  "en": "10. Children's Privacy",
  "ru": "10. Конфиденциальность детей",
  "zh": "10. 儿童隐私"
 },
 "Dịch vụ không hướng tới người dưới độ tuổi thành niên theo quy định pháp luật. Chúng tôi không kiểm soát được việc trẻ em tự truy cập website hoặc cài đặt ứng dụng khi không có sự giám sát của cha mẹ. Phụ huynh nên đọc Chính sách Bảo mật này trước khi đồng ý cho con em sử dụng ứng dụng và dịch vụ của chúng tôi.": {
  "en": "The Services are not intended for persons under the age of majority as defined by law. We cannot control whether children access the website or install the application on their own without parental supervision. Parents should read this Privacy Policy before allowing their children to use our application and Services.",
  "ru": "Сервисы не предназначены для лиц, не достигших совершеннолетия в соответствии с законодательством. Мы не можем контролировать самостоятельный доступ детей к веб-сайту или установку ими приложения без надзора родителей. Родителям следует ознакомиться с настоящей Политикой конфиденциальности, прежде чем разрешать детям пользоваться нашим приложением и Сервисами.",
  "zh": "本服务不面向未达到法定成年年龄的人士。对于儿童在无父母监护的情况下自行访问网站或安装应用程序，我们无法加以控制。家长在同意子女使用我们的应用程序和服务之前，应阅读本隐私政策。"
 },
 "11. Thay đổi chính sách": {
  "en": "11. Changes to the Policy",
  "ru": "11. Изменения Политики",
  "zh": "11. 政策变更"
 },
 "Chính sách này có thể được cập nhật theo thời gian. Phiên bản mới có hiệu lực kể từ khi được đăng tải trên trang này. Với thay đổi trọng yếu ảnh hưởng đến quyền của bạn, chúng tôi sẽ thông báo qua email hoặc trong ứng dụng trước khi áp dụng.": {
  "en": "This Policy may be updated from time to time. A new version takes effect once it is published on this page. For material changes affecting Your rights, we will notify You by email or in the application before they apply.",
  "ru": "Настоящая Политика может время от времени обновляться. Новая редакция вступает в силу с момента её публикации на этой странице. О существенных изменениях, затрагивающих Ваши права, мы уведомим Вас по электронной почте или в приложении до начала их применения.",
  "zh": "本政策可能会不时更新。新版本自在本页面发布之日起生效。对于影响您权利的重大变更，我们将在适用前通过电子邮件或在应用程序内通知您。"
 },
 "12. Liên hệ": {
  "en": "12. Contact",
  "ru": "12. Контакты",
  "zh": "12. 联系方式"
 },
 "Mọi câu hỏi về quyền riêng tư, vui lòng liên hệ với chúng tôi qua trang Liên hệ.": {
  "en": "For any questions about privacy, please contact us via the Contact page.",
  "ru": "По любым вопросам, связанным с конфиденциальностью, свяжитесь с нами через страницу Контакты.",
  "zh": "如有任何隐私相关问题，请通过联系我们页面与我们联系。"
 },
 "Nội dung": {
  "en": "Contents",
  "ru": "Содержание",
  "zh": "目录"
 },
 "Bản dịch này chỉ nhằm mục đích tham khảo. Nếu có khác biệt giữa các bản, bản tiếng Việt là bản có giá trị pháp lý.": {
  "en": "This translation is provided for reference purposes only. In the event of any discrepancy between the versions, the Vietnamese version shall prevail as the legally binding version.",
  "ru": "Настоящий перевод предоставляется исключительно в справочных целях. В случае расхождений между версиями юридическую силу имеет версия на вьетнамском языке.",
  "zh": "本译文仅供参考。如各版本之间存在差异，以越南语版本为具有法律效力的版本。"
 }
};
