// ============================================================================
//  fingerprint.js - bộ SINH NGẪU NHIÊN vân tay (client-side, không cần server)
// ----------------------------------------------------------------------------
//  Gom toàn bộ logic random từng nằm rải rác trong views/profile_create.js về
//  một chỗ. Trọng tâm là những trường dễ "lộ" nhất khi giả lập: WebGL metadata
//  (vendor + ANGLE renderer) và User Agent - hai thứ phải LUÔN khớp với OS đã
//  chọn, nếu không sẽ là dấu hiệu antidetect rõ nhất.
//
//  Hợp đồng dữ liệu (không đổi so với trước):
//    - newFingerprint()  → object trạng thái form (nhánh `ui` của fingerprint).
//    - buildFpConfig()   → object `fpConfig` đẩy vào CGTBrowser qua --fp-config.
//    - uaString()        → chuỗi User Agent theo kernel + OS.
//  profile_create.js gói lại thành: { meta, fpConfig, ui } khi lưu lên server.
//
//  LƯU Ý antidetect: MẶC ĐỊNH phiên bản Chrome trong UA bằng phiên bản Chromium
//  thật của CGTBrowser (140.x) - đây là lựa chọn an toàn nhất. Người dùng CÓ THỂ
//  chủ động chọn major version khác qua ô "User-Agent" (giống AdsPower): khi đó UA
//  phát chuỗi full-version THẬT của bản Chrome đó (bảng CHROME_BUILDS bên dưới).
// ============================================================================

// Phiên bản engine thật (Chromium/Firefox) mà UA phải KHỚP. Trước đây hardcode 140.x;
// nay theo MÔ HÌNH ĐA NHÂN, engine thật = nhân ĐANG DÙNG mà người dùng đã tải/chọn, nên
// các giá trị này là BIẾN có thể cập nhật qua setActiveKernel() lúc app khởi động (đọc từ
// manifest nhân đang dùng). Giá trị mặc định bên dưới là "phao cứu sinh" khi chưa gọi
// setter (vd chưa cài nhân nào) - vẫn phải là bản THẬT để không tự lộ.
//   • CHROME_VERSION      : dạng rút gọn "major.0.0.0" cho token UA (Chrome đóng băng).
//   • KERNEL_MAJOR        : số major của nhân đang dùng.
//   • KERNEL_FULL_VERSION : full-version THẬT của binary → uaFullVersion == fullVersionList.
//   • FIREFOX_VERSION     : phiên bản nhân Firefox đang dùng.
let CHROME_VERSION = '153.0.0.0';
let KERNEL_MAJOR = 153;
let KERNEL_FULL_VERSION = '153.0.7993.0';
let FIREFOX_VERSION = '135.0';

// Cập nhật phiên bản engine theo nhân ĐANG DÙNG. Gọi 1 lần lúc boot (app.js) sau khi biết
// nhân active. Tham số linh hoạt: { chromiumFull?, firefoxVersion? } - mỗi cái thiếu thì
// GIỮ NGUYÊN giá trị hiện tại (không ghi đè bằng rác). chromiumFull phải là full-version
// hợp lệ dạng "140.0.7339.264"; từ đó suy ra major + dạng rút gọn "140.0.0.0".
export function setActiveKernel({ chromiumFull, firefoxVersion } = {}) {
  const full = String(chromiumFull || '').trim();
  const m = full.match(/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/);
  if (m) {
    KERNEL_FULL_VERSION = full;
    KERNEL_MAJOR = parseInt(m[1], 10);
    CHROME_VERSION = `${m[1]}.0.0.0`;
    // Nhân đang dùng LUÔN phải có mặt trong bảng build (dropdown "User-Agent" +
    // randomChromeFull). Nếu là major mới hơn bảng chụp lúc phát hành (vd 151) thì
    // đây là chỗ duy nhất nó được nạp vào - xem registerKernelBuild().
    registerKernelBuild(full);
  }
  const fx = String(firefoxVersion || '').trim();
  if (/^\d+(\.\d+)*$/.test(fx)) {
    FIREFOX_VERSION = fx;
    // Song sinh với registerKernelBuild() ở trên: nhân Firefox đang dùng LUÔN phải có
    // trong dropdown "User-Agent". Nhân mới hơn ảnh chụp lúc phát hành (vd 153) thì đây
    // là chỗ duy nhất nó nới được mốc trên - xem registerFirefoxBuild().
    registerFirefoxBuild(fx);
  }
  return { CHROME_VERSION, KERNEL_MAJOR, KERNEL_FULL_VERSION, FIREFOX_VERSION };
}

// ĐỌC phiên bản nhân đang dùng. Bắt buộc phải qua hàm này chứ KHÔNG được import biến
// ra ngoài: `export let` bị "đóng băng" tại thời điểm import ở một số bundler, còn ở
// đây giá trị THAY ĐỔI sau khi setActiveKernel() chạy (app khởi động xong mới biết
// nhân nào đang dùng). Màn hình nào cần hiển thị số phiên bản thì gọi lúc render.
export function activeKernel() {
  return { CHROME_VERSION, KERNEL_MAJOR, KERNEL_FULL_VERSION, FIREFOX_VERSION };
}

// ---- Bảng major → DANH SÁCH full version Chrome stable THẬT (88..148) ----
// Dùng khi người dùng chọn một phiên bản cụ thể ở ô "User-Agent" (giống AdsPower).
// Mỗi major chứa NHIỀU build ĐÃ PHÁT HÀNH thật, lấy trực tiếp từ API CHÍNH THỨC
// của Google (versionhistory.googleapis.com, kênh stable/win). Số build (thành
// phần thứ 3) cố định theo major; phần patch (thứ 4) đổi giữa các bản phát hành →
// "Tạo lại"/"Tạo vân tay mới" random một build THẬT trong dải của major đã chọn.
// TUYỆT ĐỐI không bịa số patch (build sai = dễ bị phát hiện hơn).
const CHROME_BUILDS = {
  150: ['150.0.7871.187', '150.0.7871.186', '150.0.7871.184', '150.0.7871.183', '150.0.7871.182', '150.0.7871.181', '150.0.7871.130', '150.0.7871.129', '150.0.7871.128', '150.0.7871.127', '150.0.7871.126', '150.0.7871.125', '150.0.7871.124', '150.0.7871.116', '150.0.7871.115', '150.0.7871.114', '150.0.7871.102', '150.0.7871.101', '150.0.7871.100', '150.0.7871.49', '150.0.7871.47', '150.0.7871.46', '150.0.7871.24'],
  149: ['149.0.7827.201', '149.0.7827.200', '149.0.7827.199', '149.0.7827.198', '149.0.7827.197', '149.0.7827.196', '149.0.7827.158', '149.0.7827.157', '149.0.7827.156', '149.0.7827.155', '149.0.7827.116', '149.0.7827.115', '149.0.7827.114', '149.0.7827.104', '149.0.7827.103', '149.0.7827.102', '149.0.7827.55', '149.0.7827.54', '149.0.7827.53', '149.0.7827.22'],
  148: ['148.0.7778.218', '148.0.7778.217', '148.0.7778.216', '148.0.7778.181', '148.0.7778.180', '148.0.7778.179', '148.0.7778.178', '148.0.7778.169', '148.0.7778.168', '148.0.7778.167', '148.0.7778.98', '148.0.7778.97', '148.0.7778.96', '148.0.7778.56'],
  147: ['147.0.7727.139', '147.0.7727.138', '147.0.7727.137', '147.0.7727.119', '147.0.7727.118', '147.0.7727.117', '147.0.7727.116', '147.0.7727.103', '147.0.7727.102', '147.0.7727.101', '147.0.7727.57', '147.0.7727.56', '147.0.7727.55', '147.0.7727.50', '147.0.7727.49', '147.0.7727.24'],
  146: ['146.0.7680.180', '146.0.7680.179', '146.0.7680.178', '146.0.7680.177', '146.0.7680.167', '146.0.7680.166', '146.0.7680.165', '146.0.7680.164', '146.0.7680.155', '146.0.7680.154', '146.0.7680.81', '146.0.7680.80', '146.0.7680.76', '146.0.7680.72', '146.0.7680.66', '146.0.7680.31'],
  145: ['145.0.7632.162', '145.0.7632.161', '145.0.7632.160', '145.0.7632.159', '145.0.7632.119', '145.0.7632.118', '145.0.7632.117', '145.0.7632.116', '145.0.7632.111', '145.0.7632.110', '145.0.7632.109', '145.0.7632.77', '145.0.7632.76', '145.0.7632.68', '145.0.7632.46', '145.0.7632.26'],
  144: ['144.0.7559.135', '144.0.7559.134', '144.0.7559.133', '144.0.7559.132', '144.0.7559.112', '144.0.7559.111', '144.0.7559.110', '144.0.7559.109', '144.0.7559.98', '144.0.7559.97', '144.0.7559.96', '144.0.7559.61', '144.0.7559.60', '144.0.7559.59'],
  143: ['143.0.7499.194', '143.0.7499.193', '143.0.7499.192', '143.0.7499.171', '143.0.7499.170', '143.0.7499.169', '143.0.7499.148', '143.0.7499.147', '143.0.7499.146', '143.0.7499.111', '143.0.7499.110', '143.0.7499.109', '143.0.7499.42', '143.0.7499.41', '143.0.7499.40'],
  142: ['142.0.7444.177', '142.0.7444.176', '142.0.7444.175', '142.0.7444.164', '142.0.7444.163', '142.0.7444.162', '142.0.7444.136', '142.0.7444.135', '142.0.7444.134', '142.0.7444.61', '142.0.7444.60', '142.0.7444.59', '142.0.7444.52'],
  141: ['141.0.7390.125', '141.0.7390.124', '141.0.7390.123', '141.0.7390.122', '141.0.7390.109', '141.0.7390.108', '141.0.7390.107', '141.0.7390.78', '141.0.7390.77', '141.0.7390.76', '141.0.7390.67', '141.0.7390.66', '141.0.7390.65', '141.0.7390.56', '141.0.7390.55', '141.0.7390.37'],
  140: ['140.0.7339.210', '140.0.7339.209', '140.0.7339.208', '140.0.7339.207', '140.0.7339.187', '140.0.7339.186', '140.0.7339.185', '140.0.7339.129', '140.0.7339.128', '140.0.7339.127', '140.0.7339.82', '140.0.7339.81', '140.0.7339.80', '140.0.7339.41'],
  139: ['139.0.7258.157', '139.0.7258.156', '139.0.7258.155', '139.0.7258.154', '139.0.7258.140', '139.0.7258.139', '139.0.7258.138', '139.0.7258.129', '139.0.7258.128', '139.0.7258.127', '139.0.7258.68', '139.0.7258.67', '139.0.7258.66'],
  138: ['138.0.7204.185', '138.0.7204.184', '138.0.7204.183', '138.0.7204.170', '138.0.7204.169', '138.0.7204.168', '138.0.7204.159', '138.0.7204.158', '138.0.7204.157', '138.0.7204.102', '138.0.7204.101', '138.0.7204.100', '138.0.7204.51', '138.0.7204.50', '138.0.7204.49', '138.0.7204.35'],
  137: ['137.0.7151.122', '137.0.7151.121', '137.0.7151.120', '137.0.7151.119', '137.0.7151.105', '137.0.7151.104', '137.0.7151.103', '137.0.7151.70', '137.0.7151.69', '137.0.7151.68', '137.0.7151.57', '137.0.7151.56', '137.0.7151.55', '137.0.7151.41', '137.0.7151.40'],
  136: ['136.0.7103.116', '136.0.7103.115', '136.0.7103.114', '136.0.7103.113', '136.0.7103.94', '136.0.7103.93', '136.0.7103.92', '136.0.7103.49', '136.0.7103.48'],
  135: ['135.0.7049.117', '135.0.7049.116', '135.0.7049.115', '135.0.7049.114', '135.0.7049.97', '135.0.7049.96', '135.0.7049.95', '135.0.7049.86', '135.0.7049.85', '135.0.7049.84', '135.0.7049.43', '135.0.7049.42', '135.0.7049.41'],
  134: ['134.0.6998.179', '134.0.6998.178', '134.0.6998.177', '134.0.6998.167', '134.0.6998.166', '134.0.6998.165', '134.0.6998.119', '134.0.6998.118', '134.0.6998.117', '134.0.6998.90', '134.0.6998.89', '134.0.6998.88', '134.0.6998.37', '134.0.6998.36', '134.0.6998.35'],
  133: ['133.0.6943.143', '133.0.6943.142', '133.0.6943.141', '133.0.6943.128', '133.0.6943.127', '133.0.6943.126', '133.0.6943.100', '133.0.6943.99', '133.0.6943.98', '133.0.6943.60', '133.0.6943.59', '133.0.6943.54', '133.0.6943.53', '133.0.6943.35'],
  132: ['132.0.6834.197', '132.0.6834.196', '132.0.6834.162', '132.0.6834.161', '132.0.6834.160', '132.0.6834.159', '132.0.6834.112', '132.0.6834.111', '132.0.6834.110', '132.0.6834.84', '132.0.6834.83'],
  131: ['131.0.6778.267', '131.0.6778.266', '131.0.6778.265', '131.0.6778.264', '131.0.6778.206', '131.0.6778.205', '131.0.6778.204', '131.0.6778.141', '131.0.6778.140', '131.0.6778.139', '131.0.6778.110', '131.0.6778.109', '131.0.6778.108', '131.0.6778.87', '131.0.6778.86', '131.0.6778.85', '131.0.6778.71', '131.0.6778.70', '131.0.6778.69', '131.0.6778.33'],
  130: ['130.0.6723.119', '130.0.6723.118', '130.0.6723.117', '130.0.6723.116', '130.0.6723.93', '130.0.6723.92', '130.0.6723.91', '130.0.6723.71', '130.0.6723.70', '130.0.6723.69', '130.0.6723.60', '130.0.6723.59', '130.0.6723.58', '130.0.6723.44'],
  129: ['129.0.6668.103', '129.0.6668.102', '129.0.6668.101', '129.0.6668.100', '129.0.6668.90', '129.0.6668.89', '129.0.6668.72', '129.0.6668.71', '129.0.6668.70', '129.0.6668.60', '129.0.6668.59', '129.0.6668.58', '129.0.6668.42'],
  128: ['128.0.6613.139', '128.0.6613.138', '128.0.6613.137', '128.0.6613.122', '128.0.6613.121', '128.0.6613.120', '128.0.6613.119', '128.0.6613.115', '128.0.6613.114', '128.0.6613.113', '128.0.6613.86', '128.0.6613.85', '128.0.6613.84', '128.0.6613.36'],
  127: ['127.0.6533.122', '127.0.6533.121', '127.0.6533.120', '127.0.6533.119', '127.0.6533.101', '127.0.6533.100', '127.0.6533.99', '127.0.6533.90', '127.0.6533.89', '127.0.6533.88', '127.0.6533.74', '127.0.6533.73', '127.0.6533.72', '127.0.6533.57'],
  126: ['126.0.6478.185', '126.0.6478.184', '126.0.6478.183', '126.0.6478.182', '126.0.6478.128', '126.0.6478.127', '126.0.6478.126', '126.0.6478.116', '126.0.6478.115', '126.0.6478.114', '126.0.6478.63', '126.0.6478.62', '126.0.6478.61', '126.0.6478.57', '126.0.6478.56', '126.0.6478.36'],
  125: ['125.0.6422.176', '125.0.6422.144', '125.0.6422.143', '125.0.6422.142', '125.0.6422.141', '125.0.6422.114', '125.0.6422.113', '125.0.6422.112', '125.0.6422.78', '125.0.6422.77', '125.0.6422.76', '125.0.6422.61', '125.0.6422.60', '125.0.6422.41'],
  124: ['124.0.6367.210', '124.0.6367.209', '124.0.6367.208', '124.0.6367.207', '124.0.6367.203', '124.0.6367.202', '124.0.6367.201', '124.0.6367.158', '124.0.6367.157', '124.0.6367.156', '124.0.6367.155', '124.0.6367.119', '124.0.6367.118', '124.0.6367.93', '124.0.6367.92', '124.0.6367.91', '124.0.6367.79', '124.0.6367.78', '124.0.6367.63', '124.0.6367.62', '124.0.6367.61', '124.0.6367.60'],
  123: ['123.0.6312.124', '123.0.6312.123', '123.0.6312.122', '123.0.6312.107', '123.0.6312.106', '123.0.6312.105', '123.0.6312.88', '123.0.6312.87', '123.0.6312.86', '123.0.6312.60', '123.0.6312.59', '123.0.6312.58', '123.0.6312.46'],
  122: ['122.0.6261.131', '122.0.6261.130', '122.0.6261.129', '122.0.6261.128', '122.0.6261.113', '122.0.6261.112', '122.0.6261.111', '122.0.6261.96', '122.0.6261.95', '122.0.6261.94', '122.0.6261.71', '122.0.6261.70', '122.0.6261.69', '122.0.6261.58', '122.0.6261.57', '122.0.6261.39'],
  121: ['121.0.6167.189', '121.0.6167.187', '121.0.6167.186', '121.0.6167.185', '121.0.6167.184', '121.0.6167.162', '121.0.6167.161', '121.0.6167.160', '121.0.6167.141', '121.0.6167.140', '121.0.6167.139', '121.0.6167.87', '121.0.6167.86', '121.0.6167.85', '121.0.6167.75'],
  120: ['120.0.6099.227', '120.0.6099.226', '120.0.6099.225', '120.0.6099.224', '120.0.6099.218', '120.0.6099.217', '120.0.6099.216', '120.0.6099.201', '120.0.6099.200', '120.0.6099.199', '120.0.6099.131', '120.0.6099.130', '120.0.6099.129', '120.0.6099.111', '120.0.6099.110', '120.0.6099.109', '120.0.6099.72', '120.0.6099.71', '120.0.6099.63', '120.0.6099.62', '120.0.6099.56'],
  119: ['119.0.6045.202', '119.0.6045.201', '119.0.6045.200', '119.0.6045.199', '119.0.6045.161', '119.0.6045.160', '119.0.6045.159', '119.0.6045.125', '119.0.6045.124', '119.0.6045.123', '119.0.6045.107', '119.0.6045.106', '119.0.6045.105', '119.0.6045.59'],
  118: ['118.0.5993.120', '118.0.5993.119', '118.0.5993.118', '118.0.5993.117', '118.0.5993.90', '118.0.5993.89', '118.0.5993.88', '118.0.5993.72', '118.0.5993.71', '118.0.5993.70', '118.0.5993.54'],
  117: ['117.0.5938.152', '117.0.5938.151', '117.0.5938.150', '117.0.5938.149', '117.0.5938.134', '117.0.5938.132', '117.0.5938.92', '117.0.5938.89', '117.0.5938.88', '117.0.5938.63', '117.0.5938.62', '117.0.5938.48'],
  116: ['116.0.5845.190', '116.0.5845.189', '116.0.5845.188', '116.0.5845.187', '116.0.5845.182', '116.0.5845.181', '116.0.5845.180', '116.0.5845.179', '116.0.5845.142', '116.0.5845.141', '116.0.5845.140', '116.0.5845.112', '116.0.5845.111', '116.0.5845.110', '116.0.5845.98', '116.0.5845.97', '116.0.5845.96', '116.0.5845.82'],
  115: ['115.0.5790.173', '115.0.5790.172', '115.0.5790.171', '115.0.5790.170', '115.0.5790.111', '115.0.5790.110', '115.0.5790.102', '115.0.5790.99', '115.0.5790.98', '115.0.5790.90'],
  114: ['114.0.5735.248', '114.0.5735.201', '114.0.5735.200', '114.0.5735.199', '114.0.5735.198', '114.0.5735.135', '114.0.5735.134', '114.0.5735.133', '114.0.5735.111', '114.0.5735.110', '114.0.5735.91', '114.0.5735.90', '114.0.5735.45'],
  113: ['113.0.5672.129', '113.0.5672.128', '113.0.5672.127', '113.0.5672.126', '113.0.5672.94', '113.0.5672.93', '113.0.5672.92', '113.0.5672.64', '113.0.5672.63'],
  112: ['112.0.5615.140', '112.0.5615.139', '112.0.5615.138', '112.0.5615.137', '112.0.5615.122', '112.0.5615.121', '112.0.5615.87', '112.0.5615.86', '112.0.5615.50', '112.0.5615.49'],
  111: ['111.0.5563.149', '111.0.5563.148', '111.0.5563.147', '111.0.5563.146', '111.0.5563.112', '111.0.5563.111', '111.0.5563.110', '111.0.5563.66', '111.0.5563.65', '111.0.5563.64', '111.0.5563.50'],
  110: ['110.0.5481.180', '110.0.5481.179', '110.0.5481.178', '110.0.5481.177', '110.0.5481.105', '110.0.5481.104', '110.0.5481.100', '110.0.5481.97', '110.0.5481.96', '110.0.5481.78', '110.0.5481.77'],
  109: ['109.0.5414.122', '109.0.5414.121', '109.0.5414.120', '109.0.5414.119', '109.0.5414.76', '109.0.5414.75', '109.0.5414.74'],
  108: ['108.0.5359.126', '108.0.5359.125', '108.0.5359.124', '108.0.5359.100', '108.0.5359.99', '108.0.5359.98', '108.0.5359.96', '108.0.5359.95', '108.0.5359.94', '108.0.5359.73', '108.0.5359.72', '108.0.5359.71'],
  107: ['107.0.5304.123', '107.0.5304.122', '107.0.5304.121', '107.0.5304.108', '107.0.5304.107', '107.0.5304.106', '107.0.5304.89', '107.0.5304.88', '107.0.5304.87', '107.0.5304.63', '107.0.5304.62'],
  106: ['106.0.5249.121', '106.0.5249.120', '106.0.5249.119', '106.0.5249.103', '106.0.5249.91', '106.0.5249.62', '106.0.5249.61'],
  105: ['105.0.5195.128', '105.0.5195.127', '105.0.5195.126', '105.0.5195.125', '105.0.5195.102', '105.0.5195.54', '105.0.5195.53', '105.0.5195.52'],
  104: ['104.0.5112.102', '104.0.5112.101', '104.0.5112.82', '104.0.5112.81', '104.0.5112.80', '104.0.5112.79'],
  103: ['103.0.5060.134', '103.0.5060.114', '103.0.5060.66', '103.0.5060.53'],
  102: ['102.0.5005.115', '102.0.5005.63', '102.0.5005.62', '102.0.5005.61'],
  101: ['101.0.4951.67', '101.0.4951.64', '101.0.4951.54', '101.0.4951.41'],
  100: ['100.0.4896.127', '100.0.4896.88', '100.0.4896.75', '100.0.4896.60'],
  99: ['99.0.4844.84', '99.0.4844.82', '99.0.4844.74', '99.0.4844.51'],
  98: ['98.0.4758.102', '98.0.4758.82', '98.0.4758.81'],
  97: ['97.0.4692.99', '97.0.4692.71'],
  96: ['96.0.4664.110', '96.0.4664.93', '96.0.4664.45'],
  95: ['95.0.4638.69', '95.0.4638.54'],
  94: ['94.0.4606.81', '94.0.4606.71', '94.0.4606.61', '94.0.4606.54'],
  93: ['93.0.4577.82', '93.0.4577.63'],
  92: ['92.0.4515.159', '92.0.4515.131', '92.0.4515.107'],
  91: ['91.0.4472.164', '91.0.4472.124', '91.0.4472.123', '91.0.4472.114', '91.0.4472.106', '91.0.4472.101', '91.0.4472.77'],
  90: ['90.0.4430.212', '90.0.4430.93', '90.0.4430.85', '90.0.4430.72'],
  89: ['89.0.4389.128', '89.0.4389.114', '89.0.4389.90', '89.0.4389.82', '89.0.4389.72'],
  88: ['88.0.4324.190', '88.0.4324.182', '88.0.4324.150', '88.0.4324.146', '88.0.4324.104', '88.0.4324.96'],
};

// NẠP THÊM bản THẬT đọc được từ nhân ĐÃ CÀI trên máy vào bảng trên.
//
// LÝ DO TỒN TẠI: bảng CHROME_BUILDS là ảnh chụp tại thời điểm phát hành app. Khi server
// đẩy nhân MỚI HƠN (vd 151) thì major đó KHÔNG có trong bảng → dropdown "User-Agent"
// không liệt kê 151 và randomChromeFull(151) trả rỗng. Sửa bằng cách gõ tay số build
// 151 vào source là SAI HƯỚNG (mỗi lần Chrome lên bản lại phải phát hành app mới).
//
// KHÔNG BỊA SỐ: chỉ nhận full-version ĐỌC ĐƯỢC TỪ BINARY thật trên máy (kernel-manager
// bóc từ file "<full>.manifest" đi kèm mỗi bản Chromium). Bịa số patch = build không
// tồn tại = tự lộ diện với detector, nên thà thiếu còn hơn bịa.
//
// Trả true nếu chuỗi hợp lệ dạng x.y.z.w.
export function registerKernelBuild(fullVersion) {
  const v = String(fullVersion || '').trim();
  const m = v.match(/^(\d+)\.\d+\.\d+\.\d+$/);
  if (!m) return false;
  const major = parseInt(m[1], 10);
  if (!CHROME_BUILDS[major]) CHROME_BUILDS[major] = [];
  // Đặt LÊN ĐẦU: đây là build ta CHẮC CHẮN có thật (đang nằm trên đĩa), nên nó cũng là
  // lựa chọn dự phòng tốt nhất cho chromeFullFromUa (vốn lấy phần tử [0]).
  if (!CHROME_BUILDS[major].includes(v)) CHROME_BUILDS[major].unshift(v);
  return true;
}

// Danh sách major (giảm dần) cho dropdown "User-Agent". PHẢI là HÀM chứ không phải mảng
// hằng: registerKernelBuild() có thể thêm major mới (nhân 151 tải về sau) SAU khi module
// đã được nạp - một mảng chụp lúc import sẽ vĩnh viễn thiếu bản mới.
export function chromeMajors() {
  return Object.keys(CHROME_BUILDS).map(Number).sort((a, b) => b - a);
}

// Random một full-version THẬT trong dải của major (rỗng nếu major không có).
// Gọi ở ô "User-Agent" mỗi khi chọn major / bấm "Tạo lại" / "Tạo vân tay mới".
export function randomChromeFull(major) {
  const arr = CHROME_BUILDS[parseInt(major, 10)];
  if (!arr || !arr.length) return '';
  return arr[Math.floor(Math.random() * arr.length)];
}

// ---- Major Firefox cho dropdown "User-Agent" ---------------------------
// VÌ SAO KHÔNG CÓ BẢNG BUILD KIỂU CHROME_BUILDS: UA Firefox desktop ĐÓNG BĂNG phiên bản
// ở dạng "<major>.0" - bản 152.0.6 vẫn tự báo "Firefox/152.0" (cả token rv:). Số patch
// KHÔNG BAO GIỜ lọt vào UA, nên liệt kê MAJOR là đã ĐẦY ĐỦ và ĐÚNG; chép thêm bảng patch
// chỉ là dữ liệu chết. (Chromium ngược lại: UA phát đủ 4 số ⇒ bắt buộc phải có bảng.)
//
// KHÔNG BỊA SỐ - vẫn giữ đúng nguyên tắc của CHROME_BUILDS. Firefox đánh major LIÊN TỤC,
// chưa từng bỏ số nào (khác Chrome từng bỏ 82), nên dải liên tục là danh sách THẬT chứ
// không phải suy đoán:
//   • Mốc DƯỚI 85 = Firefox 85 (26/01/2021) - CÙNG THỜI KỲ với Chrome 88, mốc dưới của
//     CHROME_BUILDS. Nhờ vậy hai engine trưng danh sách dài tương đương, cùng một thời kỳ
//     (Chromium 88..150 = 63 mục; Firefox 85..152 = 68 mục).
//   • Mốc TRÊN không hardcode vĩnh viễn: 152 chỉ là ẢNH CHỤP lúc phát hành, đọc từ nhân
//     THẬT đóng gói kèm app (vendor/gecko/application.ini → Version=152.0.6). Nhân mới
//     tải về sau sẽ tự NỚI mốc này qua registerFirefoxBuild() - không phải phát hành app
//     mới, đúng như cách Chromium làm.
const FIREFOX_MAJOR_MIN = 85;
let FIREFOX_MAJOR_MAX = 152;

// Nới mốc trên bằng major ĐỌC ĐƯỢC TỪ NHÂN THẬT. CHỈ NỚI LÊN, không bao giờ hạ xuống:
// người dùng quay về dùng nhân cũ thì các major mới đã biết vẫn phải còn trong dropdown.
// Trả true nếu chuỗi phiên bản hợp lệ (dạng "152" / "152.0" / "152.0.6").
export function registerFirefoxBuild(version) {
  const m = String(version || '').trim().match(/^(\d+)(?:\.\d+)*$/);
  if (!m) return false;
  const major = parseInt(m[1], 10);
  if (major > FIREFOX_MAJOR_MAX) FIREFOX_MAJOR_MAX = major;
  return true;
}

// Danh sách major Firefox (giảm dần). Là HÀM chứ không phải mảng hằng - CÙNG LÝ DO với
// chromeMajors(): mốc trên có thể đổi SAU khi module đã nạp (registerFirefoxBuild).
export function firefoxMajors() {
  const out = [];
  for (let v = FIREFOX_MAJOR_MAX; v >= FIREFOX_MAJOR_MIN; v--) out.push(v);
  return out;
}

// ---- User Agent --------------------------------------------------------
// UA theo (kernel, os, osVersion). Chromium-based mặc định; nhánh Firefox dự phòng.
// Token OS-version trong UA:
//   • Desktop (Windows/macOS/Linux): Chrome thật ĐÓNG BĂNG token này
//     (Windows luôn "NT 10.0", Mac luôn "10_15_7") → giữ cố định, KHÔNG theo
//     osVersion (làm khác đi mới là dấu hiệu antidetect).
//   • Mobile (Android/iOS): Chrome/Safari thật báo ĐÚNG phiên bản OS → token này
//     phải bám theo osVersion đã chọn để nhất quán.
// Lấy số phiên bản từ chuỗi hiển thị, vd "Android 14" → "14", "iOS 17" → "17".
const verNum = (osVersion, fallback) => { const m = String(osVersion || '').match(/(\d+)/); return m ? m[1] : fallback; };
export function uaString(kernel, os, osVersion, chromeFull) {
  // chromeFull rỗng/'' (= "Tất cả") → dùng version kernel thật (an toàn nhất).
  // Có giá trị → full-version THẬT đã chọn/đổ ngẫu nhiên ở ô "User-Agent"
  // (randomChromeFull). Việc random nằm ở view để chuỗi UA ổn định giữa các lần
  // render, chỉ đổi khi người dùng chủ động "Tạo lại"/"Tạo vân tay mới".
  const v = chromeFull || CHROME_VERSION;
  // Firefox ĐÓNG BĂNG số phiên bản trong UA ở dạng "<major>.0" - bản vá 152.0.6 vẫn tự
  // báo là 152.0 (cả token rv: lẫn Firefox/). Nhét nguyên full-version vào UA là dấu
  // hiệu antidetect lộ ngay, nên luôn rút về major.
  //
  // Tham số thứ 4 là phiên bản của NHÂN ĐANG CHỌN trên form (view chịu trách nhiệm
  // truyền đúng engine - Chrome "140.0.7339.264", Firefox "152.0.6"). Có thì ưu tiên để
  // đổi nhân trên thẻ "Trình duyệt" là UA đổi theo; không có mới lùi về nhân đang active.
  const fx = `${String(chromeFull || FIREFOX_VERSION).split('.')[0]}.0`;
  // ---- Firefox: MỖI OS một dạng UA riêng, không được rơi nhầm sang dạng của OS khác ----
  // Hai token phân biệt Firefox desktop với Firefox mobile - sai một cái là lộ ngay:
  //   • Gecko/20100101 : desktop (Windows/macOS/Linux) dùng chuỗi NGÀY cố định này.
  //   • Gecko/<ver>    : Android dùng SỐ PHIÊN BẢN, không phải chuỗi ngày.
  if (kernel === 'Firefox') {
    // Android: phiên bản OS THỰC SỰ vào UA (giống nhánh Chromium) → bám osVersion đã chọn.
    if (os === 'Android') return `Mozilla/5.0 (Android ${verNum(osVersion, '13')}; Mobile; rv:${fx}) Gecko/${fx} Firefox/${fx}`;
    // iOS: KHÔNG có Gecko trên iOS - Apple bắt mọi trình duyệt dùng WebKit, nên Firefox iOS
    // là WebKit + token riêng "FxiOS/" (đối xứng với "CriOS/" của Chrome iOS ở dưới).
    //
    // TRƯỚC ĐÂY nhánh Firefox KHÔNG có case iOS nên rơi thẳng xuống return cuối = UA
    // WINDOWS: hồ sơ chọn iOS lại khai "Windows NT 10.0 … Gecko/20100101" - vừa sai OS,
    // vừa khai Gecko trên một nền tảng không thể có Gecko. Lỗi nặng nhất trong nhóm này.
    //
    // Khác Chrome iOS ở đuôi: FxiOS đi với Safari/605.1.15 (không phải Safari/604.1).
    // AppleWebKit/605.1.15 + Mobile/15E148 là token WebKit chung của mọi trình duyệt iOS.
    if (os === 'iOS') return `Mozilla/5.0 (iPhone; CPU iPhone OS ${verNum(osVersion, '16')}_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) FxiOS/${fx} Mobile/15E148 Safari/605.1.15`;
    if (os === 'Linux') return `Mozilla/5.0 (X11; Linux x86_64; rv:${fx}) Gecko/20100101 Firefox/${fx}`;
    // macOS: Firefox ĐÓNG BĂNG token này ở "10.15" (bản 26/15/14… đều báo 10.15) - báo số
    // thật mới là dấu hiệu antidetect. Lưu ý viết CHẤM "10.15", khác Chrome dùng gạch dưới
    // "10_15_7"; chép nhầm dấu của engine kia là lộ.
    if (os === 'macOS') return `Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:${fx}) Gecko/20100101 Firefox/${fx}`;
    // Windows: LUÔN "NT 10.0", KHÔNG bám osVersion - cùng cách nhánh Chromium làm, nhưng
    // ở đây còn có lý do mạnh hơn: Firefox hiện đại KHÔNG CHẠY ĐƯỢC trên Win 7/8 (hỗ trợ
    // dừng ở ESR 115). Cặp "NT 6.1 + rv:152.0" là tổ hợp BẤT KHẢ THI, tự tố cáo còn nặng
    // hơn việc hồ sơ ghi nhãn Win 7 mà UA nói NT 10.0.
    return `Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:${fx}) Gecko/20100101 Firefox/${fx}`;
  }
  if (os === 'macOS') return `Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${v} Safari/537.36`;
  if (os === 'Linux') return `Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${v} Safari/537.36`;
  if (os === 'Android') return `Mozilla/5.0 (Linux; Android ${verNum(osVersion, '13')}; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${v} Mobile Safari/537.36`;
  // Chrome trên iOS = CriOS/<Chrome revision> thay cho Version/<n> của Safari (mọi trình
  // duyệt iOS chạy WebKit nên chỉ khác token này). Ở ĐÂY phát full revision; buildUaMeta
  // rút gọn CriOS về major.0.0.0 (Chrome iOS hiện đại CŨNG áp UA-Reduction - UA thật 7/2026:
  // "CriOS/150.0.0.0"). Mobile/15E148 là build token iOS cố định phổ biến. Nhân (WebKit-mode)
  // tự lo phần engine/userAgentData cho iOS.
  if (os === 'iOS') { const iv = verNum(osVersion, '16'); return `Mozilla/5.0 (iPhone; CPU iPhone OS ${iv}_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/${v} Mobile/15E148 Safari/604.1`; }
  return `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${v} Safari/537.36`;
}

// ---- Map OS hiển thị (client) → enum server ----------------------------
export const osToEnum = (os) => ({ Windows: 'windows', macOS: 'macos', Mac: 'macos', Linux: 'linux', Android: 'android', iOS: 'ios' }[os] || 'windows');

// ---- Pool LẤY TỪ SERVER (GPU/WebGL + fonts) ----------------------------
// Theo yêu cầu: GPU/WebGL và Fonts là dữ liệu server (bảng fp_gpus/fp_fonts),
// các trường khác client tự random. profile_create.js fetch qua
// remote.fingerprintPools(osEnum) rồi nạp vào đây bằng setPools(). Khi CHƯA nạp
// được (offline/đang tải) thì fall back về pool built-in OS_GPU / FALLBACK_FONTS.
const _gpuPools = {};   // { [clientOs]: [{vendor, renderer}] }
const _fontSets = {};   // { [clientOs]: [font, ...] }

// Nạp pool server cho 1 OS. pools = { gpus:[{vendor,renderer}], fonts:[{label,fonts:[]}] }.
export function setPools(clientOs, pools) {
  const p = pools || {};
  if (Array.isArray(p.gpus) && p.gpus.length) _gpuPools[clientOs] = p.gpus;
  // fonts server trả mảng "bộ font"; lấy bộ đầu (trọng số cao nhất).
  if (Array.isArray(p.fonts) && p.fonts.length && Array.isArray(p.fonts[0].fonts)) _fontSets[clientOs] = p.fonts[0].fonts;
}

// Nạp TOÀN BỘ catalog (5 OS) trong 1 lần - server trả keyed theo enum os.
// Sau khi gọi, mọi OS đều có pool trong RAM → đổi OS sau đó không cần fetch.
const ENUM_TO_CLIENT = { windows: 'Windows', macos: 'macOS', linux: 'Linux', android: 'Android', ios: 'iOS' };
export function setAllPools(catalog) {
  if (!catalog) return;
  for (const [enumOs, clientOs] of Object.entries(ENUM_TO_CLIENT)) {
    if (catalog[enumOs]) setPools(clientOs, catalog[enumOs]);
  }
}

// Đã có pool server cho OS này chưa.
export const hasPools = (clientOs) => !!_gpuPools[clientOs];

// ---- WebGL metadata (vendor + ANGLE renderer), khớp theo OS ------------
// Ghép một renderer macOS Metal với UA Windows (hoặc ngược lại) là dấu hiệu
// antidetect lớn nhất → vendor/renderer LUÔN bám theo OS đang chọn.
// OS_GPU dưới đây chỉ là FALLBACK khi pool server chưa nạp được.
export const OS_GPU = {
  Windows: [
    { vendor: 'Google Inc. (Intel)', renderer: 'ANGLE (Intel, Intel(R) UHD Graphics 630 Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    { vendor: 'Google Inc. (AMD)', renderer: 'ANGLE (AMD, AMD Radeon RX 6600 Direct3D11 vs_5_0 ps_5_0, D3D11)' },
  ],
  macOS: [
    { vendor: 'Google Inc. (Apple)', renderer: 'ANGLE (Apple, ANGLE Metal Renderer: Apple M1, Unspecified Version)' },
    { vendor: 'Google Inc. (Apple)', renderer: 'ANGLE (Apple, ANGLE Metal Renderer: Apple M2, Unspecified Version)' },
  ],
  Linux: [
    { vendor: 'Google Inc. (Intel)', renderer: 'ANGLE (Intel, Mesa Intel(R) UHD Graphics 630 (CFL GT2), OpenGL 4.6 (Core Profile) Mesa 23.2.1-1ubuntu3)' },
    { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA Corporation, NVIDIA GeForce RTX 3060/PCIe/SSE2, OpenGL 4.6.0 NVIDIA 535.146.02)' },
  ],
  Android: [
    { vendor: 'Google Inc. (Qualcomm)', renderer: 'ANGLE (Qualcomm, Adreno (TM) 730, OpenGL ES 3.2)' },
    { vendor: 'Google Inc. (ARM)', renderer: 'ANGLE (ARM, Mali-G78 MP14, OpenGL ES 3.2)' },
  ],
  iOS: [
    { vendor: 'Apple Inc.', renderer: 'Apple GPU' },
  ],
};

// Danh sách vendor cho dropdown WebGL - PHẢI phủ hết mọi chuỗi vendor mà pool
// server (fp_gpus) sinh ra, nếu không customSelect không tìm thấy option khớp và
// hiển thị TRỐNG (vd macOS "ATI Technologies Inc."/"Intel Inc.", Linux "NVIDIA
// Corporation", Android "Samsung..."). Tất cả là giá trị THẬT lấy từ fp_gpus.
export const WEBGL_VENDORS = ['Google Inc. (Apple)', 'Google Inc. (Intel)', 'Google Inc. (NVIDIA)', 'Google Inc. (AMD)', 'Apple Inc.', 'Google Inc. (Qualcomm)', 'Google Inc. (ARM)', 'Google Inc. (ATI Technologies Inc.)', 'Google Inc. (Intel Inc.)', 'Google Inc. (NVIDIA Corporation)', 'Google Inc. (Samsung Electronics Co. Ltd.)'];

// Rút ngẫu nhiên 1 cặp {vendor, renderer} - ưu tiên pool SERVER, thiếu thì FALLBACK.
export function osGpu(os) {
  const pool = (_gpuPools[os] && _gpuPools[os].length) ? _gpuPools[os] : (OS_GPU[os] || OS_GPU.Windows);
  return pool[Math.floor(Math.random() * pool.length)];
}

// Bộ font cho OS - ưu tiên pool SERVER, thiếu thì FALLBACK tối thiểu.
const FALLBACK_FONTS = {
  Windows: ['Arial', 'Calibri', 'Consolas', 'Segoe UI', 'Tahoma', 'Times New Roman', 'Verdana'],
  macOS: ['Helvetica', 'Helvetica Neue', 'Menlo', 'Monaco', 'San Francisco', 'Times'],
  Linux: ['DejaVu Sans', 'Liberation Sans', 'Noto Sans', 'Ubuntu'],
  Android: ['Roboto', 'Noto Sans', 'Droid Sans'],
  iOS: ['Helvetica', 'Helvetica Neue', 'San Francisco', 'Arial'],
};
export function osFonts(os) {
  return (_fontSets[os] && _fontSets[os].length) ? _fontSets[os] : (FALLBACK_FONTS[os] || FALLBACK_FONTS.Windows);
}

// ---- Thiết bị truyền thông (camera + mic) khớp theo OS -----------------
// Label thiết bị PHẢI nhất quán với OS: "FaceTime HD Camera" chỉ có trên macOS,
// "Microphone (High Definition Audio Device)" là chuỗi Windows điển hình. Ghép
// chéo (vd camera macOS dưới UA Windows) là dấu hiệu antidetect → luôn bám OS.
// Số phần tử cameraLabels/micLabels = số máy quảng bá (audio_inputs/video_inputs).
// Giá trị THẬT, quan sát trên thiết bị tương ứng (không bịa device-id).
export const OS_MEDIA = {
  Windows: { cameraLabels: ['Integrated Webcam'],        micLabels: ['Microphone (High Definition Audio Device)'] },
  macOS:   { cameraLabels: ['FaceTime HD Camera'],       micLabels: ['MacBook Pro Microphone'] },
  Linux:   { cameraLabels: ['Integrated Camera'],        micLabels: ['Built-in Audio Analog Stereo'] },
  Android: { cameraLabels: ['camera2 1, facing front'],  micLabels: ['Default'] },
  iOS:     { cameraLabels: ['Front Camera'],             micLabels: ['iPhone Microphone'] },
};
export function osMediaLabels(os) { return OS_MEDIA[os] || OS_MEDIA.Windows; }

// ---- SpeechVoices (getVoices whitelist) khớp theo OS -------------------
// Bộ giọng đọc lộ qua speechSynthesis.getVoices() đặc trưng theo OS:
//  - Windows: giọng SAPI "Microsoft David/Zira/Mark - English (United States)".
//  - macOS/iOS: giọng Apple ("Samantha", "Alex"...).
//  - Linux/Android: chủ yếu là giọng Google do Chrome cấp ("Google US English"...).
// Whitelist = CHỈ expose các giọng này ở getVoices → đồng nhất theo OS, tránh lộ
// danh sách giọng không khớp nền tảng. Giá trị THẬT quan sát trên từng OS.
export const OS_VOICES = {
  Windows: ['Microsoft David - English (United States)', 'Microsoft Zira - English (United States)', 'Microsoft Mark - English (United States)'],
  macOS:   ['Samantha', 'Alex', 'Victoria'],
  Linux:   ['Google US English', 'Google UK English Female', 'Google UK English Male'],
  Android: ['Google US English', 'Google UK English Female', 'Google UK English Male'],
  iOS:     ['Samantha', 'Daniel', 'Karen'],
};
export function osVoices(os) { return OS_VOICES[os] || OS_VOICES.Windows; }

// ---- Phần cứng (CPU cores / RAM) khớp theo OS + HẠNG GPU ----------------
// hardwareConcurrency và deviceMemory phải nhất quán theo HAI trục:
//  (1) OS - iPhone/Android không báo số nhân & RAM kiểu desktop.
//  (2) GPU - card tích hợp (Intel UHD/Iris, APU Radeon Graphics) chỉ đi với 4-8
//      nhân / 8-16 GB; card rời tầm trung (RTX 3060, RX 6600) đi 6-12 nhân / 8-16
//      GB; card cao cấp (RTX 4080, RX 7900) mới đi 12-24 nhân / 16-64 GB. Ghép
//      card yếu với 32 nhân/128 GB là cấu hình phi lý → dễ bị nghi.
// Mọi giá trị thuộc tập option của select (CPU 3..64, RAM 2..128). RAM hiển thị có
// thể >8 nhưng navigator.deviceMemory luôn bị quy về luỹ thừa 2 ≤ 8 (xem
// quantizeDeviceMemory) - phần này chỉ lo độ HỢP LÝ của cấu hình hiển thị.

// Phân hạng GPU desktop từ chuỗi renderer ANGLE → 'low' | 'mid' | 'high'.
function gpuTier(renderer) {
  const r = String(renderer || '');
  // GPU tích hợp / phần mềm / đồ hoạ APU → hạng thấp
  if (/UHD Graphics|HD Graphics| Iris|Microsoft Basic|llvmpipe|SwiftShader|Radeon\(TM\) Graphics|Radeon Vega|Vega \d/i.test(r)) return 'low';
  // NVIDIA GeForce: hai chữ số cuối (x0) cho biết phân khúc - 70/80/90 = cao cấp.
  let m = r.match(/(?:RTX|GTX)\s*(\d{2,4})/i);
  if (m) return (+m[1].slice(-2) >= 70) ? 'high' : 'mid';
  // AMD Radeon RX 4 chữ số: chữ số hàng trăm (vd 6[7]00) ≥ 7 = cao cấp.
  m = r.match(/RX\s*(\d{4})/i);
  if (m) return (+m[1][1] >= 7) ? 'high' : 'mid';
  // GPU rời khác / không nhận dạng được → hạng trung.
  return 'mid';
}

// Cấu hình phần cứng desktop theo hạng GPU (giá trị thuộc tập option của select).
const DESKTOP_HW = {
  low:  { cpu: [4, 6, 8],        ram: [8, 8, 16] },
  mid:  { cpu: [6, 8, 10, 12],   ram: [8, 16, 16] },
  high: { cpu: [12, 16, 20, 24], ram: [16, 32, 64] },
};
// Sinh CPU/RAM nhất quán với OS và (trên desktop) với hạng GPU của renderer.
export function osHardware(os, renderer) {
  const pick = (a) => a[Math.floor(Math.random() * a.length)];
  if (os === 'iOS')     return { cpu: 6, ram: 4 };
  if (os === 'Android') return { cpu: 8, ram: pick([8, 4]) };
  if (os === 'macOS') {
    // Apple Silicon: chỉ bản Pro/Max/Ultra mới nhiều nhân & RAM lớn.
    const big = /M\d+\s*(Pro|Max|Ultra)/i.test(String(renderer || ''));
    return big ? { cpu: pick([10, 12]), ram: pick([16, 32]) }
               : { cpu: 8, ram: pick([8, 16]) };
  }
  const h = DESKTOP_HW[gpuTier(renderer)] || DESKTOP_HW.mid;
  return { cpu: pick(h.cpu), ram: pick(h.ram) };
}
// navigator.deviceMemory chỉ nhận luỹ thừa 2 và bị Chrome chặn trần ở 8 GiB. UI cho
// chọn 2/4/6/8/16/32/64/128 GB (khớp AdsPower) nhưng giá trị xuất ra fp-config phải
// là luỹ thừa 2 hợp lệ gần nhất ≤ 8 - vd 6 GB → 8, 16/32/64/128 → 8.
function quantizeDeviceMemory(gb) {
  const capped = Math.min(8, Number(gb) || 8);
  const valid = [1, 2, 4, 8];
  let best = valid[0];
  for (const v of valid) {
    if (Math.abs(v - capped) <= Math.abs(best - capped)) best = v;
  }
  return best;
}

// ---- Tên máy / MAC -----------------------------------------------------
// Tên máy nhất quán theo OS ("DESKTOP-XXXX" chỉ hợp lý trên Windows).
export function osDeviceName(os) {
  const rnd = (n, set) => Array.from({ length: n }, () => set[Math.floor(Math.random() * set.length)]).join('');
  const UP = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  const LO = 'abcdefghijklmnopqrstuvwxyz0123456789';
  if (os === 'macOS') return ['MacBook-Pro', 'MacBook-Air', 'iMac', 'Mac-mini'][Math.floor(Math.random() * 4)] + '-' + rnd(4, UP);
  if (os === 'Linux') return 'ubuntu-' + rnd(6, LO);
  if (os === 'Android') return ['Pixel-7', 'SM-G991B', 'Mi-11'][Math.floor(Math.random() * 3)];
  if (os === 'iOS') return 'iPhone';
  return 'DESKTOP-' + rnd(7, UP);
}

export function randMac() {
  const h = () => Math.floor(Math.random() * 256).toString(16).toUpperCase().padStart(2, '0');
  return [h(), h(), h(), h(), h(), h()].join('-');
}

// Tên máy mặc định kiểu Windows (dùng cho giá trị khởi tạo form).
export function randDevice() {
  const s = Array.from({ length: 7 }, () => 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'[Math.floor(Math.random() * 36)]).join('');
  return 'DESKTOP-' + s;
}

// Danh sách múi giờ IANA THẬT (kèm nhãn offset GMT) cho ô "Múi giờ → Tùy chỉnh".
// Tên zone là IANA chuẩn, KHÔNG bịa - value đi thẳng vào fp-config cfg.timezone.
export const TIMEZONES = [
  { value: 'Pacific/Midway', label: '(GMT-11:00) Pacific/Midway' },
  { value: 'Pacific/Honolulu', label: '(GMT-10:00) Pacific/Honolulu' },
  { value: 'America/Anchorage', label: '(GMT-09:00) America/Anchorage' },
  { value: 'America/Los_Angeles', label: '(GMT-08:00) America/Los_Angeles' },
  { value: 'America/Denver', label: '(GMT-07:00) America/Denver' },
  { value: 'America/Chicago', label: '(GMT-06:00) America/Chicago' },
  { value: 'America/New_York', label: '(GMT-05:00) America/New_York' },
  { value: 'America/Halifax', label: '(GMT-04:00) America/Halifax' },
  { value: 'America/Sao_Paulo', label: '(GMT-03:00) America/Sao_Paulo' },
  { value: 'Atlantic/Azores', label: '(GMT-01:00) Atlantic/Azores' },
  { value: 'Etc/UTC', label: '(GMT+00:00) UTC' },
  { value: 'Europe/London', label: '(GMT+00:00) Europe/London' },
  { value: 'Europe/Paris', label: '(GMT+01:00) Europe/Paris' },
  { value: 'Europe/Athens', label: '(GMT+02:00) Europe/Athens' },
  { value: 'Europe/Moscow', label: '(GMT+03:00) Europe/Moscow' },
  { value: 'Asia/Dubai', label: '(GMT+04:00) Asia/Dubai' },
  { value: 'Asia/Karachi', label: '(GMT+05:00) Asia/Karachi' },
  { value: 'Asia/Kolkata', label: '(GMT+05:30) Asia/Kolkata' },
  { value: 'Asia/Dhaka', label: '(GMT+06:00) Asia/Dhaka' },
  { value: 'Asia/Bangkok', label: '(GMT+07:00) Asia/Bangkok' },
  { value: 'Asia/Ho_Chi_Minh', label: '(GMT+07:00) Asia/Ho_Chi_Minh' },
  { value: 'Asia/Shanghai', label: '(GMT+08:00) Asia/Shanghai' },
  { value: 'Asia/Singapore', label: '(GMT+08:00) Asia/Singapore' },
  { value: 'Asia/Tokyo', label: '(GMT+09:00) Asia/Tokyo' },
  { value: 'Asia/Seoul', label: '(GMT+09:00) Asia/Seoul' },
  { value: 'Australia/Sydney', label: '(GMT+10:00) Australia/Sydney' },
  { value: 'Pacific/Auckland', label: '(GMT+12:00) Pacific/Auckland' },
];

// "Độ phân giải → Được xác định trước": danh sách preset khớp 1:1 với AdsPower.
// Phần tử đầu 'Dựa trên User-Agent' nghĩa là KHÔNG ghi đè screen (browser tự suy từ UA);
// các giá trị 'W x H' dùng ' x ' để buildFpConfig parse được qua /(\d+)\s*x\s*(\d+)/i.
export const RESOLUTIONS = [
  'Dựa trên User-Agent',
  '750 x 1334', '800 x 600', '1024 x 600', '1024 x 640', '1024 x 768',
  '1152 x 864', '1280 x 720', '1280 x 800', '1280 x 960', '1280 x 1024',
  '1360 x 768', '808 x 1792', '828 x 1792', '1080 x 2340', '1125 x 2436',
  '1170 x 2532', '1284 x 2778', '1366 x 768', '1400 x 1050', '1400 x 900',
  '1440 x 900', '1536 x 864', '1600 x 900', '1600 x 1200', '1680 x 1050',
  '1920 x 1080', '1920 x 1200', '2048 x 1152', '2304 x 1440', '2560 x 1440',
  '2560 x 1600', '2880 x 1800', '4096 x 2304', '5120 x 2880',
];

// Locale BCP-47 THẬT cho "Ngôn ngữ → Tùy chỉnh" (Accept-Language) và "Ngôn ngữ
// hiển thị → Tùy chỉnh". value = mã chuẩn, đi vào cfg.locale / navigator.languages.
// Verified-real BCP-47 locale codes with native-language labels (AdsPower-style:
// native name on the left, the code surfaced on the right by the display-language combobox).
export const LOCALES = [
  { value: 'af', label: 'Afrikaans' },
  { value: 'am', label: 'አማርኛ' },
  { value: 'ar', label: 'العربية' },
  { value: 'az', label: 'Azərbaycan' },
  { value: 'be', label: 'Беларуская' },
  { value: 'bg', label: 'Български' },
  { value: 'bn', label: 'বাংলা' },
  { value: 'bs', label: 'Bosanski' },
  { value: 'ca', label: 'Català' },
  { value: 'cs', label: 'Čeština' },
  { value: 'cy', label: 'Cymraeg' },
  { value: 'da', label: 'Dansk' },
  { value: 'de', label: 'Deutsch' },
  { value: 'de-AT', label: 'Deutsch (Österreich)' },
  { value: 'de-CH', label: 'Deutsch (Schweiz)' },
  { value: 'el', label: 'Ελληνικά' },
  { value: 'en', label: 'English' },
  { value: 'en-AU', label: 'English (Australia)' },
  { value: 'en-CA', label: 'English (Canada)' },
  { value: 'en-GB', label: 'English (United Kingdom)' },
  { value: 'en-IN', label: 'English (India)' },
  { value: 'en-US', label: 'English (United States)' },
  { value: 'es', label: 'Español' },
  { value: 'es-419', label: 'Español (Latinoamérica)' },
  { value: 'es-AR', label: 'Español (Argentina)' },
  { value: 'es-ES', label: 'Español (España)' },
  { value: 'es-MX', label: 'Español (México)' },
  { value: 'et', label: 'Eesti' },
  { value: 'eu', label: 'Euskara' },
  { value: 'fa', label: 'فارسی' },
  { value: 'fi', label: 'Suomi' },
  { value: 'fil', label: 'Filipino' },
  { value: 'fr', label: 'Français' },
  { value: 'fr-CA', label: 'Français (Canada)' },
  { value: 'ga', label: 'Gaeilge' },
  { value: 'gl', label: 'Galego' },
  { value: 'gu', label: 'ગુજરાતી' },
  { value: 'he', label: 'עברית' },
  { value: 'hi', label: 'हिन्दी' },
  { value: 'hr', label: 'Hrvatski' },
  { value: 'hu', label: 'Magyar' },
  { value: 'hy', label: 'Հայերեն' },
  { value: 'id', label: 'Bahasa Indonesia' },
  { value: 'is', label: 'Íslenska' },
  { value: 'it', label: 'Italiano' },
  { value: 'ja', label: '日本語' },
  { value: 'ka', label: 'ქართული' },
  { value: 'kk', label: 'Қазақ' },
  { value: 'km', label: 'ខ្មែរ' },
  { value: 'kn', label: 'ಕನ್ನಡ' },
  { value: 'ko', label: '한국어' },
  { value: 'ky', label: 'Кыргызча' },
  { value: 'lo', label: 'ລາວ' },
  { value: 'lt', label: 'Lietuvių' },
  { value: 'lv', label: 'Latviešu' },
  { value: 'mk', label: 'Македонски' },
  { value: 'ml', label: 'മലയാളം' },
  { value: 'mn', label: 'Монгол' },
  { value: 'mr', label: 'मराठी' },
  { value: 'ms', label: 'Bahasa Melayu' },
  { value: 'my', label: 'မြန်မာ' },
  { value: 'nb', label: 'Norsk bokmål' },
  { value: 'ne', label: 'नेपाली' },
  { value: 'nl', label: 'Nederlands' },
  { value: 'pa', label: 'ਪੰਜਾਬੀ' },
  { value: 'pl', label: 'Polski' },
  { value: 'pt', label: 'Português' },
  { value: 'pt-BR', label: 'Português (Brasil)' },
  { value: 'pt-PT', label: 'Português (Portugal)' },
  { value: 'ro', label: 'Română' },
  { value: 'ru', label: 'Русский' },
  { value: 'si', label: 'සිංහල' },
  { value: 'sk', label: 'Slovenčina' },
  { value: 'sl', label: 'Slovenščina' },
  { value: 'sq', label: 'Shqip' },
  { value: 'sr', label: 'Српски' },
  { value: 'sv', label: 'Svenska' },
  { value: 'sw', label: 'Kiswahili' },
  { value: 'ta', label: 'தமிழ்' },
  { value: 'te', label: 'తెలుగు' },
  { value: 'th', label: 'ไทย' },
  { value: 'tr', label: 'Türkçe' },
  { value: 'uk', label: 'Українська' },
  { value: 'ur', label: 'اردو' },
  { value: 'uz', label: 'Oʻzbek' },
  { value: 'vi', label: 'Tiếng Việt' },
  { value: 'zh-CN', label: '简体中文' },
  { value: 'zh-HK', label: '繁體中文（香港）' },
  { value: 'zh-TW', label: '繁體中文' },
  { value: 'zu', label: 'isiZulu' },
];

// ---- Trạng thái form mặc định (nhánh `ui`) -----------------------------
export function newFingerprint() {
  return {
    timezone: 'Dựa trên IP', timezoneValue: 'Asia/Ho_Chi_Minh',
    webRTC: 'Vô hiệu hóa', geo: 'Dựa trên IP', geoMode: 'Hỏi mỗi lần',
    geoLat: '0', geoLng: '0', geoAccuracy: 1000,
    language: 'Dựa trên IP', languageList: ['en-US', 'en'],
    displayLanguage: 'Dựa trên ngôn ngữ', displayLanguageValue: 'en-US',
    resolution: 'Ngẫu nhiên', resolutionSize: 'Dựa trên User-Agent',
    fontMode: 'Mặc định', fonts: String(440 + Math.floor(Math.random() * 40)),
    canvas: 'Nhiễu', webglImage: 'Nhiễu',
    webglMode: 'Tùy chỉnh', cpuMode: 'Tùy chỉnh', ramMode: 'Tùy chỉnh',
    // GPU + CPU/RAM phải nhất quán: chọn card trước rồi suy ra phần cứng theo hạng.
    ...(() => {
      const g = osGpu('Windows');
      const hw = osHardware('Windows', g.renderer);
      return { webglVendor: g.vendor, webglMeta: g.renderer, cpu: hw.cpu, ram: hw.ram };
    })(),
    webGPU: 'Trùng với WebGL', audioContext: 'Nhiễu', mediaDevice: 'Nhiễu', clientRects: 'Nhiễu', speechVoice: 'Nhiễu',
    deviceMode: 'Tùy chỉnh', deviceName: randDevice(), macMode: 'Tùy chỉnh', mac: randMac(),
    doNotTrack: 'Mặc định', portScan: 'Bắt đầu dùng', portScanPorts: '',
    hardwareAccel: 'Mặc định', imageLoad: 'Cho phép', audioPlay: 'Cho phép', tlsDisable: 'Đóng', launchArgs: '',
  };
}

// ---- fp-config builder -------------------------------------------------
// Quy đổi trạng thái form (tiếng Việt) → JSON --fp-config của CGTBrowser,
// khớp hợp đồng FingerprintConfigWriter của patch-chromium: seed/custom_text
// luôn có; mỗi section chỉ phát khi override; fonts/network/plugins/
// media_devices/sensors luôn hiện diện. custom_text == tên hồ sơ.
// Seed hồ sơ - bám đúng NewSeed() của patch-chromium:
//   (long)(BitConverter.ToUInt64(buf, 0) & 0x7FFFFFFFFFFFFFFFUL)
// tức lấy 64 bit từ RNG mật mã rồi MASK bit dấu → dải Int64 dương
// [0, 9223372036854775807]. Phân bố đều trên dải này nên độ dài chuỗi tự nhiên
// là ~89% 19 chữ số, ~10% 18 chữ số - GIỐNG HỆT bản gốc, không ép về đúng 19
// chữ số (ép sẽ cắt mất ~11% dải, giảm entropy và tạo dấu hiệu nhận dạng).
// Dùng crypto RNG chứ không Math.random(): tạo hàng loạt hồ sơ cùng lúc
// (profile_create_batch) phải không được trùng seed ⇒ trùng vân tay tuyệt đối.
export function genSeed() {
  const buf = new Uint8Array(8);
  const g = globalThis.crypto;
  if (g && typeof g.getRandomValues === 'function') {
    g.getRandomValues(buf);
  } else {
    for (let i = 0; i < 8; i++) buf[i] = Math.floor(Math.random() * 256);
  }
  let v = 0n;
  for (let i = 0; i < 8; i++) v = (v << 8n) | BigInt(buf[i]);
  return (v & 0x7FFFFFFFFFFFFFFFn).toString();  // mask bit dấu → Int64 dương
}

export function navPlatform(os) {
  switch (os) {
    case 'macOS': return 'MacIntel';
    case 'Linux': return 'Linux x86_64';
    case 'Android': return 'Linux armv8l';
    case 'iOS': return 'iPhone';
    default: return 'Win32';
  }
}

// OS di động (cảm ứng). UA mobile PHẢI đi kèm maxTouchPoints > 0 + màn hình dọc nhỏ +
// devicePixelRatio cao, nếu không validator chấm "Masking detected" (UA nói điện thoại
// nhưng thiết bị lộ ra là desktop: touch=0, 1920×1080, DPR=1).
const isMobileOs = (os) => os === 'Android' || os === 'iOS';

// Màn hình THẬT của thiết bị mobile theo model đang giả lập (khớp token trong UA):
//   • Android = Pixel 7  → 412×915 CSS, DPR 2.625 (1080×2400 vật lý).
//   • iOS     = iPhone   → 393×852 CSS, DPR 3 (iPhone 15/16, 1179×2556 vật lý).
// availHeight = height (di động không có taskbar cố định). colorDepth 24. Nhân đọc các
// field screen.* này từ fp-config (mirror FingerprintGeneratorService.cs preset mobile) và
// hook cả screen.width/height + devicePixelRatio + inner/outer nên window geometry cũng khớp.
function mobileScreen(os) {
  if (os === 'iOS') return { width: 393, height: 852, availWidth: 393, availHeight: 852, colorDepth: 24, devicePixelRatio: 3 };
  return { width: 412, height: 915, availWidth: 412, availHeight: 915, colorDepth: 24, devicePixelRatio: 2.625 };
}

// ---- Client Hints (navigator.userAgentData / Sec-CH-UA high-entropy) -----
// userAgentData PHẢI nhất quán với chuỗi UA. Nếu chỉ phát mỗi `ua` mà bỏ client
// hints, browser rơi về giá trị build mặc định (build trên Linux ⇒ platform
// "Linux"/"x86_64") trong khi UA báo Windows/Chrome ⇒ creepjs phát hiện mâu thuẫn
// ngay. Bảng dưới mirror 1:1 FingerprintGeneratorService.cs của patch-chromium
// (giá trị THẬT đã kiểm chứng, KHÔNG bịa).
const OS_CLIENT_HINTS = {
  Windows: { platform: 'Windows', platformVersion: '15.0.0', architecture: 'x86', bitness: '64', model: '', mobile: false },
  macOS:   { platform: 'macOS',   platformVersion: '14.5.0', architecture: 'arm', bitness: '64', model: '', mobile: false },
  Linux:   { platform: 'Linux',   platformVersion: '6.5.0',  architecture: 'x86', bitness: '64', model: '', mobile: false },
  Android: { platform: 'Android', platformVersion: '14.0.0', architecture: '',    bitness: '',   model: 'Pixel 7',  mobile: true },
  iOS:     { platform: 'iOS',     platformVersion: '17.5.0', architecture: '',    bitness: '',   model: 'iPhone',   mobile: true },
};

// Sec-CH-UA-Platform-Version cho Windows PHỤ THUỘC bản Windows. Token UA ("Windows
// NT 10.0") GIỐNG nhau cho MỌI bản Windows (Chrome reduced-UA đóng băng) nên CHỈ
// client-hint này phân biệt được các bản → phải đổi theo osVersion, nếu không Win10
// vẫn bị creepjs đọc là Windows 11.
//
// Giá trị THẬT theo WICG ua-client-hints (#220) + Microsoft "how-to-detect-win11" -
// ĐÂY là bảng các trình phát hiện (creepjs computeWindowsRelease) tra để suy ra bản
// Windows, nên phải khớp KEY tuyệt đối, nếu không bị trả "Unknown":
//   Win11   = major ≥ 13 (15.0.0 = 22H2/SV2 → '11')
//   Win10   = '10.0.0' (2004|20H2|21H1; các build sau giữ 10..12 → vẫn '10')
//   Win8.1  = '0.3.0', Win8 = '0.2.0', Win7 = '0.1.0'  (KHÔNG phải '0.0.0' - '0.0.0'
//             KHÔNG có trong bảng nên creepjs trả 'Unknown', tưởng nhầm là không nhất quán).
// Token UA vẫn đóng băng "Windows NT 10.0" cho mọi bản (Chrome reduced-UA), client-hint
// platformVersion là tín hiệu DUY NHẤT phân biệt bản → bảng này quyết định tất cả.
// LƯU Ý antidetect: nhân Chrome 140 không chạy thật trên Win8/7 → muốn nhất quán tuyệt
// đối hãy chọn major Chrome ≤ 109 cho hồ sơ Win8/7 ở ô User-Agent.
const WIN_PLATFORM_VERSION = {
  'Windows 11': '15.0.0', 'Windows 10': '10.0.0',
  'Windows 8.1': '0.3.0', 'Windows 8': '0.2.0', 'Windows 7': '0.1.0',
};

// macOS: client-hint platformVersion = phiên bản macOS THẬT. Chrome chỉ ĐÓNG BĂNG token
// UA ("10_15_7"), KHÔNG cap client-hint này (đã kiểm chứng: navigator.userAgentData báo
// đúng "14.5.0"…). creepjs giải mã theo MAJOR nên minor chỉ cần là một bản phát hành
// THẬT của major đó. Giá trị dưới là bản GA thật (KHÔNG bịa); macOS 10 = Catalina
// 10.15.7 (bản 10.x cuối, trùng token UA). Bản ngoài bảng giữ mặc định OS_CLIENT_HINTS.
const MAC_PLATFORM_VERSION = {
  'macOS 26': '26.0.0', 'macOS 15': '15.0.0', 'macOS 14': '14.5.0', 'macOS 13': '13.6.0',
  'macOS 12': '12.7.0', 'macOS 11': '11.7.0', 'macOS 10': '10.15.7',
};

// platformVersion theo OS + bản đã chọn.
//  • Desktop (Windows/macOS): token UA bị đóng băng nên client-hint là nguồn DUY NHẤT
//    phân biệt bản → tra bảng WIN/MAC_PLATFORM_VERSION.
//  • Mobile (Android/iOS): Chrome/WebKit THẬT báo đúng số bản OS dạng "<bản>.0.0"
//    (Android 14→14.0.0, iOS 17→17.0.0); cũng khớp số bản đã nhúng trong token UA mobile
//    (uaString bám osVersion) nên hai nguồn không còn tự mâu thuẫn.
function platformVersionFor(os, osVersion, base) {
  if (os === 'Windows') return WIN_PLATFORM_VERSION[osVersion] || base;
  if (os === 'macOS' || os === 'Mac') return MAC_PLATFORM_VERSION[osVersion] || base;
  if (os === 'Android' || os === 'iOS') {
    const m = String(osVersion || '').match(/(\d+)/);
    return m ? `${m[1]}.0.0` : base;
  }
  return base;
}

// Đọc major + full-version từ token Chrome/CriOS trong UA. Chrome thật ĐÓNG BĂNG
// UA về dạng X.0.0.0 nhưng vẫn báo full-version THẬT qua Sec-CH-UA-Full-Version →
// với UA rút gọn ta lấy 1 build THẬT của major (CHROME_BUILDS) cho fullVersion.
function chromeFullFromUa(ua) {
  const m = String(ua || '').match(/(?:Chrome|CriOS)\/(\d+)\.(\d+)\.(\d+)\.(\d+)/);
  if (!m) return '';
  const major = parseInt(m[1], 10);
  // Major engine: PHẢI trả đúng build engine (264) để uaFullVersion == fullVersionList.
  if (major === KERNEL_MAJOR) return KERNEL_FULL_VERSION;
  // Major khác (engine vẫn 140): cố gắng giữ MAJOR khớp UA - UA rút gọn lấy 1 build
  // THẬT của major, UA tường minh giữ nguyên build đã chọn.
  if (m[3] === '0' && m[4] === '0') {
    const real = CHROME_BUILDS[major];
    return real && real.length ? real[0] : KERNEL_FULL_VERSION;
  }
  return `${m[1]}.${m[2]}.${m[3]}.${m[4]}`;
}

// Major brand (Sec-CH-UA / navigator.userAgentData.brands) PHẢI khớp major của UA.
// Nhân vá đọc brandVersion (chuỗi major, vd "148") để GHI ĐÈ .version của brand thật
// trong brand_version_list (xem fp_hooks_ua.cc::ApplyUAMetadata); nếu vắng nó tự suy
// major từ fullVersion. Ta phát TƯỜNG MINH để brand major == major UA dù UA rút gọn
// (tránh creepjs báo "Google Chrome 140 (148.x)" - major nhân gốc lẫn full đã chọn).
function chromeMajorFromUa(ua) {
  const m = String(ua || '').match(/(?:Chrome|CriOS)\/(\d+)\./);
  return m ? m[1] : '';
}

// Lấy TÊN THIẾT BỊ từ token trong UA mobile để Sec-CH-UA-Model KHỚP UA.
// Android: "...; Android 13; Pixel 7)" → "Pixel 7". iOS: token là "iPhone".
function modelFromUa(ua) {
  const s = String(ua || '');
  const m = s.match(/Android [\d.]+;\s*([^);]+)\)/);
  if (m) return m[1].trim();
  if (/iPhone/.test(s)) return 'iPhone';
  return '';
}

// Dựng object user_agent (ua + client hints) khớp hợp đồng fingerprint_config.cc.
// Mirror PutStr của writer C#: chỉ phát field chuỗi khi KHÔNG rỗng; mobile chỉ phát
// khi true. iOS bỏ fullVersion vì Chrome on iOS = engine WebKit, không gửi
// Sec-CH-UA-Full-Version.
//
// EXPORT vì màn "Trình duyệt" hàng loạt (views/profiles.js) phải dựng lại ĐÚNG nhánh
// cfg.user_agent khi đổi UA mà KHÔNG được gọi buildFpConfig() - hàm đó sinh seed mới
// (genSeed) nên sẽ đổi luôn cả vân tay. Hàm này THUẦN (os, ua, osVersion) → object,
// không random gì, nên vá lẻ bằng nó cho ra kết quả y hệt buildFpConfig.
export function buildUaMeta(os, ua, osVersion) {
  const base = OS_CLIENT_HINTS[os === 'Mac' ? 'macOS' : os] || OS_CLIENT_HINTS.Windows;
  // navigator.userAgent PHẢI rút gọn về major.0.0.0 trên MỌI OS (Chrome ≥110 UA-Reduction,
  // độc lập OS). Full build CHỈ lộ qua client-hints (fullVersion/fullVersionList bên dưới) -
  // đúng như Chrome thật, và đã kiểm chứng: nhân vá lấy fullVersionList từ field fullVersion
  // (KHÔNG suy từ .ua) nên rút gọn .ua không làm mất full build ở client-hints. Nếu để full
  // build trong .ua thì navigator.userAgent lộ 140.0.7339.264 → lệch Chrome thật và lệch hồ
  // sơ Windows "Tất cả" (native ra 140.0.0.0). Rút gọn CHỈ token Chrome/CriOS; Firefox (rv:)
  // và iOS (Version/, không có token Chrome) không khớp regex nên giữ nguyên.
  // Rút gọn version token về major.0.0.0 cho CẢ `Chrome/` (desktop + Android) LẪN `CriOS/`
  // (Chrome iOS): Chrome iOS hiện đại CŨNG áp UA-Reduction → navigator.userAgent ra
  // CriOS/140.0.0.0 (kiểm chứng UA thật 7/2026: "CriOS/150.0.0.0"). Full revision KHÔNG lộ
  // đâu trên iOS vì WebKit không có navigator.userAgentData. Firefox (Firefox/…) không khớp
  // regex nên giữ nguyên (Firefox không rút gọn version).
  let reducedUa = String(ua).replace(/((?:Chrome|CriOS))\/(\d+)\.\d+\.\d+\.\d+/, '$1/$2.0.0.0');
  // KHÔNG đóng băng "Android <ver>; <model>" về "Android 10; K". Tuy Chrome 140 THẬT có
  // rút gọn phần này, nhưng khi giữ "K" thì navigator.userAgent MẤT model trong khi
  // client-hints (Sec-CH-UA-Model) vẫn báo model thật ("Pixel 7") → detector so hai nguồn
  // thấy LỆCH model ⇒ "Masking detected" (kiểm chứng: uaModel="K" vs chModel="Pixel 7" =
  // MISMATCH). Dự án patch-chromium gốc GIỮ model thật trong UA ("Android 14; SM-S911B")
  // nên UA ↔ CH khớp và KHÔNG bị masking. Ta theo cách đó: giữ nguyên "Android <ver>; <model>"
  // (chỉ rút gọn token Chrome/CriOS version ở trên) để UA model == userAgentData.model.
  const meta = { ua: reducedUa };
  const put = (k, v) => { if (v) meta[k] = v; };
  put('platform', base.platform);
  // platformVersion phải bám theo bản OS đã chọn cho MỌI OS, nếu không creepjs đọc sai
  // bản (vd Win10 ra Win11, macOS 15 ra macOS 14, Android 13 ra 14). Xem platformVersionFor.
  // Dùng base.platform (đã chuẩn hoá 'Windows'/'macOS'/…) thay vì `os` thô: nếu `os` lọt
  // vào dạng viết thường ('windows') thì platformVersionFor so sánh strict sẽ trượt mọi
  // nhánh và trả base (mặc định = bản mới nhất) → Win10 bị báo nhầm Win11. Truyền canonical
  // để LUÔN tra đúng bảng theo osVersion đã chọn.
  put('platformVersion', platformVersionFor(base.platform, osVersion, base.platformVersion));
  if (base.mobile) {
    meta.mobile = true;
    // model = tên thiết bị, PHẢI khớp token thiết bị trong UA (UA "Pixel 7" ⇒ model
    // "Pixel 7"); lấy thẳng từ UA để không lệch như cũ (UA Pixel 7 vs model SM-S911B).
    put('model', modelFromUa(ua) || base.model);
    // Android/iOS THẬT trả architecture/bitness = "" (rỗng - di động không lộ kiến trúc).
    // fp-config BỎ field rỗng nên nếu vắng, browser rơi về arch BUILD (x86_64) ⇒ lộ
    // "Android x86_64" (bất khả thi). Phát rỗng TƯỜNG MINH để báo đúng "" như Chrome thật.
    meta.architecture = '';
    meta.bitness = '';
  } else {
    put('architecture', base.architecture);
    put('bitness', base.bitness);
    put('model', base.model);
  }
  put('fullVersion', base.platform === 'iOS' ? '' : chromeFullFromUa(ua));
  // brandVersion = major Chrome đã chọn (đồng bộ với fullVersion ở trên). iOS không có
  // userAgentData (WebKit) nên bỏ qua, giống fullVersion.
  if (base.platform !== 'iOS') put('brandVersion', chromeMajorFromUa(ua));
  return meta;
}

// ---- WebGPU (GPUAdapterInfo) SUY TỪ WebGL renderer ------------------------
// Nhân đọc khối `webgpu` trong --fp-config đúng 4 trường:
//   { vendor: "amd", architecture: "rdna-2", device: "0x73df", description: "AMD Radeon RX 6700 XT" }
// Tab "WebGPU" = "Trùng với WebGL" ⇒ cả 4 trường PHẢI rút ra từ CHÍNH chuỗi WebGL renderer
// của hồ sơ. Lấy card khác (dù cùng hãng) là detector đặt navigator.gpu cạnh WEBGL_debug_
// renderer_info rồi thấy hai GPU khác nhau ⇒ lộ ngay. Vì vậy hàm này KHÔNG random gì.
//
// Quy tắc tên trường (khớp Dawn/Chrome thật):
//  - vendor       : chữ thường, tên hãng PCI: nvidia | amd | intel | apple | qualcomm | arm | samsung
//  - architecture : tên Dawn ở dạng js-enum: "gen-9" "gen-12lp" "gen-12hp" "rdna-2" "gcn-5"
//                   "pascal" "ampere" "lovelace" "adreno-7xx" "valhall"… (gạch nối KHÔNG đứng
//                   sau chữ số - "gen-12lp" chứ không phải "gen-12-lp").
//  - device       : PCI device id dạng hex chữ thường, KHÔNG đệm số 0 ("0x73df", không
//                   "0x000073DF"). Chuỗi D3D11/Vulkan có sẵn "(0x0000XXXX)" thì lấy ĐÚNG số đó
//                   (khớp tuyệt đối WebGL); không có mới tra bảng GPU_DEVICE_IDS bên dưới.
//                   GPU không có PCI id (Apple Silicon, Adreno, Mali, Xclipse) ⇒ "" như Chrome thật.
//  - description  : TÊN card nằm trong renderer, đã gọt phần API ("Direct3D11 vs_5_0 ps_5_0",
//                   "/PCIe/SSE2", " OpenGL Engine", "Mesa ", "(0x…)").
// Không nhận ra hãng ⇒ trả null ⇒ KHÔNG phát khối webgpu (bịa hãng còn tệ hơn để thật).

// Card mà renderer KHÔNG kèm "(0x…)" (Linux GL, macOS, vài dòng D3D11 cũ). Khoá = description
// viết thường. Bản trùng tên với dòng D3D11 có id dùng CÙNG id đó để mọi OS ra một số.
const GPU_DEVICE_IDS = {
  // Windows D3D11 không kèm id (gồm cả 3 card của pool DỰ PHÒNG OS_GPU.Windows - đó là
  // hồ sơ mặc định khi pool server chưa nạp kịp, thiếu ở đây là device/architecture rỗng)
  'amd radeon rx 6600': '0x73ff',
  'amd radeon rx 6500 xt': '0x743f',
  'amd radeon(tm) rx 560 series': '0x67ff',
  'radeon rx550/550 series': '0x699f',
  'intel(r) hd graphics 530': '0x191b',
  'intel(r) hd graphics 630': '0x5912',
  'intel(r) uhd graphics': '0x9a78',
  'nvidia geforce gtx 1650': '0x1f82',
  'nvidia geforce gtx 1660': '0x2184',
  'nvidia geforce gtx 1660 super': '0x21c4',
  'nvidia geforce rtx 2060 super': '0x1f06',
  // NVIDIA (Linux GL "…/PCIe/SSE2")
  'nvidia geforce gtx 1050 ti': '0x1c82',
  'nvidia geforce gtx 1060 6gb': '0x1c03',
  'nvidia geforce gtx 1070': '0x1b81',
  'nvidia geforce gtx 1080 ti': '0x1b06',
  'nvidia geforce gtx 1650 super': '0x2187',
  'nvidia geforce gtx 1660 ti': '0x2182',
  'nvidia geforce rtx 2060': '0x1f08',
  'nvidia geforce rtx 2070 super': '0x1e84',
  'nvidia geforce rtx 2080': '0x1e87',
  'nvidia geforce rtx 3050': '0x2507',
  'nvidia geforce rtx 3060 ti': '0x2486',
  'nvidia geforce rtx 3060': '0x2503',
  'nvidia geforce rtx 3070 ti': '0x2482',
  'nvidia geforce rtx 3070': '0x2484',
  'nvidia geforce rtx 3080 laptop gpu': '0x249c',
  'nvidia geforce rtx 3080': '0x2206',
  'nvidia geforce rtx 3090': '0x2204',
  'nvidia geforce rtx 4060 ti': '0x2803',
  'nvidia geforce rtx 4060': '0x2882',
  'nvidia geforce rtx 4070 super': '0x2783',
  'nvidia geforce rtx 4070 ti': '0x2782',
  'nvidia geforce rtx 4070': '0x2786',
  'nvidia geforce rtx 4080': '0x2704',
  'nvidia geforce rtx 4090': '0x2684',
  'nvidia geforce rtx 5070 ti': '0x2c05',
  'nvidia geforce rtx 5070': '0x2f04',
  'nvidia geforce rtx 5080': '0x2c02',
  'nvidia geforce rtx 5090': '0x2b85',
  // Intel Mesa (Linux) - tên kèm mã nhân "(KBL GT2)"
  'intel(r) graphics (adl gt2)': '0x46a6',
  'intel(r) graphics (rkl gt1)': '0x4c8a',
  'intel(r) graphics (rpl-p)': '0xa7a0',
  'intel(r) hd graphics 520 (skl gt2)': '0x1916',
  'intel(r) hd graphics 530 (skl gt2)': '0x1912',
  'intel(r) hd graphics 620 (kbl gt2)': '0x5916',
  'intel(r) hd graphics 630 (kbl gt2)': '0x5912',
  'intel(r) uhd graphics (cml gt2)': '0x9b41',
  'intel(r) uhd graphics (tgl gt1)': '0x9a68',
  'intel(r) uhd graphics 620 (kbl gt2)': '0x5917',
  'intel(r) uhd graphics 630 (cfl gt2)': '0x3e92',
  'intel(r) uhd graphics 770 (adl-s gt1)': '0x4680',
  'intel(r) xe graphics (tgl gt2)': '0x9a49',
  // macOS Intel
  'intel(r) iris(tm) plus graphics 640': '0x5926',
  'intel(r) iris(tm) plus graphics 645': '0x3ea6',
  'intel(r) iris(tm) plus graphics 650': '0x5927',
  'intel(r) iris(tm) plus graphics 655': '0x3ea5',
  'intel(r) iris(tm) plus graphics': '0x8a52',
  'intel(r) uhd graphics 617': '0x87c0',
  'intel(r) uhd graphics 630': '0x3e9b',
  // macOS AMD
  'amd radeon pro 450': '0x67ef',
  'amd radeon pro 455': '0x67ef',
  'amd radeon pro 460': '0x67ef',
  'amd radeon pro 560': '0x67ef',
  'amd radeon pro 560x': '0x67ef',
  'amd radeon pro 570': '0x67df',
  'amd radeon pro 575': '0x67df',
  'amd radeon pro 580': '0x67df',
  'amd radeon pro 580x': '0x67df',
  'amd radeon pro vega 20': '0x69af',
  'amd radeon pro vega 48': '0x6869',
  'amd radeon pro vega 56': '0x687f',
  'amd radeon rx vega 64': '0x687f',
  'amd radeon pro 5300': '0x7340',
  'amd radeon pro 5300m': '0x7340',
  'amd radeon pro 5500m': '0x7340',
  'amd radeon pro 5600m': '0x7360',
  'amd radeon pro 5700 xt': '0x731f',
  'amd radeon pro w5700x': '0x7310',
};

// [hãng, tên Dawn, các khoảng device id] - tra kiến trúc THEO SỐ (chính xác hơn đoán tên).
const GPU_ARCH_BY_DEVICE = [
  ['nvidia', 'maxwell', [[0x1300, 0x14ff], [0x1600, 0x17ff]]],
  ['nvidia', 'pascal', [[0x1500, 0x15ff], [0x1b00, 0x1dff]]],
  ['nvidia', 'turing', [[0x1e00, 0x1fff], [0x2100, 0x21ff]]],
  ['nvidia', 'ampere', [[0x2000, 0x20ff], [0x2200, 0x25ff]]],
  ['nvidia', 'lovelace', [[0x2600, 0x28ff]]],
  ['nvidia', 'blackwell', [[0x2900, 0x2fff]]],
  ['amd', 'gcn-4', [[0x67c0, 0x67ff], [0x6980, 0x699f], [0x6fd0, 0x6fdf]]],
  ['amd', 'gcn-5', [[0x6860, 0x687f], [0x69a0, 0x69af], [0x66a0, 0x66af], [0x15d8, 0x15d8], [0x15dd, 0x15dd], [0x15e7, 0x15e7], [0x1636, 0x1636], [0x1638, 0x1638], [0x164c, 0x164c]]],
  ['amd', 'rdna-1', [[0x7310, 0x731f], [0x7340, 0x734f], [0x7360, 0x736f]]],
  ['amd', 'rdna-2', [[0x73a0, 0x73ff], [0x7420, 0x743f], [0x163f, 0x163f], [0x164d, 0x164d], [0x1681, 0x1681]]],
  ['amd', 'rdna-3', [[0x7440, 0x749f], [0x15bf, 0x15bf], [0x15c8, 0x15c8], [0x1900, 0x1901]]],
  ['amd', 'rdna-4', [[0x7550, 0x755f]]],
  ['intel', 'gen-9', [[0x1900, 0x19ff], [0x5900, 0x59ff], [0x3e00, 0x3eff], [0x9b00, 0x9bff], [0x8700, 0x87ff], [0x3100, 0x31ff], [0x5a00, 0x5aff]]],
  ['intel', 'gen-11', [[0x8a00, 0x8aff], [0x4e00, 0x4eff], [0x4500, 0x45ff]]],
  ['intel', 'gen-12lp', [[0x9a00, 0x9aff], [0x4c00, 0x4cff], [0x4600, 0x46ff], [0x4900, 0x49ff], [0xa700, 0xa7ff]]],
  ['intel', 'gen-12hp', [[0x5600, 0x56ff], [0x4f00, 0x4fff]]],
  ['intel', 'xe-lpg', [[0x7d00, 0x7dff]]],
  ['intel', 'xe-2lpg', [[0x6400, 0x64ff]]],
  ['intel', 'xe-2hpg', [[0xe200, 0xe2ff]]],
];

function webgpuArchByDevice(vendor, device) {
  const id = parseInt(String(device || '').replace(/^0x/i, ''), 16);
  if (!Number.isFinite(id)) return '';
  for (const [v, arch, ranges] of GPU_ARCH_BY_DEVICE) {
    if (v !== vendor) continue;
    if (ranges.some(([lo, hi]) => id >= lo && id <= hi)) return arch;
  }
  return '';
}

// GPU không có PCI id (di động / Apple Silicon) ⇒ kiến trúc suy theo TÊN.
function webgpuArchByName(vendor, desc) {
  const d = String(desc || '');
  if (vendor === 'apple') return /^Apple M\d/i.test(d) ? 'metal-3' : '';
  if (vendor === 'qualcomm') {
    const m = d.match(/Adreno\D*(\d)\d\d/i);
    return m ? `adreno-${m[1]}xx` : '';
  }
  if (vendor === 'arm') {
    // Mali-G31/G51/G52/G71/G72/G76 = Bifrost; G57/G68/G77/G78/G610/G615/G710/G715 = Valhall.
    // G720/G925 (thế hệ 5) Dawn chưa đặt tên ⇒ '' như Chrome thật.
    const m = d.match(/G(\d{2,3})\b/i);
    if (!m) return '';
    const n = parseInt(m[1], 10);
    if ([31, 51, 52, 71, 72, 76].includes(n)) return 'bifrost';
    if ([57, 68, 77, 78, 610, 615, 710, 715].includes(n)) return 'valhall';
    return '';
  }
  if (vendor === 'samsung') return /Xclipse/i.test(d) ? 'rdna-2' : '';
  return '';
}

export function webgpuFromRenderer(renderer, webglVendor) {
  const raw = String(renderer || '').trim();
  if (!raw) return null;

  // ANGLE (<hãng>, <tên card + API>, <phiên bản API>) - phần cuối sau ", " là API, bỏ.
  let vendorTok = '';
  let gpu = raw;
  const angle = raw.match(/^ANGLE \((.*)\)$/s);
  if (angle) {
    const inner = angle[1];
    const first = inner.indexOf(', ');
    vendorTok = first > 0 ? inner.slice(0, first) : '';
    const rest = first > 0 ? inner.slice(first + 2) : inner;
    const last = rest.lastIndexOf(', ');
    gpu = last > 0 ? rest.slice(0, last) : rest;
  }

  // Gỡ các lớp bọc của backend để còn TÊN card.
  let m;
  if ((m = gpu.match(/^Vulkan [\d.]+ \((.*)\)$/))) gpu = m[1];
  if ((m = gpu.match(/^ANGLE \((.*)\) on Vulkan/))) gpu = m[1];
  if ((m = gpu.match(/^ANGLE Metal Renderer: (.*)$/))) gpu = m[1];

  // Device id có sẵn trong chuỗi ⇒ dùng ĐÚNG số đó.
  let device = '';
  const idm = gpu.match(/\s*\(0x([0-9a-f]{1,8})\)/i);
  if (idm) {
    device = '0x' + parseInt(idm[1], 16).toString(16);
    gpu = gpu.replace(idm[0], '');
  }
  const desc = gpu
    .replace(/\s+Direct3D(?:9Ex|11|12)?\s+vs_\d_\d\s+ps_\d_\d.*$/i, '')
    .replace(/\/(?:PCIe|PCI|AGP)\/SSE2$/i, '')
    .replace(/\s+OpenGL Engine$/i, '')
    .replace(/^Mesa\s+/i, '')
    .replace(/^NVIDIA\s+(?=NVIDIA\s)/i, '')
    .replace(/\s{2,}/g, ' ')
    .trim();
  if (!desc) return null;

  // Hãng lấy từ CHÍNH renderer trước; ô "Nhà cung cấp" WebGL chỉ là lối lùi - người dùng
  // gõ tay renderer card AMD mà quên đổi vendor thì description (AMD) mới là thứ lộ ra.
  const vendorOf = (s) => {
    const h = String(s || '').toLowerCase();
    return /nvidia|geforce|quadro/.test(h) ? 'nvidia'
      : /\bamd\b|ati technologies|radeon/.test(h) ? 'amd'
        : /intel/.test(h) ? 'intel'
          : /qualcomm|adreno/.test(h) ? 'qualcomm'
            : /samsung|xclipse/.test(h) ? 'samsung'
              : /\barm\b|mali|immortalis/.test(h) ? 'arm'
                : /apple/.test(h) ? 'apple'
                  : '';
  };
  const vendor = vendorOf(`${vendorTok} ${desc}`) || vendorOf(webglVendor);
  if (!vendor) return null;

  if (!device && ['nvidia', 'amd', 'intel'].includes(vendor)) device = GPU_DEVICE_IDS[desc.toLowerCase()] || '';
  const architecture = webgpuArchByDevice(vendor, device) || webgpuArchByName(vendor, desc);

  return { vendor, architecture, device, description: desc };
}

export function buildFpConfig(fp, os, ua, name, osVersion) {
  const cfg = { seed: genSeed(), custom_text: name };

  // timezone / locale: chỉ phát khi người dùng override ("Tùy chỉnh"), lấy ĐÚNG
  // giá trị người dùng chọn trong ô con (không còn hardcode).
  if (fp.timezone === 'Tùy chỉnh') cfg.timezone = fp.timezoneValue || 'Asia/Ho_Chi_Minh';
  if (fp.language === 'Tùy chỉnh') {
    const list = Array.isArray(fp.languageList) && fp.languageList.length ? fp.languageList : ['en-US', 'en'];
    cfg.locale = list[0];
  }

  // device_name / mac_address: chỉ khi custom
  if (fp.deviceMode === 'Tùy chỉnh' && fp.deviceName) cfg.device_name = fp.deviceName;
  if (fp.macMode === 'Tùy chỉnh' && fp.mac) cfg.mac_address = fp.mac;

  // navigator
  const nav = { platform: navPlatform(os), webdriver: false };
  // Mobile: thiết bị cảm ứng → maxTouchPoints = 5 (desktop bỏ trống ⇒ nhân trả 0). UA
  // mobile mà maxTouchPoints=0 là mâu thuẫn kinh điển khiến validator báo "Masking".
  if (isMobileOs(os)) nav.maxTouchPoints = 5;
  if (fp.cpuMode === 'Tùy chỉnh') nav.hardwareConcurrency = fp.cpu;
  // Chrome lượng tử hoá deviceMemory về luỹ thừa 2 và CHẶN TRẦN ở 8 GiB. Báo 16/32
  // (hoặc 6, không phải luỹ thừa 2) là giá trị bất khả thi → tự lộ. Luôn quy về
  // luỹ thừa 2 hợp lệ gần nhất và kẹp ≤ 8 dù người dùng chọn RAM lớn hơn.
  if (fp.ramMode === 'Tùy chỉnh') nav.deviceMemory = quantizeDeviceMemory(fp.ram);
  if (fp.language === 'Tùy chỉnh') {
    nav.languages = Array.isArray(fp.languageList) && fp.languageList.length ? fp.languageList.slice() : ['en-US', 'en'];
  }
  cfg.navigator = nav;

  // screen: MOBILE ép độ phân giải + DPR của thiết bị, BỎ QUA ô "Độ phân giải" desktop
  // (1920×1080 @1 mâu thuẫn UA điện thoại). DESKTOP: chỉ phát khi chọn độ phân giải cụ thể.
  if (isMobileOs(os)) {
    cfg.screen = mobileScreen(os);
  } else if (fp.resolution !== 'Ngẫu nhiên' && fp.resolutionSize) {
    const m = fp.resolutionSize.match(/(\d+)\s*x\s*(\d+)/i);
    if (m) {
      const w = parseInt(m[1], 10);
      const h = parseInt(m[2], 10);
      cfg.screen = { width: w, height: h, availWidth: w, availHeight: h, colorDepth: 24, devicePixelRatio: 1.0 };
    }
  }

  // webgl: noise (Avatar WebGL) và/hoặc custom vendor+renderer
  const webgl = {};
  if (fp.webglImage === 'Nhiễu') webgl.noise = true;
  if (fp.webglMode === 'Tùy chỉnh') {
    if (fp.webglVendor) webgl.vendor = fp.webglVendor;
    if (fp.webglMeta) webgl.renderer = fp.webglMeta;
  }
  if (Object.keys(webgl).length) cfg.webgl = webgl;

  // webgpu: tab "WebGPU".
  //  'Trùng với WebGL' → khối webgpu suy từ ĐÚNG renderer vừa phát ở webgl.renderer (cùng
  //                      một biến fp.webglMeta ⇒ description luôn khớp). WebGL đang "Thực"
  //                      (không phát webgl) thì "trùng" nghĩa là WebGPU cũng thật ⇒ không phát.
  //  'Thực'            → không phát (nhân trả GPU thật).
  //  'Vô hiệu hóa'     → JSON nhân KHÔNG có trường tắt; hiện chưa phát gì (= như 'Thực').
  if (fp.webGPU === 'Trùng với WebGL' && webgl.renderer) {
    const wg = webgpuFromRenderer(webgl.renderer, webgl.vendor);
    if (wg) cfg.webgpu = wg;
  }

  // noise-based sections
  if (fp.canvas === 'Nhiễu') cfg.canvas = { noise: true };
  if (fp.audioContext === 'Nhiễu') cfg.audio = { noise: true, factor: 1e-7 };
  if (fp.clientRects === 'Nhiễu') cfg.clientRects = { noise: true };

  // webrtc: 'Thực'→real (mặc định, không phát) | 'Vô hiệu hóa'→disabled |
  // 'Thay thế'→fake_ip | 'UDP qua proxy'→proxy_only.
  //
  // 'Thay thế' = fake_ip: thay IP srflx bằng IP exit proxy (tool tự dò publicIp khi Launch ở
  // mode Proxy IP) và ẩn host/.local + IP/MAC rõ trong pc.getStats()/RTCIceCandidateStats.
  // Đúng ngữ nghĩa nhãn và đúng chú thích trên nút: "Sử dụng IP WebRTC trùng khớp với proxy".
  // Đây là lựa chọn NÊN DÙNG trên nhân Chromium vì nhân C++ khớp CHÍNH XÁC chuỗi này.
  //
  // 'UDP qua proxy' = proxy_only: ép mọi ứng viên ICE đi qua proxy, cấm UDP trực tiếp.
  // CẢNH BÁO: proxy_only KHÔNG có một dòng C++ nào trong nhân - nó chỉ sống nhờ pref thuần
  // media.peerconnection.ice.proxy_only (đường Gecko, xem browser-launcher.js). Trên nhân
  // Chromium pref này KHÔNG AI XỬ LÝ ⇒ WebRTC vẫn chạy UDP bình thường và STUN trả về IP
  // CÔNG KHAI THẬT. Vì vậy chỉ chọn mode này khi chạy nhân Firefox; nhân Chromium hãy dùng
  // "Thay thế". Ta vẫn gửi kèm hideStatsHostname/hideStatsMac để ít nhất che host/.local.
  //
  // TÊN MODE PHẢI KHỚP NHÂN. Đây là chuỗi nhân đọc từ --fp-config, không phải nhãn nội bộ:
  // đổi ở đây thì PHẢI đổi luôn applyProxyGeo() trong src/main/ipc.js - chỗ đó dò IP exit
  // của proxy rồi gán webrtc.publicIp, và nó lọc theo ĐÚNG chuỗi mode này. Lệch một chữ là
  // publicIp không bao giờ được gán NHƯNG KHÔNG BÁO LỖI GÌ: hồ sơ vẫn mở, WebRTC vẫn chạy,
  // chỉ là không còn thay IP nữa - lỗi im lặng, chỉ lộ ra khi người dùng bị site phát hiện.
  const rtc = fp.webRTC === 'Vô hiệu hóa' ? 'disabled'
    : fp.webRTC === 'Thay thế' ? 'fake_ip'
      : fp.webRTC === 'UDP qua proxy' ? 'proxy_only'
        : 'real';
  if (rtc === 'disabled') cfg.webrtc = { mode: 'disabled' };
  else if (rtc === 'fake_ip') cfg.webrtc = { mode: 'fake_ip', hideStatsHostname: true, hideStatsMac: true };
  else if (rtc === 'proxy_only') cfg.webrtc = { mode: 'proxy_only', hideStatsHostname: true, hideStatsMac: true };

  // geolocation: chỉ phát khi không phải real. "Tùy chỉnh" (fake) lấy lat/long +
  // accuracy người dùng nhập trong ô con; thiếu lat/long thì để browser tự suy theo IP.
  const geoMode = fp.geo === 'Block' ? 'disabled' : fp.geo === 'Tùy chỉnh' ? 'fake' : 'real';
  if (geoMode !== 'real') {
    const acc = Number(fp.geoAccuracy) > 0 ? Number(fp.geoAccuracy) : 100;
    cfg.geolocation = { mode: geoMode, accuracy: acc };
    if (geoMode === 'fake') {
      const lat = parseFloat(fp.geoLat);
      const lng = parseFloat(fp.geoLng);
      if (Number.isFinite(lat) && Number.isFinite(lng)) {
        cfg.geolocation.latitude = lat;
        cfg.geolocation.longitude = lng;
      }
    }
  }

  // các section luôn hiện diện (mặc định khớp FingerprintProfile của patch-chromium)
  // fonts: whitelist = bộ font (server) gắn vào hồ sơ → quảng bá đúng bộ font OS.
  cfg.fonts = { mode: 'real', whitelist: Array.isArray(fp.fontList) ? fp.fontList : [], blacklist: [] };
  cfg.network = { mode: 'real', type: 'wifi', effectiveType: '4g', downlink: 10, rtt: 50, saveData: false };
  cfg.plugins = { mode: 'real', pdf_viewer_enabled: true, list: [] };

  // media_devices: toggle "Thiết bị truyền thông" BẬT (mediaDevice==='Nhiễu') → spoof
  // với label camera/mic ĐÚNG OS (osMediaLabels). TẮT → giữ thật (mode:'real', -1).
  if (fp.mediaDevice === 'Nhiễu') {
    const md = osMediaLabels(os);
    const cams = Array.isArray(md.cameraLabels) ? md.cameraLabels.slice() : [];
    const mics = Array.isArray(md.micLabels) ? md.micLabels.slice() : [];
    cfg.media_devices = {
      mode: 'spoof',
      audio_inputs: mics.length,
      audio_outputs: 1,
      video_inputs: cams.length,
      cameraLabels: cams,
      micLabels: mics,
      noiseDeviceId: true,
      emptyLabels: true,
    };
  } else {
    cfg.media_devices = { mode: 'real', audio_inputs: -1, audio_outputs: -1, video_inputs: -1 };
  }

  // speechVoices: toggle "SpeechVoices" BẬT (speechVoice==='Nhiễu') → chỉ expose bộ
  // giọng ĐÚNG OS ở getVoices() (osVoices). TẮT → không phát section (giữ thật).
  if (fp.speechVoice === 'Nhiễu') {
    cfg.speechVoices = { whitelist: osVoices(os).slice() };
  }

  cfg.sensors = { battery: 'real', bluetooth: 'real', gamepad: 'real', usb: 'real', serial: 'real', hid: 'real', motion: 'off' };

  if (ua) cfg.user_agent = buildUaMeta(os, ua, osVersion);

  return cfg;
}
