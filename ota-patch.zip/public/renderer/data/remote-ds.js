// Renderer-side adapter over window.vt.remote.* - unwraps the IPC envelope
// ({ ok:true, data } / { ok:false, error, code, status }) so views can call
// remote.groups.list() and get the data directly (or a thrown Error on failure).
//
// This is the bridge used while flipping screens from local SQLite (vt.*) to the
// server (vt.remote.*). Each view migrates one at a time; the local path stays
// intact until the server is proven 100%.

import { logActivity, logActivityBatch, nameFor } from './activity-log.js';

async function unwrap(promise) {
  const res = await promise;
  if (res && res.ok) return res.data;
  const err = new Error((res && res.error) || 'Lỗi không xác định');
  if (res) { err.code = res.code; err.status = res.status; }
  throw err;
}

// os meta (create view dùng 'Windows'/'macOS'/…) → enum server.
const OS_TO_ENUM = { Windows: 'windows', macOS: 'macos', Mac: 'macos', Linux: 'linux', Android: 'android', iOS: 'ios' };
// Chiều ngược lại (enum server → hiển thị proper-case) - dùng khi ép fp.meta.os sau khi
// sinh vân tay mới, để lưới đọc đúng icon OS (cột `os` được server suy từ fp.meta.os).
const ENUM_TO_OS = { windows: 'Windows', macos: 'macOS', linux: 'Linux', android: 'Android', ios: 'iOS' };
// Các khóa "dynamic" local → đưa vào metadata jsonb của server.
const META_KEYS = [
  'note', 'tags', 'proxyType', 'proxyHost', 'proxyPort', 'proxyUser', 'proxyPass',
  'proxyToken', 'proxyRotateUrl',
  'geoIp', 'geoCountry', 'geoRegion', 'geoCity', 'startUrl',
  'resourceType', 'resourceFormat', 'resourceAccount',
];

// Vân tay local có thể là chuỗi JSON (từ create/edit-view) hoặc object → object.
function parseFp(fingerprint) {
  try { return typeof fingerprint === 'string' ? JSON.parse(fingerprint || '{}') : (fingerprint || {}); }
  catch { return {}; }
}

// Payload create-view local ({name, groupId, fingerprint:JSON, dynamic}) → shape server.
// Cookie là DỮ LIỆU CÁ NHÂN (PDPD Việt Nam) → TÁCH khỏi fingerprint TRƯỚC khi gửi lên
// server; nó chỉ được ghi xuống file LOCAL của hồ sơ (xem writeCookieSeed).
function toServerProfile(payload) {
  const p = payload || {};
  const fp = parseFp(p.fingerprint);
  if (fp && typeof fp === 'object') delete fp.cookies; // KHÔNG bao giờ lên server
  const os = OS_TO_ENUM[(fp.meta && fp.meta.os) || ''] || null;
  const dyn = p.dynamic || {};
  const metadata = {};
  for (const k of META_KEYS) if (dyn[k] != null && dyn[k] !== '') metadata[k] = dyn[k];
  return { name: p.name, os, groupId: p.groupId || null, fingerprint: fp, metadata };
}

// Lấy chuỗi cookie seed người dùng dán từ payload create-view (nếu có).
function pullCookieSeed(payload) {
  const fp = parseFp((payload || {}).fingerprint);
  return typeof fp.cookies === 'string' ? fp.cookies : '';
}
// Ghi cookie seed xuống file LOCAL của hồ sơ (qua IPC). Best-effort - cookie ở local
// là bắt buộc về mặt pháp lý; lỗi ghi local không được làm hỏng luồng tạo/sửa hồ sơ.
async function writeCookieSeed(id, text) {
  try { if (id) await vt.remote.profiles.writeCookieSeed(id, text || ''); }
  catch { /* local best-effort */ }
}

// Bảo thẻ gói (sidebar) tự làm mới sau thao tác vừa chạm tới con số của gói.
//
// Vì sao đặt ở TẦNG DỮ LIỆU chứ không rải trong từng view: mọi thao tác đều đi qua tệp này, nên
// thêm nút "xoá vĩnh viễn"/"nhân bản" ở bất kỳ view nào cũng TỰ có, không ai phải nhớ gọi
// refreshProfileCount(). Đã mất một lần vì rải tay: nút xoá vĩnh viễn trong Thùng rác gọi load()
// của riêng nó mà quên thẻ gói ⇒ hoàn slot rồi mà thẻ vẫn ghi số cũ.
//
// CHỈ gắn vào thao tác THỰC SỰ đổi số trên thẻ (app.js gộp nhịp 250ms nên gọi liên tiếp vẫn 1
// request). Cố tình KHÔNG gắn cho xoá mềm / khôi phục thùng rác: hồ sơ trong thùng rác VẪN chiếm
// slot nên hai thao tác đó không đổi con số nào - gắn vào chỉ tốn request và làm người đọc code
// tưởng xoá mềm có hoàn chỗ. Lượt MỞ được bắt ở app.js qua tín hiệu running-changed.
const bumpPlan = () => {
  try { if (window.__vtApp && window.__vtApp.bumpPlanCard) window.__vtApp.bumpPlanCard(); }
  catch { /* thẻ gói chỉ là hiển thị - không bao giờ làm hỏng thao tác chính */ }
};

export const remote = {
  groups: {
    list: () => unwrap(vt.remote.groups.list()),
    create: (g) => unwrap(vt.remote.groups.create(g)),
    update: (id, g) => unwrap(vt.remote.groups.update(id, g)),
    remove: (id) => unwrap(vt.remote.groups.remove(id)),
  },
  // Thẻ độc lập (standalone tags) - kho server thay cho customTags local.
  // list() trả mảng tên (string[]); create/rename/remove khóa theo tên.
  tags: {
    list: () => unwrap(vt.remote.tags.list()),
    create: async (name) => { const r = await unwrap(vt.remote.tags.create(name)); logActivity('add_tag', { profileName: name }); return r; },
    rename: async (oldName, newName) => { const r = await unwrap(vt.remote.tags.rename(oldName, newName)); logActivity('update_tag', { profileName: newName }); return r; },
    remove: async (name) => { const r = await unwrap(vt.remote.tags.remove(name)); logActivity('delete_tag', { profileName: name }); return r; },
  },
  profiles: {
    list: (groupId) => unwrap(vt.remote.profiles.list(groupId)),
    get: (id) => unwrap(vt.remote.profiles.get(id)),
    // Nhận payload create-view local, dịch sang shape server rồi tạo.
    create: async (payload) => {
      const created = await unwrap(vt.remote.profiles.create(toServerProfile(payload)));
      const newId = created && (created.profileId || created.id);
      await writeCookieSeed(newId, pullCookieSeed(payload)); // cookie → LOCAL, không server
      logActivity('create_profile', { profileId: newId, profileName: (payload && payload.name) || (created && created.name) });
      bumpPlan(); // chiếm thêm 1 slot ⇒ thẻ gói phải đổi số ngay
      return created;
    },
    // Sửa: tên + vân tay (nếu có) qua PATCH; nhóm (kể cả bỏ nhóm) qua move
    // (update COALESCE bỏ qua null nên không bỏ nhóm được); ghi chú/dynamic MERGE
    // để không xóa khóa khác. Vân tay chỉ gửi khi payload thực sự có (tránh ghi đè
    // rỗng); server COALESCE bỏ qua null nên gửi thiếu vân tay vẫn an toàn.
    update: async (id, payload) => {
      const p = payload || {};
      const patch = { name: p.name };
      if (p.fingerprint != null && p.fingerprint !== '') {
        const fp = parseFp(p.fingerprint);
        if (fp && Object.keys(fp).length) {
          // Cookie chỉ ghi LOCAL - chỉ đụng seed khi payload THỰC SỰ mang khóa cookies
          // (form Sửa luôn gửi; quick-edit không → tránh xoá nhầm seed đã có).
          if ('cookies' in fp) {
            const seed = typeof fp.cookies === 'string' ? fp.cookies : '';
            delete fp.cookies; // KHÔNG lên server
            await writeCookieSeed(id, seed);
          }
          patch.fingerprint = fp;
          // Đồng bộ cột `os` theo fingerprint.meta.os - đổi OS khi sửa phải cập nhật
          // cả cột os, nếu không lưới vẫn hiện icon OS cũ (server COALESCE bỏ qua null
          // nên thiếu os = giữ nguyên). Mirror toServerProfile cho parity với create.
          const os = OS_TO_ENUM[(fp.meta && fp.meta.os) || ''];
          if (os) patch.os = os;
        }
      }
      await unwrap(vt.remote.profiles.update(id, patch));
      await unwrap(vt.remote.profiles.move([id], p.groupId || null));
      const dyn = p.dynamic || {};
      if (Object.keys(dyn).length) await unwrap(vt.remote.profiles.updateDynamic(id, dyn));
      logActivity('update_profile', { profileId: id, profileName: p.name || nameFor(id) });
      return true;
    },
    // Đổi tên đơn lẻ (lưới dùng cho bulk-rename) → PATCH name.
    rename: async (id, name) => {
      const r = await unwrap(vt.remote.profiles.update(id, { name }));
      logActivity('update_profile', { profileId: id, profileName: name });
      return r;
    },
    softDelete: async (id) => {
      const r = await unwrap(vt.remote.profiles.softDelete(id));
      logActivity('delete_profile', { profileId: id, profileName: nameFor(id) });
      return r;
    },
    fingerprint: (id) => unwrap(vt.remote.profiles.fingerprint(id)),
    // "Dấu vân tay mới" - sinh vân tay mới TỪ SERVER (cùng generator với màn Tạo hồ sơ)
    // rồi PATCH thẳng qua kênh raw (chỉ fingerprint+os, KHÔNG move nhóm như update()).
    newFingerprint: async (id, os) => {
      const osEnum = os || 'windows';
      const fp = await unwrap(vt.remote.generateFingerprint(osEnum));
      // Bảo đảm fp.meta.os (dạng hiển thị 'Windows'/'macOS'…) khớp OS đã chọn - lưới
      // đọc icon OS từ cột `os`, mà server suy `os` từ fp.meta.os; thiếu/sai case →
      // cột os rỗng → icon không cập nhật. Ép đúng để icon reload sau khi lưu.
      if (fp && typeof fp === 'object') { fp.meta = fp.meta || {}; fp.meta.os = ENUM_TO_OS[osEnum] || 'Windows'; }
      await unwrap(vt.remote.profiles.update(id, { fingerprint: fp, os: osEnum }));
      logActivity('update_profile', { profileId: id, profileName: nameFor(id) });
      return fp;
    },
    // Ghi đè fingerprint đã DỰNG SẴN client-side (cùng generator + buildFpConfig với
    // màn Sửa hồ sơ) - PATCH thẳng qua kênh raw: chỉ fingerprint(+os), KHÔNG đụng
    // name/nhóm như update(). Dùng cho "Dấu vân tay mới" hàng loạt ở lưới hồ sơ để
    // vân tay sinh ra ĐÚNG BẢN CHẤT như bấm trong màn Sửa (đầy đủ meta/fpConfig/ui).
    saveFingerprint: async (id, fp, os) => {
      const patch = { fingerprint: fp };
      if (os) patch.os = os;
      await unwrap(vt.remote.profiles.update(id, patch));
      logActivity('update_profile', { profileId: id, profileName: nameFor(id) });
      return fp;
    },
    count: () => unwrap(vt.remote.profiles.count()),
    // Nhận danh sách payload create-view local ({name, groupId, fingerprint:JSON, dynamic}),
    // dịch từng cái sang shape server (giống create đơn) rồi tạo hàng loạt + ghi nhật ký.
    createBatch: async (items) => {
      const list = items || [];
      const created = await unwrap(vt.remote.profiles.createBatch(list.map(toServerProfile)));
      // Ghi cookie seed LOCAL cho từng hồ sơ vừa tạo (theo id server trả về, giữ đúng thứ tự).
      await Promise.all((created || []).map((c, i) =>
        writeCookieSeed(c && (c.profileId || c.id), pullCookieSeed(list[i]))));
      (created || []).forEach((c, i) => logActivity('create_profile', {
        profileId: c && (c.profileId || c.id),
        profileName: (list[i] && list[i].name) || (c && c.name),
      }));
      bumpPlan(); // chiếm thêm N slot ⇒ thẻ gói phải đổi số ngay
      return created;
    },
    move: async (ids, groupId) => {
      const r = await unwrap(vt.remote.profiles.move(ids, groupId));
      const names = {}; (ids || []).forEach((id) => { names[id] = nameFor(id); });
      logActivityBatch('move_group', ids || [], names);
      return r;
    },
    duplicate: async (id) => {
      const created = await unwrap(vt.remote.profiles.duplicate(id));
      logActivity('duplicate_profile', { profileId: id, profileName: nameFor(id) });
      bumpPlan(); // nhân bản CŨNG là tạo hồ sơ: chiếm thêm 1 slot
      return created;
    },
    // Quick-edit đơn lẻ từ lưới (ghi chú / proxy / thẻ) đi qua đây → phân loại theo
    // khóa để ghi đúng hành động. (Form Sửa hồ sơ đầy đủ gọi thẳng vt.remote.* nên
    // KHÔNG kích hoạt nhánh này - tránh log trùng update_profile.)
    updateDynamic: async (id, changes) => {
      const r = await unwrap(vt.remote.profiles.updateDynamic(id, changes));
      try {
        const c = changes || {};
        if (Object.keys(c).some((k) => /^proxy/i.test(k))) logActivity('update_proxy', { profileId: id, profileName: nameFor(id) });
        else if ('note' in c) logActivity('update_note', { profileId: id, profileName: nameFor(id) });
        else if ('tags' in c) logActivity('update_profile', { profileId: id, profileName: nameFor(id) });
      } catch { /* logging best-effort */ }
      return r;
    },
    softDeleteBatch: async (ids) => {
      const r = await unwrap(vt.remote.profiles.softDeleteBatch(ids));
      const names = {}; (ids || []).forEach((id) => { names[id] = nameFor(id); });
      logActivityBatch('delete_profile', ids || [], names);
      return r;
    },
    // Runtime ops chạy LOCAL (id-agnostic, không cần DB) → dùng kênh launcher sẵn có.
    open: async (id) => { try { return await unwrap(vt.remote.profiles.open(id)); } catch (e) { return { ok: false, error: e.message }; } },
    checkIp: async (id) => { try { return await unwrap(vt.remote.profiles.checkIp(id)); } catch { return { ok: false }; } },
    // Đọc cookie THẬT của hồ sơ từ file trên máy (local, không qua server envelope).
    readCookies: async (id) => { try { return await vt.remote.profiles.readCookies(id); } catch (e) { return { ok: false, error: e.message }; } },
    // Đọc cookie seed (chuỗi người dùng đã dán) từ file LOCAL - dùng để nạp lại ô Cookie
    // khi Sửa hồ sơ chưa từng mở (chưa tích luỹ cookie thật). Không bao giờ qua server.
    readCookieSeed: async (id) => { try { return await vt.remote.profiles.readCookieSeed(id); } catch { return ''; } },
    // Dọn dữ liệu hồ sơ (local): xóa cookie / xóa bộ nhớ đệm.
    clearCookies: async (id) => { try { return await vt.remote.profiles.clearCookies(id); } catch (e) { return { ok: false, error: e.message }; } },
    clearCache: async (id) => { try { return await vt.remote.profiles.clearCache(id); } catch (e) { return { ok: false, error: e.message }; } },
    close: (id) => vt.profiles.close(id),
    show: (id) => vt.profiles.show(id),
    isRunning: (id) => vt.profiles.isRunning(id),
    runningIds: () => vt.profiles.runningIds(),
    onRunningChanged: (cb) => vt.profiles.onRunningChanged(cb),
    // Hồ sơ đang lưu cookie sau khi đóng (giữ nút loading, chặn mở lại quá sớm).
    closingIds: () => (vt.profiles.closingIds ? vt.profiles.closingIds() : Promise.resolve([])),
    onClosingChanged: (cb) => (vt.profiles.onClosingChanged ? vt.profiles.onClosingChanged(cb) : null),
  },
  trash: {
    list: () => unwrap(vt.remote.trash.list()),
    restore: async (ids) => {
      const r = await unwrap(vt.remote.trash.restore(ids));
      const names = {}; (ids || []).forEach((id) => { names[id] = nameFor(id); });
      logActivityBatch('restore_profile', ids || [], names);
      return r;
    },
    // XOÁ VĨNH VIỄN = điểm DUY NHẤT hoàn slot ⇒ thẻ gói PHẢI giảm ngay tại đây, nếu không người
    // dùng xoá xong thấy số đứng yên và kết luận sản phẩm không hoàn chỗ như đã hứa.
    hardDelete: async (ids) => {
      const r = await unwrap(vt.remote.trash.hardDelete(ids));
      bumpPlan();
      return r;
    },
  },
  // ----- workspaces (bộ chọn multi-team) -----------------------------------
  // list() trả [{id,name,role,teamRole,isOwner}]; getActive/setActive lưu ở
  // settings (main), gắn header x-workspace-id mỗi request.
  workspaces: {
    list: () => unwrap(vt.remote.workspaces.list()),
    create: (body) => unwrap(vt.remote.workspaces.create(body)),
    getActive: () => unwrap(vt.remote.workspaces.getActive()),
    setActive: (id) => unwrap(vt.remote.workspaces.setActive(id)),
  },
  // ----- team ("Thành viên nhóm") - server source-of-truth -----------------
  // groups = nhóm quyền; members = thành viên đã tham gia; invites = lời mời chờ.
  // permissions() trả { role, teamRole, canManageMembers, permissions:[...], catalog }.
  team: {
    permissions: () => unwrap(vt.remote.team.permissions()),
    // { role, planName, limit, used, remaining } - remaining==null ⇒ không giới hạn.
    balance: () => unwrap(vt.remote.team.balance()),
    groups: {
      list: () => unwrap(vt.remote.team.groups.list()),
      create: (g) => unwrap(vt.remote.team.groups.create(g)),
      update: (id, g) => unwrap(vt.remote.team.groups.update(id, g)),
      remove: (id) => unwrap(vt.remote.team.groups.remove(id)),
    },
    members: {
      list: () => unwrap(vt.remote.team.members.list()),
      update: (id, m) => unwrap(vt.remote.team.members.update(id, m)),
      remove: (id) => unwrap(vt.remote.team.members.remove(id)),
    },
    invites: {
      list: (status) => unwrap(vt.remote.team.invites.list(status)),
      create: (body) => unwrap(vt.remote.team.invites.create(body)),
      revoke: (id) => unwrap(vt.remote.team.invites.revoke(id)),
      accept: (token) => unwrap(vt.remote.team.invites.accept(token)),
      // Hộp thư lời mời của tôi (chuông thông báo) + accept/decline theo id.
      mine: () => unwrap(vt.remote.team.invites.mine()),
      acceptById: (id) => unwrap(vt.remote.team.invites.acceptById(id)),
      decline: (id) => unwrap(vt.remote.team.invites.decline(id)),
    },
  },
  // ----- profile shares ("Chia sẻ hồ sơ") - server source-of-truth --------
  // create nhận { profileId | profileIds:[], email, permission:'view'|'edit'|'full' }.
  // mine = hộp thư "chia sẻ của tôi" cho chuông thông báo (accept/decline theo id).
  profileShares: {
    create: (body) => unwrap(vt.remote.profileShares.create(body)),
    listFor: (profileId) => unwrap(vt.remote.profileShares.listFor(profileId)),
    revoke: (id) => unwrap(vt.remote.profileShares.revoke(id)),
    mine: () => unwrap(vt.remote.profileShares.mine()),
    acceptById: (id) => unwrap(vt.remote.profileShares.acceptById(id)),
    decline: (id) => unwrap(vt.remote.profileShares.decline(id)),
    acceptBatch: (ids) => unwrap(vt.remote.profileShares.acceptBatch(ids)),
    declineBatch: (ids) => unwrap(vt.remote.profileShares.declineBatch(ids)),
  },
  generateFingerprint: (os) => unwrap(vt.remote.generateFingerprint(os)),
  // Pool GPU/WebGL + bộ font theo OS (server-side) cho màn Tạo hồ sơ.
  // os: enum server ('windows'|'macos'|…). Trả { gpus:[{vendor,renderer}], fonts:[{label,fonts:[]}] }.
  fingerprintPools: (os) => unwrap(vt.remote.fingerprintPools(os)),
  // Toàn bộ catalog 5 OS trong 1 lần → fetch 1 lần, cache hết ở client.
  fingerprintCatalog: () => unwrap(vt.remote.fingerprintCatalog()),
};
