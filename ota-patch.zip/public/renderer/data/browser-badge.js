// Huy hiệu "trình duyệt của hồ sơ" (icon + số phiên bản) dùng chung cho MỌI lưới hồ sơ
// (profiles.js, trash.js, …).
//
// VÌ SAO PHẢI DÙNG CHUNG: trước đây mỗi lưới tự chép một bản polyBrowserVersion() giống
// hệt nhau. Sửa một chỗ là chỗ kia lệch ngay - đúng lỗi đã tái diễn nhiều lần. Gom về
// một chỗ thì hai lưới KHÔNG THỂ lệch nhau nữa.
import { activeKernel } from './fingerprint.js';

// Engine THẬT của hồ sơ. meta.engine ('chromium'|'firefox') là nguồn chuẩn - đúng thứ
// launcher đọc để chọn nhân (xem ipc.js / browser-launcher.js). Hồ sơ tạo bằng bản app
// cũ chưa có meta.engine thì suy từ meta.browser ('Poly'|'Firefox') - thẻ "Trình duyệt"
// lúc tạo. Không đoán gì thêm: không rõ ⇒ chromium (mặc định lịch sử của app).
export function profileEngine(p) {
  const meta = (p && p.fingerprint && p.fingerprint.meta) || null;
  if (!meta) return 'chromium';
  if (meta.engine) return meta.engine === 'firefox' ? 'firefox' : 'chromium';
  return meta.browser === 'Firefox' ? 'firefox' : 'chromium';
}

// Nhãn engine dùng chung cho mọi chỗ hiển thị tên nhân.
export const ENGINE_LABEL = { chromium: 'Chromium', firefox: 'Firefox' };

// Chuẩn hoá về đúng 2 giá trị engine hợp lệ. Mọi hàm dưới đây đi qua đây để một chuỗi
// lạ (undefined, 'Firefox' hoa, …) không âm thầm rơi vào nhánh sai.
function normEngine(engine) { return engine === 'firefox' ? 'firefox' : 'chromium'; }

// Major mặc định của MỘT engine khi chưa ghim gì - nhân đang dùng CỦA ĐÚNG ENGINE ĐÓ.
// PHẢI đọc lúc render (hàm, không phải hằng): nhân đang dùng chỉ biết được sau khi
// syncActiveKernelToFingerprint() chạy lúc boot, và đổi khi người dùng tải nhân mới.
export function defaultKernelMajor(engine) {
  const k = activeKernel();
  // FIREFOX_VERSION là full ("152.0.6") → chỉ trưng major cho đồng bộ với Chromium.
  return normEngine(engine) === 'firefox'
    ? (String(k.FIREFOX_VERSION || '').split('.')[0] || '135')
    : String(k.KERNEL_MAJOR || '153');
}

// Nhãn dòng "Browser Kernel" ở bảng Tổng quan (màn tạo đơn VÀ tạo hàng loạt).
//
// TRƯỚC ĐÂY mỗi màn tự chép một bản kernelLabel(major) HARDCODE chữ "Chromium" và bỏ
// qua nhân đang chọn, nên bấm sang thẻ Firefox thì Tổng quan vẫn trơ ra
// "CGTBrowser (Chromium 140)" - vừa sai tên engine vừa sai số. Gom về đây để hai màn
// KHÔNG THỂ lệch nhau nữa (cùng lý do đã gom polyBrowserVersion ở trên).
export function kernelLabel(engine, major) {
  const e = normEngine(engine);
  const m = String(major || '').trim() || defaultKernelMajor(e);
  return m ? `CGTBrowser (${ENGINE_LABEL[e]} ${m})` : 'CGTBrowser';
}

// Major của nhân hồ sơ - badge cạnh icon ở ô tên.
// Ưu tiên NHÂN ĐÃ GHIM (meta.kernelMajor, do thẻ "Trình duyệt" lúc tạo/sửa) vì đó đúng
// là nhân launcher sẽ mở; badge phải nói thật về TỪNG hồ sơ chứ không dán chung một số.
// Hồ sơ cũ chưa ghim → rơi về nhân đang dùng CỦA ĐÚNG ENGINE ĐÓ. Trước đây luôn rơi về
// KERNEL_MAJOR (Chromium), nên hồ sơ Firefox chưa ghim bị dán số Chrome - cùng lớp lỗi
// "lẫn số giữa hai engine" đã bị bắt ở trang tạo hồ sơ.
export function polyBrowserVersion(p) {
  const pinned = p && p.fingerprint && p.fingerprint.meta && p.fingerprint.meta.kernelMajor;
  if (pinned) return String(pinned);
  return defaultKernelMajor(profileEngine(p));
}

// Tên hiển thị + icon theo engine. Hai file PNG nằm ở src/assets/ (được đóng gói kèm),
// đường dẫn tương đối 'assets/…' đúng như các icon khác của lưới.
export function polyBrowserName(p) {
  return profileEngine(p) === 'firefox' ? 'CGTBrowser Firefox' : 'CGTBrowser';
}

export function polyBrowserIcon(p) {
  return profileEngine(p) === 'firefox'
    ? 'assets/poly-browser-firefox.png'
    : 'assets/poly-browser.png';
}
