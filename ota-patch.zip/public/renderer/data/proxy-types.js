// MỘT nguồn sự thật cho MỌI combobox "Loại proxy" trong app.
//
// VÌ SAO phải gom về đây: trước ngày 2026-10-03 có SÁU danh sách rời nhau và cả sáu
// đều KHÁC nhau:
//   views/profiles.js         ['Không Sử Dụng Proxy','HTTP','SOCKS4','SOCKS5','Token','Proxy Xoay']
//   views/profiles.js (bulk)  [socks5 | https | http]              ← nhãn "Socks5", "HTTPS"
//   views/profiles.js (bật)   ['HTTP','SOCKS4','SOCKS5']
//   views/proxies.js          [socks5 | https | http]              ← dùng ở 2 chỗ
//   views/profile_create.js   ['HTTP','SOCKS4','SOCKS5']
//   views/profile_create_batch.js  ['HTTP','SOCKS4','SOCKS5']
// Người dùng mở hai màn kế nhau là thấy hai bộ chọn khác nhau cho CÙNG một khái niệm
// (chỗ thì có SOCKS4, chỗ thì không; chỗ thì gọi "HTTPS", chỗ thì "HTTP"). User chốt
// 2026-10-03: đúng BỐN item, đúng thứ tự dưới đây, ở MỌI combobox proxy.
//
// ⚠️ ĐỪNG sửa thứ tự. Thứ tự này là yêu cầu trực tiếp ("lần lượt từ trên xuống").
// ⚠️ ĐỪNG thêm lại 'Không Sử Dụng Proxy' / 'Proxy Xoay':
//    - TẮT proxy KHÔNG mất đi: vẫn còn hai lệnh riêng trong menu hồ sơ là "Không dùng
//      proxy" (giữ host/port, chỉ xoá proxyType) và "Xóa proxy ra khỏi hồ sơ" (xoá
//      sạch) - xem resetProxy() ở views/profiles.js. proxyType rỗng CHÍNH LÀ công tắc
//      tắt (db.getProfileProxyConfig trả null khi type rỗng).
//    - 'Proxy Xoay' vẫn tạo được ở tab "Proxy xoay" của trang tạo hồ sơ; nó suy ra từ
//      proxyRotateUrl chứ không cần người dùng chọn trong combobox.
//
// Giá trị ở đây CHÍNH LÀ enum `proxyType` lưu trong dynamic_data của hồ sơ, nên
// combobox dùng trực tiếp làm value (không cần bảng value→label nữa).
export const PROXY_TYPES = ['HTTP', 'SOCKS4', 'SOCKS5', 'Token'];

// Mặc định khi chưa biết gì. KHÔNG phải chuỗi rỗng: rỗng là "tắt proxy", mà combobox
// này không còn item tắt nữa.
export const PROXY_TYPE_DEFAULT = 'HTTP';

// Quy mọi giá trị CŨ/lạ về đúng một trong bốn item trên.
//
// VÌ SAO cần: customSelect hiển thị TRỐNG khi `value` không khớp option nào. Dữ liệu cũ
// có đủ loại biến thể - trang "Proxies" lưu `type` chữ thường ('http','https','socks5',
// 'ssh'), hồ sơ cũ lưu 'Proxy Xoay', API cục bộ nhận 'https'. Đưa thẳng vào combobox
// mới là ô chọn trắng trơn và người dùng tưởng mất dữ liệu.
//
// 'https' và 'ssh' gộp về HTTP - KHÔNG mất thông tin: cả hai bảng map cũ
// (PROXY_TYPE_MAP ở proxies.js / local-api.js) vốn đã gộp về 'HTTP' từ trước.
export function normalizeProxyType(raw) {
  const s = String(raw == null ? '' : raw).trim().toLowerCase();
  if (!s) return PROXY_TYPE_DEFAULT;
  if (s === 'token') return 'Token';
  if (s.startsWith('socks4')) return 'SOCKS4';
  if (s.startsWith('socks')) return 'SOCKS5';   // socks, socks5, socks5h
  return 'HTTP';                                 // http, https, ssh, 'proxy xoay', lạ
}
