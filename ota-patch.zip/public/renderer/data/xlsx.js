// Minimal, dependency-free .xlsx (OOXML/SpreadsheetML) writer.
//
// Builds a single-sheet workbook from an array-of-arrays and returns the raw bytes
// (Uint8Array) of a ZIP container. Compression method = STORE (no deflate) so we
// don't need a zip library - just the local/central headers + a CRC-32. The output
// opens cleanly in Excel / Google Sheets / LibreOffice with no format warning.
//
// Usage: buildXlsx([[ 'Header A', 'Header B' ], [ 'a1', 2 ], …]) -> Uint8Array.
// Strings are written as inline strings (t="inlineStr"); finite numbers as <v>.

const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    t[n] = c >>> 0;
  }
  return t;
})();

function crc32(bytes) {
  let c = 0xFFFFFFFF;
  for (let i = 0; i < bytes.length; i++) c = CRC_TABLE[(c ^ bytes[i]) & 0xFF] ^ (c >>> 8);
  return (c ^ 0xFFFFFFFF) >>> 0;
}

const enc = (s) => new TextEncoder().encode(s);

const NEEDS_ESC = /[&<>"']/;
function xmlEsc(v) {
  const s = v == null ? '' : String(v);
  if (!NEEDS_ESC.test(s)) return s; // fast path: most cells have no special chars
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&apos;');
}

// 0 -> "A", 25 -> "Z", 26 -> "AA" …
function colName(i) {
  let s = '';
  i += 1;
  while (i > 0) { const m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); }
  return s;
}

// Build the sheet XML. For large exports (thousands of rows × columns) we avoid
// quadratic string `+=` growth by pushing fragments into one array and join()-ing
// once, and precompute the column letters (A, B, …) instead of recomputing per cell.
function sheetXml(rows) {
  let maxCols = 0;
  for (const r of rows) if (r.length > maxCols) maxCols = r.length;
  const cols = new Array(maxCols);
  for (let i = 0; i < maxCols; i++) cols[i] = colName(i);

  const out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
    '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>'];
  for (let r = 0; r < rows.length; r++) {
    const row = rows[r];
    const rn = r + 1;
    out.push('<row r="', rn, '">');
    for (let c = 0; c < row.length; c++) {
      const val = row[c];
      const ref = cols[c] + rn;
      if (typeof val === 'number' && Number.isFinite(val)) {
        out.push('<c r="', ref, '"><v>', val, '</v></c>');
      } else {
        out.push('<c r="', ref, '" t="inlineStr"><is><t xml:space="preserve">', xmlEsc(val), '</t></is></c>');
      }
    }
    out.push('</row>');
  }
  out.push('</sheetData></worksheet>');
  return out.join('');
}

const CONTENT_TYPES = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
  + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
  + '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
  + '<Default Extension="xml" ContentType="application/xml"/>'
  + '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
  + '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
  + '</Types>';

const RELS = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
  + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
  + '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
  + '</Relationships>';

const WORKBOOK = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
  + '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
  + '<sheets><sheet name="Ho so" sheetId="1" r:id="rId1"/></sheets></workbook>';

const WB_RELS = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
  + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
  + '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
  + '</Relationships>';

// Assemble a STORE-only ZIP from [{ name, data:Uint8Array }].
function zip(files) {
  const u16 = (n) => [n & 0xFF, (n >>> 8) & 0xFF];
  const u32 = (n) => [n & 0xFF, (n >>> 8) & 0xFF, (n >>> 16) & 0xFF, (n >>> 24) & 0xFF];
  const parts = [];
  const central = [];
  let offset = 0;
  for (const f of files) {
    const nameBytes = enc(f.name);
    const crc = crc32(f.data);
    const size = f.data.length;
    const local = new Uint8Array([
      ...u32(0x04034b50), ...u16(20), ...u16(0), ...u16(0), ...u16(0), ...u16(0),
      ...u32(crc), ...u32(size), ...u32(size), ...u16(nameBytes.length), ...u16(0),
    ]);
    parts.push(local, nameBytes, f.data);
    central.push(new Uint8Array([
      ...u32(0x02014b50), ...u16(20), ...u16(20), ...u16(0), ...u16(0), ...u16(0), ...u16(0),
      ...u32(crc), ...u32(size), ...u32(size), ...u16(nameBytes.length), ...u16(0), ...u16(0),
      ...u16(0), ...u16(0), ...u32(0), ...u32(offset),
    ]), nameBytes);
    offset += local.length + nameBytes.length + size;
  }
  let centralSize = 0;
  for (const c of central) centralSize += c.length;
  const eocd = new Uint8Array([
    ...u32(0x06054b50), ...u16(0), ...u16(0), ...u16(files.length), ...u16(files.length),
    ...u32(centralSize), ...u32(offset), ...u16(0),
  ]);
  const all = [...parts, ...central, eocd];
  let total = 0;
  for (const a of all) total += a.length;
  const out = new Uint8Array(total);
  let p = 0;
  for (const a of all) { out.set(a, p); p += a.length; }
  return out;
}

export function buildXlsx(rows) {
  return zip([
    { name: '[Content_Types].xml', data: enc(CONTENT_TYPES) },
    { name: '_rels/.rels', data: enc(RELS) },
    { name: 'xl/workbook.xml', data: enc(WORKBOOK) },
    { name: 'xl/_rels/workbook.xml.rels', data: enc(WB_RELS) },
    { name: 'xl/worksheets/sheet1.xml', data: enc(sheetXml(rows)) },
  ]);
}
