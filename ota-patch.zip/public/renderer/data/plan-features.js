// Bộ nhớ đệm TÍNH NĂNG theo gói của workspace hiện tại. Gói Free cắt vài tính năng
// (features[k] === false); các gói trả phí bật hết. Fetch một lần rồi cache để view
// gọi hasFeature() đồng bộ khi dựng UI.
//
// ĐÂY CHỈ LÀ UX (hiện modal nâng cấp cho gọn đường), KHÔNG phải bảo vệ - nên hàm
// hasFeature() cố ý fail-OPEN khi chưa nạp được: thà lỡ hiện nút rồi ăn lỗi 403 hơn
// là chặn oan khách đã trả tiền. Chỗ enforce THẬT nằm ở:
//   • server/src/lib/plan-features.js  → POST /workspaces ('workspace'),
//     POST /profile-shares ('share')
//   • src/main/plan-gate.js            → API cục bộ 127.0.0.1:51001 ('api')
// Thêm cổng mới ở đây thì PHẢI thêm cả ở một trong hai chỗ trên, không thì nó chỉ là
// cái nút bị ẩn - gọi thẳng HTTP là xong.
import { openUpgradeModal, toast } from '../ui.js';

let _cache = null; // { planCode, planName, features:{}, expired }

// Nhãn tính năng (khớp upgrade.js FEATURE_LABELS) - dùng ghép câu phụ đề modal.
export const FEATURE_LABELS = {
  share: 'Chia sẻ hồ sơ',
  market_publish: 'Đăng chợ kịch bản',
  workspace: 'Tạo không gian làm việc',
  api: 'Sử dụng API cục bộ',
  // "Dấu vân tay mới" (lưới hồ sơ + màn Tạo/Sửa/Tạo hàng loạt) - gói Free bị cắt, CHỈ chặn ở app bằng modal nâng cấp
  // (chủ sở hữu 2026-10-30: "chặn hiển thị modal bắt nâng cấp như tạo không gian làm việc là được").
  new_fingerprint: 'Dấu vân tay mới',
};

// Nạp (và cache) tính năng của gói đang dùng. force=true để làm mới sau khi đổi gói.
export async function loadPlanFeatures(force = false) {
  if (_cache && !force) return _cache;
  try {
    const [sub, plans] = await Promise.all([
      vt.billing.subscription(),
      vt.billing.plans(),
    ]);
    const code = sub && sub.plan_code;
    const plan = (plans || []).find((p) => p.code === code) || null;
    _cache = {
      planCode: code || null,
      planName: (plan && plan.name) || null,
      features: (plan && plan.features) || {},
      // HẾT HẠN = điều kiện ĐẦU TIÊN: gói (của tài khoản người mua) hết hạn → coi như
      // KHÔNG có tính năng nào (kể cả chủ sở hữu), dù số dư hồ sơ còn. Server cũng chặn.
      expired: !!(sub && sub.expired),
    };
  } catch {
    // Không tải được → coi như đủ tính năng (không chặn nhầm, server vẫn enforce).
    _cache = { planCode: null, planName: null, features: {}, expired: false };
  }
  return _cache;
}

// Ảnh chụp đồng bộ (null nếu chưa nạp).
export function planFeaturesSync() { return _cache; }

// Gói đang hết hạn? (đồng bộ; false khi chưa nạp).
export function isPlanExpired() { return !!(_cache && _cache.expired); }

// Tính năng `key` có khả dụng ở gói hiện tại không. Mặc định khi chưa nạp = true
// (tránh chặn nhầm; sẽ nạp nền qua ensurePlanFeatures ở app khởi động).
// HẾT HẠN → mọi tính năng đều KHÔNG khả dụng.
export function hasFeature(key) {
  if (!_cache) return true;
  if (_cache.expired) return false;
  return _cache.features[key] !== false;
}

// Xóa cache (gọi khi đăng xuất / đổi tài khoản / đổi workspace / đổi gói).
export function clearPlanFeatures() { _cache = null; }

// Cổng tính năng gói Free: nếu `key` khả dụng → chạy onAllowed() và trả true; nếu bị
// giới hạn → hiện modal nâng cấp (nút "Nâng cấp ngay bây giờ" mở trang Nâng cấp) và
// trả false. Dùng ở nút/điểm vào của tính năng bị gói Free cắt.
//   gateFeature('rpa', { onAllowed: () => openRpa() })
export async function gateFeature(key, { onAllowed, featureLabel, navigate } = {}) {
  await loadPlanFeatures();
  // HẾT HẠN có ưu tiên cao hơn: hiện nhắc GIA HẠN (không phải "nâng cấp").
  if (isPlanExpired()) { showRenewModal(navigate); return false; }
  if (hasFeature(key)) {
    if (typeof onAllowed === 'function') onAllowed();
    return true;
  }
  openUpgradeModal({
    title: 'Bạn cần nâng cấp gói để sử dụng tính năng',
    onUpgrade: () => {
      const nav = navigate || (window.__vtApp && window.__vtApp.navigate);
      if (typeof nav === 'function') nav('upgrade');
      else toast('Mở mục Nâng cấp gói ở thanh bên để nâng cấp.', '');
    },
  });
  return false;
}

// Cổng CHUNG cho HÀNH ĐỘNG bất kỳ (không gắn feature key), vd MỞ hồ sơ / chạy RPA:
// nếu gói hết hạn → hiện nhắc Gia hạn và trả false; còn hạn → chạy onAllowed() trả true.
// Điều kiện ĐẦU TIÊN là hạn thuê bao (rồi mới đến số dư hồ sơ ở nơi khác).
export async function gateNotExpired({ onAllowed, navigate } = {}) {
  await loadPlanFeatures();
  if (isPlanExpired()) { showRenewModal(navigate); return false; }
  if (typeof onAllowed === 'function') onAllowed();
  return true;
}

// Modal nhắc Gia hạn (nút mở trang Nâng cấp/Gia hạn).
function showRenewModal(navigate) {
  openUpgradeModal({
    title: 'Gói thuê bao đã hết hạn - vui lòng gia hạn để tiếp tục sử dụng',
    buttonText: 'Gia hạn ngay',
    onUpgrade: () => {
      const nav = navigate || (window.__vtApp && window.__vtApp.navigate);
      if (typeof nav === 'function') nav('upgrade');
      else toast('Mở mục Nâng cấp gói ở thanh bên để gia hạn.', '');
    },
  });
}
