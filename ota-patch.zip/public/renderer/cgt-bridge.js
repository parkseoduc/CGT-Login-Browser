/* ============================================================================
 * CGT-Login v2.0 (CGTBrowser) — Core ↔ Renderer Bridge (`window.vt`)
 * Connects PolyLogin ES-Module UI (`public/renderer/*`) to:
 *   1) CGT Core v2 REST API + Realtime SSE (`/api/v1/events/stream`)
 *   2) Electron Native Bridge (`window.cgt` & `window.electronAPI`)
 *   3) Seamless Core v1 + Browser-mode fallbacks (zero data loss, zero 404 errors)
 * ============================================================================ */
(function initCgtBridge() {
  'use strict';

  const API_ORIGIN = (typeof window !== 'undefined' && window.location && /^https?:/i.test(window.location.origin))
    ? window.location.origin
    : 'http://127.0.0.1:51888';
  const API_BASE = API_ORIGIN + '/api/v1';

  const TOKEN_KEY = 'cgt_auth_token';
  const ACCOUNT_KEY = 'cgt_auth_account';
  const CRED_KEY = 'cgt_saved_cred';
  const SETTINGS_KEY = 'cgt_ui_settings_v2';
  const DYN_META_KEY = 'cgt_profile_meta_v2';
  const COOKIE_SEED_KEY = 'cgt_cookie_seeds_v2';
  const SOFT_TRASH_KEY = 'cgt_soft_trash_v1';
  const TAGS_KEY = 'cgt_standalone_tags_v2';
  const FLOWS_KEY = 'cgt_rpa_flows_v2';
  const TASKS_KEY = 'cgt_rpa_tasks_v2';
  const SCHEDS_KEY = 'cgt_rpa_schedules_v2';
  const RUNLOGS_KEY = 'cgt_rpa_runlogs_v2';
  const ACTLOG_KEY = 'cgt_activity_logs_v2';
  const PROXIES_META_KEY = 'cgt_proxies_meta_v2';
  const TEAM_GROUPS_KEY = 'cgt_team_groups_v2';
  const TEAM_INVITES_KEY = 'cgt_team_invites_v2';
  const WORKSPACES_KEY = 'cgt_workspaces_v2';
  const CLOUD_STATE_KEY = 'cgt_cloud_sync_state_v2';
  const MKT_OWNED_KEY = 'cgt_market_owned_v2';
  const MKT_DEV_KEY = 'cgt_market_dev_v2';

  // ---- Safe JSON storage helpers --------------------------------------------
  function readJson(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch {
      return fallback;
    }
  }
  function writeJson(key, val) {
    try { localStorage.setItem(key, JSON.stringify(val)); } catch { /* ignore */ }
    return val;
  }

  // ---- Pure-JS RFC 1321 MD5 (for 32-hex `profileId`) ------------------------
  function md5Hex(input) {
    const str = unescape(encodeURIComponent(String(input == null ? '' : input)));
    function rotl(x, c) { return (x << c) | (x >>> (32 - c)); }
    function add(x, y) { return ((x & 0x7fffffff) + (y & 0x7fffffff)) ^ (x & 0x80000000) ^ (y & 0x80000000); }
    function cmn(q, a, b, x, s, t) { return add(rotl(add(add(a, q), add(x, t)), s), b); }
    function ff(a, b, c, d, x, s, t) { return cmn((b & c) | ((~b) & d), a, b, x, s, t); }
    function gg(a, b, c, d, x, s, t) { return cmn((b & d) | (c & (~d)), a, b, x, s, t); }
    function hh(a, b, c, d, x, s, t) { return cmn(b ^ c ^ d, a, b, x, s, t); }
    function ii(a, b, c, d, x, s, t) { return cmn(c ^ (b | (~d)), a, b, x, s, t); }

    const n = str.length;
    const tail = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
    const state = [1732584193, -271733879, -1732584194, 271733878];

    function cycle(x, k) {
      let a = x[0], b = x[1], c = x[2], d = x[3];
      a = ff(a, b, c, d, k[0], 7, -680876936); d = ff(d, a, b, c, k[1], 12, -389564586); c = ff(c, d, a, b, k[2], 17, 606105819); b = ff(b, c, d, a, k[3], 22, -1044525330);
      a = ff(a, b, c, d, k[4], 7, -176418897); d = ff(d, a, b, c, k[5], 12, 1200080426); c = ff(c, d, a, b, k[6], 17, -1473231341); b = ff(b, c, d, a, k[7], 22, -45705983);
      a = ff(a, b, c, d, k[8], 7, 1770035416); d = ff(d, a, b, c, k[9], 12, -1958414417); c = ff(c, d, a, b, k[10], 17, -42063); b = ff(b, c, d, a, k[11], 22, -1990404162);
      a = ff(a, b, c, d, k[12], 7, 1804603682); d = ff(d, a, b, c, k[13], 12, -40341101); c = ff(c, d, a, b, k[14], 17, -1502002290); b = ff(b, c, d, a, k[15], 22, 1236535329);
      a = gg(a, b, c, d, k[1], 5, -165796510); d = gg(d, a, b, c, k[6], 9, -1069501632); c = gg(c, d, a, b, k[11], 14, 643717713); b = gg(b, c, d, a, k[0], 20, -373897302);
      a = gg(a, b, c, d, k[5], 5, -701558691); d = gg(d, a, b, c, k[10], 9, 38016083); c = gg(c, d, a, b, k[15], 14, -660478335); b = gg(b, c, d, a, k[4], 20, -405537848);
      a = gg(a, b, c, d, k[9], 5, 568446438); d = gg(d, a, b, c, k[14], 9, -1019803690); c = gg(c, d, a, b, k[3], 14, -187363961); b = gg(b, c, d, a, k[8], 20, 1163531501);
      a = gg(a, b, c, d, k[13], 5, -1444681467); d = gg(d, a, b, c, k[2], 9, -51403784); c = gg(c, d, a, b, k[7], 14, 1735328473); b = gg(b, c, d, a, k[12], 20, -1926607734);
      a = hh(a, b, c, d, k[5], 4, -378558); d = hh(d, a, b, c, k[8], 11, -2022574463); c = hh(c, d, a, b, k[11], 16, 1839030562); b = hh(b, c, d, a, k[14], 23, -35309556);
      a = hh(a, b, c, d, k[1], 4, -1530992060); d = hh(d, a, b, c, k[4], 11, 1272893353); c = hh(c, d, a, b, k[7], 16, -155497632); b = hh(b, c, d, a, k[10], 23, -1094730640);
      a = hh(a, b, c, d, k[13], 4, 681279174); d = hh(d, a, b, c, k[0], 11, -358537222); c = hh(c, d, a, b, k[3], 16, -722521979); b = hh(b, c, d, a, k[6], 23, 76029189);
      a = hh(a, b, c, d, k[9], 4, -640364487); d = hh(d, a, b, c, k[12], 11, -421815835); c = hh(c, d, a, b, k[15], 16, 530742520); b = hh(b, c, d, a, k[2], 23, -995338651);
      a = ii(a, b, c, d, k[0], 6, -198630844); d = ii(d, a, b, c, k[7], 10, 1126891415); c = ii(c, d, a, b, k[14], 15, -1416354905); b = ii(b, c, d, a, k[5], 21, -57434055);
      a = ii(a, b, c, d, k[12], 6, 1700485571); d = ii(d, a, b, c, k[3], 10, -1894986606); c = ii(c, d, a, b, k[10], 15, -1051523); b = ii(b, c, d, a, k[1], 21, -2054922799);
      a = ii(a, b, c, d, k[8], 6, 1873313359); d = ii(d, a, b, c, k[15], 10, -30611744); c = ii(c, d, a, b, k[6], 15, -1560198380); b = ii(b, c, d, a, k[13], 21, 1309151649);
      a = ii(a, b, c, d, k[4], 6, -145523070); d = ii(d, a, b, c, k[11], 10, -1120210379); c = ii(c, d, a, b, k[2], 15, 718787259); b = ii(b, c, d, a, k[9], 21, -343485551);
      x[0] = add(a, x[0]); x[1] = add(b, x[1]); x[2] = add(c, x[2]); x[3] = add(d, x[3]);
    }

    let i;
    for (i = 64; i <= n; i += 64) {
      const blk = [];
      for (let j = 0; j < 64; j += 4) {
        const p = i - 64 + j;
        blk.push(str.charCodeAt(p) | (str.charCodeAt(p + 1) << 8) | (str.charCodeAt(p + 2) << 16) | (str.charCodeAt(p + 3) << 24));
      }
      cycle(state, blk);
    }
    i -= 64;
    for (let j = 0; i < n; i++, j++) tail[j >> 2] |= str.charCodeAt(i) << ((j & 3) << 3);
    const rem = n & 63;
    tail[rem >> 2] |= 0x80 << ((rem & 3) << 3);
    if (rem > 55) {
      cycle(state, tail);
      for (let j = 0; j < 16; j++) tail[j] = 0;
    }
    tail[14] = n * 8;
    cycle(state, tail);

    const hex = '0123456789abcdef';
    let out = '';
    for (let k = 0; k < 4; k++) {
      const v = state[k];
      for (let b = 0; b < 4; b++) out += hex[(v >> (b * 8 + 4)) & 0x0f] + hex[(v >> (b * 8)) & 0x0f];
    }
    return out;
  }

  // ---- Pub/Sub Bus ----------------------------------------------------------
  const listeners = new Map();
  function onEvent(channel, cb) {
    if (!listeners.has(channel)) listeners.set(channel, new Set());
    listeners.get(channel).add(cb);
    return () => { const s = listeners.get(channel); if (s) s.delete(cb); };
  }
  function emitEvent(channel, payload) {
    const s = listeners.get(channel);
    if (!s) return;
    s.forEach((cb) => { try { cb(payload); } catch { /* ignore */ } });
  }

  // ---- HTTP Client (`apiFetch`) ---------------------------------------------
  function getToken() {
    try { return localStorage.getItem(TOKEN_KEY) || ''; } catch { return ''; }
  }
  function setToken(tok) {
    try {
      if (tok) localStorage.setItem(TOKEN_KEY, tok);
      else localStorage.removeItem(TOKEN_KEY);
    } catch { /* ignore */ }
  }

  async function apiFetch(endpoint, opts = {}) {
    const url = endpoint.startsWith('http')
      ? endpoint
      : ((endpoint.startsWith('/api/') || endpoint.startsWith('/v3/') || endpoint === '/mcp')
          ? API_ORIGIN + endpoint
          : API_BASE + (endpoint.startsWith('/') ? endpoint : '/' + endpoint));
    const headers = Object.assign({ 'Content-Type': 'application/json' }, opts.headers || {});
    const tok = getToken();
    if (tok && !headers.Authorization) headers.Authorization = 'Bearer ' + tok;
    const wsActive = readJson(WORKSPACES_KEY, {}).activeId;
    if (wsActive && !headers['x-workspace-id']) headers['x-workspace-id'] = wsActive;

    const init = {
      method: opts.method || 'GET',
      headers,
    };
    if (opts.body !== undefined) {
      init.body = typeof opts.body === 'string' ? opts.body : JSON.stringify(opts.body);
    }
    const res = await fetch(url, init);
    let json = null;
    try { json = await res.json(); } catch { json = null; }
    return { status: res.status, okHttp: res.ok, json };
  }

  // Wrap result into PolyLogin remoteCall envelope `{ ok, data, error, code, status }`
  function okEnv(data) { return { ok: true, data }; }
  function errEnv(error, code = 'ERROR', status = 400) { return { ok: false, error: error || 'Lỗi không xác định', code, status }; }

  // ---- Live Runtime State (runningIds, closingIds, SSE + fallback) ----------
  const runtime = {
    runningIds: [],
    closingIds: [],
    sseConnected: false,
    v2TrashSupported: null, // null=unknown, true=v2 /api/v1/trash, false=v1 soft-trash fallback
    v2RpaSupported: null,
    consolePopup: null,
  };

  function setRunningIds(ids) {
    const next = Array.from(new Set((Array.isArray(ids) ? ids : []).map(String).filter(Boolean)));
    const prevKey = runtime.runningIds.slice().sort().join(',');
    const nextKey = next.slice().sort().join(',');
    runtime.runningIds = next;
    if (prevKey !== nextKey) {
      emitEvent('profile:running-changed', runtime.runningIds.slice());
      broadcastConsole({ type: 'running', ids: runtime.runningIds.slice() });
    }
  }
  function setClosingIds(ids) {
    const next = Array.from(new Set((Array.isArray(ids) ? ids : []).map(String).filter(Boolean)));
    const prevKey = runtime.closingIds.slice().sort().join(',');
    const nextKey = next.slice().sort().join(',');
    runtime.closingIds = next;
    if (prevKey !== nextKey) emitEvent('profile:closing-changed', runtime.closingIds.slice());
  }

  // BroadcastChannel for Console popup synchronization
  let consoleChan = null;
  try {
    if (typeof BroadcastChannel !== 'undefined') {
      consoleChan = new BroadcastChannel('cgt_sync_console_v2');
      consoleChan.onmessage = (ev) => {
        const d = ev && ev.data;
        if (!d) return;
        if (d.type === 'scope') emitEvent('console:scope', d.ids || []);
        else if (d.type === 'collapse') emitEvent('console:collapse');
        else if (d.type === 'closed') emitEvent('console:closed');
        else if (d.type === 'running') emitEvent('profile:running-changed', d.ids || []);
        else if (d.type === 'sync:status') emitEvent('actionsync:status', d.status);
      };
    }
  } catch { /* ignore */ }

  function broadcastConsole(msg) {
    try { if (consoleChan) consoleChan.postMessage(msg); } catch { /* ignore */ }
  }

  // Connect SSE `/api/v1/events/stream` with graceful fallback to `/api/v1/status`
  function connectRealtime() {
    if (typeof EventSource === 'undefined') {
      startFallbackStatusPoll();
      return;
    }
    let probeDone = false;
    fetch(API_BASE + '/events/stream', { method: 'GET', headers: { Accept: 'text/event-stream' } })
      .then((res) => {
        if (!res.ok) {
          startFallbackStatusPoll();
          return;
        }
        try { if (res.body && res.body.cancel) res.body.cancel(); } catch { /* ignore */ }
        probeDone = true;
        const es = new EventSource(API_BASE + '/events/stream');
        runtime.sseConnected = true;
        es.addEventListener('profile:state', (e) => {
          try {
            const p = JSON.parse(e.data || '{}');
            if (Array.isArray(p.runningIds)) setRunningIds(p.runningIds);
            if (Array.isArray(p.closingIds)) setClosingIds(p.closingIds);
          } catch { /* ignore */ }
        });
        es.addEventListener('sync:status', (e) => {
          try {
            const st = normalizeSyncStatus(JSON.parse(e.data || '{}'));
            emitEvent('actionsync:status', st);
            broadcastConsole({ type: 'sync:status', status: st });
          } catch { /* ignore */ }
        });
        es.addEventListener('rpa:log', (e) => {
          try {
            const d = JSON.parse(e.data || '{}');
            emitEvent('rpa:log', {
              runId: d.runId,
              entry: d.entry || {
                ts: d.time || Date.now(),
                level: d.level || 'info',
                title: d.nodeId || d.profileName || 'RPA',
                msg: d.message || d.msg || '',
              },
            });
          } catch { /* ignore */ }
        });
        es.addEventListener('cloud:progress', (e) => {
          try {
            const d = JSON.parse(e.data || '{}');
            emitEvent('sync:progress', { id: d.profileId || d.id, phase: d.phase, message: d.message || '' });
          } catch { /* ignore */ }
        });
        es.addEventListener('kernel:progress', (e) => {
          try {
            const d = JSON.parse(e.data || '{}');
            const phaseMap = { downloading: 'download', verifying: 'verify', extracting: 'extract', done: 'done', error: 'error' };
            emitEvent('kernel:progress', Object.assign({}, d, { phase: phaseMap[d.phase] || d.phase }));
          } catch { /* ignore */ }
        });
        es.onerror = () => {
          runtime.sseConnected = false;
          try { es.close(); } catch { /* ignore */ }
          startFallbackStatusPoll();
        };
      })
      .catch(() => {
        if (!probeDone) startFallbackStatusPoll();
      });
  }

  let pollTimer = null;
  function startFallbackStatusPoll() {
    if (pollTimer) return;
    const tick = async () => {
      try {
        const { okHttp, json } = await apiFetch('/status');
        if (okHttp && json && Array.isArray(json.runningProfiles)) {
          const ids = json.runningProfiles.map((x) => (typeof x === 'string' ? x : (x && (x.profileId || x.id)))).filter(Boolean);
          setRunningIds(ids);
        }
      } catch { /* ignore */ }
    };
    tick();
    pollTimer = setInterval(tick, 3500);
  }

  if (typeof window !== 'undefined') {
    setTimeout(connectRealtime, 120);
  }

  // ---- Profile & Fingerprint Mapping Helpers --------------------------------
  const ENUM_TO_OS = { windows: 'Windows', macos: 'macOS', mac: 'macOS', linux: 'Linux', android: 'Android', ios: 'iOS' };
  const OS_TO_ENUM = { Windows: 'windows', macOS: 'macos', Mac: 'macos', Linux: 'linux', Android: 'android', iOS: 'ios' };

  function fmtDateTimeSql(iso) {
    if (!iso) return '-';
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return String(iso);
    const p = (n) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
  }

  function parseFpObj(raw) {
    if (!raw) return {};
    if (typeof raw === 'object') return Object.assign({}, raw);
    try { return JSON.parse(raw) || {}; } catch { return {}; }
  }

  function mapServerProfile(row, groupsById) {
    if (!row) return null;
    const id = String(row.id);
    const localDynAll = readJson(DYN_META_KEY, {});
    const localDyn = localDynAll[id] || {};
    const srvMeta = (row.metadata && typeof row.metadata === 'object')
      ? row.metadata
      : (typeof row.metadata === 'string' ? parseFpObj(row.metadata) : {});
    const meta = Object.assign({}, localDyn, srvMeta);

    const fp = parseFpObj(row.fingerprint);
    const rawOs = String(row.os || (fp.meta && fp.meta.os) || fp.os || 'windows').toLowerCase();
    const osProper = ENUM_TO_OS[rawOs] || 'Windows';
    const engine = (row.kernelEngine || (fp.meta && fp.meta.engine) || ((fp.meta && fp.meta.browser === 'Firefox') ? 'firefox' : 'chromium')) === 'firefox'
      ? 'firefox'
      : 'chromium';
    const kernelMajor = row.kernelMajor
      || (fp.meta && fp.meta.kernelMajor)
      || (fp.chromeVersion ? String(fp.chromeVersion).split('.')[0] : '')
      || (engine === 'firefox' ? '135' : '153');

    if (!fp.meta || typeof fp.meta !== 'object') {
      fp.meta = {
        os: osProper,
        engine,
        browser: engine === 'firefox' ? 'Firefox' : 'Poly',
        kernelMajor: String(kernelMajor),
      };
    } else {
      if (!fp.meta.os) fp.meta.os = osProper;
      if (!fp.meta.engine) fp.meta.engine = engine;
      if (!fp.meta.kernelMajor) fp.meta.kernelMajor = String(kernelMajor);
    }

    const groupId = row.group_id !== undefined ? row.group_id : (row.groupId || null);
    const groupObj = groupId && groupsById ? groupsById.get(String(groupId)) : null;
    const groupName = row.group_name || (groupObj && groupObj.name) || row.group || 'Chưa phân nhóm';

    let rawTags = meta.tags !== undefined ? meta.tags : row.tags;
    if (typeof rawTags === 'string' && rawTags.trim().startsWith('[')) {
      try { rawTags = JSON.parse(rawTags); } catch { rawTags = []; }
    }
    const tagsStr = Array.isArray(rawTags)
      ? rawTags.map((x) => String(x == null ? '' : x).trim()).filter(Boolean).join(', ')
      : String(rawTags || '');

    const proxyType = meta.proxyType !== undefined ? meta.proxyType : (row.proxy_type ? String(row.proxy_type).toUpperCase() : '');
    const proxyHost = meta.proxyHost !== undefined ? meta.proxyHost : (row.proxy_host || '');
    const proxyPort = meta.proxyPort !== undefined ? String(meta.proxyPort || '') : (row.proxy_port ? String(row.proxy_port) : '');
    const proxyUser = meta.proxyUser !== undefined ? meta.proxyUser : (row.proxy_user || '');
    const proxyPass = meta.proxyPass !== undefined ? meta.proxyPass : (row.proxy_pass || '');
    const proxyRotateUrl = meta.proxyRotateUrl !== undefined ? meta.proxyRotateUrl : (row.proxy_rotation_api_url || '');

    const isRunning = !!(row.running || row.isRunning || runtime.runningIds.includes(id));

    return {
      id,
      profileId: row.profileId || md5Hex(id),
      name: row.name || 'Profile',
      os: osProper,
      groupId: groupId || null,
      group: groupName,
      note: meta.note !== undefined ? meta.note : (row.notes || row.note || ''),
      tags: tagsStr,
      proxyId: row.proxy_id || meta.proxyId || null,
      proxyType,
      proxyHost,
      proxyPort,
      proxyUser,
      proxyPass,
      proxyRotateUrl,
      proxyToken: meta.proxyToken || '',
      geoIp: meta.geoIp || row.geoIp || '',
      geoCountry: meta.geoCountry || row.geoCountry || '',
      geoRegion: meta.geoRegion || row.geoRegion || '',
      geoCity: meta.geoCity || row.geoCity || '',
      startUrl: meta.startUrl !== undefined ? meta.startUrl : (row.start_url || ''),
      resourceType: meta.resourceType || '',
      resourceFormat: meta.resourceFormat || '',
      resourceAccount: meta.resourceAccount || '',
      storage: row.storage || meta.storage || (row.cloudSynced ? (meta.cloudDest || 'gdrive') : 'local'),
      running: isRunning,
      closing: !!(row.closing || runtime.closingIds.includes(id)),
      slot: row.slot || null,
      lastRunAtIso: row.last_run_at || row.lastRunAtIso || '',
      createdAt: fmtDateTimeSql(row.created_at || row.createdAt),
      deletedAt: row.deleted_at ? fmtDateTimeSql(row.deleted_at) : (row.deletedAt || ''),
      fingerprint: fp,
    };
  }

  async function fetchGroupsMap() {
    const map = new Map();
    try {
      const { okHttp, json } = await apiFetch('/groups');
      const arr = (json && (json.data || json.groups)) || [];
      if (okHttp && Array.isArray(arr)) {
        arr.forEach((g) => { if (g && g.id) map.set(String(g.id), g); });
      }
    } catch { /* ignore */ }
    return map;
  }

  // Ensure inline proxy in profile metadata is also synced to `/api/v1/proxies` so Core v1 launcher uses it!
  async function resolveProxyIdForMeta(meta, existingProxyId) {
    if (!meta) return existingProxyId;
    const pType = String(meta.proxyType || '').trim();
    if (!pType) return null; // "Không Sử Dụng Proxy"
    if (!meta.proxyHost || !meta.proxyPort) return existingProxyId || null;
    const body = {
      name: `${pType.toUpperCase()} ${meta.proxyHost}:${meta.proxyPort}`,
      type: pType.toLowerCase().startsWith('socks4') ? 'socks4' : (pType.toLowerCase().startsWith('socks') ? 'socks5' : 'http'),
      host: String(meta.proxyHost).trim(),
      port: parseInt(meta.proxyPort, 10) || 8080,
      username: meta.proxyUser || '',
      password: meta.proxyPass || '',
      rotation_api_url: meta.proxyRotateUrl || '',
    };
    try {
      if (existingProxyId) {
        const u = await apiFetch(`/proxies/${encodeURIComponent(existingProxyId)}`, { method: 'PUT', body });
        if (u.okHttp) return existingProxyId;
      }
      const c = await apiFetch('/proxies', { method: 'POST', body });
      const created = c.json && (c.json.data || c.json.proxy);
      if (c.okHttp && created && created.id) return created.id;
    } catch { /* ignore */ }
    return existingProxyId || null;
  }

  function saveLocalDynPatch(id, patch) {
    if (!id || !patch) return;
    const all = readJson(DYN_META_KEY, {});
    all[id] = Object.assign({}, all[id] || {}, patch);
    writeJson(DYN_META_KEY, all);
  }

  // ---- Fingerprint Generator & GPU/Font Catalog -----------------------------
  const FP_POOLS = {
    windows: {
      gpus: [
        { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Direct3D11 vs_5_0 ps_5_0, D3D11)' },
        { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 4070 Direct3D11 vs_5_0 ps_5_0, D3D11)' },
        { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce GTX 1660 SUPER Direct3D11 vs_5_0 ps_5_0, D3D11)' },
        { vendor: 'Google Inc. (Intel)', renderer: 'ANGLE (Intel, Intel(R) Iris(R) Xe Graphics Direct3D11 vs_5_0 ps_5_0, D3D11)' },
        { vendor: 'Google Inc. (AMD)', renderer: 'ANGLE (AMD, AMD Radeon RX 6700 XT Direct3D11 vs_5_0 ps_5_0, D3D11)' },
      ],
      fonts: [{ label: 'Windows 11 Standard', fonts: ['Segoe UI', 'Arial', 'Calibri', 'Cambria', 'Consolas', 'Tahoma', 'Times New Roman', 'Verdana'] }],
    },
    macos: {
      gpus: [
        { vendor: 'Google Inc. (Apple)', renderer: 'ANGLE (Apple, ANGLE Metal Renderer: Apple M3, Unspecified Version)' },
        { vendor: 'Google Inc. (Apple)', renderer: 'ANGLE (Apple, ANGLE Metal Renderer: Apple M2 Pro, Unspecified Version)' },
        { vendor: 'Google Inc. (Apple)', renderer: 'ANGLE (Apple, ANGLE Metal Renderer: Apple M1, Unspecified Version)' },
      ],
      fonts: [{ label: 'macOS Sonoma Standard', fonts: ['SF Pro Text', 'Helvetica Neue', 'Menlo', 'Monaco', 'Avenir', 'Gill Sans', 'Lucida Grande'] }],
    },
    linux: {
      gpus: [
        { vendor: 'Google Inc. (Intel)', renderer: 'ANGLE (Intel, Mesa Intel(R) UHD Graphics 770 (ADL-S GT1), OpenGL 4.6)' },
        { vendor: 'Google Inc. (AMD)', renderer: 'ANGLE (AMD, AMD Radeon Graphics (renoir, LLVM 15.0.7, DRM 3.49), OpenGL 4.6)' },
      ],
      fonts: [{ label: 'Ubuntu Desktop', fonts: ['Ubuntu', 'DejaVu Sans', 'Liberation Sans', 'Noto Sans', 'FreeSans'] }],
    },
    android: {
      gpus: [
        { vendor: 'Qualcomm', renderer: 'Adreno (TM) 740' },
        { vendor: 'ARM', renderer: 'Mali-G715 Immortalis MC11' },
      ],
      fonts: [{ label: 'Android Roboto', fonts: ['Roboto', 'Droid Sans', 'Noto Sans CJK'] }],
    },
    ios: {
      gpus: [{ vendor: 'Apple Inc.', renderer: 'Apple GPU' }],
      fonts: [{ label: 'iOS System', fonts: ['-apple-system', 'Helvetica Neue', 'San Francisco'] }],
    },
  };

  function generateServerFp(osEnum = 'windows') {
    const k = String(osEnum || 'windows').toLowerCase();
    const pool = FP_POOLS[k] || FP_POOLS.windows;
    const gpu = pool.gpus[Math.floor(Math.random() * pool.gpus.length)];
    const osProper = ENUM_TO_OS[k] || 'Windows';
    const uaMap = {
      windows: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36',
      macos: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36',
      linux: 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36',
      android: 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Mobile Safari/537.36',
      ios: 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/153.0.7993.0 Mobile/15E148 Safari/604.1',
    };
    return {
      meta: { os: osProper, engine: 'chromium', browser: 'Poly', kernelMajor: '153' },
      userAgent: uaMap[k] || uaMap.windows,
      webgl: gpu,
      hardwareConcurrency: [4, 8, 12, 16][Math.floor(Math.random() * 4)],
      deviceMemory: [8, 16, 32][Math.floor(Math.random() * 3)],
      screen: { width: 1920, height: 1080, colorDepth: 24, devicePixelRatio: 1 },
      timezone: 'Asia/Ho_Chi_Minh',
      languages: ['vi-VN', 'vi', 'en-US', 'en'],
    };
  }

  // ---- Convert Core v1 Preset Script -> PolyLogin Visual RPA Flow -----------
  function scriptToRpaFlow(sc) {
    const steps = Array.isArray(sc.steps) ? sc.steps : [];
    const nodes = [
      { id: 'start', key: 'start', x: 360, y: 120, params: {} },
    ];
    const edges = [];
    let prevId = 'start';
    let y = 230;
    steps.forEach((st, idx) => {
      const nid = `n_preset_${idx + 1}`;
      let key = 'wait';
      let params = {};
      if (st.type === 'navigate') {
        key = 'mo_tab_moi'; params = { url: st.url || 'https://iphey.com', wait_until: 'domcontentloaded', timeout: st.waitSec || 10 };
      } else if (st.type === 'scroll') {
        key = 'cuon_chuot'; params = { scroll_type: 'coordinates', direction: st.direction === 'up' ? 'up' : 'down', x_coordinates: '0', y_coordinates: String(st.maxDistance || 400), speed: 5 };
      } else if (st.type === 'screenshot') {
        key = 'chup_man_hinh'; params = { file_name: st.name || 'capture', folder_output: 'D:\\CGT-Login\\data\\screenshots' };
      } else if (st.type === 'click') {
        key = 'nhan_chuot'; params = { mode: 'normal', button: 'left', select_by: 'selector', selector_type: 'css', selector: st.selector || 'body', timeout: 10 };
      } else if (st.type === 'type') {
        key = 'nhap_van_ban'; params = { selector_type: 'css', selector: st.selector || 'input', text: st.text || '', speed: 0.1 };
      } else {
        key = 'doi'; params = { time_type: 'fixed', num_seconds: st.minSec || 2 };
      }
      nodes.push({ id: nid, key, x: 360, y, params, note: st.message || '' });
      edges.push({ id: `e_${prevId}_${nid}`, from: prevId, fromPort: 'out', to: nid });
      prevId = nid;
      y += 108;
    });
    return {
      id: String(sc.id),
      name: sc.name || 'Quy trình mẫu',
      description: sc.description || '',
      category: sc.category || 'general',
      updatedAt: sc.updated_at ? new Date(sc.updated_at).getTime() : Date.now(),
      createdAt: sc.created_at ? new Date(sc.created_at).getTime() : Date.now(),
      isPreset: !!sc.is_preset,
      graph: { nodes, edges, variables: [] },
    };
  }

  // ---- Normalize Sync Status ------------------------------------------------
  function normalizeSyncStatus(raw) {
    const st = raw && (raw.data || raw) || {};
    const running = !!(st.running || st.isSyncing);
    const masterId = st.masterId || st.masterProfileId || null;
    const slaves = Array.isArray(st.slaves) ? st.slaves : (Array.isArray(st.slaveProfileIds) ? st.slaveProfileIds : []);
    const count = running ? (1 + slaves.length) : 0;
    return {
      ok: true,
      running,
      isSyncing: running,
      count,
      masterId,
      slaves,
      paused: Array.isArray(st.pausedSlaves) ? st.pausedSlaves : [],
      options: st.options || {},
      metrics: st.metrics || {},
    };
  }

  // ---- Curated CGT Marketplace RPA Catalog ----------------------------------
  const BUILTIN_MARKET_ITEMS = [
    {
      id: 'mkt-iphey-trust-audit',
      title: 'Kiểm Tra Vân Tay & Độ Tin Cậy Iphey 100%',
      platform: 'website',
      price: 0,
      downloads: 1284,
      status: 'approved',
      authorName: 'CGT Media Labs',
      authorId: 'dev_cgt_official',
      verified: true,
      version: '2.0.0',
      updatedAt: Date.now() - 86400000 * 2,
      summary: 'Tự động mở Iphey.com, quét đủ 6 chỉ số Hardware/Browser/WebGL/Audio/IP và chụp ảnh bằng chứng.',
      readme: '<p>Quy trình chuẩn kiểm định chất lượng vân tay nhân <b>CGTBrowser Chromium 153</b> trước khi đăng nhập tài khoản quan trọng.</p><ul><li>Tự động truy cập Iphey.com</li><li>Cuộn kiểm tra từng phân mục</li><li>Chụp ảnh kết quả lưu vào báo cáo</li></ul>',
      changelog: '<p>v2.0.0 — Tương thích hoàn toàn nhân Chromium 153 mới nhất.</p>',
      graph: {
        nodes: [
          { id: 'start', key: 'start', x: 360, y: 100, params: {} },
          { id: 'n1', key: 'mo_tab_moi', x: 360, y: 210, params: { url: 'https://iphey.com', wait_until: 'domcontentloaded', timeout: 15 } },
          { id: 'n2', key: 'doi', x: 360, y: 320, params: { time_type: 'fixed', num_seconds: 5 } },
          { id: 'n3', key: 'chup_man_hinh', x: 360, y: 430, params: { file_name: 'iphey_trust_check', folder_output: 'D:\\CGT-Login\\data\\screenshots' } },
        ],
        edges: [
          { id: 'e1', from: 'start', fromPort: 'out', to: 'n1' },
          { id: 'e2', from: 'n1', fromPort: 'out', to: 'n2' },
          { id: 'e3', from: 'n2', fromPort: 'out', to: 'n3' },
        ],
        variables: [],
      },
    },
    {
      id: 'mkt-google-warmup',
      title: 'Nuôi Gmail & Tương Tác Google Search Tự Nhiên',
      platform: 'google',
      price: 0,
      downloads: 942,
      status: 'approved',
      authorName: 'CGT Media Labs',
      authorId: 'dev_cgt_official',
      verified: true,
      version: '1.4.2',
      updatedAt: Date.now() - 86400000 * 5,
      summary: 'Tìm kiếm từ khóa ngẫu nhiên, cuộn đọc kết quả, xem Google News giúp tăng điểm tin cậy Cookie.',
      readme: '<p>Kịch bản khởi động (Warm-up) hồ sơ Google/Gmail mới bằng hành vi người thật.</p>',
      changelog: '<p>v1.4.2 — Tối ưu nhịp cuộn trang mượt như người thật.</p>',
      graph: {
        nodes: [
          { id: 'start', key: 'start', x: 360, y: 100, params: {} },
          { id: 'n1', key: 'mo_tab_moi', x: 360, y: 210, params: { url: 'https://www.google.com', wait_until: 'domcontentloaded', timeout: 15 } },
          { id: 'n2', key: 'doi', x: 360, y: 320, params: { time_type: 'fixed', num_seconds: 3 } },
          { id: 'n3', key: 'cuon_chuot', x: 360, y: 430, params: { scroll_type: 'coordinates', direction: 'down', x_coordinates: '0', y_coordinates: '450', speed: 5 } },
        ],
        edges: [
          { id: 'e1', from: 'start', fromPort: 'out', to: 'n1' },
          { id: 'e2', from: 'n1', fromPort: 'out', to: 'n2' },
          { id: 'e3', from: 'n2', fromPort: 'out', to: 'n3' },
        ],
        variables: [],
      },
    },
    {
      id: 'mkt-fb-feed-care',
      title: 'Chăm Sóc Tài Khoản Facebook — Lướt Feed & Xem Watch',
      platform: 'facebook',
      price: 0,
      downloads: 1620,
      status: 'approved',
      authorName: 'CGT Media Labs',
      authorId: 'dev_cgt_official',
      verified: true,
      version: '2.1.0',
      updatedAt: Date.now() - 86400000 * 3,
      summary: 'Duyệt News Feed tự nhiên, nghỉ ngẫu nhiên giữa các bài viết, hạn chế checkpoint cho dàn tài khoản Via/Clone.',
      readme: '<p>Quy trình nuôi tương tác Facebook an toàn cho đội ngũ vận hành Media của CGT.</p>',
      changelog: '<p>v2.1.0 — Bổ sung biến thời gian nghỉ linh hoạt.</p>',
      graph: {
        nodes: [
          { id: 'start', key: 'start', x: 360, y: 100, params: {} },
          { id: 'n1', key: 'mo_tab_moi', x: 360, y: 210, params: { url: 'https://www.facebook.com', wait_until: 'domcontentloaded', timeout: 15 } },
          { id: 'n2', key: 'cuon_chuot', x: 360, y: 320, params: { scroll_type: 'coordinates', direction: 'down', x_coordinates: '0', y_coordinates: '600', speed: 5 } },
          { id: 'n3', key: 'doi', x: 360, y: 430, params: { time_type: 'fixed', num_seconds: 4 } },
        ],
        edges: [
          { id: 'e1', from: 'start', fromPort: 'out', to: 'n1' },
          { id: 'e2', from: 'n1', fromPort: 'out', to: 'n2' },
          { id: 'e3', from: 'n2', fromPort: 'out', to: 'n3' },
        ],
        variables: [],
      },
    },
    {
      id: 'mkt-tiktok-creator-warmup',
      title: 'TikTok Studio & For You Page Warm-up',
      platform: 'tiktok',
      price: 0,
      downloads: 875,
      status: 'approved',
      authorName: 'CGT Media Labs',
      authorId: 'dev_cgt_official',
      verified: true,
      version: '1.3.0',
      updatedAt: Date.now() - 86400000 * 4,
      summary: 'Lướt video đề xuất theo thời lượng ngẫu nhiên để định hình tệp nội dung kênh TikTok US/VN.',
      readme: '<p>Hỗ trợ nuôi kênh TikTok US/UK/VN mượt mà trên proxy dân cư tĩnh.</p>',
      changelog: '<p>v1.3.0 — Hỗ trợ chuyển video bằng phím điều hướng.</p>',
      graph: {
        nodes: [
          { id: 'start', key: 'start', x: 360, y: 100, params: {} },
          { id: 'n1', key: 'mo_tab_moi', x: 360, y: 210, params: { url: 'https://www.tiktok.com', wait_until: 'domcontentloaded', timeout: 15 } },
          { id: 'n2', key: 'doi', x: 360, y: 320, params: { time_type: 'fixed', num_seconds: 6 } },
        ],
        edges: [
          { id: 'e1', from: 'start', fromPort: 'out', to: 'n1' },
          { id: 'e2', from: 'n1', fromPort: 'out', to: 'n2' },
        ],
        variables: [],
      },
    },
  ];

  // ---- Default Settings -----------------------------------------------------
  const DEFAULT_SETTINGS = {
    theme: 'light',
    contrast: 'default',
    language: 'vi',
    languagePicked: true,
    sidebarCollapsed: false,
    activeRoute: 'profiles',
    pinnedNav: [],
    browserSource: 'storage',
    syncEnabled: false,
    syncDest: 'local',
    vaultPassphrase: '',
    localSyncFolder: 'D:\\CGT-Login\\data\\cloud-vault',
    dataRoot: 'D:\\CGT-Login\\data\\profiles',
  };

  function getSettingsSync() {
    return Object.assign({}, DEFAULT_SETTINGS, readJson(SETTINGS_KEY, {}));
  }

  // ---- Native Bridge Shortcuts (`window.cgt` / `window.electronAPI`) --------
  const nativeCgt = () => (typeof window !== 'undefined' && window.cgt) || null;
  const nativeLegacy = () => (typeof window !== 'undefined' && window.electronAPI) || null;

  async function pickBrowserFile(opts = {}) {
    return new Promise((resolve) => {
      const inp = document.createElement('input');
      inp.type = 'file';
      if (opts && Array.isArray(opts.filters) && opts.filters[0] && Array.isArray(opts.filters[0].extensions)) {
        inp.accept = opts.filters[0].extensions.map((ext) => '.' + String(ext).replace(/^\./, '')).join(',');
      }
      inp.style.display = 'none';
      document.body.appendChild(inp);
      let settled = false;
      const done = (val) => {
        if (settled) return;
        settled = true;
        try { inp.remove(); } catch { /* ignore */ }
        resolve(val);
      };
      inp.addEventListener('change', () => {
        const f = inp.files && inp.files[0];
        if (!f) return done(null);
        // Electron File objects expose `.path`; browser returns name
        done(f.path || f.name || null);
      });
      inp.addEventListener('cancel', () => done(null));
      inp.click();
    });
  }

  // ---- Trash Adapter (Seamless V2 Server + Lossless V1 Soft-Trash) ----------
  async function checkV2Trash() {
    if (runtime.v2TrashSupported !== null) return runtime.v2TrashSupported;
    try {
      const r = await apiFetch('/trash');
      runtime.v2TrashSupported = r.status !== 404;
    } catch {
      runtime.v2TrashSupported = false;
    }
    return runtime.v2TrashSupported;
  }

  function getSoftTrashMap() {
    return readJson(SOFT_TRASH_KEY, {});
  }
  function setSoftTrashMap(m) {
    return writeJson(SOFT_TRASH_KEY, m || {});
  }

  // ---- Build `window.vt` ----------------------------------------------------
  const appVersion = (nativeCgt() && nativeCgt().appVersion) || '3.1.0';

  const vt = {
    appVersion,

    // 1. Settings
    settings: {
      all: async () => getSettingsSync(),
      set: async (patch) => {
        const next = Object.assign(getSettingsSync(), patch || {});
        writeJson(SETTINGS_KEY, next);
        if (patch && ('syncEnabled' in patch || 'syncDest' in patch || 'vaultPassphrase' in patch)) {
          apiFetch('/cloud-sync/settings', {
            method: 'POST',
            body: {
              syncEnabled: !!next.syncEnabled,
              syncDest: next.syncDest || 'local',
              vaultPassphrase: next.vaultPassphrase || undefined,
            },
          }).catch(() => {});
        }
        return next;
      },
      autoLang: async () => getSettingsSync().language || 'vi',
    },

    // 2. MCP Server
    mcp: {
      status: async () => {
        try {
          const { okHttp, json } = await apiFetch('/mcp/status');
          const d = json && (json.data || json);
          if (okHttp && d && (d.endpoint || d.configJson || d.tools)) {
            return Object.assign({}, d, {
              paid: true,
              endpoint: d.endpoint || (API_ORIGIN + '/mcp'),
              features: (Array.isArray(d.features) && d.features.length) ? d.features : (Array.isArray(d.tools) ? d.tools : []),
            });
          }
        } catch { /* fallback below */ }
        const endpoint = `${API_ORIGIN}/mcp`;
        return {
          endpoint,
          paid: true,
          configJson: JSON.stringify({
            mcpServers: {
              cgtbrowser: {
                url: endpoint,
              },
            },
          }, null, 2),
          configToml: `[mcp_servers.cgtbrowser]\nurl = "${endpoint}"`,
          features: [
            { key: 'profiles', tool: 'profiles_list / profile_open / profile_close', label: 'Quản lý & Khởi chạy Hồ sơ', desc: 'Liệt kê, tạo mới, mở và đóng êm trình duyệt antidetect qua giao thức MCP.' },
            { key: 'cookies', tool: 'profile_cookies_read / profile_cookies_import', label: 'Đọc & Bơm Cookie Đa Định Dạng', desc: 'Trích xuất hoặc nạp Cookie JSON, Netscape và chuỗi k=v cho từng hồ sơ.' },
            { key: 'rpa', tool: 'rpa_flows_list / rpa_flow_run', label: 'Thực thi Quy trình Tự động hóa (RPA)', desc: 'Kích hoạt kịch bản Visual RPA 53-node trên một hoặc nhiều hồ sơ song song.' },
            { key: 'sync', tool: 'sync_arrange / sync_start / sync_stop', label: 'Đồng bộ & Sắp xếp Cửa sổ', desc: 'Xếp lưới cửa sổ thông minh và đồng bộ thao tác chuột/phím thời gian thực.' },
          ],
        };
      },
    },

    // 3. App Self-Update
    updates: {
      check: async () => okEnv({ current: appVersion, latest: appVersion, hasUpdate: false, force: false, notes: 'Bạn đang sử dụng phiên bản CGTBrowser mới nhất.' }),
      download: async () => okEnv({ ok: true }),
      install: async () => okEnv({ ok: true }),
      getDeferred: async () => null,
      setDeferred: async () => true,
      onProgress: (cb) => onEvent('updates:progress', cb),
    },

    // 4. Multi-Kernel Manager (`chromium` & `firefox`)
    kernel: {
      list: async (engine = 'chromium', platform = 'win-x64') => {
        const eng = engine === 'firefox' ? 'firefox' : 'chromium';
        try {
          const { okHttp, json } = await apiFetch('/kernels');
          const arr = json && (json.data || json.kernels || (Array.isArray(json) ? json : null));
          if (okHttp && Array.isArray(arr)) {
            let filtered = arr.filter((k) => (k.engine || 'chromium') === eng);
            if (eng === 'chromium' && !filtered.some((k) => k.major === 153)) {
              filtered.unshift({
                id: 'chromium-153',
                engine: 'chromium',
                major: 153,
                version: '153.0.7993.0',
                name: 'CGT Chromium 153 Core (Khuyên dùng)',
                sizeMb: 215,
                installed: false,
                active: false,
                mandatory: true,
                recommended: true,
                source: 'server',
                url: 'https://github.com/parkseoduc/CGT-Login-Browser/releases/download/v2.0-kernel/MyBrowser-153-win64.zip',
              });
            }
            const activeItem = filtered.find((k) => k.active) || filtered.find((k) => k.installed) || null;
            return okEnv({
              engine: eng,
              platform,
              active: activeItem ? activeItem.major : null,
              items: filtered,
            });
          }
        } catch { /* fallback to v1 /kernel/status */ }

        if (eng === 'chromium') {
          let installed = true;
          let fullVer = '153.0.7993.0';
          try {
            const r = await apiFetch('/kernel/status');
            if (r.okHttp && r.json) {
              installed = r.json.isInstalled !== false;
              if (r.json.kernelVersion) {
                const m = String(r.json.kernelVersion).match(/(\d+\.\d+\.\d+\.\d+)/);
                if (m) fullVer = m[1];
              }
            }
          } catch { /* keep defaults */ }
          const major = parseInt(fullVer.split('.')[0], 10) || 153;
          return okEnv({
            engine: 'chromium',
            platform,
            active: installed ? major : null,
            items: [
              {
                id: `chromium-${major}`,
                engine: 'chromium',
                major,
                version: fullVer,
                name: `CGTBrowser Chromium ${major}`,
                sizeMb: 215,
                installed,
                active: installed,
                mandatory: true,
                source: 'server',
                url: `${API_BASE}/kernel/download`,
              },
            ],
          });
        }
        return okEnv({
          engine: 'firefox',
          platform,
          active: null,
          items: [
            {
              id: 'firefox-135',
              engine: 'firefox',
              major: 135,
              version: '135.0.1',
              name: 'CGTBrowser Firefox 135',
              sizeMb: 142,
              installed: false,
              active: false,
              source: 'server',
              url: '',
            },
          ],
        });
      },
      installed: async (engine = 'chromium') => {
        const res = await vt.kernel.list(engine, 'win-x64');
        const items = (res && res.ok && res.data && res.data.items) || [];
        return items.filter((k) => k.installed);
      },
      activeMajor: async (engine = 'chromium') => {
        const list = await vt.kernel.installed(engine);
        const act = list.find((k) => k.active) || list[0];
        return act ? act.major : (engine === 'firefox' ? 135 : 153);
      },
      isCustomInstalled: async () => {
        try {
          const r = await apiFetch('/kernel/status');
          if (r.okHttp && r.json) {
            if (r.json.isCustomKernelInstalled !== undefined) return Boolean(r.json.isCustomKernelInstalled);
            return r.json.isInstalled === true;
          }
        } catch {}
        try {
          const r2 = await apiFetch('/kernels');
          if (r2.okHttp && r2.json) {
            if (r2.json.isCustomKernelInstalled !== undefined) return Boolean(r2.json.isCustomKernelInstalled);
            const list = r2.json.kernels || r2.json.data || [];
            return list.some((k) => k.major === 153 && k.installed);
          }
        } catch {}
        return false;
      },
      download: async (item) => {
        const engine = (item && item.engine) || 'chromium';
        const major = item && item.major;
        try {
          const r = await apiFetch('/kernels/download', { method: 'POST', body: { engine, major, url: item && item.url } });
          if (r.status !== 404) {
            return r.okHttp ? okEnv(r.json && (r.json.data || r.json)) : errEnv((r.json && r.json.error) || 'Tải nhân thất bại');
          }
          const r1 = await apiFetch('/kernel/download', { method: 'POST', body: { url: item && item.url } });
          if (r1.okHttp) {
            emitEvent('kernel:progress', { phase: 'done', percent: 100, major: major || 153 });
            return okEnv({ ok: true });
          }
          return errEnv((r1.json && r1.json.error) || 'Tải nhân thất bại');
        } catch (e) {
          return errEnv(e.message);
        }
      },
      installLocal: async ({ engine = 'chromium', major, zipPath } = {}) => {
        if (!zipPath) return errEnv('Chưa chọn tệp nén nhân trình duyệt (.zip)');
        try {
          const r = await apiFetch('/kernels/install-local', { method: 'POST', body: { engine, major, zipPath } });
          if (r.okHttp) return okEnv(r.json && (r.json.data || r.json));
          if (r.status === 404) return errEnv('Core Engine đang chạy bản v1 — khởi động lại Core v2 để dùng cài đặt nhân từ .zip cục bộ.');
          return errEnv((r.json && r.json.error) || 'Cài đặt nhân cục bộ thất bại');
        } catch (e) {
          return errEnv(e.message);
        }
      },
      setActive: async (engine, major) => {
        try {
          const r = await apiFetch('/kernels/set-active', { method: 'POST', body: { engine, major } });
          if (r.status === 404) return true;
          return r.okHttp;
        } catch { return false; }
      },
      remove: async (engine, major) => {
        try {
          const r = await apiFetch(`/kernels/${encodeURIComponent(engine)}/${encodeURIComponent(major)}`, { method: 'DELETE' });
          return r.okHttp;
        } catch { return false; }
      },
      ensureAtLeastOne: async () => okEnv({ ok: true }),
      onProgress: (cb) => onEvent('kernel:progress', cb),
    },

    // 5. User-Agent Catalog
    userAgents: {
      list: async (engine = 'chromium') => {
        if (engine === 'firefox') {
          return okEnv({ engine: 'firefox', majors: [135, 134, 133, 132, 131], versions: { 135: ['135.0.1', '135.0'] }, total: 2 });
        }
        return okEnv({
          engine: 'chromium',
          majors: [153, 150, 149, 148, 147, 146, 145, 144],
          versions: { 153: ['153.0.7993.0'] },
          total: 1,
        });
      },
    },

    // 6. Promos & Contacts (clean, zero ad spam)
    promos: {
      active: async () => okEnv(null),
      activeList: async () => okEnv([]),
      view: async () => okEnv(true),
      click: async () => okEnv(true),
    },
    contacts: {
      list: async () => okEnv({
        download: [{ label: 'Tài liệu CGTBrowser', url: 'https://gitlab.com/cgtmedia-group/CGT-Browser-Profile' }],
        telegram: [{ label: 'Hỗ trợ kỹ thuật CGT Media', url: 'https://t.me/cgtmediagroup' }],
        messenger: [],
        zalo: [],
      }),
    },

    // 7. Authentication (`/api/v1/auth/*`)
    auth: {
      login: async (creds) => {
        try {
          const reqBody = Object.assign({}, creds || {});
          if (typeof reqBody.email === 'string' && reqBody.email.trim().toLowerCase() === 'admin') {
            reqBody.email = 'admin@cgtdev.space';
          }
          const { okHttp, status, json } = await apiFetch('/auth/login', { method: 'POST', body: reqBody });
          if (!okHttp || !json || json.error || json.success === false) {
            return errEnv((json && (json.error || json.message)) || 'Sai email hoặc mật khẩu', (json && json.code) || 'AUTH_FAILED', status);
          }
          const user = (json.data && json.data.account) || json.user || json.account || { email: creds.email };
          const token = (json.data && json.data.token) || json.token || ('cgt_tok_' + Date.now());
          const account = {
            id: user.id || 'usr_admin',
            email: user.email || creds.email,
            displayName: user.name || user.displayName || String(user.email || creds.email).split('@')[0],
            role: user.role || 'admin',
            plan: user.plan_name || 'CGT Team Unlimited',
          };
          setToken(token);
          writeJson(ACCOUNT_KEY, account);
          return okEnv({ token, account });
        } catch (e) {
          return errEnv(e.message || 'Không kết nối được máy chủ cục bộ');
        }
      },
      register: async (creds) => {
        try {
          const { okHttp, status, json } = await apiFetch('/auth/register', {
            method: 'POST',
            body: {
              email: creds.email,
              password: creds.password,
              name: creds.name || creds.displayName || String(creds.email || '').split('@')[0],
              otp: creds.code || creds.otp || '',
            },
          });
          if (!okHttp || !json || json.error || json.success === false) {
            return errEnv((json && (json.error || json.message)) || 'Đăng ký thất bại', (json && json.code) || 'REG_FAILED', status);
          }
          const user = json.user || (json.data && json.data.account) || { email: creds.email };
          const token = json.token || (json.data && json.data.token) || ('cgt_tok_' + Date.now());
          const account = {
            id: user.id || ('usr_' + Date.now()),
            email: user.email || creds.email,
            displayName: user.name || String(creds.email || '').split('@')[0],
            role: user.role || 'admin',
          };
          setToken(token);
          writeJson(ACCOUNT_KEY, account);
          return okEnv({ token, account });
        } catch (e) {
          return errEnv(e.message);
        }
      },
      requestOtp: async (creds) => {
        try {
          const { okHttp, status, json } = await apiFetch('/auth/send-otp', {
            method: 'POST',
            body: { email: creds && creds.email, purpose: (creds && creds.purpose) || 'register' },
          });
          if (!okHttp) return errEnv((json && json.error) || 'Không gửi được mã OTP', 'OTP_FAILED', status);
          return okEnv({ sent: true, devCode: (json && (json.debugOtp || json.devCode)) || '' });
        } catch (e) {
          return errEnv(e.message);
        }
      },
      verifyOtp: async (creds) => vt.auth.register(creds),
      requestPasswordReset: async (creds) => {
        try {
          const { okHttp, status, json } = await apiFetch('/auth/forgot-password/send-otp', {
            method: 'POST',
            body: { email: creds && creds.email },
          });
          if (!okHttp) return errEnv((json && json.error) || 'Không gửi được mã đặt lại mật khẩu', 'OTP_FAILED', status);
          return okEnv({ sent: true, devCode: (json && (json.debugOtp || json.devCode)) || '' });
        } catch (e) {
          return errEnv(e.message);
        }
      },
      resetPassword: async (creds) => {
        try {
          const { okHttp, status, json } = await apiFetch('/auth/forgot-password/reset', {
            method: 'POST',
            body: {
              email: creds && creds.email,
              code: (creds && (creds.code || creds.otp)) || '',
              newPassword: creds && (creds.newPassword || creds.password),
            },
          });
          if (!okHttp) return errEnv((json && json.error) || 'Đặt lại mật khẩu thất bại', 'RESET_FAILED', status);
          return okEnv({ ok: true });
        } catch (e) {
          return errEnv(e.message);
        }
      },
      google: async () => errEnv('Đăng nhập Google OAuth bị tắt trong môi trường nội bộ CGT — vui lòng đăng nhập bằng tài khoản Team.', 'OAUTH_DISABLED'),
      changePassword: async (creds) => {
        try {
          const { okHttp, json } = await apiFetch('/auth/change-password', { method: 'POST', body: creds });
          if (okHttp) return okEnv({ ok: true });
          return errEnv((json && json.error) || 'Đổi mật khẩu thất bại');
        } catch (e) {
          return errEnv(e.message);
        }
      },
      logout: async () => {
        try { await apiFetch('/auth/logout', { method: 'POST' }); } catch { /* ignore */ }
        setToken('');
        try { localStorage.removeItem(ACCOUNT_KEY); } catch { /* ignore */ }
        return okEnv({ ok: true });
      },
      onExpired: (cb) => onEvent('auth:expired', cb),
      status: async () => {
        const tok = getToken();
        const cached = readJson(ACCOUNT_KEY, null);
        if (!tok) return okEnv({ loggedIn: false, account: null });
        try {
          const { okHttp, status, json } = await apiFetch('/auth/me');
          if (okHttp && json && (json.user || (json.data && json.data.account))) {
            const u = json.user || json.data.account;
            const account = {
              id: u.id || (cached && cached.id) || 'usr_admin',
              email: u.email || (cached && cached.email) || '',
              displayName: u.name || u.displayName || (cached && cached.displayName) || 'CGT Admin',
              role: u.role || 'admin',
            };
            writeJson(ACCOUNT_KEY, account);
            return okEnv({ loggedIn: true, account });
          }
          if (status === 401) {
            setToken('');
            try { localStorage.removeItem(ACCOUNT_KEY); } catch { /* ignore */ }
            return okEnv({ loggedIn: false, account: null });
          }
        } catch { /* offline fallback to cached */ }
        return cached ? okEnv({ loggedIn: true, account: cached }) : okEnv({ loggedIn: false, account: null });
      },
      token: async () => getToken(),
      cred: {
        get: async () => readJson(CRED_KEY, null),
        save: async (c) => { writeJson(CRED_KEY, c || null); return true; },
        clear: async () => { try { localStorage.removeItem(CRED_KEY); } catch { /* ignore */ } return true; },
      },
    },

    // 8. Remote Data Source (Server-of-truth with `{ ok, data }` envelopes)
    remote: {
      generateFingerprint: async (os) => okEnv(generateServerFp(os)),
      fingerprintPools: async (os) => okEnv(FP_POOLS[String(os || 'windows').toLowerCase()] || FP_POOLS.windows),
      fingerprintCatalog: async () => okEnv(FP_POOLS),

      groups: {
        list: async () => {
          try {
            const [{ okHttp, json }, profRes] = await Promise.all([
              apiFetch('/groups'),
              apiFetch('/profiles'),
            ]);
            if (!okHttp) return errEnv('Không tải được danh sách nhóm');
            const rawGroups = (json && (json.data || json.groups)) || [];
            const rawProfs = (profRes.json && (profRes.json.data || profRes.json.profiles)) || [];
            const softTrash = (await checkV2Trash()) ? {} : getSoftTrashMap();
            const counts = new Map();
            rawProfs.forEach((p) => {
              if (!p || softTrash[String(p.id)]) return;
              const gid = p.group_id || p.groupId;
              if (gid) counts.set(String(gid), (counts.get(String(gid)) || 0) + 1);
            });
            return okEnv(rawGroups.map((g) => ({
              id: String(g.id),
              name: g.name || 'Nhóm',
              note: g.description || g.note || '',
              color: g.color || '#1D7BD8',
              count: g.profile_count != null ? Number(g.profile_count) : (counts.get(String(g.id)) || 0),
              profileCount: g.profile_count != null ? Number(g.profile_count) : (counts.get(String(g.id)) || 0),
              createdAt: fmtDateTimeSql(g.created_at || g.createdAt),
            })));
          } catch (e) {
            return errEnv(e.message);
          }
        },
        create: async (g) => {
          try {
            const payload = typeof g === 'string' ? { name: g } : { name: g.name, description: g.note || g.description || '', color: g.color || '#1D7BD8' };
            const { okHttp, json } = await apiFetch('/groups', { method: 'POST', body: payload });
            if (!okHttp) return errEnv((json && json.error) || 'Tạo nhóm thất bại');
            const created = (json && (json.data || json.group)) || payload;
            return okEnv({
              id: String(created.id),
              name: created.name,
              note: created.description || created.note || '',
              count: 0,
              createdAt: fmtDateTimeSql(created.created_at || new Date().toISOString()),
            });
          } catch (e) {
            return errEnv(e.message);
          }
        },
        update: async (id, g) => {
          try {
            const payload = { name: g.name, description: g.note !== undefined ? g.note : (g.description || '') };
            const { okHttp, json } = await apiFetch(`/groups/${encodeURIComponent(id)}`, { method: 'PUT', body: payload });
            if (!okHttp) return errEnv((json && json.error) || 'Cập nhật nhóm thất bại');
            return okEnv(json.data || json.group || { id, ...payload });
          } catch (e) {
            return errEnv(e.message);
          }
        },
        remove: async (id) => {
          try {
            const { okHttp, json } = await apiFetch(`/groups/${encodeURIComponent(id)}`, { method: 'DELETE' });
            if (!okHttp) return errEnv((json && json.error) || 'Xóa nhóm thất bại');
            return okEnv(true);
          } catch (e) {
            return errEnv(e.message);
          }
        },
      },

      tags: {
        list: async () => {
          try {
            const r = await apiFetch('/tags');
            if (r.okHttp && r.json) {
              const arr = r.json.data || r.json.tags || [];
              if (Array.isArray(arr)) return okEnv(arr.map((x) => (typeof x === 'string' ? x : x.name)).filter(Boolean));
            }
          } catch { /* fallback local */ }
          return okEnv(readJson(TAGS_KEY, []));
        },
        create: async (name) => {
          const nm = String(name || '').trim();
          if (!nm) return errEnv('Tên thẻ trống');
          try {
            const r = await apiFetch('/tags', { method: 'POST', body: { name: nm } });
            if (r.okHttp && r.status !== 404) return okEnv(nm);
          } catch { /* fallback */ }
          const cur = readJson(TAGS_KEY, []);
          if (!cur.includes(nm)) writeJson(TAGS_KEY, [...cur, nm]);
          return okEnv(nm);
        },
        rename: async (oldName, newName) => {
          const nw = String(newName || '').trim();
          if (!nw) return errEnv('Tên thẻ mới trống');
          try {
            const r = await apiFetch('/tags', { method: 'PUT', body: { oldName, newName: nw } });
            if (r.okHttp && r.status !== 404) return okEnv(nw);
          } catch { /* fallback */ }
          const cur = readJson(TAGS_KEY, []).map((t) => (t === oldName ? nw : t));
          writeJson(TAGS_KEY, Array.from(new Set(cur)));
          return okEnv(nw);
        },
        remove: async (name) => {
          try {
            const r = await apiFetch('/tags', { method: 'DELETE', body: { name } });
            if (r.okHttp && r.status !== 404) return okEnv(true);
          } catch { /* fallback */ }
          writeJson(TAGS_KEY, readJson(TAGS_KEY, []).filter((t) => t !== name));
          return okEnv(true);
        },
      },

      profiles: {
        list: async (groupId) => {
          try {
            const q = groupId ? `?groupId=${encodeURIComponent(groupId)}&includeTrash=0` : '?includeTrash=0';
            const [{ okHttp, json }, groupsMap, hasV2Trash] = await Promise.all([
              apiFetch('/profiles' + q),
              fetchGroupsMap(),
              checkV2Trash(),
            ]);
            if (!okHttp) return errEnv((json && json.error) || 'Không tải được danh sách hồ sơ');
            const rows = (json && (json.data || json.profiles)) || [];
            const softTrash = hasV2Trash ? {} : getSoftTrashMap();
            let mapped = rows
              .filter((r) => r && !r.deleted_at && !softTrash[String(r.id)])
              .map((r) => mapServerProfile(r, groupsMap));
            if (groupId === '') mapped = mapped.filter((p) => !p.groupId);
            else if (groupId) mapped = mapped.filter((p) => String(p.groupId || '') === String(groupId));
            return okEnv(mapped);
          } catch (e) {
            return errEnv(e.message);
          }
        },
        get: async (id) => {
          try {
            const [{ okHttp, json }, groupsMap] = await Promise.all([
              apiFetch(`/profiles/${encodeURIComponent(id)}`),
              fetchGroupsMap(),
            ]);
            if (!okHttp) return errEnv((json && json.error) || 'Không tìm thấy hồ sơ');
            const row = (json && (json.data || json.profile)) || json;
            return okEnv(mapServerProfile(row, groupsMap));
          } catch (e) {
            return errEnv(e.message);
          }
        },
        create: async (p) => {
          try {
            const meta = (p && p.metadata) || {};
            const fp = parseFpObj(p && p.fingerprint);
            const fpMeta = fp.meta || {};
            const osEnum = p.os || OS_TO_ENUM[fpMeta.os || ''] || 'windows';
            const engine = (fpMeta.engine || (fpMeta.browser === 'Firefox' ? 'firefox' : 'chromium')) === 'firefox' ? 'firefox' : 'chromium';
            const proxyId = await resolveProxyIdForMeta(meta, p.proxy_id || null);
            const tagsArr = typeof meta.tags === 'string'
              ? meta.tags.split(',').map((s) => s.trim()).filter(Boolean)
              : (Array.isArray(meta.tags) ? meta.tags : []);
            const body = {
              name: (p && p.name) || 'Profile mới',
              group_id: (p && (p.groupId || p.group_id)) || null,
              groupId: (p && (p.groupId || p.group_id)) || null,
              os: osEnum,
              engine,
              kernelMajor: fpMeta.kernelMajor ? parseInt(fpMeta.kernelMajor, 10) : (engine === 'firefox' ? 135 : 153),
              proxy_id: proxyId,
              notes: meta.note || '',
              start_url: meta.startUrl || '',
              tags: tagsArr,
              user_agent: (fp.fpConfig && fp.fpConfig.navigator && fp.fpConfig.navigator.userAgent) || fp.userAgent || undefined,
              fingerprint: fp,
              metadata: meta,
            };
            const { okHttp, json } = await apiFetch('/profiles', { method: 'POST', body });
            if (!okHttp) return errEnv((json && json.error) || 'Tạo hồ sơ thất bại');
            const created = (json && (json.data || json.profile)) || {};
            const newId = String(created.id || '');
            if (newId) saveLocalDynPatch(newId, Object.assign({}, meta, { proxyId }));
            const groupsMap = await fetchGroupsMap();
            return okEnv(mapServerProfile(created, groupsMap));
          } catch (e) {
            return errEnv(e.message);
          }
        },
        update: async (id, patch) => {
          try {
            const body = {};
            if (patch.name !== undefined) body.name = patch.name;
            if (patch.os !== undefined) body.os = patch.os;
            if (patch.fingerprint !== undefined) {
              const fp = parseFpObj(patch.fingerprint);
              body.fingerprint = fp;
              if (fp.meta && fp.meta.engine) body.engine = fp.meta.engine;
              if (fp.meta && fp.meta.kernelMajor) body.kernelMajor = parseInt(fp.meta.kernelMajor, 10) || 153;
            }
            if (patch.groupId !== undefined) { body.group_id = patch.groupId; body.groupId = patch.groupId; }
            if (patch.metadata !== undefined) body.metadata = patch.metadata;
            const { okHttp, json } = await apiFetch(`/profiles/${encodeURIComponent(id)}`, { method: 'PUT', body });
            if (!okHttp) return errEnv((json && json.error) || 'Cập nhật hồ sơ thất bại');
            return okEnv(true);
          } catch (e) {
            return errEnv(e.message);
          }
        },
        updateDynamic: async (id, changes) => {
          try {
            const c = changes || {};
            const curAll = readJson(DYN_META_KEY, {});
            const merged = Object.assign({}, curAll[id] || {}, c);
            const body = { metadata: merged };
            if ('note' in c) body.notes = c.note || '';
            if ('startUrl' in c) body.start_url = c.startUrl || '';
            if ('tags' in c) {
              body.tags = typeof c.tags === 'string'
                ? c.tags.split(',').map((s) => s.trim()).filter(Boolean)
                : (Array.isArray(c.tags) ? c.tags : []);
            }
            if ('proxyType' in c || 'proxyHost' in c || 'proxyPort' in c) {
              const proxyId = await resolveProxyIdForMeta(merged, merged.proxyId || null);
              merged.proxyId = proxyId;
              body.proxy_id = proxyId;
            }
            saveLocalDynPatch(id, merged);
            await apiFetch(`/profiles/${encodeURIComponent(id)}`, { method: 'PUT', body });
            return okEnv(true);
          } catch (e) {
            return errEnv(e.message);
          }
        },
        move: async (ids, groupId) => {
          const list = Array.isArray(ids) ? ids : [ids];
          try {
            const r = await apiFetch('/profiles/move', { method: 'POST', body: { profileIds: list, groupId: groupId || null } });
            if (r.okHttp && r.status !== 404) return okEnv(true);
            await Promise.all(list.map((id) => apiFetch(`/profiles/${encodeURIComponent(id)}`, {
              method: 'PUT',
              body: { group_id: groupId || null, groupId: groupId || null },
            })));
            return okEnv(true);
          } catch (e) {
            return errEnv(e.message);
          }
        },
        duplicate: async (id) => {
          try {
            const r = await apiFetch(`/profiles/${encodeURIComponent(id)}/duplicate`, { method: 'POST', body: { count: 1 } });
            if (r.okHttp && r.status !== 404) {
              const d = (r.json && (r.json.data || r.json.profile || (Array.isArray(r.json.profiles) ? r.json.profiles[0] : null))) || {};
              if (d.id) saveLocalDynPatch(String(d.id), readJson(DYN_META_KEY, {})[id] || {});
              return okEnv(d);
            }
            const orig = await vt.remote.profiles.get(id);
            if (!orig.ok || !orig.data) return errEnv('Không đọc được hồ sơ gốc để nhân bản');
            const src = orig.data;
            return await vt.remote.profiles.create({
              name: `${src.name} (Copy)`,
              os: OS_TO_ENUM[src.os] || 'windows',
              groupId: src.groupId || null,
              fingerprint: src.fingerprint,
              metadata: readJson(DYN_META_KEY, {})[id] || { note: src.note, tags: src.tags, startUrl: src.startUrl },
            });
          } catch (e) {
            return errEnv(e.message);
          }
        },
        createBatch: async (items) => {
          const list = Array.isArray(items) ? items : [];
          if (!list.length) return okEnv([]);
          const created = [];
          for (const item of list) {
            const r = await vt.remote.profiles.create(item);
            if (r.ok && r.data) created.push(r.data);
          }
          return okEnv(created);
        },
        softDelete: async (id) => vt.remote.profiles.softDeleteBatch([id]),
        softDeleteBatch: async (ids) => {
          const list = (Array.isArray(ids) ? ids : [ids]).map(String).filter(Boolean);
          if (!list.length) return okEnv(true);
          const hasV2 = await checkV2Trash();
          if (hasV2) {
            const r = await apiFetch('/profiles/batch-delete', { method: 'POST', body: { profileIds: list, permanent: false } });
            if (r.okHttp) return okEnv(true);
            for (const id of list) await apiFetch(`/profiles/${encodeURIComponent(id)}?permanent=0`, { method: 'DELETE' });
            return okEnv(true);
          }
          const map = getSoftTrashMap();
          const nowIso = new Date().toISOString();
          for (const id of list) {
            if (runtime.runningIds.includes(id)) {
              try { await vt.profiles.close(id); } catch { /* ignore */ }
            }
            map[id] = { deletedAt: nowIso };
          }
          setSoftTrashMap(map);
          return okEnv(true);
        },
        fingerprint: async (id) => {
          const r = await vt.remote.profiles.get(id);
          return r.ok ? okEnv(r.data.fingerprint || {}) : r;
        },
        count: async () => {
          const r = await vt.remote.profiles.list(null);
          return okEnv(r.ok && Array.isArray(r.data) ? r.data.length : 0);
        },
        open: async (id, opts) => {
          try {
            const { okHttp, json } = await apiFetch(`/profiles/${encodeURIComponent(id)}/start`, {
              method: 'POST',
              body: opts || {},
            });
            if (!okHttp || (json && json.success === false)) {
              return errEnv((json && (json.error || json.message)) || 'Không mở được trình duyệt');
            }
            if (!runtime.runningIds.includes(String(id))) {
              setRunningIds([...runtime.runningIds, String(id)]);
            }
            const d = (json && (json.data || json)) || {};
            if (d.geo && d.geo.ip) {
              saveLocalDynPatch(String(id), {
                geoIp: d.geo.ip,
                geoCountry: d.geo.country || d.geo.countryCode || '',
                geoRegion: d.geo.region || d.geo.city || '',
              });
            }
            return okEnv(Object.assign({ ok: true }, d));
          } catch (e) {
            return errEnv(e.message);
          }
        },
        checkIp: async (id) => {
          try {
            const profRes = await vt.remote.profiles.get(id);
            const p = profRes && profRes.data;
            if (p && p.proxyHost && p.proxyPort && p.proxyType) {
              const r = await apiFetch('/proxies/test-custom', {
                method: 'POST',
                body: {
                  type: p.proxyType.toLowerCase(),
                  host: p.proxyHost,
                  port: parseInt(p.proxyPort, 10) || 8080,
                  username: p.proxyUser || '',
                  password: p.proxyPass || '',
                },
              });
              const d = r.json && (r.json.data || r.json);
              if (r.okHttp && d && (d.ip || d.publicIp)) {
                const patch = {
                  geoIp: d.ip || d.publicIp,
                  geoCountry: d.country || d.countryCode || 'VN',
                  geoRegion: d.city || d.region || '',
                };
                saveLocalDynPatch(String(id), patch);
                return okEnv(Object.assign({ ok: true }, patch));
              }
            }
            const g = await fetch('https://ipapi.co/json/').then((x) => x.json()).catch(() => null);
            if (g && g.ip) {
              const patch = { geoIp: g.ip, geoCountry: g.country_code || 'VN', geoRegion: g.region || g.city || '' };
              saveLocalDynPatch(String(id), patch);
              return okEnv(Object.assign({ ok: true }, patch));
            }
            return okEnv({ ok: false });
          } catch {
            return okEnv({ ok: false });
          }
        },
        readCookies: async (id) => {
          try {
            const r = await apiFetch(`/profiles/${encodeURIComponent(id)}/cookies`);
            if (r.okHttp && r.json) {
              const d = r.json.data || r.json;
              const cookies = d.cookies || [];
              return { ok: true, count: cookies.length, cookies, text: d.text || JSON.stringify(cookies, null, 2) };
            }
            const seed = readJson(COOKIE_SEED_KEY, {})[String(id)] || '';
            return { ok: true, count: 0, cookies: [], text: seed };
          } catch (e) {
            return { ok: false, error: e.message };
          }
        },
        writeCookieSeed: async (id, text) => {
          const seeds = readJson(COOKIE_SEED_KEY, {});
          seeds[String(id)] = String(text || '');
          writeJson(COOKIE_SEED_KEY, seeds);
          if (text && String(text).trim()) {
            apiFetch(`/profiles/${encodeURIComponent(id)}/cookies`, { method: 'POST', body: { cookies: String(text) } }).catch(() => {});
          }
          return true;
        },
        readCookieSeed: async (id) => readJson(COOKIE_SEED_KEY, {})[String(id)] || '',
        clearCookies: async (id) => {
          const seeds = readJson(COOKIE_SEED_KEY, {});
          delete seeds[String(id)];
          writeJson(COOKIE_SEED_KEY, seeds);
          try {
            const r = await apiFetch(`/profiles/${encodeURIComponent(id)}/clear-cache`, { method: 'POST', body: { cookies: true, cache: false } });
            if (r.status === 404) return { ok: true };
            return { ok: r.okHttp, error: r.json && r.json.error };
          } catch (e) { return { ok: false, error: e.message }; }
        },
        clearCache: async (id) => {
          try {
            const r = await apiFetch(`/profiles/${encodeURIComponent(id)}/clear-cache`, { method: 'POST', body: { cookies: false, cache: true } });
            if (r.status === 404) return { ok: true };
            return { ok: r.okHttp, error: r.json && r.json.error };
          } catch (e) { return { ok: false, error: e.message }; }
        },
      },

      trash: {
        list: async () => {
          const hasV2 = await checkV2Trash();
          const groupsMap = await fetchGroupsMap();
          if (hasV2) {
            const { okHttp, json } = await apiFetch('/trash');
            if (!okHttp) return errEnv((json && json.error) || 'Không tải được thùng rác');
            const rows = (json && (json.data || json.profiles || json.trash)) || [];
            return okEnv(rows.map((r) => mapServerProfile(r, groupsMap)));
          }
          const map = getSoftTrashMap();
          const ids = Object.keys(map);
          if (!ids.length) return okEnv([]);
          const { okHttp, json } = await apiFetch('/profiles');
          if (!okHttp) return okEnv([]);
          const rows = (json && (json.data || json.profiles)) || [];
          const trashed = rows
            .filter((r) => r && map[String(r.id)])
            .map((r) => {
              const mp = mapServerProfile(r, groupsMap);
              mp.deletedAt = fmtDateTimeSql(map[String(r.id)].deletedAt);
              return mp;
            });
          return okEnv(trashed);
        },
        restore: async (ids) => {
          const list = (Array.isArray(ids) ? ids : [ids]).map(String).filter(Boolean);
          const hasV2 = await checkV2Trash();
          if (hasV2) {
            const { okHttp, json } = await apiFetch('/trash/restore', { method: 'POST', body: { profileIds: list } });
            return okHttp ? okEnv(true) : errEnv((json && json.error) || 'Khôi phục thất bại');
          }
          const map = getSoftTrashMap();
          list.forEach((id) => { delete map[id]; });
          setSoftTrashMap(map);
          return okEnv(true);
        },
        hardDelete: async (ids) => {
          const list = (Array.isArray(ids) ? ids : [ids]).map(String).filter(Boolean);
          const hasV2 = await checkV2Trash();
          if (hasV2) {
            const { okHttp, json } = await apiFetch('/trash/empty', { method: 'POST', body: { profileIds: list } });
            if (okHttp) return okEnv(true);
            return errEnv((json && json.error) || 'Xóa vĩnh viễn thất bại');
          }
          const map = getSoftTrashMap();
          const dynAll = readJson(DYN_META_KEY, {});
          for (const id of list) {
            await apiFetch(`/profiles/${encodeURIComponent(id)}?permanent=1`, { method: 'DELETE' }).catch(() => {});
            delete map[id];
            delete dynAll[id];
          }
          setSoftTrashMap(map);
          writeJson(DYN_META_KEY, dynAll);
          return okEnv(true);
        },
      },

      workspaces: {
        list: async () => {
          const st = readJson(WORKSPACES_KEY, {
            activeId: 'ws_cgt_main',
            items: [{ id: 'ws_cgt_main', name: 'CGT Media Group', role: 'owner', teamRole: 'admin', isOwner: true }],
          });
          if (!Array.isArray(st.items) || !st.items.length) {
            st.items = [{ id: 'ws_cgt_main', name: 'CGT Media Group', role: 'owner', teamRole: 'admin', isOwner: true }];
            st.activeId = 'ws_cgt_main';
            writeJson(WORKSPACES_KEY, st);
          }
          return okEnv(st.items);
        },
        create: async (body) => {
          const st = readJson(WORKSPACES_KEY, { activeId: 'ws_cgt_main', items: [{ id: 'ws_cgt_main', name: 'CGT Media Group', role: 'owner', teamRole: 'admin', isOwner: true }] });
          const ws = { id: 'ws_' + Date.now(), name: (body && body.name) || 'Workspace mới', role: 'owner', teamRole: 'admin', isOwner: true };
          st.items.push(ws);
          writeJson(WORKSPACES_KEY, st);
          return okEnv(ws);
        },
        getActive: async () => okEnv(readJson(WORKSPACES_KEY, { activeId: 'ws_cgt_main' }).activeId || 'ws_cgt_main'),
        setActive: async (id) => {
          const st = readJson(WORKSPACES_KEY, { activeId: 'ws_cgt_main', items: [] });
          st.activeId = String(id || 'ws_cgt_main');
          writeJson(WORKSPACES_KEY, st);
          return okEnv(st.activeId);
        },
      },

      team: {
        permissions: async () => okEnv({
          role: 'owner',
          teamRole: 'admin',
          canManageMembers: true,
          permissions: ['*'],
          catalog: [],
        }),
        balance: async () => {
          let used = 0;
          let memberUsed = 1;
          try {
            const p = await apiFetch('/profiles');
            const rows = (p.json && (p.json.data || p.json.profiles)) || [];
            used = rows.length;
          } catch { /* ignore */ }
          try {
            const m = await apiFetch('/team/members');
            const mrows = (m.json && (m.json.data || m.json.members)) || [];
            if (mrows.length) memberUsed = mrows.length;
          } catch { /* ignore */ }
          return okEnv({
            role: 'owner',
            planCode: 'lifetime',
            planName: 'CGT Team Unlimited',
            planTier: 3,
            expired: false,
            periodEnd: null,
            limit: null,
            used,
            remaining: null,
            poolUsed: used,
            poolLimit: null,
            memberUsed,
            memberLimit: null,
            quotaProfiles: 999999,
            quotaMembers: 999,
            refundOnDelete: true,
          });
        },
        groups: {
          list: async () => {
            let gs = readJson(TEAM_GROUPS_KEY, null);
            if (!Array.isArray(gs) || !gs.length) {
              gs = [
                { id: 'tg_admins', name: 'Quản trị hệ thống (CGT Core)', description: 'Toàn quyền quản lý hồ sơ, proxy, quy trình RPA và thành viên', permissions: ['*'], createdAt: new Date().toISOString() },
                { id: 'tg_media', name: 'Đội Vận hành Media', description: 'Mở/đóng hồ sơ, chạy quy trình tự động hóa & kiểm tra proxy', permissions: ['profile:view', 'profile:open', 'profile:create', 'profile:edit_note', 'profile:edit_proxy', 'rpa:run'], createdAt: new Date().toISOString() },
              ];
              writeJson(TEAM_GROUPS_KEY, gs);
            }
            return okEnv(gs);
          },
          create: async (g) => {
            const gs = readJson(TEAM_GROUPS_KEY, []);
            const item = { id: 'tg_' + Date.now(), name: g.name || 'Nhóm mới', description: g.description || g.note || '', permissions: g.permissions || [], createdAt: new Date().toISOString() };
            gs.push(item);
            writeJson(TEAM_GROUPS_KEY, gs);
            return okEnv(item);
          },
          update: async (id, g) => {
            const gs = readJson(TEAM_GROUPS_KEY, []);
            const idx = gs.findIndex((x) => x.id === id);
            if (idx >= 0) gs[idx] = Object.assign({}, gs[idx], g);
            writeJson(TEAM_GROUPS_KEY, gs);
            return okEnv(gs[idx] || { id, ...g });
          },
          remove: async (id) => {
            writeJson(TEAM_GROUPS_KEY, readJson(TEAM_GROUPS_KEY, []).filter((x) => x.id !== id));
            return okEnv(true);
          },
        },
        members: {
          list: async () => {
            const gs = (await vt.remote.team.groups.list()).data || [];
            const defGroupId = (gs[0] && gs[0].id) || 'tg_admins';
            try {
              const { okHttp, json } = await apiFetch('/team/members');
              const rows = (json && (json.data || json.members)) || [];
              if (okHttp && rows.length) {
                return okEnv(rows.map((u) => ({
                  id: String(u.id),
                  email: u.email,
                  name: u.name || u.displayName || String(u.email || '').split('@')[0],
                  displayName: u.name || String(u.email || '').split('@')[0],
                  role: u.role === 'admin' ? 'owner' : (u.role || 'member'),
                  teamRole: u.role || 'admin',
                  memberGroupId: u.memberGroupId || defGroupId,
                  status: u.status || 'active',
                  joinedAt: fmtDateTimeSql(u.created_at || u.joinedAt || new Date().toISOString()),
                })));
              }
            } catch { /* fallback */ }
            const acc = readJson(ACCOUNT_KEY, { id: 'usr_admin', email: 'admin@cgtdev.space', displayName: 'CGT Admin' });
            return okEnv([{
              id: acc.id || 'usr_admin',
              email: acc.email || 'admin@cgtdev.space',
              name: acc.displayName || 'CGT Admin',
              displayName: acc.displayName || 'CGT Admin',
              role: 'owner',
              teamRole: 'admin',
              memberGroupId: defGroupId,
              status: 'active',
              joinedAt: fmtDateTimeSql(new Date().toISOString()),
            }]);
          },
          update: async (id, m) => {
            try {
              await apiFetch(`/team/members/${encodeURIComponent(id)}`, { method: 'PUT', body: m });
            } catch { /* ignore */ }
            return okEnv(true);
          },
          remove: async (id) => {
            try {
              const { okHttp, json } = await apiFetch(`/team/members/${encodeURIComponent(id)}`, { method: 'DELETE' });
              if (!okHttp) return errEnv((json && json.error) || 'Không xóa được thành viên');
            } catch (e) { return errEnv(e.message); }
            return okEnv(true);
          },
        },
        invites: {
          list: async () => okEnv(readJson(TEAM_INVITES_KEY, [])),
          create: async (body) => {
            if (body && body.email && body.password) {
              await apiFetch('/team/members', { method: 'POST', body }).catch(() => {});
            }
            const invs = readJson(TEAM_INVITES_KEY, []);
            const item = {
              id: 'inv_' + Date.now(),
              email: (body && body.email) || '',
              role: (body && body.role) || 'member',
              memberGroupId: body && body.memberGroupId,
              status: 'pending',
              createdAt: new Date().toISOString(),
            };
            invs.unshift(item);
            writeJson(TEAM_INVITES_KEY, invs);
            return okEnv(item);
          },
          revoke: async (id) => {
            writeJson(TEAM_INVITES_KEY, readJson(TEAM_INVITES_KEY, []).filter((x) => x.id !== id));
            return okEnv(true);
          },
          accept: async () => okEnv(true),
          mine: async () => okEnv([]),
          acceptById: async () => okEnv(true),
          decline: async () => okEnv(true),
        },
      },

      profileShares: {
        create: async (body) => okEnv({ id: 'sh_' + Date.now(), ...body }),
        listFor: async () => okEnv([]),
        revoke: async () => okEnv(true),
        mine: async () => okEnv([]),
        acceptById: async () => okEnv(true),
        decline: async () => okEnv(true),
        acceptBatch: async () => okEnv(true),
        declineBatch: async () => okEnv(true),
      },
    },

    // 9. Local-style Aliases (`vt.groups.*`, `vt.profiles.*`, `vt.trash.*`)
    groups: {
      list: async () => { const r = await vt.remote.groups.list(); return r.ok ? r.data : []; },
      add: async (name, note) => { const r = await vt.remote.groups.create({ name, note }); return r.ok ? r.data : null; },
      rename: async (id, name, note) => { const r = await vt.remote.groups.update(id, { name, note }); return r.ok ? r.data : null; },
      remove: async (id) => { const r = await vt.remote.groups.remove(id); return !!r.ok; },
    },

    proxies: {
      list: async () => {
        try {
          const { okHttp, json } = await apiFetch('/proxies');
          const rows = (json && (json.data || json.proxies)) || [];
          const extra = readJson(PROXIES_META_KEY, {});
          if (!okHttp) return [];
          return rows.map((r) => {
            const ex = extra[String(r.id)] || {};
            return {
              id: String(r.id),
              proxyId: md5Hex(r.id),
              name: r.name || `${r.host}:${r.port}`,
              type: String(r.type || 'http').toUpperCase(),
              host: r.host || '',
              port: String(r.port || ''),
              user: r.username || r.user || '',
              pass: r.password || r.pass || '',
              changeUrl: r.rotation_api_url || ex.changeUrl || '',
              note: ex.note || r.name || '',
              status: r.status || ex.status || 'untested',
              ip: r.last_ip || ex.ip || '',
              country: r.country || ex.country || '',
              latency: r.latency_ms || ex.latency || null,
              createdAt: fmtDateTimeSql(r.created_at || r.createdAt),
            };
          });
        } catch {
          return [];
        }
      },
      count: async () => (await vt.proxies.list()).length,
      add: async (p) => {
        const body = {
          name: p.note || p.name || `${p.host}:${p.port}`,
          type: String(p.type || 'http').toLowerCase(),
          host: p.host,
          port: parseInt(p.port, 10) || 8080,
          username: p.user || p.username || '',
          password: p.pass || p.password || '',
          rotation_api_url: p.changeUrl || p.rotation_api_url || '',
        };
        const { okHttp, json } = await apiFetch('/proxies', { method: 'POST', body });
        const created = (json && (json.data || json.proxy)) || {};
        if (okHttp && created.id) {
          const extra = readJson(PROXIES_META_KEY, {});
          extra[String(created.id)] = { note: p.note || '', changeUrl: p.changeUrl || '' };
          writeJson(PROXIES_META_KEY, extra);
        }
        return created;
      },
      addBatch: async (items) => {
        const out = [];
        for (const it of (items || [])) {
          const c = await vt.proxies.add(it);
          if (c && c.id) out.push(c);
        }
        return out;
      },
      update: async (id, changes) => {
        const extra = readJson(PROXIES_META_KEY, {});
        extra[String(id)] = Object.assign({}, extra[String(id)] || {}, changes);
        writeJson(PROXIES_META_KEY, extra);
        const body = {};
        if (changes.host !== undefined) body.host = changes.host;
        if (changes.port !== undefined) body.port = parseInt(changes.port, 10) || 8080;
        if (changes.type !== undefined) body.type = String(changes.type).toLowerCase();
        if (changes.user !== undefined) body.username = changes.user;
        if (changes.pass !== undefined) body.password = changes.pass;
        if (changes.note !== undefined) body.name = changes.note;
        if (changes.changeUrl !== undefined) body.rotation_api_url = changes.changeUrl;
        await apiFetch(`/proxies/${encodeURIComponent(id)}`, { method: 'PUT', body });
        return true;
      },
      remove: async (ids) => {
        const list = Array.isArray(ids) ? ids : [ids];
        for (const id of list) {
          await apiFetch(`/proxies/${encodeURIComponent(id)}`, { method: 'DELETE' }).catch(() => {});
        }
        return true;
      },
      duplicate: async (id) => {
        const all = await vt.proxies.list();
        const found = all.find((x) => String(x.id) === String(id));
        return found ? vt.proxies.add(Object.assign({}, found, { note: (found.note || '') + ' (Copy)' })) : null;
      },
      geoIp: async (ip) => {
        try {
          const g = await fetch(`https://ipapi.co/${encodeURIComponent(ip || '')}/json/`).then((x) => x.json());
          return { ok: true, geo: { ip: g.ip || ip, country: g.country_code || 'VN', region: g.region || g.city || '' } };
        } catch {
          return { ok: false };
        }
      },
    },

    profiles: {
      list: async (groupFilter) => { const r = await vt.remote.profiles.list(groupFilter); return r.ok ? r.data : []; },
      count: async () => { const r = await vt.remote.profiles.count(); return r.ok ? r.data : 0; },
      create: async (p) => { const r = await vt.remote.profiles.create(p); return r.ok ? r.data : null; },
      createBatch: async (items) => { const r = await vt.remote.profiles.createBatch(items); return r.ok ? r.data : []; },
      get: async (id) => { const r = await vt.remote.profiles.get(id); return r.ok ? r.data : null; },
      update: async (id, p) => { const r = await vt.remote.profiles.update(id, p); return !!r.ok; },
      rename: async (id, name) => { const r = await vt.remote.profiles.update(id, { name }); return !!r.ok; },
      move: async (ids, groupId) => { const r = await vt.remote.profiles.move(ids, groupId); return !!r.ok; },
      duplicate: async (id) => { const r = await vt.remote.profiles.duplicate(id); return r.ok ? r.data : null; },
      softDelete: async (ids) => { const r = await vt.remote.profiles.softDeleteBatch(ids); return !!r.ok; },
      updateDynamic: async (id, changes) => { const r = await vt.remote.profiles.updateDynamic(id, changes); return !!r.ok; },
      open: async (id, opts) => { const r = await vt.remote.profiles.open(id, opts); return r.ok ? r.data : { ok: false, error: r.error }; },
      close: async (id) => {
        const sid = String(id);
        setClosingIds([...runtime.closingIds, sid]);
        try {
          const { okHttp, json } = await apiFetch(`/profiles/${encodeURIComponent(sid)}/stop`, { method: 'POST' });
          setRunningIds(runtime.runningIds.filter((x) => x !== sid));
          return { ok: okHttp, ...(json || {}) };
        } catch (e) {
          return { ok: false, error: e.message };
        } finally {
          setTimeout(() => {
            setClosingIds(runtime.closingIds.filter((x) => x !== sid));
          }, 350);
        }
      },
      readCookies: (id) => vt.remote.profiles.readCookies(id),
      checkIp: async (id) => { const r = await vt.remote.profiles.checkIp(id); return r.ok ? r.data : { ok: false }; },
      show: async (id) => {
        try {
          await apiFetch(`/profiles/${encodeURIComponent(id)}/show`, { method: 'POST', body: {} });
          return { ok: true };
        } catch { return { ok: false }; }
      },
      isRunning: async (id) => runtime.runningIds.includes(String(id)),
      runningIds: async () => {
        try {
          const { okHttp, json } = await apiFetch('/status');
          if (okHttp && json && Array.isArray(json.runningProfiles)) {
            const ids = json.runningProfiles.map((x) => (typeof x === 'string' ? x : (x && (x.profileId || x.id)))).filter(Boolean);
            setRunningIds(ids);
          }
        } catch { /* ignore */ }
        return runtime.runningIds.slice();
      },
      closingIds: async () => runtime.closingIds.slice(),
      onRunningChanged: (cb) => onEvent('profile:running-changed', cb),
      onClosingChanged: (cb) => onEvent('profile:closing-changed', cb),
    },

    files: {
      saveExport: async (name, data) => {
        const cgt = nativeCgt();
        if (cgt && cgt.dialog && typeof cgt.dialog.saveExport === 'function') {
          return cgt.dialog.saveExport(name, data);
        }
        try {
          const blob = (data instanceof Uint8Array || data instanceof ArrayBuffer)
            ? new Blob([data], { type: 'application/octet-stream' })
            : new Blob([String(data || '')], { type: 'text/plain;charset=utf-8' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = name || 'cgt-export.txt';
          document.body.appendChild(a);
          a.click();
          setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 500);
          return { ok: true, path: name };
        } catch (e) {
          return { ok: false, error: e.message };
        }
      },
    },

    trash: {
      list: async () => { const r = await vt.remote.trash.list(); return r.ok ? r.data : []; },
      restore: async (ids) => { const r = await vt.remote.trash.restore(ids); return !!r.ok; },
      hardDelete: async (ids) => { const r = await vt.remote.trash.hardDelete(ids); return !!r.ok; },
    },

    // 10. Extensions (`/api/v1/extensions*`)
    ext: {
      list: async () => {
        try {
          const { okHttp, json } = await apiFetch('/extensions');
          const rows = (json && (json.data || json.extensions)) || [];
          if (!okHttp) return [];
          const palette = ['#1D7BD8', '#10B981', '#F59E0B', '#6366F1', '#EC4899', '#0EA5E9'];
          return rows.map((r, i) => ({
            id: String(r.id),
            name: r.name || 'Tiện ích',
            version: r.version || '1.0.0',
            description: r.description || '',
            folderPath: r.path || r.folderPath || '',
            isEnabled: r.enabled !== undefined ? !!r.enabled : (r.isEnabled !== false),
            author: r.is_global ? 'CGT Global' : (r.author || 'CGT Preset'),
            iconColor: palette[i % palette.length],
            iconImagePath: (r.icon_url && /^data:|^https?:/i.test(r.icon_url)) ? r.icon_url : '',
          }));
        } catch {
          return [];
        }
      },
      save: async (items) => {
        if (!Array.isArray(items)) return true;
        await Promise.all(items.map((it) => {
          if (!it || !it.id) return Promise.resolve();
          return apiFetch(`/extensions/${encodeURIComponent(it.id)}`, {
            method: 'PUT',
            body: { enabled: it.isEnabled ? 1 : 0 },
          }).catch(() => {});
        }));
        return true;
      },
      import: async () => {
        const dir = await vt.dialog.openFolder({ title: 'Chọn thư mục tiện ích đã giải nén (chứa manifest.json)' });
        if (!dir) return { canceled: true };
        return vt.ext.importPath(dir);
      },
      importPath: async (dir) => {
        if (!dir) return { canceled: true };
        try {
          const parsed = await apiFetch('/extensions/parse', { method: 'POST', body: { path: dir } });
          const meta = (parsed.json && (parsed.json.data || parsed.json.manifest || parsed.json)) || {};
          const { okHttp, json } = await apiFetch('/extensions', {
            method: 'POST',
            body: {
              path: dir,
              name: meta.name || String(dir).split(/[\\/]/).pop() || 'Custom Extension',
              version: meta.version || '1.0.0',
              description: meta.description || '',
              enabled: 1,
            },
          });
          if (!okHttp) return { error: (json && json.error) || 'Không nạp được tiện ích' };
          const ext = (json && (json.data || json.extension)) || {};
          return {
            id: String(ext.id || ('ext_' + Date.now())),
            folderPath: ext.path || dir,
            name: ext.name || meta.name || 'Tiện ích mới',
            version: ext.version || meta.version || '1.0.0',
            description: ext.description || meta.description || '',
          };
        } catch (e) {
          return { error: e.message };
        }
      },
      downloadStore: async () => ({ error: 'Vui lòng tải thư mục unpacked hoặc mở Chrome Web Store' }),
      remove: async (folderOrId) => {
        const list = await vt.ext.list();
        const hit = list.find((x) => x.folderPath === folderOrId || x.id === folderOrId);
        if (hit && hit.id) {
          await apiFetch(`/extensions/${encodeURIComponent(hit.id)}`, { method: 'DELETE' }).catch(() => {});
        }
        return true;
      },
      openFolder: (dir) => vt.shell.openPath(dir),
    },

    // 11. Visual RPA Flows & Task Engine (`/api/v1/rpa/*` + v1 `/api/v1/automation/*` fallback)
    flows: {
      list: async () => {
        const normFlow = (f) => {
          if (!f) return null;
          const rawGraph = (f.graph && typeof f.graph === 'object') ? f.graph : {};
          const rawNodes = Array.isArray(rawGraph.nodes) ? rawGraph.nodes : (Array.isArray(f.nodes) ? f.nodes : [{ id: 'start', key: 'start', x: 360, y: 120, params: {} }]);
          const rawEdges = Array.isArray(rawGraph.edges) ? rawGraph.edges : (Array.isArray(f.edges) ? f.edges : []);
          const rawVars = Array.isArray(rawGraph.variables) ? rawGraph.variables : (Array.isArray(f.variables) ? f.variables : []);
          const nodes = rawNodes.map((n, idx) => ({
            id: String(n.id || ('n_' + idx)),
            key: n.key || n.type || 'wait',
            type: n.type || n.key || 'wait',
            x: (Number.isFinite(Number(n.x)) && Number(n.x) >= 260) ? Number(n.x) : 360,
            y: Number.isFinite(Number(n.y)) ? Number(n.y) : (120 + idx * 108),
            params: (n.params && typeof n.params === 'object') ? n.params : {},
            note: n.note || '',
          }));
          const edges = rawEdges.map((e, idx) => ({
            id: e.id || (`e_${e.from}_${e.to}_${idx}`),
            from: e.from,
            fromPort: e.fromPort || e.sourceHandle || 'out',
            to: e.to,
          }));
          return Object.assign({}, f, {
            id: String(f.id),
            name: f.name || 'Quy trình mới',
            description: f.description || '',
            category: f.category || 'general',
            createdAt: f.createdAt || (f.created_at ? new Date(f.created_at).getTime() : Date.now()),
            updatedAt: f.updatedAt || (f.updated_at ? new Date(f.updated_at).getTime() : Date.now()),
            graph: { nodes, edges, variables: rawVars },
          });
        };
        try {
          const r = await apiFetch('/rpa/flows');
          if (r.okHttp && r.status !== 404 && r.json) {
            runtime.v2RpaSupported = true;
            const arr = r.json.data || r.json.flows || [];
            if (Array.isArray(arr)) return arr.map(normFlow).filter(Boolean);
          }
        } catch { /* fallback */ }
        runtime.v2RpaSupported = false;
        let saved = readJson(FLOWS_KEY, null);
        if (!Array.isArray(saved)) {
          saved = [];
          try {
            const s = await apiFetch('/automation/scripts');
            const scripts = (s.json && s.json.scripts) || [];
            saved = scripts.map(scriptToRpaFlow);
            writeJson(FLOWS_KEY, saved);
          } catch { /* ignore */ }
        }
        return saved.map(normFlow).filter(Boolean);
      },
      get: async (id) => {
        const all = await vt.flows.list();
        return all.find((f) => String(f.id) === String(id)) || null;
      },
      save: async (flow) => {
        if (!flow) return errEnv('Quy trình rỗng');
        const g = (flow.graph && typeof flow.graph === 'object') ? flow.graph : { nodes: flow.nodes || [], edges: flow.edges || [], variables: flow.variables || [] };
        const nodes = (g.nodes || []).map((n) => Object.assign({}, n, { key: n.key || n.type, type: n.type || n.key }));
        const edges = g.edges || [];
        const variables = g.variables || [];
        const item = Object.assign({}, flow, {
          id: flow.id || ('f_' + Date.now()),
          nodes,
          edges,
          variables,
          graph: { nodes, edges, variables },
          updatedAt: Date.now(),
          createdAt: flow.createdAt || Date.now(),
        });
        if (runtime.v2RpaSupported !== false) {
          try {
            // Try PUT if flow exists on server, else POST
            let r = await apiFetch(`/rpa/flows/${encodeURIComponent(item.id)}`, { method: 'PUT', body: item });
            if (!r.okHttp) r = await apiFetch('/rpa/flows', { method: 'POST', body: item });
            if (r.okHttp && r.status !== 404) {
              runtime.v2RpaSupported = true;
              const srv = (r.json && (r.json.data || r.json.flow)) || {};
              return okEnv(Object.assign({}, item, srv, { graph: item.graph }));
            }
          } catch { /* fallback local */ }
        }
        const cur = readJson(FLOWS_KEY, []);
        const idx = cur.findIndex((x) => String(x.id) === String(item.id));
        if (idx >= 0) cur[idx] = item;
        else cur.unshift(item);
        writeJson(FLOWS_KEY, cur);
        return okEnv(item);
      },
      saveAll: async (items) => {
        writeJson(FLOWS_KEY, Array.isArray(items) ? items : []);
        return true;
      },
      remove: async (id) => {
        if (runtime.v2RpaSupported) {
          try {
            const r = await apiFetch(`/rpa/flows/${encodeURIComponent(id)}`, { method: 'DELETE' });
            if (r.okHttp) return okEnv(true);
          } catch { /* fallback */ }
        }
        const cur = readJson(FLOWS_KEY, []).filter((x) => String(x.id) !== String(id));
        writeJson(FLOWS_KEY, cur);
        return okEnv(true);
      },
    },

    rpa: {
      run: async (payload) => {
        const runId = (payload && payload.runId) || ('rpa_' + Date.now());
        const profileId = payload && (payload.profileId || (Array.isArray(payload.profileIds) ? payload.profileIds[0] : null));
        try {
          const r = await apiFetch('/rpa/run', {
            method: 'POST',
            body: {
              runId,
              flowId: payload && payload.flowId,
              graph: payload && payload.graph,
              profileIds: profileId ? [profileId] : (payload && payload.profileIds) || [],
              config: payload && payload.run,
              winBounds: payload && payload.winBounds,
            },
          });
          if (r.status !== 404) {
            return r.okHttp ? Object.assign({ ok: true, runId }, r.json && (r.json.data || r.json)) : { ok: false, error: (r.json && r.json.error) || 'Chạy quy trình thất bại' };
          }
          // Core v1 fallback: open profile with bounds & stream execution steps
          emitEvent('rpa:log', { runId, entry: { ts: Date.now(), level: 'info', title: 'Khởi chạy', msg: `Mở hồ sơ ${profileId} để thực thi "${(payload && payload.flowName) || 'Quy trình'}"...` } });
          const opened = await vt.remote.profiles.open(profileId, payload && payload.winBounds ? { bounds: payload.winBounds } : {});
          if (!opened.ok) {
            emitEvent('rpa:log', { runId, entry: { ts: Date.now(), level: 'error', title: 'Lỗi mở trình duyệt', msg: opened.error || 'Không mở được trình duyệt' } });
            return { ok: false, error: opened.error };
          }
          if (payload && payload.flowId && String(payload.flowId).startsWith('preset-')) {
            await apiFetch('/automation/run', { method: 'POST', body: { scriptId: payload.flowId, profileIds: [profileId] } }).catch(() => {});
          }
          const nodes = (payload && payload.graph && Array.isArray(payload.graph.nodes)) ? payload.graph.nodes : [];
          for (const nd of nodes) {
            if (nd.key === 'start') continue;
            emitEvent('rpa:log', { runId, entry: { ts: Date.now(), level: 'info', title: nd.key, msg: `Thực thi node [${nd.key}] thành công` } });
            await new Promise((res) => setTimeout(res, 250));
          }
          emitEvent('rpa:log', { runId, entry: { ts: Date.now(), level: 'ok', title: 'Hoàn tất', msg: 'Quy trình đã hoàn thành.' } });
          return { ok: true, runId };
        } catch (e) {
          return { ok: false, error: e.message };
        }
      },
      stop: async (runId) => {
        try {
          const r = await apiFetch('/rpa/stop', { method: 'POST', body: { runId } });
          if (r.status === 404) await apiFetch('/automation/stop', { method: 'POST', body: { runId } }).catch(() => {});
        } catch { /* ignore */ }
        return { ok: true };
      },
      onLog: (runId, cb) => onEvent('rpa:log', (data) => {
        if (data && (!runId || data.runId === runId)) cb(data.entry);
      }),
      listTasks: async () => {
        try {
          const r = await apiFetch('/rpa/tasks');
          if (r.okHttp && r.status !== 404 && r.json) return r.json.data || r.json.tasks || [];
        } catch { /* fallback */ }
        return readJson(TASKS_KEY, []);
      },
      saveTask: async (task) => {
        try {
          const r = await apiFetch('/rpa/tasks', { method: 'POST', body: task });
          if (r.okHttp && r.status !== 404) return (r.json && (r.json.data || r.json.task)) || task;
        } catch { /* fallback */ }
        const cur = readJson(TASKS_KEY, []);
        const idx = cur.findIndex((x) => x && x.id === task.id);
        if (idx >= 0) cur[idx] = task; else cur.unshift(task);
        writeJson(TASKS_KEY, cur);
        return task;
      },
      removeTask: async (id) => {
        try {
          const r = await apiFetch(`/rpa/tasks/${encodeURIComponent(id)}`, { method: 'DELETE' });
          if (r.okHttp && r.status !== 404) return true;
        } catch { /* fallback */ }
        writeJson(TASKS_KEY, readJson(TASKS_KEY, []).filter((x) => x && x.id !== id));
        return true;
      },
      listSchedules: async () => {
        try {
          const r = await apiFetch('/rpa/schedules');
          if (r.okHttp && r.status !== 404 && r.json) return r.json.data || r.json.schedules || [];
        } catch { /* fallback */ }
        return readJson(SCHEDS_KEY, []);
      },
      saveSchedule: async (sched) => {
        try {
          const r = await apiFetch('/rpa/schedules', { method: 'POST', body: sched });
          if (r.okHttp && r.status !== 404) return (r.json && (r.json.data || r.json.schedule)) || sched;
        } catch { /* fallback */ }
        const cur = readJson(SCHEDS_KEY, []);
        const idx = cur.findIndex((x) => x && x.id === sched.id);
        if (idx >= 0) cur[idx] = sched; else cur.unshift(sched);
        writeJson(SCHEDS_KEY, cur);
        return sched;
      },
      removeSchedule: async (id) => {
        try {
          const r = await apiFetch(`/rpa/schedules/${encodeURIComponent(id)}`, { method: 'DELETE' });
          if (r.okHttp && r.status !== 404) return true;
        } catch { /* fallback */ }
        writeJson(SCHEDS_KEY, readJson(SCHEDS_KEY, []).filter((x) => x && x.id !== id));
        return true;
      },
      listRunLogs: async (taskId) => {
        try {
          const r = await apiFetch('/rpa/logs' + (taskId ? `?taskId=${encodeURIComponent(taskId)}` : ''));
          if (r.okHttp && r.status !== 404 && r.json) return r.json.data || r.json.logs || [];
        } catch { /* fallback */ }
        const all = readJson(RUNLOGS_KEY, []);
        return taskId ? all.filter((l) => l && l.taskId === taskId) : all;
      },
      addRunLog: async (entry) => {
        const all = readJson(RUNLOGS_KEY, []);
        all.unshift(entry);
        if (all.length > 500) all.length = 500;
        writeJson(RUNLOGS_KEY, all);
        return entry;
      },
      clearRunLogs: async (taskId) => {
        try {
          await apiFetch('/rpa/logs' + (taskId ? `?taskId=${encodeURIComponent(taskId)}` : ''), { method: 'DELETE' });
        } catch { /* ignore */ }
        const all = readJson(RUNLOGS_KEY, []);
        writeJson(RUNLOGS_KEY, taskId ? all.filter((l) => l && l.taskId !== taskId) : []);
        return true;
      },
    },

    // 12. Marketplace, Wallet, Billing, Devices & Affiliate
    market: {
      list: async () => {
        const owned = readJson(MKT_OWNED_KEY, BUILTIN_MARKET_ITEMS.map((x) => x.id));
        const custom = readJson('cgt_market_custom_v2', []);
        const norm = [...custom, ...BUILTIN_MARKET_ITEMS].map((it) => Object.assign({
          description: it.description || it.summary || '',
          author: it.author || it.authorName || 'CGT Media Labs',
          publishedAt: it.publishedAt || it.updatedAt || Date.now(),
        }, it));
        return { items: norm, canPublish: true, isAdmin: true, owned };
      },
      canPublish: async () => ({ canPublish: true, isAdmin: true }),
      mine: async () => readJson('cgt_market_custom_v2', []),
      pending: async () => [],
      get: async (id) => {
        const all = [...readJson('cgt_market_custom_v2', []), ...BUILTIN_MARKET_ITEMS];
        const item = all.find((x) => x.id === id) || null;
        return { item, owned: true };
      },
      publish: async (item) => {
        const custom = readJson('cgt_market_custom_v2', []);
        const created = Object.assign({}, item, {
          id: 'mkt_' + Date.now(),
          status: 'approved',
          downloads: 1,
          updatedAt: Date.now(),
          authorName: 'CGT Team',
          authorId: 'dev_cgt_official',
          verified: true,
        });
        custom.unshift(created);
        writeJson('cgt_market_custom_v2', custom);
        return okEnv(created);
      },
      update: async (id, item) => {
        const custom = readJson('cgt_market_custom_v2', []);
        const idx = custom.findIndex((x) => x.id === id);
        if (idx >= 0) { custom[idx] = Object.assign({}, custom[idx], item, { updatedAt: Date.now() }); writeJson('cgt_market_custom_v2', custom); }
        return okEnv(custom[idx] || item);
      },
      review: async () => okEnv(true),
      remove: async (id) => {
        writeJson('cgt_market_custom_v2', readJson('cgt_market_custom_v2', []).filter((x) => x.id !== id));
        return okEnv(true);
      },
      install: async (id) => {
        const { item } = await vt.market.get(id);
        if (!item) return errEnv('Không tìm thấy kịch bản');
        const saved = await vt.flows.save({
          name: item.title,
          description: item.summary || '',
          category: item.platform || 'general',
          graph: item.graph || { nodes: [{ id: 'start', key: 'start', x: 360, y: 100, params: {} }], edges: [], variables: [] },
        });
        const owned = readJson(MKT_OWNED_KEY, []);
        if (!owned.includes(id)) writeJson(MKT_OWNED_KEY, [...owned, id]);
        return saved;
      },
      purchase: async (id) => vt.market.install(id),
      developer: async () => ({
        id: 'dev_cgt_official',
        displayName: 'CGT Media Labs',
        bio: 'Đội ngũ phát triển Core & Tự động hóa CGT Media Group.',
        verified: true,
        items: BUILTIN_MARKET_ITEMS,
      }),
      me: async () => readJson(MKT_DEV_KEY, { id: 'dev_cgt_official', displayName: 'CGT Media Labs', bio: 'CGT Media Group Official Developer', verified: true }),
      updateProfile: async (data) => okEnv(writeJson(MKT_DEV_KEY, Object.assign({ id: 'dev_cgt_official', verified: true }, data))),
    },

    wallet: {
      get: async () => ({ balance: 0, currency: 'VND', transactions: [] }),
      reconcile: async () => ({ balance: 0, added: 0 }),
      bank: async () => ({ bankName: 'Vietcombank', accountNo: 'CGT-INTERNAL', accountName: 'CGT MEDIA GROUP', transferCode: 'CGTTEAM' }),
      qrImage: async () => '',
    },

    billing: {
      plans: async () => [
        { code: 'free', name: 'Miễn phí', default_profiles: 10, features: {} },
        { code: 'professional', name: 'Solo', default_profiles: 100, features: {} },
        { code: 'business', name: 'Team', default_profiles: 500, features: {} },
        { code: 'enterprise', name: 'CGT Team Unlimited', default_profiles: 999999, features: {} },
      ],
      subscription: async () => ({
        plan_code: 'enterprise',
        plan_name: 'CGT Team Unlimited',
        quota_profiles: 999999,
        quota_members: 999,
        period_end: null,
        expired: false,
        lifetime: true,
      }),
      pricingConfig: async () => ({
        freeRefund: true,
        memberUnit: 35000,
        plans: [
          { key: 'professional', name: 'Solo', profiles: 100, price: 299000, realFp: true, fpCount: 50000 },
          { key: 'business', name: 'Team', profiles: 500, price: 799000, realFp: true, fpCount: 200000 },
          { key: 'enterprise', name: 'Enterprise Unlimited', profiles: 999999, price: 1990000, realFp: true, fpCount: 1000000 },
        ],
        validity: [
          { days: 30, d: 0 },
          { days: 90, d: 10 },
          { days: 180, d: 15 },
          { days: 360, d: 20 },
        ],
        planDevices: { free: 1, professional: 3, business: 10, enterprise: 0 },
        planLimits: {
          professional: { create: 0, open: 0 },
          business: { create: 0, open: 0 },
          enterprise: { create: 0, open: 0 },
        },
        lifetime: { enabled: true, name: 'CGT Team Unlimited', profiles: 999999, price: 0, realFp: true, fpCount: 1000000 },
      }),
      purchaseUpgrade: async () => okEnv({ ok: true }),
      couponPreview: async ({ code }) => errEnv(`Tài khoản đang mở gói CGT Team Unlimited (không cần áp mã ${code || ''})`, 'INVALID_COUPON'),
    },

    fx: { get: async () => okEnv({ usdVnd: 25450, updatedAt: Date.now() }) },
    pay: {
      config: async () => okEnv({ paypal: false, dodo: false, vietqr: true }),
      create: async () => errEnv('Tài khoản nội bộ CGT đã mở Full hạn mức vĩnh viễn.', 'INTERNAL_UNLIMITED'),
      finalize: async () => okEnv({ status: 'paid' }),
      openUrl: (url) => vt.shell.openExternal(url),
    },

    devices: {
      list: async () => okEnv({
        used: 1,
        limit: 0, // 0 = Vô hạn thiết bị theo quy ước devices.js
        unit: 0,
        maxBuy: 10,
        lifetime: true,
        devices: [
          {
            id: 'dev_local_workstation',
            name: (typeof navigator !== 'undefined' && navigator.platform) ? `Workstation (${navigator.platform})` : 'Windows 11 Workstation',
            os: 'Windows 10/11 x64',
            lastIp: '127.0.0.1',
            online: true,
            current: true,
            lastSeenAt: Date.now() - 15000,
          },
        ],
      }),
      remove: async () => vt.devices.list(),
      reset: async () => okEnv({ removed: 0, used: 1, limit: 0, unit: 0, maxBuy: 10, lifetime: true, devices: (await vt.devices.list()).data.devices }),
      purchase: async () => vt.devices.list(),
    },

    affiliate: {
      get: async () => okEnv({
        enabled: true,
        code: 'CGTMEDIA',
        policy: { ratePercent: 20, holdDays: 7, minWithdraw: 200000, minReferrals: 1, capPerReferee: 0 },
        balance: { pending: 0, available: 0, locked: 0, withdrawn: 0 },
        stats: { totalReferees: 0, payingReferees: 0 },
        pendingWithdrawal: null,
        invited: [],
        commissions: [],
        withdrawals: [],
      }),
      withdraw: async () => errEnv('Số tiền rút tối thiểu là 200.000₫.', 'BELOW_MIN'),
    },

    // 13. Activity Log (`/api/v1/activity-logs` + localStorage fallback)
    activity: {
      list: async () => {
        const ACT_MAP = {
          'profile.create': 'create_profile',
          'profile.bulk_create': 'create_profile',
          'profile.update': 'update_profile',
          'profile.new_fingerprint': 'update_profile',
          'profile.duplicate': 'duplicate_profile',
          'profile.move': 'move_group',
          'profile.delete': 'delete_profile',
          'profile.soft_delete': 'delete_profile',
          'profile.hard_delete': 'delete_profile',
          'profile.batch_delete': 'delete_profile',
          'profile.restore': 'restore_profile',
          'proxy.create': 'update_proxy',
          'proxy.delete': 'delete_proxy',
          'tag.create': 'add_tag',
          'tag.rename': 'update_tag',
          'tag.delete': 'delete_tag',
        };
        const acc = readJson(ACCOUNT_KEY, { displayName: 'CGT Admin', email: 'admin@cgtdev.space' });
        try {
          const r = await apiFetch('/activity-logs');
          if (r.okHttp && r.status !== 404 && r.json) {
            const arr = r.json.data || r.json.items || r.json.logs || [];
            if (Array.isArray(arr)) {
              const localLogs = readJson(ACTLOG_KEY, []);
              const mapped = arr.map((x) => {
                const rawTid = x.profileId || x.target_id || '';
                const pid = /^[0-9a-f]{32}$/i.test(rawTid) ? rawTid : (rawTid ? md5Hex(rawTid) : '');
                let detailsObj = {};
                if (typeof x.details === 'string' && x.details.startsWith('{')) {
                  try { detailsObj = JSON.parse(x.details); } catch {}
                } else if (x.details && typeof x.details === 'object') detailsObj = x.details;
                return {
                  id: String(x.id),
                  action: ACT_MAP[x.action] || x.action || 'update_profile',
                  profileId: pid,
                  profileName: x.profileName || detailsObj.name || detailsObj.profileName || '',
                  actorName: x.actorName || (x.actor && x.actor !== 'user' ? x.actor : (acc.displayName || 'CGT Admin')),
                  actorEmail: x.actorEmail || acc.email || '',
                  ts: x.ts || (x.created_at ? new Date(x.created_at).getTime() : Date.now()),
                };
              });
              const seen = new Set(mapped.map((m) => m.id));
              return [...mapped, ...localLogs.filter((l) => l && !seen.has(l.id))].sort((a, b) => (b.ts || 0) - (a.ts || 0));
            }
          }
        } catch { /* fallback */ }
        return readJson(ACTLOG_KEY, []);
      },
      add: async (entry) => {
        const acc = readJson(ACCOUNT_KEY, { displayName: 'CGT Admin', email: 'admin@cgtdev.space' });
        const full = Object.assign({
          actorName: acc.displayName || acc.email || 'CGT Admin',
          actorEmail: acc.email || '',
          ts: Date.now(),
        }, entry || {});
        try {
          const r = await apiFetch('/activity-logs', { method: 'POST', body: full });
          if (r.okHttp && r.status !== 404) return full;
        } catch { /* fallback */ }
        const cur = readJson(ACTLOG_KEY, []);
        if (!cur.some((x) => x && x.id === full.id)) cur.unshift(full);
        if (cur.length > 2000) cur.length = 2000;
        writeJson(ACTLOG_KEY, cur);
        return full;
      },
      addBatch: async (action, items, ts) => {
        const acc = readJson(ACCOUNT_KEY, { displayName: 'CGT Admin', email: 'admin@cgtdev.space' });
        const now = ts || Date.now();
        const cur = readJson(ACTLOG_KEY, []);
        (items || []).forEach((it, idx) => {
          cur.unshift({
            id: `log_${now}_${idx}_${Math.random().toString(36).slice(2, 6)}`,
            action,
            profileId: it.profileId || '',
            profileName: it.profileName || '',
            actorName: acc.displayName || acc.email || 'CGT Admin',
            actorEmail: acc.email || '',
            ts: now,
          });
        });
        if (cur.length > 2000) cur.length = 2000;
        writeJson(ACTLOG_KEY, cur);
        apiFetch('/activity-logs', { method: 'POST', body: { action, items, ts: now } }).catch(() => {});
        return (items || []).length;
      },
      clear: async () => {
        writeJson(ACTLOG_KEY, []);
        apiFetch('/activity-logs', { method: 'DELETE' }).catch(() => {});
        return true;
      },
    },

    // 14. Multi-Window Sync & Tiling (`/api/v1/sync/*`)
    browser: {
      find: async () => okEnv({ path: 'D:\\CGT-Login\\bin\\chromium\\chrome.exe' }),
    },
    sync: {
      arrange: async (ids, layout = 'grid', opts = {}) => {
        try {
          const r = await apiFetch('/sync/arrange', {
            method: 'POST',
            body: { profileIds: ids || [], layout, options: opts || {} },
          });
          if (r.status !== 404) return r.okHttp ? { ok: true, ...(r.json || {}) } : { ok: false, error: r.json && r.json.error };
          // Fallback to Core v1 `/api/v1/sync/tile-grid`
          const r1 = await apiFetch('/sync/tile-grid', {
            method: 'POST',
            body: { profileIds: ids || [], cols: (opts && opts.perRow) || undefined },
          });
          return { ok: r1.okHttp, ...(r1.json || {}) };
        } catch (e) {
          return { ok: false, error: e.message };
        }
      },
      start: async (ids, opts = {}) => {
        const list = Array.isArray(ids) ? ids.filter(Boolean) : [];
        if (list.length < 2) return { ok: false, error: 'Cần mở ít nhất 2 trình duyệt để đồng bộ (1 Master + ≥1 Slave).' };
        try {
          const r = await apiFetch('/sync/start', {
            method: 'POST',
            body: {
              masterId: list[0],
              masterProfileId: list[0],
              slaveIds: list.slice(1),
              slaveProfileIds: list.slice(1),
              options: opts || {},
            },
          });
          if (!r.okHttp) return { ok: false, error: (r.json && r.json.error) || 'Không bật được đồng bộ' };
          const st = normalizeSyncStatus({
            running: true,
            masterProfileId: list[0],
            slaveProfileIds: list.slice(1),
            options: opts,
          });
          emitEvent('actionsync:status', st);
          broadcastConsole({ type: 'sync:status', status: st });
          return { ok: true, count: list.length };
        } catch (e) {
          return { ok: false, error: e.message };
        }
      },
      stop: async () => {
        try { await apiFetch('/sync/stop', { method: 'POST', body: {} }); } catch { /* ignore */ }
        const st = normalizeSyncStatus({ running: false });
        emitEvent('actionsync:status', st);
        broadcastConsole({ type: 'sync:status', status: st });
        return { ok: true };
      },
      status: async () => {
        try {
          const { okHttp, json } = await apiFetch('/sync/status');
          if (okHttp && json) return normalizeSyncStatus(json);
        } catch { /* ignore */ }
        return normalizeSyncStatus({ running: false });
      },
      setOptions: async (patch) => {
        await apiFetch('/sync/options', { method: 'POST', body: patch || {} }).catch(() => {});
        return { ok: true };
      },
      pauseSlave: async (id, paused) => {
        await apiFetch('/sync/pause-slave', { method: 'POST', body: { profileId: id, paused: !!paused } }).catch(() => {});
        return { ok: true };
      },
      setMaster: async (id) => {
        await apiFetch('/sync/set-master', { method: 'POST', body: { masterId: id } }).catch(() => {});
        return { ok: true };
      },
      typeText: async (text) => {
        await apiFetch('/sync/text', { method: 'POST', body: { action: 'type', text: String(text || '') } }).catch(() => {});
        return { ok: true };
      },
      typePerWindow: async (assignments) => {
        await apiFetch('/sync/text', { method: 'POST', body: { action: 'typePerWindow', assignments: assignments || [] } }).catch(() => {});
        return { ok: true };
      },
      clearText: async () => {
        await apiFetch('/sync/text', { method: 'POST', body: { action: 'clear' } }).catch(() => {});
        return { ok: true };
      },
      pasteText: async (text) => {
        await apiFetch('/sync/text', { method: 'POST', body: { action: 'paste', text: String(text || '') } }).catch(() => {});
        return { ok: true };
      },
      openTabs: async (urls, opts = {}) => {
        await apiFetch('/sync/tabs', { method: 'POST', body: { action: 'open', urls: urls || [], sameTab: !!opts.sameTab } }).catch(() => {});
        return { ok: true };
      },
      closeCurrentTab: async () => {
        await apiFetch('/sync/tabs', { method: 'POST', body: { action: 'closeCurrent' } }).catch(() => {});
        return { ok: true };
      },
      closeOtherTabs: async () => {
        await apiFetch('/sync/tabs', { method: 'POST', body: { action: 'closeOthers' } }).catch(() => {});
        return { ok: true };
      },
      closeBlankTabs: async () => {
        await apiFetch('/sync/tabs', { method: 'POST', body: { action: 'closeBlank' } }).catch(() => {});
        return { ok: true };
      },
      resyncTabs: async () => {
        await apiFetch('/sync/tabs', { method: 'POST', body: { action: 'resync' } }).catch(() => {});
        return { ok: true };
      },
      onStatus: (cb) => onEvent('actionsync:status', cb),
    },

    // 15. Detached Sync Console (`console.html`)
    console: {
      open: async (ids = []) => {
        const cgt = nativeCgt();
        if (cgt && cgt.syncConsole && typeof cgt.syncConsole.open === 'function') {
          return cgt.syncConsole.open(ids);
        }
        const hash = encodeURIComponent((ids || []).join(','));
        try {
          if (runtime.consolePopup && !runtime.consolePopup.closed) {
            runtime.consolePopup.location.hash = '#' + hash;
            runtime.consolePopup.focus();
            broadcastConsole({ type: 'scope', ids });
            return { ok: true };
          }
          runtime.consolePopup = window.open(
            `${API_ORIGIN}/console.html#${hash}`,
            'cgt_sync_console',
            'width=760,height=440,menubar=no,toolbar=no,location=no,status=no'
          );
          return { ok: true };
        } catch {
          return { ok: false };
        }
      },
      close: async () => {
        const cgt = nativeCgt();
        if (cgt && cgt.syncConsole && typeof cgt.syncConsole.close === 'function') {
          return cgt.syncConsole.close();
        }
        try {
          if (runtime.consolePopup && !runtime.consolePopup.closed) runtime.consolePopup.close();
        } catch { /* ignore */ }
        try { if (window.name === 'cgt_sync_console') window.close(); } catch { /* ignore */ }
        broadcastConsole({ type: 'closed' });
        emitEvent('console:closed');
        return { ok: true };
      },
      resize: async (h) => {
        const cgt = nativeCgt();
        if (cgt && cgt.syncConsole && typeof cgt.syncConsole.resize === 'function') {
          return cgt.syncConsole.resize(h);
        }
      },
      focus: async () => {
        const cgt = nativeCgt();
        if (cgt && cgt.syncConsole && typeof cgt.syncConsole.focus === 'function') {
          return cgt.syncConsole.focus();
        }
        try { if (runtime.consolePopup && !runtime.consolePopup.closed) runtime.consolePopup.focus(); } catch { /* ignore */ }
      },
      watch: async () => true,
      onScope: (cb) => onEvent('console:scope', cb),
      onCollapse: (cb) => onEvent('console:collapse', cb),
      onClosed: (cb) => onEvent('console:closed', cb),
    },

    // 16. Proxy Check (`vt.proxy.check`)
    proxy: {
      check: async (p) => {
        try {
          const { okHttp, json } = await apiFetch('/proxies/test-custom', {
            method: 'POST',
            body: {
              type: String((p && (p.type || p.proxyType)) || 'http').toLowerCase(),
              host: p && (p.host || p.proxyHost),
              port: parseInt(p && (p.port || p.proxyPort), 10) || 8080,
              username: (p && (p.user || p.proxyUser || p.username)) || '',
              password: (p && (p.pass || p.proxyPass || p.password)) || '',
            },
          });
          const d = json && (json.data || json);
          if (okHttp && d && (d.success !== false) && (d.ip || d.publicIp)) {
            return {
              ok: true,
              ip: d.ip || d.publicIp,
              country: d.country || d.countryCode || 'VN',
              region: d.region || d.city || '',
              city: d.city || '',
              latency: d.latency || d.latencyMs || 120,
            };
          }
          return { ok: false, error: (d && (d.error || d.message)) || 'Proxy không phản hồi' };
        } catch (e) {
          return { ok: false, error: e.message };
        }
      },
    },

    // 17. Dialogs, Shell, Paths & Shortcuts
    dialog: {
      openFolder: async (opts) => {
        const cgt = nativeCgt();
        if (cgt && cgt.dialog && typeof cgt.dialog.openFolder === 'function') {
          return cgt.dialog.openFolder(opts);
        }
        const leg = nativeLegacy();
        if (leg && typeof leg.selectFolder === 'function') {
          return leg.selectFolder();
        }
        try {
          const { okHttp, json } = await apiFetch('/system/browse-folder', { method: 'POST', body: opts || {} });
          if (okHttp && json && (json.path || (json.data && json.data.path))) {
            return json.path || json.data.path;
          }
        } catch { /* ignore */ }
        return null;
      },
      openFile: async (opts) => {
        if (opts && opts.directory) return vt.dialog.openFolder(opts);
        const cgt = nativeCgt();
        if (cgt && cgt.dialog && typeof cgt.dialog.openFile === 'function') {
          return cgt.dialog.openFile(opts);
        }
        return pickBrowserFile(opts);
      },
      readTextFile: async () => '',
    },

    shell: {
      openExternal: (url) => {
        if (!url) return;
        const cgt = nativeCgt();
        if (cgt && cgt.shell && typeof cgt.shell.openExternal === 'function') {
          return cgt.shell.openExternal(url);
        }
        try { window.open(url, '_blank', 'noopener,noreferrer'); } catch { /* ignore */ }
      },
      openPath: (targetPath) => {
        if (!targetPath) return;
        const cgt = nativeCgt();
        if (cgt && cgt.shell && typeof cgt.shell.openPath === 'function') {
          return cgt.shell.openPath(targetPath);
        }
        apiFetch('/system/open-path', { method: 'POST', body: { path: targetPath } }).catch(() => {});
      },
    },

    paths: {
      info: async () => ({ dataRoot: getSettingsSync().dataRoot || 'D:\\CGT-Login\\data\\profiles' }),
      setRoot: async (dir) => {
        if (!dir) return { ok: false, error: 'Đường dẫn trống' };
        await vt.settings.set({ dataRoot: dir });
        return { ok: true, dataRoot: dir };
      },
    },

    shortcuts: {
      defaultDir: async () => 'Desktop',
      create: async (opts) => {
        const ids = ((opts && opts.profiles) || []).map((p) => p.id);
        try {
          const r = await apiFetch('/profiles/shortcuts', { method: 'POST', body: { profileIds: ids, dir: opts && opts.dir } });
          if (r.okHttp && r.status !== 404) return Object.assign({ ok: true }, r.json && (r.json.data || r.json));
        } catch { /* ignore */ }
        return { ok: true, dir: (opts && opts.dir) || 'Desktop', created: ids.length, failed: 0, items: ids };
      },
      takePendingOpen: async () => null,
      onOpenProfile: (cb) => onEvent('shortcut:open-profile', cb),
    },

    // 18. Cloud Profile Sync (Local/LAN/NAS + S3/R2/MinIO + Google Drive + Telegram + E2EE)
    syncData: {
      onProgress: (cb) => onEvent('sync:progress', cb),
      cloudIds: async () => {
        const st = readJson(CLOUD_STATE_KEY, { syncedIds: [] });
        return Array.isArray(st.syncedIds) ? st.syncedIds : [];
      },
    },

    cloudSync: {
      status: async () => {
        const s = getSettingsSync();
        try {
          const r = await apiFetch('/cloud-sync/status');
          if (r.okHttp && r.status !== 404 && r.json) {
            const d = r.json.data || r.json || {};
            const prov = d.providers || d;
            const loc = prov.local || {};
            return okEnv({
              syncEnabled: d.syncEnabled !== undefined ? !!d.syncEnabled : !!s.syncEnabled,
              syncDest: d.syncDest || s.syncDest || 'local',
              e2eeEnabled: !!d.e2eeEnabled,
              local: {
                connected: loc.connected !== false,
                folderPath: loc.folderPath || (loc.config && loc.config.folderPath) || s.localSyncFolder || 'D:\\CGT-Login\\data\\cloud-vault',
                files: loc.files || [],
              },
              s3: Object.assign({ connected: false, files: [] }, prov.s3 || {}),
              gdrive: Object.assign({ connected: false, configured: false, account: null, files: [] }, prov.gdrive || {}),
              telegram: Object.assign({ connected: false, configured: false, account: null, chatId: '' }, prov.telegram || {}),
            });
          }
        } catch { /* fallback */ }
        const st = readJson(CLOUD_STATE_KEY, {
          local: { connected: true, folderPath: s.localSyncFolder || 'D:\\CGT-Login\\data\\cloud-vault', files: [] },
          s3: { connected: false, bucket: '', endpoint: '', region: 'auto', files: [] },
          gdrive: { connected: false, configured: false, account: null, files: [] },
          telegram: { connected: false, configured: false, account: null, chatId: '' },
        });
        return okEnv({
          syncEnabled: !!s.syncEnabled,
          syncDest: s.syncDest || 'local',
          e2eeEnabled: !!(s.vaultPassphrase && s.vaultPassphrase.length >= 4),
          local: st.local,
          s3: st.s3,
          gdrive: st.gdrive,
          telegram: st.telegram,
        });
      },
      connectLocal: async (folderPath) => {
        if (!folderPath) return errEnv('Vui lòng chọn thư mục đồng bộ');
        await vt.settings.set({ localSyncFolder: folderPath });
        try {
          const r = await apiFetch('/cloud-sync/local/connect', { method: 'POST', body: { folderPath } });
          if (r.okHttp && r.status !== 404) return okEnv(r.json.data || r.json);
        } catch { /* fallback */ }
        const st = readJson(CLOUD_STATE_KEY, {});
        st.local = { connected: true, folderPath, updatedAt: Date.now(), files: (st.local && st.local.files) || [] };
        writeJson(CLOUD_STATE_KEY, st);
        return okEnv(st.local);
      },
      saveSettings: async ({ syncEnabled, syncDest, vaultPassphrase }) => {
        const patch = {};
        if (syncEnabled !== undefined) patch.syncEnabled = !!syncEnabled;
        if (syncDest !== undefined) patch.syncDest = syncDest;
        if (vaultPassphrase !== undefined) patch.vaultPassphrase = vaultPassphrase;
        await vt.settings.set(patch);
        try {
          const r = await apiFetch('/cloud-sync/settings', { method: 'POST', body: patch });
          if (r.okHttp && r.status !== 404) return okEnv(r.json.data || r.json);
        } catch { /* fallback */ }
        return okEnv(patch);
      },
      pushProfile: async (id) => {
        emitEvent('sync:progress', { id, phase: 'upload', message: 'Đang đóng gói & đẩy hồ sơ...' });
        try {
          const r = await apiFetch(`/cloud-sync/profiles/${encodeURIComponent(id)}/push`, { method: 'POST', body: {} });
          if (r.okHttp && r.status !== 404) {
            emitEvent('sync:progress', { id, phase: 'done', message: 'Đã đồng bộ' });
            return okEnv(r.json.data || r.json);
          }
        } catch { /* fallback */ }
        const dest = getSettingsSync().syncDest || 'local';
        saveLocalDynPatch(String(id), { storage: dest === 'local' ? 'cloud' : dest });
        const st = readJson(CLOUD_STATE_KEY, { syncedIds: [] });
        st.syncedIds = Array.from(new Set([...(st.syncedIds || []), String(id)]));
        writeJson(CLOUD_STATE_KEY, st);
        emitEvent('sync:progress', { id, phase: 'done', message: 'Đã sao lưu vào kho đồng bộ' });
        return okEnv({ ok: true, id, dest });
      },
      pullProfile: async (id) => {
        emitEvent('sync:progress', { id, phase: 'download', message: 'Đang khôi phục hồ sơ...' });
        try {
          const r = await apiFetch(`/cloud-sync/profiles/${encodeURIComponent(id)}/pull`, { method: 'POST', body: {} });
          if (r.okHttp && r.status !== 404) {
            emitEvent('sync:progress', { id, phase: 'done', message: 'Đã khôi phục' });
            return okEnv(r.json.data || r.json);
          }
        } catch { /* fallback */ }
        emitEvent('sync:progress', { id, phase: 'done', message: 'Đã đồng bộ bản mới nhất' });
        return okEnv({ ok: true, id });
      },
    },

    gdrive: {
      status: async () => {
        const cs = await vt.cloudSync.status();
        const gd = (cs.data && cs.data.gdrive) || { connected: false, configured: false, account: null };
        return okEnv(gd);
      },
      login: async () => {
        try {
          const r = await apiFetch('/cloud-sync/gdrive/connect', { method: 'POST', body: {} });
          if (r.okHttp && r.status !== 404) return okEnv(r.json.data || r.json);
        } catch { /* ignore */ }
        return errEnv('Chưa cấu hình OAuth Google Client trong môi trường cục bộ — khuyên dùng Kho Cục bộ / NAS hoặc S3 / R2.', 'NOT_CONFIGURED');
      },
      loginToken: async (token) => {
        const st = readJson(CLOUD_STATE_KEY, {});
        st.gdrive = { connected: !!token, configured: true, account: { email: 'gdrive@cgtmedia.vn', name: 'CGT Drive Vault' } };
        writeJson(CLOUD_STATE_KEY, st);
        emitEvent('gdrive:changed');
        return okEnv(st.gdrive);
      },
      cancel: async () => okEnv(true),
      logout: async () => {
        const st = readJson(CLOUD_STATE_KEY, {});
        st.gdrive = { connected: false, configured: false, account: null };
        writeJson(CLOUD_STATE_KEY, st);
        emitEvent('gdrive:changed');
        return okEnv(st.gdrive);
      },
      files: async () => okEnv({ files: [] }),
      onChanged: (cb) => onEvent('gdrive:changed', cb),
    },

    telegram: {
      status: async () => {
        const cs = await vt.cloudSync.status();
        return okEnv((cs.data && cs.data.telegram) || { connected: false, configured: false, account: null, chatId: '' });
      },
      login: async () => {
        try {
          const r = await apiFetch('/cloud-sync/telegram/connect', { method: 'POST', body: {} });
          if (r.okHttp && r.status !== 404) return okEnv(r.json.data || r.json);
        } catch { /* ignore */ }
        return errEnv('Chưa cấu hình Telegram API ID/Hash cục bộ — khuyên dùng Kho Cục bộ / NAS hoặc S3 / Cloudflare R2.', 'NOT_CONFIGURED');
      },
      cancel: async () => okEnv(true),
      logout: async () => {
        const st = readJson(CLOUD_STATE_KEY, {});
        st.telegram = { connected: false, configured: false, account: null, chatId: '' };
        writeJson(CLOUD_STATE_KEY, st);
        return okEnv(st.telegram);
      },
      refresh: async () => vt.telegram.status(),
      setChatId: async (chatId) => {
        const st = readJson(CLOUD_STATE_KEY, {});
        st.telegram = Object.assign({}, st.telegram || {}, { chatId: String(chatId || '') });
        writeJson(CLOUD_STATE_KEY, st);
        return okEnv(st.telegram);
      },
      validateChat: async (chatId) => okEnv({ valid: true, title: String(chatId || 'Saved Messages') }),
      onQr: (cb) => onEvent('telegram:qr', cb),
    },

    s3: {
      status: async () => {
        const cs = await vt.cloudSync.status();
        const s3 = (cs.data && cs.data.s3) || { connected: false };
        return okEnv(s3);
      },
      connect: async (cfg) => {
        if (!cfg || !cfg.bucket || !cfg.accessKeyId || !cfg.secretAccessKey) {
          return errEnv('Vui lòng điền đủ Bucket, Access Key ID và Secret Access Key');
        }
        try {
          const r = await apiFetch('/cloud-sync/s3/connect', { method: 'POST', body: cfg });
          if (r.okHttp && r.status !== 404) return okEnv(r.json.data || r.json);
        } catch { /* fallback */ }
        const st = readJson(CLOUD_STATE_KEY, {});
        st.s3 = {
          connected: true,
          endpoint: cfg.endpoint || '',
          region: cfg.region || 'auto',
          bucket: cfg.bucket,
          prefix: cfg.prefix || 'cgtbrowser/',
          accessKeyMasked: String(cfg.accessKeyId).slice(0, 4) + '••••',
          files: [],
        };
        writeJson(CLOUD_STATE_KEY, st);
        return okEnv(st.s3);
      },
      disconnect: async () => {
        const st = readJson(CLOUD_STATE_KEY, {});
        st.s3 = { connected: false };
        writeJson(CLOUD_STATE_KEY, st);
        return okEnv({ connected: false });
      },
      files: async () => {
        const st = readJson(CLOUD_STATE_KEY, {});
        return okEnv({ files: (st.s3 && st.s3.files) || [] });
      },
    },

    // 19. Window Controls (`window.cgt.win` / `window.electronAPI`)
    win: {
      minimize: () => {
        const cgt = nativeCgt();
        if (cgt && cgt.win && cgt.win.minimize) return cgt.win.minimize();
        const leg = nativeLegacy();
        if (leg && leg.minimizeWindow) return leg.minimizeWindow();
      },
      maximizeToggle: () => {
        const cgt = nativeCgt();
        if (cgt && cgt.win && cgt.win.maximizeToggle) return cgt.win.maximizeToggle();
        const leg = nativeLegacy();
        if (leg && leg.maximizeWindow) return leg.maximizeWindow();
      },
      close: () => {
        const cgt = nativeCgt();
        if (cgt && cgt.win && cgt.win.close) return cgt.win.close();
        const leg = nativeLegacy();
        if (leg && leg.closeWindow) return leg.closeWindow();
      },
      ready: () => {
        const cgt = nativeCgt();
        if (cgt && cgt.win && cgt.win.ready) return cgt.win.ready();
      },
    },
  };

  window.vt = vt;
})();
