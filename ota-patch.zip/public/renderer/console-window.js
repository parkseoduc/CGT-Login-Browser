// Renderer entry for the detached action-sync "Console" window (console.html).
//
// FRAMELESS, COMPACT-BY-DEFAULT control panel (matches MKTLogin's "Synchronizer >
// Console"): only the title bar + header + tabs show at rest; hovering anywhere
// over the window expands it to reveal the active tab's body + footer, and the
// window height follows the content exactly (driven back to the main process via
// vt.console.resize). Renders the SAME shared Console used by the in-app
// "Đồng bộ thao tác" view (buildSyncConsole) - we just re-compose its tabs + body
// under our own header. The scope (window ids the actions apply to) arrives in the
// URL hash and can be refreshed live by the main process via vt.console.onScope.
import { el } from './ui.js';
import { buildSyncConsole } from './views/sync-console.js';
import { tf } from './i18n.js';

// Match the app theme.
(async () => {
  try {
    const s = await vt.settings.all();
    document.documentElement.dataset.theme = s && s.theme === 'dark' ? 'dark' : 'light';
  } catch { /* default light */ }
})();

// Scope = ids passed via the loadFile hash; updated live by the main process.
let ids = decodeURIComponent((location.hash || '').replace(/^#/, '')).split(',').filter(Boolean);

const consoleApi = buildSyncConsole({ getScopeIds: () => ids.slice() });

// ---- title bar (draggable) with custom window controls --------------------
// "Thu nhỏ" collapses the panel back to compact (titlebar+header+tabs). It does
// NOT OS-minimize: the window is skipTaskbar/non-minimizable so it can never be
// sent to a taskbar it doesn't have. (setExpanded is a hoisted declaration below.)
const minBtn = el('button.cw-wbtn', { title: 'Thu nhỏ', html: '<svg viewBox="0 0 12 12"><path d="M2 6h8" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>', onclick: () => { try { setExpanded(false); } catch { /* ignore */ } } });
const closeBtn = el('button.cw-wbtn.cw-wclose', { title: 'Đóng', html: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M0 0h24v24H0z" fill="none"/><path fill="currentColor" d="M19 6.41L17.59 5L12 10.59L6.41 5L5 6.41L10.59 12L5 17.59L6.41 19L12 13.41L17.59 19L19 17.59L13.41 12z"/></svg>', onclick: () => { try { vt.console.close(); } catch { /* ignore */ } } });
const titlebar = el('div.cw-titlebar', {}, [
  el('span.cw-dots', { text: '⠿' }),
  el('div.cw-wctrls', {}, [minBtn, closeBtn]),
]);

// ---- header: app logo + title(count) ---------------------------------------
const titleEl = el('span.cw-title', { text: tf('Đồng bộ thao tác({0})', ids.length) });
const header = el('div.cw-header', {}, [
  el('span.cw-logo', { html: '<img src="assets/cgt-logo.svg" alt="CGTBrowser">' }),
  titleEl,
]);

// ---- expandable body (active tab content + footer hint) --------------------
const expand = el('div.cw-expand', {}, [
  consoleApi.bodyEl,
  el('div.cw-foot', { text: 'Sau khi đóng bảng điều khiển, bạn có thể mở lại thông qua [Synchronizer] > Console' }),
]);

const root = el('div.cw', {}, [titlebar, header, consoleApi.ctabsEl, expand]);
document.getElementById('app').appendChild(root);

function setTitleCount() { titleEl.textContent = tf('Đồng bộ thao tác({0})', ids.length); }

// Keep the live count fresh when the scope changes.
if (vt.console && vt.console.onScope) {
  vt.console.onScope((next) => {
    if (Array.isArray(next)) { ids = next.slice(); setTitleCount(); }
  });
}

// Keep the count in sync with the ACTUAL set of open Chrome windows: when a synced
// profile's browser is closed (or dies externally) the main process broadcasts the
// live running set, so we drop any scope id that is no longer open and refresh the
// header count. This makes the status reflect reality instead of the snapshot taken
// when the Console was first opened.
if (vt.profiles && vt.profiles.onRunningChanged) {
  vt.profiles.onRunningChanged((runIds) => {
    const live = new Set(Array.isArray(runIds) ? runIds : []);
    ids = ids.filter((id) => live.has(id));
    setTitleCount();
  });
}

// ---- compact ⇄ expanded; the OS window height tracks the panel exactly --------
// `.cw` hugs its content (align-self:flex-start in app.css), so root.scrollHeight
// is ALWAYS the true rendered height - we just push it to the main process via
// vt.console.resize so the window is a pixel-perfect fit (no empty padding, no
// clipped/unscrollable body). The shared body caps itself (max-height + overflow-y
// in app.css), so a tall tab scrolls inside a fixed-size window.
//
// Interaction: HOVER expands. The panel then STAYS expanded (it does NOT collapse on
// mouse-leave) until an actual CLICK lands somewhere OUTSIDE it. The main process
// watches the global mouse button + cursor position while expanded (console-window.js
// setWatch, polling GetAsyncKeyState/GetCursorPos - no input hook) and pushes
// 'console:collapse' here the moment a press happens outside the window bounds. This
// catches a click on EVERY surface (desktop, this app, a synced Chrome window, any
// other window) - unlike the old focus/blur path, which Windows' foreground lock
// defeated for cross-process clicks (the hover-time win.focus() was denied while
// another process was in front, so a click on a Chrome window never produced a blur).
// The window itself never minimises/hides (skipTaskbar + alwaysOnTop +
// non-minimizable in main); it only CLOSES via its ✕ button or when action-sync stops.
let raf = 0;
let compactH = 0;     // collapsed height (with the +20% breathing room), measured once
let expanded = false;

function pushHeight() {
  const h = (expanded ? Math.ceil(root.scrollHeight) : compactH) || Math.ceil(root.scrollHeight);
  try { vt.console.resize(h); } catch { /* ignore */ }
}
function syncHeight() {
  if (raf) cancelAnimationFrame(raf);
  raf = requestAnimationFrame(() => { raf = 0; pushHeight(); });
}
function setExpanded(on) {
  if (on === expanded) return;
  expanded = on;
  root.classList.toggle('is-expanded', on);
  syncHeight();
  // Run the main-process outside-click watch ONLY while expanded.
  try { vt.console.watch(on); } catch { /* ignore */ }
}

// HOVER expands. Collapse is driven by the main process' outside-click watch.
root.addEventListener('mouseenter', () => { setExpanded(true); });
if (vt.console && vt.console.onCollapse) {
  vt.console.onCollapse(() => { setExpanded(false); });
}

// Follow in-place content growth while expanded (tab switch / "Thêm nhóm văn bản").
// Observing root is safe: it hugs content, so resizing the window never changes
// root's height and can't feed back into a resize loop.
try { new ResizeObserver(() => { if (expanded) syncHeight(); }).observe(root); } catch { /* ignore */ }

// Measure the collapsed height once everything (incl. the logo image) has laid out,
// then add ~20% breathing room. The extra is applied as bottom padding on .cw (only
// while collapsed - see app.css) so the panel itself grows to fill the taller window
// rather than leaving an empty strip of background below a content-hugging .cw.
requestAnimationFrame(() => {
  const base = Math.ceil(root.scrollHeight);     // natural compact height
  const pad = Math.round(base * 0.2);            // +20%
  root.style.setProperty('--cw-compact-pad', pad + 'px');
  compactH = base + pad;
  pushHeight();
});

// Close the window only when sync TRANSITIONS from running → stopped. We must NOT close
// merely because sync isn't running at open time: the user can detach the Console via the
// "Thu gọn" button while sync is idle, and it should stay open (until ✕ / Khôi phục) just
// like it does while sync is running. Tracking the previous state avoids the old bug where
// the window flashed open and instantly closed when collapsed without sync running.
let wasRunning = false;
vt.sync.onStatus((st) => {
  const run = !!(st && st.running);
  if (wasRunning && !run) { try { vt.console.close(); } catch { /* ignore */ } }
  wasRunning = run;
});
vt.sync.status().then((st) => { wasRunning = !!(st && st.running); }).catch(() => {});
