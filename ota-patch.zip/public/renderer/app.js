// Renderer bootstrap: builds the shell (sidebar + header), applies the saved
// theme, and routes between views. Mirrors the WPF MainWindow shell.
import { el, clear, iconBtn, installTooltips, openMenu, openModal, closeModal, toast, customSelect, withSpin } from './ui.js';
import { icon } from './icons.js';
import { renderLogin } from './views/login.js';
import { remote } from './data/remote-ds.js';
import { loadPermissions } from './data/team-permissions.js';
import { loadPlanFeatures, clearPlanFeatures, hasFeature, gateFeature, isPlanExpired } from './data/plan-features.js';
import { notifyError, errorMessage } from './data/errors.js';
import { setLang, getLang, applyI18n, tf, fmtDate } from './i18n.js';
import { checkForUpdates, openUpdateModal, renderDropdownBody, subscribe as subscribeUpdates, hasPendingUpdate } from './ui/update-modal.js';
import { showPromoModal } from './ui/promo-modal.js';
import { mountPromoBanner } from './ui/promo-banner.js';
import { inAppInfoBubble } from './ui/info-bubble.js';
import { ensureKernelOnStartup, syncActiveKernelToFingerprint } from './views/kernels.js';
import { registerKernelBuild, registerFirefoxBuild } from './data/fingerprint.js';

// Tiêu đề cửa sổ = "CGTBrowser <phiên bản>", đọc từ package.json qua window.vt.appVersion.
// Phải đặt ở đây chứ không ghi trong <title> của index.html: thẻ <title> tĩnh ĐÈ LÊN tuỳ
// chọn `title` của BrowserWindow, nên ghi cứng ở đó là tiêu đề kẹt lại bản cũ sau mỗi lần
// nâng phiên bản. Chạy NGAY lúc nạp module, trước mọi thao tác dựng giao diện.
(() => {
  const v = (window.vt && window.vt.appVersion) || '';
  document.title = v ? `CGTBrowser ${v}` : 'CGTBrowser';
})();

// Nạp danh mục User-Agent do web admin quản lý (server /user-agents/list) MỘT LẦN lúc
// khởi động và merge vào bộ chọn UA cục bộ (CHROME_BUILDS/Firefox trong fingerprint.js).
// Vì thế lúc chọn/đổi UA KHÔNG gọi API (không lag) - bộ chọn chỉ đọc bảng trong bộ nhớ.
// Best-effort: lỗi mạng thì main trả cache đĩa; hết cách thì giữ danh sách hardcode sẵn.
async function loadUserAgentCatalog() {
  try {
    const res = await vt.userAgents.list('chromium');
    const versions = res && res.ok && res.data && Array.isArray(res.data.versions) ? res.data.versions : [];
    for (const v of versions) registerKernelBuild(v);
  } catch { /* giữ danh sách hardcode */ }
  try {
    const res = await vt.userAgents.list('firefox');
    const versions = res && res.ok && res.data && Array.isArray(res.data.versions) ? res.data.versions : [];
    for (const v of versions) registerFirefoxBuild(v);
  } catch { /* giữ danh sách hardcode */ }
}

// Sidebar nav. Top-level leaf entries, then two collapsible SECTIONS
// ("Tự Động Hóa" and "Nhóm") that each group related pages under a gray header
// with a collapse chevron (AdsPower-style). A section item can itself be a leaf
// or an expandable group (e.g. "Quy Trình RPA" with its sub-pages).
const NAV = [
  { route: 'profiles', label: 'Hồ sơ', icon: 'profiles' },
  { route: 'groups', label: 'Nhóm', icon: 'folder' },
  { route: 'proxies', label: 'Proxies', icon: 'proxies' },
  { route: 'extensions', label: 'Tiện ích', icon: 'extensions' },
  { route: 'sync_data', label: 'Dữ liệu đồng bộ', icon: 'syncData', badge: 'Quan trọng' },
  { route: 'trash', label: 'Thùng rác', icon: 'trash' },
  { section: 'Tự động hóa', items: [
    { route: 'sync', label: 'Đồng bộ thao tác', icon: 'syncActions' },
    { label: 'Tự động hóa', icon: 'automation', children: [
      { route: 'automation', label: 'Quy trình', icon: 'process' },
      { route: 'tasks', label: 'Nhiệm vụ', icon: 'taskDoc' },
      { route: 'scheduler', label: 'Lập lịch', icon: 'calendarDays' },
      { route: 'script_store', label: 'Chợ', icon: 'bag' },
    ] },
    { route: 'api', label: 'Tài liệu API', icon: 'api' },
    /* MCP: ngay DƯỚI "Tài liệu API" (user chốt 2026-10-05). Nhãn "NEW !" đã BỎ (user 2026-11-07).
       Biến thể `badgeKind: 'new'` (chữ đỏ, không nền) vẫn còn trong buildNav nếu cần gắn cho mục khác. */
    { route: 'mcp', label: 'MCP', icon: 'mcp' },
  ] },
  { section: 'Nhóm', items: [
    { route: 'members', label: 'Thành viên nhóm', icon: 'usersGroup' },
    /* "Quản lý thiết bị": trang riêng trên sidebar (chủ sở hữu 2026-11-12), trước là tab trong trang Nâng cấp gói. */
    { route: 'devices', label: 'Quản lý thiết bị', icon: 'monitor' },
    { route: 'log', label: 'Nhật ký hoạt động', icon: 'logList' },
    { route: 'settings', label: 'Cài đặt', icon: 'settings' },
  ] },
];

const state = {
  settings: null,
  route: null,   // currently-shown route (null before the first navigate)
  collapsed: false,
  hosts: new Map(), // route -> { node, api, volatile } - kept-alive view DOM
  account: null, // logged-in server account (null until authenticated)
  runningIds: [], // live set of currently-open profile ids (kept fresh session-wide)
  workspaces: [], // các workspace tài khoản thuộc về (của mình + được mời)
  activeWorkspaceId: '', // workspace đang hoạt động (khớp header x-workspace-id ở main)
  walletBalance: null, // số dư ví workspace đang hoạt động (null = chưa nạp xong)
};

// Định dạng số dư ví hiển thị trên header (dưới email). Số đầy đủ có dấu phân cách
// cho rõ ràng; chỉ rút gọn khi RẤT lớn (≥1 tỷ) để không tràn ô 160px.
function fmtWalletVnd(n) {
  const v = Number(n) || 0;
  if (v >= 1e9) return (v / 1e9).toFixed(v % 1e9 ? 1 : 0).replace('.', ',') + ' tỷ ₫';
  return v.toLocaleString('vi-VN') + '₫';
}

// Nạp số dư ví (theo workspace đang hoạt động) rồi cập nhật ô "Số dư" cạnh avatar.
// Best-effort: lỗi mạng/chưa đăng nhập → giữ nguyên. Gọi sau mountShell + đổi ws.
async function refreshWalletBalance() {
  try {
    const w = await vt.wallet.get();
    state.walletBalance = Number(w && w.balance) || 0;
  } catch { return; }
  const elBal = document.getElementById('user-balance');
  if (elBal) elBal.textContent = fmtWalletVnd(state.walletBalance);
}

// Keep-alive routing: a view's DOM stays mounted (hidden) when you navigate away
// and is re-shown as-is on return, so ALL page state survives - scroll position,
// text inputs, active tab, filters, selection, sub-navigation. Views may export
// optional `onHide()`/`onShow(param)` hooks (e.g. to pause polling timers while
// hidden). `destroy()` is only called when a host is evicted (logout/unmount) or
// for a VOLATILE route (see below).
//
// VOLATILE routes are param-driven / single-use editors that must render fresh
// every time (their content depends on `param`, or they're a one-shot form), so
// they are never cached and get destroyed the moment you leave them.
//   - profile_create / profile_create_batch: keyed by the profile id in `param`.
//   - automation: the RPA editor attaches GLOBAL window listeners (mousemove /
//     mouseup / keydown) + toggles the header, all torn down only in destroy();
//     keeping it alive would leave those handlers firing on every other page.
//   - mcp: trang đọc TRẠNG THÁI GÓI (`paid`) lúc dựng. Nếu cache lại thì khách vừa
//     nâng cấp xong quay về vẫn thấy dải "chỉ hỗ trợ gói trả phí" - bắt dựng lại mỗi
//     lượt vào là tự hết, rẻ hơn nhiều so với thêm một kênh thông báo đổi gói.
// 'affiliate' nằm trong danh sách VÌ TIỀN: số dư hoa hồng do JOB QUÉT bên server đổi (5
// phút/lượt) và do admin duyệt lệnh rút, tức là nó đổi SAU LƯNG app. Giữ host sống lại là
// khách rời trang rồi quay lại vẫn thấy số cũ và tưởng hoa hồng chưa về / lệnh rút chưa duyệt.
// 'checkout' / 'topup' VÌ TIỀN như 'upgrade': số dư + đơn đọc lại mỗi lượt vào, không giữ host cũ.
const VOLATILE_ROUTES = new Set(['profile_create', 'profile_create_batch', 'automation', 'upgrade', 'devices', 'checkout', 'topup', 'mcp', 'affiliate']);

const views = {}; // route -> loader
function loader(route, importer) { views[route] = importer; }
loader('profiles', () => import('./views/profiles.js'));
loader('profile_create', () => import('./views/profile_create.js'));
loader('profile_create_batch', () => import('./views/profile_create_batch.js'));
loader('groups', () => import('./views/groups.js'));
loader('proxies', () => import('./views/proxies.js'));
loader('automation', () => import('./views/automation.js'));
loader('tasks', () => import('./views/tasks.js'));
loader('task_edit', () => import('./views/task_edit.js'));
loader('scheduler', () => import('./views/scheduler.js'));
loader('script_store', () => import('./views/market.js'));
loader('sync', () => import('./views/sync.js'));
loader('extensions', () => import('./views/extensions.js'));
loader('sync_data', () => import('./views/sync_data.js'));
loader('members', () => import('./views/members.js'));
loader('api', () => import('./views/api.js'));
loader('trash', () => import('./views/trash.js'));
loader('settings', () => import('./views/settings.js'));
loader('account', () => import('./views/account.js'));
loader('log', () => import('./views/log.js'));
loader('about', () => import('./views/about.js'));
loader('upgrade', () => import('./views/upgrade.js'));
loader('devices', () => import('./views/devices.js'));
// Bước 2 mua gói / thiết bị + trang Nạp tiền (port web landing /checkout, /topup) - xem views/pay-common.js.
loader('checkout', () => import('./views/checkout.js'));
loader('topup', () => import('./views/topup.js'));
loader('mcp', () => import('./views/mcp.js'));
loader('affiliate', () => import('./views/affiliate.js'));

const PLACEHOLDER_META = {
  proxies: ['proxies', 'Proxies', 'Quản lý danh sách proxy dùng cho hồ sơ.'],
  tasks: ['automation', 'Nhiệm Vụ', 'Quản lý và theo dõi các nhiệm vụ tự động hóa.'],
  scheduler: ['log', 'Lập Lịch', 'Lên lịch chạy kịch bản theo thời gian.'],
  script_store: ['store', 'Chợ', 'Khám phá và cài đặt các kịch bản tự động hóa có sẵn.'],
  members: ['usersGroup', 'Thành viên nhóm', 'Quản lý thành viên và phân quyền trong workspace.'],
  api: ['api', 'Tài Liệu API', 'Quản lý khóa API và tích hợp dịch vụ bên ngoài.'],
  log: ['log', 'Nhật ký hoạt động', 'Lịch sử hoạt động và nhật ký hệ thống.'],
  profile_create_batch: ['copy', 'Tạo Hàng Loạt', 'Tạo nhiều hồ sơ cùng lúc - giao diện đang được thiết kế.'],
};

function applyTheme(theme) {
  document.documentElement.dataset.theme = theme === 'dark' ? 'dark' : 'light';
}

// Contrast = the outermost background layer (body → var(--window-bg)). 'f9' switches
// it to #F9F9F9; 'default' keeps the theme's own window-bg. The CSS override is
// scoped to light theme (see app.css), so this is a no-op visually in dark mode.
function applyContrast(contrast) {
  if (contrast === 'f9') document.documentElement.dataset.contrast = 'f9';
  else delete document.documentElement.dataset.contrast;
}

// Switch theme + persist + keep the header toggle icon in sync. Used by both the
// header button and the account-menu "Chủ đề" submenu.
function setTheme(next) {
  applyTheme(next);
  if (state.settings) state.settings.theme = next;
  vt.settings.set({ theme: next });
  const tb = document.getElementById('theme-btn');
  if (tb) tb.innerHTML = icon(next === 'dark' ? 'themeSun' : 'themeMoon');
}

// Switch the outermost-layer contrast + persist. Used by the account-menu
// "Độ tương phản" submenu. 'default' = theme's own window-bg, 'f9' = #F9F9F9.
function setContrast(next) {
  applyContrast(next);
  if (state.settings) state.settings.contrast = next;
  vt.settings.set({ contrast: next });
}

// Switch the UI language + persist + re-translate the whole body live (incl. the
// kept-alive hidden views). Used by the account-menu "Ngôn ngữ" submenu. Default
// is Vietnamese ('vi'), which restores the app's authored strings.
function setLanguage(next) {
  setLang(next);
  if (state.settings) state.settings.language = next;
  if (state.settings) state.settings.languagePicked = true;
  vt.settings.set({ language: next, languagePicked: true });
  // Translate the shell (sidebar / header / menus) in place, then rebuild the
  // active view from scratch so strings composed at render time (paginator
  // "1-8 trên 8", relative times "3 giờ trước", combobox option lists…) are
  // re-emitted in the new language rather than left stale. Cached hosts are
  // dropped; they re-render in the new language the next time they're visited.
  applyI18n(document.body);
  // Keep the header flag in sync with the chosen language.
  const lb = document.getElementById('lang-btn');
  if (lb) lb.innerHTML = icon(LANG_FLAG[next] || 'flagVi');
  const route = state.route;
  if (route) {
    resetHosts();
    state.route = null;   // force navigate() to treat this as a fresh render
    navigate(route);
  }
}

// Cho trang "Cài đặt" điều khiển ĐÚNG cùng logic (persist + áp dụng live) với các nút
// ở header / menu tài khoản, thay vì tự nhân bản. Đọc giá trị hiện tại qua get().
if (typeof window !== 'undefined') {
  window.__appPrefs = {
    setTheme, setLanguage, setContrast,
    get: () => ({
      theme: (state.settings && state.settings.theme) || 'light',
      language: getLang() || 'vi',
      contrast: (state.settings && state.settings.contrast) || 'default',
    }),
  };
}

// route -> the parent group label whose children include it (for auto-expand).
// Descends into sections so grouped sub-pages still auto-expand their group.
const ROUTE_GROUP = {};
function indexGroups(items) {
  items.forEach((item) => {
    if (item.section) indexGroups(item.items);
    else if (item.children) item.children.forEach((c) => { ROUTE_GROUP[c.route] = item.label; });
  });
}
indexGroups(NAV);

// route -> page title shown in the header (left side). Built from the nav labels
// (leaf entries + grouped sub-items), plus a few routes that aren't in the rail.
const ROUTE_TITLE = {};
function indexTitles(items) {
  items.forEach((item) => {
    if (item.section) indexTitles(item.items);
    else if (item.children) item.children.forEach((c) => { ROUTE_TITLE[c.route] = c.label; });
    else if (item.route) ROUTE_TITLE[item.route] = item.label;
  });
}
indexTitles(NAV);
Object.assign(ROUTE_TITLE, {
  profile_create: 'Tạo hồ sơ',
  profile_create_batch: 'Tạo hàng loạt',
  task_edit: 'Chỉnh sửa nhiệm vụ',
  about: 'Giới thiệu',
  account: 'Hồ sơ đăng ký',
  upgrade: 'Nâng cấp gói',
  // Không có trong NAV (vào từ dải mép thẻ gói + menu tài khoản) nên PHẢI khai ở đây, không
  // thì tiêu đề header trống trơn khi mở trang.
  affiliate: 'Hoa hồng',
});
function routeTitle(route) { return ROUTE_TITLE[route] || (PLACEHOLDER_META[route] && PLACEHOLDER_META[route][1]) || ''; }
function setHeaderTitle(route) {
  const t = document.getElementById('header-title');
  if (t) t.textContent = routeTitle(route);
}

function highlightNav(route) {
  // leaf items + sub-items: active when their route matches
  document.querySelectorAll('.nav-item[data-route], .nav-sub-item[data-route]').forEach((n) =>
    n.classList.toggle('active', n.dataset.route === route));
  // group headers: highlight the GROUP ICON only when the rail is COLLAPSED (the
  // sub-items are hidden then, so the parent icon stands in for the active child).
  // When EXPANDED the active sub-item carries the highlight instead, so the header
  // stays un-highlighted.
  const activeGroup = ROUTE_GROUP[route] || null;
  document.querySelectorAll('.nav-group').forEach((g) => {
    const isActive = g.dataset.group === activeGroup;
    g.querySelector('.nav-item').classList.toggle('active', isActive && state.collapsed);
    // auto-expand the group that owns the active route (only matters when expanded)
    if (isActive && g.classList.contains('collapsed')) toggleGroup(g);
  });
}

// Destroy a cached host: run its view's destroy() and remove its DOM.
function destroyHost(route) {
  const h = state.hosts.get(route);
  if (!h) return;
  try { h.api && typeof h.api.destroy === 'function' && h.api.destroy(); } catch { /* ignore */ }
  try { h.node.remove(); } catch { /* ignore */ }
  state.hosts.delete(route);
}
// Tear down cached hosts (logout / shell re-mount). Truyền `keep` (mảng route) để
// GIỮ LẠI một số view không dựng lại - vd "Chợ" (script_store) khi đổi workspace:
// dữ liệu chợ là PUBLIC nên không cần nạp lại theo workspace.
function resetHosts(keep) {
  const keepSet = new Set(keep || []);
  [...state.hosts.keys()].forEach((route) => { if (!keepSet.has(route)) destroyHost(route); });
}

// Bộ đếm thế hệ điều hướng: mỗi lần navigate() được gọi sẽ tăng lên. Một lần
// navigate đang chờ import() bất đồng bộ mà bị một lần navigate MỚI vượt qua
// (vd chuyển workspace liên tục) sẽ tự bỏ dở khi import xong (không set host/
// không đụng progress) → không còn host mồ côi hay trạng thái kẹt.
let _navSeq = 0;

// Đang mở hộp thoại "chưa lưu thay đổi" thì bỏ qua mọi cú bấm điều hướng khác,
// nếu không mỗi cú bấm lại dựng thêm một hộp thoại đè lên (openModal xoá sạch
// modal-host) và Promise của hộp cũ treo mãi.
let _leaveAsking = false;

// ── Khoá cứng khi thuê bao HẾT HẠN ─────────────────────────────────────────
// Hết hạn = KHÔNG được dùng bất kỳ tính năng nào (kể cả chủ sở hữu, dù số dư hồ
// sơ còn). Cách hiển thị: GIỮ trang chính ở "Hồ sơ" nhưng phủ lên vùng nội dung
// một THẺ GÓI (.plan-card) ngay CHÍNH GIỮA - thông báo hết hạn + nút "Gia hạn
// ngay". Đồng thời enable=false TOÀN UI qua class body.app-expired (CSS làm mờ +
// chặn bấm thanh bên + bộ chọn workspace). Chỉ trang Nâng cấp (gia hạn) + Hồ sơ
// đăng ký mới gỡ thẻ phủ để thao tác. Server VẪN enforce 403. Gia hạn → mở khoá.
// Gói hết hạn vẫn phải TRẢ TIỀN được để gia hạn ⇒ cho cả 'checkout' + 'topup'.
const EXPIRED_ALLOWED_ROUTES = new Set(['upgrade', 'devices', 'checkout', 'topup', 'account']);

let _expiredCard = null;
function showExpiredCard() {
  const content = document.getElementById('content');
  if (!content || _expiredCard) return;
  // Mirror giá trị "Hết hạn lúc"/"Hồ Sơ" từ thẻ gói ở thanh bên (server-driven).
  const grid = buildPlanGrid(false);
  const vals = grid.querySelectorAll('.plan-row-v');
  const exp = document.getElementById('plan-expiry');
  const prof = document.getElementById('plan-profiles');
  const mem = document.getElementById('plan-members');
  if (exp && vals[0]) vals[0].textContent = exp.textContent;
  if (prof && vals[1]) vals[1].textContent = prof.textContent;
  if (mem && vals[2]) vals[2].textContent = mem.textContent;
  const card = el('div.plan-card.expired-plan-card', {}, [
    // Dải mép trên thẻ gói: cụm trái (icon đồng tiền + "Nhận hoa hồng") + mũi tên "⇀" bên
    // phải; click cả dải -> trang "Hoa hồng". Style ở app.css `.plan-card > .plan-deco`.
    // Ba nơi render thẻ (sidebar / flyout / hết hạn) dùng chuỗi HTML y hệt để dải đồng nhất
    // ⇒ SỬA MỘT NƠI LÀ PHẢI SỬA CẢ BA, không thì ba thẻ dẫn đi hai trang khác nhau mà không
    // có lỗi nào báo (dùng replace_all / sửa xong grep lại 'plan-deco').
    el('div.plan-deco', { onclick: () => navigate('affiliate'), html: `<span class="plan-deco-left"><span class="plan-deco-ico">${icon('planCoin')}</span><span class="plan-deco-label">Nhận hoa hồng</span></span><span class="plan-deco-arrow">\u21C0</span>` }),
    el('div.plan-top', {}, [
      el('span.plan-badge', { html: icon('planHome') }),
      el('div.plan-title', { text: 'Gói thuê bao đã hết hạn' }),
    ]),
    el('div.expired-sub', { text: 'Vui lòng gia hạn để tiếp tục sử dụng để tránh bị gián đoạn' }),
    grid,
    el('button.plan-upgrade', {
      onclick: () => navigate('upgrade'),
      html: `<span class="plan-upgrade-ico">${icon('planUpgrade')}</span><span>Gia hạn ngay</span>`,
    }),
  ]);
  const overlay = el('div.expired-overlay#expired-overlay', {}, [card]);
  content.appendChild(overlay);
  _expiredCard = overlay;
}
function hideExpiredCard() {
  if (!_expiredCard) return;
  try { _expiredCard.remove(); } catch { /* ignore */ }
  _expiredCard = null;
}

// Áp trạng thái hết-hạn lên toàn UI (đọc cache đồng bộ isPlanExpired()). Gọi sau
// mỗi lần loadPlanFeatures() (khởi động / đổi workspace / sau khi gia hạn) và ở
// cuối navigate() (để thẻ phủ theo đúng route hiện tại).
function enforceExpiry() {
  const expired = isPlanExpired();
  document.body.classList.toggle('app-expired', expired);
  // Chỉ phủ thẻ gói khi đang ở route bị khoá (Hồ sơ…); ở trang Gia hạn/Hồ sơ đăng
  // ký thì GỠ thẻ để người dùng thao tác gia hạn/đăng xuất.
  if (expired && !EXPIRED_ALLOWED_ROUTES.has(state.route)) showExpiredCard();
  else hideExpiredCard();
}
// Cho trang Nâng cấp gọi sau khi gia hạn thành công để mở khoá lại ngay.
window.__vtRecheckExpiry = async () => {
  try { await loadPlanFeatures(true); } catch { /* giữ nguyên nếu lỗi mạng */ }
  enforceExpiry();
};

async function navigate(route, param) {
  // Hỏi TRƯỚC khi động vào bất cứ thứ gì: bên dưới là destroyHost() (xoá DOM +
  // trạng thái trong bộ nhớ) và state.route/highlightNav đã đổi - hỏi sau thì có
  // trả lời "ở lại" cũng không còn gì để ở lại.
  if (_leaveAsking) return;

  // KHÔNG cổng gói cho route 'api' (user bỏ 2026-09-27). "Tài liệu API" là TÀI LIỆU: gói Free
  // được vào ĐỌC - biết API làm được gì mới có lý do nâng cấp, chặn ở cửa thì khách không bao
  // giờ thấy thứ mình đang bán. Chỗ chặn thật vẫn nguyên ở main/local-api.js: mọi endpoint (trừ
  // /status và /v3/api-docs) trả 403 kèm câu "api chỉ hỗ trợ đối với gói trả phí." - nên "Try it
  // out" ở gói Free hiện đúng lý do, không phải lỗi mơ hồ.
  if (route !== state.route) {
    const cur = state.hosts.get(state.route);
    const ask = cur && cur.api && cur.api.confirmLeave;
    if (typeof ask === 'function') {
      _leaveAsking = true;
      let mayLeave = true;
      try { mayLeave = await ask(); } catch { mayLeave = true; }
      _leaveAsking = false;
      if (!mayLeave) return;
    }
  }

  const myGen = ++_navSeq;
  const prevRoute = state.route;
  state.route = route;
  highlightNav(route);
  setHeaderTitle(route);
  vt.settings.set({ activeRoute: route });
  const content = document.getElementById('content');

  // Cập nhật thẻ phủ "hết hạn" theo route mới: route bị khoá → phủ thẻ gói giữa
  // màn; route Gia hạn/Hồ sơ đăng ký → gỡ thẻ để thao tác. (No-op khi còn hạn.)
  enforceExpiry();

  // Leave the previously-shown view: destroy it if volatile, otherwise just hide
  // it (its DOM + state stay alive for a later return) and pause it via onHide().
  if (prevRoute && prevRoute !== route) {
    const prev = state.hosts.get(prevRoute);
    if (prev) {
      if (prev.volatile) destroyHost(prevRoute);
      else { prev.node.style.display = 'none'; try { prev.api && prev.api.onHide && prev.api.onHide(); } catch { /* ignore */ } }
    }
  }

  const volatile = VOLATILE_ROUTES.has(route) || param != null;

  // Re-show a kept-alive host instantly - scroll/inputs/tab/filters are exactly as
  // the user left them. Still flash the top progress bar so EVERY page switch has
  // the same visual feedback (brief run, since there's no async load to wait on).
  const cached = state.hosts.get(route);
  if (cached && !volatile) {
    startProgress();
    cached.node.style.display = '';
    try { cached.api && cached.api.onShow && cached.api.onShow(param); } catch { /* ignore */ }
    applyI18n(document.body);
    // No async load to await here, so give the bar a brief run before completing
    // (two rAFs let the 'active' width transition actually start painting).
    requestAnimationFrame(() => requestAnimationFrame(() => endProgress()));
    return;
  }
  // A volatile route (or a re-entry with a new param) must render fresh.
  if (cached) destroyHost(route);

  startProgress();
  const node = el('div.view-host', { dataset: { route } });
  content.appendChild(node);

  const importer = views[route];
  if (!importer) { node.appendChild(placeholder(route)); state.hosts.set(route, { node, api: null, volatile }); applyI18n(document.body); endProgress(); return; }
  try {
    const mod = await importer();
    if (myGen !== _navSeq) { try { node.remove(); } catch { /* ignore */ } return; }
    const ctx = { container: node, navigate, meta: PLACEHOLDER_META[route], param };
    const api = (mod.render ? mod.render(ctx) : null) || null;
    state.hosts.set(route, { node, api, volatile });
  } catch (err) {
    if (myGen !== _navSeq) { try { node.remove(); } catch { /* ignore */ } return; }
    console.error('view load failed', route, err);
    node.appendChild(el('div.placeholder-view', {}, [
      el('div.big', { html: icon('about') }),
      el('div', { text: 'Không tải được màn hình: ' + route }),
      el('div.muted', { text: String(err && err.message || err) }),
    ]));
    state.hosts.set(route, { node, api: null, volatile });
  } finally {
    if (myGen === _navSeq) { applyI18n(document.body); endProgress(); }
  }
}

function placeholder(route) {
  const meta = PLACEHOLDER_META[route] || ['about', route, ''];
  return el('div.placeholder-view', {}, [
    el('div.big', { html: icon(meta[0]) }),
    el('h2', { text: meta[1] }),
    el('div.muted', { text: meta[2] }),
  ]);
}

// shared tooltip element (only shown while sidebar is collapsed). Appended to
// body so the sidebar's overflow:hidden can't clip it. No show/hide delay.
let navTip = null;
function showTip(target, text) {
  if (!state.collapsed) return;
  if (!navTip) { navTip = el('div.app-tooltip.nav-tooltip'); document.body.appendChild(navTip); }
  navTip.textContent = text;
  const r = target.getBoundingClientRect();
  navTip.style.left = (r.right + 10) + 'px';
  navTip.style.top = (r.top + r.height / 2) + 'px';
  navTip.style.display = 'block';
}
function hideTip() { if (navTip) navTip.style.display = 'none'; }

// Collapsed-sidebar flyout: when the rail is collapsed, an expandable GROUP can't
// show its sub-items inline (the .nav-sub is hidden at 64px width), so hovering the
// group icon pops its children out to the RIGHT as a clickable panel (AdsPower-style).
// Appended to <body> so the sidebar's overflow can't clip it. A short hide-delay +
// the panel's own mouseenter let the pointer travel across the gap into the flyout.
let navFly = null, navFlyTimer = null;
function showFlyout(target, item) {
  if (!state.collapsed) return;
  if (!navFly) {
    navFly = el('div.nav-flyout');
    navFly.addEventListener('mouseenter', () => clearTimeout(navFlyTimer));
    navFly.addEventListener('mouseleave', hideFlyout);
    document.body.appendChild(navFly);
  }
  clearTimeout(navFlyTimer);
  clear(navFly);
  item.children.forEach((c) => navFly.appendChild(
    el('button.nav-flyout-item' + (state.route === c.route ? '.active' : ''), {
      dataset: { route: c.route },
      onclick: () => { hideFlyout(); navigate(c.route); },
      html: `<span class="ico">${icon(c.icon)}</span><span class="label">${c.label}</span>`,
    })
  ));
  const r = target.getBoundingClientRect();
  navFly.style.left = (r.right + 8) + 'px';
  navFly.style.top = r.top + 'px';
  navFly.style.display = 'block';
}
function hideFlyout() {
  navFlyTimer = setTimeout(() => { if (navFly) navFly.style.display = 'none'; }, 140);
}

// ── GHIM mục menu (user 2026-11-02): rê chuột vào mục ⇒ hiện icon ghim nhỏ bên phải; bấm ⇒ mục DỜI LÊN ĐẦU sidebar
// (khối .nav-pinned), bấm lần nữa ⇒ trả về chỗ cũ. Ghim được mục lá (khoá = route) và cả nhóm có mục con như
// "Tự động hóa" (khoá = 'group:<nhãn>', dời cả nhóm). Mục con trong nhóm KHÔNG ghim riêng. Thứ tự khối ghim = thứ tự
// bấm ghim. Lưu ở settings.pinnedNav (main/settings.js nhận khoá tuỳ ý, không cần DEFAULTS).
const navPinKey = (item) => item.route || ('group:' + item.label);
function pinnedNavKeys() {
  const all = new Set();
  const walk = (items) => items.forEach((it) => { if (it.section) walk(it.items); else all.add(navPinKey(it)); });
  walk(NAV);
  const list = (state.settings && Array.isArray(state.settings.pinnedNav)) ? state.settings.pinnedNav : [];
  return list.filter((k, i) => all.has(k) && list.indexOf(k) === i);
}
function navPinHtml(item, pinned) {
  return `<span class="nav-pin" data-pin="${navPinKey(item)}" title="${pinned ? 'Bỏ ghim' : 'Ghim lên đầu'}">${icon(pinned ? 'navPinFilled' : 'navPinOutline')}</span>`;
}
function buildNavContent() {
  const pinned = pinnedNavKeys();
  if (!pinned.length) return NAV.map((it) => buildNavItem(it, false));
  const find = (key, items = NAV) => {
    for (const it of items) { const hit = it.section ? find(key, it.items) : (navPinKey(it) === key ? it : null); if (hit) return hit; }
    return null;
  };
  const top = el('div.nav-pinned', {}, pinned.map((k) => buildNavItem(find(k), true)));
  const rest = NAV.map((it) => (it.section ? { ...it, items: it.items.filter((x) => !pinned.includes(navPinKey(x))) } : it))
    .filter((it) => (it.section ? it.items.length : !pinned.includes(navPinKey(it))));
  return [top, ...rest.map((it) => buildNavItem(it, false))];
}
// Dựng lại nav sau khi ghim/bỏ ghim: giữ nguyên trạng thái đóng/mở của section và nhóm.
function rebuildNav() {
  const nav = document.querySelector('#sidebar .nav');
  if (!nav) return;
  const closedSections = [...nav.querySelectorAll('.nav-section.collapsed')].map((x) => x.dataset.section);
  const openGroups = [...nav.querySelectorAll('.nav-group:not(.collapsed)')].map((x) => x.dataset.group);
  nav.replaceChildren(...buildNavContent());
  nav.querySelectorAll('.nav-section').forEach((x) => x.classList.toggle('collapsed', closedSections.includes(x.dataset.section)));
  nav.querySelectorAll('.nav-group').forEach((x) => { if (openGroups.includes(x.dataset.group)) x.classList.remove('collapsed'); });
  if (state.route) highlightNav(state.route);
  applyI18n(nav);
}
function toggleNavPin(key) {
  const cur = pinnedNavKeys();
  const next = cur.includes(key) ? cur.filter((k) => k !== key) : [...cur, key];
  if (state.settings) state.settings.pinnedNav = next;
  vt.settings.set({ pinnedNav: next });
  rebuildNav();
  // Vừa GHIM ⇒ cuộn danh sách lên đầu để thấy mục vừa dời lên (bấm ghim ở mục nằm thấp thì khối ghim khuất phía trên).
  const nav = document.querySelector('#sidebar .nav');
  if (nav && next.length > cur.length) nav.scrollTo({ top: 0, behavior: 'smooth' });
}

function buildNavItem(item, pinned = false) {
  // Collapsible section: gray header (label + chevron) over a body of nav items.
  // The body wraps its items in an inner element so the open/close can animate
  // smoothly via a grid-template-rows 0fr↔1fr transition (height-agnostic).
  if (item.section) {
    const inner = el('div.nav-section-inner', {}, item.items.map((it) => buildNavItem(it, false)));
    const body = el('div.nav-section-body', {}, [inner]);
    const head = el('button.nav-section-head', {
      onclick: () => section.classList.toggle('collapsed'),
      html: `<span class="label">${item.section}</span><span class="chev">${icon('chevronDown')}</span>`,
    });
    const section = el('div.nav-section', { dataset: { section: item.section } }, [head, body]);
    return section;
  }
  if (!item.children) {
    /* Nhãn nhỏ trên mục menu. Hai biến thể, chọn bằng `badgeKind`:
         - không ghi gì  -> badge "Quan trọng": viên pin NỀN gradient, chữ trắng, góc trên-phải.
         - badgeKind:'new' -> nhãn "NEW !": KHÔNG nền, chữ ĐỎ TƯƠI đặc, nằm ngay TRÊN ĐẦU nhãn mục.
       Lớp .has-badge chỉ bật `position: relative` cho mục, dùng chung cho cả hai biến thể. */
    const badgeHtml = item.badge
      ? `<span class="nav-badge${item.badgeKind ? ' nav-badge--' + item.badgeKind : ''}">${item.badge}</span>`
      : '';
    return el('button.nav-item' + (item.badge ? '.has-badge' : '') + (pinned ? '.is-pinned' : ''), {
      dataset: { route: item.route },
      onclick: () => navigate(item.route),
      onmouseenter: (e) => showTip(e.currentTarget, item.label),
      onmouseleave: hideTip,
      html: `<span class="ico">${icon(item.icon)}</span><span class="label">${item.label}</span>${badgeHtml}${navPinHtml(item, pinned)}`,
    });
  }
  // expandable group: header button + sub-items list, collapsed by default
  const subList = el('div.nav-sub', {}, item.children.map((c) =>
    el('button.nav-sub-item', {
      dataset: { route: c.route }, onclick: () => navigate(c.route),
      html: `<span class="ico">${icon(c.icon)}</span><span class="label">${c.label}</span>`,
    })
  ));
  const header = el('button.nav-item.nav-group-head' + (pinned ? '.is-pinned' : ''), {
    onclick: () => toggleGroup(group),
    // collapsed: pop children out to the right; expanded: plain tooltip (no-op when expanded).
    onmouseenter: (e) => { if (state.collapsed) showFlyout(e.currentTarget, item); else showTip(e.currentTarget, item.label); },
    onmouseleave: () => { hideTip(); hideFlyout(); },
    html: `<span class="ico">${icon(item.icon)}</span><span class="label">${item.label}</span>${navPinHtml(item, pinned)}<span class="chev">${icon('chevronDown')}</span>`,
  });
  const group = el('div.nav-group.collapsed', { dataset: { group: item.label } }, [header, subList]);
  return group;
}

function toggleGroup(group) {
  group.classList.toggle('collapsed');
}

function buildSidebar() {
  // "Hồ sơ mới" call-to-action - a brand-gradient split button. The wide left part
  // opens the single-profile creator; the boxed "+" on the right opens batch create.
  const newCta = el('div.np-cta', {}, [
    el('button.np-main', {
      onclick: () => navigate('profile_create'),
      onmouseenter: (e) => showTip(e.currentTarget, 'Tạo hồ sơ mới'),
      onmouseleave: hideTip,
      html: `<span class="np-ico">${icon('windowPlus')}</span><span class="np-label">Hồ sơ mới</span>`,
    }),
    el('button.np-add', {
      title: 'Tạo hàng loạt',
      onclick: () => navigate('profile_create_batch'),
      html: `<span class="np-add-ico">${icon('createProfile')}</span>`,
    }),
  ]);

  const nav = el('div.nav', {}, buildNavContent());
  // Bấm icon ghim: bắt ở pha CAPTURE rồi chặn lan truyền ⇒ không kích hoạt nút mục (không chuyển trang / không mở-đóng nhóm).
  nav.addEventListener('click', (e) => {
    const pin = e.target.closest && e.target.closest('.nav-pin');
    if (!pin) return;
    e.preventDefault(); e.stopPropagation();
    toggleNavPin(pin.dataset.pin);
  }, true);
  // Hiệu ứng bấm mục menu (user 2026-11-02): nền TOẢ từ GIỮA ra hai bên trái/phải. Chèn một span.nav-ripple vào mục rồi
  // tự gỡ khi chạy xong (CSS .nav-ripple). Bấm icon ghim không tới đây (bị chặn ở pha capture phía trên).
  nav.addEventListener('click', (e) => {
    const item = e.target.closest && e.target.closest('.nav-item, .nav-sub-item');
    if (!item || !nav.contains(item)) return;
    item.querySelectorAll(':scope > .nav-ripple').forEach((x) => x.remove());
    const fx = document.createElement('span');
    fx.className = 'nav-ripple';
    fx.addEventListener('animationend', () => fx.remove(), { once: true });
    item.appendChild(fx);
  });

  const plan = el('div.plan-card', {}, [
    // Dải mép trên thẻ gói: cụm trái (icon đồng tiền + "Nhận hoa hồng") + mũi tên "⇀" bên
    // phải; click cả dải -> trang "Hoa hồng". Style ở app.css `.plan-card > .plan-deco`.
    // Ba nơi render thẻ (sidebar / flyout / hết hạn) dùng chuỗi HTML y hệt để dải đồng nhất
    // ⇒ SỬA MỘT NƠI LÀ PHẢI SỬA CẢ BA, không thì ba thẻ dẫn đi hai trang khác nhau mà không
    // có lỗi nào báo (dùng replace_all / sửa xong grep lại 'plan-deco').
    el('div.plan-deco', { onclick: () => navigate('affiliate'), html: `<span class="plan-deco-left"><span class="plan-deco-ico">${icon('planCoin')}</span><span class="plan-deco-label">Nhận hoa hồng</span></span><span class="plan-deco-arrow">\u21C0</span>` }),
    el('div.plan-top', {}, [
      el('span.plan-badge', { html: icon('planHome') }),
      el('div.plan-title', { id: 'plan-name', text: 'Free' }),
    ]),
    buildPlanGrid(true),
    el('button.plan-upgrade', {
      id: 'plan-upgrade-btn',
      onclick: () => navigate('upgrade'),
      html: `<span class="plan-upgrade-ico">${icon('planUpgrade')}</span><span id="plan-upgrade-label">Nâng cấp ngay</span>`,
    }),
  ]);

  // collapsed-rail surrogate: when the sidebar is collapsed the gradient plan-card
  // is hidden and replaced by a single icon-only "Số dư" item; hovering it pops the
  // full balance box out to the right (see showPlanFlyout).
  const planRail = el('button.nav-item.plan-rail', {
    onmouseenter: (e) => showPlanFlyout(e.currentTarget),
    onmouseleave: hidePlanFlyout,
    html: `<span class="ico">${icon('walletCard')}</span><span class="label">Số dư</span>`,
  });

  return el('aside.sidebar#sidebar', {}, [
    el('div.brand', {}, [
      el('div.brand-mark', { html: '<img src="assets/cgt-logo.svg" alt="CGTBrowser">' }),
      el('div.brand-name', { text: 'CGTBrowser' }),
    ]),
    newCta,
    nav,
    plan,
    planRail,
  ]);
}

// Các dòng thông tin gói theo bố cục AdsPower (nhãn trái · giá trị phải):
//   • "Hết hạn lúc"  → #plan-expiry       (Vô hạn cho Free, hoặc ngày hết hạn gói trả phí)
//   • "Hồ Sơ"        → #plan-profiles     (số CHỖ đang chiếm / hạn mức, vd 2/5; ∞ = không giới hạn)
//   • "Thành viên"   → #plan-members      (ẩn ở gói Free)
// Tên gói (#plan-name) nằm ở header (.plan-top), KHÔNG trong lưới này nữa.
// The hover flyout builds an id-less copy (withIds=false) and mirrors the live text.
//
// KHÔNG thêm lại hai hàng "Tạo hôm nay"/"Mở hôm nay" (user bỏ 2026-09-27). Thẻ gói chỉ nói về
// HẠN MỨC GÓI - thứ nâng cấp gói giải quyết được. Limit theo ngày là phanh theo nhịp do quản
// trị viên đặt, gần như không khách nào bị đặt, để chung một khung chỉ làm thẻ rối. Chạm limit
// vẫn được báo bằng lỗi 403/CREATE_RATE_EXCEEDED, 409/OPEN_RATE_EXCEEDED kèm mốc reset 00:00.
const PLAN_ROW_IDS = ['plan-expiry', 'plan-profiles', 'plan-members'];
function buildPlanGrid(withIds) {
  const planRow = (label, value, valueId) => el('div.plan-row', {}, [
    el('span.plan-row-k', { text: label }),
    (withIds && valueId)
      ? el('span.plan-row-v', { id: valueId, text: value })
      : el('span.plan-row-v', { text: value }),
  ]);
  return el('div.plan-rows', {}, [
    planRow('Hết hạn lúc', 'Vô hạn', 'plan-expiry'),
    planRow('Hồ Sơ', '0/0', 'plan-profiles'),
    planRow('Thành viên', '0/0', 'plan-members'),
  ]);
}

// Collapsed-sidebar balance flyout: pops the full plan box out to the RIGHT of the
// "Số dư" rail item. Mirrors the nav-group flyout pattern (body-appended so the
// sidebar overflow can't clip it; short hide-delay lets the pointer cross the gap).
let planFly = null, planFlyTimer = null;
function showPlanFlyout(target) {
  if (!state.collapsed) return;
  if (!planFly) {
    planFly = el('div.plan-flyout');
    planFly.addEventListener('mouseenter', () => clearTimeout(planFlyTimer));
    planFly.addEventListener('mouseleave', hidePlanFlyout);
    document.body.appendChild(planFly);
  }
  clearTimeout(planFlyTimer);
  clear(planFly);
  const grid = buildPlanGrid(false);
  // Sao giá trị THẬT (do server đẩy vào) từ thẻ inline đang ẩn sang flyout. Chạy theo
  // PLAN_ROW_IDS chứ không đánh số tay vals[0]/vals[1]/... - thứ tự hàng trong
  // buildPlanGrid đúng bằng thứ tự PLAN_ROW_IDS, nên thêm/bớt hàng chỉ cần sửa 1 chỗ.
  // Sao cả TRẠNG THÁI ẨN của hàng: gói Free ẩn "Thành viên" - flyout phải giống thẻ inline
  // từng hàng, không chỉ giống phần chữ.
  const vals = grid.querySelectorAll('.plan-row-v');
  PLAN_ROW_IDS.forEach((rowId, i) => {
    const live = document.getElementById(rowId);
    const cell = vals[i];
    if (!live || !cell) return;
    cell.textContent = live.textContent;
    const liveRow = live.closest('.plan-row');
    const flyRow = cell.closest('.plan-row');
    if (liveRow && flyRow) flyRow.style.display = liveRow.style.display === 'none' ? 'none' : '';
  });
  const nm = document.getElementById('plan-name');
  // Build a REAL `.plan-card` - same structure as the inline expanded-sidebar card -
  // so the existing `.plan-card` CSS renders the flyout 100% identically. `.plan-flyout`
  // is just a positioning wrapper now.
  planFly.appendChild(el('div.plan-card', {}, [
    // Dải mép trên thẻ gói: cụm trái (icon đồng tiền + "Nhận hoa hồng") + mũi tên "⇀" bên
    // phải; click cả dải -> trang "Hoa hồng". Style ở app.css `.plan-card > .plan-deco`.
    // Ba nơi render thẻ (sidebar / flyout / hết hạn) dùng chuỗi HTML y hệt để dải đồng nhất
    // ⇒ SỬA MỘT NƠI LÀ PHẢI SỬA CẢ BA, không thì ba thẻ dẫn đi hai trang khác nhau mà không
    // có lỗi nào báo (dùng replace_all / sửa xong grep lại 'plan-deco').
    el('div.plan-deco', { onclick: () => navigate('affiliate'), html: `<span class="plan-deco-left"><span class="plan-deco-ico">${icon('planCoin')}</span><span class="plan-deco-label">Nhận hoa hồng</span></span><span class="plan-deco-arrow">\u21C0</span>` }),
    el('div.plan-top', {}, [
      el('span.plan-badge', { html: icon('planHome') }),
      el('div.plan-title', { text: nm ? nm.textContent : 'Free' }),
    ]),
    grid,
    el('button.plan-upgrade', {
      onclick: () => navigate('upgrade'),
      // Nhãn nút bám theo bản inline (đã "Gia hạn" khi workspace là Pro/hết hạn).
      html: `<span class="plan-upgrade-ico">${icon('planUpgrade')}</span><span>${(document.getElementById('plan-upgrade-label') || {}).textContent || 'Nâng cấp ngay'}</span>`,
    }),
  ]));
  const r = target.getBoundingClientRect();
  planFly.style.left = (r.right + 8) + 'px';
  planFly.style.top = 'auto';
  planFly.style.bottom = (window.innerHeight - r.bottom) + 'px';
  planFly.style.display = 'block';
}
function hidePlanFlyout() {
  planFlyTimer = setTimeout(() => { if (planFly) planFly.style.display = 'none'; }, 140);
}

// Header language selector: a bordered flag of the current language that opens a
// dropdown of the 4 supported languages (each with its flag). Re-renders itself
// on switch so the flag stays in sync.
const LANG_FLAG = { vi: 'flagVi', en: 'flagEn', ru: 'flagRu', zh: 'flagZh' };
function buildLangBtn() {
  // Ngôn ngữ ĐANG ÁP (có thể vừa đổi ở màn đăng nhập, hoặc tự đoán theo quốc gia lúc boot).
  const cur = getLang() || 'vi';
  const btn = el('button.icon-btn.lang-btn', {
    id: 'lang-btn', title: 'Ngôn ngữ',
    html: icon(LANG_FLAG[cur] || 'flagVi'),
    onclick: (e) => {
      const m = openMenu(e.currentTarget, [
        { label: 'Tiếng Việt', icon: 'flagVi', onClick: () => setLanguage('vi') },
        { label: 'English', icon: 'flagEn', onClick: () => setLanguage('en') },
        { label: 'Русский', icon: 'flagRu', onClick: () => setLanguage('ru') },
        { label: '中文', icon: 'flagZh', onClick: () => setLanguage('zh') },
      ]);
      applyI18n(m);
    },
  });
  return btn;
}

// Workspace switcher - bộ chọn workspace nay sống Ở HEADER chung (cạnh title),
// buildWorkspaceChip() bên dưới dựng chip. app.js giữ state + hàm chuyển; các nơi
// khác (nhận lời mời...) vẫn gọi window.__vtSwitchWorkspace.

// Nạp danh sách workspace + workspace đang hoạt động từ main vào state (để hàm
// chuyển biết tên hiển thị + fallback). Best-effort. Xong thì đồng bộ lại chip.
async function refreshWorkspaces() {
  try {
    const [list, active] = await Promise.all([
      remote.workspaces.list(),
      remote.workspaces.getActive(),
    ]);
    state.workspaces = Array.isArray(list) ? list : [];
    // getActive() có thể trả CHUỖI id hoặc object {id}. Nhận cả hai.
    const activeId = active == null ? '' : String(typeof active === 'object' ? (active.id || '') : active);
    const valid = activeId && state.workspaces.some((w) => String(w.id) === activeId);
    state.activeWorkspaceId = valid ? activeId : (state.workspaces[0] ? String(state.workspaces[0].id) : '');
    // TỰ CHỮA header lệch: đẩy workspace đã resolve XUỐNG main bất cứ khi nào nó khác với
    // giá trị main đang giữ (activeId). Bao gồm HAI trường hợp:
    //   • Vừa ĐĂNG NHẬP: main xóa activeWorkspaceId='' (remote.js:40/55/78/99) nên activeId=''.
    //     Renderer chọn workspaces[0] cho state nhưng NẾU không đẩy xuống main thì main vẫn giữ
    //     '' → header x-workspace-id KHÔNG được gửi (api-client.js chỉ gửi khi có giá trị) →
    //     server fallback workspace mặc định (W0) để KÝ giấy phép flow Chợ, còn main GIẢI MÃ lại
    //     so với '' → verifyLicense lệch → editor mở flow Chợ TRỐNG (0 node). Đẩy id xuống main
    //     là để header + khâu giải mã license luôn khớp workspace server dùng.
    //   • Đổi tài khoản: id cũ (theo máy) không thuộc account này (activeId có nhưng !valid) →
    //     tránh 403 NOT_WORKSPACE_MEMBER.
    if (state.activeWorkspaceId && String(state.activeWorkspaceId) !== activeId) {
      try { await remote.workspaces.setActive(state.activeWorkspaceId); } catch { /* ignore */ }
    }
  } catch {
    state.workspaces = [];
    state.activeWorkspaceId = '';
  }
  syncWorkspaceChip();
}

// Serialize hoá việc chuyển workspace: mỗi lúc CHỈ một lần chuyển chạy; bấm dồn
// dập nhiều lần → gộp lại thành "id mới nhất thắng" (xử lý sau khi lần đang chạy
// xong). Cùng với navigate() có sentinel thế hệ ở trên, việc chuyển qua lại liên
// tục không còn chồng chéo resetHosts()/navigate() → không bị kẹt, luôn load được.
let _wsSwitching = false;   // đang có 1 lần chuyển chạy dở?
let _wsPending = null;      // id được yêu cầu MỚI NHẤT trong lúc đang chạy

async function switchWorkspace(id) {
  if (!id) return;
  if (String(id) === String(state.activeWorkspaceId)) return;
  // Đang bận → chỉ ghi nhớ id mới nhất; lần đang chạy xong sẽ tự chuyển tiếp.
  if (_wsSwitching) { _wsPending = String(id); return; }
  _wsSwitching = true;
  try {
    await _doSwitchWorkspace(id);
  } finally {
    _wsSwitching = false;
    const next = _wsPending;
    _wsPending = null;
    // Còn yêu cầu dồn lại + khác workspace hiện tại → chuyển tiếp (đệ quy an toàn).
    if (next && String(next) !== String(state.activeWorkspaceId)) switchWorkspace(next);
  }
}

// Thân thật của việc chuyển: lưu ở main (đổi header x-workspace-id), dựng lại mọi
// view (huỷ host cache, điều hướng lại route hiện tại) + làm mới số hồ sơ + chip.
async function _doSwitchWorkspace(id) {
  try {
    const res = await remote.workspaces.setActive(id);
    state.activeWorkspaceId = (res && res.id) ? String(res.id) : String(id);
  } catch (e) {
    toast(e.message || 'Không thể chuyển workspace');
    return;
  }
  // Mọi dữ liệu (hồ sơ/nhóm/proxy/thành viên...) đều theo workspace → dựng lại sạch.
  // Nạp lại các store in-memory theo workspace mới (RPA tác vụ/lịch/nhật ký chạy +
  // nhật ký hoạt động) + quyền (khác nhau theo workspace) - nếu không, cache của
  // workspace cũ sẽ rò sang workspace mới. 3 việc này ĐỘC LẬP nhau → chạy SONG SONG
  // (allSettled: một cái lỗi/chậm không kéo theo cả chuỗi) thay vì tuần tự từng cái.
  // TRƯỚC ĐÂY await lần lượt 5 request (tasks→scheds→runlogs→activity→permissions)
  // rồi mới dựng lại view → chuyển workspace bị chậm & dễ "trống lưới phải reload".
  clearPlanFeatures();
  await Promise.allSettled([
    (typeof window.__rpaRefresh === 'function') ? window.__rpaRefresh() : Promise.resolve(),
    (typeof window.__activityRefresh === 'function') ? window.__activityRefresh() : Promise.resolve(),
    loadPermissions(true),
    loadPlanFeatures(true),
  ]);
  const cur = state.route;
  // GIỮ view "Chợ" (dữ liệu PUBLIC, không theo workspace) → đổi workspace không phải
  // nạp lại chợ. Các view còn lại (theo workspace) vẫn dựng lại sạch.
  resetHosts(['script_store']);
  state.route = null;
  // Dựng lại view (nạp hồ sơ/nhóm của workspace mới) + làm mới số dư ví SONG SONG -
  // hai việc độc lập, không cần chờ nhau.
  // navigate() tự chạy enforceExpiry() theo hạn thuê bao của workspace mới (đã nạp
  // lại ở allSettled trên) → khoá/mở UI + phủ/gỡ thẻ gói. Không cần gọi lại ở đây.
  await Promise.allSettled([navigate(cur || 'profiles'), refreshProfileCount(), refreshWalletBalance()]);
  syncWorkspaceChip();
  const active = (state.workspaces || []).find((w) => String(w.id) === String(state.activeWorkspaceId));
  toast(tf('Đã chuyển sang “{0}”', wsDisplayName(active)));
}
// Cho nơi khác (nhận lời mời, tạo workspace...) gọi để chuyển workspace.
window.__vtSwitchWorkspace = switchWorkspace;

// Sau khi CHẤP NHẬN lời chia sẻ hồ sơ: đưa người dùng về "Tất cả" của CHÍNH họ
// (workspace GỐC = thông tin chung, aggregate MỌI hồ sơ có quyền) rồi DỰNG LẠI lưới
// hồ sơ để hồ sơ vừa nhận xuất hiện NGAY cùng toàn bộ hồ sơ khác - không phải chỉ mỗi
// hồ sơ vừa nhận (bug cũ: chuyển sang ws của người mời → lưới chỉ có 1 hồ sơ, phải
// reload mới đủ). Đọc lại aggregate từ server nên gồm cả hồ sơ mới.
async function focusDefaultWorkspaceProfiles() {
  const def = (state.workspaces || []).find((w) => w.isDefault) || (state.workspaces || [])[0];
  const defId = def ? String(def.id) : '';
  // Khác workspace hiện tại → chuyển về "Tất cả" (switchWorkspace tự dựng lại view).
  if (defId && defId !== String(state.activeWorkspaceId)) {
    await switchWorkspace(defId);
  }
  // Dựng lại lưới hồ sơ (đọc lại aggregate gồm hồ sơ vừa nhận). destroyHost an toàn
  // kể cả khi host chưa tồn tại; navigate lại 'profiles' luôn render mới sau khi huỷ.
  destroyHost('profiles');
  navigate('profiles');
}

// Cập nhật lại tên + dấu tích trên chip workspace ở header (nếu chip đang tồn tại).
let _wsChipRefresh = null;
function syncWorkspaceChip() {
  try { if (_wsChipRefresh) _wsChipRefresh(); } catch { /* ignore */ }
  // Nếu đang mở màn "Thành viên nhóm", cập nhật lại trạng thái khoá/mở theo workspace.
  try { if (state.route === 'members') { const h = state.hosts.get('members'); if (h && h.api && h.api.onShow) h.api.onShow(); } } catch { /* ignore */ }
}

// Workspace đang hoạt động (object) - tra trong state theo activeWorkspaceId.
function activeWorkspace() {
  const list = state.workspaces || [];
  return list.find((w) => String(w.id) === String(state.activeWorkspaceId)) || null;
}

// Đang ở workspace GỐC cá nhân ("Tất cả") không? Server đánh dấu isDefault cho
// workspace tạo sớm nhất mình sở hữu. Chưa xác định được → coi như đang ở gốc (an
// toàn: ẩn "Thành viên nhóm" cho tới khi biết chắc đang ở team riêng).
function isDefaultWorkspaceActive() {
  const w = activeWorkspace();
  return w ? !!w.isDefault : true;
}

// Tên hiển thị của workspace: workspace gốc luôn hiện "Tất cả" (kể cả khi tên lưu
// khác), còn lại dùng tên thật.
function wsDisplayName(w) {
  if (!w) return 'Workspace';
  return w.isDefault ? 'Tất cả' : (w.name || 'Workspace');
}

// Cho view "Thành viên nhóm" biết đang ở workspace gốc "Tất cả" (thông tin chung,
// không phải team) → khoá tương tác (cursor cấm + tooltip). MỤC sidebar KHÔNG ẩn.
window.__vtIsDefaultWorkspace = isDefaultWorkspaceActive;

// Account đã tạo/tham gia workspace RIÊNG nào (khác "Tất cả") chưa? Dùng để đổi nội
// dung khoá màn "Thành viên nhóm": chưa có team → nhắc TẠO; đã có team mà đang ở
// "Tất cả" → nhắc CHỌN một workspace cụ thể.
function hasTeamWorkspace() {
  return (state.workspaces || []).some((w) => !w.isDefault);
}
window.__vtHasTeamWorkspace = hasTeamWorkspace;

// ---- Chip chọn workspace ở header -----------------------------------------
// Clone thiết kế MKTLogin: nhãn nhỏ "Không gian làm việc" + hộp viền (tên + caret);
// bấm mở panel có ô tìm kiếm + nút làm mới + "Tạo mới" + danh sách workspace (icon
// nhóm, chìa khoá nếu là workspace gốc, dấu tích cho cái đang hoạt động). Chọn 1
// cái → switchWorkspace (dựng lại toàn bộ view). LUÔN hiện, kể cả khi chỉ 1 workspace.
function buildWorkspaceChip() {
  const nameSpan = el('span.ws-pick-name', { text: 'Workspace' });
  const trigger = el('button.ws-pick-trigger', { title: 'Không gian làm việc' }, [
    nameSpan,
    el('span.ws-pick-caret', { html: icon('chevronDown') }),
  ]);
  const searchInput = el('input.ws-pick-search-input', { placeholder: 'Tìm workspace...', oninput: () => renderList() });
  const refreshWsBtn = el('button.ws-pick-refresh', { title: 'Làm mới', html: icon('sync'),
    onclick: async (e) => { e.stopPropagation(); await refreshWorkspaces(); renderList(); } });
  const createBtn = el('button.ws-pick-create', { html: '<span>Tạo mới</span>',
    onclick: (e) => { e.stopPropagation(); doClose(); createWorkspaceModal(); } });
  const listEl = el('div.ws-pick-list');
  const menu = el('div.ws-pick-menu', {}, [
    el('div.ws-pick-head', {}, [
      el('div.ws-pick-search', {}, [el('span.ico', { html: icon('search') }), searchInput]),
      refreshWsBtn,
      createBtn,
    ]),
    listEl,
  ]);
  let open = false;

  // Đồng bộ tên hiển thị trên trigger theo state (gọi khi đổi/nạp lại workspace).
  const syncName = () => {
    const list = state.workspaces || [];
    const active = list.find((w) => String(w.id) === String(state.activeWorkspaceId)) || list[0];
    nameSpan.textContent = wsDisplayName(active);
  };

  const renderList = () => {
    clear(listEl);
    const list = state.workspaces || [];
    const q = searchInput.value.trim().toLowerCase();
    // Chìa khoá CHỈ đánh dấu workspace GỐC (owner-first + created_at ASC → cái mình
    // sở hữu SỚM NHẤT là gốc). Không hiện với workspace tự tạo thêm.
    const rootId = (list.find((w) => w.isOwner) || {}).id;
    const shown = list.filter((w) => !q || wsDisplayName(w).toLowerCase().includes(q));
    if (!shown.length) { listEl.appendChild(el('div.ws-pick-none', { text: 'Không tìm thấy workspace' })); return; }
    shown.forEach((w) => {
      const on = String(w.id) === String(state.activeWorkspaceId);
      const isRoot = rootId != null && String(w.id) === String(rootId);
      const label = wsDisplayName(w);
      listEl.appendChild(el('div.ws-pick-opt' + (on ? '.selected' : ''), {
        onclick: () => {
          // Phản hồi tức thì: đổi tên + dấu tích trước, rồi mới chuyển (dựng lại view).
          nameSpan.textContent = label;
          doClose();
          if (!on) switchWorkspace(w.id);
        },
      }, [
        el('span.ws-pick-key' + (isRoot ? '' : '.is-blank'), { html: isRoot ? icon('key') : '' }),
        el('span.ws-pick-optico', { html: icon('workspaceGrid') }),
        el('span.ws-pick-label', { text: label }),
        el('span.ws-pick-check', { html: on ? icon('checkCircle') : '' }),
      ]));
    });
  };
  const place = () => {
    const r = trigger.getBoundingClientRect();
    menu.style.position = 'fixed';
    menu.style.left = r.left + 'px';
    menu.style.minWidth = Math.max(r.width, 240) + 'px';
    menu.style.top = (r.bottom + 6) + 'px';
  };
  const onDoc = (e) => { if (!wrap.contains(e.target) && !menu.contains(e.target)) doClose(); };
  const doOpen = () => {
    open = true; searchInput.value = ''; renderList();
    document.body.appendChild(menu); place();
    requestAnimationFrame(() => { if (open) menu.classList.add('is-open'); });
    wrap.classList.add('open');
    document.addEventListener('mousedown', onDoc);
    window.addEventListener('scroll', doClose, true);
    setTimeout(() => searchInput.focus(), 20);
  };
  const doClose = () => {
    open = false;
    menu.classList.remove('is-open');
    wrap.classList.remove('open');
    setTimeout(() => { if (!open && menu.parentNode) menu.parentNode.removeChild(menu); }, 170);
    document.removeEventListener('mousedown', onDoc);
    window.removeEventListener('scroll', doClose, true);
  };
  trigger.addEventListener('click', () => { open ? doClose() : doOpen(); });

  const wrap = el('div.ws-pick.ws-pick-header', {}, [
    el('span.ws-pick-caption', { text: 'Không gian làm việc' }),
    trigger,
  ]);
  // Cho refreshWorkspaces()/switchWorkspace() cập nhật lại chip khi state đổi.
  _wsChipRefresh = () => { syncName(); if (open) renderList(); };
  syncName();
  return wrap;
}

// Modal "Tạo không gian làm việc" - clone MKTLogin: Tên + Mô tả + Phương pháp phân
// quyền (Chia theo nhóm | Chia theo hồ sơ). Người tạo tự thành owner; tạo xong nạp
// lại danh sách rồi tự chuyển sang workspace mới (dựng lại view).
function createWorkspaceModal() {
  // Cổng gói: "Tạo không gian làm việc" là tính năng trả phí → gói Free hiện modal
  // nâng cấp thay vì mở form. hasFeature() đồng bộ (đã nạp ở mountShell).
  if (!hasFeature('workspace')) { gateFeature('workspace', { navigate }); return; }
  let nameInput, descInput;
  let permMode = 'group';
  const permSel = customSelect(
    [{ value: 'group', label: 'Chia theo nhóm' }, { value: 'profile', label: 'Chia theo hồ sơ' }],
    { value: permMode, width: '100%', height: 40, onChange: (v) => { permMode = v; } },
  );

  const save = async () => {
    const name = nameInput.value.trim();
    if (!name) { nameInput.focus(); toast('Vui lòng nhập tên không gian làm việc', 'error'); return; }
    try {
      const ws = await remote.workspaces.create({
        name, description: descInput.value.trim(), permissionMode: permMode,
      });
      closeModal();
      toast('Đã tạo không gian làm việc', 'ok');
      await refreshWorkspaces();        // đưa workspace mới vào state + chip
      if (ws && ws.id) await switchWorkspace(ws.id);
    } catch (e) { toast(e.message || 'Tạo thất bại', 'error'); }
  };

  openModal({
    title: 'Tạo không gian làm việc',
    width: 560,
    body: [el('div.mem-form', {}, [
      el('div.mem-form-row', {}, [
        (nameInput = el('input.input', { placeholder: 'Nhập tên không gian làm việc' })),
      ]),
      el('div.mem-form-row', {}, [
        (descInput = el('textarea.input.mem-textarea', { rows: 4, placeholder: 'Nhập mô tả' }, '')),
      ]),
      el('div.mem-form-row', {}, [
        permSel,
      ]),
    ])],
    footer: [
      el('button.grp-cancel', { text: 'Hủy', onclick: closeModal }),
      el('button.btn.primary', { text: 'Tạo', onclick: save }),
    ],
  });
  setTimeout(() => nameInput && nameInput.focus(), 30);
}

function buildKernelBtn() {
  const btn = el('button.header-kernel-btn#header-kernel-btn', {
    type: 'button',
    title: 'Trạng thái nhân Chromium',
    onclick: () => {
      vt.kernel.isCustomInstalled().then((installed) => {
        if (!installed) {
          import('./views/kernels.js').then((m) => {
            m.openKernelDownloadModal({
              engine: 'chromium',
              major: 153,
              version: '153.0.7993.0',
              name: 'CGT Chromium 153 Core',
              sizeMb: 215,
              url: 'https://github.com/parkseoduc/CGT-Login-Browser/releases/download/v2.0-kernel/MyBrowser-153-win64.zip',
            }, {
              onDone: () => {
                refreshHeaderKernelBtn();
                m.syncActiveKernelToFingerprint();
              },
            });
          });
        } else {
          navigate('settings');
          setTimeout(() => {
            const b = document.querySelector('[data-val="kernels"]') || Array.from(document.querySelectorAll('button')).find((x) => x.innerText && x.innerText.includes('Nhân trình duyệt'));
            if (b) b.click();
          }, 150);
        }
      });
    },
  });

  async function refreshHeaderKernelBtn() {
    const elBtn = document.getElementById('header-kernel-btn');
    if (!elBtn) return;
    try {
      const isInstalled = await vt.kernel.isCustomInstalled();
      if (isInstalled) {
        elBtn.className = 'header-kernel-btn installed';
        elBtn.innerHTML = `
          <span class="hkb-dot green"></span>
          <span class="hkb-label">Kernel 153: Sẵn sàng</span>
        `;
        elBtn.title = 'Nhân Chromium 153 Core đã sẵn sàng (Pass 100% Bot Detection)';
      } else {
        elBtn.className = 'header-kernel-btn uninstalled';
        elBtn.innerHTML = `
          <span class="hkb-dot orange pulse"></span>
          <span class="hkb-label">⚡ Cài Kernel 153</span>
        `;
        elBtn.title = 'Bấm để 1-Click Tải & Cài Đặt nhân Chromium 153 (Khuyên dùng)';
      }
    } catch {
      elBtn.style.display = 'none';
    }
  }

  window.__refreshHeaderKernelBtn = refreshHeaderKernelBtn;
  window.addEventListener('cgt:kernel-installed', () => {
    refreshHeaderKernelBtn();
    syncActiveKernelToFingerprint().catch(() => {});
  });
  setTimeout(refreshHeaderKernelBtn, 200);

  return btn;
}

function buildHeader() {
  const themeBtn = iconBtn(state.settings.theme === 'dark' ? 'themeSun' : 'themeMoon', {
    title: 'Đổi giao diện',
    onclick: () => setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'),
  });
  themeBtn.id = 'theme-btn';

  return el('header.header', {}, [
    el('div.header-left', {}, [
      buildWorkspaceChip(),
      el('div.header-title#header-title', { text: routeTitle(state.route) }),
    ]),
    // Ô giữa: banner quảng cáo (type='banner' từ web admin). Rỗng nếu không có banner.
    el('div.header-promo#header-promo'),
    el('div.header-right', {}, [
      buildKernelBtn(),
      buildNotifBtn(),
      iconBtn('wallet', { title: 'Nạp tiền', onclick: () => navigate('topup') }),
      buildUpdateBtn(),
      themeBtn,
      buildLangBtn(),
      buildAvatar(),
    ]),
  ]);
}

// Nút "Cập nhật": mở dropdown trạng thái cập nhật. Badge đỏ khi có bản mới đang chờ.
// Đăng ký lắng nghe trạng thái cập nhật để bật/tắt badge + vẽ lại dropdown đang mở.
function buildUpdateBtn() {
  const btn = iconBtn('appUpdate', { title: 'Cập nhật', onclick: toggleUpdatePop });
  btn.id = 'update-btn';
  const badge = el('span.notif-badge#update-badge', { style: { display: 'none' } });
  const wrap = el('div.upd-wrap', {}, [btn, badge]);
  // Đăng ký MỘT LẦN cho cả vòng đời tiến trình (ID badge/pop ổn định nên callback luôn
  // trỏ đúng phần tử hiện tại kể cả khi header dựng lại lúc đăng nhập lại).
  if (!_updSubscribed) {
    _updSubscribed = true;
    subscribeUpdates(() => {
      const b = document.getElementById('update-badge');
      if (b) b.style.display = hasPendingUpdate() ? 'block' : 'none';
      const pop = document.getElementById('update-pop');
      if (pop) renderUpdatePop();
    });
  }
  // Đồng bộ badge ngay khi dựng (đã có trạng thái từ lần kiểm tra trước).
  badge.style.display = hasPendingUpdate() ? 'block' : 'none';
  return wrap;
}
let _updSubscribed = false;

let _updOff = null;
function closeUpdatePop() {
  const p = document.getElementById('update-pop');
  if (p) p.remove();
  if (_updOff) { document.removeEventListener('mousedown', _updOff); _updOff = null; }
}

// Toggle dropdown cập nhật: đang mở thì đóng, chưa mở thì mở.
function toggleUpdatePop() {
  if (document.getElementById('update-pop')) { closeUpdatePop(); return; }
  const btn = document.getElementById('update-btn');
  if (!btn) return;
  const pop = el('div.notif-pop.upd-pop#update-pop');
  document.body.appendChild(pop);
  renderUpdatePop();
  // Mở dropdown = cơ hội làm mới (im lặng), KHÔNG bật modal - modal chỉ hiện lúc mở app.
  checkForUpdates({ silent: true, noModal: true });
  const r = btn.getBoundingClientRect();
  pop.style.top = (r.bottom + 8) + 'px';
  pop.style.right = Math.max(8, window.innerWidth - r.right) + 'px';
  const off = (e) => { if (!pop.contains(e.target) && !btn.contains(e.target)) closeUpdatePop(); };
  _updOff = off;
  setTimeout(() => document.addEventListener('mousedown', off), 0);
}

// Vẽ nội dung dropdown cập nhật (khung tĩnh - sẽ nối trạng thái thật sau).
function renderUpdatePop() {
  const pop = document.getElementById('update-pop');
  if (!pop) return;
  clear(pop);

  pop.appendChild(el('div.notif-pop-head', {}, [
    el('span.notif-pop-title', { text: 'Cập nhật phiên bản' }),
  ]));

  // Nội dung phụ thuộc trạng thái thật (module update-modal quản lý): có bản mới →
  // thẻ phiên bản + nút "Cập nhật ngay"; không có → trạng thái rỗng kèm vector.
  const body = el('div.upd-body');
  renderDropdownBody(body);
  pop.appendChild(body);
}

// Chuông "Thông báo": nút chuông + badge đỏ đếm. Bấm mở DROPDOWN trung tâm thông
// báo (thiết kế chung, sau này thêm nhiều loại thông báo). Riêng thông báo "lời
// mời tham gia nhóm" khi bấm mới mở modal Chấp nhận / Từ chối. Badge cập nhật riêng
// bởi refreshInvites() (không rebuild header).
function buildNotifBtn() {
  const btn = iconBtn('bell', { title: 'Thông báo', onclick: toggleNotifPop });
  btn.id = 'notif-btn';
  const badge = el('span.notif-badge#notif-badge', { style: { display: 'none' } });
  return el('div.notif-wrap', {}, [btn, badge]);
}

// Cập nhật con số trên badge chuông theo state.invites (ẩn khi = 0).
function renderNotifBadge() {
  const badge = document.getElementById('notif-badge');
  if (!badge) return;
  const n = (state.invites || []).length + (state.shares || []).length;
  badge.textContent = n > 99 ? '99+' : String(n);
  badge.style.display = n > 0 ? '' : 'none';
}

// Nạp hộp thư lời mời + lời chia sẻ hồ sơ của tôi từ server rồi cập nhật badge.
// Best-effort (nuốt lỗi - ví dụ chưa đăng nhập / mạng lỗi thì coi như rỗng). Hai
// nguồn độc lập: một cái lỗi không được xoá cái kia.
async function refreshInvites() {
  try { state.invites = await remote.team.invites.mine(); }
  catch { state.invites = []; }
  try { state.shares = await remote.profileShares.mine(); }
  catch { state.shares = []; }
  renderNotifBadge();
  if (document.getElementById('notif-pop')) renderNotifPop(); // đang mở → cập nhật ngay
}

// Gom mọi nguồn thông báo thành 1 danh sách chung. Hiện chỉ có "lời mời tham gia
// nhóm"; sau này push thêm loại khác vào đây (type + onOpen riêng).
function collectNotifications() {
  const items = [];
  for (const inv of state.invites || []) {
    const who = inv.inviterName || inv.inviterEmail || 'Ai đó';
    items.push({
      type: 'invite',
      icon: 'usersGroup',
      title: 'Lời mời tham gia nhóm',
      desc: tf('{0} mời bạn vào “{1}”', who, inv.workspaceName || 'workspace'),
      onOpen: () => { closeNotifPop(); openInviteModal(inv); },
    });
  }
  // Gom lời chia sẻ hồ sơ theo NGƯỜI CHIA SẺ (+ workspace): nếu 1 người chia sẻ ≥2
  // hồ sơ → gộp thành 1 thông báo, bấm mở modal xử lý hàng loạt (đồng ý/từ chối tất
  // cả) thay vì bắt người nhận click từng hồ sơ.
  const shareGroups = new Map();
  for (const sh of state.shares || []) {
    const key = `${(sh.inviterEmail || sh.inviterName || '?').toLowerCase()}|${sh.workspaceId || ''}`;
    if (!shareGroups.has(key)) shareGroups.set(key, []);
    shareGroups.get(key).push(sh);
  }
  for (const group of shareGroups.values()) {
    const who = group[0].inviterEmail || 'Ai đó';
    if (group.length === 1) {
      const sh = group[0];
      items.push({
        type: 'share',
        icon: 'share',
        title: 'Lời mời truy cập hồ sơ',
        desc: tf('{0} chia sẻ hồ sơ “{1}” với bạn', who, sh.profileName || 'hồ sơ'),
        onOpen: () => { closeNotifPop(); openShareInviteModal(sh); },
      });
    } else {
      items.push({
        type: 'share',
        icon: 'share',
        title: 'Lời mời truy cập hồ sơ',
        desc: tf('{0} chia sẻ {1} hồ sơ với bạn', who, group.length),
        onOpen: () => { closeNotifPop(); openShareBatchModal(group); },
      });
    }
  }
  return items;
}

// Modal 1 lời chia sẻ hồ sơ: tên hồ sơ + người chia sẻ + mức quyền, kèm Chấp nhận /
// Từ chối. Chấp nhận → server kết nạp vào workspace của hồ sơ + cấp quyền đúng hồ sơ
// đó, rồi chuyển sang workspace ấy để thấy hồ sơ ngay.
// Nhãn hiển thị cho từng key quyền hồ sơ được chia sẻ (khớp checkbox ở modal chia sẻ).
const SHARE_PERM_LABELS = {
  'profile:open': 'Mở',
  'profile:show_note': 'Hiển thị ghi chú',
  'profile:edit_note': 'Chỉnh sửa ghi chú',
  'profile:edit_proxy': 'Chỉnh sửa proxy',
  'profile:edit_fingerprint': 'Chỉnh sửa dấu vân tay',
  'profile:move_group': 'Chuyển nhóm hồ sơ',
  'profile:duplicate': 'Nhân bản',
  'profile:transfer': 'Chuyển đi',
};

function openShareInviteModal(sh) {
  const who = sh.inviterEmail || 'Ai đó';
  // Ưu tiên bộ quyền tùy chỉnh (permKeys); rỗng (lời chia sẻ cũ) → nhãn mức view/edit/full.
  const keys = Array.isArray(sh.permKeys) ? sh.permKeys : [];
  const permChips = keys.length
    ? keys.map((k) => SHARE_PERM_LABELS[k] || k)
    : [sh.permission === 'full' ? 'Toàn quyền' : sh.permission === 'edit' ? 'Chỉnh sửa' : 'Xem'];
  const pName = sh.profileName || 'Hồ sơ';
  const initial = (pName.trim().charAt(0) || 'H').toUpperCase();

  const acceptBtn = el('button.btn.primary.invite-accept', { text: 'Chấp nhận' });
  const declineBtn = el('button.btn.invite-decline', { text: 'Từ chối' });

  const card = el('div.invite-card.invite-card-solo', {}, [
    el('div.invite-avatar', { text: initial }),
    el('div.invite-card-main', {}, [
      el('div.invite-ws', { text: pName }),
      el('div.invite-by', { text: tf('{0} đã chia sẻ hồ sơ này với bạn', who) }),
      el('div.invite-meta', {}, [
        ...permChips.map((label) => el('span.invite-chip', { text: label })),
        sh.workspaceName ? el('span.invite-chip', { text: sh.workspaceName }) : null,
      ]),
    ]),
  ]);

  acceptBtn.onclick = async () => {
    acceptBtn.disabled = declineBtn.disabled = true;
    try {
      await remote.profileShares.acceptById(sh.id);
      toast(tf('Đã nhận quyền truy cập hồ sơ “{0}”', pName));
      await refreshInvites();
      closeModal();
      await refreshWorkspaces();
      // Hồ sơ vừa nhận nằm ở workspace của NGƯỜI MỜI (thường là ws gốc "Tất cả" của
      // họ - đã ẩn khỏi bộ chọn của mình). KHÔNG chuyển sang đó (sẽ chỉ thấy đúng 1 hồ
      // sơ vừa nhận). Về "Tất cả" của MÌNH - thông tin chung gộp MỌI hồ sơ có quyền -
      // để hồ sơ mới hiện NGAY cùng toàn bộ hồ sơ khác (không cần reload).
      focusDefaultWorkspaceProfiles();
    } catch (e) {
      acceptBtn.disabled = declineBtn.disabled = false;
      toast(e.message || 'Không thể chấp nhận lời chia sẻ');
    }
  };
  declineBtn.onclick = async () => {
    acceptBtn.disabled = declineBtn.disabled = true;
    try {
      await remote.profileShares.decline(sh.id);
      toast('Đã từ chối lời chia sẻ');
      await refreshInvites();
      closeModal();
    } catch (e) {
      acceptBtn.disabled = declineBtn.disabled = false;
      toast(e.message || 'Không thể từ chối lời chia sẻ');
    }
  };

  openModal({
    title: 'Lời mời truy cập hồ sơ',
    body: [card],
    footer: [declineBtn, acceptBtn],
    width: 440,
  });
}

// Modal xử lý HÀNG LOẠT khi 1 người chia sẻ nhiều hồ sơ: danh sách hồ sơ + checkbox
// tùy chọn (mặc định chọn tất cả) + "Chọn tất cả", kèm nút Đồng ý tất cả / Từ chối
// tất cả - thao tác trên các hồ sơ ĐANG CHỌN (endpoint batch, tha thứ lỗi từng cái).
function openShareBatchModal(shares) {
  const who = shares[0].inviterEmail || 'Ai đó';
  const selected = new Set(shares.map((s) => s.id)); // mặc định chọn tất cả

  const rowCbs = [];
  const masterCb = el('input', { type: 'checkbox', checked: true });
  const syncMaster = () => {
    const on = shares.filter((s) => selected.has(s.id)).length;
    masterCb.checked = on === shares.length && on > 0;
    masterCb.indeterminate = on > 0 && on < shares.length;
  };
  masterCb.onchange = () => {
    shares.forEach((s) => { masterCb.checked ? selected.add(s.id) : selected.delete(s.id); });
    rowCbs.forEach((cb) => { cb.checked = masterCb.checked; });
    syncMaster();
  };

  const list = el('div.share-batch-list');
  shares.forEach((sh) => {
    const keys = Array.isArray(sh.permKeys) ? sh.permKeys : [];
    const permChips = keys.length
      ? keys.map((k) => SHARE_PERM_LABELS[k] || k)
      : [sh.permission === 'full' ? 'Toàn quyền' : sh.permission === 'edit' ? 'Chỉnh sửa' : 'Xem'];
    const cb = el('input', { type: 'checkbox', checked: true,
      onchange: (e) => { e.target.checked ? selected.add(sh.id) : selected.delete(sh.id); syncMaster(); } });
    rowCbs.push(cb);
    list.appendChild(el('label.share-batch-row', {}, [
      cb,
      el('div.share-batch-main', {}, [
        el('div.share-batch-name', { text: sh.profileName || 'Hồ sơ' }),
        el('div.share-batch-perms', {}, permChips.map((l) => el('span.invite-chip', { text: l }))),
      ]),
    ]));
  });

  const head = el('label.share-batch-head', {}, [masterCb, el('span', { text: 'Chọn tất cả' })]);

  const acceptBtn = el('button.btn.primary', { text: 'Đồng ý tất cả' });
  const declineBtn = el('button.btn', { text: 'Từ chối tất cả' });
  const setBusy = (b) => { acceptBtn.disabled = declineBtn.disabled = b; };

  acceptBtn.onclick = async () => {
    const ids = [...selected];
    if (!ids.length) return toast('Chưa chọn hồ sơ nào');
    setBusy(true);
    try {
      const res = await remote.profileShares.acceptBatch(ids);
      toast(tf('Đã nhận quyền {0} hồ sơ', (res && res.accepted) || ids.length));
      await refreshInvites();
      closeModal();
      await refreshWorkspaces();
      // Về "Tất cả" của MÌNH (aggregate) để các hồ sơ vừa nhận hiện NGAY cùng toàn bộ
      // hồ sơ khác - không chuyển sang ws của người mời (đã ẩn, chỉ thấy hồ sơ vừa nhận).
      focusDefaultWorkspaceProfiles();
    } catch (e) { setBusy(false); toast(e.message || 'Không thể chấp nhận lời chia sẻ'); }
  };
  declineBtn.onclick = async () => {
    const ids = [...selected];
    if (!ids.length) return toast('Chưa chọn hồ sơ nào');
    setBusy(true);
    try {
      await remote.profileShares.declineBatch(ids);
      toast('Đã từ chối lời chia sẻ');
      await refreshInvites();
      closeModal();
    } catch (e) { setBusy(false); toast(e.message || 'Không thể từ chối lời chia sẻ'); }
  };

  openModal({
    title: 'Lời mời truy cập hồ sơ',
    sub: tf('{0} chia sẻ {1} hồ sơ với bạn', who, shares.length),
    width: 520,
    body: [head, list],
    footer: [declineBtn, acceptBtn],
  });
}

// ----- Trung tâm thông báo (dropdown dưới chuông) --------------------------
let _notifOff = null;
function closeNotifPop() {
  const p = document.getElementById('notif-pop');
  if (p) p.remove();
  if (_notifOff) { document.removeEventListener('mousedown', _notifOff); _notifOff = null; }
}

// Toggle: đang mở thì đóng, chưa mở thì mở (bấm lại vào chuông để đóng).
function toggleNotifPop() {
  if (document.getElementById('notif-pop')) { closeNotifPop(); return; }
  const btn = document.getElementById('notif-btn');
  if (!btn) return;
  const pop = el('div.notif-pop#notif-pop');
  document.body.appendChild(pop);
  renderNotifPop();
  const r = btn.getBoundingClientRect();
  pop.style.top = (r.bottom + 8) + 'px';
  pop.style.right = Math.max(8, window.innerWidth - r.right) + 'px';
  // Đóng khi bấm ra ngoài (bỏ qua chính nút chuông để click đó tự toggle).
  const off = (e) => { if (!pop.contains(e.target) && !btn.contains(e.target)) closeNotifPop(); };
  _notifOff = off;
  setTimeout(() => document.addEventListener('mousedown', off), 0);
}

// Vẽ (hoặc vẽ lại) nội dung dropdown từ collectNotifications().
function renderNotifPop() {
  const pop = document.getElementById('notif-pop');
  if (!pop) return;
  clear(pop);
  const items = collectNotifications();

  pop.appendChild(el('div.notif-pop-head', {}, [
    el('span.notif-pop-title', { text: 'Thông báo' }),
    items.length ? el('span.notif-pop-count', { text: String(items.length) }) : null,
  ]));

  const listEl = el('div.notif-pop-list');
  if (!items.length) {
    listEl.appendChild(el('div.notif-pop-empty', {}, [
      el('div.notif-pop-empty-ic', { html: icon('bell') }),
      el('div', { text: 'Chưa có thông báo nào.' }),
    ]));
  } else {
    for (const it of items) {
      const row = el('div.notif-item', {}, [
        el('div.notif-item-ic', { html: icon(it.icon) }),
        el('div.notif-item-main', {}, [
          el('div.notif-item-title', { text: it.title }),
          el('div.notif-item-desc', { text: it.desc }),
        ]),
        el('span.notif-item-arrow', { html: icon('chevron') }),
      ]);
      row.onclick = it.onOpen;
      listEl.appendChild(row);
    }
  }
  pop.appendChild(listEl);
}

// Modal 1 lời mời: workspace + người mời + vai trò/nhóm, kèm Chấp nhận / Từ chối.
function openInviteModal(inv) {
  const who = inv.inviterName || inv.inviterEmail || 'Ai đó';
  const roleTxt = inv.teamRole === 'admin' ? 'Quản trị viên'
    : inv.teamRole === 'manager' ? 'Quản lý' : 'Thành viên';
  const wsName = inv.workspaceName || 'Workspace';
  const initial = (wsName.trim().charAt(0) || 'W').toUpperCase();

  const acceptBtn = el('button.btn.primary.invite-accept', { text: 'Chấp nhận' });
  const declineBtn = el('button.btn.invite-decline', { text: 'Từ chối' });

  const card = el('div.invite-card.invite-card-solo', {}, [
    el('div.invite-avatar', { text: initial }),
    el('div.invite-card-main', {}, [
      el('div.invite-ws', { text: wsName }),
      el('div.invite-by', { text: tf('{0} đã mời bạn tham gia nhóm', who) }),
      el('div.invite-meta', {}, [
        el('span.invite-chip', { text: roleTxt }),
        inv.groupName ? el('span.invite-chip', { text: inv.groupName }) : null,
      ]),
    ]),
  ]);

  acceptBtn.onclick = async () => {
    acceptBtn.disabled = declineBtn.disabled = true;
    try {
      await remote.team.invites.acceptById(inv.id);
      toast(tf('Đã tham gia “{0}”', wsName));
      await refreshInvites();
      closeModal();
      // Nạp lại bộ chọn workspace (workspace vừa vào giờ đã xuất hiện) rồi CHUYỂN
      // hẳn sang nó - người nhận thấy đúng dữ liệu/nhóm được chia sẻ ngay lập tức.
      await refreshWorkspaces();
      if (inv.workspaceId) { await switchWorkspace(inv.workspaceId); return; }
      // Không rõ workspaceId → ít nhất dựng lại trang Thành viên nhóm nếu đang mở.
      if (state.route === 'members') { destroyHost('members'); navigate('members'); }
    } catch (e) {
      acceptBtn.disabled = declineBtn.disabled = false;
      toast(e.message || 'Không thể chấp nhận lời mời');
    }
  };
  declineBtn.onclick = async () => {
    acceptBtn.disabled = declineBtn.disabled = true;
    try {
      await remote.team.invites.decline(inv.id);
      toast('Đã từ chối lời mời');
      await refreshInvites();
      closeModal();
    } catch (e) {
      acceptBtn.disabled = declineBtn.disabled = false;
      toast(e.message || 'Không thể từ chối lời mời');
    }
  };

  openModal({
    title: 'Lời mời tham gia nhóm',
    body: [card],
    footer: [declineBtn, acceptBtn],
    width: 440,
  });
}

// Bảng màu gradient cho avatar - mỗi chữ cái/số một màu riêng, tươi & dễ phân biệt.
// Không dùng cứng 1 màu brand; màu được ánh xạ theo ký tự đầu (ổn định theo email).
const AVATAR_GRADIENTS = [
  'linear-gradient(135deg,#FF6B6B 0%,#D8365D 100%)', // A
  'linear-gradient(135deg,#FF8E53 0%,#FE6B8B 100%)', // B
  'linear-gradient(135deg,#FFB13C 0%,#FF7A18 100%)', // C
  'linear-gradient(135deg,#F9D423 0%,#F76B1C 100%)', // D
  'linear-gradient(135deg,#C2E059 0%,#5FA803 100%)', // E
  'linear-gradient(135deg,#43E97B 0%,#159957 100%)', // F
  'linear-gradient(135deg,#2AF598 0%,#009EFD 100%)', // G
  'linear-gradient(135deg,#43CEA2 0%,#187FA0 100%)', // H
  'linear-gradient(135deg,#4FACFE 0%,#00C6FB 100%)', // I
  'linear-gradient(135deg,#5B9BFF 0%,#1D7BD8 100%)', // J
  'linear-gradient(135deg,#667EEA 0%,#3A47C6 100%)', // K
  'linear-gradient(135deg,#7367F0 0%,#4634C9 100%)', // L
  'linear-gradient(135deg,#9D50BB 0%,#6E48AA 100%)', // M
  'linear-gradient(135deg,#B24592 0%,#8E2DE2 100%)', // N
  'linear-gradient(135deg,#DA22FF 0%,#9733EE 100%)', // O
  'linear-gradient(135deg,#F857A6 0%,#B5179E 100%)', // P
  'linear-gradient(135deg,#FF5FA2 0%,#E1306C 100%)', // Q
  'linear-gradient(135deg,#F5515F 0%,#A1051D 100%)', // R
  'linear-gradient(135deg,#E65C00 0%,#C0392B 100%)', // S
  'linear-gradient(135deg,#F2994A 0%,#C97B1C 100%)', // T
  'linear-gradient(135deg,#B8C400 0%,#6A8500 100%)', // U
  'linear-gradient(135deg,#11998E 0%,#065C55 100%)', // V
  'linear-gradient(135deg,#00B4DB 0%,#0083B0 100%)', // W
  'linear-gradient(135deg,#396AFC 0%,#2948FF 100%)', // X
  'linear-gradient(135deg,#8E54E9 0%,#4776E6 100%)', // Y
  'linear-gradient(135deg,#c04848 0%,#480048 100%)', // Z
];

// Chọn gradient ổn định theo ký tự: A→0 … Z→25; chữ số/ký tự khác băm theo mã ký tự.
function avatarGradient(ch) {
  const c = (ch || 'V').toUpperCase();
  const code = c.charCodeAt(0);
  let idx;
  if (code >= 65 && code <= 90) idx = code - 65;        // A–Z
  else idx = code % AVATAR_GRADIENTS.length;            // số/ký tự khác
  return AVATAR_GRADIENTS[idx % AVATAR_GRADIENTS.length];
}

// Modal "Đổi mật khẩu" - đổi mật khẩu ngay tại chỗ, KHÔNG cần xác thực email.
// Server vẫn bắt nhập ĐÚNG mật khẩu hiện tại. Mở từ menu tài khoản trên header.
function openChangePasswordModal() {
  // Định dạng mật khẩu mới: tối thiểu 6 ký tự, phải gồm CẢ chữ và số.
  const PW_RE = /^(?=.*[A-Za-z])(?=.*\d).{6,}$/;

  // Một ô mật khẩu kiểu "nhãn nổi": nhãn nằm giữa ô như placeholder, khi focus/đã
  // nhập thì trượt lên CẮT vào viền trên ô. Kèm nút con mắt hiện/ẩn mật khẩu và một
  // dòng báo lỗi NGAY DƯỚI CHÂN ô (không dùng toast). setError(msg) bật/tắt lỗi.
  // placeholder=' ' (1 khoảng trắng) là bắt buộc để :placeholder-shown hoạt động.
  function pwField(labelText, autocomplete) {
    const input = el('input.input.pw-input', { type: 'password', placeholder: ' ', autocomplete });
    const label = el('label.pw-float', { text: labelText });
    let shown = false;
    const eyeBtn = el('button.pw-eye', {
      type: 'button', html: icon('eye'), title: 'Hiện/ẩn mật khẩu',
      onclick: () => {
        if (input.disabled) return;
        shown = !shown;
        input.type = shown ? 'text' : 'password';
        eyeBtn.innerHTML = icon(shown ? 'eyeOff' : 'eye');
        input.focus();
      },
    });
    const field = el('div.pw-field', {}, [input, label, eyeBtn]);
    const errText = el('span');
    const err = el('div.pw-error', {}, [el('span.pw-error-ico', { html: icon('infoCircle') }), errText]);
    err.style.display = 'none';
    const wrap = el('div.pw-field-wrap', {}, [field, err]);
    function setError(msg) {
      if (msg) { errText.textContent = msg; err.style.display = ''; field.classList.add('is-error'); }
      else { err.style.display = 'none'; field.classList.remove('is-error'); }
    }
    return { input, field, wrap, setError };
  }

  const cur = pwField('Mật khẩu cũ', 'current-password');
  const nw = pwField('Mật khẩu mới', 'new-password');
  const cf = pwField('Xác nhận mật khẩu mới', 'new-password');
  const curInput = cur.input, newInput = nw.input, confirmInput = cf.input;

  // Kiểm tra + mở khóa DẦN, chạy MỖI KHI GÕ (không đợi bấm nút). Trả về trạng thái
  // để nút Lưu tận dụng. Quy tắc:
  //  · Chưa nhập "mật khẩu cũ" → khóa ô "mật khẩu mới".
  //  · "Mật khẩu mới": trùng cũ → lỗi "không được trùng"; sai định dạng → lỗi định dạng.
  //  · Ô "xác nhận" CHỈ khóa khi chưa nhập mật khẩu mới HOẶC mật khẩu mới trùng cũ;
  //    đủ điều kiện thì MỞ. Nhập lại không khớp → lỗi ngay dưới ô xác nhận.
  function validate() {
    const hasCur = curInput.value.length > 0;
    newInput.disabled = !hasCur;
    if (!hasCur) newInput.value = '';
    nw.field.classList.toggle('is-locked', !hasCur);

    const newVal = newInput.value;
    let newOk = false;
    if (!hasCur || newVal.length === 0) nw.setError('');
    else if (newVal === curInput.value) nw.setError('Mật khẩu mới không được trùng mật khẩu cũ');
    else if (!PW_RE.test(newVal)) nw.setError('Mật khẩu mới tối thiểu 6 ký tự, gồm cả chữ và số');
    else { nw.setError(''); newOk = true; }

    const confirmEnabled = hasCur && newVal.length > 0 && newVal !== curInput.value;
    confirmInput.disabled = !confirmEnabled;
    cf.field.classList.toggle('is-locked', !confirmEnabled);
    if (!confirmEnabled) confirmInput.value = '';

    let confirmMatch = false;
    const cVal = confirmInput.value;
    if (!confirmEnabled || cVal.length === 0) cf.setError('');
    else if (cVal !== newVal) cf.setError('Mật khẩu nhập lại không khớp');
    else { cf.setError(''); confirmMatch = true; }

    return { hasCur, newOk, confirmMatch };
  }
  // Dòng lỗi CHUNG (mạng / lỗi không xác định) đặt ở cuối form - vẫn là inline,
  // KHÔNG phải toast bên phải màn hình.
  const formErr = (() => {
    const errText = el('span');
    const box = el('div.pw-error.pw-form-error', {}, [el('span.pw-error-ico', { html: icon('infoCircle') }), errText]);
    box.style.display = 'none';
    return {
      el: box,
      setError(msg) { if (msg) { errText.textContent = msg; box.style.display = ''; } else { box.style.display = 'none'; } },
    };
  })();

  curInput.addEventListener('input', () => { cur.setError(''); formErr.setError(''); validate(); });
  newInput.addEventListener('input', () => { formErr.setError(''); validate(); });
  confirmInput.addEventListener('input', () => { formErr.setError(''); validate(); });

  const saveBtn = el('button.btn.primary', {
    text: 'Lưu mật khẩu mới',
    onclick: (e) => withSpin(e.currentTarget, async () => {
      const { hasCur, newOk, confirmMatch } = validate();
      const currentPassword = curInput.value;
      const newPassword = newInput.value;

      // Lỗi hiển thị INLINE ngay dưới ô tương ứng (validate đã set), chỉ cần focus.
      if (!hasCur) { cur.setError('Vui lòng nhập mật khẩu hiện tại'); curInput.focus(); return; }
      if (!newOk) { newInput.focus(); return; }
      if (!confirmMatch) {
        if (!confirmInput.value) cf.setError('Vui lòng nhập lại mật khẩu mới');
        confirmInput.focus();
        return;
      }

      let res;
      try {
        res = await vt.auth.changePassword({ currentPassword, newPassword });
      } catch (err) { res = { ok: false, code: err && err.code, error: err && err.message }; }

      if (res && res.ok === true) {
        // Thành công.
        closeModal();
        toast('Đã đổi mật khẩu thành công', 'ok');
        return;
      }

      // THẤT BẠI: báo lỗi INLINE ngay dưới ô liên quan (không dùng toast bên phải).
      // Map theo mã lỗi server; lỗi mạng/không rõ → dòng lỗi chung dưới form.
      formErr.setError('');
      switch (res && res.code) {
        case 'BAD_CURRENT_PASSWORD':
          cur.setError('Mật khẩu hiện tại không đúng'); curInput.focus(); break;
        case 'PASSWORD_SAME':
          nw.setError('Mật khẩu mới trùng mật khẩu hiện tại'); newInput.focus(); break;
        case 'PASSWORD_TOO_SHORT':
        case 'VALIDATION':
          nw.setError('Mật khẩu mới tối thiểu 6 ký tự, gồm cả chữ và số'); newInput.focus(); break;
        default:
          formErr.setError(errorMessage(res, 'Đổi mật khẩu thất bại'));
      }
    }),
  });

  const { modal } = openModal({
    title: 'Thay đổi mật khẩu',
    width: 520,
    body: [
      el('div.pw-form', {}, [cur.wrap, nw.wrap, cf.wrap, formErr.el]),
    ],
    footer: [
      el('button.btn', { text: 'Hủy', onclick: closeModal }),
      saveBtn,
    ],
  });
  applyI18n(modal);
  validate();
  setTimeout(() => curInput.focus(), 0);
}

// Account avatar - initial of the logged-in account, click opens a menu with
// logout. Falls back to 'V' before an account is known.
function buildAvatar() {
  const acc = state.account || {};
  // Đăng ký không còn tên hiển thị → header chỉ hiện EMAIL. Chữ cái avatar lấy từ email.
  const mail = (acc.email || 'Tài khoản').trim();
  const initial = (mail.charAt(0) || 'V').toUpperCase();
  // Che email: 3 ký tự đầu + "***" + đuôi mail (phần @tên-miền). Nếu không có "@"
  // hoặc phần trước "@" ngắn ≤ 3 ký tự thì giữ nguyên (không đủ để che).
  const maskMail = (m) => {
    const at = m.indexOf('@');
    if (at < 0) return m;
    const local = m.slice(0, at);
    const domain = m.slice(at); // gồm cả "@"
    return (local.length > 3 ? local.slice(0, 3) + '***' : local) + domain;
  };
  // Fixed-width box: avatar + a single email line + a dropdown caret.
  // The box width is fixed; long text is simply clipped (ellipsis) - overflow is fine.
  return el('div.user-box', {
    title: mail,
    onclick: (e) => { const box = e.currentTarget; box.classList.add('active'); const m = openMenu(box, [
      { label: 'Đổi mật khẩu', icon: 'changePassword', onClick: openChangePasswordModal },
      { label: 'Cài đặt', icon: 'settings', onClick: () => navigate('settings') },
      // Cùng đích với nút ví trên thanh tiêu đề (iconBtn 'wallet'): MÀN "Nạp tiền" - lối vào thứ hai,
      // không dựng luồng nạp riêng (y web: menu avatar ⇒ /topup).
      { label: 'Nạp tiền', icon: 'wallet', onClick: () => navigate('topup') },
      // Lối vào thứ hai của trang "Hoa hồng" (lối thứ nhất là dải mép thẻ gói). Giữ nhãn
      // 'Hoa Hồng' viết hoa H như cũ: nó là KHOÁ từ điển i18n đã dịch sẵn 4 ngôn ngữ, đổi
      // sang 'Hoa hồng' cho khớp tiêu đề header là mục menu lặng lẽ in tiếng Việt ở en/ru/zh.
      { label: 'Hoa Hồng', icon: 'star', onClick: () => navigate('affiliate') },
      { label: 'Ngôn ngữ', icon: 'globe', submenu: [
        { label: 'Tiếng Việt', onClick: () => setLanguage('vi') },
        { label: 'English', onClick: () => setLanguage('en') },
        { label: 'Русский', onClick: () => setLanguage('ru') },
        { label: '中文', onClick: () => setLanguage('zh') },
      ] },
      { label: 'Chủ đề', icon: 'contrast', submenu: [
        { label: 'Sáng', icon: 'themeSun', onClick: () => setTheme('light') },
        { label: 'Tối', icon: 'themeMoon', onClick: () => setTheme('dark') },
      ] },
      { label: 'Độ tương phản', icon: 'contrastItem', submenu: [
        { label: 'Sáng', icon: 'contrastLight', onClick: () => setContrast('default') },
        { label: 'Tiêu chuẩn', icon: 'contrastStd', onClick: () => setContrast('f9') },
      ] },
      '-',
      { label: 'Đăng xuất', icon: 'logout', danger: true, onClick: doLogout },
    ]); applyI18n(m);
      // Giữ viền brand khi menu đang mở; menu đóng (menu-host bị dọn) → bỏ .active.
      const host = document.getElementById('menu-host');
      if (host) {
        const obs = new MutationObserver(() => {
          if (!host.contains(m)) { box.classList.remove('active'); obs.disconnect(); }
        });
        obs.observe(host, { childList: true });
      } },
  }, [
    (() => {
      // Fill theo chữ cái phải đặt qua custom property (--avatar-fill) vì el()
      // dùng Object.assign(style,…) không set được biến CSS. Nhờ vậy vòng ring khi
      // click mới dựng được bằng background-clip padding/border-box.
      const av = el('div.avatar', { text: initial });
      av.style.setProperty('--avatar-fill', avatarGradient(initial));
      return av;
    })(),
    el('div.user-meta', {}, [
      el('span.user-mail', { text: maskMail(mail) }),
      el('span.user-sub#user-balance', {
        text: state.walletBalance != null ? fmtWalletVnd(state.walletBalance) : 'Số dư …',
        title: 'Số dư ví',
        // Chỉ HIỂN THỊ số dư - không mở modal khi bấm (nạp tiền qua nút ví ở header).
      }),
    ]),
    el('span.user-caret', { html: icon('chevron') }),
  ]);
}

async function doLogout() {
  try { await vt.auth.logout(); } catch { /* ignore */ }
  state.account = null;
  showLogin();
}

// PHIÊN CHẾT (main báo 'auth:expired' khi server từ chối token và không làm mới được) ⇒ về màn đăng nhập NGAY, một
// thông báo duy nhất (user 2026-11-07: thay vì toast "Token không hợp lệ hoặc đã hết hạn" liên tục). Đăng ký MỘT lần ở
// tầng module; đang ở màn đăng nhập (chưa có account) thì bỏ qua.
try {
  vt.auth.onExpired && vt.auth.onExpired(() => {
    if (!state.account) return;
    state.account = null;
    try { closeModal(); } catch { /* ignore */ }
    showLogin();
    toast('Phiên đăng nhập đã kết thúc. Vui lòng đăng nhập lại.');
  });
} catch { /* preload cũ không có onExpired */ }

function toggleSidebar() {
  setSidebarCollapsed(!state.collapsed, true);
}

// Apply a collapse state to the sidebar. `persist` writes it to settings (the
// user's manual toggle); transient callers (e.g. the RPA editor auto-collapsing
// the rail) pass persist=false so the saved preference is left untouched.
function setSidebarCollapsed(collapsed, persist) {
  collapsed = !!collapsed;
  if (collapsed === state.collapsed) return;
  state.collapsed = collapsed;
  hideTip();
  const sb = document.getElementById('sidebar');
  if (sb) sb.classList.toggle('collapsed', state.collapsed);
  const tgl = document.getElementById('sidebar-toggle');
  if (tgl) tgl.classList.toggle('collapsed', state.collapsed);
  if (persist) vt.settings.set({ sidebarCollapsed: state.collapsed });
  // move the group-active highlight between the collapsed icon and the expanded
  // sub-item depending on the new rail state.
  highlightNav(state.route);
}

// circular chevron that sits on the sidebar's right edge (mirrors MKTLogin's
// collapse handle). Points "‹" when open, "›" when collapsed.
function buildSidebarToggle() {
  return el('button.sidebar-toggle#sidebar-toggle' + (state.collapsed ? '.collapsed' : ''), {
    html: icon('chevron'), onclick: toggleSidebar,
  });
}

// thin top loading bar shown while a view module loads / route switches
function startProgress() {
  const p = document.getElementById('topprogress');
  if (!p) return;
  p.classList.remove('done');
  // restart the animation from 0
  void p.offsetWidth;
  p.classList.add('active');
}
function endProgress() {
  const p = document.getElementById('topprogress');
  if (!p) return;
  p.classList.add('done');
  setTimeout(() => { p.classList.remove('active', 'done'); }, 280);
}

// Refreshes the sidebar "ví" card from the server's authoritative balance:
//  - "Số dư hồ sơ"   = còn lại theo hạn mức quản trị viên đặt (thành viên) hoặc theo
//                      gói (owner/admin); null ⇒ "Không giới hạn".
//  - "Gói đang dùng" = tên gói đang hiệu lực.
//  - "Hồ sơ hiện có" = số hồ sơ đã tính vào hạn mức (thành viên: do họ tạo).
// Called on mount and after every create/delete so the balance stays live. Kept the
// name refreshProfileCount for the existing callers (profile_create/trash/profiles).
export async function refreshProfileCount() {
  try {
    const bal = await remote.team.balance();
    // Gói hiện tại có HOÀN LƯỢT tạo khi xoá vĩnh viễn không (gói Free khi admin tắt công tắc ⇒ false). Modal "Xóa hồ sơ"
    // (profiles.js) đọc cờ này để không hứa điều server không làm. Server cũ không trả ⇒ coi như có hoàn.
    window.__polyRefundOnDelete = bal.refundOnDelete !== false;
    // Đã lên gói trả phí (Free chỉ ở lần đầu; mua Pro thì workspace vĩnh viễn là Pro).
    const isPaid = (bal.planTier || 0) > 0 || (bal.planName && bal.planName !== 'Free');
    // Tên gói (header thẻ) - hiển thị đúng tên gói, KHÔNG thêm hậu tố "Plan".
    const nmEl = document.getElementById('plan-name');
    if (nmEl) {
      const name = bal.planName || 'Free';
      nmEl.textContent = name.replace(/\s*plan\s*$/i, '').trim() || name;
    }
    // Nút CTA:
    //   • Free (chưa mua) → "Nâng cấp ngay" (mua gói lần đầu).
    //   • Đã Pro & CÒN HẠN → "Nâng cấp gói" (đổi lên mức cao hơn, trả chênh lệch).
    //   • Đã Pro & HẾT HẠN → "Gia hạn" (mua kỳ mới để mở khoá lại).
    const upLabel = document.getElementById('plan-upgrade-label');
    if (upLabel) upLabel.textContent = !isPaid ? 'Nâng cấp ngay' : (bal.expired ? 'Gia hạn' : 'Nâng cấp gói');
    // "Hết hạn lúc": Vô hạn khi không có hạn (Free), else ngày hết hạn. Gói trả phí ĐÃ hết
    // hạn → thêm "(đã hết hạn)" + class đỏ để báo rõ (plan VẪN là Pro, không về Free).
    const expEl = document.getElementById('plan-expiry');
    if (expEl) {
      if (bal.periodEnd) {
        // fmtDate: định dạng theo ngôn ngữ đang chọn - để cứng 'vi-VN' thì ngày mồng 1..12
        // hiện giữa giao diện tiếng Anh sẽ bị hiểu SAI THÁNG (7/3 = 3 July hay 7 March?).
        const d = fmtDate(bal.periodEnd);
        expEl.textContent = bal.expired ? tf('{0} (đã hết hạn)', d) : d;
      } else {
        expEl.textContent = 'Vô hạn';
      }
      expEl.classList.toggle('plan-expired', !!bal.expired);
    }
    // "Hồ Sơ": số CHỖ (slot) đang bị chiếm / hạn mức của EMAIL ĐÃ THUÊ GÓI (bể chung),
    // hiển thị giống nhau cho chủ gói lẫn thành viên (server trả poolUsed/poolLimit).
    // MÔ HÌNH QUOTA/SLOT: poolUsed là số hồ sơ ĐANG TỒN TẠI - KỂ CẢ hồ sơ trong thùng rác -
    // chứ không phải tổng lượt tạo trong đời. Xoá vĩnh viễn thì con số này GIẢM (hoàn slot);
    // chỉ chuyển vào thùng rác thì KHÔNG giảm. ∞ = không giới hạn.
    const profEl = document.getElementById('plan-profiles');
    if (profEl) {
      const pUsed = bal.poolUsed ?? bal.used ?? 0;
      const pLimit = (bal.poolLimit !== undefined) ? bal.poolLimit : bal.limit;
      profEl.textContent = (pLimit == null) ? `${pUsed}/∞` : `${pUsed}/${pLimit}`;
    }
    // "Thành viên": số thành viên team hiện có / hạn mức gói (∞ khi không giới hạn).
    // Gói Free KHÔNG cộng tác nhóm → ẩn hẳn dòng này (ẩn cả hàng .plan-row cha).
    const memEl = document.getElementById('plan-members');
    if (memEl) {
      const mUsed = bal.memberUsed ?? 0;
      const mLimit = (bal.memberLimit !== undefined) ? bal.memberLimit : null;
      memEl.textContent = (mLimit == null) ? `${mUsed}/∞` : `${mUsed}/${mLimit}`;
      const memRow = memEl.closest('.plan-row');
      if (memRow) memRow.style.display = isPaid ? '' : 'none';
    }
    // `bal.dayLimits` (limit tạo/mở theo ngày) CÓ trong payload nhưng thẻ gói không vẽ nữa -
    // xem ghi chú ở buildPlanGrid. Server vẫn chặn khi chạm limit, đó mới là phần bắt buộc.
  } catch { /* ignore */ }
}

// LÀM MỚI THẺ GÓI NGAY sau MỌI thao tác chạm tới con số của gói - có GỘP NHỊP.
//
// Luật: thẻ gói không bao giờ được đứng yên chờ người dùng đổi trang hay bấm "làm mới". Từ khi
// hồ sơ chuyển sang mô hình quota/slot thì điều này thành bắt buộc: xoá vĩnh viễn 10 hồ sơ mà
// thẻ vẫn ghi số cũ thì người dùng kết luận "xoá vĩnh viễn KHÔNG hoàn chỗ" - đúng cái ngược lại
// với sản phẩm đang hứa.
//
// Vì sao GỘP: mỗi lượt là 1 request /members/balance (endpoint rất nóng), mà thao tác hàng loạt
// (tạo 100 hồ sơ, mở 50 hồ sơ) bắn hàng chục tín hiệu liền nhau. Gộp về ĐÚNG MỘT lần sau 250ms
// nên vẫn "ngay lập tức" với mắt người mà không đập server. Trailing debounce (không leading):
// lần gọi cuối mới là lúc DB đã xong hết, đọc sớm là ra số giữa chừng.
let _planBumpTimer = null;
export function bumpPlanCard() {
  clearTimeout(_planBumpTimer);
  _planBumpTimer = setTimeout(() => {
    _planBumpTimer = null;
    refreshProfileCount().catch(() => {});
  }, 250);
}

// Render the login gate into #app. On success we have a server session, so we
// store the account and mount the real shell.
function showLogin() {
  // Mã giảm giá đang nhập (views/upgrade.js, sessionStorage) không được mang sang tài khoản đăng nhập kế tiếp.
  try { sessionStorage.removeItem('polyCheckoutCoupon'); } catch { /* bỏ qua */ }
  const app = document.getElementById('app');
  // Trang đăng nhập/đăng ký LUÔN dùng chế độ sáng, bất kể theme đã lưu (chế độ tối chỉ
  // áp dụng bên trong app sau khi đăng nhập). mountShell() khôi phục lại theme của user.
  applyTheme('light');
  clear(app);
  renderLogin(app, {
    onSuccess: async (account) => {
      state.account = account;
      await mountShell();
    },
  });
}

// Build the authenticated shell (sidebar + header + content) and route to the
// initial view. Only reached once a server session exists.
async function mountShell() {
  const app = document.getElementById('app');
  // A re-mount (logout → re-login) throws away the old #content; destroy any
  // kept-alive hosts first so their timers/listeners don't leak, and forget the
  // previously-shown route so the first navigate() builds fresh.
  resetHosts();
  state.route = null;
  clear(app);
  // Khôi phục theme đã lưu của user khi vào app (showLogin đã ép sáng cho màn đăng nhập).
  applyTheme(state.settings.theme);
  const sidebar = buildSidebar();
  if (state.collapsed) sidebar.classList.add('collapsed');
  app.appendChild(sidebar);
  app.appendChild(el('div.main', {}, [buildSidebarToggle(), buildHeader(), el('div.content#content')]));
  // Bong bóng info trong app (liên hệ hỗ trợ): position:fixed, kéo thả tự do, thu gọn
  // thành robot phát sáng. Đặt trong #app (bị clear() dọn khi logout→login) nên KHÔNG bị
  // nhân bản qua các lần mountShell, và tồn tại xuyên suốt mọi view vì nằm ngoài #content.
  app.appendChild(inAppInfoBubble());

  // Track the live running-profile set GLOBALLY (this subscription lives for the whole
  // session, independent of which view is mounted). Two jobs:
  //  1) toggle a <body> flag so the sidebar pauses its GPU-heavy animations while any
  //     browser is open (see .browsers-running in app.css → silky hover under GPU load);
  //  2) cache the running ids on window.__vtApp so a view (e.g. the profile grid) can
  //     render the correct open/close state INSTANTLY on (re)mount - no re-detect lag
  //     when switching sidebar items back and forth.
  // KHÔNG gọi bumpPlanCard() ở đây nữa: từ khi thẻ gói bỏ hàng "Mở hôm nay", việc MỞ hồ sơ
  // không đổi một con số nào trên thẻ (hết hạn / slot hồ sơ / thành viên đều không phụ thuộc
  // trạng thái đang chạy). Giữ lại chỉ là bắn thêm /members/balance mỗi đợt mở - endpoint rất
  // nóng. Đóng trình duyệt trước đây cũng đã được bỏ qua vì đúng lý do này.
  const onRun = (ids) => {
    state.runningIds = Array.isArray(ids) ? ids.slice() : [];
    document.body.classList.toggle('browsers-running', state.runningIds.length > 0);
  };
  try { onRun(await remote.profiles.runningIds()); } catch { /* ignore */ }
  if (remote.profiles.onRunningChanged) {
    // mountShell() can run more than once per process (e.g. logout → re-login), and
    // onRunningChanged() registers an ipcRenderer listener each call. Drop the previous
    // subscription first so handlers don't pile up on the 'profile:running-changed'
    // channel - otherwise every open/close event fans out to N stale onRun copies.
    try { if (state._offRun) state._offRun(); } catch { /* ignore */ }
    try { state._offRun = remote.profiles.onRunningChanged(onRun) || null; } catch { /* ignore */ }
  }

  // Nạp workspace (bộ chọn header) TRƯỚC + CHỜ XONG: refreshWorkspaces() tự chữa
  // header x-workspace-id nếu đang trỏ workspace không thuộc account (đổi tài khoản).
  // Phải xong TRƯỚC khi navigate() dựng lưới, nếu không loadProfiles chạy với header
  // lệch → 403 → toast "lỗi cơ sở dữ liệu" oan ngay lần vào đầu.
  await refreshWorkspaces();
  await refreshProfileCount();
  // Nạp quyền của tôi ở workspace hiện hành để các view ẩn/hiện nút tạo/sửa/xoá
  // đúng ngay lần dựng đầu (server vẫn enforce thật). Best-effort, không chặn.
  loadPermissions(true).catch(() => {});
  // Nạp trước tính năng theo gói để cổng nâng cấp (gateFeature) quyết định đồng bộ.
  // CHỜ XONG (rồi mới navigate) để nếu HẾT HẠN thì biết ngay và giữ trang chính ở
  // "Hồ sơ" + phủ thẻ gói (enforceExpiry chạy trong navigate). Server vẫn enforce.
  await loadPlanFeatures(true).catch(() => {});

  // Hộp thư lời mời: nạp ngay khi vào app rồi poll định kỳ để badge chuông tự cập
  // nhật khi có người mời (không cần F5). Dọn timer cũ nếu mountShell chạy lại.
  refreshInvites();
  try { if (state._invitesTimer) clearInterval(state._invitesTimer); } catch { /* ignore */ }
  state._invitesTimer = setInterval(refreshInvites, 60000);

  // Số dư ví (theo workspace hiện hành) → hiển thị cạnh avatar. Best-effort.
  refreshWalletBalance();

  // HẾT HẠN → luôn mở trang chính ở "Hồ sơ" (rồi phủ thẻ gói chính giữa), bất kể
  // route lưu trước đó; còn hạn thì khôi phục route đang mở dở như thường.
  let saved = state.settings.activeRoute && views[state.settings.activeRoute] ? state.settings.activeRoute : 'profiles';
  // Không còn route nào bị CỔNG GÓI chặn ở navigate() nên không phải lùi 'api' về 'profiles'
  // nữa (gói Free được vào "Tài liệu API" từ 2026-09-27). Nếu sau này thêm lại một cổng route
  // trong navigate() thì PHẢI thêm lại lối lùi ở đây: navigate() return sớm để hiện modal,
  // vùng nội dung ở lại RỖNG và người dùng vào app thấy màn trắng.
  const initial = isPlanExpired() ? 'profiles' : saved;
  // ĐỌC NHÂN ĐANG DÙNG TRƯỚC KHI VẼ TRANG ĐẦU. Các màn hình hiển thị số phiên bản
  // (badge "140/150" ở lưới Hồ sơ + Thùng rác, dòng "Browser Kernel" ở Tạo hồ sơ) lấy
  // giá trị này LÚC RENDER; nếu để sau navigate thì trang đầu vẽ bằng số dự phòng 140
  // rồi không tự vẽ lại → người dùng tải nhân 150 mà vẫn thấy 140. Hàm này chỉ đọc sổ
  // cái cục bộ (nhanh) và tự nuốt mọi lỗi nên await ở đây không chặn vào app.
  await syncActiveKernelToFingerprint().catch(() => {});
  // Nạp danh mục UA từ web admin MỘT LẦN vào bộ chọn (không gọi API mỗi lần chọn UA).
  // Best-effort, không chặn vào app: chờ ở đây để trang đầu (nếu là Tạo hồ sơ) đã có
  // danh sách đầy đủ; lỗi cũng nuốt để không kẹt.
  await loadUserAgentCatalog();
  await navigate(initial);

  // Kiểm tra cập nhật khi vào app (im lặng): force → modal chặn; thường + chưa hoãn bản
  // đó → modal có "Để sau"; không có → chỉ badge. Best-effort, không chặn dựng shell.
  checkForUpdates({ silent: true }).catch(() => {});

  // Nhân trình duyệt: lần đầu (chưa cài nhân Chromium nào) → tự mở modal tải BẮT BUỘC
  // bản mới nhất, vì không có nhân thì không mở được hồ sơ. Đã có nhân → trả nhanh (chỉ
  // đọc manifest cục bộ). Tải xong thì đồng bộ lại phiên bản engine cho vân tay (lần
  // đồng bộ đầu đã chạy TRƯỚC navigate ở trên). Best-effort - không chặn vào app.
  ensureKernelOnStartup('chromium').then((ok) => { if (ok) syncActiveKernelToFingerprint(); }).catch(() => {});

  // Popup quảng cáo - lấy promo đang hiệu lực từ server (bảng promos do web admin
  // quản lý) rồi hiện giữa màn hình. Không có promo → không hiện gì. Best-effort.
  showPromoModal().catch(() => {});

  // Banner quảng cáo ở header (type='banner'). Rỗng nếu không có banner hiệu lực.
  mountPromoBanner(document.getElementById('header-promo')).catch(() => {});

  // Khởi động NGUỘI bằng lối tắt hồ sơ: tham số --open-profile=<id> có trong argv từ
  // trước khi renderer tồn tại, nên main giữ hộ và ta kéo về ĐÚNG Ở ĐÂY - cuối
  // mountShell, tức đã đăng nhập + đã có host trang Hồ sơ. Kéo sớm hơn (trong boot) là
  // mở hồ sơ trong lúc còn ở màn đăng nhập. takePendingOpen XOÁ id sau lần gọi đầu nên
  // lần logout → đăng nhập lại sau đó không mở lại hồ sơ đó nữa.
  try {
    const pendingId = await vt.shortcuts.takePendingOpen();
    if (pendingId) openProfileFromShortcut(pendingId);
  } catch { /* bản preload cũ / main chưa có handler */ }
}

// Cho các view khác (vd màn Thành viên nhóm sau khi tự accept qua token) chủ động
// làm mới badge chuông.
window.__vtRefreshInvites = refreshInvites;

// ---- LỐI TẮT HỒ SƠ (.lnk trên màn hình nền - xem main/shortcuts.js) ----
// Mở hồ sơ theo id do lối tắt yêu cầu. Bắt buộc phải sang trang "Hồ sơ" trước: toàn bộ
// luồng mở (chặn hết hạn, đòi nhân đã cài, khoá phiên, đồng bộ, badge/toast) sống trong
// views/profiles.js nên phải có host của nó đã dựng mới gọi được openProfileById.
async function openProfileFromShortcut(id) {
  if (!id) return;
  try {
    await navigate('profiles');
    const host = state.hosts.get('profiles');
    if (host && host.api && host.api.openProfileById) await host.api.openProfileById(String(id));
  } catch { /* lối tắt lỗi thì im lặng - người dùng vẫn đang ở trong app */ }
}
// Nhấp lối tắt khi app ĐANG chạy → main đẩy id xuống qua kênh push. Đăng ký MỘT LẦN ở
// tầng module (không đặt trong mountShell) vì mountShell chạy lại mỗi lần logout → đăng
// nhập lại, đặt trong đó là listener dồn lên nhau và một cú nhấp mở hồ sơ N lần.
try {
  if (window.vt && vt.shortcuts && vt.shortcuts.onOpenProfile) {
    vt.shortcuts.onOpenProfile((id) => { openProfileFromShortcut(id); });
  }
} catch { /* bản preload cũ không có nhánh shortcuts */ }

async function boot() {
  state.settings = await vt.settings.all();
  applyTheme(state.settings.theme);
  applyContrast(state.settings.contrast);
  // Ngôn ngữ y web landing: đã tự chọn ⇒ theo lựa chọn; chưa ⇒ theo quốc gia IP (VN ⇒ vi, còn lại ⇒ en).
  // Bản cũ chưa có cờ languagePicked: ngôn ngữ khác 'vi' (mặc định cũ) chỉ có thể do người dùng chọn.
  if (!state.settings.languagePicked && state.settings.language && state.settings.language !== 'vi') {
    state.settings.languagePicked = true;
    try { vt.settings.set({ languagePicked: true }); } catch { /* ignore */ }
  }
  if (!state.settings.languagePicked) {
    try { if (vt.settings.autoLang) state.settings.language = await vt.settings.autoLang(); } catch { /* giữ mặc định */ }
  }
  setLang(state.settings.language || 'vi');
  state.collapsed = !!state.settings.sidebarCollapsed;
  installTooltips();

  // Gate on a valid server session. status() is the only network call at boot;
  // it returns the cached account when offline so a logged-in user still gets in.
  let loggedIn = false;
  try {
    const res = await vt.auth.status();
    if (res && res.ok && res.data && res.data.loggedIn) {
      state.account = res.data.account;
      loggedIn = true;
    }
  } catch { /* treat as logged out */ }

  try {
    if (loggedIn) await mountShell();
    else showLogin();
  } finally {
    // Báo main: app đã dựng xong (shell hoặc màn đăng nhập) → đóng cửa sổ splash
    // và hiện cửa sổ chính. finally: kể cả dựng lỗi cũng báo để không kẹt ở splash.
    try { vt.win.ready(); } catch { /* ignore */ }
  }
}

window.addEventListener('DOMContentLoaded', boot);
// expose for views that need to bump the sidebar profile counter, plus the live
// running-profile id set (so the profile grid renders open/close state instantly).
window.__vtApp = { refreshProfileCount, bumpPlanCard, refreshWalletBalance, navigate, getRunningIds: () => (state.runningIds || []).slice(), getAccount: () => state.account, setSidebarCollapsed, isSidebarCollapsed: () => state.collapsed };
