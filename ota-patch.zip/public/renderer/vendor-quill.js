// Vendored Quill (rich-text editor) loader — same pattern as the Swagger/Monaco
// vendoring: quill.js + quill.snow.css live under renderer/vendor and are pulled
// in via same-origin <script>/<link> (CSP is script-src/style-src 'self', no CDN).
//
// Two gotchas handled here:
//   1. Quill's UMD build attaches to `window.Quill` ONLY when there is no AMD
//      `define`. Monaco's vendored AMD loader sets a global `define.amd`, so — just
//      like swagger-ui-bundle — we neutralise `define` for the duration of the
//      quill.js load and restore it after, forcing the UMD global branch.
//   2. Quill's "formula" toolbar button needs a global `katex`. We load katex
//      (js + css) FIRST so the fx button renders exactly like MKTLogin's.
'use strict';
import { tf } from './i18n.js';

const QUILL_CSS = 'renderer/vendor/quill/quill.snow.css';
const QUILL_JS = 'renderer/vendor/quill/quill.js';
const KATEX_CSS = 'renderer/vendor/katex/katex.min.css';
const KATEX_JS = 'renderer/vendor/katex/katex.min.js';

function loadCss(id, href) {
  if (document.getElementById(id)) return;
  const link = document.createElement('link');
  link.id = id; link.rel = 'stylesheet'; link.href = href;
  document.head.appendChild(link);
}

// Load a UMD script while hiding any AMD `define` so it takes the global branch.
function loadUmdScript(src) {
  return new Promise((resolve, reject) => {
    const savedDefine = window.define;
    const restore = () => { window.define = savedDefine; };
    // eslint-disable-next-line no-undef
    if (savedDefine) window.define = undefined;
    const s = document.createElement('script');
    s.src = src;
    s.onload = () => { restore(); resolve(); };
    s.onerror = () => { restore(); reject(new Error(tf('không tải được {0}', src))); };
    document.head.appendChild(s);
  });
}

let quillLoad = null;

// Resolves to the global `Quill` constructor (idempotent — safe to call repeatedly).
export function ensureQuill() {
  if (quillLoad) return quillLoad;
  quillLoad = (async () => {
    loadCss('katex-css', KATEX_CSS);
    loadCss('quill-snow-css', QUILL_CSS);
    if (!window.katex) await loadUmdScript(KATEX_JS);
    if (!window.Quill) await loadUmdScript(QUILL_JS);
    if (!window.Quill) throw new Error('Quill không khả dụng sau khi tải');
    return window.Quill;
  })();
  return quillLoad;
}
