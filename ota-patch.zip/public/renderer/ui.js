// Small DOM helpers shared across views: element builder, toasts, modal host,
// and context menus. Keeps view code declarative without a framework.
import { icon } from './icons.js';
import { applyI18n, t, tf } from './i18n.js';

// el('div.classname#id', { attrs }, [children|string])
export function el(tag, attrs = {}, children = []) {
  let name = 'div';
  const classes = [];
  let id = null;
  const m = tag.match(/^([a-zA-Z0-9]+)?([.#][^\s]*)?$/);
  if (m) {
    name = m[1] || 'div';
    const rest = tag.slice((m[1] || '').length);
    rest.split(/(?=[.#])/).forEach((tok) => {
      if (tok.startsWith('.')) classes.push(tok.slice(1));
      else if (tok.startsWith('#')) id = tok.slice(1);
    });
  }
  const node = document.createElement(name);
  if (classes.length) node.className = classes.join(' ');
  if (id) node.id = id;
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null) continue;
    if (k === 'html') node.innerHTML = v;
    else if (k === 'text') node.textContent = v;
    else if (k === 'style' && typeof v === 'object') Object.assign(node.style, v);
    else if (k.startsWith('on') && typeof v === 'function') node.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === 'dataset') Object.assign(node.dataset, v);
    else if (v === true) node.setAttribute(k, '');
    else if (v !== false) node.setAttribute(k, v);
  }
  appendChildren(node, children);
  return node;
}

function appendChildren(node, children) {
  const list = Array.isArray(children) ? children : [children];
  for (const c of list) {
    if (c == null || c === false) continue;
    node.appendChild(typeof c === 'string' || typeof c === 'number' ? document.createTextNode(String(c)) : c);
  }
}

export function clear(node) { while (node.firstChild) node.removeChild(node.firstChild); return node; }

export function iconBtn(name, attrs = {}) {
  return el('button.icon-btn', { ...attrs, html: icon(name), title: attrs.title || '' });
}

// Run an async action while showing a loading spinner ON the button that triggered it,
// so any feature that isn't instant (open/close profile, start sync, network call…)
// gives immediate visible feedback instead of looking frozen. Auto-adapts to the button
// kind:
//   • text buttons (.btn): prepend a rotating .btn-spin ring, keep the label, hide the
//     original leading icon, and disable the button until the action settles.
//   • icon-only buttons (.icon-btn / .ip-act): rotate the existing svg via .spinning.
// Re-entrancy guard: a second click while busy is ignored. A small floor (~400ms) keeps
// a near-instant action from blinking the spinner. Always restores the button, even on
// throw. Returns whatever fn() returns (or undefined if it was ignored as re-entrant).
export async function withSpin(btn, fn) {
  if (!btn || btn.classList.contains('is-loading') || btn.classList.contains('spinning')) return;
  const isText = btn.classList.contains('btn');
  const started = Date.now();
  let restore;
  if (isText) {
    const prevHTML = btn.innerHTML;
    const prevDisabled = btn.disabled;
    btn.classList.add('is-loading');
    btn.disabled = true;
    btn.insertAdjacentHTML('afterbegin', '<span class="btn-spin"></span>');
    restore = () => { btn.classList.remove('is-loading'); btn.disabled = prevDisabled; btn.innerHTML = prevHTML; };
  } else {
    btn.classList.add('spinning');
    restore = () => { btn.classList.remove('spinning'); };
  }
  try {
    return await fn();
  } finally {
    const elapsed = Date.now() - started;
    if (elapsed < 400) setTimeout(restore, 400 - elapsed); else restore();
  }
}

// ------------------------------------------------------- empty-state vector
// Shared "no data" illustration (modern duotone: soft floating panel + empty
// rows + magnifier, brand-tinted). Uses currentColor for the highlights so it
// follows the brand colour. Shown by every datagrid when it has no rows.
export const noDataSvg = `<svg viewBox="0 0 160 120" fill="none" xmlns="http://www.w3.org/2000/svg">
  <ellipse cx="80" cy="104" rx="54" ry="8" fill="currentColor" opacity=".08"/>
  <rect x="34" y="26" width="92" height="64" rx="10" fill="currentColor" opacity=".08"/>
  <rect x="44" y="14" width="72" height="70" rx="10" class="vec-paper" stroke="currentColor" stroke-opacity=".35" stroke-width="2"/>
  <rect x="54" y="28" width="20" height="20" rx="5" fill="currentColor" opacity=".22"/>
  <rect x="80" y="30" width="28" height="5" rx="2.5" fill="currentColor" opacity=".30"/>
  <rect x="80" y="41" width="20" height="5" rx="2.5" fill="currentColor" opacity=".18"/>
  <rect x="54" y="58" width="54" height="5" rx="2.5" fill="currentColor" opacity=".18"/>
  <rect x="54" y="69" width="38" height="5" rx="2.5" fill="currentColor" opacity=".12"/>
  <circle cx="108" cy="92" r="18" class="vec-paper" stroke="currentColor" stroke-width="2.4"/>
  <path d="M121 105l9 9" stroke="currentColor" stroke-width="3.4" stroke-linecap="round"/>
  <path d="M101 92h14M108 85v14" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" opacity=".5"/>
</svg>`;

// Function-specific empty illustrations (same duotone language as noDataSvg -
// viewBox 160×120, currentColor=brand, `.vec-paper` fills the "paper" surfaces).
// Each datagrid passes the one that matches what it lists, so the empty state
// reads as the real thing being absent (a closed browser, an empty bin, …)
// instead of a generic "no data" graphic.

// "Không mở trình duyệt" - a browser window with a circle-slash badge.
export const noBrowserSvg = `<svg viewBox="0 0 160 120" fill="none" xmlns="http://www.w3.org/2000/svg">
  <ellipse cx="80" cy="104" rx="54" ry="8" fill="currentColor" opacity=".08"/>
  <rect x="34" y="26" width="92" height="60" rx="10" fill="currentColor" opacity=".08"/>
  <rect x="40" y="18" width="80" height="62" rx="10" class="vec-paper" stroke="currentColor" stroke-opacity=".35" stroke-width="2"/>
  <path d="M40 33h80" stroke="currentColor" stroke-opacity=".25" stroke-width="2"/>
  <circle cx="50" cy="25.5" r="2.4" fill="currentColor" opacity=".4"/>
  <circle cx="58" cy="25.5" r="2.4" fill="currentColor" opacity=".28"/>
  <circle cx="66" cy="25.5" r="2.4" fill="currentColor" opacity=".2"/>
  <rect x="78" y="22.5" width="36" height="6" rx="3" fill="currentColor" opacity=".15"/>
  <rect x="52" y="46" width="56" height="6" rx="3" fill="currentColor" opacity=".18"/>
  <rect x="52" y="59" width="38" height="6" rx="3" fill="currentColor" opacity=".12"/>
  <circle cx="111" cy="92" r="18" class="vec-paper" stroke="currentColor" stroke-width="2.4"/>
  <path d="M100 81l22 22" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>
</svg>`;

// "Chưa có hồ sơ" - a profile/ID card (avatar) with a + badge.
export const noProfileSvg = `<svg viewBox="0 0 160 120" fill="none" xmlns="http://www.w3.org/2000/svg">
  <ellipse cx="80" cy="104" rx="54" ry="8" fill="currentColor" opacity=".08"/>
  <rect x="34" y="26" width="92" height="64" rx="10" fill="currentColor" opacity=".08"/>
  <rect x="44" y="16" width="72" height="70" rx="10" class="vec-paper" stroke="currentColor" stroke-opacity=".35" stroke-width="2"/>
  <circle cx="68" cy="41" r="11" fill="currentColor" opacity=".22"/>
  <path d="M53 63c0-8.3 6.7-15 15-15s15 6.7 15 15z" fill="currentColor" opacity=".16"/>
  <rect x="50" y="71" width="60" height="5" rx="2.5" fill="currentColor" opacity=".12"/>
  <circle cx="109" cy="90" r="16" class="vec-paper" stroke="currentColor" stroke-width="2.4"/>
  <path d="M109 83v14M102 90h14" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/>
</svg>`;

// "Thùng rác trống" - an empty waste bin.
export const trashEmptySvg = `<svg viewBox="0 0 160 120" fill="none" xmlns="http://www.w3.org/2000/svg">
  <ellipse cx="80" cy="104" rx="46" ry="8" fill="currentColor" opacity=".08"/>
  <path d="M57 45h46l-4.4 47.6a8 8 0 0 1-8 7.4H69.4a8 8 0 0 1-8-7.4z" class="vec-paper" stroke="currentColor" stroke-opacity=".35" stroke-width="2" stroke-linejoin="round"/>
  <path d="M50 41h60" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/>
  <path d="M70 41v-6a4 4 0 0 1 4-4h12a4 4 0 0 1 4 4v6" stroke="currentColor" stroke-opacity=".5" stroke-width="2" stroke-linejoin="round"/>
  <path d="M72 58v30M80 58v30M88 58v30" stroke="currentColor" stroke-width="2" stroke-linecap="round" opacity=".22"/>
</svg>`;

// "Chưa có proxy" - a globe/network sphere with a + badge (add a proxy).
export const noProxySvg = `<svg viewBox="0 0 160 120" fill="none" xmlns="http://www.w3.org/2000/svg">
  <ellipse cx="80" cy="104" rx="50" ry="8" fill="currentColor" opacity=".08"/>
  <circle cx="76" cy="52" r="34" fill="currentColor" opacity=".08"/>
  <circle cx="76" cy="52" r="30" class="vec-paper" stroke="currentColor" stroke-opacity=".35" stroke-width="2"/>
  <path d="M46 52h60M76 22v60" stroke="currentColor" stroke-opacity=".22" stroke-width="2"/>
  <path d="M76 22c-12 8-12 52 0 60M76 22c12 8 12 52 0 60" stroke="currentColor" stroke-opacity=".28" stroke-width="2"/>
  <ellipse cx="76" cy="52" rx="30" ry="12" stroke="currentColor" stroke-opacity=".2" stroke-width="2"/>
  <circle cx="76" cy="52" r="4.5" fill="currentColor" opacity=".28"/>
  <circle cx="109" cy="88" r="16" class="vec-paper" stroke="currentColor" stroke-width="2.4"/>
  <path d="M109 81v14M102 88h14" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/>
</svg>`;

// "Chưa có lịch" - a calendar with a clock badge (a schedule).
export const noScheduleSvg = `<svg viewBox="0 0 160 120" fill="none" xmlns="http://www.w3.org/2000/svg">
  <ellipse cx="80" cy="104" rx="50" ry="8" fill="currentColor" opacity=".08"/>
  <rect x="36" y="30" width="88" height="60" rx="10" fill="currentColor" opacity=".08"/>
  <rect x="44" y="24" width="72" height="66" rx="10" class="vec-paper" stroke="currentColor" stroke-opacity=".35" stroke-width="2"/>
  <path d="M44 40h72" stroke="currentColor" stroke-opacity=".25" stroke-width="2"/>
  <path d="M58 20v10M102 20v10" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>
  <rect x="54" y="50" width="12" height="9" rx="2" fill="currentColor" opacity=".2"/>
  <rect x="72" y="50" width="12" height="9" rx="2" fill="currentColor" opacity=".14"/>
  <rect x="54" y="65" width="12" height="9" rx="2" fill="currentColor" opacity=".14"/>
  <circle cx="106" cy="86" r="16" class="vec-paper" stroke="currentColor" stroke-width="2.4"/>
  <path d="M106 78v8l5 4" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`;

// "Chưa có nhiệm vụ" - a clipboard checklist (a task list).
export const noTaskSvg = `<svg viewBox="0 0 160 120" fill="none" xmlns="http://www.w3.org/2000/svg">
  <ellipse cx="80" cy="104" rx="48" ry="8" fill="currentColor" opacity=".08"/>
  <rect x="40" y="26" width="80" height="64" rx="10" fill="currentColor" opacity=".08"/>
  <rect x="48" y="20" width="64" height="70" rx="10" class="vec-paper" stroke="currentColor" stroke-opacity=".35" stroke-width="2"/>
  <rect x="68" y="14" width="24" height="12" rx="4" fill="currentColor" opacity=".25"/>
  <path d="M57 40l4 4 7-7" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" opacity=".5"/>
  <rect x="74" y="38" width="28" height="5" rx="2.5" fill="currentColor" opacity=".2"/>
  <path d="M57 56l4 4 7-7" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" opacity=".5"/>
  <rect x="74" y="54" width="28" height="5" rx="2.5" fill="currentColor" opacity=".16"/>
  <path d="M57 72l4 4 7-7" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" opacity=".3"/>
  <rect x="74" y="70" width="22" height="5" rx="2.5" fill="currentColor" opacity=".12"/>
</svg>`;

// "Chưa có thành viên" - a group of people (a member list). The front figure is
// outlined "paper", the two behind are soft ghosts.
export const noMemberSvg = `<svg viewBox="0 0 160 120" fill="none" xmlns="http://www.w3.org/2000/svg">
  <ellipse cx="80" cy="106" rx="52" ry="8" fill="currentColor" opacity=".08"/>
  <g opacity=".18">
    <circle cx="46" cy="52" r="13" fill="currentColor"/>
    <path d="M26 90c0-11 9-20 20-20s20 9 20 20z" fill="currentColor"/>
  </g>
  <g opacity=".18">
    <circle cx="114" cy="52" r="13" fill="currentColor"/>
    <path d="M94 90c0-11 9-20 20-20s20 9 20 20z" fill="currentColor"/>
  </g>
  <circle cx="80" cy="44" r="17" class="vec-paper" stroke="currentColor" stroke-opacity=".4" stroke-width="2"/>
  <path d="M53 96c0-14.9 12.1-27 27-27s27 12.1 27 27z" class="vec-paper" stroke="currentColor" stroke-opacity=".4" stroke-width="2"/>
</svg>`;

// "Chưa có nhật ký/hoạt động" - a document with lines + a history-clock badge.
export const noLogSvg = `<svg viewBox="0 0 160 120" fill="none" xmlns="http://www.w3.org/2000/svg">
  <ellipse cx="80" cy="104" rx="48" ry="8" fill="currentColor" opacity=".08"/>
  <rect x="40" y="24" width="76" height="66" rx="10" fill="currentColor" opacity=".08"/>
  <path d="M46 18h44l20 20v46a6 6 0 0 1-6 6H52a6 6 0 0 1-6-6z" class="vec-paper" stroke="currentColor" stroke-opacity=".35" stroke-width="2" stroke-linejoin="round"/>
  <path d="M90 18v20h20" stroke="currentColor" stroke-opacity=".3" stroke-width="2" stroke-linejoin="round"/>
  <path d="M56 50h30M56 62h40M56 74h24" stroke="currentColor" stroke-width="4" stroke-linecap="round" opacity=".16"/>
  <circle cx="108" cy="88" r="16" class="vec-paper" stroke="currentColor" stroke-width="2.4"/>
  <path d="M108 80v8l5 4" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`;

// Build a datagrid empty-state element (illustration + caption). Hidden by
// default; toggle its visibility from renderPage() via `node.style.display`.
// Pass a function-specific `svg` (e.g. noProfileSvg / trashEmptySvg) so the
// graphic matches what the grid lists; falls back to the generic noDataSvg.
export function gridEmpty(text = 'Không có dữ liệu', svg = noDataSvg) {
  return el('div.grid-empty', { style: { display: 'none' } }, [
    el('div.grid-empty-ico', { html: svg }),
    el('div.muted', { text }),
  ]);
}

// ------------------------------------------------------- custom combobox
// A styled drop-in replacement for native <select> (whose popup can't be
// themed). `options` is an array of strings or { value, label } objects.
// The returned element exposes a `.value` getter/setter (setting it updates
// the UI without firing change) and dispatches a 'change' event on selection,
// so `sel.value` and addEventListener('change') keep working like a <select>.
// opts: { value, placeholder, onChange, width, height, className,
//         creatable, createPlaceholder, onCreate }
// --- combobox search helpers (forgiving matching) ---------------------------
// Strip Vietnamese/Unicode diacritics + fold đ→d so "chua" matches "Chưa",
// "nhom" matches "Nhóm", etc. (users rarely type accents into a filter).
function foldText(s) {
  return String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd').replace(/Đ/g, 'd').toLowerCase();
}
// Ordered-subsequence test: every char of q appears in s in order (fuzzy).
function isSubseq(q, s) {
  let i = 0;
  for (let j = 0; j < s.length && i < q.length; j++) if (s[j] === q[i]) i++;
  return i === q.length;
}
// Filter + rank options against a query. Empty query → all. Ranking: prefix <
// substring < fuzzy subsequence, then earliest match position. Returns option objs.
function filterOptions(options, query) {
  const q = foldText(query).trim();
  if (!q) return (options || []).slice();
  const qn = q.replace(/\s+/g, '');
  const scored = [];
  (options || []).forEach((o) => {
    const s = foldText(o.label);
    const idx = s.indexOf(q);
    let score = -1;
    if (idx === 0) score = 0;
    else if (idx > 0) score = 1;
    else if (isSubseq(qn, s.replace(/\s+/g, ''))) score = 2;
    if (score >= 0) scored.push({ o, score, idx: idx < 0 ? 1e9 : idx });
  });
  scored.sort((a, b) => a.score - b.score || a.idx - b.idx);
  return scored.map((x) => x.o);
}

export function customSelect(rawOptions, opts = {}) {
  const { value = '', placeholder = '', onChange, width, height, className = '',
    creatable = false, createPlaceholder = '', onCreate, menuMinWidth } = opts;
  const options = (rawOptions || []).map((o) => (typeof o === 'string' ? { value: o, label: o } : o));
  let val = value;
  const combo = el('div.pc-select' + (className ? '.' + className : ''));
  if (width != null) combo.style.width = typeof width === 'number' ? width + 'px' : width;
  // EVERY select is a searchable combobox (AdsPower-style): the trigger is a
  // typeable input. Opening dims the selected label into the placeholder and lets
  // you type to filter the options; `creatable` additionally pins a "create" card.
  const trigger = el('div.pc-select-trigger.pc-select-trigger-search');
  if (height != null) trigger.style.height = typeof height === 'number' ? height + 'px' : height;
  const searchInput = el('input.pc-select-search.pc-i18n-val', { type: 'text', placeholder: placeholder || '' });
  // Selected option's `right` badge (e.g. locale code) - shown when closed, hidden while searching.
  const rightEl = el('span.pc-select-trigger-right');
  // Live refs for the create-card (built in renderMenu, updated by applyFilter).
  let optsBoxEl = null, createLabelEl = null, createBtnEl = null, createRowEl = null;
  // The menu is portaled to <body> with fixed positioning so it's never
  // clipped by an ancestor's overflow (modals, scrollable tables, pagers).
  const menu = el('div.pc-select-menu' + (className ? '.' + className : ''));
  let bound = false;
  const onDoc = (e) => { if (!combo.contains(e.target) && !menu.contains(e.target)) close(); };
  // Don't close when the scroll happens INSIDE the menu (long lists need to scroll);
  // only reposition-close on outer scroll/resize.
  const onReposition = (e) => { if (e && e.target && menu.contains(e.target)) return; if (combo.classList.contains('open')) close(); };
  function place() {
    const r = trigger.getBoundingClientRect();
    menu.style.position = 'fixed';
    // Bề rộng menu = bề rộng trigger, nhưng có thể nới tối thiểu `menuMinWidth` để
    // hiện đủ nhãn dài khi trigger bị bó hẹp (vd ô key trong bảng key-value). Nếu
    // menu rộng ra mà chạm mép phải cửa sổ thì dịch trái để không tràn.
    const w = menuMinWidth ? Math.max(r.width, menuMinWidth) : r.width;
    let left = r.left;
    if (left + w > window.innerWidth - 8) left = Math.max(8, window.innerWidth - w - 8);
    menu.style.left = left + 'px';
    menu.style.width = w + 'px';
    // flip upward when there isn't room below (e.g. bottom pagers)
    if ((window.innerHeight - r.bottom) < 260) {
      menu.style.top = 'auto'; menu.style.bottom = (window.innerHeight - r.top + 6) + 'px';
    } else {
      menu.style.bottom = 'auto'; menu.style.top = (r.bottom + 6) + 'px';
    }
  }
  function close() {
    combo.classList.remove('open'); menu.classList.remove('open');
    if (menu.parentNode) menu.parentNode.removeChild(menu);
    if (bound) {
      document.removeEventListener('mousedown', onDoc);
      window.removeEventListener('scroll', onReposition, true);
      window.removeEventListener('resize', onReposition);
      bound = false;
    }
    searchInput.placeholder = t(placeholder || '');
    renderTrigger();   // restore the selected label in the input
  }
  function open() {
    searchInput.value = '';                          // clear so the user can type to filter
    const o = optFor(val);
    searchInput.placeholder = t(o ? o.label : (placeholder || ''));   // "làm mờ" the selected item
    rightEl.style.display = 'none';                  // hide the badge while searching
    renderMenu();
    document.body.appendChild(menu);
    combo.classList.add('open'); menu.classList.add('open');
    place();
    document.addEventListener('mousedown', onDoc);
    window.addEventListener('scroll', onReposition, true);
    window.addEventListener('resize', onReposition);
    bound = true;
    setTimeout(() => { try { searchInput.focus(); } catch (_) {} }, 0);
  }
  // Badge `right` được ghép vào innerHTML, mà nội dung có thể là ký hiệu toán tử
  // (`<`, `>=`) - không thoát thì trình duyệt hiểu thành thẻ. Escape trước khi ghép.
  const escRight = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const optFor = (v) => options.find((x) => x.value === v);
  const labelFor = (v) => { const o = optFor(v); return o ? o.label : (placeholder || ''); };
  function renderTrigger() {
    const o = optFor(val);
    searchInput.value = o ? o.label : '';
    if (o && o.right) { rightEl.innerHTML = `<span class="code">${escRight(o.right)}</span>`; rightEl.style.display = ''; }
    else { rightEl.innerHTML = ''; rightEl.style.display = 'none'; }
    applyI18n(combo);   // translate the selected label (input.value) after a language switch
  }
  const optBtn = (o) => {
    const right = o.right ? `<span class="code">${escRight(o.right)}</span>` : '';
    return el('button.pc-select-opt' + (o.value === val ? '.sel' : ''), {
      type: 'button',
      html: `<span class="lbl">${o.label}</span>${right}`,
      onclick: () => { setValue(o.value, true); close(); },
    });
  };
  // Creatable combobox (AdsPower group picker): a "create" card pinned to the top
  // that mirrors what's typed in the trigger (⊕ <text> + "Tạo ↵"), then the option
  // list which the trigger live-filters; "Không có dữ liệu" when nothing matches.
  function applyFilter(text) {
    const t = (text || '').trim();
    if (creatable) {
      const dup = !!t && options.some((o) => (o.label || '').trim().toLowerCase() === t.toLowerCase());
      if (createLabelEl) { createLabelEl.textContent = t || createPlaceholder; createLabelEl.classList.toggle('ph', !t); }
      if (createBtnEl) createBtnEl.disabled = !t || dup;
      if (createRowEl) createRowEl.classList.toggle('disabled', !t || dup);
    }
    if (!optsBoxEl) return;
    clear(optsBoxEl);
    const list = filterOptions(options, t);
    if (!list.length) { optsBoxEl.appendChild(el('div.pc-select-empty', { text: 'Không có dữ liệu' })); return; }
    list.forEach((o) => optsBoxEl.appendChild(optBtn(o)));
  }
  function doCreate() {
    const name = (searchInput ? searchInput.value : '').trim();
    if (!name) return;
    if (options.some((o) => (o.label || '').trim().toLowerCase() === name.toLowerCase())) return;  // không tạo nhóm trùng
    let opt = onCreate ? onCreate(name) : { value: name, label: name };
    if (opt == null) return;                                    // caller rejected
    if (typeof opt === 'string') opt = { value: opt, label: opt };
    if (!options.some((o) => o.value === opt.value)) options.push(opt);
    setValue(opt.value, true);
    close();
  }
  function renderMenu() {
    clear(menu);
    optsBoxEl = el('div.pc-select-opts');
    if (creatable) {
      createLabelEl = el('span.pc-create-label');
      createBtnEl = el('button.pc-create-btn', { type: 'button', html: 'Tạo <kbd>↵</kbd>',
        onmousedown: (e) => e.preventDefault(), onclick: (e) => { e.stopPropagation(); doCreate(); } });
      createRowEl = el('div.pc-select-create', { onmousedown: (e) => e.preventDefault(), onclick: doCreate }, [
        el('span.pc-create-ico', { html: icon('plusCircleFill') }),
        createLabelEl,
        createBtnEl,
      ]);
      menu.appendChild(createRowEl);
    }
    menu.appendChild(optsBoxEl);
    applyFilter(searchInput.value);
  }
  function setValue(v, fire) {
    val = v; renderTrigger();
    if (fire) { combo.dispatchEvent(new Event('change')); if (onChange) onChange(val); }
  }
  const chev = el('span.chev', { html: icon('chevronDown') });
  trigger.appendChild(searchInput);
  trigger.appendChild(rightEl);
  trigger.appendChild(chev);
  searchInput.addEventListener('focus', () => { if (!combo.classList.contains('open')) open(); });
  searchInput.addEventListener('input', () => applyFilter(searchInput.value));
  searchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      if (creatable) { doCreate(); return; }
      // plain select: Enter picks the best-ranked filtered option
      const list = filterOptions(options, searchInput.value);
      if (list.length) { setValue(list[0].value, true); close(); }
    } else if (e.key === 'Escape') { close(); searchInput.blur(); }
  });
  chev.addEventListener('mousedown', (e) => {
    e.preventDefault();
    if (combo.classList.contains('open')) close(); else searchInput.focus();
  });
  combo.appendChild(trigger); combo.appendChild(menu);
  Object.defineProperty(combo, 'value', { get: () => val, set: (v) => setValue(v, false), configurable: true });
  // Thay CẢ danh sách lựa chọn tại chỗ (vd ô "User-Agent" đổi từ major Chrome sang major
  // Firefox khi người dùng đổi nhân). PHẢI sửa mảng `options` TẠI CHỖ chứ không gán mảng
  // mới: filterOptions/renderMenu/setValue đều đã "chụp" đúng tham chiếu này trong closure.
  // Không fire onChange (đây là thay đổi do chương trình, không phải người dùng chọn).
  combo.setOptions = (raw, nextValue) => {
    const mapped = (raw || []).map((o) => (typeof o === 'string' ? { value: o, label: o } : o));
    options.length = 0;
    for (const o of mapped) options.push(o);
    if (nextValue !== undefined) val = nextValue;
    else if (val && !options.some((o) => o.value === val)) val = ''; // giá trị cũ không còn hợp lệ
    searchInput.value = '';
    renderMenu(); renderTrigger();
  };
  renderTrigger();
  return combo;
}

// Ô "số dòng mỗi trang" cho pager (dùng chung TOÀN dự án). Khác customSelect: đây là TEXTBOX
// gõ được - nhập số bất kỳ để đặt số dòng/trang tùy ý (không phải để lọc). Bấm vào ô mở dropdown
// các mốc sẵn (vd 10/25/50/100). Hậu tố CỐ ĐỊNH "/trang" luôn hiển thị bên phải số.
//   pageSizeSelect([10,25,50,100], { value, onChange })  →  onChange(nSốNguyên)
export function pageSizeSelect(sizes, opts = {}) {
  const { value, onChange, width } = opts;
  const list = (sizes && sizes.length ? sizes : [10, 25, 50, 100]).map((n) => parseInt(n, 10)).filter((n) => n > 0);
  let val = Math.max(1, parseInt(value, 10) || list[0] || 10);

  const wrap = el('div.pagesize');
  if (width != null) wrap.style.width = typeof width === 'number' ? width + 'px' : width;
  const input = el('input.pagesize-input', { type: 'text', inputmode: 'numeric' });
  const suffix = el('span.pagesize-suffix', { text: '/' + t('trang') });
  input.value = String(val);
  wrap.appendChild(input); wrap.appendChild(suffix);

  const menu = el('div.pagesize-menu');
  let open = false;
  const onDoc = (e) => { if (!wrap.contains(e.target) && !menu.contains(e.target)) closeMenu(); };
  function place() {
    const r = wrap.getBoundingClientRect();
    menu.style.position = 'fixed';
    menu.style.left = r.left + 'px';
    menu.style.minWidth = r.width + 'px';
    // Pager nằm cuối trang → thường bung LÊN TRÊN nếu thiếu chỗ bên dưới.
    if ((window.innerHeight - r.bottom) < 220) { menu.style.top = 'auto'; menu.style.bottom = (window.innerHeight - r.top + 6) + 'px'; }
    else { menu.style.bottom = 'auto'; menu.style.top = (r.bottom + 6) + 'px'; }
  }
  function renderMenu() {
    clear(menu);
    list.forEach((n) => menu.appendChild(el('div.pagesize-opt' + (n === val ? '.active' : ''), {
      text: String(n),
      onmousedown: (e) => { e.preventDefault(); commit(n); closeMenu(); input.blur(); },
    })));
  }
  function openMenu() {
    if (open) return; open = true;
    renderMenu(); document.body.appendChild(menu); wrap.classList.add('open'); place();
    document.addEventListener('mousedown', onDoc);
    window.addEventListener('scroll', place, true);
    window.addEventListener('resize', place);
  }
  function closeMenu() {
    if (!open) return; open = false;
    if (menu.parentNode) menu.parentNode.removeChild(menu); wrap.classList.remove('open');
    document.removeEventListener('mousedown', onDoc);
    window.removeEventListener('scroll', place, true);
    window.removeEventListener('resize', place);
  }
  // Gán giá trị + phát onChange (idempotent: chỉ báo khi giá trị đổi thật → tránh double-fire
  // giữa mousedown-chọn-item và blur commit).
  function commit(n) {
    const v = Math.max(1, parseInt(n, 10) || val);
    input.value = String(v);
    if (v === val) return;
    val = v;
    if (onChange) onChange(v);
  }
  input.addEventListener('focus', openMenu);
  input.addEventListener('click', openMenu);
  input.addEventListener('input', () => { const c = input.value.replace(/[^0-9]/g, ''); if (c !== input.value) input.value = c; });
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); commit(input.value); closeMenu(); input.blur(); }
    else if (e.key === 'Escape') { input.value = String(val); closeMenu(); input.blur(); }
  });
  input.addEventListener('blur', () => { setTimeout(() => { commit(input.value); closeMenu(); }, 120); });
  // Bấm vào BẤT KỲ đâu trong ô (kể cả hậu tố "/trang" / phần đệm) → focus + mở dropdown.
  wrap.addEventListener('mousedown', (e) => { if (e.target === input) return; e.preventDefault(); input.focus(); openMenu(); });

  wrap.setValue = (v) => { val = Math.max(1, parseInt(v, 10) || val); input.value = String(val); };
  Object.defineProperty(wrap, 'value', { get: () => val, set: (v) => wrap.setValue(v), configurable: true });
  return wrap;
}

// ----------------------------------------------------------------- toast
// Custom date / time picker (shared by the Automation modal + the Lên lịch dialog).
// Replaces the un-styleable native <input type=datetime-local> with a wide trigger +
// a portaled panel (custom calendar grid + time spinners). `mode` = 'datetime' | 'time'.
// onChange receives the same string the native inputs emitted:
//   datetime → 'YYYY-MM-DDTHH:MM'   ·   time → 'HH:MM'
export function customDateTime({ value = '', mode = 'datetime', placeholder, onChange } = {}) {
  const pad = (n) => String(n).padStart(2, '0');
  const now = new Date();
  const WD = ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'];
  const parse = (v) => {
    if (!v) return null;
    if (mode === 'time') { const m = /^(\d{1,2}):(\d{2})$/.exec(v); if (!m) return null; const d = new Date(); d.setHours(+m[1], +m[2], 0, 0); return d; }
    const d = new Date(v); return isNaN(d.getTime()) ? null : d;
  };
  let sel = parse(value);
  let viewY = (sel || now).getFullYear();
  let viewM = (sel || now).getMonth();
  let hh = sel ? sel.getHours() : 0;
  let mm = sel ? sel.getMinutes() : 0;

  const fmt = () => {
    if (!sel) return '';
    if (mode === 'time') return pad(sel.getHours()) + ':' + pad(sel.getMinutes());
    return `${pad(sel.getDate())}/${pad(sel.getMonth() + 1)}/${sel.getFullYear()}  ${pad(sel.getHours())}:${pad(sel.getMinutes())}`;
  };
  const outVal = () => {
    if (!sel) return '';
    if (mode === 'time') return pad(sel.getHours()) + ':' + pad(sel.getMinutes());
    return `${sel.getFullYear()}-${pad(sel.getMonth() + 1)}-${pad(sel.getDate())}T${pad(sel.getHours())}:${pad(sel.getMinutes())}`;
  };
  const commit = () => { if (onChange) onChange(outVal()); };

  const valEl = el('span.dtp-val');
  const renderVal = () => {
    const t = fmt();
    valEl.textContent = t || (placeholder || (mode === 'time' ? 'Chọn giờ' : 'Chọn thời gian'));
    valEl.classList.toggle('ph', !t);
  };
  const CAL_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M0 0h24v24H0z" fill="none"/><path fill="currentColor" d="M6.94 2c.416 0 .753.324.753.724v1.46c.668-.012 1.417-.012 2.26-.012h4.015c.842 0 1.591 0 2.259.013v-1.46c0-.4.337-.725.753-.725s.753.324.753.724V4.25c1.445.111 2.394.384 3.09 1.055c.698.67.982 1.582 1.097 2.972L22 9H2v-.724c.116-1.39.4-2.302 1.097-2.972s1.645-.944 3.09-1.055V2.724c0-.4.337-.724.753-.724"/><path fill="currentColor" d="M22 14v-2c0-.839-.004-2.335-.017-3H2.01c-.013.665-.01 2.161-.01 3v2c0 3.771 0 5.657 1.172 6.828S6.228 22 10 22h4c3.77 0 5.656 0 6.828-1.172S22 17.772 22 14" opacity=".5"/><path fill="currentColor" d="M18 17a1 1 0 1 1-2 0a1 1 0 0 1 2 0m0-4a1 1 0 1 1-2 0a1 1 0 0 1 2 0m-5 4a1 1 0 1 1-2 0a1 1 0 0 1 2 0m0-4a1 1 0 1 1-2 0a1 1 0 0 1 2 0m-5 4a1 1 0 1 1-2 0a1 1 0 0 1 2 0m0-4a1 1 0 1 1-2 0a1 1 0 0 1 2 0"/></svg>';
  const trigger = el('button.dtp-trigger' + (mode === 'time' ? '.is-time' : ''), { type: 'button' }, [
    valEl, el('span.dtp-ico', { html: mode === 'time' ? icon('clock') : CAL_SVG }),
  ]);
  const wrap = el('div.dtp', {}, [trigger]);
  const panel = el('div.dtp-panel' + (mode === 'time' ? '.is-time' : ''));

  const syncSel = () => { if (sel) sel.setHours(hh, mm, 0, 0); else sel = new Date(viewY, viewM, now.getDate(), hh, mm, 0, 0); };
  const spinner = (which) => {
    const cur = which === 'h' ? hh : mm;
    const max = which === 'h' ? 23 : 59;
    const inp = el('input.dtp-num', { type: 'number', min: '0', max: String(max), value: pad(cur) });
    inp.addEventListener('input', () => {
      let v = parseInt(inp.value, 10); if (isNaN(v)) return;
      v = Math.max(0, Math.min(max, v));
      if (which === 'h') hh = v; else mm = v;
      syncSel(); renderVal(); commit();
    });
    inp.addEventListener('blur', () => { inp.value = pad(which === 'h' ? hh : mm); });
    return inp;
  };

  function buildPanel() {
    clear(panel);
    if (mode !== 'time') {
      const title = el('div.dtp-title', { text: tf('Tháng {0}, {1}', viewM + 1, viewY) });
      const prev = el('button.dtp-nav', { type: 'button', html: icon('chevron'), title: 'Tháng trước', onclick: () => { viewM--; if (viewM < 0) { viewM = 11; viewY--; } buildPanel(); } });
      const next = el('button.dtp-nav', { type: 'button', html: icon('chevron'), title: 'Tháng sau', onclick: () => { viewM++; if (viewM > 11) { viewM = 0; viewY++; } buildPanel(); } });
      prev.classList.add('prev');
      panel.appendChild(el('div.dtp-head', {}, [prev, title, next]));
      panel.appendChild(el('div.dtp-wd', {}, WD.map((w) => el('span', { text: w }))));

      const grid = el('div.dtp-grid');
      const startDow = (new Date(viewY, viewM, 1).getDay() + 6) % 7; // Monday-based
      const daysInMonth = new Date(viewY, viewM + 1, 0).getDate();
      const prevDays = new Date(viewY, viewM, 0).getDate();
      for (let i = 0; i < 42; i++) {
        let dayNum, cellY = viewY, cellM = viewM, other = false;
        if (i < startDow) { dayNum = prevDays - startDow + 1 + i; other = true; cellM = viewM - 1; if (cellM < 0) { cellM = 11; cellY--; } }
        else if (i >= startDow + daysInMonth) { dayNum = i - startDow - daysInMonth + 1; other = true; cellM = viewM + 1; if (cellM > 11) { cellM = 0; cellY++; } }
        else dayNum = i - startDow + 1;
        const isSel = sel && sel.getFullYear() === cellY && sel.getMonth() === cellM && sel.getDate() === dayNum;
        const isToday = now.getFullYear() === cellY && now.getMonth() === cellM && now.getDate() === dayNum;
        grid.appendChild(el('button.dtp-day' + (other ? '.other' : '') + (isSel ? '.sel' : '') + (isToday ? '.today' : ''), {
          type: 'button', text: String(dayNum),
          onclick: () => { sel = new Date(cellY, cellM, dayNum, hh, mm, 0, 0); viewY = cellY; viewM = cellM; renderVal(); commit(); if (mode === 'datetime') buildPanel(); else close(); },
        }));
      }
      panel.appendChild(grid);
    }
    if (mode === 'datetime' || mode === 'time') {
      panel.appendChild(el('div.dtp-time', {}, [
        el('span.dtp-time-ico', { html: icon('clock') }),
        spinner('h'), el('span.dtp-colon', { text: ':' }), spinner('m'),
        el('span.dtp-spacer'),
        el('button.dtp-now', { type: 'button', text: 'Bây giờ', onclick: () => { const d = new Date(); sel = new Date(d.getFullYear(), d.getMonth(), d.getDate(), d.getHours(), d.getMinutes(), 0, 0); hh = sel.getHours(); mm = sel.getMinutes(); viewY = sel.getFullYear(); viewM = sel.getMonth(); buildPanel(); renderVal(); commit(); } }),
        el('button.dtp-done', { type: 'button', text: 'Xong', onclick: () => { syncSel(); renderVal(); commit(); close(); } }),
      ]));
    }
  }

  let bound = false;
  const onDoc = (e) => { if (!wrap.contains(e.target) && !panel.contains(e.target)) close(); };
  const onReposition = (e) => { if (e && e.target && panel.contains(e.target)) return; if (wrap.classList.contains('open')) close(); };
  function place() {
    const r = trigger.getBoundingClientRect();
    panel.style.position = 'fixed';
    panel.style.left = r.left + 'px';
    panel.style.minWidth = r.width + 'px';
    if ((window.innerHeight - r.bottom) < 360) { panel.style.top = 'auto'; panel.style.bottom = (window.innerHeight - r.top + 6) + 'px'; }
    else { panel.style.bottom = 'auto'; panel.style.top = (r.bottom + 6) + 'px'; }
  }
  function open() {
    buildPanel();
    document.body.appendChild(panel);
    wrap.classList.add('open'); panel.classList.add('open');
    place();
    document.addEventListener('mousedown', onDoc);
    window.addEventListener('scroll', onReposition, true);
    window.addEventListener('resize', onReposition);
    bound = true;
  }
  function close() {
    wrap.classList.remove('open'); panel.classList.remove('open');
    if (panel.parentNode) panel.parentNode.removeChild(panel);
    if (bound) { document.removeEventListener('mousedown', onDoc); window.removeEventListener('scroll', onReposition, true); window.removeEventListener('resize', onReposition); bound = false; }
  }
  trigger.addEventListener('click', () => { if (wrap.classList.contains('open')) close(); else open(); });

  renderVal();
  return wrap;
}

// Per-state glyph: success → check (green), error → close (red),
// warn → warning triangle (orange), default → info (brand blue).
const TOAST_ICON = { ok: 'toastOk', err: 'toastErr', error: 'toastErr', warn: 'toastErr' };
function dismissToast(t) {
  if (!t || t._dismissed) return;
  t._dismissed = true;
  clearTimeout(t._timer);
  t.classList.add('leaving');
  setTimeout(() => t.remove(), 260);
}
// Câu lỗi PHIÊN CHẾT trả về từ các lệnh gọi dở dang (api-client SESSION_EXPIRED_MSG + câu 401 cũ của server): không hiện
// thành toast - app.js đã đưa về màn đăng nhập kèm MỘT thông báo riêng.
// So CHUỖI CON: notifyError hay ghép 'Tải … thất bại: <câu server>'.
const SESSION_DEAD_MSGS = ['Phiên đăng nhập đã hết hạn', 'Token không hợp lệ hoặc đã hết hạn'];
export function toast(message, kind = '') {
  if (SESSION_DEAD_MSGS.some((m) => String(message || '').includes(m))) return;
  const host = document.getElementById('toasts');
  const t = el('div.toast' + (kind ? '.' + kind : ''), {}, [
    el('span.toast-ico', { html: icon(TOAST_ICON[kind] || 'toastInfo') }),
    el('span.toast-msg', { text: message }),
    el('button.toast-x', { html: icon('close'), title: 'Đóng', onclick: () => dismissToast(t) }),
  ]);
  host.appendChild(t);
  t._timer = setTimeout(() => dismissToast(t), 3200);
}

// --------------------------------------------------------------- tooltip
// One themed tooltip shared by the whole app. It hijacks any element carrying a
// `title` attribute: the native title is moved to `data-tip` (so the OS tooltip
// never appears) and our styled pill is shown instead. This keeps every tooltip
// - sidebar, icon buttons, action cells - visually identical.
let tipEl = null;
let tipTimer = null;     // show delay
let hideTimer = null;    // hide delay - lets the cursor cross into an interactive tip
let tipTarget = null;
// Elements registered with an interactive ("rich") tooltip: a builder returning an
// HTMLElement to render INSIDE the shared tooltip. When the builder returns null the
// tooltip falls back to the element's plain data-tip text. This keeps ONE shared
// tooltip for the whole app (no bespoke per-feature tooltips) while still allowing
// styled, clickable content (e.g. the RPA "Chọn lại" link).
const richTips = new WeakMap();
export function setRichTooltip(target, build) {
  if (build) richTips.set(target, build); else richTips.delete(target);
}

function tipNode() {
  if (!tipEl) {
    tipEl = el('div.app-tooltip'); tipEl.style.display = 'none';
    // Keep an interactive tip open while the cursor is over it.
    tipEl.addEventListener('mouseenter', () => { if (hideTimer) { clearTimeout(hideTimer); hideTimer = null; } });
    tipEl.addEventListener('mouseleave', scheduleHideTooltip);
    document.body.appendChild(tipEl);
  }
  return tipEl;
}

function showTooltip(target) {
  const tip = tipNode();
  const build = richTips.get(target);
  const content = build ? build() : null;
  if (content) { tip.classList.add('rich'); clear(tip); tip.appendChild(content); }
  else {
    const text = target.getAttribute('data-tip');
    if (!text) return;
    tip.classList.remove('rich'); tip.textContent = text;
  }
  tip.style.display = 'block';
  const r = target.getBoundingClientRect();
  const tw = tip.offsetWidth, th = tip.offsetHeight;
  // Opt-in: phần tử (hoặc tổ tiên) mang [data-tip-place="top"] LUÔN hiện tooltip bên trên.
  const forceTop = target.closest && target.closest('[data-tip-place="top"]');
  let placeAbove = !!forceTop;
  let top = placeAbove ? r.top - th - 8 : r.bottom + 8;
  if (!forceTop && top + th > window.innerHeight - 8) { top = r.top - th - 8; placeAbove = true; } // flip above when no room below
  let left = r.left + r.width / 2 - tw / 2;                        // center on the target
  left = Math.max(8, Math.min(left, window.innerWidth - tw - 8));  // clamp inside viewport
  tip.style.left = left + 'px';
  tip.style.top = Math.max(8, top) + 'px';
  // Mũi nhọn: class chỉ hướng (trên/dưới phần tử) + toạ độ NGANG = tâm phần tử so với mép
  // trái tooltip, kẹp trong [12, tw-12] để mũi nhọn không lọt khỏi thân tooltip.
  tip.classList.remove('tip-top', 'tip-bottom');
  tip.classList.add(placeAbove ? 'tip-top' : 'tip-bottom');
  const arrowX = Math.max(12, Math.min(tw - 12, r.left + r.width / 2 - left));
  tip.style.setProperty('--tip-arrow-x', arrowX + 'px');
}

function scheduleHideTooltip() { if (hideTimer) clearTimeout(hideTimer); hideTimer = setTimeout(hideTooltip, 160); }

export function hideTooltip() {
  if (tipTimer) { clearTimeout(tipTimer); tipTimer = null; }
  if (hideTimer) { clearTimeout(hideTimer); hideTimer = null; }
  if (tipEl) { tipEl.style.display = 'none'; tipEl.classList.remove('rich', 'tip-top', 'tip-bottom'); }
  tipTarget = null;
}

// Install once (from app boot). Uses event delegation so it covers every
// element rendered now or later, with no per-call-site changes.
export function installTooltips() {
  document.addEventListener('mouseover', (e) => {
    const node = e.target.closest && e.target.closest('[title], [data-tip]');
    if (!node || node === tipTarget) return;
    // Move the native title → data-tip once so the OS tooltip is suppressed.
    if (node.hasAttribute('title')) {
      const t = node.getAttribute('title');
      node.removeAttribute('title');
      if (t) node.setAttribute('data-tip', t);
    }
    if (!node.getAttribute('data-tip') && !richTips.has(node)) return;
    if (hideTimer) { clearTimeout(hideTimer); hideTimer = null; }
    tipTarget = node;
    if (tipTimer) clearTimeout(tipTimer);
    // data-tip-instant: hiện ngay không chờ (thẻ gói ở trang Nâng cấp gói, chủ sở hữu 2026-11-12).
    tipTimer = setTimeout(() => showTooltip(node), node.hasAttribute('data-tip-instant') ? 0 : 280);
  }, true);

  document.addEventListener('mouseout', (e) => {
    if (!tipTarget) return;
    const to = e.relatedTarget;
    // Stay open while moving within the target OR into the (interactive) tooltip.
    if (to && (tipTarget === to || tipTarget.contains(to) || (tipEl && tipEl.contains(to)))) return;
    scheduleHideTooltip();   // delayed so the cursor can cross the gap into a rich tip
  }, true);

  // A click inside an interactive tooltip (e.g. "Chọn lại") must NOT dismiss it
  // before the handler runs; clicks anywhere else hide the tooltip as before.
  document.addEventListener('mousedown', (e) => { if (tipEl && tipEl.contains(e.target)) return; hideTooltip(); }, true);
  window.addEventListener('scroll', hideTooltip, true);
}

// ----------------------------------------------------------------- modal
// Every modal in the app shares one footprint (660px, no header icon) so the
// surface feels consistent. `width` can still be overridden per-call if needed,
// but call sites are expected to inherit the default. `iconName`/`iconColor`
// are accepted for backwards compatibility but no longer rendered.
export function openModal({ title, sub, body, footer, width = 660 }) {
  const host = document.getElementById('modal-host');
  clear(host);
  const headChildren = [];
  headChildren.push(el('div', {}, [
    el('h3', { text: title || '' }),
    sub ? el('div.sub', { text: sub }) : null,
  ]));
  const closeBtn = iconBtn('close', { class: 'icon-btn x', onclick: closeModal });
  headChildren.push(closeBtn);

  const modal = el('div.modal', { style: { width: width + 'px' } }, [
    el('div.modal-head', {}, headChildren),
    el('div.modal-body', {}, body || []),
    footer ? el('div.modal-foot', {}, footer) : null,
  ]);
  const scrim = el('div.scrim', { onclick: closeModal });
  host.appendChild(scrim);
  host.appendChild(modal);
  host.classList.add('open');
  return { close: closeModal, modal };
}

export function closeModal() {
  const host = document.getElementById('modal-host');
  host.classList.remove('open');
  clear(host);
}

// ------------------------------------------------------- upgrade / upsell modal
// Shown when a free-plan workspace hits a feature that requires a paid plan.
// Layout mirrors the familiar antidetect upsell: a full-bleed illustration band
// on top (with the close X floating over it), a centered bold blue title, and a
// single centered CTA button carrying the app's signature 3-colour gradient. The
// illustration is an ORIGINAL inline SVG (rocket + upward chart on a light-blue
// band) so we don't copy any third-party artwork. The host is centred vertically
// (`.upgrade-open`) instead of the usual top-anchored modal position.
export function openUpgradeModal({
  title = 'Bạn cần nâng cấp gói để sử dụng tính năng',
  buttonText = 'Nâng cấp ngay bây giờ',
  onUpgrade,
} = {}) {
  const host = document.getElementById('modal-host');
  clear(host);

  // Minh hoạ: 'happy banker jumping coins' (chủ sở hữu 2026-10-30). Bản gốc EPS 6000×5000 + JPG kèm theo; máy không có
  // công cụ đổi EPS nên dựng từ JPG: bỏ nền hồng (loang từ mép, mép mềm) ⇒ WebP nền trong suốt 536×460 (= 2× khung hiển thị).
  const illust = el('div.upgrade-illust', {}, [
    el('img.upgrade-illust-img', { src: 'assets/upgrade-banker.webp', alt: '', draggable: 'false' }),
  ]);
  const closeBtn = iconBtn('close', { class: 'icon-btn x upgrade-x', onclick: closeUpgradeModal });

  const btn = el('button.upgrade-btn', {
    onclick: () => { closeUpgradeModal(); if (typeof onUpgrade === 'function') onUpgrade(); },
  }, [el('span', { text: buttonText })]);

  const modal = el('div.modal.upgrade-modal', { style: { width: '560px' } }, [
    el('div.upgrade-illust-wrap', {}, [illust, closeBtn]),
    el('div.upgrade-body', {}, [
      el('div.upgrade-title', { text: title }),
      btn,
    ]),
  ]);
  const scrim = el('div.scrim', { onclick: closeUpgradeModal });
  host.appendChild(scrim);
  host.appendChild(modal);
  host.classList.add('open', 'upgrade-open');
  return { close: closeUpgradeModal, modal };
}

// Đóng modal nâng cấp (bỏ luôn lớp căn-giữa .upgrade-open riêng của nó).
export function closeUpgradeModal() {
  const host = document.getElementById('modal-host');
  host.classList.remove('upgrade-open');
  closeModal();
}

// ----------------------------------------------------------------- menu
// The single outside-click "dismiss" listener for the currently-open menu. We
// track it module-wide so it is ALWAYS removed when the menu closes - no matter
// how it closed (item click, hover-out, another menu opening). A leaked listener
// from a previous menu would otherwise fire on the next menu's mousedown and tear
// it down before the click registered (broke hover-menu item clicks).
let _menuOff = null;
function clearMenuOff() {
  if (_menuOff) { document.removeEventListener('mousedown', _menuOff); _menuOff = null; }
}

export function openMenu(anchorEl, items) {
  const host = document.getElementById('menu-host');
  clearMenuOff();
  clear(host);

  // A single row button. Leaf rows fire onClick; rows with a `submenu` show a
  // ">" caret and reveal a nested flyout on hover (handled purely in CSS).
  const makeButton = (it) => {
    const hasSub = Array.isArray(it.submenu);
    const b = el('button' + (it.danger ? '.danger' : '') + (it.disabled ? '.is-locked' : ''), {
      html: (it.icon ? icon(it.icon) : '')
        + `<span>${it.label}</span>`
        + (hasSub ? `<span class="menu-caret">${icon('chevron')}</span>` : ''),
    });
    if (it.title) b.title = it.title;
    if (it.disabled) {
      // Khóa mềm: mục vẫn hiện + tooltip báo thiếu quyền, click không thực thi
      // gì và KHÔNG đóng menu (khác hẳn "hide"). Server vẫn enforce thật.
      b.onclick = (e) => { e.stopPropagation(); };
    } else if (!hasSub) {
      b.onclick = (e) => { e.stopPropagation(); closeMenu(); it.onClick && it.onClick(); };
    }
    return b;
  };

  const buildMenu = (list) => {
    const menu = el('div.menu');
    for (const it of list) {
      if (it === '-') { menu.appendChild(el('div.sep')); continue; }
      if (Array.isArray(it.submenu)) {
        const row = el('div.menu-row', {}, [makeButton(it)]);
        const sub = buildMenu(it.submenu);
        sub.classList.add('submenu');
        row.appendChild(sub);
        menu.appendChild(row);
      } else {
        menu.appendChild(makeButton(it));
      }
    }
    return menu;
  };

  const menu = buildMenu(items);
  host.appendChild(menu);
  const r = anchorEl.getBoundingClientRect();
  menu.style.position = 'fixed';
  menu.style.top = Math.min(r.bottom + 4, window.innerHeight - menu.offsetHeight - 10) + 'px';
  menu.style.left = Math.min(r.left, window.innerWidth - menu.offsetWidth - 10) + 'px';
  const off = (e) => { if (!menu.contains(e.target)) closeMenu(); };
  _menuOff = off;
  setTimeout(() => { if (_menuOff === off) document.addEventListener('mousedown', off); }, 0);
  return menu;
}

// Open a dropdown menu on HOVER instead of click - used by the "3-dot" (kebab)
// buttons inside datagrid row cells and by the split buttons on the selection bar
// ("Reset proxy", "Thêm"). `itemsProvider` is an items array or a function returning
// one (so the menu reflects fresh state each open). Clicking still opens it too. The
// menu auto-closes shortly after the pointer leaves both the button and the menu.
export function hoverMenu(btn, itemsProvider) {
  const resolve = () => (typeof itemsProvider === 'function' ? itemsProvider() : itemsProvider);
  // Nút đang KHÓA MỀM (thiếu quyền / hết hạn) hoặc `disabled` thì KHÔNG mở dropdown.
  // Bắt buộc phải có chốt này: khóa mềm (gateBtn trong views/profiles.js) chỉ THAY
  // `btn.onclick` bằng toast nhắc quyền, nó không hề chạm tới listener hover/click do
  // hàm này gắn - thiếu chốt thì nút đã mờ vẫn bung menu ra cho bấm.
  const locked = () => btn.disabled || btn.classList.contains('is-locked');
  let menu = null;
  let timer = null;
  const isOpen = () => menu && menu.isConnected;
  const clearT = () => { if (timer) { clearTimeout(timer); timer = null; } };
  const close = () => { clearT(); closeMenu(); menu = null; };
  const schedule = () => { clearT(); timer = setTimeout(close, 200); };
  const open = () => {
    clearT();
    menu = openMenu(btn, resolve());
    menu.addEventListener('mouseenter', clearT);
    menu.addEventListener('mouseleave', schedule);
  };
  btn.addEventListener('mouseenter', () => { clearT(); if (!locked() && !isOpen()) open(); });
  btn.addEventListener('mouseleave', schedule);
  btn.addEventListener('click', (e) => { e.stopPropagation(); if (!locked() && !isOpen()) open(); });
  return btn;
}

export function closeMenu() { clearMenuOff(); clear(document.getElementById('menu-host')); }

// confirm dialog built on modal
export function confirmDialog({ title, message, danger, confirmLabel = 'Đồng ý', onConfirm }) {
  openModal({
    title,
    body: [el('div', { text: message })],
    footer: [
      el('button.btn', { text: 'Hủy', onclick: closeModal }),
      el('button.btn' + (danger ? '.solid-red' : '.primary'), { text: confirmLabel, onclick: () => { closeModal(); onConfirm && onConfirm(); } }),
    ],
  });
}

// Hộp thoại "rời trang khi CHƯA LƯU" - dùng chung cho mọi trang có form/đồ thị đang
// sửa (quy trình RPA, hồ sơ…). Trả về Promise<'save' | 'discard' | 'stay'>; bên gọi tự
// quyết định lưu thế nào, ui.js không cần biết dữ liệu của trang.
//
// KHÔNG dùng confirmDialog được: cần badge cảnh báo, dòng phụ, và BA lối ra chứ không
// phải hai - gộp "bỏ thay đổi" với "ở lại" là làm mất việc của người dùng.
//
// Mọi lối đóng modal (nút X, nền mờ) đều PHẢI resolve, nếu không cú điều hướng đang
// await sẽ treo vĩnh viễn và kẹt cứng toàn bộ thanh bên.
export function confirmUnsavedDialog({ title, message, sub, discardLabel, saveLabel } = {}) {
  return new Promise((resolve) => {
    let done = false;
    const finish = (action) => { if (done) return; done = true; closeModal(); resolve(action); };
    const { modal } = openModal({
      title: title || t('Xác nhận thoát'),
      width: 560,
      // Hai dòng nằm chung MỘT thẻ bọc: .modal-body là flex column gap 12px, tách rời
      // thì dòng phụ bị đẩy xa khỏi câu hỏi mà nó đang giải thích.
      body: [el('div', {}, [
        el('div', { text: message }),
        sub ? el('div.muted', { text: sub, style: { marginTop: '6px', fontSize: '12.5px' } }) : null,
      ].filter(Boolean))],
      footer: [
        el('button.btn', { text: discardLabel || t('OK'), onclick: () => finish('discard') }),
        el('button.btn.primary', { text: saveLabel || t('Lưu và thoát'), onclick: () => finish('save') }),
      ],
    });
    // Badge cảnh báo tròn màu hổ phách cạnh tiêu đề - dùng lại mẫu của hộp thoại xoá
    // nhóm (CSS .grp-del-badge có sẵn), không thêm CSS mới.
    const head = modal.querySelector('.modal-head > div');
    if (head) head.insertBefore(el('span.grp-del-badge', { html: icon('warning') }), head.firstChild);
    // openModal gắn closeModal cho nền mờ + nút X bằng addEventListener và không giữ
    // tham chiếu nên không gỡ ra được → nhân bản node để bỏ listener cũ rồi gắn lại.
    const host = document.getElementById('modal-host');
    [host && host.querySelector('.scrim'), modal.querySelector('.icon-btn.x')].forEach((node) => {
      if (!node || !node.parentNode) return;
      const fresh = node.cloneNode(true);
      node.parentNode.replaceChild(fresh, node);
      fresh.addEventListener('click', () => finish('stay'));
    });
  });
}

// ─── URL trong câu thông báo → LINK BẤM ĐƯỢC ────────────────────────────────────────────
// Nhiều thông báo lỗi có kèm địa chỉ web là LỐI THOÁT của người dùng (rõ nhất: hết giới hạn
// thiết bị → "đăng nhập vào https://cgtdev.space/ để mua thêm/gỡ bớt thiết bị"). In ra dạng
// chữ thường thì khách phải tự bôi-đen-copy-dán, nên biến nó thành link xanh bấm được.
//
// TRẢ VỀ MẢNG NODE, KHÔNG trả về HTML. Chuỗi vào đây là message của SERVER - kể cả bản server
// cũ hoặc bản khác - tức dữ liệu ngoài; ghép vào `innerHTML` là mở cửa cho thẻ lạ. Ở đây chỉ
// sinh Text node + thẻ <a> do chính hàm này tạo, chữ luôn đi qua `textContent`.
//
// Thẻ <a> CỐ Ý KHÔNG có `href`: có href thì Electron tự điều hướng chính cửa sổ app sang web -
// mất luôn màn đăng nhập, không có đường quay lại. Mở bằng `vt.shell.openExternal` để ra trình
// duyệt MẶC ĐỊNH của máy. Không href nên con trỏ phải do CSS `.ext-link` đặt (cursor: pointer).
const URL_RE = /https?:\/\/[^\s<>"'()]+[^\s<>"'(),.;:!?]/g;

function externalLink(url) {
  return el('a.ext-link', {
    text: url,
    onclick: (e) => {
      e.preventDefault();
      try { window.vt.shell.openExternal(url); } catch { /* ignore - không chặn luồng báo lỗi */ }
    },
  });
}

export function linkifyNodes(text) {
  const s = String(text == null ? '' : text);
  const out = [];
  let last = 0;
  for (const m of s.matchAll(URL_RE)) {
    if (m.index > last) out.push(document.createTextNode(s.slice(last, m.index)));
    out.push(externalLink(m[0]));
    last = m.index + m[0].length;
  }
  // Không có URL nào → vẫn PHẢI trả về một Text node, đừng trả mảng rỗng: nơi gọi dùng chung
  // một đường vẽ cho cả hai ca, trả rỗng là thông báo biến mất.
  if (!out.length) return [document.createTextNode(s)];
  if (last < s.length) out.push(document.createTextNode(s.slice(last)));
  return out;
}

// Modal thông báo 1 nút (chỉ để BÁO, không hỏi). Dùng cho các tình huống "không xử lý
// được" cần nhấn mạnh (vd đã đạt giới hạn gói) - không được đứng im.
export function alertDialog({ title, message, okLabel = 'Đã hiểu', danger = false, onClose }) {
  openModal({
    title,
    body: [el('div', {}, linkifyNodes(message))],
    footer: [
      el('button.btn' + (danger ? '.solid-red' : '.primary'), { text: okLabel, onclick: () => { closeModal(); onClose && onClose(); } }),
    ],
  });
}

// prompt dialog
export function promptDialog({ title, label, value = '', placeholder = '', onSubmit }) {
  let input;
  openModal({
    title,
    body: [el('div.field', {}, [
      label ? el('label', { text: label }) : null,
      (input = el('input.input', { value, placeholder })),
    ])],
    footer: [
      el('button.btn', { text: 'Hủy', onclick: closeModal }),
      el('button.btn.primary', { text: 'Lưu', onclick: () => { const v = input.value.trim(); closeModal(); onSubmit && onSubmit(v); } }),
    ],
  });
  setTimeout(() => input && input.focus(), 30);
}
