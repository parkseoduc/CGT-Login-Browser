// "Tài liệu API" — renders vendored Swagger UI against CGTBrowser v2.0's live
// `/v3/api-docs` OpenAPI 3.0.3 endpoint, with an automatic built-in OpenAPI 3.0.3
// fallback spec if Core v1 is running before `/v3/api-docs` is mounted.
import { el } from '../ui.js';
import { t, getLang } from '../i18n.js';

const SWAGGER_CSS = 'renderer/vendor/swagger-ui/swagger-ui.css';
const SWAGGER_JS = 'renderer/vendor/swagger-ui/swagger-ui-bundle.js';

let swaggerLoad = null;
function loadSwagger() {
  if (window.SwaggerUIBundle) return Promise.resolve();
  if (swaggerLoad) return swaggerLoad;
  swaggerLoad = new Promise((resolve, reject) => {
    if (!document.getElementById('swagger-ui-css')) {
      const link = document.createElement('link');
      link.id = 'swagger-ui-css';
      link.rel = 'stylesheet';
      link.href = SWAGGER_CSS;
      document.head.appendChild(link);
    }
    const prevDefine = window.define;
    if (prevDefine) window.define = undefined;
    const restore = () => { if (prevDefine) window.define = prevDefine; };
    const s = document.createElement('script');
    s.src = SWAGGER_JS;
    s.onload = () => { restore(); resolve(); };
    s.onerror = () => { restore(); reject(new Error('không tải được swagger-ui-bundle.js')); };
    document.body.appendChild(s);
  });
  return swaggerLoad;
}

const ORIGIN = (typeof window !== 'undefined' && window.location && /^https?:/i.test(window.location.origin))
  ? window.location.origin
  : 'http://127.0.0.1:51888';
const API_DOCS_URL = ORIGIN + '/v3/api-docs';

function buildFallbackOpenApiSpec() {
  return {
    openapi: '3.0.3',
    info: {
      title: 'CGTBrowser Local Control & Automation API',
      version: '2.0.0',
      description: 'REST & CDP Control API cục bộ cho **CGTBrowser v2.0** (`127.0.0.1:51888`). Cho phép công cụ bên ngoài, kịch bản Python/Node.js, Puppeteer/Playwright và MCP Agent quản lý hồ sơ, khởi chạy nhân trình duyệt Chromium 153 / Firefox, đồng bộ cửa sổ và thực thi quy trình RPA.',
    },
    servers: [{ url: ORIGIN, description: 'Local CGTBrowser Engine (127.0.0.1:51888)' }],
    tags: [
      { name: 'Hệ thống', description: 'Trạng thái máy chủ Core, danh sách nhân & kênh sự kiện thời gian thực (SSE)' },
      { name: 'Profiles', description: 'Quản lý vòng đời hồ sơ, mở/đóng trình duyệt qua CDP, Cookie & Thùng rác' },
      { name: 'Proxies', description: 'Quản lý kho Proxy HTTP / SOCKS4 / SOCKS5 & kiểm tra GeoIP' },
      { name: 'Multi-Window Sync', description: 'Xếp lưới cửa sổ thông minh & đồng bộ thao tác Master → Slave' },
      { name: 'Visual RPA', description: 'Danh mục 53 node, đồ thị quy trình RPA, nhiệm vụ đa luồng & lập lịch' },
      { name: 'Cloud Sync & MCP', description: 'Đồng bộ đám mây E2EE (Local/NAS, S3/R2, GDrive, Telegram) & Model Context Protocol' },
    ],
    paths: {
      '/api/v1/status': {
        get: {
          tags: ['Hệ thống'],
          summary: 'Kiểm tra trạng thái hoạt động của CGTBrowser Core & các hồ sơ đang chạy',
          responses: { '200': { description: 'Trạng thái hệ thống hiện hành' } },
        },
      },
      '/api/v1/events/stream': {
        get: {
          tags: ['Hệ thống'],
          summary: 'Kênh Realtime Server-Sent Events (profile:state, sync:status, rpa:log, cloud:progress, kernel:progress)',
          responses: { '200': { description: 'text/event-stream' } },
        },
      },
      '/api/v1/profiles': {
        get: {
          tags: ['Profiles'],
          summary: 'Lấy danh sách hồ sơ (hỗ trợ lọc search, groupId, tag, engine)',
          parameters: [
            { name: 'search', in: 'query', schema: { type: 'string' }, description: 'Từ khóa tìm theo tên hoặc ghi chú' },
            { name: 'groupId', in: 'query', schema: { type: 'string' }, description: 'ID nhóm hồ sơ' },
          ],
          responses: { '200': { description: 'Danh sách hồ sơ' } },
        },
        post: {
          tags: ['Profiles'],
          summary: 'Tạo hồ sơ trình duyệt mới (tự sinh vân tay nhất quán WebGL/Canvas/Audio)',
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    name: { type: 'string', example: 'Hồ sơ API 01' },
                    os: { type: 'string', enum: ['windows', 'macos', 'linux', 'android', 'ios'], example: 'windows' },
                    engine: { type: 'string', enum: ['chromium', 'firefox'], example: 'chromium' },
                    start_url: { type: 'string', example: 'https://iphey.com' },
                    notes: { type: 'string', example: 'Tạo bằng API cục bộ' },
                  },
                },
              },
            },
          },
          responses: { '200': { description: 'Hồ sơ vừa tạo' } },
        },
      },
      '/api/v1/profiles/{id}/start': {
        post: {
          tags: ['Profiles'],
          summary: 'Khởi chạy trình duyệt và nhận cổng CDP / WebSocket (wsEndpoint) cho Puppeteer/Playwright',
          parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
          requestBody: {
            required: false,
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    blank: { type: 'boolean', example: false },
                    bounds: {
                      type: 'object',
                      properties: { x: { type: 'integer', example: 0 }, y: { type: 'integer', example: 0 }, width: { type: 'integer', example: 960 }, height: { type: 'integer', example: 720 } },
                    },
                  },
                },
              },
            },
          },
          responses: { '200': { description: '{ success, pid, debugPort, wsEndpoint, slot }' } },
        },
      },
      '/api/v1/profiles/{id}/stop': {
        post: {
          tags: ['Profiles'],
          summary: 'Đóng êm trình duyệt (flush Cookie an toàn xuống đĩa trước khi thoát)',
          parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
          responses: { '200': { description: 'Đã đóng trình duyệt' } },
        },
      },
      '/api/v1/profiles/{id}/cookies': {
        get: {
          tags: ['Profiles'],
          summary: 'Đọc Cookie của hồ sơ (qua CDP khi đang mở hoặc SQLite khi đang đóng)',
          parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
          responses: { '200': { description: 'Danh sách Cookie' } },
        },
        post: {
          tags: ['Profiles'],
          summary: 'Bơm Cookie tự nhận diện 3 định dạng: JSON, Netscape cookies.txt, hoặc k=v; k2=v2',
          parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
          requestBody: {
            required: true,
            content: { 'application/json': { schema: { type: 'object', properties: { cookies: { type: 'string', example: 'c_user=10001; xs=abcd1234' } } } } },
          },
          responses: { '200': { description: 'Đã nạp Cookie' } },
        },
      },
      '/api/v1/proxies': {
        get: { tags: ['Proxies'], summary: 'Danh sách Proxy đã lưu', responses: { '200': { description: 'Danh sách Proxy' } } },
        post: {
          tags: ['Proxies'],
          summary: 'Thêm Proxy mới vào kho dùng chung',
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    type: { type: 'string', example: 'socks5' },
                    host: { type: 'string', example: '103.110.84.10' },
                    port: { type: 'integer', example: 1080 },
                    username: { type: 'string', example: 'user01' },
                    password: { type: 'string', example: 'pass01' },
                  },
                },
              },
            },
          },
          responses: { '200': { description: 'Proxy vừa tạo' } },
        },
      },
      '/api/v1/sync/arrange': {
        post: {
          tags: ['Multi-Window Sync'],
          summary: 'Xếp cửa sổ trình duyệt đang mở theo bố cục lưới / cột / xếp tầng (sàn 516×96px)',
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    layout: { type: 'string', enum: ['grid', 'columns', 'cascade', 'stack', 'manual'], example: 'grid' },
                    profileIds: { type: 'array', items: { type: 'string' } },
                  },
                },
              },
            },
          },
          responses: { '200': { description: 'Đã sắp xếp cửa sổ' } },
        },
      },
      '/api/v1/sync/start': {
        post: {
          tags: ['Multi-Window Sync'],
          summary: 'Bắt đầu phiên đồng bộ thao tác chuột/phím/cuộn từ cửa sổ Master sang các cửa sổ Slave',
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    masterId: { type: 'string' },
                    slaveIds: { type: 'array', items: { type: 'string' } },
                  },
                },
              },
            },
          },
          responses: { '200': { description: 'Đã bật đồng bộ' } },
        },
      },
      '/api/v1/rpa/flows': {
        get: { tags: ['Visual RPA'], summary: 'Danh sách đồ thị quy trình Visual RPA', responses: { '200': { description: 'Danh sách quy trình' } } },
      },
      '/api/v1/rpa/run': {
        post: {
          tags: ['Visual RPA'],
          summary: 'Thực thi quy trình RPA đa luồng theo Làn sóng (Wave/Lane)',
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    flowId: { type: 'string' },
                    profileIds: { type: 'array', items: { type: 'string' } },
                  },
                },
              },
            },
          },
          responses: { '200': { description: 'Thông tin lượt chạy (runId)' } },
        },
      },
      '/api/v1/cloud-sync/status': {
        get: { tags: ['Cloud Sync & MCP'], summary: 'Trạng thái kết nối Cloud Profile Sync & mã hóa E2EE', responses: { '200': { description: 'Trạng thái đồng bộ đám mây' } } },
      },
      '/api/v1/mcp/status': {
        get: { tags: ['Cloud Sync & MCP'], summary: 'Thông tin cấu hình Model Context Protocol (MCP) cho Claude / Cursor / Codex', responses: { '200': { description: 'Cấu hình MCP JSON & TOML' } } },
      },
    },
  };
}

function ensureApiStyles() {
  if (document.getElementById('api-view-overrides')) return;
  const st = document.createElement('style');
  st.id = 'api-view-overrides';
  st.textContent = `
    .api-view .swagger-ui { background: transparent !important; }
    .api-view .swagger-ui .info .title small { background: transparent !important; padding: 0; }
    .api-view .swagger-ui .info .title small pre { color: inherit; }
    .api-view .swagger-ui .info .title small.version-stamp { display: none !important; }
    .api-view .swagger-ui .info hgroup.main a { display: inline-block; margin-top: 8px; }
    .api-view .swagger-ui .info { margin: 30px 0 0; }
    .api-view .swagger-ui .scheme-container { padding: 0 0 10px; }
  `;
  document.head.appendChild(st);
}

let themeSynced = false;
function syncSwaggerTheme() {
  const apply = () => {
    const dark = document.documentElement.getAttribute('data-theme') === 'dark';
    document.documentElement.classList.toggle('dark-mode', dark);
  };
  apply();
  if (themeSynced) return;
  themeSynced = true;
  new MutationObserver(apply).observe(document.documentElement, {
    attributes: true, attributeFilter: ['data-theme'],
  });
}

const API_PHRASES = [
  ['**Nhân đã cài trên máy này**', { en: '**Kernels installed on this machine**', ru: '**Ядра, установленные на этом компьютере**', zh: '**本机已安装的内核**' }],
  ['"Hồ sơ API 01"', { en: '"API Profile 01"', ru: '"Профиль API 01"', zh: '"API 配置文件 01"' }],
  ['"Tạo bằng API cục bộ"', { en: '"Created via the local API"', ru: '"Создан через локальный API"', zh: '"通过本地 API 创建"' }],
];
function phraseTx(str, lang) {
  let out = str;
  for (const [vi, m] of API_PHRASES) if (m[lang]) out = out.split(vi).join(m[lang]);
  return out;
}
function docTx(str) {
  const lang = getLang();
  if (typeof str !== 'string' || !str || lang === 'vi') return str;
  const one = (p) => { const hit = t(p); return hit !== p ? hit : phraseTx(p, lang); };
  return str.split(/(\n{2,})/).map((p) => {
    if (!p.trim()) return p;
    if (t(p) !== p) return t(p);
    return p.includes('\n') ? p.split('\n').map(one).join('\n') : one(p);
  }).join('');
}
function localizeSpec(spec) {
  if (!spec || typeof spec !== 'object') return spec;
  const lang = getLang();
  if (lang === 'vi') return spec;
  if (spec.info) spec.info.description = docTx(spec.info.description);
  for (const tg of spec.tags || []) { tg.name = docTx(tg.name); tg.description = docTx(tg.description); }
  for (const ops of Object.values(spec.paths || {})) {
    for (const op of Object.values(ops || {})) {
      if (!op || typeof op !== 'object' || Array.isArray(op)) continue;
      op.summary = docTx(op.summary);
      op.description = docTx(op.description);
      if (Array.isArray(op.tags)) op.tags = op.tags.map(docTx);
    }
  }
  return spec;
}

function jsoncExamplePlugin(system) {
  const React = system && system.React;
  const sys = () => (system && typeof system.getSystem === 'function' ? system.getSystem() : system);
  const isJsonc = (v) => typeof v === 'string' && /^\s*\{/.test(v);

  const swapJsonc = (spec) => {
    const paths = (spec && spec.paths) || {};
    for (const p of Object.keys(paths)) {
      for (const m of Object.keys(paths[p] || {})) {
        const op = paths[p][m];
        const content = op && op.requestBody && op.requestBody.content;
        for (const ct of Object.keys(content || {})) {
          const mt = content[ct];
          if (mt && typeof mt['x-example-jsonc'] === 'string') mt.example = mt['x-example-jsonc'];
        }
      }
    }
    return spec;
  };

  const plugin = {
    statePlugins: {
      spec: {
        wrapActions: {
          updateJsonSpec: (ori) => (spec, ...rest) => ori(swapJsonc(localizeSpec(spec)), ...rest),
        },
      },
    },
    fn: {
      getSampleSchema: (schema, contentType = '', config = {}, example = undefined) => {
        const ex = example && typeof example.toJS === 'function' ? example.toJS() : example;
        if (isJsonc(ex)) return ex;
        const fn = sys().fn;
        if (/xml/.test(contentType)) {
          const sch = schema && typeof schema.toJS === 'function' ? schema.toJS() : schema;
          return fn.getXmlSampleSchema(sch, config, ex);
        }
        if (/(yaml|yml)/.test(contentType)) return fn.getYamlSampleSchema(schema, config, contentType, ex);
        return fn.getJsonSampleSchema(schema, contentType, ex);
      },
    },
  };
  if (React) {
    plugin.wrapComponents = {
      HighlightCode: (Original) => (props) => React.createElement(
        Original,
        !props.language && isJsonc(props.children) ? { ...props, language: 'json' } : props,
      ),
    };
  }
  return plugin;
}

export function render(ctx) {
  syncSwaggerTheme();
  ensureApiStyles();
  const host = el('div.api-view');
  const mount = el('div.swagger-mount#swagger-ui-root');
  host.appendChild(mount);
  ctx.container.appendChild(host);

  host.addEventListener('click', (e) => {
    const a = e.target && e.target.closest ? e.target.closest('.swagger-ui .info a[href]') : null;
    if (!a) return;
    const href = a.getAttribute('href') || '';
    if (!/^https?:/i.test(href)) return;
    e.preventDefault();
    e.stopPropagation();
    try { if (window.vt && window.vt.shell) window.vt.shell.openExternal(href); } catch { /* ignore */ }
  });

  Promise.all([
    loadSwagger(),
    fetch(API_DOCS_URL)
      .then((r) => (r.ok ? r.json() : null))
      .catch(() => null),
  ]).then(([, liveSpec]) => {
    if (!window.SwaggerUIBundle) throw new Error('SwaggerUIBundle không khả dụng');
    const specToRender = (liveSpec && liveSpec.openapi && liveSpec.paths)
      ? liveSpec
      : buildFallbackOpenApiSpec();
    window.SwaggerUIBundle({
      spec: localizeSpec(specToRender),
      domNode: mount,
      deepLinking: false,
      docExpansion: 'list',
      defaultModelsExpandDepth: 1,
      defaultModelExpandDepth: 2,
      tryItOutEnabled: false,
      supportedSubmitMethods: ['get', 'post', 'put', 'delete', 'patch'],
      presets: [window.SwaggerUIBundle.presets.apis],
      plugins: [jsoncExamplePlugin],
      layout: 'BaseLayout',
    });
  }).catch((err) => {
    mount.appendChild(el('div.placeholder-view', {}, [
      el('h2', { text: 'Không tải được Swagger UI' }),
      el('div.muted', { text: String(err && err.message || err) }),
    ]));
  });

  return null;
}
