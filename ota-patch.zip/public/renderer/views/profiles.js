// Port of ProfileView.xaml(.cs) - the default screen and the most complex one.
// Collapsible group panel + searchable/paginated profile grid with inline cell
// editing, per-row open/close (launches Chrome via the main process), bulk
// actions, and the create / batch-create / edit-proxy modals.
import { el, clear, toast, openModal, closeModal, confirmDialog, alertDialog, openMenu, hoverMenu, customSelect, pageSizeSelect, customDateTime, gridEmpty, noProfileSvg, withSpin } from '../ui.js';
import { icon } from '../icons.js';
import { remote } from '../data/remote-ds.js';
import { rememberProfiles } from '../data/activity-log.js';
import { tasks as rpaTasks, saveTask, runTask as runSharedTask, ready as rpaReady } from '../data/rpa-store.js';
import { loadPermissions, can, canOnProfile } from '../data/team-permissions.js';
import { hasFeature, gateFeature, gateNotExpired, isPlanExpired, loadPlanFeatures } from '../data/plan-features.js';
import { notifyError } from '../data/errors.js';
import { buildXlsx } from '../data/xlsx.js';
import { t, tf } from '../i18n.js';
import { PROXY_TYPES, PROXY_TYPE_DEFAULT, normalizeProxyType } from '../data/proxy-types.js';
import { ensureKernelReady } from './kernels.js';
import { polyBrowserVersion, polyBrowserName, polyBrowserIcon, profileEngine } from '../data/browser-badge.js';
// uaString/chromeMajors/firefoxMajors/randomChromeFull/buildUaMeta: dùng cho ô
// "User-Agent" của modal "Trình duyệt" hàng loạt - xem bulkSetKernel().
import { newFingerprint, buildFpConfig, osGpu, osHardware, osDeviceName, osFonts, setAllPools, hasPools, uaString, chromeMajors, firefoxMajors, randomChromeFull, buildUaMeta } from '../data/fingerprint.js';

// Thông điệp tooltip khi nhân viên chỉ-xem-chạy bấm nút bị khóa. Server VẪN chặn
// thật (403); phần này chỉ khóa mềm nút ở client cho rõ UX (mờ + not-allowed +
// tooltip), KHÔNG ẩn nút.
const PERM_MSG = {
  edit: 'Bạn chỉ có quyền xem & chạy - không thể chỉnh sửa. Liên hệ quản trị để nâng quyền.',
  del: 'Bạn không có quyền xóa hồ sơ. Liên hệ quản trị để nâng quyền.',
  create: 'Bạn không có quyền tạo hồ sơ. Liên hệ quản trị để nâng quyền.',
  move: 'Bạn không có quyền chuyển nhóm. Liên hệ quản trị để nâng quyền.',
  dupe: 'Bạn không có quyền nhân bản hồ sơ. Liên hệ quản trị để nâng quyền.',
  share: 'Bạn không có quyền chia sẻ hồ sơ. Liên hệ quản trị để nâng quyền.',
  expired: 'Gói thuê bao đã hết hạn - hãy gia hạn để tiếp tục sử dụng.',
};

// Quyền hồ sơ CÓ THỂ chia sẻ - hiển thị dạng checkbox tùy chỉnh (giống "Thành viên
// nhóm"). Nhãn khớp danh mục quyền hồ sơ; gửi lên server dạng key phẳng `profile:*`
// (server có whitelist SHAREABLE_KEYS trùng khớp để lọc/chống leo thang quyền).
const SHARE_PERMS = [
  { key: 'profile:open', label: 'Mở' },
  { key: 'profile:show_note', label: 'Hiển thị ghi chú' },
  { key: 'profile:edit_note', label: 'Chỉnh sửa ghi chú' },
  { key: 'profile:edit_proxy', label: 'Chỉnh sửa proxy' },
  { key: 'profile:edit_fingerprint', label: 'Chỉnh sửa dấu vân tay' },
  { key: 'profile:move_group', label: 'Chuyển nhóm hồ sơ' },
  { key: 'profile:duplicate', label: 'Nhân bản' },
  { key: 'profile:transfer', label: 'Chuyển đi' },
];

// Khóa/mở một nút thường: allowed=false → mờ, not-allowed, tooltip, click chỉ
// nhắc tooltip (giữ handler thật ở _realClick để mở lại khi được nâng quyền).
function gateBtn(btn, allowed, msg) {
  if (!btn) return btn;
  if (allowed) {
    btn.classList.remove('is-locked');
    if (btn._realClick) { btn.onclick = btn._realClick; btn._realClick = null; }
    if (btn.getAttribute('title') === msg) btn.removeAttribute('title');
  } else {
    if (!btn._realClick) btn._realClick = btn.onclick;
    btn.classList.add('is-locked');
    btn.title = msg;
    btn.onclick = (e) => { e.stopPropagation(); toast(msg, 'warn'); };
  }
  return btn;
}

const SCOPES = [['all', 'Tất cả'], ['name', 'Tên'], ['id', 'Profile ID'], ['note', 'Ghi chú'], ['tags', 'Thẻ'], ['proxy', 'Proxy'], ['group', 'Nhóm'], ['creator', 'Email tạo']];
// Advanced-search field list (everything except the "all" pseudo-scope).
const ADV_FIELDS = SCOPES.filter(([k]) => k !== 'all');
// Advanced-search operators, matching the WPF condition builder.
const ADV_OPS = [
  ['startsWith', 'Bắt đầu bằng'],
  ['contains', 'Bao gồm'],
  ['notContains', 'Không bao gồm'],
  ['empty', 'Trống'],
  ['notEmpty', 'Không được để trống'],
];
const ADV_NO_VALUE = (op) => op === 'empty' || op === 'notEmpty';
// PROXY_TYPES / normalizeProxyType: xem data/proxy-types.js (nguồn DUY NHẤT, 4 item).
const OS_LIST = [['Windows', 'Windows'], ['macOS (Intel)', 'macOS Intel'], ['macOS (Apple)', 'macOS Apple'], ['Linux', 'Linux'], ['Android', 'Android']];
// Badge trình duyệt của hồ sơ (icon + major) - xem data/browser-badge.js. Dùng chung với
// trash.js để hai lưới không thể lệch nhau.
// Maps a profile's OS (stored in fingerprint meta.os) to the icon name used on
// the create-profile "Thao tác hệ thống" pills, so the grid shows the same icon.
const OS_ICON = { Windows: 'windows', macOS: 'apple', Linux: 'linux', Android: 'android', iOS: 'ios' };
// Grid OS label → server enum (for regenerating a fingerprint via generateFingerprint).
const OS_ENUM = { Windows: 'windows', macOS: 'macos', Mac: 'macos', Linux: 'linux', Android: 'android', iOS: 'ios' };

// Hai nhân trình duyệt - BÊ Y NGUYÊN từ màn "Tạo hồ sơ" (profile_create.js) để
// modal "Trình duyệt" hàng loạt hiện đúng cùng bộ thẻ/nhãn. [val, label, iconName].
const BULK_KERNELS = [
  ['Poly', 'ChromeBrowser', 'chrome'],
  ['Firefox', 'FirefoxBrowser', 'firefox'],
];
const bulkEngineOf = (kernel) => (kernel === 'Firefox' ? 'firefox' : 'chromium');

// 4 chế độ WebRTC - NHÃN PHẢI KHỚP TỪNG CHỮ với màn "Tạo/Sửa hồ sơ", vì giá trị
// lưu vào fingerprint.ui.webRTC chính là nhãn tiếng Việt này (buildFpConfig so
// chuỗi để suy ra mode cho nhân). Lệch một chữ = fpConfig.webrtc sai im lặng.
// [value, label, icon, tooltip] - đúng shape `pills()` nhận.
const WEBRTC_OPTS = [
  ['Thực', 'Thực', null, 'Sử dụng IP thực của thiết bị hiện tại'],
  ['Vô hiệu hóa', 'Vô hiệu hóa', null, 'Chặn đọc tham số WebRTC'],
  ['Thay thế', 'Thay thế', null, 'Sử dụng IP WebRTC trùng khớp với proxy của bạn'],
  ['UDP qua proxy', 'UDP qua proxy', null, 'Ép mọi kết nối ICE đi qua proxy, chặn hoàn toàn UDP trực tiếp'],
];

// Dựng lại ĐÚNG nhánh `fpConfig.webrtc` mà buildFpConfig() sinh ra cho một nhãn.
// PHẢI soi gương khối webrtc trong data/fingerprint.js: 'Thực' → KHÔNG có section
// (nhân dùng WebRTC thật), còn lại → { mode, hideStatsHostname, hideStatsMac }.
// Đây là lý do hàm này tồn tại: sửa vân tay hàng loạt KHÔNG được build lại cả
// fpConfig (sẽ đổi seed/canvas/WebGL…), nên phải vá đúng một nhánh webrtc.
function webRtcCfgFor(label) {
  if (label === 'Vô hiệu hóa') return { mode: 'disabled' };
  if (label === 'Thay thế') return { mode: 'fake_ip', hideStatsHostname: true, hideStatsMac: true };
  if (label === 'UDP qua proxy') return { mode: 'proxy_only', hideStatsHostname: true, hideStatsMac: true };
  return null;   // 'Thực' = mặc định, không phát section webrtc
}

// Segmented control - BẢN SAO của pills() trong profile_create.js (hàm đó là local
// của module ấy, không export). Giữ cùng class .seg.pc-seg để nhìn y hệt màn tạo.
// `options`: ['Label', …] | [[value, label], …] | [[value, label, icon, tooltip], …]
function pills(options, value, onChange) {
  const norm = options.map((o) => (Array.isArray(o) ? o : [o, o]));
  const wrap = el('div.seg.pc-seg');
  function render() {
    clear(wrap);
    norm.forEach(([v, l, ic, tip]) => {
      wrap.appendChild(el('button.seg-opt' + (v === value ? '.active' : ''), {
        type: 'button',
        // Nhãn + tooltip để NGUYÊN tiếng Việt: bộ i18n tự dịch text node và thuộc tính
        // `title` qua MutationObserver (applyAttr) - gọi t() ở đây là dịch hai lần.
        title: tip || undefined,
        html: (ic ? icon(ic) : '') + `<span>${l}</span>`,
        onclick: () => { value = v; render(); onChange && onChange(v); },
      }));
    });
  }
  render();
  Object.defineProperty(wrap, 'value', { get: () => value });
  return wrap;
}

// ---- helpers -------------------------------------------------------------

function fingerprintJson(browser, os) {
  return JSON.stringify({ browser, os, userAgent: '' });
}

// Deterministic colour bucket for a tag name → one of N palette classes, so the
// same tag always renders with the same colour everywhere in the grid.
const TAG_COLOR_COUNT = 6;
function tagColorClass(name) {
  let h = 0;
  const s = String(name || '');
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return 'tag-c' + (h % TAG_COLOR_COUNT);
}

function proxyDisplay(p) {
  const t = (p.proxyType || '').toLowerCase();
  if (t === 'token') return 'Token';
  if (t === 'proxy xoay') return 'Proxy xoay';
  if (p.proxyHost && p.proxyPort) return `${p.proxyHost}:${p.proxyPort}`;
  return 'Local IP';
}

// A short, stable display ID for a profile - the first 8 hex chars of its
// "Profile ID" (md5 of the GUID). Used where the full name is too long (grid
// cell sub-line, Automation modal chips). Deterministic + unique enough for
// display; the real key stays the GUID `p.id`.
function shortId(p) {
  const pid = p && (p.profileId || p.id) ? String(p.profileId || p.id) : '';
  return pid ? pid.slice(0, 8).toUpperCase() : '';
}

// true when the profile has a usable proxy configured (so the IP cell shows the
// proxy on top instead of the bare geo IP).
function hasProxy(p) {
  const t = (p.proxyType || '').toLowerCase();
  // An empty proxyType is the "Không Sử Dụng Proxy" off-state: host/port may still be
  // stored (we retain them for easy re-enable) but the proxy is inactive, so the cell
  // shows the local IP rather than the retained host:port.
  return (!!p.proxyHost && !!p.proxyPort && !!t) || t === 'token' || t === 'proxy xoay';
}

// Modal cập nhật hàng loạt dùng CHUNG PROXY_TYPES (data/proxy-types.js). Trước đây nó có
// danh sách riêng [socks5 | https | http] với nhãn "Socks5"/"HTTPS" nên lệch hẳn với modal
// một-hồ-sơ ngay bên cạnh, và THIẾU SOCKS4. Bảng map value→enum cũng không cần nữa: giá trị
// của combobox giờ chính là enum proxyType.

// 2-letter ISO country code → a flag-emoji span. The two letters map to a pair
// of regional-indicator codepoints (e.g. VN → 🇻🇳). Windows has no native flag
// glyphs, so the .ip-flag CSS renders these with the bundled Twemoji Country
// Flags font, which covers every ISO country. Returns null on invalid codes.
function flagImg(cc) {
  const c = (cc || '').toUpperCase();
  if (!/^[A-Z]{2}$/.test(c)) return null;
  const emoji = String.fromCodePoint(
    0x1f1e6 + (c.charCodeAt(0) - 65),
    0x1f1e6 + (c.charCodeAt(1) - 65),
  );
  return el('span.ip-flag', { text: emoji, title: c });
}

function relTime(iso) {
  if (!iso) return '-';
  const then = new Date(iso).getTime();
  if (Number.isNaN(then)) return '-';
  const s = Math.floor((Date.now() - then) / 1000);
  if (s < 45) return t('Vừa xong');
  const m = Math.floor(s / 60);
  if (m < 60) return `${m} ${t('phút trước')}`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} ${t('giờ trước')}`;
  const d = Math.floor(h / 24);
  if (d < 30) return `${d} ${t('ngày trước')}`;
  const mo = Math.floor(d / 30);
  if (mo < 12) return `${mo} ${t('tháng trước')}`;
  return `${Math.floor(d / 365)} ${t('năm trước')}`;
}

// "scheme://user:pass@host:port" | "host:port:user:pass" | "host:port"
function parseProxyLine(line, defaultType) {
  let type = defaultType || 'HTTP', host = '', port = '', user = '', pass = '';
  line = (line || '').trim();
  if (!line) return null;
  if (line.includes('://')) {
    const [scheme, rest] = line.split('://');
    const s = scheme.toLowerCase();
    type = s.startsWith('socks4') ? 'SOCKS4' : s.startsWith('socks') ? 'SOCKS5' : 'HTTP';
    line = rest;
  }
  if (line.includes('@')) {
    const [cred, hp] = line.split('@');
    const [u, pw] = cred.split(':');
    user = u || ''; pass = pw || '';
    const [hh, pp] = hp.split(':');
    host = hh || ''; port = pp || '';
  } else {
    const parts = line.split(':');
    host = parts[0] || ''; port = parts[1] || ''; user = parts[2] || ''; pass = parts[3] || '';
  }
  return host ? { proxyType: type, proxyHost: host, proxyPort: port, proxyUser: user, proxyPass: pass } : null;
}

// ---- view ----------------------------------------------------------------

export function render(ctx) {
  let groups = [];
  let profiles = [];
  let filtered = [];
  let filter = null;       // null=all, ''=ungrouped, id
  let search = '';
  let scope = 'all';
  let advConditions = [];  // advanced search: [{ field, op, value }], AND-combined
  let sortKey = 'default'; // active sort order (see SORT_OPTIONS); 'default' = giữ thứ tự gốc
  let page = 0;
  let pageSize = 10;
  const selected = new Set();
  let lastRunTimer = null;
  let statusTimer = null;

  // ---- "Ghim đầu trang": tập id hồ sơ được đẩy lên đầu danh sách ------------
  // Ghim là thiết lập THEO MÁY (localStorage), KHÔNG đẩy lên server: nó chỉ là cách người
  // dùng này xếp lại chỗ làm việc của mình, cả nhóm không cần thấy theo. Áp lên MỌI kiểu
  // sắp xếp (xem applySort) nên hồ sơ đã ghim luôn ở trang 1.
  // Không dọn id của hồ sơ đã xóa: nhiều workspace dùng chung một tệp localStorage nên lọc
  // theo danh sách hồ sơ đang xem sẽ xóa oan ghim của workspace khác. Vài id rác vô hại.
  const PIN_KEY = 'polyPinnedProfiles';
  let pinned = new Set();
  try { const a = JSON.parse(localStorage.getItem(PIN_KEY) || '[]'); if (Array.isArray(a)) pinned = new Set(a.map(String)); }
  catch { /* dữ liệu hỏng → coi như chưa ghim gì */ }
  function savePins() {
    try { localStorage.setItem(PIN_KEY, JSON.stringify([...pinned])); } catch { /* ignore */ }
  }
  const isPinned = (id) => pinned.has(String(id));
  // on=true ghim, on=false bỏ ghim. GHIM thì nhảy về trang 1 (đúng chỗ hồ sơ vừa được đẩy
  // lên, nếu không người dùng bấm xong chẳng thấy gì thay đổi); BỎ GHIM thì giữ trang đang
  // xem, vì hồ sơ rơi về vị trí tự nhiên của nó chứ không đi đâu cụ thể.
  function setPinned(ids, on) {
    const list = (ids || []).map(String).filter(Boolean);
    if (!list.length) return;
    for (const id of list) { if (on) pinned.add(id); else pinned.delete(id); }
    savePins();
    applySearch(!on);
    const n = list.length;
    // Dùng lại đúng khoá i18n của trang Nhóm / Tự động hóa ('Đã ghim lên đầu trang',
    // 'Đã bỏ ghim') để khỏi sinh khoá trùng nghĩa.
    toast(on ? `${t('Đã ghim lên đầu trang')} ${n} ${t('hồ sơ')}` : `${t('Đã bỏ ghim')} ${n} ${t('hồ sơ')}`, 'ok');
  }
  // Mục ghim cho menu "Thêm" (hàng loạt). KHÔNG đặt `icon`: mọi mục khác của menu đó đều
  // không có icon, thêm vào là chữ của riêng nó thụt sang phải 26px so với cả danh sách.
  function pinBulkItem() {
    const ids = selIds();
    const allPinned = ids.length > 0 && ids.every((id) => isPinned(id));
    return { label: allPinned ? 'Bỏ ghim đầu trang' : 'Ghim đầu trang',
      onClick: () => { if (needSel()) setPinned(selIds(), !allPinned); } };
  }

  // elements built once
  const tbody = el('tbody');
  const emptyEl = gridEmpty('Chưa có hồ sơ nào', noProfileSvg);
  const totalText = el('span.muted');
  const pageNumbers = el('div.page-nums');
  const selectAll = el('input', { type: 'checkbox' });
  const selChip = el('span.sel-chip', { style: { display: 'none' } });
  let selBar = null; // bulk-action bar, built below; shown when ≥1 row is checked
  let barCloseBtn = null; // toolbar "Đóng" button; disabled when no profile is open
  let bulkGatedBtns = null; // các nút ghi trong thanh chọn cần khóa theo quyền
  // Thuê bao HẾT HẠN → khoá cứng MỌI thao tác ở UI (enable=false) để không bắn
  // request thừa làm lag metadata. Điều kiện ĐẦU TIÊN, trước cả quyền/số dư hồ sơ.
  // Khởi tạo ĐỒNG BỘ từ cache plan-features (app đã nạp lúc boot) để lần loadProfiles
  // đầu tiên đã bỏ qua list() ngay khi hết hạn (không chờ refreshExpiry async).
  let EXPIRED = isPlanExpired();
  // Profiles the user just clicked "Mở" for, optimistically shown as running while
  // their (2–3s) launch prep runs - so the button flips to "Đóng" instantly instead
  // of waiting for the browser process to actually spawn. An id is dropped from here
  // once the real running set confirms it (or the launch fails).
  const opening = new Set();
  // Hồ sơ vừa bấm "Đóng" nhưng CHƯA lưu xong cookie/phiên (main còn đang flush trong
  // _reapProfile). Trong lúc này nút hàng hiện spinner "Đang lưu" và KHÔNG cho mở lại, để
  // tránh cảnh vừa tắt đã mở ngay khi cookie chưa kịp ghi (mất cookie). Main đẩy danh sách
  // này qua onClosingChanged; ta cũng thêm lạc quan ngay lúc bấm để nút không nháy về "Mở".
  const closing = new Set();
  // Có kênh đẩy trạng thái closing từ main không (preload/main đủ mới). Nếu không, KHÔNG đặt
  // cờ closing lạc quan để tránh kẹt spinner - rơi về hành vi cũ (nút về "Mở" ngay).
  let closingSupported = false;
  // Đối soát cờ 'cloud' cho hồ sơ CŨ: chỉ hỏi Telegram 1 lần/phiên xem (tốn kết nối).
  let cloudReconciled = false;

  // Trạng thái ĐỒNG BỘ dữ liệu theo hồ sơ (id -> { phase, message }) do main-process đẩy
  // về khi tải/đóng gói/tải lên lúc mở/đóng browser. Dùng để hiện icon loading + nhãn ở
  // cell hành động. phase 'idle'/'done'/'error' (sau timeout) → xoá khỏi map.
  const syncing = new Map();

  // Quyền của người dùng hiện tại (khóa mềm nút Sửa/Xóa/Tạo… cho nhân viên chỉ
  // xem+chạy). Mặc định "cho phép" để chủ/quản trị không bị chớp-khóa trong lúc
  // loadPermissions() còn đang chạy; sau khi có quyền thật → computePerm + áp lại.
  // Sửa hồ sơ ở server dùng requireAnyPerm(4 quyền sửa) → client cũng gộp thành
  // `editAny` để khớp: có BẤT KỲ quyền sửa nào là sửa được (mọi PATCH).
  const PERM = { editAny: true, del: true, create: true, move: true, dupe: true, share: true };
  function computePerm() {
    PERM.del = can('profile:delete');
    PERM.create = can('profile:create');
    PERM.move = can('profile:move_group');
    PERM.dupe = can('profile:duplicate');
    PERM.share = can('profile:share');
    PERM.editAny = can('profile:edit_fingerprint') || can('profile:edit_proxy')
      || can('profile:edit_note') || can('profile:move_group');
  }
  // Quyền hiệu lực TRÊN MỘT HỒ SƠ (khoá nút theo từng hàng). Hồ sơ chia sẻ riêng dùng
  // đúng quyền chia sẻ (AUTHORITATIVE), không lấy quyền nhóm rộng - khớp server.
  function perProfilePerm(id) {
    const c = (k) => canOnProfile(id, k);
    return {
      editAny: c('profile:edit_fingerprint') || c('profile:edit_proxy')
        || c('profile:edit_note') || c('profile:move_group'),
      dupe: c('profile:duplicate'),
      move: c('profile:move_group'),
      del: c('profile:delete'),
      share: c('profile:share'),
    };
  }
  // Áp khóa mềm lên các nút cố định (tạo hồ sơ + thanh chọn) và vẽ lại lưới để
  // các bút chì/kebab trong hàng đọc PERM mới. Gọi sau khi loadPermissions() xong.
  function applyGating() {
    // Nút "Tạo hồ sơ" KHÔNG khóa mềm (không làm mờ) - nó luôn bấm được; khi thiếu
    // quyền thì click sẽ bung MODAL báo (xử lý ngay trong onclick của nút, đọc
    // PERM.create tại thời điểm bấm). Chỉ các nút thao tác hàng loạt mới mờ như cũ.
    if (bulkGatedBtns) {
      // Hết hạn → khoá HẾT (kể cả chủ/đủ quyền), nhắc gia hạn; ngược lại khoá theo quyền.
      const g = (btn, allowed, msg) => gateBtn(btn, EXPIRED ? false : allowed, EXPIRED ? PERM_MSG.expired : msg);
      g(bulkGatedBtns.open, true, '');
      g(bulkGatedBtns.auto, true, '');
      g(bulkGatedBtns.updateProxy, PERM.editAny, PERM_MSG.edit);
      // "Web RTC" / "Trình duyệt" ghi vào vân tay ⇒ cùng cổng quyền với "Dấu vân tay mới".
      // ("Di chuyển" đã vào dropdown "Thêm" nên khoá bằng `disabled` ở item, không qua đây.)
      g(bulkGatedBtns.webRtc, PERM.editAny, PERM_MSG.edit);
      g(bulkGatedBtns.kernel, PERM.editAny, PERM_MSG.edit);
      g(bulkGatedBtns.fp, PERM.editAny, PERM_MSG.edit);
      g(bulkGatedBtns.resetProxy, PERM.editAny, PERM_MSG.edit);
      g(bulkGatedBtns.del, PERM.del, PERM_MSG.del);
      g(bulkGatedBtns.share, PERM.share, PERM_MSG.share);
    }
    // Nút "Tạo hồ sơ" bình thường không khoá mềm; khi hết hạn thì khoá luôn để tránh
    // mở màn tạo rồi mới bị 403. (Bấm → nhắc gia hạn qua gateBtn.)
    gateBtn(createProfileBtn, !EXPIRED, PERM_MSG.expired);
    renderPage();
  }
  // Đọc trạng thái hết-hạn của gói thuê bao (cache ở plan-features) rồi khoá/mở UI.
  // force=true → gọi lại server 1 lần; onShow dùng để bắt kịp khi vừa gia hạn.
  async function refreshExpiry(force = false) {
    try { await loadPlanFeatures(force); EXPIRED = isPlanExpired(); }
    catch { /* mạng lỗi → giữ nguyên, không khoá oan */ }
    applyGating();
  }

  // -------------------------------------------------- data load
  async function loadGroups() {
    // Bọc lỗi: nhóm chỉ nuôi dropdown lọc/tạo/chuyển - một lần list() lỗi (mạng/429
    // lúc đổi workspace dồn request) KHÔNG được ném ra ngoài, nếu không sẽ chặn luôn
    // loadProfiles() ở nhánh khởi tạo → lưới trống, phải reload nhiều lần mới có.
    try { groups = await remote.groups.list(); } catch { groups = groups || []; }
    renderGroupFilter();
  }
  async function loadProfiles() {
    // HẾT HẠN thuê bao: thẻ gói phủ kín lưới rồi → KHÔNG gọi list() hồ sơ (khỏi bắn
    // request/lag metadata). Gia hạn xong quay lại trang này sẽ tự nạp (EXPIRED=false).
    if (EXPIRED) return;
    try {
      profiles = await remote.profiles.list(filter);
    } catch (e) {
      // Đừng gán oan "lỗi cơ sở dữ liệu" cho MỌI lỗi: NOT_WORKSPACE_MEMBER (header
      // workspace lệch khi đổi tài khoản) hay NO_PERMISSION/403 không phải lỗi DB.
      // notifyError phân loại đúng (quyền/mạng/quota); NOT_WORKSPACE_MEMBER thường đã
      // được refreshWorkspaces tự chữa nên chỉ báo gọn, không doạ người dùng.
      if (e && e.code === 'NOT_WORKSPACE_MEMBER') toast('Đang đồng bộ lại không gian làm việc…', 'warn');
      else notifyError(e, 'Không tải được danh sách hồ sơ.');
      return;
    }
    // Feed the id→name cache so activity-log entries created by id alone
    // (duplicate/move/delete) can still show the profile name.
    try { rememberProfiles(profiles); } catch { /* best-effort */ }
    // Seed each row's running state from the session-wide cache (kept fresh even while
    // this view was unmounted), so switching sidebar items back here shows the correct
    // open/close button INSTANTLY instead of re-detecting from scratch.
    let runSet = null;
    try { runSet = new Set(window.__vtApp && window.__vtApp.getRunningIds ? window.__vtApp.getRunningIds() : []); } catch { runSet = null; }
    if (runSet) profiles.forEach((p) => { p.running = runSet.has(p.id); });
    // Re-apply optimistic "đang mở" to freshly-fetched rows still mid-launch, so a
    // list refresh during the prep window doesn't momentarily revert the button.
    if (opening.size) profiles.forEach((p) => { if (opening.has(p.id)) p.running = true; });
    applySearch();
    window.__vtApp && window.__vtApp.refreshProfileCount();
    // Đối soát trạng thái 'cloud' cho hồ sơ CŨ (best-effort, không chặn render).
    reconcileCloudStorage();
  }

  // Hồ sơ CŨ đã có gói sao lưu trên cloud NHƯNG metadata.storage chưa được đặt (đồng bộ
  // trước khi có cơ chế cờ) sẽ hiện 'local' sai. Hỏi main-process danh sách ID đã có backup
  // trên đích (kèm TÊN ĐÍCH) → cập nhật storage = tên đích cho các hồ sơ đang 'local' khớp id.
  // Chỉ chạy 1 lần/phiên xem để tránh gọi Telegram lặp; lỗi/không bật cloud → bỏ qua êm.
  async function reconcileCloudStorage() {
    if (cloudReconciled) return;
    cloudReconciled = true;
    let res = null;
    try {
      const api = window.vt && window.vt.syncData;
      if (!api || typeof api.cloudIds !== 'function') return;
      res = await api.cloudIds();
    } catch { return; }
    const ids = res && res.ids;
    const dest = (res && res.dest) || 'cloud';
    if (!ids || !ids.length) return;
    const cloudSet = new Set(ids);
    // Hồ sơ được coi là "chưa ở cloud" khi storage rỗng hoặc 'local'. Đã ở một đích cloud
    // nào đó (telegram/gdrive/…) thì giữ nguyên, không đổi đích do đối soát.
    const stale = profiles.filter((p) => (!p.storage || p.storage === 'local') && cloudSet.has(p.id));
    if (!stale.length) return;
    let changed = false;
    for (const p of stale) {
      try {
        await remote.profiles.updateDynamic(p.id, { storage: dest });
        p.storage = dest;
        changed = true;
      } catch { /* best-effort per hồ sơ */ }
    }
    if (changed) applySearch();
  }

  function fieldValue(p, field) {
    const map = { name: p.name, id: p.profileId, note: p.note, tags: p.tags, proxy: proxyDisplay(p), group: p.group, creator: p.createdByEmail };
    return String(map[field] != null ? map[field] : '');
  }

  function condMatch(p, c) {
    const v = fieldValue(p, c.field).toLowerCase();
    const q = String(c.value || '').toLowerCase();
    switch (c.op) {
      case 'startsWith': return v.startsWith(q);
      case 'contains': return v.includes(q);
      case 'notContains': return !v.includes(q);
      case 'empty': return v.length === 0;
      case 'notEmpty': return v.length > 0;
      default: return true;
    }
  }

  function matches(p) {
    if (search) {
      const q = search.toLowerCase();
      const map = {
        all: [p.name, p.profileId, p.note, p.tags, proxyDisplay(p), p.group, p.createdByEmail],
        name: [p.name], id: [p.profileId], note: [p.note], tags: [p.tags], proxy: [proxyDisplay(p)], group: [p.group], creator: [p.createdByEmail],
      };
      if (!(map[scope] || map.all).some((v) => String(v || '').toLowerCase().includes(q))) return false;
    }
    if (advConditions.length && !advConditions.every((c) => condMatch(p, c))) return false;
    return true;
  }

  // Các kiểu sắp xếp cho dropdown "Sắp xếp" cạnh ô tìm kiếm. Array.sort ổn định nên
  // 'default' giữ nguyên thứ tự gốc từ server (không đảo lộn khi bỏ chọn sắp xếp).
  const SORT_OPTIONS = [
    ['default', 'Mặc định'],
    ['name_asc', 'Tên (A → Z)'],
    ['name_desc', 'Tên (Z → A)'],
    ['created_desc', 'Ngày tạo (mới nhất)'],
    ['created_asc', 'Ngày tạo (cũ nhất)'],
    ['lastrun_desc', 'Lần chạy gần nhất'],
    // LỌC, không phải sắp xếp: chọn mục này là chỉ hiện những hồ sơ đã "Ghim đầu trang".
    // Không thể làm kiểu sắp xếp được, vì hồ sơ đã ghim LUÔN nổi lên đầu ở mọi kiểu sắp xếp
    // (xem applySort) - một mục "sắp xếp theo ghim" sẽ cho ra đúng y "Mặc định". Nằm chung
    // combobox với các kiểu sắp xếp là theo đúng yêu cầu, xử lý riêng ở applySearch().
    ['pinned', 'Đã ghim đầu trang'],
    ['status', 'Trạng thái (đang mở trước)'],
  ];
  function applySort(arr) {
    const cmpName = (a, b) => String(a.name || '').localeCompare(String(b.name || ''), 'vi', { numeric: true, sensitivity: 'base' });
    const iso = (v) => (v ? Date.parse(v) || 0 : 0);
    switch (sortKey) {
      case 'name_asc': arr.sort(cmpName); break;
      case 'name_desc': arr.sort((a, b) => cmpName(b, a)); break;
      case 'created_desc': arr.sort((a, b) => iso(b.createdAtIso) - iso(a.createdAtIso)); break;
      case 'created_asc': arr.sort((a, b) => iso(a.createdAtIso) - iso(b.createdAtIso)); break;
      case 'lastrun_desc': arr.sort((a, b) => iso(b.lastRunAtIso) - iso(a.lastRunAtIso)); break;
      case 'status': arr.sort((a, b) => (b.running ? 1 : 0) - (a.running ? 1 : 0)); break;
      default: break;
    }
    // GHIM đứng TRÊN mọi kiểu sắp xếp (kể cả 'default'): đã ghim là phải thấy ngay ở trang 1.
    // Tách hai nhóm rồi nối lại thay vì sort() thêm một lượt - giữ nguyên thứ tự vừa sắp xếp
    // bên trong từng nhóm, và không phụ thuộc vào tính ổn định của sort ở từng engine.
    if (pinned.size) {
      const top = arr.filter((p) => isPinned(p.id));
      if (top.length) return top.concat(arr.filter((p) => !isPinned(p.id)));
    }
    return arr;
  }

  // keepPage=true: dựng lại danh sách mà GIỮ trang đang xem. Chỉ dùng cho thao tác không
  // đổi tập kết quả, chỉ đổi thứ tự (bỏ ghim) - đổi tìm kiếm/bộ lọc thì vẫn phải về trang 1
  // vì trang cũ có thể vượt quá số trang mới.
  function applySearch(keepPage = false) {
    let list = profiles.filter(matches);
    // 'pinned' là mục LỌC nằm trong combobox sắp xếp: chỉ giữ hồ sơ đã ghim, thứ tự bên
    // trong để nguyên như bản gốc từ server (chúng đã ghim hết nên chẳng còn gì để "đưa
    // lên đầu"). Lọc SAU matches() để nó cộng dồn với tìm kiếm + tìm kiếm nâng cao.
    if (sortKey === 'pinned') list = list.filter((p) => isPinned(p.id));
    filtered = applySort(list);
    if (!keepPage) page = 0;
    renderPage();
  }

  // -------------------------------------------------- grid
  function renderPage() {
    const pages = Math.max(1, Math.ceil(filtered.length / pageSize));
    if (page >= pages) page = pages - 1;
    const slice = filtered.slice(page * pageSize, page * pageSize + pageSize);
    clear(tbody);
    slice.forEach((p) => tbody.appendChild(renderRow(p)));
    const total = filtered.length;
    const from = total === 0 ? 0 : page * pageSize + 1;
    const to = Math.min((page + 1) * pageSize, total);
    totalText.textContent = total === 0 ? `0 ${t('trên')} 0` : `${from}-${to} ${t('trên')} ${total}`;
    emptyEl.style.display = total === 0 ? 'flex' : 'none';
    // Lưới rỗng vì đang LỌC "Đã ghim đầu trang" mà chưa ghim hồ sơ nào thì phải nói đúng lý
    // do - "Chưa có hồ sơ nào" trong khi người dùng có 50 hồ sơ là câu gây hiểu sai.
    if (total === 0) {
      const cap = emptyEl.querySelector('.muted');
      if (cap) cap.textContent = t(sortKey === 'pinned' ? 'Chưa ghim hồ sơ nào lên đầu trang' : 'Chưa có hồ sơ nào');
    }
    renderPager(pages);
    syncSelAll();
    updateSelUi();
    if (barCloseBtn) barCloseBtn.disabled = !profiles.some((p) => p.running);
  }

  function renderRow(p) {
    const cb = el('input', { type: 'checkbox', checked: selected.has(p.id),
      onchange: (e) => { e.target.checked ? selected.add(p.id) : selected.delete(p.id); syncSelAll(); updateSelUi(); } });

    // Quyền THEO TỪNG HỒ SƠ: hồ sơ được chia sẻ riêng (chỉ mở/xem ghi chú…) phải khoá
    // đúng dù người dùng thuộc nhóm quyền rộng (khớp server profilePermissions).
    const pp = perProfilePerm(p.id);

    // Bút chì "sửa ô" (tên/ghi chú/thẻ/proxy) - khóa mềm khi không có quyền sửa.
    const editBtn = (cls, onClick) => gateBtn(el('button.cell-edit', { html: icon('edit'), onclick: onClick }), pp.editAny, PERM_MSG.edit);

    const nameCell = el('td', {}, [el('div.name-cell', {}, [
      el('span.os-mark', { title: p.os || 'Windows', html: icon(OS_ICON[p.os] || 'windows') }),
      el('div.poly-mark', { title: polyBrowserName(p) + ' ' + polyBrowserVersion(p) }, [
        el('span.poly-ver', { text: polyBrowserVersion(p) }),
        el('img.poly-ico', { src: polyBrowserIcon(p), alt: polyBrowserName(p) }),
      ]),
      el('div', {}, [
        // Hồ sơ đã ghim: dấu ghim nhỏ trước tên. Cần dấu này vì hàng ghim nằm lẫn với hàng
        // thường ở đầu trang 1 - không có gì phân biệt thì người dùng tưởng danh sách tự đảo.
        // Bấm vào dấu là bỏ ghim luôn (khỏi phải mở menu ba chấm).
        el('div.name-main' + (isPinned(p.id) ? '.is-pinned' : ''), {}, [
          isPinned(p.id)
            ? el('span.name-pin', { html: icon('pin'), title: 'Bỏ ghim đầu trang',
                onclick: (e) => { e.stopPropagation(); setPinned([p.id], false); } })
            : null,
          el('span', { text: p.name }),
        ]),
        el('div.name-id.muted', { text: shortId(p), title: 'Profile ID: ' + (p.profileId || ''), onclick: (e) => { e.stopPropagation(); try { navigator.clipboard.writeText(p.profileId || ''); toast('Đã sao chép Profile ID', 'ok'); } catch { /* noop */ } } }),
        el('div.name-sub.muted', { html: `${icon('folder')}<span>${p.group}</span>` }),
        // "Tạo bởi: email" - CHỈ hiện ở workspace tạo riêng (server chỉ trả
        // createdByEmail ở workspace khác mặc định); workspace cá nhân bỏ qua.
        p.createdByEmail
          ? el('div.name-sub.muted.name-creator', { title: 'Tạo bởi: ' + p.createdByEmail }, [
              el('span.ncr-ico', { html: icon('user') }),
              el('span.ncr-label', { text: 'Tạo bởi:' }),
              el('span.ncr-email', { text: p.createdByEmail }),
            ])
          : null,
      ]),
      editBtn('', () => ctx.navigate('profile_create', p.id)),
    ])]);

    const noteCell = el('td', {}, [el('div.edit-cell', {}, [noteDisplay(p), editBtn('', () => editCell(p, 'note', 'Ghi chú'))])]);
    const tagCell = el('td', {}, [el('div.edit-cell', {}, [tagsDisplay(p), editBtn('', () => editTags(p))])]);
    // IP cell. When empty (no proxy and no geo IP yet) it mimics the "Thẻ" cell:
    // just "-" with an edit pencil. Once there's data, it shows the IP/proxy on
    // top, the country flag image below, plus check / location actions.
    const ipEmpty = !hasProxy(p) && !p.geoIp;
    let ipCell;
    if (ipEmpty) {
      ipCell = el('td', {}, [el('div.edit-cell', {}, [
        el('span.muted', { text: '-' }),
        editBtn('', () => editProxy(p)),
      ])]);
    } else {
      const flag = flagImg(p.geoCountry || '');
      const topText = hasProxy(p) ? proxyDisplay(p) : (p.geoIp || '-');
      const botParts = [flag, p.geoRegion ? el('span.ip-region', { text: p.geoRegion }) : null].filter(Boolean);
      ipCell = el('td', {}, [el('div.ip-cell', {}, [
        el('div.ip-actions', {}, [
          el('button.ip-act', { html: icon('proxyCheck'), title: 'Kiểm tra proxy', onclick: (e) => spinWhile(e.currentTarget, () => checkProxy(p)) }),
          el('button.ip-act.loc', { html: icon('location'), title: 'Vị trí IP', onclick: () => showLocation(p) }),
        ]),
        el('div.ip-info', {}, [
          el('div.ip-top', { text: topText }),
          botParts.length ? el('div.ip-bot', {}, botParts) : null,
        ]),
        editBtn('', () => editProxy(p)),
      ])]);
    }
    const lastRunCell = el('td', { text: relTime(p.lastRunAtIso) });
    // storage - nơi lưu trữ hồ sơ. Chưa đồng bộ (storage rỗng/'local') ⇒ "Local". Đã đẩy lên
    // đám mây ⇒ hiện ĐÚNG đích: icon đám mây + tên đích (vd "Telegram"), không "Cloud" chung.
    const storageInfo = storageBadge(p.storage);
    const storageCell = el('td', {}, [
      el('span.storage-badge' + (storageInfo.cloud ? '.cloud' : '.local'), {
        html: `${icon(storageInfo.cloud ? 'cloud' : 'cloudOff')}<span>${storageInfo.label}</span>`,
      }),
    ]);
    const createdCell = el('td.muted', { text: p.createdAt || '-' });

    // action
    // Icon nút Mở/Đóng phải theo ĐÚNG nhân của hồ sơ. Trước đây luôn là icon Chrome nên
    // hồ sơ Firefox vẫn hiện logo Chrome - nhìn nhầm sang hồ sơ Chromium. profileEngine()
    // là cùng một quy tắc mà launcher dùng để chọn nhân (xem data/browser-badge.js), nên
    // icon không thể nói khác thứ sẽ thực sự mở lên.
    const engIcon = icon(profileEngine(p) === 'firefox' ? 'firefox' : 'chrome');
    const openBtn = gateBtn(el('button.btn.primary.sm.glow', { html: `${engIcon}<span>Mở</span>`, onclick: () => openProfile(p) }), !EXPIRED, PERM_MSG.expired);
    const closeBtn = el('button.btn.danger-mix.sm.glow', { html: `${engIcon}<span>Đóng</span>`, onclick: () => closeProfile(p) });
    const showBtn = el('button.icon-btn', { html: icon('windowFull'), title: 'Hiển thị cửa sổ', onclick: () => remote.profiles.show(p.id) });
    const kebab = el('button.icon-btn.kebab', { html: icon('moreVertical') });
    hoverMenu(kebab, () => rowMenuItems(p));
    // Trạng thái nút cell "Hành động" theo 3 pha:
    //   • ĐANG MỞ  → đã bấm mở nhưng cửa sổ CHƯA thực sự lên (còn trong `opening` cho tới khi
    //                tiến trình browser spawn xong, hoặc đang kéo dữ liệu từ cloud về). Hiện
    //                spinner "Đang mở", KHÔNG lật sang "Đóng" sớm (lỗi cũ: nút đổi ngay lúc bấm
    //                dù cửa sổ chưa lên gì, do đặt p.running=true lạc quan).
    //   • ĐANG ĐÓNG → cửa sổ đã tắt, đang nén + đẩy lên cloud. Spinner "Đang đóng".
    //   • BÌNH THƯỜNG → Mở (chưa chạy) / Đóng (đang chạy).
    const sy = syncing.get(p.id);
    const syncActive = sy && sy.phase && sy.phase !== 'idle' && sy.phase !== 'done' && sy.phase !== 'error';
    const openingPhase = syncActive && (sy.phase === 'download' || sy.phase === 'unpack');
    const isOpening = opening.has(p.id) || openingPhase;
    // Đang đóng-êm: cửa sổ đã tắt nhưng cookie/phiên CHƯA flush xong. Giữ spinner "Đang lưu"
    // và KHÔNG hiện nút "Mở" cho tới khi main báo lưu xong (rời khỏi tập `closing`).
    const isClosing = closing.has(p.id) && !isOpening;
    const spinnerBtn = (label) => el('button.btn.sm.syncing-btn', {
      disabled: true, title: label, html: `${icon('sync')}<span>${label}</span>`,
    });
    let rowBtns;
    if (isOpening) {
      // Cửa sổ chưa xác nhận lên → chỉ spinner "Đang mở" (+ kebab); chưa cho "Đóng"/"Hiển thị".
      rowBtns = [spinnerBtn(syncActive ? syncLabel(sy.phase) : 'Đang mở'), kebab];
    } else if (isClosing) {
      // Đang lưu cookie sau khi đóng → spinner "Đang đóng" (+ kebab); chưa cho mở lại.
      // KHÔNG dùng thuộc tính `disabled` (nó tắt hover/cursor): giữ nút enable + class
      // .closing-btn để trình duyệt hiện con trỏ CẤM (not-allowed) khi rê chuột. Nút không có
      // onclick, và ta nuốt click ở pha capture cho chắc.
      const closingBtn = el('button.btn.sm.syncing-btn.closing-btn', {
        title: 'Đang đóng', html: `${icon('sync')}<span>Đang đóng</span>`,
      });
      closingBtn.addEventListener('click', (e) => { e.stopImmediatePropagation(); e.preventDefault(); }, true);
      rowBtns = [closingBtn, kebab];
    } else if (syncActive) {
      // Pha đóng (pack/upload) sau khi cửa sổ đã tắt.
      const syncBtn = spinnerBtn(syncLabel(sy.phase));
      rowBtns = p.running ? [syncBtn, showBtn, kebab] : [syncBtn, kebab];
    } else {
      rowBtns = p.running ? [closeBtn, showBtn, kebab] : [openBtn, kebab];
    }
    const actionCell = el('td.col-action', {}, [el('div.row-actions', {}, rowBtns)]);

    return el('tr', {}, [el('td.col-check', {}, [cb]), nameCell, noteCell, tagCell, ipCell, lastRunCell, storageCell, createdCell, actionCell]);
  }

  // Xóa cookie của 1 hồ sơ: xác nhận rồi gọi backend (CDP nếu đang mở, xóa file nếu đã đóng).
  function clearProfileCookies(p) {
    confirmDialog({
      title: 'Xóa cookie',
      message: tf('Xóa toàn bộ cookie của hồ sơ “{0}”? Bạn sẽ phải đăng nhập lại các trang.', p.name || p.id),
      danger: true,
      confirmLabel: 'Xóa cookie',
      onConfirm: async () => {
        const r = await remote.profiles.clearCookies(p.id);
        if (r && r.ok) toast('Đã xóa cookie', 'ok');
        else notifyError(new Error((r && r.error) || 'unknown'), 'Xóa cookie thất bại');
      },
    });
  }

  // Xóa bộ nhớ đệm (cache) của 1 hồ sơ: xác nhận rồi gọi backend.
  function clearProfileCache(p) {
    confirmDialog({
      title: 'Xóa bộ nhớ đệm',
      message: tf('Xóa toàn bộ bộ nhớ đệm của hồ sơ “{0}”?', p.name || p.id),
      danger: true,
      confirmLabel: 'Xóa bộ nhớ đệm',
      onConfirm: async () => {
        const r = await remote.profiles.clearCache(p.id);
        if (r && r.ok) toast('Đã xóa bộ nhớ đệm', 'ok');
        else notifyError(new Error((r && r.error) || 'unknown'), 'Xóa bộ nhớ đệm thất bại');
      },
    });
  }

  function rowMenuItems(p) {
    // Quyền THEO TỪNG HỒ SƠ (hồ sơ chia sẻ riêng bị khoá đúng dù người dùng thuộc nhóm
    // quyền rộng). Mục sửa/xóa/nhân bản/chuyển nhóm khóa mềm; mở/xem luôn dùng được.
    const pp = perProfilePerm(p.id);
    // Hết hạn thuê bao → khoá cứng mọi mục ghi (kể cả chủ/đủ quyền), nhắc gia hạn.
    // Khoá ở đây để tránh mở màn/bắn request rồi mới ăn 403 làm lag metadata.
    const wr = (allowed, msg) => EXPIRED ? { disabled: true, title: PERM_MSG.expired } : { disabled: !allowed, title: allowed ? '' : msg };
    return [
      { label: 'Chỉnh sửa', icon: 'edit', ...wr(pp.editAny, PERM_MSG.edit), onClick: () => ctx.navigate('profile_create', p.id) },
      // Cùng một modal với mục "Chỉnh sửa tiện ích" trong menu "Thêm" (hàng loạt), chỉ truyền
      // đúng MỘT id - KHÔNG tách hàm riêng để hai lối vào không bao giờ lệch ngữ nghĩa
      // fp.ui.extensions. Khoá cùng quyền editAny như mục "Chỉnh sửa" vì nó ghi vào vân tay.
      { label: 'Chỉnh sửa tiện ích', icon: 'extensions', ...wr(pp.editAny, PERM_MSG.edit), onClick: () => bulkSetExtensions([p.id]) },
      { label: 'Nhân bản', icon: 'copy', ...wr(pp.dupe, PERM_MSG.dupe), onClick: async () => { try { await remote.profiles.duplicate(p.id); await loadProfiles(); await loadGroups(); toast('Đã nhân bản', 'ok'); } catch (e) { notifyError(e, 'Nhân bản hồ sơ thất bại'); } } },
      { label: 'Xóa cookie', icon: 'cloudOff', ...wr(pp.editAny, PERM_MSG.edit), onClick: () => clearProfileCookies(p) },
      { label: 'Xóa bộ nhớ đệm', icon: 'cacheClear', ...wr(pp.editAny, PERM_MSG.edit), onClick: () => clearProfileCache(p) },
      { label: 'Chuyển nhóm', icon: 'folderMove', ...wr(pp.move, PERM_MSG.move), onClick: () => moveToGroup([p.id]) },
      // Ghim KHÔNG qua wr(): nó chỉ đổi cách sắp xếp trên MÁY NÀY, không ghi gì lên hồ sơ
      // nên cả người chỉ-xem lẫn thuê bao hết hạn đều dùng được.
      { label: isPinned(p.id) ? 'Bỏ ghim đầu trang' : 'Ghim đầu trang', icon: 'pin',
        onClick: () => setPinned([p.id], !isPinned(p.id)) },
      '-',
      { label: 'Xóa', icon: 'trash', danger: true, ...wr(pp.del, PERM_MSG.del), onClick: () => deleteProfiles([p.id]) },
    ];
  }

  function renderPager(pages) {
    clear(pageNumbers);
    for (let i = 0; i < pages; i++) {
      if (pages > 7 && i > 1 && i < pages - 2 && Math.abs(i - page) > 1) {
        if (i === 2 || i === pages - 3) pageNumbers.appendChild(el('span.muted', { text: '…' }));
        continue;
      }
      pageNumbers.appendChild(el('button.page-num' + (i === page ? '.active' : ''), { text: String(i + 1), onclick: () => { page = i; renderPage(); } }));
    }
  }

  function syncSelAll() {
    const slice = filtered.slice(page * pageSize, page * pageSize + pageSize);
    selectAll.checked = slice.length > 0 && slice.every((p) => selected.has(p.id));
  }
  function updateSelUi() {
    const n = selected.size;
    selChip.style.display = n ? 'inline-flex' : 'none';
    selChip.textContent = tf('Đã chọn {0}/{1}', n, filtered.length);
    // Toolbar is always visible now; only the "Đã chọn n/total" chip reacts.
  }

  // Nhãn ngắn cho từng pha đồng bộ (hiện trên nút "đang xử lý").
  // Gộp các pha đồng bộ chi tiết thành 2 trạng thái đơn giản kèm icon xoay:
  //   • MỞ  (download/unpack - kéo dữ liệu từ cloud về trước khi mở) → "Đang mở…"
  //   • ĐÓNG (pack/upload - nén + đẩy lên cloud sau khi đóng)        → "Đang đóng…"
  function syncLabel(phase) {
    switch (phase) {
      case 'download':
      case 'unpack':
        return 'Đang mở';
      case 'pack':
      case 'upload':
        return 'Đang đóng';
      default:
        return 'Đang đồng bộ';
    }
  }

  // Nhãn + trạng thái cloud cho cell "storage" từ giá trị storage của hồ sơ.
  // storage lưu TÊN ĐÍCH đã đồng bộ (telegram|gdrive|s3) → hiện đúng tên; 'cloud' (dữ liệu
  // cũ chưa rõ đích) → "Cloud"; rỗng/'local' → "Local".
  const STORAGE_LABELS = { telegram: 'Telegram', gdrive: 'Google Drive', s3: 'S3', cloud: 'Cloud' };
  function storageBadge(storage) {
    const st = storage || 'local';
    if (!st || st === 'local') return { cloud: false, label: 'Local' };
    return { cloud: true, label: STORAGE_LABELS[st] || 'Cloud' };
  }

  // -------------------------------------------------- open / close
  async function openProfile(p) {
    // Đang lưu cookie sau khi đóng (chưa flush xong) → CHẶN mở lại lặng lẽ: nút đã disabled +
    // cursor not-allowed, đây chỉ là chốt an toàn cuối (mở lúc này = spawn đè khi cookie chưa
    // kịp ghi = mất cookie). Không toast.
    if (closing.has(p.id)) return;
    // Hết hạn thuê bao = điều kiện ĐẦU TIÊN: không cho MỞ hồ sơ (dù còn số dư). Nhắc Gia hạn.
    if (!(await gateNotExpired({ navigate: ctx.navigate }))) return;
    // Phương án B (bản thương mại): PHẢI có nhân đã cài mới mở. Chưa có → mở modal tải
    // (có thể huỷ). Huỷ / không tải được → dừng, KHÔNG fallback vendor/hệ thống.
    if (!p.running && !(await ensureKernelReady('chromium'))) return;
    // Optimistic: flip the button to the running state on click. Real status (from the
    // main-process push) reconciles this once the browser actually spawns.
    opening.add(p.id);
    p.running = true;
    renderPage();
    let r;
    try { r = await remote.profiles.open(p.id); } catch { r = { ok: false }; }
    if (!r || !r.ok) {
      opening.delete(p.id);
      p.running = false;
      renderPage();
      return toast((r && r.error) || 'Không mở được trình duyệt', 'error');
    }
    toast('Đang mở ' + p.name, 'ok');
    // Sau khi khởi chạy → lấy IP/geo qua ipinfo.io rồi refresh cell "IP".
    remote.profiles.checkIp(p.id).then((res) => { if (res && res.ok) loadProfiles(); }).catch(() => {});
  }

  // Spin a refresh button's icon while its async action runs - a loading
  // affordance so a click on "làm mới" / "Kiểm tra proxy" visibly shows progress.
  // Adds .spinning (CSS rotates the inner svg) until fn() settles, with a small
  // floor so a near-instant refresh still flashes the spinner rather than blinking.
  async function spinWhile(btn, fn) {
    if (btn) btn.classList.add('spinning');
    const started = Date.now();
    try {
      await fn();
    } finally {
      const elapsed = Date.now() - started;
      const finish = () => { if (btn) btn.classList.remove('spinning'); };
      if (elapsed < 450) setTimeout(finish, 450 - elapsed); else finish();
    }
  }

  // Manual "Kiểm tra proxy" - làm mới IP/geo. Có proxy → tra IP thoát của proxy;
  // KHÔNG proxy → tra public IP máy thật (handler checkIp xử lý proxy=null bằng
  // geo.lookup trực tiếp). Trước đây chặn khi không proxy nên cell "IP" của hồ sơ
  // không proxy kẹt ở geo cũ đã lưu (vd "Da Nang") và không bao giờ cập nhật lại.
  async function checkProxy(p) {
    toast('Đang kiểm tra IP…');
    let res;
    try { res = await remote.profiles.checkIp(p.id); } catch { res = null; }
    if (res && res.ok) { toast('Đã cập nhật IP', 'ok'); await loadProfiles(); }
    else toast('Không lấy được IP (kiểm tra proxy/mạng)', 'err');
  }

  // "Vị trí IP" - show the cached geo detail.
  function showLocation(p) {
    if (!p.geoIp && !p.geoCountry) return toast('Chưa có dữ liệu IP, hãy bấm "Kiểm tra proxy" trước', 'warn');
    const parts = [p.geoIp, p.geoCity, p.geoRegion, p.geoCountry].filter(Boolean);
    toast(parts.join(' · ') || 'Không có dữ liệu', 'ok');
  }
  async function closeProfile(p) {
    // Lạc quan: chuyển ngay sang trạng thái "Đang lưu" (spinner) để nút không nháy về "Mở"
    // trong lúc chờ main flush cookie. main sẽ xác nhận qua onClosingChanged rồi tự gỡ khi
    // lưu xong. Chỉ đặt cờ khi có kênh đẩy closing (nếu không sẽ kẹt loading) - applyClosing
    // là nguồn sự thật cuối cùng.
    if (closingSupported) { closing.add(p.id); p.running = false; renderPage(); }
    await remote.profiles.close(p.id);
    toast('Đã đóng ' + p.name);
    setTimeout(loadProfiles, 400);
  }

  // -------------------------------------------------- edit modals
  function editCell(p, key, label) {
    let input;
    openModal({ title: 'Chỉnh sửa ' + label.toLowerCase(),
      body: [el('div.field', {}, [el('label', { text: label }), (input = el('input.input', { value: p[key] || '' }))])],
      footer: [el('button.btn', { text: 'Hủy', onclick: closeModal }),
        el('button.btn.primary', { text: 'Lưu', onclick: async () => { const v = input.value.trim(); closeModal(); try { await remote.profiles.updateDynamic(p.id, { [key]: v }); await loadProfiles(); } catch (e) { notifyError(e, 'Lưu ' + label.toLowerCase() + ' thất bại'); } } })],
    });
    setTimeout(() => input.focus(), 30);
  }

  // Renders a profile's tags as chips inside the grid cell (falls back to -).
  function tagsDisplay(p) {
    const tags = profileTagList(p);
    if (!tags.length) return el('span.muted', { text: '-' });
    return el('div.cell-tags', {}, tags.map((t) => el('span.chip.tag-chip.' + tagColorClass(t), { text: t })));
  }

  // Ghi chú trong lưới: bọc thành CHIP không viền, ăn luôn bộ 6 màu của thẻ.
  // Dùng ĐÚNG cặp lớp của thẻ (.tag-chip + .tag-cN) chứ không tự định nghĩa màu riêng, để
  // hai cột "Ghi chú"/"Thẻ" không bao giờ lệch tông khi ai đó đổi bảng màu.
  // Màu trông như ngẫu nhiên nhưng ỔN ĐỊNH: tagColorClass() băm nội dung, nên một ghi chú
  // luôn ra cùng một màu (không nhảy màu mỗi lần vẽ lại lưới, không đổi khi sang trang).
  // Rỗng thì vẫn trả dấu "-" TRƠN, đúng như tagsDisplay() - bọc chip quanh một dấu gạch
  // nhìn như ô đang có dữ liệu.
  // title = nguyên văn ghi chú: đây là văn bản TỰ DO (dài, có thể nhiều dòng) khác hẳn thẻ
  // luôn ngắn, nên chip phải cắt bằng ellipsis và chỉ hover mới đọc được đủ.
  function noteDisplay(p) {
    const s = String(p.note || '').trim();
    if (!s) return el('span.muted', { text: '-' });
    return el('span.chip.tag-chip.' + tagColorClass(s) + '.note-chip', { text: s, title: s });
  }

  // Tag editor - a multi-select combobox (mirrors MKTLogin's "Thêm thẻ"): the
  // field shows the chosen tags as chips; opening it reveals an input to mint a
  // new tag plus the list of every existing tag (union of all profiles' tags +
  // standalone tags saved in settings) to toggle on/off.
  // Bộ chọn thẻ dùng chung - dùng cho cả sửa 1 hồ sơ (editTags) lẫn cập nhật hàng
  // loạt (bulkEditTags). initial = mảng thẻ ban đầu; onSave nhận mảng thẻ đã chọn.
  async function openTagEditor({ title = 'Thêm thẻ', initial = [], onSave }) {
    // Thẻ độc lập lấy TỪ SERVER (remote.tags) thay cho settings local.
    let customTags = await remote.tags.list();
    const known = new Set(customTags);
    profiles.forEach((pp) => profileTagList(pp).forEach((t) => known.add(t)));
    let allTags = [...known].sort((a, b) => a.localeCompare(b));
    const current = new Set(initial);

    const sel = el('div.tagsel');
    const trigger = el('div.tagsel-trigger', { tabindex: '0' });
    const panel = el('div.tagsel-panel');
    const optList = el('div.tagsel-opts');
    let addInput;

    function renderTrigger() {
      clear(trigger);
      const chips = el('div.tagsel-chips');
      if (current.size) {
        [...current].forEach((t) => chips.appendChild(el('span.tagsel-chip', {}, [
          el('span', { text: t }),
          el('button.tagsel-x', { type: 'button', html: icon('close'), onclick: (e) => { e.stopPropagation(); current.delete(t); renderTrigger(); renderOpts(); } }),
        ])));
      } else {
        chips.appendChild(el('span.tagsel-ph', { text: '+ Chọn thẻ' }));
      }
      trigger.appendChild(chips);
      trigger.appendChild(el('span.tagsel-chev', { html: icon('chevronDown') }));
    }

    function renderOpts() {
      clear(optList);
      const q = (addInput && addInput.value.trim().toLowerCase()) || '';
      const rows = allTags.filter((t) => !q || t.toLowerCase().includes(q));
      if (!rows.length) { optList.appendChild(el('div.tagsel-empty.muted', { text: q ? 'Không có thẻ khớp' : 'Chưa có thẻ nào' })); return; }
      rows.forEach((t) => {
        const on = current.has(t);
        optList.appendChild(el('div.tagsel-opt' + (on ? '.sel' : ''), {
          onclick: () => { on ? current.delete(t) : current.add(t); renderTrigger(); renderOpts(); },
        }, [el('span.tagsel-opt-lbl', { text: t }), on ? el('span.tagsel-ck', { html: icon('check') }) : null]));
      });
    }

    function addNew() {
      const v = addInput.value.trim(); if (!v) return;
      if (!allTags.includes(v)) { allTags.push(v); allTags.sort((a, b) => a.localeCompare(b)); customTags.push(v); remote.tags.create(v).catch((e) => notifyError(e, 'Tạo thẻ thất bại')); }
      current.add(v); addInput.value = ''; renderTrigger(); renderOpts(); addInput.focus();
    }

    addInput = el('input.tagsel-add-input', { placeholder: 'Nhập giá trị để thêm thẻ mới',
      oninput: () => renderOpts(),
      onkeydown: (e) => { if (e.key === 'Enter') { e.preventDefault(); addNew(); } } });
    panel.appendChild(el('div.tagsel-add', {}, [
      el('span.tagsel-add-ico', { html: icon('plus') }),
      addInput,
      el('button.tagsel-addbtn', { type: 'button', html: `<span>Thêm thẻ</span><span class="ent">↵</span>`, onclick: addNew }),
    ]));
    panel.appendChild(el('div.tagsel-div'));
    panel.appendChild(optList);

    const onDoc = (e) => { if (!sel.contains(e.target)) close(); };
    function open() { sel.classList.add('open'); renderOpts(); setTimeout(() => addInput.focus(), 0); document.addEventListener('mousedown', onDoc); }
    function close() { sel.classList.remove('open'); document.removeEventListener('mousedown', onDoc); }
    trigger.onclick = () => { sel.classList.contains('open') ? close() : open(); };

    sel.appendChild(trigger);
    sel.appendChild(panel);
    renderTrigger();

    openModal({ title,
      body: [el('div.field', {}, [sel])],
      footer: [el('button.btn', { text: 'Hủy', onclick: () => { close(); closeModal(); } }),
        el('button.btn.primary', { text: 'Lưu', onclick: async () => {
          close(); closeModal();
          await onSave([...current]);
        } })],
    });
  }
  // Sửa thẻ 1 hồ sơ (từ cell "Thẻ" trong lưới).
  function editTags(p) {
    return openTagEditor({ title: 'Thêm thẻ', initial: profileTagList(p),
      onSave: async (tags) => { try { await remote.profiles.updateDynamic(p.id, { tags: tags.join(', ') }); await loadProfiles(); } catch (e) { notifyError(e, 'Cập nhật thẻ thất bại'); } } });
  }
  // "Cập nhật thẻ" hàng loạt - chọn bộ thẻ rồi áp cho tất cả hồ sơ đã chọn.
  function bulkEditTags(ids) {
    return openTagEditor({ title: 'Cập nhật thẻ', initial: [],
      onSave: async (tags) => {
        try {
          for (const id of ids) await remote.profiles.updateDynamic(id, { tags: tags.join(', ') });
          await loadProfiles();
          toast(`${t('Đã cập nhật thẻ cho')} ${ids.length} ${t('hồ sơ')}`, 'ok');
        } catch (e) { await loadProfiles(); notifyError(e, 'Cập nhật thẻ hàng loạt thất bại'); }
      } });
  }
  // "Cập nhật ghi chú" hàng loạt - nhập ghi chú chung rồi áp cho tất cả hồ sơ đã chọn.
  function bulkEditNote(ids) {
    let input;
    openModal({ title: 'Cập nhật ghi chú',
      body: [el('div.field', {}, [
        el('label', { text: `${t('Ghi chú (áp cho')} ${ids.length} ${t('hồ sơ đã chọn')})` }),
        (input = el('textarea.input', { style: { minHeight: '110px', resize: 'vertical' }, placeholder: 'Nhập ghi chú…' })),
      ])],
      footer: [el('button.btn', { text: 'Hủy', onclick: closeModal }),
        el('button.btn.primary', { text: 'Cập nhật', onclick: async (e) => {
          const note = input.value.trim();
          try {
            await withSpin(e.currentTarget, async () => {
              for (const id of ids) await remote.profiles.updateDynamic(id, { note });
            });
            closeModal();
            await loadProfiles();
            toast(`${t('Đã cập nhật ghi chú cho')} ${ids.length} ${t('hồ sơ')}`, 'ok');
          } catch (err) { closeModal(); await loadProfiles(); notifyError(err, 'Cập nhật ghi chú thất bại'); }
        } })],
    });
  }
  // "Xóa thẻ" hàng loạt - xóa sạch thẻ của các hồ sơ đã chọn (có xác nhận).
  function bulkClearTags(ids) {
    confirmDialog({ title: 'Xóa thẻ', danger: true, confirmLabel: 'Xóa',
      message: `${t('Xóa toàn bộ thẻ của')} ${ids.length} ${t('hồ sơ đã chọn')}?`,
      onConfirm: async () => {
        try {
          for (const id of ids) await remote.profiles.updateDynamic(id, { tags: '' });
          await loadProfiles();
          toast(`${t('Đã xóa thẻ của')} ${ids.length} ${t('hồ sơ')}`, 'ok');
        } catch (e) { await loadProfiles(); notifyError(e, 'Xóa thẻ thất bại'); }
      } });
  }
  // "Xóa ghi chú" hàng loạt - xóa sạch ghi chú của các hồ sơ đã chọn (có xác nhận).
  function bulkClearNote(ids) {
    confirmDialog({ title: 'Xóa ghi chú', danger: true, confirmLabel: 'Xóa',
      message: `${t('Xóa toàn bộ ghi chú của')} ${ids.length} ${t('hồ sơ đã chọn')}?`,
      onConfirm: async () => {
        try {
          for (const id of ids) await remote.profiles.updateDynamic(id, { note: '' });
          await loadProfiles();
          toast(`${t('Đã xóa ghi chú của')} ${ids.length} ${t('hồ sơ')}`, 'ok');
        } catch (e) { await loadProfiles(); notifyError(e, 'Xóa ghi chú thất bại'); }
      } });
  }
  // "Xóa bộ nhớ đệm" hàng loạt - bản nhiều hồ sơ của clearProfileCache().
  // KHÁC các bulk ở trên: remote.profiles.clearCache() KHÔNG ném lỗi, nó trả { ok:false,
  // error } cho từng hồ sơ (hồ sơ Firefox đang mở là không xoá được). Nên phải ĐẾM
  // ok/lỗi và chạy hết danh sách, chứ không try/catch một cục rồi dừng ở hồ sơ đầu tiên.
  // Cũng KHÔNG gọi loadProfiles(): xoá cache chẳng đổi metadata nào của hồ sơ.
  function bulkClearCache(ids) {
    confirmDialog({ title: 'Xóa bộ nhớ đệm', danger: true, confirmLabel: 'Xóa bộ nhớ đệm',
      message: `${t('Xóa toàn bộ bộ nhớ đệm của')} ${ids.length} ${t('hồ sơ đã chọn')}?`,
      onConfirm: async () => {
        toast('Đang xóa bộ nhớ đệm…');
        let done = 0; let failed = 0; let lastErr = '';
        for (const id of ids) {
          let r = null;
          try { r = await remote.profiles.clearCache(id); } catch (e) { r = { ok: false, error: (e && e.message) || String(e) }; }
          if (r && r.ok) done++;
          else { failed++; lastErr = (r && r.error) || lastErr; }
        }
        // Không hồ sơ nào xoá được ⇒ báo LỖI kèm nguyên văn lý do từ main (thường là
        // "hồ sơ Firefox đang mở"), đừng chỉ nói "0/3" rồi để người dùng tự đoán.
        if (!done) return notifyError(new Error(lastErr || 'unknown'), 'Xóa bộ nhớ đệm thất bại');
        const bits = [`${t('Đã xóa bộ nhớ đệm của')} ${done}/${ids.length} ${t('hồ sơ')}`];
        if (failed) bits.push(`${t('lỗi')} ${failed}`);
        toast(bits.join(' · '), failed ? 'warn' : 'ok');
      } });
  }

  function editProxy(p) {
    let typeSel, host, port, user, pass, token, detail, tokenBox;
    // Token KHÔNG có host:port - nó là một chuỗi do nhà cung cấp phát. Nên combobox đổi
    // sang 'Token' thì ẩn khối host/port/user/pass và hiện ô token (giống tab "Proxy token"
    // ở trang tạo hồ sơ). Trước đây chọn 'Token' chỉ ẩn hết mọi ô, không có chỗ nào nhập -
    // tức item đó vô dụng.
    const refresh = () => {
      const isToken = typeSel.value === 'Token';
      detail.style.display = isToken ? 'none' : 'block';
      tokenBox.style.display = isToken ? 'block' : 'none';
    };
    // CHỈ modal này (bấm icon chỉnh sửa proxy ở cell) có thêm item "Không dùng proxy" ở
    // ĐẦU danh sách - là lối tắt công tắc tắt ngay trong combobox (value rỗng = công tắc
    // tắt, giữ nguyên host/port). KHÔNG đụng PROXY_TYPES (nguồn dùng chung cho 6 combobox
    // kia): prepend vào một mảng CỤC BỘ, không mutate mảng gốc.
    // ⚠ Nhãn PHẢI trùng khoá từ điển sẵn có 'Không dùng proxy' (i18n.js) - customSelect
    // chạy t(label) nên viết hoa 'Proxy' là mất bản dịch (đứng nguyên tiếng Việt ở en/ru/zh).
    const typeOptions = [{ value: '', label: 'Không dùng proxy' }, ...PROXY_TYPES];
    // Hồ sơ đang TẮT proxy (proxyType rỗng) thì chọn sẵn "Không dùng proxy"; ngược lại
    // normalizeProxyType quy giá trị cũ/lạ ('Proxy Xoay','https'...) về đúng 4 item.
    const typeInit = p.proxyType ? normalizeProxyType(p.proxyType) : '';
    openModal({ title: 'Cập nhật proxy',
      body: [
        el('div.field', {}, [el('label', { text: 'Loại proxy' }), (typeSel = customSelect(typeOptions, { value: typeInit, onChange: () => refresh() }))]),
        (detail = el('div', {}, [
          el('div.field-row', {}, [
            el('div.field', {}, [el('label', { text: 'Host' }), (host = el('input.input', { value: p.proxyHost || '' }))]),
            el('div.field', {}, [el('label', { text: 'Port' }), (port = el('input.input', { value: p.proxyPort || '' }))]),
          ]),
          el('div.field', {}, [el('label', { text: 'User' }), (user = el('input.input', { value: p.proxyUser || '' }))]),
          el('div.field', {}, [el('label', { text: 'Pass' }), (pass = el('input.input', { value: p.proxyPass || '' }))]),
        ])),
        (tokenBox = el('div.field', {}, [el('label', { text: 'Proxy token' }),
          (token = el('input.input', { value: p.proxyToken || '', placeholder: 'Proxy token' }))])),
      ],
      footer: [el('button.btn', { text: 'Hủy', onclick: closeModal }),
        el('button.btn.primary', { text: 'Cập nhật', onclick: async () => {
          const tv = typeSel.value;
          closeModal();
          // Lưu HẾT những gì đang có trong các ô, bất kể loại đang chọn: đổi qua Token rồi
          // đổi về HTTP phải thấy lại host/port cũ, và ngược lại. Ta chỉ thêm/sửa, không xoá.
          //
          // Chọn "Không dùng proxy" ⇒ tv === '' ⇒ lưu proxyType rỗng = công tắc TẮT (giữ
          // nguyên host/port; db.getProfileProxyConfig trả null khi type rỗng). Đây là lối
          // tắt tương đương lệnh "Không dùng proxy" trong menu hồ sơ (resetProxy()).
          try {
            await remote.profiles.updateDynamic(p.id, {
              proxyType: tv,
              proxyHost: host.value.trim(),
              proxyPort: port.value.trim(),
              proxyUser: user.value.trim(),
              proxyPass: pass.value.trim(),
              proxyToken: token.value.trim(),
            });
            await loadProfiles();
          } catch (e) { notifyError(e, 'Cập nhật proxy thất bại'); }
        } })],
    });
    refresh();
  }

  // "Cập nhật proxy" hàng loạt - modal thiết kế tương tự add-page ở "Proxies":
  // chọn "Loại proxy" + dán danh sách proxy (mỗi dòng 1 proxy). Gán lần lượt cho các
  // hồ sơ đã chọn (1 dòng = 1 hồ sơ, thiếu dòng thì lặp lại vòng; 1 dòng = áp cho tất cả).
  function updateProxyBulk(ids) {
    let typeSel, listBox;
    // Gợi ý trong textarea phải theo loại đang chọn: Token thì không có host:port để dán.
    const HINT_HOSTPORT = [
      'host:port:user:pass hoặc host:port  (mỗi dòng 1 proxy)',
      'Ví dụ:',
      '45.76.120.33:8080:username:password',
      '45.76.120.33:8080',
    ].join('\n');
    const HINT_TOKEN = 'Mỗi dòng 1 proxy token';
    const syncHint = () => {
      if (listBox) listBox.placeholder = t(typeSel.value === 'Token' ? HINT_TOKEN : HINT_HOSTPORT);
    };
    openModal({ title: 'Cập nhật proxy',
      body: [el('div.px-form', {}, [
        el('div.field', {}, [el('label', { text: 'Loại proxy' }),
          (typeSel = customSelect(PROXY_TYPES, { value: PROXY_TYPE_DEFAULT, width: '100%', onChange: () => syncHint() }))]),
        el('div.field', {}, [
          el('label', { text: `${t('Danh sách proxy (áp cho')} ${ids.length} ${t('hồ sơ đã chọn')})` }),
          (listBox = el('textarea.input.px-addlist', { placeholder: HINT_HOSTPORT })),
        ]),
      ])],
      footer: [el('button.btn', { text: 'Hủy', onclick: closeModal }),
        el('button.btn.primary', { text: 'Cập nhật', onclick: async (e) => {
          const enumType = typeSel.value;
          // Token = mỗi dòng MỘT token (không có host:port để tách), nên không đi qua
          // parseProxyLine - dòng nào cũng là token nguyên văn.
          const lines = enumType === 'Token'
            ? (listBox.value || '').split('\n').map((ln) => ln.trim()).filter(Boolean)
              .map((tok) => ({ proxyType: 'Token', proxyToken: tok }))
            // parseProxyLine (dùng chung) trả sẵn {proxyType, proxyHost, proxyPort, proxyUser,
            // proxyPass}; loại lấy theo scheme trong dòng, mặc định = loại đã chọn ở modal.
            : (listBox.value || '').split('\n').map((ln) => parseProxyLine(ln, enumType)).filter(Boolean);
          if (!lines.length) return toast('Vui lòng nhập ít nhất 1 proxy hợp lệ', 'warn');
          // Đổi proxy → geo cũ (IP thoát proxy trước) đã lỗi thời; reset để cell IP làm mới.
          const geoReset = { geoIp: '', geoCountry: '', geoRegion: '', geoCity: '' };
          await withSpin(e.currentTarget, async () => {
            for (let i = 0; i < ids.length; i++) {
              await remote.profiles.updateDynamic(ids[i], { ...lines[i % lines.length], ...geoReset });
            }
          });
          closeModal();
          await loadProfiles();
          toast(`${t('Đã cập nhật proxy cho')} ${ids.length} ${t('hồ sơ')}`, 'ok');
        } })],
    });
  }

  function moveToGroup(ids) {
    let sel;
    openModal({ title: 'Chuyển nhóm',
      body: [el('div.field', {}, [el('label', { text: 'Nhóm đích' }), (sel = customSelect(
        [{ value: '', label: 'Không có nhóm' }, ...groups.map((g) => ({ value: g.id, label: g.name }))], { value: '' },
      ))])],
      footer: [el('button.btn', { text: 'Hủy', onclick: closeModal }),
        el('button.btn.primary', { text: 'Chuyển', onclick: async () => { closeModal(); try { await remote.profiles.move(ids, sel.value || null); await loadProfiles(); await loadGroups(); selected.clear(); toast('Đã chuyển nhóm', 'ok'); } catch (e) { notifyError(e, 'Chuyển nhóm thất bại'); } } })],
    });
  }

  // Chia sẻ hồ sơ đã chọn qua email. `ids` = 1 hồ sơ (từ kebab) hoặc nhiều hồ sơ.
  // Người dùng nhập email + chọn mức quyền (Xem/Chỉnh sửa/Toàn quyền). Server chỉ
  // cho người có quyền 'profile:share' gọi (nhân viên bị 403 → notifyError).
  function openShareModal(ids) {
    const list = Array.isArray(ids) ? ids.filter(Boolean) : [];
    if (!list.length) return toast('Chưa chọn hồ sơ nào', 'warn');
    // Cổng gói: "Chia sẻ" là tính năng trả phí → gói Free hiện modal nâng cấp.
    if (!hasFeature('share')) { gateFeature('share', { navigate: ctx.navigate }); return; }
    let input;
    const many = list.length > 1;
    const nameOf = (id) => { const p = profiles.find((x) => x.id === id); return (p && p.name) || id; };
    const subtitle = many
      ? tf('Chia sẻ {0} hồ sơ đã chọn qua email', list.length)
      : tf('Chia sẻ hồ sơ "{0}" qua email', nameOf(list[0]));

    // Bộ quyền tick sẵn = mức "Xem" (mở + xem ghi chú). Người dùng tùy chỉnh thêm.
    const perms = new Set(['profile:open', 'profile:show_note']);

    // Checkbox tùy chỉnh giống "Thành viên nhóm": 1 hàng danh mục (tick tất/indeterminate)
    // + các checkbox con. Dùng lại class .mem-access* để đồng bộ giao diện.
    const childCbs = [];
    const catCb = el('input', { type: 'checkbox' });
    const syncCat = () => {
      const on = SHARE_PERMS.filter((p) => perms.has(p.key)).length;
      catCb.checked = on === SHARE_PERMS.length && on > 0;
      catCb.indeterminate = on > 0 && on < SHARE_PERMS.length;
    };
    catCb.onchange = () => {
      SHARE_PERMS.forEach((p) => { catCb.checked ? perms.add(p.key) : perms.delete(p.key); });
      childCbs.forEach((cb) => { cb.checked = catCb.checked; });
      syncCat();
    };
    const permsWrap = el('div.mem-access-perms');
    SHARE_PERMS.forEach((p) => {
      const cb = el('input', { type: 'checkbox', checked: perms.has(p.key),
        onchange: (e) => { e.target.checked ? perms.add(p.key) : perms.delete(p.key); syncCat(); } });
      childCbs.push(cb);
      permsWrap.appendChild(el('label.mem-perm', {}, [cb, el('span', { text: p.label })]));
    });
    syncCat();
    const permGrid = el('div.mem-access', {}, [
      el('div.mem-access-row', {}, [
        el('label.mem-access-cat', {}, [catCb, el('span', { text: 'Quyền truy cập' })]),
        permsWrap,
      ]),
    ]);

    openModal({ title: 'Chia sẻ hồ sơ', sub: subtitle, width: 560,
      body: [
        el('div.field', {}, [
          el('label', { text: 'Email người nhận' }),
          (input = el('input.input', { type: 'email', placeholder: 'Nhập email người nhận' })),
        ]),
        el('div.field', {}, [
          el('label', { text: 'Quyền truy cập' }),
          permGrid,
        ]),
      ],
      footer: [
        el('button.btn', { text: 'Hủy', onclick: closeModal }),
        el('button.btn.primary', { text: 'Chia sẻ', onclick: async (e) => {
          const email = (input.value || '').trim().toLowerCase();
          if (!email || !email.includes('@')) { input.focus(); return toast('Email không hợp lệ', 'warn'); }
          const permissions = [...perms];
          if (!permissions.length) return toast('Hãy chọn ít nhất một quyền', 'warn');
          try {
            const body = many
              ? { profileIds: list, email, permissions }
              : { profileId: list[0], email, permissions };
            const res = await withSpin(e.currentTarget, () => remote.profileShares.create(body));
            closeModal();
            if (many && res && typeof res.shared === 'number') {
              toast(tf('Đã chia sẻ {0} hồ sơ', res.shared) + (res.skipped ? tf(', bỏ qua {0}', res.skipped) : ''), 'ok');
            } else {
              toast('Đã gửi lời chia sẻ', 'ok');
            }
          } catch (err) { notifyError(err, 'Chia sẻ hồ sơ thất bại', { title: 'Không thể chia sẻ' }); }
        } }),
      ],
    });
  }

  // Modal "Xóa hồ sơ" - HAI đường ra trong MỘT hộp thoại, chọn bằng ô tích:
  //   • không tích (mặc định) = xoá mềm vào thùng rác, còn khôi phục NGUYÊN VẸN được;
  //   • có tích = xoá VĨNH VIỄN ngay, bỏ qua thùng rác (cho người dùng không muốn phải
  //     vào trang Thùng rác làm thao tác thứ hai chỉ để dọn một hồ sơ rác).
  // Mặc định để ở nhánh AN TOÀN: nút "Xóa" không được âm thầm thành xoá vĩnh viễn.
  //
  // Vì sao nhánh vĩnh viễn phải gọi HAI lời gọi? Máy chủ (profiles.repo.hardDelete) lọc
  // `is_deleted = true`, nên hồ sơ CÒN SỐNG là vô hình với nó: gọi trash.hardDelete() thẳng
  // sẽ trả deleted=0 và im lặng không xoá gì. Phải xoá mềm trước rồi mới xoá hẳn - đúng
  // trình tự local-api.js hardDeleteProfile() đã dùng cho endpoint "Xoá hồ sơ (vĩnh viễn)".
  //
  // PHẢI đi qua remote.trash.hardDelete (remote-ds.js), KHÔNG gọi vt.remote.* trực tiếp:
  // đó là điểm duy nhất bumpPlan() ⇒ xoá vĩnh viễn là thao tác DUY NHẤT hoàn slot nên thẻ
  // gói phải giảm ngay, không chờ load lại. Nó cũng kích purgeProfileStorage ở main để thu
  // hồi thư mục hồ sơ trên đĩa.
  //
  // KHÔNG dùng confirmDialog được: body của nó cứng là một dòng chữ, không có chỗ cho ô tích.
  function deleteProfiles(ids) {
    // Hồ sơ đang mở sẽ bị ĐÓNG khi thu hồi đĩa (purgeProfileStorage kill tiến trình con rồi
    // mới xoá folder - Windows khoá tệp trong user-data-dir). Nói trước, thay vì để trình
    // duyệt của người dùng tắt đột ngột không rõ lý do.
    const runningCount = ids.filter((id) => {
      const p = profiles.find((x) => x.id === id);
      return !!(p && p.running);
    }).length;

    const permChk = el('input', { type: 'checkbox' });
    const question = el('div');
    // Dòng chữ ĐỎ (.del-warn, dùng chung khai báo với .grp-del-warn ở modal xoá nhóm): nói hệ
    // quả của lựa chọn đang chọn. Một dòng, ĐỔI CHỮ TẠI CHỖ theo ô tích - KHÔNG bung thêm khung
    // hay thêm/bớt phần tử, để modal không nhảy chiều cao khi tích (user đã bỏ khung cảnh báo).
    const warn = el('div.del-warn');
    const okBtn = el('button.btn.solid-red', { text: 'Xóa' });

    const paint = () => {
      const perm = permChk.checked;
      question.textContent = perm
        ? `${t('Xóa vĩnh viễn')} ${ids.length} ${t('hồ sơ? Không thể khôi phục.')}`
        : `${t('Chuyển')} ${ids.length} ${t('hồ sơ vào thùng rác?')}`;
      // Nhánh vĩnh viễn PHẢI phủ định rõ lời hứa 30 ngày ở nhánh kia - người dùng vừa đọc
      // "lưu giữ 30 ngày" xong, không được để họ tưởng vẫn còn đường lùi. Câu "hồ sơ đang mở
      // sẽ bị đóng" cũng để ở đây: đó là hệ quả không đoán được (purgeProfileStorage kill
      // tiến trình con rồi mới xoá folder - Windows khoá tệp trong user-data-dir).
      warn.textContent = perm
        ? t('Chú ý: Hồ sơ KHÔNG vào thùng rác. Toàn bộ dữ liệu trên máy bị xóa hẳn.')
          + (runningCount ? ' ' + tf('{0} hồ sơ đang mở sẽ bị đóng.', runningCount) : '')
        : t('Chú ý: Sau khi xóa, hồ sơ sẽ được chuyển vào thùng rác và lưu giữ trong vòng 30 ngày.');
      okBtn.textContent = t(perm ? 'Xóa vĩnh viễn' : 'Xóa');
    };
    permChk.onchange = paint;
    paint();

    okBtn.onclick = async (e) => {
      const perm = permChk.checked;
      try {
        // withSpin trả undefined nếu nút ĐANG chạy (chốt chống bấm đôi) - khi đó nó KHÔNG
        // gọi hàm bên trong, nên phải thoát chứ không được báo kết quả của lượt không chạy.
        const done = await withSpin(e.currentTarget, async () => {
          await remote.profiles.softDeleteBatch(ids);
          // Trả về SỐ hồ sơ xoá hẳn được (route trả { deleted }). Có thể nhỏ hơn số đã chọn
          // khi thành viên không có quyền xoá trên vài hồ sơ ⇒ phải nói ra, im lặng thì
          // người dùng tưởng đã dọn sạch mà hồ sơ vẫn nằm trong thùng rác và chiếm slot.
          return perm ? Number(await remote.trash.hardDelete(ids)) || 0 : ids.length;
        });
        if (done === undefined) return;
        closeModal();
        ids.forEach((id) => selected.delete(id));
        await loadProfiles();
        await loadGroups();
        const skipped = ids.length - done;
        if (!perm) toast('Đã chuyển vào thùng rác', 'ok');
        else if (skipped > 0) toast(tf('Đã xóa vĩnh viễn {0} hồ sơ', done) + tf(', bỏ qua {0}', skipped), 'warn');
        else toast('Đã xóa vĩnh viễn', 'ok');
      } catch (err) {
        // Xoá mềm xong mà xoá hẳn hỏng thì hồ sơ đã nằm ở thùng rác ⇒ vẫn phải nạp lại
        // danh sách, nếu không lưới còn hiện những hồ sơ không còn ở đây nữa.
        closeModal();
        await loadProfiles();
        await loadGroups();
        notifyError(err, perm ? 'Xóa vĩnh viễn thất bại' : 'Xóa hồ sơ thất bại');
      }
    };

    // Khoảng cách giữa 3 khối do .modal-body (flex column, gap 12px) lo - không tự thêm margin.
    // Thứ tự: câu hỏi → ô tích (thứ quyết định) → dòng đỏ giải thích hệ quả của lựa chọn đó.
    // sub (dưới tiêu đề "Xóa hồ sơ", cỡ 12.5px của .modal-head .sub): nhắc xoá vĩnh viễn là
    // thao tác DUY NHẤT hoàn slot (hoàn lại lượt tạo hồ sơ). Để ở TIÊU ĐỀ, KHÔNG xuống body.
    openModal({ title: 'Xóa hồ sơ',
      // Gói không hoàn lượt (gói Free khi admin tắt công tắc - cờ do refreshProfileCount ở app.js đặt) ⇒ KHÔNG hiện dòng phụ nào
      // (chủ sở hữu 2026-11-12: bỏ hẳn câu 'hoàn lại...'), còn hoàn thì giữ câu nhắc.
      sub: window.__polyRefundOnDelete === false ? undefined : 'Khi chọn xóa vĩnh viễn, bạn sẽ được hoàn lại lượt tạo hồ sơ.',
      body: [
        question,
        el('label.del-perm-row', {}, [permChk, el('span', { text: 'Xóa vĩnh viễn (không đưa vào thùng rác)' })]),
        warn,
      ],
      footer: [el('button.btn', { text: 'Hủy', onclick: closeModal }), okBtn],
    });
  }

  // Reset proxy cho các hồ sơ đã chọn - 2 chế độ:
  //   'disable' = KHÔNG DÙNG proxy: chỉ đặt proxyType='' (công tắc OFF), GIỮ lại
  //               host/port/user/pass để bật lại sau này.
  //   'remove'  = XÓA proxy ra khỏi hồ sơ: xoá sạch mọi trường proxy.
  // buildDynamic ở db.js drop các key rỗng nên profile trở về không dùng proxy.
  function resetProxy(ids, mode = 'remove') {
    const remove = mode === 'remove';
    // Xoá luôn geo đã resolve (geoIp/country/region/city) - đó là IP thoát của
    // proxy cũ, nên cell "IP" phải reset ngay thay vì hiện IP proxy đã bỏ.
    const geoReset = { geoIp: '', geoCountry: '', geoRegion: '', geoCity: '' };
    const changes = remove
      ? { proxyType: '', proxyHost: '', proxyPort: '', proxyUser: '', proxyPass: '', ...geoReset }
      : { proxyType: '', ...geoReset };
    const title = remove ? 'Xóa proxy ra khỏi hồ sơ' : 'Không dùng proxy';
    const question = remove
      ? `${t('Bạn có chắc chắn muốn xóa proxy của')} ${ids.length} ${t('hồ sơ đã chọn')}?`
      : `${t('Bạn có chắc chắn muốn ngừng dùng proxy cho')} ${ids.length} ${t('hồ sơ đã chọn')}?`;
    const noteText = remove
      ? 'Thao tác này sẽ xóa proxy ra khỏi các hồ sơ đã chọn. Bạn cần gán lại proxy nếu muốn dùng tiếp.'
      : 'Các hồ sơ sẽ ngừng dùng proxy nhưng vẫn giữ lại thông tin proxy để bật lại sau này.';
    openModal({ title,
      body: [
        el('div', { style: { marginBottom: '12px' }, text: question }),
        el('div.reset-proxy-note', {}, [
          el('span.rpn-icon', { html: icon(remove ? 'trashPlain' : 'proxyNone') }),
          el('span', { text: noteText }),
        ]),
      ],
      footer: [
        el('button.btn', { text: 'Không', onclick: closeModal }),
        el('button.btn.solid-red', { text: 'Có', onclick: async (e) => {
          try {
            await withSpin(e.currentTarget, async () => {
              for (const id of ids) await remote.profiles.updateDynamic(id, changes);
            });
            closeModal();
            await loadProfiles();
            toast(remove ? 'Đã xóa proxy' : 'Đã ngừng dùng proxy', 'ok');
          } catch (err) { closeModal(); await loadProfiles(); notifyError(err, remove ? 'Xóa proxy thất bại' : 'Ngừng dùng proxy thất bại'); }
        } }),
      ],
    });
  }

  // "Dùng proxy" - BẬT LẠI proxy cho hồ sơ đang ở trạng thái "Không dùng proxy"
  // (proxyType rỗng nhưng host/port/user/pass VẪN còn do chế độ 'disable' giữ lại).
  // proxyType chính là CÔNG TẮC: gán lại giá trị khác rỗng là proxy hoạt động trở lại.
  // Lúc tắt ta KHÔNG lưu loại proxy cũ, nên người dùng chọn lại loại ở modal (mặc định
  // HTTP). Riêng Token / Proxy Xoay suy được từ proxyToken / proxyRotateUrl nên tự khôi
  // phục đúng loại, không cần hỏi.
  function enableProxy(ids) {
    const rows = ids.map((id) => profiles.find((p) => p.id === id)).filter(Boolean);
    // Hồ sơ đang TẮT proxy (proxyType rỗng) mới là đối tượng cần bật.
    const off = rows.filter((p) => !String(p.proxyType || '').trim());
    // Chỉ bật lại được khi còn thông tin proxy: token / url xoay / host+port.
    const canOn = off.filter((p) => p.proxyToken || p.proxyRotateUrl || (p.proxyHost && p.proxyPort));
    const skipped = off.length - canOn.length;

    if (!canOn.length) {
      toast(off.length
        ? 'Các hồ sơ đã chọn không còn thông tin proxy để bật lại'
        : 'Các hồ sơ đã chọn đang dùng proxy', 'warn');
      return;
    }

    let type = PROXY_TYPE_DEFAULT;
    // Chỉ hỏi loại khi có hồ sơ dạng host:port (Token/Proxy Xoay tự suy ra được).
    const needType = canOn.some((p) => !p.proxyToken && !p.proxyRotateUrl);
    // Dùng CHUNG PROXY_TYPES để bốn combobox proxy không lệch nhau (user chốt 2026-10-03).
    // Item 'Token' ở ĐÂY không bao giờ áp sai được: vòng lặp bên dưới chỉ lấy `type` cho hồ
    // sơ KHÔNG có proxyToken/proxyRotateUrl, và một hồ sơ có token thì đã tự nhận 'Token'.
    // Nếu người dùng vẫn chọn 'Token' cho hồ sơ host:port thì ta bỏ qua lựa chọn đó và dùng
    // HTTP - lưu 'Token' cho một hồ sơ không có token là tạo ra dữ liệu vô nghĩa.
    const typeSel = customSelect(PROXY_TYPES,
      { value: type, width: '100%', onChange: (v) => { type = v; } });

    openModal({ title: 'Dùng proxy',
      body: [
        el('div', { style: { marginBottom: '12px' }, text: `${t('Bạn có chắc chắn muốn dùng lại proxy cho')} ${canOn.length} ${t('hồ sơ đã chọn')}?` }),
        ...(needType ? [el('div.field', { style: { marginBottom: '12px' } }, [
          el('label', { text: 'Loại proxy' }), typeSel,
        ])] : []),
        el('div.reset-proxy-note', {}, [
          el('span.rpn-icon', { html: icon('proxyUse') }),
          el('span', { text: 'Các hồ sơ sẽ dùng lại proxy đã lưu (host, cổng, tài khoản, mật khẩu). Hãy chọn đúng loại proxy để kết nối hoạt động.' }),
        ]),
        ...(skipped ? [el('div.reset-proxy-note', {}, [
          el('span.rpn-icon', { html: icon('proxyNone') }),
          el('span', { text: `${skipped} ${t('hồ sơ không còn thông tin proxy nên sẽ được bỏ qua')}` }),
        ])] : []),
      ],
      footer: [
        el('button.btn', { text: 'Không', onclick: closeModal }),
        el('button.btn.solid-blue', { text: 'Có', onclick: async (e) => {
          try {
            await withSpin(e.currentTarget, async () => {
              for (const p of canOn) {
                const restored = p.proxyToken ? 'Token'
                  : (p.proxyRotateUrl ? 'Proxy Xoay'
                    : (type === 'Token' ? PROXY_TYPE_DEFAULT : type));
                // Xoá geo cũ (IP local ghi lúc tắt proxy) để cell "IP" resolve lại theo proxy.
                await remote.profiles.updateDynamic(p.id, {
                  proxyType: restored, geoIp: '', geoCountry: '', geoRegion: '', geoCity: '',
                });
              }
            });
            closeModal();
            await loadProfiles();
            toast('Đã bật lại proxy', 'ok');
          } catch (err) { closeModal(); await loadProfiles(); notifyError(err, 'Bật lại proxy thất bại'); }
        } }),
      ],
    });
  }

  // ---------------------------------------- sửa MỘT thiết lập cho nhiều hồ sơ
  // NGUYÊN TẮC BẤT BIẾN của hai hàm dưới ("Web RTC" và "Trình duyệt"):
  //   GIỮ NGUYÊN VÂN TAY. Ta ĐỌC fingerprint hiện có của từng hồ sơ, vá ĐÚNG những
  //   khóa thuộc thiết lập người dùng vừa chọn, rồi ghi lại. TUYỆT ĐỐI KHÔNG gọi
  //   newFingerprint()/buildFpConfig() như "Dấu vân tay mới" - làm vậy là sinh seed
  //   mới và đổi sạch canvas/WebGL/font/UA, tức đổi danh tính hồ sơ.
  //   saveFingerprint() ghi cả object nên phải read-modify-write, không có PATCH lẻ.
  //
  // Đọc vân tay hiện tại của 1 hồ sơ. Lấy từ SERVER (profiles.get) chứ không dùng bản
  // trong lưới: lưới có thể đã cũ, mà đây là read-modify-write nên đọc cũ = ghi đè mất
  // thay đổi của người khác. Trả null nếu không đọc được (bỏ qua hồ sơ đó).
  async function readFingerprint(id) {
    const prof = await remote.profiles.get(id);
    if (!prof) return null;
    const fp = prof.fingerprint;
    // Server trả object (mapProfile: `fingerprint: p.fingerprint || {}`); vẫn phòng
    // trường hợp chuỗi JSON để không làm hỏng vân tay khi shape đổi.
    if (typeof fp === 'string') { try { return JSON.parse(fp || '{}'); } catch { return null; } }
    return fp && typeof fp === 'object' ? fp : null;
  }

  // Lưu vân tay đã vá. Giữ nguyên os của hồ sơ (suy từ meta.os như bulkNewFingerprint)
  // để cột OS / icon trong lưới không bị nhảy.
  function saveFingerprintKeepOs(p, fp) {
    const osEnum = OS_ENUM[(fp.meta && fp.meta.os) || p.os] || 'windows';
    return remote.profiles.saveFingerprint(p.id, fp, osEnum);
  }

  // Chạy một vòng vá + báo kết quả. `patch(fp, row)` trả true nếu có gì thay đổi;
  // `row` là dòng trong lưới, dùng khi cần thông tin không nằm trong vân tay (vd cột OS).
  async function applyFpPatch(rows, patch, okMsg) {
    let ok = 0;
    for (const p of rows) {
      try {
        const fp = await readFingerprint(p.id);
        if (!fp) continue;
        if (!patch(fp, p)) { ok++; continue; }   // đã đúng giá trị mong muốn ⇒ tính là xong
        await saveFingerprintKeepOs(p, fp);
        ok++;
      } catch { /* hồ sơ lỗi ⇒ bỏ qua, không dừng cả lô */ }
    }
    await loadProfiles();
    toast(`${t(okMsg)} ${ok}/${rows.length} ${t('hồ sơ')}`, ok ? 'ok' : 'err');
  }

  // "Web RTC" - đặt chế độ WebRTC cho các hồ sơ đã chọn. Thiết lập này sống ở HAI chỗ
  // trong vân tay và phải khớp nhau:
  //   • ui.webRTC      = nhãn tiếng Việt (để màn Sửa hồ sơ hiện đúng nút đang chọn)
  //   • fpConfig.webrtc = blob nhân đọc (mode/hideStats…) - dựng bằng webRtcCfgFor()
  // Vá cả hai, KHÔNG đụng khóa nào khác của ui/fpConfig/meta.
  function bulkSetWebRtc(ids) {
    const rows = ids.map((id) => profiles.find((p) => p.id === id)).filter(Boolean);
    if (!rows.length) return;
    // Cả lô ĐANG cùng một chế độ ⇒ chọn sẵn chế độ đó (người dùng thấy đúng hiện trạng,
    // không bị modal "gợi ý" đổi sang thứ khác). Lô lẫn lộn ⇒ mặc định 'Vô hiệu hóa'
    // (đúng mặc định của newFingerprint ở màn tạo hồ sơ).
    const curModes = new Set(rows.map((p) => ((p.fingerprint && p.fingerprint.ui) || {}).webRTC || ''));
    let mode = (curModes.size === 1 && WEBRTC_OPTS.some(([v]) => v === [...curModes][0]))
      ? [...curModes][0] : 'Vô hiệu hóa';
    const seg = pills(WEBRTC_OPTS, mode, (v) => { mode = v; });
    // .pc-seg mặc định `align-self: flex-start` (dính lề trái như trong form tạo hồ sơ).
    // Trong modal này dải nút là nội dung chính nên căn GIỮA - xem .pc-seg.bulk-center.
    seg.classList.add('bulk-center');
    openModal({ title: 'Web RTC', width: 620,
      body: [
        el('div', { style: { marginBottom: '4px' }, text: `${t('Áp dụng chế độ WebRTC cho')} ${rows.length} ${t('hồ sơ đã chọn')}.` }),
        el('div.pc-fctl', {}, [seg]),
        el('div.reset-proxy-note', {}, [
          el('span.rpn-icon', { html: icon('webRtcMark') }),
          el('span', { text: 'Chỉ thiết lập WebRTC được thay đổi. Toàn bộ phần còn lại của dấu vân tay được giữ nguyên.' }),
        ]),
      ],
      footer: [
        el('button.btn', { text: 'Hủy', onclick: closeModal }),
        el('button.btn.solid-blue', { text: 'Áp dụng', onclick: async () => {
          const cfg = webRtcCfgFor(mode);
          closeModal();
          toast('Đang áp dụng thiết lập WebRTC…');
          await applyFpPatch(rows, (fp) => {
            fp.ui = fp.ui || {};
            fp.fpConfig = fp.fpConfig || {};
            const same = fp.ui.webRTC === mode
              && JSON.stringify(fp.fpConfig.webrtc || null) === JSON.stringify(cfg);
            if (same) return false;
            fp.ui.webRTC = mode;
            // 'Thực' ⇒ XÓA hẳn section (buildFpConfig cũng không phát) thay vì để
            // {mode:'real'} - nhân không hiểu chuỗi đó, để lại là hook nhầm.
            if (cfg) fp.fpConfig.webrtc = cfg; else delete fp.fpConfig.webrtc;
            return true;
          }, 'Đã đặt WebRTC cho');
        } }),
      ],
    });
  }

  // "Chỉnh sửa tiện ích" - chọn bộ tiện ích RIÊNG cho các hồ sơ đã chọn (KHÔNG phải mở trang
  // Tiện ích: trang đó sửa kho CHUNG cho mọi hồ sơ). Ghi vào fp.ui.extensions = mảng
  // folderPath; lúc mở, main/extensions.js getFoldersForSelection() đọc đúng mảng này.
  //   • chưa từng đặt (undefined) ⇒ hồ sơ vẫn theo kho chung như trước
  //   • mảng rỗng ⇒ hồ sơ cố ý không nạp tiện ích nào
  // Khoá là folderPath chứ không phải id: các mục trong extensions.json KHÔNG có `id` ổn định
  // (cả hai nhánh thêm mới ở views/extensions.js đều không ghi `id`).
  async function bulkSetExtensions(ids) {
    const rows = ids.map((id) => profiles.find((p) => p.id === id)).filter(Boolean);
    if (!rows.length) return;

    let items = [];
    try { items = (await window.vt.ext.list()) || []; } catch { items = []; }
    items = items.filter((it) => it && it.folderPath);
    if (!items.length) { alertDialog('Chưa có tiện ích nào trong kho. Hãy vào trang Tiện ích để tải lên trước.'); return; }

    // Bộ ĐANG có hiệu lực của một hồ sơ: danh sách riêng nếu đã đặt, chưa đặt thì chính là kho
    // chung - nhờ vậy modal hiện đúng thứ hồ sơ đang nạp chứ không phải một ô trống khó hiểu.
    const globalOn = items.filter((it) => it.isEnabled).map((it) => String(it.folderPath));
    const effOf = (p) => {
      const u = (p.fingerprint && p.fingerprint.ui) || {};
      return Array.isArray(u.extensions) ? u.extensions.map(String) : globalOn;
    };
    const keyOf = (arr) => JSON.stringify([...arr].sort());
    const uniq = new Set(rows.map((p) => keyOf(effOf(p))));
    // Cả lô đang giống nhau ⇒ tick sẵn đúng bộ đó; lô lẫn lộn ⇒ tick theo kho chung.
    const chosen = new Set(uniq.size === 1 ? effOf(rows[0]) : globalOn);

    // Mỗi tiện ích là MỘT THẺ CÓ VIỀN: icon + tên/nhà cung cấp + công tắc bật/tắt.
    // Dùng lại .ext-icon/.ext-icon-img và .switch của trang Tiện ích để icon + công tắc
    // giống hệt bên đó (chỉ thu nhỏ bằng .px-extrow trong app.css), tránh sinh biến thể mới.
    // iconImagePath là đường dẫn TUYỆT ĐỐI trên ổ đĩa ⇒ phải đổi sang file:/// mới hiện
    // được trong renderer (cùng cách views/extensions.js làm).
    const fileUrl = (p) => 'file:///' + String(p).replace(/\\/g, '/');
    const listWrap = el('div.px-extlist');
    items.forEach((it) => {
      const dir = String(it.folderPath);
      const on = chosen.has(dir);
      const iconEl = it.iconImagePath
        ? el('img.ext-icon-img', { src: fileUrl(it.iconImagePath) })
        : el('div.ext-icon', { style: { background: (it.iconColor || '#1BB15C').replace(/^#FF/, '#') },
          text: it.iconGlyph || (it.name || '?')[0].toUpperCase() });
      const sw = el('button.switch.sm' + (on ? '.on' : ''), { type: 'button' }, [el('span.knob')]);
      const row = el('div.px-extrow' + (on ? '.on' : ''), {}, [
        iconEl,
        el('div.px-extmeta', {}, [
          el('div.px-extname', { text: it.name || 'Tiện ích', title: it.name || '' }),
          el('div.px-extsub', { text: it.storeId ? 'Cửa hàng Chrome' : (it.author || 'Tải lên') }),
        ]),
        sw,
      ]);
      // Bấm BẤT KỲ ĐÂU trong thẻ cũng đổi trạng thái (thẻ 1 dòng, không có nội dung nào khác
      // cần chọn) - gọn hơn bắt người dùng nhắm đúng công tắc 30px.
      row.addEventListener('click', () => {
        const nowOn = !chosen.has(dir);
        if (nowOn) chosen.add(dir); else chosen.delete(dir);
        sw.classList.toggle('on', nowOn);
        row.classList.toggle('on', nowOn);
        sw.title = t(nowOn ? 'Đang bật' : 'Đang tắt');
      });
      sw.title = t(on ? 'Đang bật' : 'Đang tắt');
      listWrap.appendChild(row);
    });

    openModal({ title: 'Chỉnh sửa tiện ích', width: 560,
      body: [
        // Mở từ menu BA CHẤM của một hàng thì chỉ có 1 hồ sơ ⇒ gọi thẳng TÊN hồ sơ, đừng in
        // "1 hồ sơ đã chọn" (người dùng đâu có tick gì). Cùng quy ước với modal "Chia sẻ".
        el('div', { style: { marginBottom: '4px' }, text: rows.length === 1
          ? tf('Chọn tiện ích cho hồ sơ "{0}"', rows[0].name || rows[0].id) + '.'
          : `${t('Chọn tiện ích áp dụng cho')} ${rows.length} ${t('hồ sơ đã chọn')}.` }),
        listWrap,
        el('div.reset-proxy-note', {}, [
          el('span.rpn-icon', { html: icon('extensions') }),
          el('span', { text: 'Chỉ các tiện ích đang bật mới nạp cho những hồ sơ này. Hồ sơ khác và kho tiện ích chung không bị ảnh hưởng.' }),
        ]),
      ],
      footer: [
        el('button.btn', { text: 'Hủy', onclick: closeModal }),
        el('button.btn.solid-blue', { text: 'Áp dụng', onclick: async () => {
          const want = [...chosen];
          closeModal();
          toast('Đang áp dụng tiện ích…');
          await applyFpPatch(rows, (fp) => {
            fp.ui = fp.ui || {};
            // Đã đúng bộ mong muốn VÀ đã là mảng ⇒ khỏi ghi (applyFpPatch tính là xong).
            // Phải kiểm cả Array.isArray: hồ sơ chưa đặt mà want trùng kho chung thì VẪN
            // phải ghi, nếu không nó mãi ở trạng thái "theo kho chung" và sẽ đổi theo kho.
            if (Array.isArray(fp.ui.extensions) && keyOf(fp.ui.extensions.map(String)) === keyOf(want)) return false;
            fp.ui.extensions = want;
            return true;
          }, 'Đã đặt tiện ích cho');
        } }),
      ],
    });
  }

  // "Trình duyệt" - đổi NHÂN (Poly/Firefox) + phiên bản nhân + User-Agent cho các hồ sơ
  // đã chọn. Nhân nằm TRỌN trong meta: browser / engine / kernelMajor; buildFpConfig
  // KHÔNG nhận nhân làm tham số nên đổi nhân không kéo theo fpConfig ⇒ vá meta là đủ.
  // Ô User-Agent mặc định "Không đổi" ⇒ UA của hồ sơ KHÔNG bị chạm; chỉ khi người dùng
  // chủ động chọn thì mới ghi meta.userAgent/uaPinned/uaFull + nhánh fpConfig.user_agent
  // (dựng bằng buildUaMeta - xem ghi chú trong data/fingerprint.js). Mọi khóa vân tay
  // khác vẫn nguyên vẹn.
  // Chỉ cho chọn nhân ĐÃ CÀI trên máy - sửa hàng loạt không phải lúc đi tải nhân.
  function bulkSetKernel(ids) {
    const rows = ids.map((id) => profiles.find((p) => p.id === id)).filter(Boolean);
    if (!rows.length) return;

    // Chọn sẵn nhân + phiên bản mà cả lô ĐANG dùng (lô lẫn lộn ⇒ Poly / bản mới nhất).
    const metas = rows.map((p) => (p.fingerprint && p.fingerprint.meta) || {});
    const curKernels = new Set(metas.map((m) => (m.engine === 'firefox' || m.browser === 'Firefox') ? 'Firefox' : 'Poly'));
    const curMajors = new Set(metas.map((m) => String(m.kernelMajor || '')));
    let kernel = curKernels.size === 1 ? [...curKernels][0] : 'Poly';
    let ver = (curKernels.size === 1 && curMajors.size === 1) ? [...curMajors][0] : '';
    // Kho nhân đã cài theo engine: { chromium: [{major,version}], firefox: [...] }.
    const store = { chromium: null, firefox: null };

    // .pc-kernels mặc định `align-self: flex-start` (dính lề trái như trong form tạo hồ
    // sơ). Trong modal này hai thẻ nhân là nội dung chính nên căn GIỮA - xem
    // .pc-kernels.bulk-center.
    const cards = el('div.pc-kernels.bulk-center');
    const verWrap = el('div.pc-fctl');
    const okBtn = el('button.btn.solid-blue', { text: 'Áp dụng' });

    // ---- ô "User-Agent" ----
    // 'keep' = KHÔNG chạm tới UA của hồ sơ (mặc định, đúng tinh thần "chỉ đổi cái đã
    // thiết lập"). 'auto' = mục "Tất cả" của màn tạo hồ sơ: UA dựng theo full-version
    // THẬT của nhân đang chọn ở trên. Còn lại = ghim MAJOR UA cụ thể.
    let uaPick = 'keep';

    // Full-version THẬT của một major đã cài (bóc từ tên thư mục nhân). Chromium phát UA
    // 4 nhóm số nên đòi đúng dạng đó; Firefox đánh số 3 nhóm và UA chỉ lộ major.
    // Soi gương kernelFullFor() ở profile_create.js.
    function installedFull(engine, major) {
      const it = (store[engine] || []).find((k) => String(k.major) === String(major) && k.version);
      if (!it) return '';
      const ok = engine === 'firefox'
        ? /^\d+(\.\d+)*$/.test(it.version)
        : /^\d+\.\d+\.\d+\.\d+$/.test(it.version);
      return ok ? String(it.version) : '';
    }

    // Full-version đưa vào uaString(). Soi gương syncUA()/rerollUA() ở profile_create.js.
    function uaFullPick(engine) {
      if (uaPick === 'auto') {
        const fallback = ver ? (engine === 'firefox' ? String(ver) : `${ver}.0.0.0`) : '';
        return installedFull(engine, ver) || fallback;
      }
      const major = String(uaPick);
      if (engine === 'firefox') return installedFull(engine, major) || major;
      // Chromium: random MỘT build THẬT trong major đã ghim. Gọi RIÊNG cho từng hồ sơ nên
      // cả lô KHÔNG dùng chung một build - giống như tạo lẻ từng hồ sơ, đỡ thành dấu hiệu.
      return randomChromeFull(major) || `${major}.0.0.0`;
    }

    // Danh sách major UA PHẢI theo ENGINE đang chọn (Firefox đi ghim major Chrome là lỗi
    // logic thấy rõ ở creepjs). Hợp thêm major có trong kho nhân để bản mới tải về hiện ngay.
    function uaOptions() {
      const engine = bulkEngineOf(kernel);
      const base = engine === 'firefox' ? firefoxMajors() : chromeMajors();
      const fromKernels = (store[engine] || []).map((k) => Number(k.major)).filter(Boolean);
      const majors = [...new Set([...base, ...fromKernels])].sort((a, b) => b - a);
      return [
        { value: 'keep', label: 'Không đổi' },
        { value: 'auto', label: 'Theo phiên bản nhân' },
        ...majors.map((m) => ({ value: String(m), label: 'UA ' + m })),
      ];
    }

    // Ô xem trước UA: chỉ-đọc, vì mỗi hồ sơ dựng UA theo HỆ ĐIỀU HÀNH của chính nó nên
    // không thể có một chuỗi dùng chung cho cả lô. Hiện theo hồ sơ đầu tiên.
    const uaPreview = el('input.input.pc-ua', { readonly: true, spellcheck: 'false' });
    const uaHint = el('div.muted');
    // .pc-ua-plain: ô UA ở đây KHÔNG có hai nút tròn "Tạo lại / Đặt lại" như màn tạo hồ
    // sơ, nên bỏ 66px padding-right mà .pc-ua-line chừa sẵn cho chúng.
    const uaLine = el('div.pc-ua-line.pc-ua-plain');
    // width 200 = CHUẨN cho cả hai combobox của modal; ô "Phiên bản trình duyệt" ở trên
    // bám theo con số này. height 40 trùng mặc định của .pc-select-trigger.
    const uaSel = customSelect(uaOptions(), {
      value: uaPick, width: 200, height: 40,
      onChange: (v) => { uaPick = v; syncUaPreview(); },
    });
    uaLine.appendChild(uaSel);
    uaLine.appendChild(uaPreview);
    const uaWrap = el('div.pc-fctl', {}, [uaLine, uaHint]);

    function syncUaPreview() {
      const keep = uaPick === 'keep';
      uaPreview.style.display = keep ? 'none' : '';
      // Nhãn để NGUYÊN tiếng Việt: bộ i18n dịch text node qua MutationObserver, gán t()
      // ở đây là dịch hai lần.
      uaHint.textContent = keep
        ? 'Giữ nguyên User-Agent hiện có của từng hồ sơ.'
        : 'Xem trước theo hồ sơ đầu tiên. Mỗi hồ sơ tự dựng User-Agent theo hệ điều hành của nó.';
      if (keep) return;
      const m0 = metas[0] || {};
      uaPreview.value = uaString(kernel, m0.os || 'Windows', m0.osVersion || '', uaFullPick(bulkEngineOf(kernel)));
    }

    // Đổi nhân ⇒ danh sách major UA của engine cũ vô nghĩa: nạp lại và đưa ô về "Không đổi"
    // (gán .value KHÔNG kích hoạt onChange nên phải tự gọi syncUaPreview).
    function resetUaForEngine() {
      uaPick = 'keep';
      try { uaSel.setOptions(uaOptions(), 'keep'); } catch { uaSel.value = 'keep'; }
      syncUaPreview();
    }

    function renderVer() {
      clear(verWrap);
      const list = store[bulkEngineOf(kernel)];
      if (list == null) { verWrap.appendChild(el('div.muted', { text: 'Đang tải danh sách nhân…' })); okBtn.disabled = true; return; }
      if (!list.length) {
        verWrap.appendChild(el('div.muted', { text: 'Chưa cài nhân nào cho trình duyệt này. Hãy tải nhân ở trang Nhân trình duyệt trước.' }));
        okBtn.disabled = true;
        return;
      }
      if (!list.some((k) => String(k.major) === String(ver))) ver = String(list[0].major);
      okBtn.disabled = false;
      verWrap.appendChild(customSelect(list.map((k) => String(k.major)),
        // Ở chế độ UA "Theo phiên bản nhân" thì chuỗi UA bám vào `ver` ⇒ đổi phiên bản
        // phải vẽ lại ô xem trước, nếu không nó trơ ra UA của bản cũ.
        // width 200 = ĐÚNG bề rộng ô "User-Agent" ngay dưới; hai combobox xếp chồng nhau
        // nên lệch bề rộng là thấy ngay. Đổi ở đây thì phải đổi cả ô UA và ngược lại.
        { value: String(ver), width: 200, onChange: (v) => { ver = v; if (uaPick === 'auto') syncUaPreview(); } }));
    }

    function renderCards() {
      clear(cards);
      BULK_KERNELS.forEach(([val, label, ic]) => {
        // Icon 'chrome' = logo Poly (mask PNG, không phải SVG) - giữ đúng 2 nhánh
        // markup như renderKernels() ở màn tạo hồ sơ để CSS dùng lại được y nguyên.
        const iconHtml = ic === 'chrome'
          ? `<span class="pc-kernel-ico" role="img" aria-label="${label}"></span>`
          : `<span class="pc-kernel-ico pc-kernel-ico-svg" role="img" aria-label="${label}">${icon(ic)}</span>`;
        const card = el('div.pc-kernel' + (kernel === val ? '.sel' : ''));
        card.appendChild(el('button.pc-kernel-main', {
          type: 'button',
          html: iconHtml + `<span class="lbl">${label}</span>`,
          onclick: () => {
            if (kernel === val) return;
            kernel = val;
            ver = '';           // đổi engine ⇒ phiên bản của engine cũ vô nghĩa
            renderCards(); renderVer(); resetUaForEngine();
          },
        }));
        cards.appendChild(card);
      });
    }

    renderCards();
    renderVer();
    syncUaPreview();
    // Nạp sổ cái nhân LOCAL của cả hai engine (không qua mạng) ⇒ danh sách hiện gần
    // như tức thì và chỉ liệt kê nhân thật có trên máy.
    ['chromium', 'firefox'].forEach((e) => {
      let req;
      try { req = window.vt.kernel.installed(e); } catch { req = null; }
      Promise.resolve(req)
        .then((list) => { store[e] = Array.isArray(list) ? list : []; })
        .catch(() => { store[e] = []; })
        .finally(() => {
          if (bulkEngineOf(kernel) !== e) return;
          renderVer();
          // Kho nhân về muộn ⇒ danh sách major UA có thể rộng ra, và UA "Theo phiên bản
          // nhân" giờ mới biết full-version THẬT. Giữ nguyên lựa chọn hiện tại của người dùng.
          try { uaSel.setOptions(uaOptions(), uaPick); } catch { /* combobox chưa dựng xong */ }
          syncUaPreview();
        });
    });

    okBtn.onclick = async () => {
      const engine = bulkEngineOf(kernel);
      const major = String(ver || '');
      if (!major) return;
      const setUa = uaPick !== 'keep';
      const pinned = uaPick === 'auto' ? '' : String(uaPick);
      closeModal();
      toast('Đang áp dụng thiết lập trình duyệt…');
      await applyFpPatch(rows, (fp, row) => {
        fp.meta = fp.meta || {};
        let changed = false;
        if (fp.meta.browser !== kernel || fp.meta.engine !== engine || String(fp.meta.kernelMajor || '') !== major) {
          fp.meta.browser = kernel;
          fp.meta.engine = engine;
          fp.meta.kernelMajor = major;
          changed = true;
        }
        if (setUa) {
          // UA phải dựng theo OS CỦA CHÍNH hồ sơ này - dùng OS của lô là ghép UA Windows
          // cho hồ sơ macOS, đúng kiểu mâu thuẫn mà antidetect soi ra ngay. Vân tay cũ
          // thiếu meta.os thì lùi về cột OS của lưới trước khi lùi về Windows.
          const os = fp.meta.os || (row && row.os) || 'Windows';
          const osVersion = fp.meta.osVersion || '';
          const full = uaFullPick(engine);
          const ua = uaString(kernel, os, osVersion, full);
          const uaFull = uaPick === 'auto' ? '' : full;
          if (fp.meta.userAgent !== ua || (fp.meta.uaPinned || '') !== pinned || (fp.meta.uaFull || '') !== uaFull) {
            fp.meta.userAgent = ua;
            fp.meta.uaPinned = pinned;
            fp.meta.uaFull = uaFull;
            changed = true;
          }
          // fpConfig.user_agent PHẢI dựng lại theo UA mới, nếu không nhân vẫn hook UA cũ
          // (meta chỉ để hiện lại form). Điều kiện phát section soi gương `uaForConfig`
          // trong profile_create.js: Windows + "Theo phiên bản nhân" ⇒ KHÔNG phát, để nhân
          // dùng UA gốc của chính nó (khớp 100% chromium gốc, không hook gì).
          const uaForConfig = (uaPick !== 'auto' || os !== 'Windows') ? ua : '';
          fp.fpConfig = fp.fpConfig || {};
          const next = uaForConfig ? buildUaMeta(os, uaForConfig, osVersion) : null;
          if (JSON.stringify(fp.fpConfig.user_agent || null) !== JSON.stringify(next)) {
            if (next) fp.fpConfig.user_agent = next; else delete fp.fpConfig.user_agent;
            changed = true;
          }
        }
        return changed;
      }, 'Đã đặt trình duyệt cho');
    };

    openModal({ title: 'Trình duyệt', width: 620,
      body: [
        el('div', { style: { marginBottom: '4px' }, text: `${t('Áp dụng trình duyệt cho')} ${rows.length} ${t('hồ sơ đã chọn')}.` }),
        cards,
        el('div.field', {}, [el('label', { text: 'Phiên bản trình duyệt' }), verWrap]),
        el('div.field', {}, [el('label', { text: 'User-Agent' }), uaWrap]),
        el('div.reset-proxy-note', {}, [
          el('span.rpn-icon', { html: icon('browserGlobe') }),
          el('span', { text: 'Chỉ những mục bạn chọn ở hộp thoại này được thay đổi. Phần còn lại của dấu vân tay được giữ nguyên.' }),
        ]),
      ],
      footer: [el('button.btn', { text: 'Hủy', onclick: closeModal }), okBtn],
    });
  }

  // "Tạo shortcut cho hồ sơ" - ghi tệp .lnk của Windows để nhấp đúp là mở thẳng hồ sơ,
  // không cần vào app tìm trong lưới. Lối tắt trỏ vào chính file thực thi của app kèm
  // --open-profile=<id>; toàn bộ phần ghi tệp nằm ở main/shortcuts.js.
  //
  // Lối tắt mở hồ sơ qua ĐÚNG openProfile() của lưới này (main chỉ chuyển id xuống đây),
  // nên nó thừa hưởng nguyên xi mọi bước: chặn hết hạn thuê bao, đòi nhân đã cài, khoá
  // phiên, đồng bộ cloud, cập nhật badge + toast. Xem api.openProfileById ở cuối tệp.
  function bulkCreateShortcut(ids) {
    const rows = ids.map((id) => profiles.find((p) => p.id === id)).filter(Boolean);
    if (!rows.length) return;

    // Thư mục đã chọn lần trước được NHỚ LẠI (theo máy - đường dẫn chỉ có nghĩa trên chính
    // máy này, nên localStorage chứ không phải thiết lập đồng bộ lên server). Chưa từng
    // chọn ⇒ để rỗng và lấy mặc định là màn hình nền ở dưới.
    const DIR_KEY = 'polyShortcutDir';
    let dir = '';
    try { dir = String(localStorage.getItem(DIR_KEY) || ''); } catch { /* ignore */ }

    // ---- Vị trí lưu: ô đường dẫn chỉ-đọc + nút thư mục NẰM TRONG (soi gương ô "Đường
    // dẫn lưu trữ dữ liệu hồ sơ" ở trang Cài đặt, nhưng class riêng .psc-path vì
    // .set-pathbox bị bó trong .set-mid). Chỉ-đọc để không ai gõ tay một đường dẫn sai
    // rồi nhận lỗi ENOENT lúc ghi.
    const dirInput = el('input.psc-pathinput', { readonly: true, value: dir, placeholder: 'Đang lấy màn hình nền…' });
    const dirBox = el('div.psc-path', {}, [
      dirInput,
      el('button.psc-pathbtn', {
        type: 'button', html: icon('folder'), title: 'Chọn thư mục lưu lối tắt',
        onclick: async () => {
          try {
            const d = await window.vt.dialog.openFolder();
            if (d) {
              dir = d; dirInput.value = d;
              // Ghi NGAY lúc chọn, không đợi bấm "Tạo lối tắt": người dùng huỷ modal rồi mở
              // lại vẫn thấy đúng thư mục họ vừa nhắm tới.
              try { localStorage.setItem(DIR_KEY, d); } catch { /* ignore */ }
            }
          } catch { /* người dùng huỷ hộp thoại */ }
        },
      }),
    ]);
    // Chưa có thư mục đã nhớ ⇒ mặc định màn hình nền THẬT của người dùng (có thể đã bị
    // OneDrive dời sang chỗ khác) - hỏi main chứ không tự ghép %USERPROFILE%\Desktop.
    // KHÔNG lưu giá trị mặc định này vào localStorage: để trống thì lần sau vẫn tự theo màn
    // hình nền hiện hành, chỉ lựa chọn do người dùng tự bấm mới được nhớ.
    if (!dir) {
      (async () => {
        try { const d = await window.vt.shortcuts.defaultDir(); if (d && !dir) { dir = d; dirInput.value = d; } }
        catch { dirInput.placeholder = 'Hãy chọn thư mục lưu'; }
      })();
    }

    // ---- Tên lối tắt: mẫu có token. Một hồ sơ thì gõ thẳng tên cũng được; cả lô thì PHẢI
    // có token, vì 50 hồ sơ cùng một mẫu tĩnh chỉ ra "X", "X (2)", "X (3)"… - không đè mất
    // nhau nhưng cũng chẳng ai đoán được cái nào là hồ sơ nào.
    const nameInput = el('input.input', { value: '{name}', spellcheck: 'false' });
    const namePreview = el('div.muted');
    function syncNamePreview() {
      const raw = nameInput.value.trim();
      // Soi gương fillPattern() ở main/shortcuts.js. Giữ hai bản khớp nhau: chỗ này chỉ
      // để XEM TRƯỚC, tên thật do main sinh.
      const fill = (p, i) => {
        if (!raw) return String(p.name || p.id || '');
        // Không token: một hồ sơ thì giữ đúng chữ đã gõ, cả lô thì lùi về tên hồ sơ.
        if (!/\{(name|id|index)\}/.test(raw)) return rows.length > 1 ? String(p.name || p.id || '') : raw;
        return raw.replace(/\{name\}/g, String(p.name || '')).replace(/\{id\}/g, String(p.id || '')).replace(/\{index\}/g, String(i + 1));
      };
      const first = fill(rows[0], 0);
      const more = rows.length > 1 ? `, ${fill(rows[1], 1)}…` : '';
      namePreview.textContent = `Ví dụ: ${first}.lnk${more}`;
    }
    nameInput.addEventListener('input', syncNamePreview);
    syncNamePreview();

    // Biểu tượng KHÔNG còn là tuỳ chọn: mặc định là logo app (main lấy icon nhúng trong
    // file thực thi). Trùng tên cũng không còn tuỳ chọn ghi đè: main tự thêm hậu tố số
    // " (2)", " (3)"… và CHỈ khi phát hiện trùng.
    openModal({ title: 'Tạo lối tắt hồ sơ', width: 620,
      body: [
        el('div', { style: { marginBottom: '4px' }, text: `${t('Tạo lối tắt trên máy cho')} ${rows.length} ${t('hồ sơ đã chọn')}.` }),
        el('div.field', {}, [el('label', { text: 'Vị trí lưu' }), dirBox]),
        // Nhãn để NGUYÊN tiếng Việt: bộ i18n dịch text node qua MutationObserver, gọi t()
        // ở đây là dịch hai lần.
        el('div.field', {}, [el('label', { text: 'Tên lối tắt' }), nameInput, namePreview,
          el('div.muted', { text: 'Dùng được {name}, {index}, {id}' })]),
      ],
      footer: [
        el('button.btn', { text: 'Hủy', onclick: closeModal }),
        el('button.btn.solid-blue', { text: 'Tạo lối tắt', onclick: async () => {
          const pattern = nameInput.value.trim();
          // Cả lô mà mẫu không phân biệt được từng hồ sơ ⇒ CHẶN tại đây (main sẽ lẳng lặng
          // lùi về tên hồ sơ, nhưng người dùng cần biết mẫu họ gõ là vô nghĩa). Một hồ sơ
          // thì mẫu tĩnh hợp lệ - đó chính là "tự đặt tên lối tắt".
          if (rows.length > 1 && pattern && !/\{(name|index|id)\}/.test(pattern)) {
            return toast('Tạo nhiều lối tắt thì tên phải chứa {name}, {index} hoặc {id}', 'warn');
          }
          closeModal();
          toast('Đang tạo lối tắt…');
          let r;
          try {
            r = await window.vt.shortcuts.create({
              profiles: rows.map((p) => ({ id: p.id, name: p.name })),
              dir, pattern,
            });
          } catch { r = null; }
          if (!r || !r.created) return toast((r && r.error) || 'Không tạo được lối tắt', 'error');
          // Cùng khuôn "<động từ> cho N/M hồ sơ" với applyFpPatch (Đã đặt WebRTC cho…) để
          // toast của mọi hành động hàng loạt đọc giống nhau, và để i18n khỏi phải có một
          // khoá trần kiểu 'Đã tạo' (quá chung, dễ đụng chỗ khác).
          const bits = [`${t('Đã tạo lối tắt cho')} ${r.created}/${rows.length} ${t('hồ sơ')}`];
          if (r.failed) bits.push(`${t('lỗi')} ${r.failed}`);
          toast(bits.join(' · '), r.failed ? 'warn' : 'ok');
          // Mở thư mục đích để người dùng thấy ngay kết quả (khỏi phải tự đi tìm khi họ
          // lưu vào một thư mục lồng sâu). Best-effort.
          if (r.created && r.dir) { try { window.vt.shell.openPath(r.dir); } catch { /* ignore */ } }
        } }),
      ],
    });
  }

  // -------------------------------------------------- create / batch
  function osRadios(name) {
    return el('div.radio-grid', {}, OS_LIST.map(([val, label], i) =>
      el('label.radio', {}, [el('input', { type: 'radio', name, value: val, checked: i === 0 }), el('span', { text: label })])));
  }
  function browserRadios(name) {
    // Engine is the patched Chromium shipped in vendor/chromium ("CGTBrowser").
    // Firefox removed: this build cannot launch a Gecko engine. The fp-config
    // schema has no "browser" field - this value is a display label only.
    return el('div', { style: { display: 'flex', gap: '12px' } }, [
      el('label.radio', {}, [el('input', { type: 'radio', name, value: 'CGTBrowser', checked: true }), el('span', { text: 'CGTBrowser' })]),
    ]);
  }
  const getRadio = (root, name) => { const c = root.querySelector(`input[name=${name}]:checked`); return c ? c.value : ''; };

  function bulkRename() {
    if (!selected.size) return toast('Chưa chọn hồ sơ nào');
    let input;
    openModal({ title: `${t('Đổi tên')} ${selected.size} ${t('hồ sơ')}`,
      body: [el('div.field', {}, [el('label', { text: 'Tên hồ sơ' }), (input = el('input.input', { placeholder: 'Tên cơ sở' })),
        el('div.muted', { style: { marginTop: '6px' }, text: 'Hệ thống tự thêm số thứ tự vào sau tên.' })])],
      footer: [el('button.btn', { text: 'Hủy', onclick: closeModal }),
        el('button.btn.primary', { text: 'Lưu', onclick: async () => {
          const base = input.value.trim(); if (!base) return; closeModal();
          const ids = [...selected]; let i = 1;
          try {
            for (const id of ids) { await remote.profiles.rename(id, `${base} ${String(i++).padStart(2, '0')}`); }
            await loadProfiles();
            toast('Đã đổi tên hồ sơ', 'ok');
          } catch (e) { await loadProfiles(); notifyError(e, 'Đổi tên hàng loạt thất bại'); }
        } })],
    });
    setTimeout(() => input.focus(), 30);
  }

  // -------------------------------------------------- bulk "Thêm" actions
  // The profiles currently checked, as full row objects (not just ids).
  const selProfiles = () => profiles.filter((p) => selected.has(p.id));

  // A copy-paste friendly proxy string for one profile ("" when no proxy).
  function proxyStr(p) {
    if (!hasProxy(p)) return '';
    if (!p.proxyHost || !p.proxyPort) return proxyDisplay(p); // Token / Proxy xoay
    const auth = p.proxyUser ? `:${p.proxyUser}:${p.proxyPass || ''}` : '';
    const scheme = p.proxyType ? `${p.proxyType}://` : '';
    return `${scheme}${p.proxyHost}:${p.proxyPort}${auth}`;
  }

  async function copyToClipboard(text, label) {
    if (!text) return toast('Không có dữ liệu để sao chép', 'warn');
    try { await navigator.clipboard.writeText(text); toast(`${t('Đã sao chép')} ${label}`, 'ok'); }
    catch { toast('Không sao chép được', 'err'); }
  }

  // Copy one field across every selected profile, one per line.
  function copyField(kind) {
    if (!needSel()) return;
    const rows = selProfiles();
    let lines; let label;
    if (kind === 'id') { lines = rows.map((p) => p.profileId || p.id); label = `ID (${rows.length})`; }
    else if (kind === 'name') { lines = rows.map((p) => p.name || ''); label = `${t('tên')} (${rows.length})`; }
    else if (kind === 'proxy') { lines = rows.map(proxyStr).filter(Boolean); label = `proxy (${lines.length})`; }
    else { lines = rows.map((p) => p.note || '').filter(Boolean); label = `${t('ghi chú')} (${lines.length})`; }
    copyToClipboard(lines.join('\n'), label);
  }

  // Bulk proxy check / refresh - both re-query the exit IP (checkIp) and persist the
  // resolved geo; "check" reports pass/fail, "update" is framed as a refresh.
  async function bulkCheckIp(mode) {
    if (!needSel()) return;
    // Chỉ xử lý hồ sơ ĐANG bật proxy - hồ sơ không set/không bật proxy sẽ bị bỏ qua
    // (không đi lấy geo IP nội bộ nữa). Nếu không hồ sơ nào có proxy thì báo "không có".
    const selRows = selProfiles();
    const rows = selRows.filter(hasProxy);
    const skipped = selRows.length - rows.length;
    if (!rows.length) return toast('Các hồ sơ đã chọn chưa cấu hình proxy', 'warn');
    toast(mode === 'update' ? 'Đang cập nhật proxy…' : 'Đang kiểm tra proxy…');
    let ok = 0;
    for (const p of rows) {
      let r; try { r = await remote.profiles.checkIp(p.id); } catch { r = null; }
      if (r && r.ok) ok++;
    }
    await loadProfiles();
    const verb = mode === 'update' ? t('Đã cập nhật') : t('Kiểm tra');
    const tail = skipped ? ` (${t('bỏ qua')} ${skipped} ${t('hồ sơ không có proxy')})` : '';
    toast(`${verb} proxy: ${ok}/${rows.length} ${t('thành công')}${tail}`, ok ? 'ok' : 'warn');
  }

  // Dựng lại vân tay ĐÚNG BẢN CHẤT như bấm "Dấu vân tay mới" trong màn Sửa hồ sơ:
  // sinh fp mới HOÀN TOÀN (newFingerprint), ép các mặt gắn-OS (GPU/CPU/RAM/tên máy/
  // font) theo đúng OS của hồ sơ (mirror applyOsConsistency), rồi build lại fpConfig
  // (buildFpConfig - seed mới). GIỮ nguyên meta (nhân/OS/phiên bản/UA đã ghim); cookie
  // seed local không bị đụng. Trả về object { meta, fpConfig, ui } để PATCH lên server.
  async function regenFingerprintFor(prof) {
    const savedFp = (prof && prof.fingerprint) || {};
    const meta = savedFp.meta || {};
    const os = meta.os || 'Windows';
    // Bảo đảm pool GPU/font của OS đã nạp (offline → fallback built-in trong fingerprint.js).
    if (!hasPools(os)) { try { setAllPools(await remote.fingerprintCatalog()); } catch { /* fallback */ } }
    const fp = newFingerprint();
    // OS-consistency: khoá GPU/tên máy/CPU-RAM/font theo OS (không để lộ card Mac dưới UA Windows).
    const g = osGpu(os);
    fp.webglVendor = g.vendor;
    fp.webglMeta = g.renderer;
    fp.deviceName = osDeviceName(os);
    const hw = osHardware(os, g.renderer);
    fp.cpu = hw.cpu;
    fp.ram = hw.ram;
    fp.fontList = osFonts(os);
    fp.fonts = String(fp.fontList.length);
    // uaForConfig: Windows + "Tất cả" (uaPinned rỗng) ⇒ '' để nhân dùng UA gốc; còn lại
    // giữ UA đã ghim (mirror quy tắc uaForConfig ở collectPayload màn Sửa).
    const uaForConfig = (meta.uaPinned || os !== 'Windows') ? (meta.userAgent || '') : '';
    const fpConfig = buildFpConfig(fp, os, uaForConfig, prof.name || '', meta.osVersion || '');
    // KHÔNG kèm cookies: chúng lưu ở seed LOCAL riêng (không có trong fingerprint server)
    // và saveFingerprint dùng kênh raw không tách cookies - kèm vào sẽ rò lên server.
    // Đổi vân tay không đụng cookie hiện có.
    return { meta, fpConfig, ui: fp };
  }

  // "Dấu vân tay mới" - regenerate a full fingerprint for each selected profile, exactly
  // like the "Dấu vân tay mới" button inside the edit dialog. Confirmed first since it
  // replaces the current fp.
  function bulkNewFingerprint() {
    if (!needSel()) return;
    // Cổng gói: "Dấu vân tay mới" là tính năng trả phí → gói Free hiện modal nâng cấp (y "Tạo không gian làm việc").
    if (!hasFeature('new_fingerprint')) { gateFeature('new_fingerprint', { navigate: ctx.navigate }); return; }
    const rows = selProfiles();
    const doRun = async () => {
      toast('Đang tạo dấu vân tay mới…');
      let ok = 0;
      for (const p of rows) {
        try {
          const prof = await remote.profiles.get(p.id);
          if (!prof) continue;
          const fp = await regenFingerprintFor(prof);
          const osEnum = OS_ENUM[(fp.meta && fp.meta.os) || p.os] || 'windows';
          await remote.profiles.saveFingerprint(p.id, fp, osEnum);
          ok++;
        } catch { /* skip */ }
      }
      await loadProfiles();
      toast(`${t('Đã tạo vân tay mới cho')} ${ok}/${rows.length} ${t('hồ sơ')}`, ok ? 'ok' : 'err');
    };
    // Custom modal so we can show an animated (gif-like) fingerprint-scan icon on top
    // of the confirmation prompt.
    openModal({ title: 'Dấu vân tay mới',
      body: [
        el('div', { style: 'text-align:center' }, [
          el('div.fp-anim', {}, [el('div.fp-anim-svg', { html: icon('fingerprintScan') }), el('div.fp-scan')]),
          el('div', { style: 'margin-top:10px', text: `${t('Tạo dấu vân tay mới cho')} ${rows.length} ${t('hồ sơ đã chọn')}? ${t('Vân tay hiện tại sẽ được thay thế.')}` }),
        ]),
      ],
      footer: [
        el('button.btn', { text: 'Hủy', onclick: closeModal }),
        el('button.btn.primary', { text: 'Tạo mới', onclick: () => { closeModal(); doRun(); } }),
      ],
    });
  }

  // "Xuất" - export the selected profiles to a real .xlsx file (main pops "Save As").
  // Optimised for large selections: the button spins (withSpin, also blocks double
  // clicks), we yield one frame so the spinner paints before the CPU-bound build, and
  // the sheet is assembled in one pass (see data/xlsx.js). The Save-As dialog opens
  // only AFTER the bytes are ready, so a big build never leaves a half-drawn dialog.
  async function exportSelected() {
    if (!needSel()) return;
    const rows = selProfiles();
    const header = ['STT', 'Profile ID', 'Tên', 'Nhóm', 'Hệ điều hành', 'Proxy', 'Thẻ', 'Ghi chú'];
    const data = new Array(rows.length + 1);
    data[0] = header;
    for (let i = 0; i < rows.length; i++) {
      const p = rows[i];
      data[i + 1] = [
        i + 1,
        p.profileId || p.id || '',
        p.name || '',
        p.group || '',
        p.os || '',
        proxyStr(p) || proxyDisplay(p) || '',
        p.tags || '',
        p.note || '',
      ];
    }
    try {
      // Let the spinner render before the synchronous, CPU-heavy build starts.
      await new Promise((r) => requestAnimationFrame(() => r()));
      const bytes = buildXlsx(data);
      // Tên file: ngày + giờ-phút-giây + 4 số ngẫu nhiên → tránh trùng khi xuất nhiều
      // lần trong cùng một ngày/giây (vd ho-so_2026-07-19_143502_8231.xlsx).
      const d = new Date();
      const pad = (n) => String(n).padStart(2, '0');
      const stamp = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`
        + `_${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
      const rnd = String(Math.floor(1000 + Math.random() * 9000));
      const res = await window.vt.files.saveExport(`ho-so_${stamp}_${rnd}.xlsx`, bytes);
      // MỘT câu hoàn chỉnh qua tf() chứ không ghép ba mảnh t(): tiếng Nga/Trung đảo
      // trật tự từ và tiếng Nga còn chia cách theo số lượng, ghép mảnh là sai ngữ pháp.
      if (res && res.ok) toast(tf('Đã xuất {0} hồ sơ → Excel', rows.length), 'ok');
      else if (res && res.error) toast(`${t('Xuất Excel thất bại')}: ${res.error}`, 'err');
      // res.canceled → im lặng (người dùng bấm Hủy ở hộp lưu)
    } catch (e) { notifyError(e, 'Xuất Excel thất bại'); }
  }

  // -------------------------------------------------- tags / windows
  // A profile's `tags` field is a comma-separated list; the tag manager
  // aggregates them across all profiles and persists standalone (unassigned)
  // tags in settings so they survive even with no profile attached.
  const profileTagList = (p) => String(p.tags || '').split(',').map((t) => t.trim()).filter(Boolean);

  async function openTagManager() {
    // Thẻ độc lập lấy TỪ SERVER (remote.tags) thay cho settings local.
    let customTags = await remote.tags.list();
    let q = '';
    const listWrap = el('div.tag-list');

    const aggregate = () => {
      const counts = new Map();
      profiles.forEach((p) => profileTagList(p).forEach((t) => counts.set(t, (counts.get(t) || 0) + 1)));
      customTags.forEach((t) => { if (!counts.has(t)) counts.set(t, 0); });
      return [...counts.entries()].map(([name, count]) => ({ name, count })).sort((a, b) => a.name.localeCompare(b.name));
    };

    async function removeTag(name) {
      try {
        const affected = profiles.filter((p) => profileTagList(p).includes(name));
        for (const p of affected) await remote.profiles.updateDynamic(p.id, { tags: profileTagList(p).filter((t) => t !== name).join(', ') });
        customTags = customTags.filter((t) => t !== name);
        await remote.tags.remove(name);
        await loadProfiles();
        toast('Đã xóa thẻ', 'ok');
      } catch (e) { await loadProfiles(); notifyError(e, 'Xóa thẻ thất bại'); }
      openTagManager();
    }

    // Rename a tag everywhere it's used: rewrite it on every profile that
    // carries it and in the standalone customTags store, then refresh.
    async function renameTag(oldName, newName) {
      newName = newName.trim();
      if (!newName || newName === oldName) return openTagManager();
      if (aggregate().some((t) => t.name === newName)) return toast('Thẻ đã tồn tại', 'warn');
      try {
        const affected = profiles.filter((p) => profileTagList(p).includes(oldName));
        for (const p of affected) {
          const next = profileTagList(p).map((t) => (t === oldName ? newName : t));
          await remote.profiles.updateDynamic(p.id, { tags: [...new Set(next)].join(', ') });
        }
        customTags = [...new Set(customTags.map((t) => (t === oldName ? newName : t)))];
        await remote.tags.rename(oldName, newName);
        await loadProfiles();
        toast('Đã cập nhật thẻ', 'ok');
      } catch (e) { await loadProfiles(); notifyError(e, 'Đổi tên thẻ thất bại'); }
      openTagManager();
    }

    function editTagDialog(name) {
      let input;
      openModal({ title: 'Chỉnh sửa thẻ',
        body: [el('div.field', {}, [el('label', { text: 'Tên thẻ' }), (input = el('input.input', { value: name }))])],
        footer: [el('button.btn', { text: 'Hủy', onclick: () => openTagManager() }),
          el('button.btn.primary', { text: 'Lưu', onclick: () => { const v = input.value.trim(); if (!v) return toast('Nhập tên thẻ'); renameTag(name, v); } })],
      });
      setTimeout(() => input.focus(), 30);
    }

    function addTagDialog() {
      let input;
      openModal({ title: 'Thêm thẻ',
        body: [el('div.field', {}, [el('label', { text: 'Tên thẻ' }), (input = el('input.input', { placeholder: 'Tên thẻ' }))])],
        footer: [el('button.btn', { text: 'Hủy', onclick: () => openTagManager() }),
          el('button.btn.primary', { text: 'Tạo', onclick: async () => {
            const v = input.value.trim(); if (!v) return toast('Nhập tên thẻ');
            try {
              if (!aggregate().some((t) => t.name === v)) { customTags.push(v); await remote.tags.create(v); }
            } catch (e) { notifyError(e, 'Tạo thẻ thất bại'); }
            openTagManager();
          } })],
      });
      setTimeout(() => input.focus(), 30);
    }

    function renderList() {
      clear(listWrap);
      listWrap.appendChild(el('div.tag-row.head', {}, [el('div', { text: 'Tên thẻ' }), el('div', { text: 'Hồ sơ được gắn' }), el('div', { text: 'Hành động' })]));
      const rows = aggregate().filter((t) => !q || t.name.toLowerCase().includes(q.toLowerCase()));
      if (!rows.length) { listWrap.appendChild(el('div.tag-empty.muted', { text: 'Chưa có thẻ nào' })); return; }
      rows.forEach((tg) => {
        listWrap.appendChild(el('div.tag-row', {}, [
          el('div', {}, [el('span.chip.tag-chip.' + tagColorClass(tg.name), { text: tg.name })]),
          el('div.muted', { text: `${tg.count} ${t('hồ sơ')}` }),
          el('div.tag-actions', {}, [
            el('button.icon-btn', { html: icon('edit'), title: 'Chỉnh sửa thẻ', onclick: () => editTagDialog(tg.name) }),
            el('button.icon-btn.danger', { html: icon('trash'), title: 'Xóa thẻ', onclick: () => confirmDialog({ title: 'Xóa thẻ', danger: true, confirmLabel: 'Xóa', message: tf('Xóa thẻ "{0}" khỏi tất cả hồ sơ?', tg.name), onConfirm: () => removeTag(tg.name) }) }),
          ]),
        ]));
      });
    }

    const searchTag = el('input.search-input', { placeholder: 'Tìm kiếm...', oninput: (e) => { q = e.target.value.trim(); renderList(); } });
    const searchTagBar = el('div.searchbar', {}, [el('span.ico', { html: icon('search') }), searchTag]);
    openModal({ title: 'Danh sách thẻ',
      body: [
        el('div.tag-toolbar', {}, [searchTagBar, el('button.btn.primary', { html: `${icon('plus')}<span>Thêm thẻ mới</span>`, onclick: addTagDialog })]),
        listWrap,
      ],
    });
    renderList();
  }

  // ---------------------------------------------- sắp xếp cửa sổ đang mở
  // Xếp lại cửa sổ Chrome của MỌI hồ sơ đang mở. Trước đây chỉ bắn toast "cần API
  // Win32" - thật ra đường dây đã có sẵn và chạy được từ lâu ở màn Đồng bộ:
  //   vt.sync.arrange(ids, layout) → ipc 'sync:arrange' → browser-launcher
  //   .arrangeWindows() → tính toạ độ (window-layout.js) → PowerShell SetWindowPos.
  // Ở đây chỉ cần gọi đúng đường dây đó, nên nút này giờ hoạt động thật.
  //
  // PHẠM VI = TẤT CẢ hồ sơ đang mở, CỐ Ý không theo ô tick. Tooltip của nút ghi rõ
  // "các hồ sơ đang mở"; nếu bám theo selection thì người dùng tick vài dòng để làm
  // việc khác (đổi nhóm, xoá…) rồi bấm nút này sẽ bị xếp thiếu cửa sổ mà không hiểu vì sao.
  const LAYOUTS = [
    ['grid', 'Lưới'],
    ['columns', 'Hàng ngang'],
    ['cascade', 'Bậc thang'],
    ['stack', 'Chồng lên'],
  ];
  // Kiểu bố cục dùng CHUNG với tab "Cửa sổ" của Console đồng bộ: cùng kho
  // localStorage 'polySyncConsole' - chọn ở đâu thì bên kia cũng thấy, không đẻ
  // thêm cơ chế lưu mới. Kho đó giữ HAI khoá cùng nghĩa (winLayout = giá trị của
  // tab, winLayoutChoice = giá trị Console trả ra ngoài qua getLayout()); nút Đồng
  // bộ ở ngay dưới cũng đọc theo thứ tự winLayout → winLayoutChoice, nên ở đây
  // ĐỌC y hệt thứ tự đó và GHI cả hai, tránh cảnh hai màn hiện hai kiểu khác nhau.
  const SYNC_STORE_KEY = 'polySyncConsole';
  function readSyncStore() { try { return JSON.parse(localStorage.getItem(SYNC_STORE_KEY)) || {}; } catch { return {}; } }
  function savedLayout() {
    const s = readSyncStore();
    const v = s.winLayout || s.winLayoutChoice;
    return LAYOUTS.some(([k]) => k === v) ? v : 'grid';
  }
  function saveLayout(v) {
    try {
      const s = readSyncStore();
      s.winLayout = v;
      s.winLayoutChoice = v;
      localStorage.setItem(SYNC_STORE_KEY, JSON.stringify(s));
    } catch { /* localStorage bị chặn → vẫn xếp được, chỉ là không nhớ lựa chọn */ }
  }

  // Gọi thật xuống main process. `count` = số tiến trình Chrome được gửi lệnh dời.
  async function applyArrange(layout) {
    let ids = [];
    try { ids = await remote.profiles.runningIds(); } catch { ids = []; }
    if (!ids.length) return toast('Không có hồ sơ nào đang mở!', 'warn');
    try {
      const r = await vt.sync.arrange(ids, layout);
      const n = (r && r.count) || 0;
      toast(n > 0 ? tf('Đã sắp xếp {0} cửa sổ', n) : 'Không tìm thấy cửa sổ trình duyệt nào đang mở.', n > 0 ? 'ok' : 'warn');
    } catch { toast('Không sắp xếp được cửa sổ.', 'err'); }
  }

  // Bấm nút → xổ menu chọn bố cục, kiểu đang dùng mang icon dấu ✓.
  //
  // Dấu hiệu "đang chọn" đặt ở ICON chứ không nối thêm ký tự vào nhãn: i18n dịch
  // theo TEXT NODE khớp đúng khoá từ điển, nhãn kiểu "Lưới ✓" sẽ không khớp khoá
  // nào và đứng nguyên tiếng Việt ở en/ru/zh. Nhãn để trần tiếng Việt (đúng lệ của
  // các openMenu khác trong tệp này) cho MutationObserver của i18n tự dịch.
  function arrangeWindows(e) {
    const btn = e && e.currentTarget;
    const cur = savedLayout();
    openMenu(btn, LAYOUTS.map(([value, label]) => ({
      label,
      icon: value === cur ? 'check' : 'gridTile',
      onClick: () => { saveLayout(value); spinWhile(btn, () => applyArrange(value)); },
    })));
  }

  // -------------------------------------------------- toolbar / search
  // Group filter combobox (left of the search box). Rebuilt whenever groups
  // load/change so the option list stays in sync. Maps the two sentinel values
  // to the `filter` states: null = all groups, '' = ungrouped.
  const groupFilterWrap = el('div.group-filter');
  function groupFilterValue() { return filter == null ? '__all__' : filter === '' ? '__ungrouped__' : filter; }
  function renderGroupFilter() {
    clear(groupFilterWrap);
    const opts = [
      { value: '__all__', label: 'Tất cả các nhóm' },
      { value: '__ungrouped__', label: 'Chưa chia nhóm' },
      ...groups.map((g) => ({ value: g.id, label: g.name })),
    ];
    groupFilterWrap.appendChild(customSelect(opts, {
      value: groupFilterValue(), width: 190, height: 41,
      onChange: (v) => { filter = v === '__all__' ? null : v === '__ungrouped__' ? '' : v; selected.clear(); loadProfiles(); },
    }));
  }

  const searchInput = el('input.search-input', { placeholder: 'Tìm kiếm...', oninput: (e) => { search = e.target.value.trim(); applySearch(); } });
  const scopeBtn = el('button.icon-btn.scope-btn', { html: icon('filter'), title: 'Tìm kiếm nâng cao', onclick: () => openAdvancedSearch() });
  const searchBar = el('div.searchbar', {}, [el('span.ico', { html: icon('search') }), searchInput, scopeBtn]);

  // "Sắp xếp" - combobox cạnh phải ô tìm kiếm; chọn kiểu sắp xếp thì áp dụng ngay.
  const sortSelect = customSelect(SORT_OPTIONS.map(([value, label]) => ({ value, label })), {
    value: sortKey, width: 200, height: 41, className: 'sort-select',
    onChange: (v) => { sortKey = v; applySearch(); },
  });

  // ---------------------------------------------- advanced search popover
  let advPanel = null;
  function closeAdvPanel() {
    if (advPanel && advPanel.parentNode) advPanel.parentNode.removeChild(advPanel);
    advPanel = null;
    document.removeEventListener('mousedown', onAdvDoc, true);
    window.removeEventListener('resize', closeAdvPanel);
  }
  function onAdvDoc(e) {
    if (!advPanel) return;
    if (advPanel.contains(e.target) || scopeBtn.contains(e.target)) return;
    if (e.target.closest && e.target.closest('.pc-select-menu')) return; // clicking a portaled combobox menu
    closeAdvPanel();
  }
  function openAdvancedSearch() {
    if (advPanel) { closeAdvPanel(); return; }
    // Working copy; seed with current conditions or one blank row.
    const work = advConditions.length
      ? advConditions.map((c) => ({ ...c }))
      : [{ field: 'name', op: 'startsWith', value: '' }];
    const rowsHost = el('div.adv-rows');

    function renderRows() {
      clear(rowsHost);
      work.forEach((c, idx) => {
        const valueInput = el('input.input.adv-value', { value: c.value || '', oninput: (e) => { c.value = e.target.value; } });
        const setPlaceholder = () => {
          const lbl = (ADV_FIELDS.find(([v]) => v === c.field) || [, 'giá trị'])[1].toLowerCase();
          valueInput.placeholder = tf('Hãy nhập {0}.', lbl);
        };
        const setValueState = () => { valueInput.disabled = ADV_NO_VALUE(c.op); };
        setPlaceholder(); setValueState();
        const fieldSel = customSelect(ADV_FIELDS.map(([v, l]) => ({ value: v, label: l })),
          { value: c.field, width: 150, height: 40, className: 'adv-select', onChange: (v) => { c.field = v; setPlaceholder(); } });
        const opSel = customSelect(ADV_OPS.map(([v, l]) => ({ value: v, label: l })),
          { value: c.op, width: 200, height: 40, className: 'adv-select', onChange: (v) => { c.op = v; setValueState(); } });
        rowsHost.appendChild(el('div.adv-row', {}, [
          el('div.adv-label', { text: idx === 0 ? 'Thỏa mãn' : '' }),
          fieldSel, opSel, valueInput,
          work.length > 1
            ? el('button.icon-btn.danger.adv-del', { html: icon('trash'), title: 'Xóa điều kiện', onclick: () => { work.splice(idx, 1); renderRows(); } })
            : el('span.adv-del-spacer'),
        ]));
      });
    }
    renderRows();

    advPanel = el('div.adv-panel', {}, [
      rowsHost,
      el('button.adv-add', { html: `${icon('plusCircle')}<span>Thêm điều kiện</span>`, onclick: () => { work.push({ field: 'name', op: 'startsWith', value: '' }); renderRows(); } }),
      el('div.adv-foot', {}, [
        el('button.btn.primary', { text: 'Xác nhận', onclick: () => {
          advConditions = work.filter((c) => ADV_NO_VALUE(c.op) || String(c.value || '').trim() !== '');
          scopeBtn.classList.toggle('active', advConditions.length > 0);
          closeAdvPanel(); applySearch();
        } }),
        el('button.adv-clear', { text: 'Xóa', onclick: () => {
          advConditions = [];
          scopeBtn.classList.remove('active');
          closeAdvPanel(); applySearch();
        } }),
      ]),
    ]);
    document.body.appendChild(advPanel);
    const r = searchBar.getBoundingClientRect();
    advPanel.style.position = 'fixed';
    advPanel.style.top = (r.bottom + 6) + 'px';
    advPanel.style.left = Math.min(r.left, window.innerWidth - advPanel.offsetWidth - 12) + 'px';
    setTimeout(() => document.addEventListener('mousedown', onAdvDoc, true), 0);
    window.addEventListener('resize', closeAdvPanel);
  }

  const selIds = () => [...selected];

  const createProfileBtn = el('button.btn.primary', { html: `${icon('createProfile')}<span>Tạo hồ sơ</span>`, onclick: () => {
    // Thiếu quyền tạo → bung MODAL báo (không làm mờ nút, không chặn âm thầm). Có
    // quyền → mở màn Tạo hồ sơ như thường. Server vẫn enforce thật (403) nếu lách.
    if (!PERM.create) { alertDialog({ title: 'Không đủ quyền', message: PERM_MSG.create }); return; }
    ctx.navigate('profile_create');
  } });
  const toolbarRight = el('div.toolbar', {}, [
    selChip,
    el('button.icon-btn', { html: icon('tag'), title: 'Danh sách thẻ', onclick: openTagManager }),
    el('button.icon-btn', { html: icon('gridTile'), title: 'Sắp xếp cửa sổ các hồ sơ đang mở', onclick: arrangeWindows }),
    el('button.icon-btn', { html: icon('sync'), title: 'Làm mới danh sách hồ sơ', onclick: (e) => spinWhile(e.currentTarget, async () => { await Promise.all([loadGroups(), loadProfiles()]); }) }),
    createProfileBtn,
  ]);

  // Selection action bar - a row of bulk-action buttons that appears above the
  // grid when one or more rows are checked (mirrors MKTLogin's selection ribbon).
  const needSel = () => { if (!selected.size) { toast('Chưa chọn hồ sơ nào'); return false; } return true; };
  // Open every selected profile (optimistic running-state flip, then launch).
  const openSelected = async () => {
    if (!needSel()) return;
    // Hết hạn thuê bao → chặn mở (điều kiện đầu tiên, trước cả số dư hồ sơ). Nhắc Gia hạn.
    if (!(await gateNotExpired({ navigate: ctx.navigate }))) return;
    // Phương án B: cổng nhân MỘT LẦN cho cả lô (tránh bật nhiều modal). Chưa có nhân →
    // mở modal tải; huỷ / không tải được → dừng cả lô, không fallback.
    if (!(await ensureKernelReady('chromium'))) return;
    const ids = selIds();
    ids.forEach((id) => { opening.add(id); const p = profiles.find((x) => x.id === id); if (p) p.running = true; });
    renderPage();
    const failMsgs = []; // gom lỗi để báo RÕ (đặc biệt "đang mở ở máy khác") thay vì im lặng
    for (const id of ids) {
      let r; try { r = await remote.profiles.open(id); } catch { r = { ok: false }; }
      if (!r || !r.ok) {
        opening.delete(id); const p = profiles.find((x) => x.id === id); if (p) p.running = false;
        const nm = (p && p.name) ? p.name : id;
        failMsgs.push(`${nm}: ${(r && r.error) || t('không mở được')}`);
      }
    }
    renderPage();
    // Báo rõ để người dùng không tưởng tool lỗi - 1 hồ sơ hiện nguyên văn lý do; nhiều hồ sơ
    // gộp lại (thường là bị khoá vì đang mở ở máy khác).
    if (failMsgs.length === 1) toast(failMsgs[0], 'error');
    else if (failMsgs.length > 1) toast(tf('{0} hồ sơ không mở được - {1}', failMsgs.length, failMsgs[0]), 'error');
  };
  const closeSelected = async () => {
    if (!needSel()) return;
    for (const id of selIds()) await remote.profiles.close(id);
    setTimeout(loadProfiles, 500);
  };
  // "Bắt đầu đồng bộ hóa" - run action-sync straight away using the "Đồng bộ thao
  // tác" view's default settings (master = first open window, grid layout) instead
  // of navigating to that view, and pop the shared Console out as a right-docked
  // overlay. Scope = selected-and-open profiles, else every open window. Needs ≥2
  // windows (1 master + ≥1 slave). The button then toggles into a "Dừng đồng bộ"
  // state, driven by live engine status.
  let syncRunning = false;
  const syncBtn = el('button.btn.sb-grad', { html: `${icon('syncActions')}<span>Bắt đầu đồng bộ hóa</span>` });
  function paintSyncBtn() {
    // Any repaint (incl. the live onStatus push) clears the transient loading state so the
    // button can never get stuck disabled/dim after the spinner was shown during connect.
    syncBtn.classList.remove('is-loading');
    if (syncRunning) {
      syncBtn.innerHTML = `${icon('stopBold')}<span>Dừng đồng bộ</span>`;
      syncBtn.classList.add('is-stop');
    } else {
      syncBtn.innerHTML = `${icon('syncActions')}<span>Bắt đầu đồng bộ hóa</span>`;
      syncBtn.classList.remove('is-stop');
    }
  }
  // Chờ tới khi TẤT CẢ id đã thực sự chạy (browser spawn mất ~2–3s) trước khi bật
  // đồng bộ - engine cần cửa sổ/CDP sống. Poll runningIds tới khi đủ hoặc hết giờ.
  async function waitForRunning(ids, timeoutMs = 20000) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      let open = [];
      try { open = await remote.profiles.runningIds(); } catch { open = []; }
      if (ids.every((id) => open.includes(id))) return true;
      // Poll nhanh (150ms): profile:runningIds chỉ đọc registry trong main process (rẻ, không
      // gọi mạng), nên rút chu kỳ giúp phát hiện "đủ cửa sổ" sớm hơn → bật đồng bộ sớm hơn.
      await new Promise((res) => setTimeout(res, 150));
    }
    return false;
  }
  const startActionSync = async () => {
    // React INSTANTLY to the click: show the spinner BEFORE the first await (the
    // runningIds() IPC round-trip) so the button never sits there looking dead - that
    // pause-before-anything-happens was the "phản ứng rất lâu mới chạy" the user felt.
    syncBtn.disabled = true;
    syncBtn.classList.add('is-loading');
    syncBtn.innerHTML = '<span class="btn-spin"></span><span>Đang bật đồng bộ…</span>';
    // Phạm vi = các hồ sơ ĐANG CHỌN. Nếu chọn ≥2 hồ sơ mà cửa sổ chưa mở thì TỰ ĐỘNG
    // MỞ (giống "Tự động hóa"), chờ chúng chạy rồi mới bật đồng bộ - người dùng không
    // cần mở sẵn cửa sổ trước. Chọn <2 → giữ hành vi cũ: dùng mọi cửa sổ đang mở.
    const selectedIds = selIds();
    let ids;
    if (selectedIds.length >= 2) {
      ids = selectedIds;
      let open = [];
      try { open = await remote.profiles.runningIds(); } catch { open = []; }
      const toOpen = ids.filter((id) => !open.includes(id));
      if (toOpen.length) {
        // Phương án B: cần nhân đã cài để tự mở cửa sổ. Chưa có → modal tải (một lần);
        // huỷ / không tải được → huỷ bật đồng bộ (không fallback vendor/hệ thống).
        if (!(await ensureKernelReady('chromium'))) {
          syncBtn.disabled = false; paintSyncBtn(); return;
        }
        syncBtn.innerHTML = '<span class="btn-spin"></span><span>Đang mở cửa sổ…</span>';
        toOpen.forEach((id) => { opening.add(id); const p = profiles.find((x) => x.id === id); if (p) p.running = true; });
        renderPage();
        // Mở SONG SONG thay vì tuần tự. Mỗi remote.profiles.open() chờ một chuỗi I/O độc lập
        // (giành khoá server + getLaunchData + tra geo proxy + prep off-thread - prepPool vốn
        // "parallel across profiles" - rồi spawn), nên mở tuần tự N hồ sơ = cộng dồn N lần các
        // độ trễ đó → đây chính là "bấm đồng bộ khi cửa sổ chưa mở thì loading lâu". Chạy đồng
        // thời thì tổng thời gian ≈ mở 1 cửa sổ (phần spawn trên main thread chỉ vài ms/hồ sơ).
        await Promise.all(toOpen.map(async (id) => {
          try { const r = await remote.profiles.open(id); if (r && r.ok === false) { opening.delete(id); const p = profiles.find((x) => x.id === id); if (p) p.running = false; } }
          catch { opening.delete(id); const p = profiles.find((x) => x.id === id); if (p) p.running = false; }
        }));
        const ready = await waitForRunning(ids);
        toOpen.forEach((id) => opening.delete(id));
        if (!ready) {
          toast('Không mở đủ cửa sổ để đồng bộ. Vui lòng thử lại.', 'err');
          syncBtn.disabled = false; paintSyncBtn(); renderPage(); return;
        }
      }
    } else {
      let open = [];
      try { open = await remote.profiles.runningIds(); } catch { open = []; }
      ids = open;
    }
    if (ids.length < 2) {
      openModal({ title: 'Đồng bộ hóa',
        body: [el('div', { text: 'Vui lòng chọn hoặc mở từ 2 profile trở lên' })],
        footer: [el('button.btn.primary', { text: 'Đã hiểu', onclick: closeModal })] });
      syncBtn.disabled = false; paintSyncBtn(); return;
    }
    try {
      // Honour ALL the Console's pre-configured settings (localStorage polySyncConsole),
      // not just sim: the "Mô phỏng hành động" pacing AND the chosen window layout /
      // auto-arrange. Previously this hard-coded a grid tile and ignored everything the
      // user set in the Console - "chạy thì không theo thiết lập ở console đã cài sẵn".
      let store = {};
      try { store = JSON.parse(localStorage.getItem('polySyncConsole')) || {}; } catch { /* ignore */ }
      const sim = store.sim || null;
      const layout = store.winLayout || store.winLayoutChoice || 'grid';
      const autoArrange = store.autoArrange !== undefined ? !!store.autoArrange : true;
      const man = store.man || {};
      const r = await vt.sync.start(ids, { masterId: ids[0], sim });
      if (r && r.ok) {
        // Engine is live - give feedback IMMEDIATELY (don't make the user wait on the
        // window tiling + Console pop-out, which add round-trips and a whole BrowserWindow
        // spin-up). Flip the button optimistically; onStatus will confirm.
        syncRunning = true;
        paintSyncBtn();
        // r.count = số hồ sơ THỰC SỰ đồng bộ (main có thể đã loại hồ sơ Firefox). Dùng nó
        // thay cho ids.length, nếu không sẽ khoe nhầm số slave khi có hồ sơ bị bỏ qua.
        const nSlave = (Number.isFinite(r.count) ? r.count : ids.length) - 1;
        toast(tf('Đã bật đồng bộ thao tác: master + {0} slave', nSlave), 'ok');
        // Hồ sơ bị loại PHẢI được nói ra - im lặng thì người dùng tưởng đủ cả.
        if (r.warning) toast(r.warning, 'warn');
        // Non-critical follow-ups run in the background, honouring the Console config.
        // ALWAYS tile + surface the windows the moment sync starts - the user shouldn't have
        // to click "Sắp xếp cửa sổ" afterwards to actually SEE them. arrange()'s native Place
        // un-minimises and raises each window non-activatingly, so the master keeps focus.
        // Honour BOTH the auto layout AND the manual placement the user configured in Console.
        if (autoArrange) {
          vt.sync.arrange(ids, layout).catch(() => {});
        } else {
          const num = (v, d) => { const n = parseInt(v, 10); return Number.isFinite(n) ? n : d; };
          vt.sync.arrange(ids, 'manual', {
            x: num(man.x, 0), y: num(man.y, 0), w: num(man.w, 500), h: num(man.h, 640),
            hs: num(man.hs, 0), vs: num(man.vs, 0), perRow: Math.max(1, num(man.per, 1)),
          }).catch(() => {});
        }
        vt.console.open(ids).catch(() => {});   // pop Console out as its own window
      } else {
        toast((r && r.error) || 'Không bật được đồng bộ.', 'err');
      }
    } catch { toast('Không bật được đồng bộ.', 'err'); }
    syncBtn.disabled = false;
    paintSyncBtn();
  };
  const stopActionSync = async () => {
    syncBtn.disabled = true;
    syncBtn.classList.add('is-loading');
    syncBtn.innerHTML = '<span class="btn-spin"></span><span>Đang dừng…</span>';
    try { await vt.sync.stop(); } catch { /* ignore */ }
    try { await vt.console.close(); } catch { /* ignore */ }
    syncBtn.disabled = false;
    paintSyncBtn();
  };
  syncBtn.onclick = () => { syncRunning ? stopActionSync() : startActionSync(); };
  // Live engine status drives the button label (and survives view re-renders via a
  // single window-scoped subscription).
  if (window.__profSyncUnsub) { try { window.__profSyncUnsub(); } catch { /* ignore */ } }
  window.__profSyncUnsub = vt.sync.onStatus((st) => { syncRunning = !!(st && st.running); paintSyncBtn(); });
  vt.sync.status().then((st) => { syncRunning = !!(st && st.running); paintSyncBtn(); }).catch(() => {});
  // ---------------------------------------------------------------- RPA Plus
  // "Tự động hóa" - a 1:1 clone of AdsPower's "RPA Plus" task dialog. Picks a
  // saved automation flow, the selected profiles to run it on, the run order,
  // and either runs immediately or on a schedule. Tasks + schedules persist to
  // the SERVER (via rpa-store, scoped theo workspace) so they survive reloads and
  // are shared across machines; timers are re-armed here after the async load.
  rpaTasks();            // kick off the server load into window.__rpaTasks
  // rebuild timers for persisted scheduled tasks ONCE the server load resolves
  // (window.__rpaTasks is empty until then, so re-arm can't run synchronously).
  rpaReady().then(() => rearmScheduledTasks()).catch(() => {});

  // Task execution lives in rpa-store's shared runTask (runSharedTask) so both the
  // immediate-run and scheduled-fire paths register in the running registry and can
  // toggle the Nhiệm vụ "Hành động" cell between Chạy/Dừng.

  // Translate a schedule config into a first-fire delay (ms) + repeat interval
  // (ms, 0 = one-shot). Returns null when the time is invalid / already past.
  function scheduleTiming(s) {
    const now = Date.now();
    const WD = { Monday: 1, Tuesday: 2, Wednesday: 3, Thursday: 4, Friday: 5, Saturday: 6, Sunday: 0 };
    const startMs = s.startAt ? new Date(s.startAt).getTime() : NaN;
    if (s.freq === 'once') {
      const t = new Date(s.startAt).getTime();
      if (isNaN(t) || t <= now) return null;
      return { delay: t - now, interval: 0 };
    }
    if (s.freq === 'interval') {
      const min = Math.max(1, parseInt(s.intervalMin, 10) || 0);
      const step = min * 60000;
      // First fire at "Thời gian bắt đầu" (or now+step if unset), then every `step`.
      let first = !isNaN(startMs) ? startMs : now + step;
      if (first < now) { const k = Math.ceil((now - first) / step); first = first + k * step; }
      return { delay: Math.max(0, first - now), interval: step };
    }
    const parts = String(s.time || '').split(':');
    const hh = parseInt(parts[0], 10), mm = parseInt(parts[1], 10);
    if (isNaN(hh) || isNaN(mm)) return null;
    // Never fire before "Thời gian bắt đầu".
    const next = new Date(Math.max(now, isNaN(startMs) ? now : startMs));
    next.setSeconds(0, 0);
    if (s.freq === 'daily') {
      next.setHours(hh, mm, 0, 0);
      let g = 0;
      while ((next.getTime() < now || (!isNaN(startMs) && next.getTime() < startMs)) && g++ < 800) next.setDate(next.getDate() + 1);
      return { delay: next.getTime() - now, interval: 24 * 3600 * 1000 };
    }
    if (s.freq === 'weekly') {
      const target = WD[s.weekday] != null ? WD[s.weekday] : 1;
      next.setHours(hh, mm, 0, 0);
      let g = 0;
      while ((next.getDay() !== target || next.getTime() < now || (!isNaN(startMs) && next.getTime() < startMs)) && g++ < 800) next.setDate(next.getDate() + 1);
      return { delay: next.getTime() - now, interval: 7 * 24 * 3600 * 1000 };
    }
    if (s.freq === 'monthly') {
      const day = Math.min(28, Math.max(1, parseInt(s.monthday, 10) || 1));
      next.setDate(day); next.setHours(hh, mm, 0, 0);
      let g = 0;
      while ((next.getTime() < now || (!isNaN(startMs) && next.getTime() < startMs)) && g++ < 120) { next.setMonth(next.getMonth() + 1); next.setDate(day); next.setHours(hh, mm, 0, 0); }
      return { delay: next.getTime() - now, interval: 0 };  // re-armed on each fire
    }
    return null;
  }

  // Arm the timers for a scheduled task. Daily/weekly/interval repeat on a fixed
  // interval; monthly re-arms itself after each fire (month length varies).
  function clearTimers(task) {
    if (task._timer) { clearTimeout(task._timer); clearInterval(task._timer); task._timer = null; }
  }
  // Set up a scheduled task's timers only (no push / no persist). Returns false
  // when the schedule can't be armed (invalid time or already past its end).
  function armTaskTimers(task) {
    if (!task || !task.schedule) return false;
    const t = scheduleTiming(task.schedule);
    if (!t) return false;
    // "Thời gian kết thúc" (optional) - stop firing / arming past it.
    const endMs = task.schedule.endAt ? new Date(task.schedule.endAt).getTime() : NaN;
    const expired = () => !isNaN(endMs) && Date.now() > endMs;
    const fire = () => { if (expired()) { clearTimers(task); return; } runSharedTask(task); };
    if (task.schedule.freq === 'monthly') {
      const armNext = () => {
        const tt = scheduleTiming(task.schedule);
        if (!tt) return;
        if (!isNaN(endMs) && Date.now() + tt.delay > endMs) return;
        task._timer = setTimeout(() => { fire(); armNext(); }, tt.delay);
      };
      armNext();
    } else {
      if (!isNaN(endMs) && Date.now() + t.delay > endMs) return false;
      task._timer = setTimeout(() => {
        fire();
        if (t.interval) task._timer = setInterval(fire, t.interval);
      }, t.delay);
    }
    return true;
  }
  function armSchedule(task) {
    if (!armTaskTimers(task)) return false;
    window.__rpaTasks.push(task);
    Promise.resolve(saveTask(task)).catch((e) => notifyError(e, 'Lên lịch nhiệm vụ thất bại'));
    return true;
  }
  // Rebuild timers for persisted scheduled tasks after a reload (timers are not
  // serialized). Idempotent: only arms tasks that don't already have a timer.
  function rearmScheduledTasks() {
    (window.__rpaTasks || []).forEach((task) => {
      if (task && task.type === 'scheduled' && task.schedule && !task._timer) armTaskTimers(task);
    });
  }

  // Bản nháp modal Automation được lưu BỀN VỮNG vào localStorage nên không chỉ
  // sống sót qua đóng/mở modal ("tắt bật lại") mà còn qua cả reload (Ctrl+R) và
  // khởi động lại app - dữ liệu "Đầu vào" đã nhập KHÔNG bao giờ bị mất cho tới
  // khi nhiệm vụ được tạo/lên lịch thành công.
  const RPA_DRAFT_KEY = 'polyRpaPlusDraft';
  function loadRpaDraft() {
    try { const raw = localStorage.getItem(RPA_DRAFT_KEY); return raw ? JSON.parse(raw) : null; } catch { return null; }
  }
  function saveRpaDraft() {
    try {
      if (window.__rpaPlusDraft) localStorage.setItem(RPA_DRAFT_KEY, JSON.stringify(window.__rpaPlusDraft));
      else localStorage.removeItem(RPA_DRAFT_KEY);
    } catch { /* ignore */ }
    // Đầu vào được nhớ VĨNH VIỄN theo từng quy trình ở kho riêng (KHÔNG bị xoá khi
    // tạo nhiệm vụ) → sau này tạo nhiều quy trình khác nhau vẫn còn đủ đầu vào.
    saveRpaInputs();
  }
  // Kho đầu-vào bền vững, khoá theo flowId, độc lập với vòng đời bản nháp. Nhờ vậy
  // "mọi thứ ở Đầu vào đều còn luôn" kể cả sau khi đã submit nhiệm vụ / reload / đổi
  // qua lại giữa các quy trình.
  const RPA_INPUTS_KEY = 'polyRpaInputsByFlow';
  function loadRpaInputs() {
    try { const raw = localStorage.getItem(RPA_INPUTS_KEY); const o = raw ? JSON.parse(raw) : null; return (o && typeof o === 'object') ? o : {}; } catch { return {}; }
  }
  function saveRpaInputs() {
    try {
      const map = window.__rpaPlusDraft && window.__rpaPlusDraft.inputsByFlow;
      if (map && typeof map === 'object') localStorage.setItem(RPA_INPUTS_KEY, JSON.stringify(map));
    } catch { /* ignore */ }
  }
  // Xoá bản nháp (name/note/lịch…) sau khi submit NHƯNG GIỮ NGUYÊN kho đầu-vào
  // theo quy trình để lần sau chọn lại quy trình đó vẫn còn dữ liệu.
  function clearRpaDraft() { window.__rpaPlusDraft = null; try { localStorage.removeItem(RPA_DRAFT_KEY); } catch { /* ignore */ } }

  // "Cấu hình chạy" là một TÙY CHỌN BỀN VỮNG (giống kho đầu-vào), độc lập với vòng
  // đời bản nháp: nó KHÔNG bị xoá khi tạo nhiệm vụ và SỐNG SÓT qua reload/khởi động
  // lại app. Trước đây các ô Cấu-hình-chạy chỉ ghi vào state.run trong bộ nhớ mà
  // không lưu đâu cả → reset app là mất hết cài đặt. Giờ mỗi lần đổi ô đều ghi vào
  // kho riêng này và khi mở modal sẽ nạp lại làm giá trị mặc định.
  const DEFAULT_RUN = { winCount: '4', winW: '500', winH: '640', winScale: '0.8', gap: '0', openDelay: '2000', threads: '5', mouseSim: true };
  const RPA_RUN_KEY = 'polyRpaRunConfig';
  function loadRpaRun() {
    try { const raw = localStorage.getItem(RPA_RUN_KEY); const o = raw ? JSON.parse(raw) : null; return (o && typeof o === 'object') ? o : {}; } catch { return {}; }
  }
  function saveRpaRun() {
    try { const r = window.__rpaPlusDraft && window.__rpaPlusDraft.run; if (r && typeof r === 'object') localStorage.setItem(RPA_RUN_KEY, JSON.stringify(r)); } catch { /* ignore */ }
  }

  function openRpaPlus() {
    if (!needSel()) return;
    // Tự động hoá (RPA) mở cho MỌI gói, kể cả Free - KHÔNG chặn nâng cấp ở đây.
    // Giữ lại bản nháp giữa các lần đóng/mở modal: nếu người dùng đóng modal
    // ("tắt") rồi mở lại ("bật lại") thì dữ liệu đã nhập KHÔNG bị reset. Bản nháp
    // được xoá (về null) ngay khi tạo/lên lịch nhiệm vụ thành công ở submit().
    const state = window.__rpaPlusDraft || loadRpaDraft() || {
      name: '',
      note: '',
      group: '',
      flowId: '',
      inputs: {},      // "Đầu vào" values của quy trình đang chọn (= inputsByFlow[flowId])
      inputsByFlow: {},// nhớ "Đầu vào" theo từng quy trình → đổi qua lại KHÔNG mất dữ liệu
      order: 'ordered',
      type: 'normal',
      priority: false,
      runNow: true,
      ids: selIds().slice(),
      sched: { freq: 'once', startAt: '', endAt: '', intervalMin: '1', time: '', weekday: 'Monday', monthday: '1' },
      // "Cấu hình chạy" tab (mirrors MKTLogin's run layout - stored with the task).
      // Nạp từ kho tùy-chọn bền vững để cài đặt cũ không bị mất khi mở modal mới.
      run: { ...DEFAULT_RUN, ...loadRpaRun() },
    };
    // `state` được tham chiếu trực tiếp làm bản nháp - mọi thay đổi tự động lưu.
    window.__rpaPlusDraft = state;
    // Hồ sơ LUÔN đồng bộ theo lựa chọn hiện tại của lưới: mở modal từ nút "Tự động hóa"
    // đã yêu cầu phải có hồ sơ đang chọn (needSel), nên danh sách chip phải phản ánh
    // đúng những hồ sơ đang tick - KHÔNG dùng lại `ids` cũ kẹt trong bản nháp (bug:
    // mở lần đầu 1 hồ sơ rồi chọn thêm, mở lại vẫn chỉ thấy 1). Các trường nháp khác
    // (tên/ghi chú/quy trình/đầu vào/cấu hình chạy) vẫn được giữ nguyên.
    state.ids = selIds().slice();
    // "Cấu hình chạy" LUÔN lấy từ kho tùy-chọn bền vững (nguồn chuẩn duy nhất): bắt
    // đầu từ mặc định, phủ lên bản nháp cũ (nếu có), rồi phủ kho bền vững (mới nhất,
    // được ghi ở MỖI lần đổi ô). Nhờ vậy reset app không còn mất dữ liệu đã cài, và
    // các khoá mới (nếu bổ sung sau này) vẫn có mặc định.
    state.run = { ...DEFAULT_RUN, ...(state.run || {}), ...loadRpaRun() };
    // Chuẩn hoá cho bản nháp cũ + đồng bộ bucket đầu-vào của quy trình đang chọn.
    // Nạp kho đầu-vào BỀN VỮNG (theo flowId) rồi hợp nhất với bản nháp - kho là
    // nguồn giữ dữ liệu lâu dài, bản nháp chỉ ưu tiên cho quy trình đang gõ dở.
    state.inputsByFlow = { ...loadRpaInputs(), ...(state.inputsByFlow || {}) };
    if (state.flowId) { state.inputsByFlow[state.flowId] = state.inputs || state.inputsByFlow[state.flowId] || {}; state.inputs = state.inputsByFlow[state.flowId]; }
    let flowsList = [];
    vt.flows.list()
      .then((fl) => { flowsList = Array.isArray(fl) ? fl : []; build(); })
      .catch(() => { flowsList = []; build(); });

    function flowsInGroup() {
      return flowsList.filter((f) => f && (!state.group || (f.group || '') === state.group));
    }

    function build() {
      // ---- Số hồ sơ (removable chips) ----
      const chipsWrap = el('div.rpp-chips');
      const countBadge = el('span.rpp-count', { text: '0' });
      const renderChips = () => {
        clear(chipsWrap);
        countBadge.textContent = String(state.ids.length);
        if (!state.ids.length) { chipsWrap.appendChild(el('span.rpp-hint', { text: 'Chưa có hồ sơ nào' })); return; }
        state.ids.forEach((id) => {
          const p = profiles.find((x) => x.id === id);
          // Show the short ID (not the full name) so many selected profiles stay
          // compact; the full name lives in the chip's tooltip.
          const label = p ? shortId(p) : id;
          const title = p ? (p.name || '') : id;
          chipsWrap.appendChild(el('span.rpp-chip', { title }, [
            el('span', { text: label }),
            el('button', { html: icon('close'), title: 'Bỏ', onclick: () => { state.ids = state.ids.filter((x) => x !== id); renderChips(); syncOk(); } }),
          ]));
        });
      };

      // ---- Thông tin: Tên + Ghi chú ----
      const nameInput = el('input.input', { value: state.name, maxlength: '64', placeholder: 'Để trống sẽ tự đặt tên khi lưu' });
      nameInput.addEventListener('input', () => { state.name = nameInput.value; });
      const noteInput = el('textarea.input.rpp-textarea', { rows: '4', placeholder: 'Ghi chú' });
      noteInput.addEventListener('input', () => { state.note = noteInput.value; });

      // ---- Thực thi tiến trình (group + process pickers) ----
      const groupOpts = [{ value: '', label: 'Tất cả' }];
      const seenG = new Set();
      flowsList.forEach((f) => { const g = (f && f.group) || ''; if (g && !seenG.has(g)) { seenG.add(g); groupOpts.push({ value: g, label: g }); } });
      const procWrap = el('div', { style: { flex: '1 1 0', minWidth: '0' } });
      const buildProc = () => {
        clear(procWrap);
        const opts = flowsInGroup().map((f) => ({ value: f.id, label: f.name || '(không tên)' }));
        procWrap.appendChild(customSelect(opts, {
          value: state.flowId, placeholder: 'Vui lòng chọn quy trình', height: 38, width: '100%',
          // Đổi quy trình → chuyển sang bucket đầu-vào của quy trình đó (nhớ lại nếu
          // đã nhập trước đây) thay vì xoá trắng → không mất dữ liệu khi đổi qua lại.
          onChange: (v) => { state.flowId = v; state.inputs = (state.inputsByFlow[v] = state.inputsByFlow[v] || {}); renderInput(); syncOk(); saveRpaDraft(); },
        }));
      };
      const groupSel = customSelect(groupOpts, {
        value: state.group, width: 160, height: 38,
        // Đổi nhóm → bỏ chọn quy trình (inputs tạm rỗng vì chưa có quy trình) nhưng
        // GIỮ nguyên inputsByFlow để chọn lại quy trình cũ vẫn còn dữ liệu đầu vào.
        onChange: (v) => { state.group = v; state.flowId = ''; state.inputs = {}; buildProc(); renderInput(); syncOk(); saveRpaDraft(); },
      });

      // ---- Conditional area (normal vs scheduled) ----
      const cond = el('div.rpp-cond');
      const FREQS = [['once', 'Một lần'], ['interval', 'Khoảng thời gian'], ['daily', 'Hàng ngày'], ['weekly', 'Hàng tuần'], ['monthly', 'Hàng tháng']];
      const WEEKDAYS = [['Monday', 'Thứ hai'], ['Tuesday', 'Thứ ba'], ['Wednesday', 'Thứ tư'], ['Thursday', 'Thứ năm'], ['Friday', 'Thứ sáu'], ['Saturday', 'Thứ bảy'], ['Sunday', 'Chủ nhật']];

      const radio = (name, val, label, cur, on) => {
        const input = el('input', { type: 'radio', name });
        if (cur === val) input.checked = true;
        input.addEventListener('change', () => { if (input.checked) on(val); });
        return el('label.radio', {}, [input, el('span', { text: label })]);
      };
      const switchBtn = (cur, on) => {
        const sw = el('button.switch' + (cur ? '.on' : ''), { type: 'button' }, [el('span.knob')]);
        sw.addEventListener('click', () => { const next = !sw.classList.contains('on'); sw.classList.toggle('on', next); on(next); });
        return sw;
      };

      const START_HINT = 'Phải lớn hơn thời điểm hiện tại';
      const END_HINT = 'Phải sau thời gian bắt đầu. Nếu không chọn nghĩa là nhiệm vụ không có thời gian kết thúc cụ thể.';
      const dtField = (key, hint) => {
        const picker = customDateTime({ value: state.sched[key], mode: 'datetime', onChange: (v) => { state.sched[key] = v; syncOk(); } });
        return el('div.rpp-ctrl', {}, [picker, hint ? el('span.rpp-hint', { text: hint }) : null]);
      };
      const timeField = () => customDateTime({ value: state.sched.time, mode: 'time', onChange: (v) => { state.sched.time = v; syncOk(); } });

      // "Thực hiện ngay" shows no extra fields (runs on Bắt đầu); "Lên lịch thực
      // hiện" reveals the frequency picker + its per-cadence time fields - matching
      // MKTLogin's Automation → Tùy chọn tab exactly.
      const renderCond = () => {
        clear(cond);
        if (state.type === 'normal') return;
        const freqRow = el('div.rpp-radios.wrap', {}, FREQS.map(([v, l]) =>
          radio('rpp-freq', v, l, state.sched.freq, (nv) => { state.sched.freq = nv; renderCond(); syncOk(); })));
        cond.appendChild(formRow('Tần suất thực hiện', freqRow));

        const f = state.sched.freq;
        if (f === 'once') {
          cond.appendChild(formRow('Thời gian thực hiện', dtField('startAt', START_HINT), true));
        } else if (f === 'interval') {
          const inp = el('input.input', { type: 'number', min: '1', value: state.sched.intervalMin });
          inp.addEventListener('input', () => { state.sched.intervalMin = inp.value; syncOk(); });
          cond.appendChild(formRow('Khoảng thời gian (phút)', el('div.rpp-ctrl', {}, [inp, el('span.rpp-hint', { text: 'Thời gian giữa các lần thực hiện tác vụ, đơn vị là phút' })]), true));
          cond.appendChild(formRow('Thời gian bắt đầu', dtField('startAt', START_HINT), true));
          cond.appendChild(formRow('Thời gian kết thúc', dtField('endAt', END_HINT)));
        } else if (f === 'daily') {
          cond.appendChild(formRow('Thời gian thực hiện', timeField(), true));
          cond.appendChild(formRow('Thời gian bắt đầu', dtField('startAt', START_HINT), true));
          cond.appendChild(formRow('Thời gian kết thúc', dtField('endAt', END_HINT)));
        } else if (f === 'weekly') {
          const wsel = customSelect(WEEKDAYS.map(([v, l]) => ({ value: v, label: l })), { value: state.sched.weekday, width: 160, height: 38, onChange: (v) => { state.sched.weekday = v; } });
          cond.appendChild(formRow('Thời gian thực hiện', el('div.rpp-inline', {}, [wsel, timeField()]), true));
          cond.appendChild(formRow('Thời gian bắt đầu', dtField('startAt', START_HINT), true));
          cond.appendChild(formRow('Thời gian kết thúc', dtField('endAt', END_HINT)));
        } else if (f === 'monthly') {
          const dsel = customSelect(Array.from({ length: 28 }, (_, i) => ({ value: String(i + 1), label: 'Ngày ' + (i + 1) })), { value: state.sched.monthday, width: 160, height: 38, onChange: (v) => { state.sched.monthday = v; } });
          cond.appendChild(formRow('Thời gian thực hiện', el('div.rpp-inline', {}, [dsel, timeField()]), true));
          cond.appendChild(formRow('Thời gian bắt đầu', dtField('startAt', START_HINT), true));
          cond.appendChild(formRow('Thời gian kết thúc', dtField('endAt', END_HINT)));
        }
      };

      // ---- Loại nhiệm vụ segmented control ("Thực hiện ngay" | "Lên lịch") ----
      let segNow, segSched;
      const segEl = el('div.pc-seg', {}, [
        (segNow = el('button.seg-opt' + (state.type === 'normal' ? '.active' : ''), { type: 'button', text: 'Thực hiện ngay' })),
        (segSched = el('button.seg-opt' + (state.type === 'scheduled' ? '.active' : ''), { type: 'button', text: 'Lên lịch thực hiện' })),
      ]);
      const setType = (t) => {
        if (state.type === t) return;
        state.type = t;
        segNow.classList.toggle('active', t === 'normal');
        segSched.classList.toggle('active', t === 'scheduled');
        renderCond();
        syncOk();
      };
      segNow.onclick = () => setType('normal');
      segSched.onclick = () => setType('scheduled');

      // ---- Đầu vào tab: schema-driven UI built from the selected flow's process
      // variables (graph.variables = the "Biến quy trình" declared on the start
      // node). One typed control per variable; values collected on state.inputs. ----
      const inputBody = el('div.rpp-tabpanel');
      const varsCache = {};   // flowId -> variables[]
      async function loadVars(flowId) {
        if (varsCache[flowId]) return varsCache[flowId];
        let vars = [];
        try {
          const f = await vt.flows.get(flowId);
          const g = typeof f?.graph === 'string' ? JSON.parse(f.graph) : (f?.graph || {});
          // Bỏ biến làm việc (local: true) - biến nội bộ dùng để gán/tính toán trong
          // quy trình, không phải tham số người chạy phải điền. Biến cũ chưa có cờ
          // vẫn là tham số đầu vào (giữ nguyên hành vi quy trình đã lưu).
          vars = Array.isArray(g.variables) ? g.variables.filter((v) => v && v.name && !v.local) : [];
        } catch { vars = []; }
        varsCache[flowId] = vars;
        return vars;
      }
      // MKTLogin's "..." data-source picker, shown on String inputs in the Đầu
      // vào form: a menu that binds the value to a text / excel / json / image
      // file or a folder path. Uses the Electron file dialog (vt.dialog.openFile).
      function pickDataSource(anchor, onPick) {
        const pick = async (opts) => { try { const p = await window.vt?.dialog?.openFile(opts); if (p) onPick(p); } catch { /* cancelled */ } };
        openMenu(anchor, [
          { label: 'Chọn tệp văn bản', icon: 'fileText', onClick: () => pick({ filters: [{ name: 'Tệp văn bản', extensions: ['txt'] }] }) },
          { label: 'Chọn tệp excel', icon: 'table', onClick: () => pick({ filters: [{ name: 'Excel', extensions: ['xlsx', 'xls', 'csv'] }] }) },
          { label: 'Chọn tệp json', icon: 'fileText', onClick: () => pick({ filters: [{ name: 'JSON', extensions: ['json'] }] }) },
          { label: 'Chọn tệp hình ảnh', icon: 'camera', onClick: () => pick({ filters: [{ name: 'Hình ảnh', extensions: ['png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp'] }] }) },
          { label: 'Chọn thư mục', icon: 'folder', onClick: () => pick({ directory: true }) },
        ]);
      }
      // A single "Đầu vào" field, rendered 1:1 like MKTLogin's task Đầu vào tab:
      // a floating-label outlined box (label = the variable name) wrapping a
      // type-appropriate control. String → text + "..." picker; Range → Min/Max;
      // Array/Object/Text → JSON textarea; Boolean → toggle; Number → number.
      function invarBox(name, inner, multi) {
        return el('div.rpp-invar' + (multi ? '.is-multi' : ''), {}, [
          el('label.rpp-invar-label', { text: name }),
          inner,
        ]);
      }
      function inputField(v) {
        const key = v.name;
        const disp = v.label || v.name;   // nhãn hiển thị thân thiện; key vẫn là tên biến sạch
        const t = v.type || 'String';
        const has = Object.prototype.hasOwnProperty.call(state.inputs, key);
        const cur = has ? state.inputs[key] : (v.value != null ? v.value : '');
        if (t === 'Boolean') {
          const on = cur === true || cur === 'true' || cur === 1 || cur === '1';
          state.inputs[key] = on;
          return invarBox(disp, el('div.rpp-invar-line', {}, [switchBtn(on, (val) => { state.inputs[key] = val; saveRpaDraft(); })]));
        }
        if (t === 'Number') {
          const inp = el('input.rpp-invar-input', { type: 'number', value: cur, placeholder: v.desc || '' });
          inp.addEventListener('input', () => { state.inputs[key] = inp.value; });
          return invarBox(disp, el('div.rpp-invar-line', {}, [inp]));
        }
        if (t === 'Range') {
          const r = (cur && typeof cur === 'object') ? cur : { min: '', max: '' };
          state.inputs[key] = r;
          const mkNum = (fld, ph) => {
            const i = el('input.rpp-invar-input', { type: 'number', value: r[fld] != null ? r[fld] : '', placeholder: ph });
            i.addEventListener('input', () => { r[fld] = i.value; });
            return i;
          };
          return invarBox(disp, el('div.rpp-invar-range', {}, [mkNum('min', 'Min'), el('span', { text: '-' }), mkNum('max', 'Max')]));
        }
        if (t === 'Array' || t === 'List' || t === 'Object' || t === 'Text') {
          const init = typeof cur === 'object' ? JSON.stringify(cur, null, 2) : String(cur == null ? '' : cur);
          const ta = el('textarea.rpp-invar-input.rpp-invar-area', { rows: '3', placeholder: v.desc || (t === 'Object' ? '{}' : t === 'Text' ? '' : '[]') });
          ta.value = init;
          ta.addEventListener('input', () => { state.inputs[key] = ta.value; });
          return invarBox(disp, ta, true);
        }
        // File / Folder → path text + a browse button that opens the OS file or
        // folder dialog directly (AdsPower's File/Folder input), value = chosen path.
        if (t === 'Folder') {
          const inp = el('input.rpp-invar-input', { value: cur, placeholder: v.desc || 'Đường dẫn thư mục local' });
          inp.addEventListener('input', () => { state.inputs[key] = inp.value; });
          const browse = el('button.rpp-invar-dots', { type: 'button', title: 'Chọn thư mục', html: icon('folder'),
            onclick: async () => { try { const p = await window.vt?.dialog?.openFile({ directory: true }); if (p) { inp.value = p; state.inputs[key] = p; saveRpaDraft(); } } catch { /* cancelled */ } } });
          return invarBox(disp, el('div.rpp-invar-line', {}, [inp, browse]));
        }
        if (t === 'File') {
          // Chọn được NHIỀU tệp: textarea (mỗi dòng 1 tệp) + nút duyệt gom thêm.
          const ta = el('textarea.rpp-invar-input.rpp-invar-area', { rows: '3', placeholder: v.desc || 'Chọn tệp (chọn được nhiều) hoặc nhập đường dẫn, mỗi dòng 1 tệp' });
          ta.value = String(cur == null ? '' : cur);
          ta.addEventListener('input', () => { state.inputs[key] = ta.value; });
          const addPaths = (picked) => {
            const arr = Array.isArray(picked) ? picked : [picked];
            const list = ta.value.split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
            for (const p of arr) { if (p && !list.includes(p)) list.push(p); }
            ta.value = list.join('\n'); state.inputs[key] = ta.value; saveRpaDraft();
          };
          const browse = el('button.rpp-invar-dots', { type: 'button', title: 'Chọn tệp (chọn được nhiều)', html: icon('folder'),
            onclick: async () => { try { const p = await window.vt?.dialog?.openFile({ multi: true }); if (p) addPaths(p); } catch { /* cancelled */ } } });
          return invarBox(disp, el('div.rpp-invar-line', {}, [ta, browse]), true);
        }
        // String → single-line text + "..." data-source picker (text/excel/json/image/folder)
        const inp = el('input.rpp-invar-input', { value: cur, placeholder: v.desc || '' });
        inp.addEventListener('input', () => { state.inputs[key] = inp.value; });
        const dots = el('button.rpp-invar-dots', { type: 'button', title: 'Chọn nguồn dữ liệu', html: icon('moreHorizontal'),
          onclick: (e) => pickDataSource(e.currentTarget, (p) => { inp.value = p; state.inputs[key] = p; saveRpaDraft(); }) });
        return invarBox(disp, el('div.rpp-invar-line', {}, [inp, dots]));
      }
      async function renderInput() {
        clear(inputBody);
        if (!state.flowId) { inputBody.appendChild(el('div.rpp-input-empty', { text: 'Vui lòng chọn quy trình' })); return; }
        const fid = state.flowId;
        const vars = await loadVars(fid);
        if (fid !== state.flowId) return;   // user switched flow while loading
        clear(inputBody);
        if (!vars.length) { inputBody.appendChild(el('div.rpp-input-empty', { text: 'Quy trình này không có tham số đầu vào.' })); return; }
        vars.forEach((v) => inputBody.appendChild(inputField(v)));
      }

      // ---- footer / validation ----
      const okBtn = el('button.btn.primary', { text: 'Bắt đầu', onclick: submit });
      function schedReady() {
        const s = state.sched;
        if (s.freq === 'once') return !!s.startAt;
        if (s.freq === 'interval') return parseInt(s.intervalMin, 10) > 0 && !!s.startAt;
        return !!s.time && !!s.startAt;  // daily/weekly/monthly
      }
      function syncOk() {
        const scheduled = state.type === 'scheduled';
        const ok = state.ids.length > 0 && !!state.flowId && (!scheduled || schedReady());
        okBtn.disabled = !ok;
        okBtn.textContent = scheduled ? 'Lên lịch' : 'Bắt đầu';
      }
      function submit() {
        // Tên nhiệm vụ hiển thị ở cell: nếu bỏ trống thì lấy CHUẨN theo tên quá
        // trình (quy trình) đã chọn, thay vì RPA_TASK_<timestamp>.
        const selFlow = flowsList.find((f) => f && f.id === state.flowId);
        const flowNm = selFlow ? (selFlow.name || '') : '';
        const task = {
          id: 'task_' + Date.now(), name: (state.name.trim() || flowNm || 'RPA_TASK_' + Date.now()), flowId: state.flowId,
          profileIds: state.ids.slice(), order: state.order === 'random' ? 'random' : 'ordered',
          type: state.type, priority: state.priority, note: state.note,
          inputs: { ...state.inputs },
          run: { ...state.run },
          schedule: { ...state.sched }, createdAt: Date.now(),
        };
        if (state.type === 'scheduled') {
          if (!armSchedule(task)) { toast('Thời gian không hợp lệ', 'err'); return; }
          clearRpaDraft();                // tạo nhiệm vụ thành công → bỏ bản nháp (RAM + localStorage)
          closeModal();
          toast(tf('Đã lên lịch nhiệm vụ "{0}"', task.name), 'ok');
          return;
        }
        // normal
        window.__rpaTasks.push(task);
        Promise.resolve(saveTask(task)).catch((e) => notifyError(e, 'Tạo nhiệm vụ thất bại'));
        clearRpaDraft();                  // tạo nhiệm vụ thành công → bỏ bản nháp (RAM + localStorage)
        closeModal();
        if (state.runNow) {
          // Điều hướng sang trang "Nhiệm vụ" rồi chạy bằng runTask chung để cell
          // "Hành động" hiển thị trạng thái Chạy/Dừng thực (có thể dừng được).
          ctx.navigate('tasks');
          runSharedTask(task);
        } else toast(tf('Đã tạo nhiệm vụ "{0}"', task.name), 'ok');
      }

      // ---- Cấu hình chạy tab (mirrors MKTLogin's run layout) ----
      const numField = (key, opts = {}) => {
        const inp = el('input.input', { type: 'number', value: state.run[key] });
        if (opts.min != null) inp.min = String(opts.min);
        // Ghi NGAY vào kho tùy-chọn bền vững mỗi lần gõ → reset app vẫn còn cài đặt.
        inp.addEventListener('input', () => { state.run[key] = inp.value; saveRpaRun(); });
        return inp;
      };
      // "Mô phỏng chuột" nằm CHUNG lưới .rpp-run2 nhưng ép về CỘT TRÁI (grid-column:1),
      // xuống hàng mới → nhãn + toggle thẳng dọc với các textbox cột trái.
      const mouseRow = formRow('Mô phỏng chuột', switchBtn(state.run.mouseSim, (v) => { state.run.mouseSim = v; saveRpaRun(); }));
      mouseRow.style.gridColumn = '1';
      const panelRun = el('div.rpp-tabpanel', {}, [
        el('div.rpp-run2', {}, [
          formRow('Số cửa sổ mỗi hàng', numField('winCount', { min: 1 })),
          formRow('Tỉ lệ thu phóng', numField('winScale', { min: 0 })),
          formRow('Chiều rộng cửa sổ', numField('winW', { min: 1 })),
          formRow('Chiều cao cửa sổ', numField('winH', { min: 1 })),
          formRow('Khoảng cách cửa sổ', numField('gap', { min: 0 })),
          formRow('Độ trễ mở (ms)', numField('openDelay', { min: 0 })),
          formRow('Số luồng đồng thời', numField('threads', { min: 1 })),
          mouseRow,
        ]),
      ]);

      // ---- Tùy chọn tab (main) ----
      const panelOpt = el('div.rpp-tabpanel', {}, [
        el('div.rpp-note', { text: 'Dữ liệu nhiệm vụ có thể được xem và quản lý trên nhiều thiết bị; việc thực thi nhiệm vụ và bật nhiệm vụ theo lịch chỉ có hiệu lực trên thiết bị hiện tại.' }),
        formRow('Hồ sơ', el('div.rpp-hosonum', {}, [countBadge, chipsWrap])),
        formRow('Quy trình', el('div.rpp-inline', {}, [groupSel, procWrap]), true),
        formRow('Loại nhiệm vụ', segEl),
        cond,
      ]);

      // ---- Thông tin tab ----
      const panelInfo = el('div.rpp-tabpanel', {}, [
        formRow('Tên nhiệm vụ', nameInput),
        formRow('Ghi chú', noteInput),
      ]);

      // ---- tab bar ----
      // Dùng CHUNG bộ icon với modal "Chỉnh sửa nhiệm vụ" (task_edit.js) cho đồng bộ:
      // Đầu vào→tabInput, Cấu hình chạy→tabRun, Thông tin→tabInfo. Tab "Tùy chọn"
      // không có ở task_edit nên dùng tabProfile (nội dung chính là chọn Hồ sơ).
      const TABS = [
        ['opt', 'Tùy chọn', 'tabProfile', panelOpt],
        ['run', 'Cấu hình chạy', 'tabRun', panelRun],
        ['input', 'Đầu vào', 'tabInput', inputBody],
        ['info', 'Thông tin', 'tabInfo', panelInfo],
      ];
      const tabBody = el('div.rpp-tabbody');
      const tabBtns = {};
      const showTab = (key) => {
        TABS.forEach(([k, , , panel]) => {
          const on = k === key;
          tabBtns[k].classList.toggle('active', on);
          panel.style.display = on ? '' : 'none';
        });
      };
      const tabBar = el('div.rpp-tabs', {}, TABS.map(([k, label, ic]) => {
        const b = el('button.rpp-tab', { type: 'button', html: `${icon(ic)}<span>${label}</span>`, onclick: () => showTab(k) });
        tabBtns[k] = b;
        return b;
      }));
      TABS.forEach(([, , , panel]) => tabBody.appendChild(panel));

      const formRoot = el('div.rpp-form.rpp-modal', {}, [tabBar, tabBody]);
      // Lưu bản nháp mỗi khi người dùng gõ/đổi giá trị bất kỳ trong modal (bao
      // gồm toàn bộ field "Đầu vào") → dữ liệu bền vững qua reload/khởi động lại.
      formRoot.addEventListener('input', saveRpaDraft, false);
      formRoot.addEventListener('change', saveRpaDraft, false);
      openModal({
        title: 'Automation', width: 840,
        body: [formRoot],
        footer: [el('button.btn', { text: 'Hủy', onclick: closeModal }), okBtn],
      });

      buildProc();
      renderChips();
      renderCond();
      renderInput();
      showTab('opt');
      syncOk();
      saveRpaDraft();   // lưu ngay trạng thái (đã chuẩn hoá) để bền vững qua reload
    }
  }

  // Left-label / right-control row used throughout the RPA Plus dialog.
  function formRow(label, control, required) {
    return el('div.rpp-row', {}, [
      el('div.rpp-label', {}, [required ? el('span.req', { text: '*' }) : null, document.createTextNode(label)]),
      el('div.rpp-ctrlcol', {}, [control]),
    ]);
  }

  // Fixed datagrid toolbar - always visible (no longer gated on a checkbox).
  // Actions that need a selection prompt when nothing is chosen.
  // "Đóng" is disabled until at least one profile is actually open.
  barCloseBtn = el('button.btn', { html: `${icon('closeCircle')}<span>Đóng</span>`, onclick: (e) => withSpin(e.currentTarget, closeSelected) });
  barCloseBtn.disabled = !profiles.some((p) => p.running);
  // Nút ghi (sửa/xóa/di chuyển) trong thanh chọn - giữ tham chiếu để khóa mềm.
  const bulkUpdateProxyBtn = el('button.btn', { html: `${icon('proxyUpdate')}<span>Cập nhật proxy</span>`, onclick: () => { if (needSel()) updateProxyBulk(selIds()); } });
  // "Xuất" / "Di chuyển" ĐÃ CHUYỂN vào dropdown "Thêm" (xem cuối selBar) - hai chỗ của
  // chúng trên thanh nay là "Web RTC" và "Trình duyệt". Cả hai đều sửa MỘT thiết lập
  // trong vân tay và giữ nguyên phần còn lại (xem bulkSetWebRtc / bulkSetKernel).
  const bulkWebRtcBtn = el('button.btn', { html: `${icon('webRtcMark')}<span>Web RTC</span>`, onclick: () => { if (needSel()) bulkSetWebRtc(selIds()); } });
  const bulkKernelBtn = el('button.btn', { html: `${icon('browserGlobe')}<span>Trình duyệt</span>`, onclick: () => { if (needSel()) bulkSetKernel(selIds()); } });
  const bulkFpBtn = el('button.btn', { html: `${icon('fingerprintNew')}<span>Dấu vân tay mới</span>`, onclick: bulkNewFingerprint });
  // Dropdown "Reset proxy" MỞ KHI TRỎ CHUỘT VÀO (hoverMenu), không cần bấm - giống nút
  // ba chấm trong từng hàng của lưới. Bấm vẫn mở như cũ, và hoverMenu tự bỏ qua khi nút
  // đang khóa mềm nên click vẫn chỉ hiện toast nhắc quyền.
  // Danh sách mục truyền dạng HÀM: nó đọc selIds() lúc bấm nên phải dựng lại mỗi lần mở.
  const bulkResetProxyBtn = hoverMenu(el('button.btn.has-caret', { html: `${icon('proxyOff')}<span>Reset proxy</span><span class="btn-divider"></span>${icon('chevronDown')}` }), () => [
      { label: 'Không dùng proxy', icon: 'proxyNone', onClick: () => { if (needSel()) resetProxy(selIds(), 'disable'); } },
      { label: 'Dùng proxy', icon: 'proxyUse', onClick: () => { if (needSel()) enableProxy(selIds()); } },
      { label: 'Xóa proxy ra khỏi hồ sơ', icon: 'trashPlain', onClick: () => { if (needSel()) resetProxy(selIds(), 'remove'); } },
    ]);
  const bulkDeleteBtn = el('button.icon-btn.sb-trash', { html: icon('trash'), title: 'Xóa', onclick: () => { if (needSel()) deleteProfiles(selIds()); } });
  const bulkShareBtn = el('button.btn', { html: `${icon('share')}<span>Chia sẻ</span>`, onclick: () => { if (needSel()) openShareModal(selIds()); } });
  const bulkOpenBtn = el('button.btn.solid-blue', { html: `${icon('appWindow')}<span>Mở</span>`, onclick: (e) => withSpin(e.currentTarget, openSelected) });
  const bulkAutoBtn = el('button.btn.sb-grad', { html: `${icon('automation')}<span>Tự động hóa</span>`, onclick: openRpaPlus });
  bulkGatedBtns = { open: bulkOpenBtn, auto: bulkAutoBtn, updateProxy: bulkUpdateProxyBtn, webRtc: bulkWebRtcBtn, kernel: bulkKernelBtn, fp: bulkFpBtn, resetProxy: bulkResetProxyBtn, del: bulkDeleteBtn, share: bulkShareBtn };
  selBar = el('div.selbar.show', {}, [
    bulkOpenBtn,
    bulkAutoBtn,
    syncBtn,
    barCloseBtn,
    bulkUpdateProxyBtn,
    bulkWebRtcBtn,
    bulkKernelBtn,
    bulkShareBtn,
    bulkFpBtn,
    bulkResetProxyBtn,
    bulkDeleteBtn,
    // Dropdown "Thêm" (ba chấm) cũng MỞ KHI HOVER - xem ghi chú ở bulkResetProxyBtn.
    // Vẫn phải là HÀM: pinBulkItem() và các cờ PERM được tính LÚC MỞ menu.
    // Dùng aria-label thay `title`: menu bung ra NGAY khi trỏ vào, để title thì cái tooltip
    // của hệ điều hành nổi lên sau đó và che mất mấy mục đầu menu. Nút ba chấm trong từng
    // hàng của lưới (kebab) cũng không có title, cùng lý do.
    hoverMenu(el('button.icon-btn', { html: icon('moreHorizontal'), 'aria-label': 'Thêm' }), () => [
      // KHÔNG đặt `icon` cho hai mục này: mọi mục còn lại của menu "Thêm" đều không có
      // icon, thêm vào là chúng thụt lề lệch hẳn so với cả danh sách (.menu button là
      // flex + gap nên mục có icon đẩy chữ sang phải 26px).
      { label: 'Xuất', onClick: () => { exportSelected(); } },
      { label: 'Di chuyển', disabled: !PERM.move, title: PERM.move ? '' : PERM_MSG.move, onClick: () => { if (needSel()) moveToGroup(selIds()); } },
      { label: 'Nhân bản', disabled: !PERM.dupe, title: PERM.dupe ? '' : PERM_MSG.dupe, onClick: async () => { if (!needSel()) return; try { for (const id of selIds()) await remote.profiles.duplicate(id); await loadProfiles(); await loadGroups(); toast('Đã nhân bản', 'ok'); } catch (e) { await loadProfiles(); notifyError(e, 'Nhân bản hàng loạt thất bại'); } } },
      { label: 'Đổi tên hàng loạt', disabled: !PERM.editAny, title: PERM.editAny ? '' : PERM_MSG.edit, onClick: () => { if (needSel()) bulkRename(); } },
      { label: 'Tạo shortcut cho hồ sơ', onClick: () => { if (needSel()) bulkCreateShortcut(selIds()); } },
      // Nhãn tính LÚC MỞ MENU: cả lô đang ghim hết thì mục này thành "Bỏ ghim" (một mục
      // duy nhất, khỏi phải đặt hai mục cạnh nhau mà lúc nào cũng có một cái vô nghĩa).
      pinBulkItem(),
      { label: 'Chỉnh sửa tiện ích', onClick: () => { if (needSel()) bulkSetExtensions(selIds()); } },
      { label: 'Kiểm tra proxy', onClick: () => bulkCheckIp('check') },
      { label: 'Cập nhật thẻ', disabled: !PERM.editAny, title: PERM.editAny ? '' : PERM_MSG.edit, onClick: () => { if (needSel()) bulkEditTags(selIds()); } },
      { label: 'Cập nhật ghi chú', disabled: !PERM.editAny, title: PERM.editAny ? '' : PERM_MSG.edit, onClick: () => { if (needSel()) bulkEditNote(selIds()); } },
      { label: 'Xóa thẻ', disabled: !PERM.editAny, title: PERM.editAny ? '' : PERM_MSG.edit, onClick: () => { if (needSel()) bulkClearTags(selIds()); } },
      { label: 'Xóa ghi chú', disabled: !PERM.editAny, title: PERM.editAny ? '' : PERM_MSG.edit, onClick: () => { if (needSel()) bulkClearNote(selIds()); } },
      // Cùng khoá quyền với mục "Xóa bộ nhớ đệm" trong menu ba chấm của từng hàng (editAny).
      { label: 'Xóa bộ nhớ đệm', disabled: !PERM.editAny, title: PERM.editAny ? '' : PERM_MSG.edit, onClick: () => { if (needSel()) bulkClearCache(selIds()); } },
      { label: 'Sao chép', submenu: [
        { label: 'Sao chép ID', onClick: () => copyField('id') },
        { label: 'Sao chép tên', onClick: () => copyField('name') },
        { label: 'Sao chép proxy', onClick: () => copyField('proxy') },
        { label: 'Sao chép ghi chú', onClick: () => copyField('note') },
      ] },
    ]),
  ]);

  selectAll.onchange = (e) => {
    const slice = filtered.slice(page * pageSize, page * pageSize + pageSize);
    slice.forEach((p) => e.target.checked ? selected.add(p.id) : selected.delete(p.id));
    renderPage();
  };

  const sizeSel = pageSizeSelect([10, 25, 50, 100], { value: pageSize, onChange: (v) => { pageSize = v; page = 0; renderPage(); } });

  // sortable column header: a label with a down arrow that flips up when clicked
  const sortTh = (label) => el('th.sortable', {}, [el('span.th-inner', {}, [
    el('span', { text: label }),
    el('button.sort-arrow', { html: icon('chevronDown'), title: 'Sắp xếp', onclick: (e) => { e.stopPropagation(); e.currentTarget.classList.toggle('up'); } }),
  ])]);

  const table = el('table.grid.profiles-grid', {}, [
    el('thead', {}, [el('tr', {}, [
      el('th.col-check', {}, [selectAll]),
      sortTh('Hồ sơ'), sortTh('Ghi chú'), sortTh('Thẻ'),
      sortTh('IP'), sortTh('Chạy lần cuối'), sortTh('Storage'),
      sortTh('Ngày tạo'),
      el('th.col-action', { text: 'Hành động' }),
    ])]),
    tbody,
  ]);

  const pager = el('div.pager', {}, [
    el('span.muted', { text: 'Số dòng mỗi trang:' }),
    sizeSel,
    totalText,
    el('button.icon-btn', { html: icon('chevron'), style: { transform: 'rotate(180deg)' }, onclick: () => { if (page > 0) { page--; renderPage(); } } }),
    pageNumbers,
    el('button.icon-btn', { html: icon('chevron'), onclick: () => { const pages = Math.ceil(filtered.length / pageSize); if (page < pages - 1) { page++; renderPage(); } } }),
  ]);

  const kernelAlertBanner = el('div.kernel-alert-banner', { style: { display: 'none' } });

  async function checkKernelBanner() {
    try {
      const isInstalled = await window.vt.kernel.isCustomInstalled();
      if (!isInstalled) {
        kernelAlertBanner.style.display = 'flex';
        kernelAlertBanner.className = 'kernel-alert-banner';
        kernelAlertBanner.innerHTML = `
          <div class="kab-left">
            <div class="kab-icon">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>
            </div>
            <div class="kab-body">
              <div class="kab-title">Khuyến nghị quan trọng: Máy chưa cài đặt nhân Chromium 153 Core tùy biến</div>
              <div class="kab-desc">Để hồ sơ đạt độ ẩn danh <strong>100% Authentic</strong> và vượt qua toàn bộ kiểm tra Bot Detection (BrowserLeaks, Iphey, Pixelscan), bạn nên cài đặt nhân Chromium tùy biến do hệ thống tạo.</div>
            </div>
          </div>
          <div class="kab-actions">
            <button type="button" class="kab-btn" id="kab-download-btn">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
              <span>1-Click Tải & Cài Đặt (~215MB)</span>
            </button>
            <button type="button" class="kab-btn-dismiss" id="kab-dismiss-btn" title="Đóng tạm thời">×</button>
          </div>
        `;
        const dlBtn = kernelAlertBanner.querySelector('#kab-download-btn');
        if (dlBtn) {
          dlBtn.onclick = () => {
            import('./kernels.js').then((m) => {
              m.openKernelDownloadModal({
                engine: 'chromium',
                major: 153,
                version: '153.0.7993.0',
                name: 'CGT Chromium 153 Core',
                sizeMb: 215,
                url: 'https://github.com/parkseoduc/CGT-Login-Browser/releases/download/v2.0-kernel/MyBrowser-153-win64.zip'
              }, {
                onDone: () => {
                  checkKernelBanner();
                  if (typeof window.__refreshHeaderKernelBtn === 'function') window.__refreshHeaderKernelBtn();
                  m.syncActiveKernelToFingerprint();
                }
              });
            });
          };
        }
        const dismissBtn = kernelAlertBanner.querySelector('#kab-dismiss-btn');
        if (dismissBtn) {
          dismissBtn.onclick = () => { kernelAlertBanner.style.display = 'none'; };
        }
      } else {
        kernelAlertBanner.style.display = 'none';
      }
    } catch {
      kernelAlertBanner.style.display = 'none';
    }
  }

  const main = el('div.profiles-main', {}, [
    el('div.page-head', {}, [groupFilterWrap, searchBar, sortSelect, el('div.toolbar-split', {}, [toolbarRight])]),
    kernelAlertBanner,
    el('div.grid-area', {}, [selBar, el('div.grid-card', {}, [table, emptyEl]), pager]),
  ]);

  const root = el('div.profiles-root', {}, [main]);
  ctx.container.appendChild(root);

  // initial load - lưới hồ sơ là ưu tiên, nhóm chỉ nuôi dropdown. Nạp ĐỘC LẬP +
  // SONG SONG: nếu nhóm lỗi thì lưới VẪN hiện (trước đây `await loadGroups()` lỗi là
  // chặn luôn loadProfiles → lưới trống phải reload). loadProfiles/loadGroups đều tự
  // bọc lỗi bên trong nên không cần catch ở đây.
  loadProfiles();
  loadGroups();
  checkKernelBanner();

  const onKernelInstalled = () => { checkKernelBanner(); };
  window.addEventListener('cgt:kernel-installed', onKernelInstalled);

  // Quyền: nạp (cache đã có sẵn từ boot/đổi workspace) rồi tính + khóa mềm nút.
  // Mặc định lạc quan (cho phép) tránh chớp-khóa với chủ/quản trị trong lúc chờ.
  loadPermissions().then(() => { computePerm(); applyGating(); }).catch(() => {});
  refreshExpiry(true);

  // Apply a running-profile id set to the in-memory rows; re-render only on a change.
  // Honors the optimistic `opening` set: an id stays "running" until the real set
  // confirms it (then we stop forcing it), so the button never flickers back to "Mở"
  // mid-launch.
  const applyRunning = (ids) => {
    const idset = new Set(ids);
    let changed = false;
    profiles.forEach((p) => {
      if (opening.has(p.id)) {
        if (idset.has(p.id)) opening.delete(p.id); // process is up for real now
        else return;                               // still launching → keep showing running
      }
      const want = idset.has(p.id);
      if (!!p.running !== want) { p.running = want; changed = true; }
    });
    if (changed) renderPage();
  };

  // Instant push from main the moment a browser opens/closes (incl. external close),
  // so the open/close button flips immediately - no waiting on a poll tick.
  const offRunning = remote.profiles.onRunningChanged
    ? remote.profiles.onRunningChanged(applyRunning)
    : null;

  // Áp tập hồ sơ ĐANG lưu cookie (đóng-êm) do main đẩy về: cập nhật `closing` rồi vẽ lại để
  // nút hàng hiện/tắt spinner "Đang lưu". Là NGUỒN SỰ THẬT - gỡ luôn cờ lạc quan đã đặt lúc bấm.
  const applyClosing = (ids) => {
    const idset = new Set(ids || []);
    let changed = false;
    idset.forEach((id) => { if (!closing.has(id)) { closing.add(id); changed = true; } });
    [...closing].forEach((id) => { if (!idset.has(id)) { closing.delete(id); changed = true; } });
    if (changed) renderPage();
  };
  const offClosing = remote.profiles.onClosingChanged
    ? remote.profiles.onClosingChanged(applyClosing)
    : null;
  closingSupported = !!offClosing;
  // Nạp trạng thái closing ban đầu (vd quay lại trang khi 1 hồ sơ đang lưu dở).
  if (remote.profiles.closingIds) {
    remote.profiles.closingIds().then(applyClosing).catch(() => {});
  }

  // Tiến trình ĐỒNG BỘ dữ liệu hồ sơ (mở/đóng) đẩy từ main. Cập nhật map `syncing` +
  // vẽ lại hàng; báo toast khi xong/lỗi; sau khi ĐẨY LÊN xong thì refresh để cell
  // "storage" lật sang Cloud.
  const syncBridge = (typeof window !== 'undefined' && window.vt && window.vt.syncData) || null;
  const offSync = syncBridge
    ? syncBridge.onProgress((pr) => {
        if (!pr || !pr.id) return;
        const { id, phase, message } = pr;
        if (phase === 'idle') {
          syncing.delete(id);
        } else if (phase === 'done') {
          syncing.delete(id);
          if (message) toast(message, 'ok');
          loadProfiles(); // cập nhật cell storage (Cloud) sau khi đẩy lên
        } else if (phase === 'error') {
          syncing.delete(id);
          if (message) toast(message, 'error');
        } else {
          syncing.set(id, { phase, message });
        }
        renderPage();
      })
    : null;

  // live timers: relative "last run" + a slow safety-net poll (the push above does the
  // real work; this only reconciles in the rare case an event is missed).
  function stopTimers() { clearInterval(lastRunTimer); clearInterval(statusTimer); lastRunTimer = statusTimer = null; }
  function startTimers() {
    stopTimers();
    lastRunTimer = setInterval(() => { renderPage(); }, 10000);
    statusTimer = setInterval(async () => {
      applyRunning(await remote.profiles.runningIds());
      // Lưới an toàn: nếu lỡ mất 1 sự kiện push, đối soát lại tập "đang lưu" để không kẹt spinner.
      if (remote.profiles.closingIds) { try { applyClosing(await remote.profiles.closingIds()); } catch { /* ignore */ } }
    }, 4000);
  }
  startTimers();

  return {
    destroy() {
      stopTimers();
      if (offRunning) offRunning();
      if (offClosing) offClosing();
      if (offSync) offSync();
      window.removeEventListener('cgt:kernel-installed', onKernelInstalled);
      // If the advanced-search popover is still open when the user navigates away,
      // closeAdvPanel() is the ONLY thing that removes its capture-phase document
      // 'mousedown' listener (+ the window 'resize' handler). destroy() must call it,
      // otherwise every visit-then-leave-with-panel-open leaks a listener that fires
      // before every click app-wide - they pile up and make the UI feel progressively
      // laggier the longer the app is used.
      closeAdvPanel();
    },
    // Keep-alive: the grid DOM stays mounted (scroll/filters/selection preserved)
    // when navigating away, so pause the polling timers + close the popover while
    // hidden, and resume + reconcile running state on return.
    onHide() { stopTimers(); closeAdvPanel(); },
    // On return, refetch the list so a profile created/edited on another page shows
    // up. Pagination / search / group filter / selection are closure state and are
    // preserved by loadProfiles()→renderPage() (only pixel scroll resets).
    onShow() { startTimers(); loadProfiles(); checkKernelBanner(); loadPermissions().then(() => { computePerm(); applyGating(); }).catch(() => {}); refreshExpiry(true); },
    // Được app.js gọi khi người dùng nhấp đúp một LỐI TẮT hồ sơ (.lnk - xem
    // bulkCreateShortcut + main/shortcuts.js). Cố tình đi qua openProfile() của chính lưới
    // này thay vì gọi launcher ở main: lối tắt phải hành xử GIỐNG HỆT bấm nút "Mở" (chặn
    // hết hạn thuê bao, đòi nhân đã cài, khoá phiên, đồng bộ, cập nhật badge + toast) -
    // dựng một đường mở song song là kiểu gì cũng lệch dần theo thời gian.
    async openProfileById(id) {
      if (!id) return;
      // Lưới có thể đang giữ danh sách cũ (lối tắt tạo từ hồ sơ vừa thêm ở máy khác) ⇒ nạp
      // lại MỘT lần trước khi kết luận là không tìm thấy.
      let p = profiles.find((x) => x.id === id);
      if (!p) { try { await loadProfiles(); } catch { /* ignore */ } p = profiles.find((x) => x.id === id); }
      if (!p) return toast('Không tìm thấy hồ sơ của lối tắt (đã xóa, hoặc thuộc workspace khác)', 'error');
      if (p.running) return toast(p.name + ' đang mở', 'warn');
      await openProfile(p);
    },
  };
}
