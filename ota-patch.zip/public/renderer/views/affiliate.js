// Trang "HOA HỒNG" - chương trình giới thiệu (affiliate).
//
// Hai lối vào: dải mép trên thẻ gói ở thanh bên (app.js `.plan-deco`) và mục "Hoa Hồng" trong
// menu tài khoản. Route 'affiliate' nằm trong VOLATILE_ROUTES nên MỖI lần vào là render lại từ
// đầu - cố ý, xem chú thích ở app.js: số dư do job quét bên server đổi sau lưng app.
//
// ─── LUẬT ĐỌC/GHI (đừng phá) ────────────────────────────────────────────────────────────────
// Trang này CHỈ LÀM HAI VIỆC: đọc snapshot (`vt.affiliate.get`) và gửi yêu cầu rút
// (`vt.affiliate.withdraw`). Nó KHÔNG tính tiền. Mọi con số hiện ra đều do server đưa:
//   • % hoa hồng, số ngày giữ, trần, mức rút tối thiểu → `snap.policy` (admin sửa được)
//   • pending / available / locked / withdrawn        → `snap.balance`
// ⛔ ĐỪNG hardcode "10%" hay "200.000₫" vào chuỗi nào ở đây. Admin đổi cấu hình bên web admin
// là trang lặng lẽ nói sai chính sách - không có lỗi nào, khách chỉ hiểu sai rồi khiếu nại.
//
// ─── VÌ SAO CÓ BỐN SỐ DƯ, KHÔNG PHẢI MỘT ────────────────────────────────────────────────────
// Tiền hoa hồng đi qua 4 trạng thái và khách PHẢI phân biệt được, không thì mọi trạng thái đều
// bị đọc là "sao tiền của tôi chưa rút được":
//   pending   = đã ghi nhận nhưng còn trong thời gian GIỮ (policy.holdDays) - chống đơn hoàn
//   available = hết thời gian giữ, rút được
//   locked    = đã gửi yêu cầu rút, đang chờ admin duyệt (tiền đã rời `available`)
//   withdrawn = admin đã chi
// Gộp 4 số thành một "số dư" là tạo ra đúng bốn lượt hỗ trợ khác nhau cho cùng một màn hình.
// Nhưng KHÔNG cho bốn số bốn ô ngang hàng nhau nữa: `available` là số DUY NHẤT khách hành động
// được, ba số kia chỉ để đối chiếu. Nên `available` đứng riêng ô đầu (số to + nút rút), còn
// `pending`/`locked` gom vào ĐÚNG MỘT dòng phụ `.aff-hold` ngay dưới nút, `withdrawn` là ô
// "Tổng đã rút". Cả bốn vẫn đọc được, chỉ tốn một dòng chữ thay vì bốn ô.
//
// ─── BỐ CỤC (ba thẻ cắt rời, KHÔNG phải một khung bọc tất cả) ────────────────────────────────
//   Thẻ 1 `.aff-card-row`   : hàng BỐN ô (`.aff-row4`) - ô đầu "Có thể rút" KHÔNG viền, ba ô sau
//                             CÓ viền bo 8px + nền xanh nhạt. CHỈ có hàng đó, không gì khác.
//   Thẻ 2 `.aff-card-code`  : câu dẫn + MỘT hàng hai cặp (mã giới thiệu | link mời). CHỈ hai thứ
//                             đó - liên kết "Cách tính hoa hồng" ở chân thẻ đã bị XOÁ HẲN
//                             (2026-10-20), xem khối chú thích ⛔⛔ ở cuối buildCodeCard().
//   Thẻ 3 `.aff-card-tabs`  : tab control 3 tab (ba bảng lịch sử), tab đang chọn có gạch dưới
// Ba thẻ dùng CÙNG style `.px-card` của trang Proxies (không viền, bo 12, bóng mềm). Trước đây
// là MỘT khung bọc tất cả + lưới 2×2 ngăn nhau bằng bóng; user bác bỏ ("quá loằng ngoằng").
//
// ⛔ ĐỪNG viết lại hàng trên thành nhiều dòng chữ mô tả. User đã bác bản cũ vì "text quá nhiều,
// lề mề quá" và đưa ảnh mẫu: mỗi ô CHỈ có nhãn nhỏ + số lớn + (tối đa) một dòng phụ bé.
// ⛔ Và nay KHÔNG CÒN chỗ nào trên trang in các câu chính sách nữa: danh sách đó từng nằm dưới
// hàng bốn ô, rồi bị dồn vào MODAL mở từ liên kết ở thẻ 2, rồi 2026-10-20 user bỏ luôn cả liên
// kết lẫn modal. Đừng tìm chỗ "gửi tạm" mấy câu đó vào trang.
import { el, clear, toast, openModal, closeModal, pageSizeSelect } from '../ui.js';
import { icon } from '../icons.js';
import { notifyError } from '../data/errors.js';
import { t, tf } from '../i18n.js';

const fmtVnd = (n) => (Number(n) || 0).toLocaleString('vi-VN') + '₫';

// LINK MỜI - ô thứ hai của thẻ 2 (xem `buildCodeCard`).
// ⚠️ PHẢI y hệt hai dòng cùng tên trong web landing (`public/affiliate.js`): khách copy link ở
// app rồi mở trang Hoa hồng trên web thấy link KHÁC là tưởng một trong hai cái sai, dù cả hai
// đều gắn mã đúng. Đổi base ở đây thì đổi luôn ở đó.
// ⚠️ Trỏ về TRANG ĐĂNG KÝ `/auth?mode=register`, KHÔNG còn về `/download` (user đổi
// 2026-10-20): người được mời bấm link là vào thẳng form đăng ký và ô "Mã giới thiệu" ở đó
// TỰ ĐIỀN sẵn mã đọc từ `?ref=` (xem phần "mã giới thiệu" trong web landing `public/auth.js`).
// ⛔ Nối bằng `&ref=` chứ KHÔNG `?ref=`: base ĐÃ có sẵn một query (`?mode=register`). Dùng dấu
// `?` lần thứ hai thì URLSearchParams đọc ra `mode = "register?ref=ABC"` - không lỗi, không
// cảnh báo, chỉ là trang mở ở chế độ đăng NHẬP và mã biến mất.
// ⛔ ĐỪNG dùng `vt.shell.openExternal` ở đây - ô này để COPY đi dán cho người khác, không phải
// để chủ tài khoản tự bấm vào.
const INVITE_BASE = 'https://cgtdev.space/auth?mode=register';
const inviteLink = (code) => (code ? INVITE_BASE + '&ref=' + encodeURIComponent(code) : '');

// epoch ms → DD/MM/YYYY HH:mm. 0/null = chưa có mốc (hiện '-' thay vì 01/01/1970, thứ mà
// khách sẽ báo là lỗi dữ liệu).
function fmtTs(ms) {
  const n = Number(ms) || 0;
  if (!n) return '-';
  const d = new Date(n);
  if (Number.isNaN(d.getTime())) return '-';
  const p = (x) => String(x).padStart(2, '0');
  return `${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

// epoch ms → DD/MM/YYYY (không giờ) cho cột ngày trong bảng, đỡ chật.
function fmtDay(ms) {
  const n = Number(ms) || 0;
  if (!n) return '-';
  const d = new Date(n);
  if (Number.isNaN(d.getTime())) return '-';
  const p = (x) => String(x).padStart(2, '0');
  return `${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()}`;
}

// Nhãn trạng thái một dòng hoa hồng. 'void' = đơn VƯỢT TRẦN: server VẪN ghi dòng đó (amount 0)
// để không quét lại, nên trang phải nói thật là "vượt trần" chứ không im lặng bỏ qua - khách
// thấy đơn của người mình mời mà không có hoa hồng thì phải đọc được lý do ngay tại đây.
const COMM_STATUS = {
  pending: ['Đang giữ', 'warn'],
  available: ['Rút được', 'ok'],
  void: ['Vượt trần', 'muted'],
};
const WD_STATUS = {
  pending: ['Chờ duyệt', 'warn'],
  paid: ['Đã chi', 'ok'],
  rejected: ['Bị từ chối', 'err'],
};

// Mã lỗi server → câu khách đọc được. Năm mã là NĂM việc khác nhau khách phải làm; gộp hết
// thành "gửi yêu cầu thất bại" là đúng cái bẫy đã mất một buổi ở trang thiết bị landing.
// Tham số là `policy` để hai câu có con số lấy đúng cấu hình đang chạy, không hardcode.
function withdrawErrText(code, policy) {
  const p = policy || {};
  switch (code) {
    case 'DISABLED':
      return t('Chương trình hoa hồng đang tạm dừng. Số dư của bạn vẫn được giữ nguyên.');
    case 'BANK_REQUIRED':
      return t('Vui lòng điền đủ tên ngân hàng, số tài khoản và tên chủ tài khoản.');
    case 'BELOW_MIN':
      return tf('Số tiền rút tối thiểu là {0}.', fmtVnd(p.minWithdraw));
    case 'INSUFFICIENT':
      return t('Số tiền rút vượt quá số dư có thể rút.');
    case 'HAS_PENDING':
      return t('Bạn còn một yêu cầu rút đang chờ duyệt. Vui lòng đợi duyệt xong rồi gửi yêu cầu mới.');
    case 'NOT_ENOUGH_REFERRALS':
      return tf('Cần ít nhất {0} người được giới thiệu đã phát sinh giao dịch mới được rút.', p.minReferrals);
    default:
      return '';
  }
}

// ─────────────── VÌ SAO CHƯA RÚT ĐƯỢC - MỘT NGUỒN DUY NHẤT ───────────────
//
// user chốt 2026-10-20 (lượt 4): "nút 'rút tiền' cho nó không bao giờ bị ẩn, khi bấm vào sẽ show
// modal nếu không đủ điều kiện gì đó thì báo rõ ở modal".
// ⛔ ĐỪNG quay về kiểu cũ (nút `disabled` + lý do nhét trong `title`): nút xám không giải thích
// là chỗ khách bấm mười lần rồi mở ticket, mà tooltip `title` thì trên máy cảm ứng KHÔNG hề
// xuất hiện và người dùng bàn phím cũng không chạm tới.
//
// Hàm này trả về `null` khi rút được, hoặc `{ code, text, facts }`:
//   `text`  = CÂU chính, dùng ĐÚNG `withdrawErrText` để không bao giờ nói khác câu server trả về
//             khi khách vẫn cố gửi (hai câu khác nhau cho cùng một nguyên nhân là chỗ mất lòng tin);
//   `facts` = các cặp "nhãn → giá trị" CỤ THỂ (đang có bao nhiêu / cần bao nhiêu). Thiếu phần này
//             thì câu "Cần tối thiểu 500.000₫" vẫn để khách tự đi tìm xem mình đang có bao nhiêu.
// ⚠️ THỨ TỰ kiểm phải y hệt `requestWithdrawal` ở server: nếu đảo, modal báo một lý do mà server
// lại chặn vì lý do khác ⇒ khách sửa xong vẫn không gửi được.
function withdrawBlock(snap) {
  const bal = (snap && snap.balance) || {};
  const pol = (snap && snap.policy) || {};
  const st = (snap && snap.stats) || {};
  const avail = Number(bal.available) || 0;
  const minW = Number(pol.minWithdraw) || 0;
  const minRef = Number(pol.minReferrals) || 0;
  const paying = Number(st.payingReferees) || 0;
  const pendingWd = snap && snap.pendingWithdrawal;

  if (snap && snap.enabled === false) {
    return { code: 'DISABLED', text: withdrawErrText('DISABLED', pol), facts: [
      [t('Số dư có thể rút'), fmtVnd(avail)],
    ] };
  }
  if (pendingWd) {
    return { code: 'HAS_PENDING', text: withdrawErrText('HAS_PENDING', pol), facts: [
      [t('Yêu cầu đang chờ'), fmtVnd(pendingWd.amount)],
      [t('Đã gửi lúc'), fmtTs(pendingWd.requestedAt)],
    ] };
  }
  if (avail < minW) {
    return { code: 'BELOW_MIN', text: tf('Cần tối thiểu {0} mới gửi được yêu cầu rút.', fmtVnd(minW)), facts: [
      [t('Số dư có thể rút'), fmtVnd(avail)],
      [t('Mức tối thiểu'), fmtVnd(minW)],
      [t('Còn thiếu'), fmtVnd(Math.max(0, minW - avail))],
    ] };
  }
  if (paying < minRef) {
    return { code: 'NOT_ENOUGH_REFERRALS', text: withdrawErrText('NOT_ENOUGH_REFERRALS', pol), facts: [
      [t('Đã có phát sinh giao dịch'), tf('{0} người', paying)],
      [t('Cần tối thiểu'), tf('{0} người', minRef)],
    ] };
  }
  return null;
}

// ─────────────────── CHẾ ĐỘ DIỄN TẬP (dev-only, mặc định TẮT) ───────────────────
//
// Dùng để NGẮM giao diện với dữ liệu như thật: tài khoản dùng để duyệt UI thường chưa mời được
// ai nên trang thật chỉ có 0₫ và ba bảng rỗng - không thấy được bảng có dòng, pager, pill
// trạng thái, hay số tiền 7 chữ số có vỡ cột không.
//
//   BẬT:  localStorage.setItem('polyAffDemo','1')   rồi Ctrl+R
//   TẮT:  bấm nút "Tắt diễn tập" trên dải cảnh báo (hoặc localStorage.removeItem('polyAffDemo'))
//
// ⛔ Cờ đọc MỘT LẦN khi dựng view, không đọc lại mỗi lượt vẽ: đổi cờ giữa phiên mà trang đang
//    hiện số giả rồi lượt vẽ sau đã là số thật (hoặc ngược lại) là cách chắc nhất để chính mình
//    đọc sai màn hình. Đổi cờ thì PHẢI Ctrl+R.
// ⛔ So sánh `=== '1'` chứ đừng dùng giá trị thật-giả của chuỗi: `localStorage` trả về CHUỖI,
//    nên `'0'` và `'false'` đều là truthy ⇒ viết `if (localStorage.getItem(...))` là tắt không
//    được bằng cách đặt '0', một cái bẫy rất dễ sa.
// ⛔ try/catch BẮT BUỘC: `localStorage` ném khi bị chặn (một số ngữ cảnh cửa sổ con), và nếu
//    chỗ này ném thì CẢ TRANG không dựng được - đổi một tiện ích dev thành lỗi trắng màn hình.
const DEMO_KEY = 'polyAffDemo';
function demoOn() {
  try { return localStorage.getItem(DEMO_KEY) === '1'; } catch { return false; }
}

export function render(ctx) {
  // Đọc cờ MỘT LẦN cho cả đời view (xem lý do ở chú thích DEMO_KEY).
  const demo = demoOn();
  // Snapshot HIỆN TẠI của server. Mọi lượt vẽ đọc từ đây; mỗi phản hồi của server đều kèm
  // snapshot mới (`state`) nên gửi yêu cầu rút xong KHÔNG cần gọi lại GET.
  let snap = null;
  let busy = false;        // chặn bấm kép: gửi yêu cầu rút không hoàn tác được
  const bodyEl = el('div.aff-body');
  // Tab đang chọn của thẻ 3. Phải sống NGOÀI paint(): paint() dựng lại toàn bộ DOM (sau khi gửi
  // yêu cầu rút, sau khi đổi tab), giữ biến trong đó là mỗi lượt vẽ lại nhảy về tab 1.
  let activeTab = 0;
  // ⛔ ĐÃ BỎ `policyOpen` (2026-10-20): danh sách chính sách từng bật/tắt TẠI CHỖ dưới hàng bốn
  // ô, rồi thành thân của một MODAL, rồi CẢ modal lẫn liên kết mở nó đều bị xoá cùng ngày ⇒
  // không còn trạng thái nào phải sống qua các lượt paint(). Giữ dòng ghi chú này để lượt sau
  // không "khôi phục" biến.
  // ── PHÂN TRANG ba bảng của thẻ 3 (user chốt 2026-10-20) ──
  // Chỉ số của hai mảng = chỉ số TAB (xem `TABS` ở dưới). Mỗi tab giữ RIÊNG trang + số dòng:
  // ba bảng dài rất khác nhau (lịch sử hoa hồng tới 200 dòng, lịch sử rút thường dưới 10) nên
  // dùng chung một biến là đổi tab một cái lại rơi vào trang trống của bảng kia.
  // Phải sống NGOÀI paint() y hệt `activeTab`: paint() dựng lại TOÀN BỘ DOM mỗi lượt vẽ.
  const pgIndex = [0, 0, 0];
  const pgSize = [10, 10, 10];

  // Bóc vỏ { ok, data, error, code } của remoteCall thành giá trị/ngoại lệ bình thường, GIỮ
  // `code` trên ngoại lệ - cả trang phản ứng theo mã (xem withdrawErrText).
  async function unwrap(p, failMsg) {
    const r = await p;
    if (!r || !r.ok) {
      const e = new Error((r && r.error) || failMsg);
      e.code = (r && r.code) || 'ERROR';
      throw e;
    }
    return r.data;
  }

  // ─────────────────────────────── khối dựng sẵn ───────────────────────────────
  // (Khuôn `panelHead` - icon + tiêu đề thẻ - đã bị gỡ cùng tiêu đề "Mã giới thiệu của bạn"
  // ngày 2026-10-20: nó chỉ còn đúng một chỗ gọi là thẻ đó. Ba thẻ của trang nay KHÔNG thẻ nào
  // có tiêu đề kèm icon, đừng dựng lại khuôn này nếu không có chỗ dùng thứ hai.)

  // Nhãn nhỏ của một ô: CHỈ chữ xám. Icon KHÔNG nằm trong đây mà là phần tử anh em ở
  // `rowTop` - nhãn còn bị i18n thay chữ, gắn icon vào cùng chỗ là dễ bị quét mất. Chữ nằm
  // trong <span> RIÊNG chứ không để trần: MutationObserver của i18n dịch theo TEXT NODE nên
  // vẫn chạy kiểu gì, nhưng mọi rule canh dòng phải nhắm vào một phần tử thật thì mới chỉnh được.
  const statKey = (label) => el('div.aff-k', {}, [el('span', { text: label })]);

  // ── BỐ CỤC MỘT Ô CÓ VIỀN: BA TẦNG CANH GIỮA (user chốt 2026-10-20, lượt 2) ──
  //   hàng TRÊN  `.aff-box-h`: icon LỚN + nhãn   - canh giữa theo chiều ngang
  //   hàng GIỮA  `.aff-box-v`: CON SỐ lớn        - canh giữa
  //   hàng DƯỚI  `.aff-box-s`: dòng phụ nhỏ      - canh giữa
  //
  // ⛔ KHÔNG còn liên kết "Lịch sử …" trong ô (user bỏ 2026-10-20: "bỏ các label lịch sử ở bên
  // trong boder"). ĐỪNG THÊM LẠI - ba bảng vẫn mở được bằng chính header tab control ở thẻ 3,
  // liên kết trong ô chỉ là lối tắt thứ hai cho cùng một việc. Chính nó là thứ ép hàng trên
  // phải chen ba thứ vào ~210px và làm nhãn dài ("Số người đã giới thiệu") bị cắt còn "Lịch...".
  //
  // Vì bỏ được cái đuôi đó nên hàng trên mới canh giữa được: icon + nhãn giờ là một cụm duy nhất.
  const rowTop = (iconName, label, tail) => el('div.aff-box-h', {}, [
    el('span.aff-box-ico', { html: icon(iconName) }),
    statKey(label),
    tail || null,
  ]);
  const rowVal = (valueEl, tail) => el('div.aff-box-v', {}, [valueEl, tail || null]);

  // Một ô CÓ VIỀN. `sub` rỗng (ô "Tổng đã rút") thì KHÔNG dựng phần tử - dựng div rỗng là tự
  // chuốc thêm một hộp cao 0px nhưng vẫn ăn gap của flex.
  const statBox = (iconName, label, value, sub) => el('div.aff-box', {}, [
    rowTop(iconName, label, null),
    rowVal(el('div.aff-v', { text: value }), null),
    sub ? el('div.aff-box-s', { text: sub }) : null,
  ]);

  // Bảng rỗng vẫn phải nói ra VÌ SAO rỗng. Một bảng trắng trơn là câu hỏi hỗ trợ.
  // Icon khay rỗng + CÂU giải thích, không phải icon thay cho câu: ba bảng rỗng vì ba lý do
  // khác hẳn nhau ("chưa ai đăng ký" / "chưa có hoa hồng" / "chưa gửi yêu cầu rút"), một cái
  // khay chung không phân biệt được.
  const emptyRow = (cols, text) => el('tr', {}, [
    el('td.aff-empty', { colspan: String(cols) }, [
      el('div.aff-empty-ico', { html: icon('trayEmpty') }),
      el('div', { text }),
    ]),
  ]);

  function table(heads, rows, emptyText) {
    return el('div.aff-tbl-wrap', {}, [el('table.aff-tbl', {}, [
      el('thead', {}, [el('tr', {}, heads.map((h) => el('th' + (h[1] ? '.' + h[1] : ''), { text: h[0] })))]),
      el('tbody', {}, rows.length ? rows : [emptyRow(heads.length, emptyText)]),
    ])]);
  }

  // MỚI NHẤT LÊN ĐẦU (user chốt 2026-10-20). Ba bảng có BA tên cột thời gian khác nhau
  // (`referredAt` / `createdAt` / `requestedAt`) nên phải truyền tên khoá vào, đừng đoán.
  //
  // ⛔ `slice()` trước khi `sort()`: `sort` sửa TẠI CHỖ, xếp thẳng `snap.referrals` là ta âm thầm
  //    đổi thứ tự của dữ liệu gốc - lần `paint()` sau sẽ xếp trên mảng đã bị xếp rồi, và bất kỳ
  //    chỗ nào khác đọc `snap` sẽ thấy thứ tự khác với lúc server trả về.
  // ⛔ Xếp phải nằm NGOÀI `pagedBlock`, tức TRƯỚC khi cắt trang: cắt trước rồi mới xếp thì mỗi
  //    trang chỉ đúng thứ tự TRONG trang - trang 1 vẫn là 10 dòng cũ nhất. Lỗi này không vỡ gì,
  //    bảng vẫn đẹp, chỉ sai.
  // Thiếu/hỏng mốc thời gian -> coi là 0 nên rơi xuống đáy, khớp với việc `fmtDay` in "-".
  const newestFirst = (list, key) => (list || []).slice()
    .sort((a, b) => (Number(b && b[key]) || 0) - (Number(a && a[key]) || 0));

  // Thân một tab = BẢNG ĐÃ CẮT TRANG + thanh phân trang.
  //
  // Thanh phân trang dùng ĐÚNG khuôn `.pager` dùng chung toàn app (lưới Hồ sơ / Nhật ký / Thùng
  // rác / Proxies): "Số dòng mỗi trang:" + ô gõ số (pageSizeSelect) + "x-y trên z" + ◀ + dãy số
  // + ▶. ⛔ ĐỪNG tự chế thanh riêng cho trang này - ba bảng ở đây nằm cùng một app với các lưới
  // kia, một thanh lạc điệu là thứ khách nhận ra ngay.
  // LUÔN HIỆN kể cả khi chỉ có một trang hoặc bảng rỗng (hiện "0 trên 0") - các lưới khác đều vậy.
  //
  // ⛔ PHẢI kẹp `pgIndex` về trang cuối TRƯỚC khi cắt: mỗi lượt `reload()` có thể về ít dòng hơn
  // (admin duyệt xong một yêu cầu rút, job gộp lại...) làm trang đang xem biến mất ⇒ bảng trắng
  // trơn trong khi pager vẫn sáng số trang cũ. Không lỗi nào báo, chỉ là dữ liệu như bốc hơi.
  function pagedBlock(tabIdx, list, rowFn, heads, emptyText) {
    const size = Math.max(1, pgSize[tabIdx] | 0);
    const total = list.length;
    const nPages = Math.max(1, Math.ceil(total / size));
    if (pgIndex[tabIdx] >= nPages) pgIndex[tabIdx] = nPages - 1;
    const cur = pgIndex[tabIdx];
    const slice = list.slice(cur * size, cur * size + size);
    const from = total === 0 ? 0 : cur * size + 1;
    const to = Math.min((cur + 1) * size, total);
    const go = (n) => { if (n === pgIndex[tabIdx]) return; pgIndex[tabIdx] = n; paint(); };

    // Rút gọn dãy số y như `renderPager` của trang Nhật ký: quá 7 trang thì chỉ giữ 2 trang đầu,
    // 2 trang cuối và lân cận trang đang xem; phần bị bỏ thay bằng đúng MỘT dấu "…" mỗi bên.
    const nums = el('div.page-nums');
    for (let i = 0; i < nPages; i++) {
      if (nPages > 7 && i > 1 && i < nPages - 2 && Math.abs(i - cur) > 1) {
        if (i === 2 || i === nPages - 3) nums.appendChild(el('span.muted', { text: '…' }));
        continue;
      }
      const at = i;
      nums.appendChild(el('button.page-num' + (i === cur ? '.active' : ''), {
        text: String(i + 1), onclick: () => go(at),
      }));
    }

    const pager = el('div.pager.aff-pager', {}, [
      el('span.muted', { text: t('Số dòng mỗi trang:') }),
      pageSizeSelect([10, 25, 50, 100], {
        value: size,
        // Đổi số dòng/trang thì PHẢI về trang 1: đang ở trang 12 cỡ 10 mà chuyển sang cỡ 100 là
        // trang 12 không còn tồn tại.
        onChange: (v) => { pgSize[tabIdx] = v; pgIndex[tabIdx] = 0; paint(); },
      }),
      el('span.muted', { text: total === 0 ? `0 ${t('trên')} 0` : `${from}-${to} ${t('trên')} ${total}` }),
      el('button.icon-btn', {
        html: icon('chevron'), title: t('Trang trước'), style: { transform: 'rotate(180deg)' },
        onclick: () => go(Math.max(0, cur - 1)),
      }),
      nums,
      el('button.icon-btn', {
        html: icon('chevron'), title: t('Trang sau'),
        onclick: () => go(Math.min(nPages - 1, cur + 1)),
      }),
    ]);
    return el('div.aff-block', {}, [table(heads, slice.map(rowFn), emptyText), pager]);
  }

  // ─────────────────────────────── MODAL yêu cầu rút ───────────────────────────────
  //
  // Mặc định điền SẴN toàn bộ `available` vào ô số tiền: rút cả số dư là việc khách làm 99%
  // số lần, và gõ lại con số bảy chữ số là chỗ dễ gõ sai thành thiếu/thừa một số 0.
  function openWithdrawModal() {
    const bal = (snap && snap.balance) || {};
    const pol = (snap && snap.policy) || {};
    const avail = Number(bal.available) || 0;

    // ── NHÁNH "CHƯA ĐỦ ĐIỀU KIỆN" (user chốt 2026-10-20 lượt 4) ──
    // Nút "Rút tiền" nay LUÔN bấm được, nên đây là chỗ duy nhất giải thích vì sao chưa rút được.
    // ⚠️ KHÔNG dựng form rồi khoá nút "Gửi yêu cầu": một form đầy ô nhập mà bấm không được là
    // kiểu giao diện tệ nhất trong cả ba lựa chọn - khách gõ xong năm ô mới biết là vô ích.
    // Thay vào đó: MỘT khối lý do + các con số cụ thể + đúng một nút "Đóng".
    // ⚠️ `return` NGAY - đừng để rơi xuống phần dựng form bên dưới.
    const blk = withdrawBlock(snap);
    if (blk) {
      openModal({
        title: t('Yêu cầu rút hoa hồng'),
        width: 560,
        body: [
          el('div.aff-wd-block', {}, [
            el('div.aff-wd-block-t', { text: t('Chưa thể gửi yêu cầu rút') }),
            el('div.aff-wd-block-s', { text: blk.text }),
          ]),
          // Bảng "đang có / cần có". Dùng lại đúng khuôn `.aff-wd-row` của form (nhãn 132px +
          // giá trị) để hai trạng thái của cùng một modal không lệch bố cục khi khách mở lại.
          ...blk.facts.map(([k, v]) => el('div.aff-wd-row', {}, [
            el('div.aff-wd-k', { text: k }),
            el('div.aff-wd-v', {}, [el('div.aff-wd-fact', { text: v })]),
          ])),
        ],
        footer: [el('button.btn.primary', { text: t('Đóng'), onclick: closeModal })],
      });
      return;
    }

    const amountInput = el('input.input', { type: 'text', value: String(avail), inputmode: 'numeric' });
    const bankInput = el('input.input', { type: 'text', placeholder: t('Ví dụ: Vietcombank') });
    const acctInput = el('input.input', { type: 'text', placeholder: t('Số tài khoản nhận tiền'), inputmode: 'numeric' });
    // ⛔ ĐỪNG thêm lại "(không dấu)" (user chốt 2026-10-20). Không phải vì nó sai - ngân hàng
    // Việt Nam đối soát tên không dấu thật - mà vì ô này KHÔNG hề chặn dấu, nên câu đó là một
    // yêu cầu mà chính form không thực thi; admin duyệt tay vẫn đọc được tên có dấu.
    const holderInput = el('input.input', { type: 'text', placeholder: t('Tên chủ tài khoản') });
    const noteInput = el('input.input', { type: 'text', placeholder: t('Ghi chú cho người duyệt (tuỳ chọn)') });
    const errEl = el('div.aff-wd-err');

    // ⚠️ `.aff-wd-hint` KHÔNG còn kèm class `.muted`: từ lượt 2026-10-20 nhãn gợi ý có VIỀN BỌC
    // và tự khai `color` trong CSS. Để cả `.muted` là hai rule cùng hạng (0,1,0) tranh nhau, ai
    // thắng phụ thuộc THỨ TỰ trong app.css - một phụ thuộc vô hình, đổi chỗ khối CSS là màu đổi.
    const row = (label, inputEl, hint) => el('div.aff-wd-row', {}, [
      el('div.aff-wd-k', { text: label }),
      el('div.aff-wd-v', {}, [inputEl, hint ? el('div.aff-wd-hint', { text: hint }) : null]),
    ]);

    const showErr = (msg) => { clear(errEl); if (msg) errEl.appendChild(el('div.aff-wd-errline', { text: msg })); };

    const submit = async (btn) => {
      if (busy) return;
      // Chỉ giữ CHỮ SỐ: khách hay dán "1.500.000₫" từ ô số dư ở trên. Parse bằng Number()
      // chuỗi đó ra NaN → gửi 0 → server trả BELOW_MIN, và khách không hiểu vì sao.
      const amount = Math.trunc(Number(String(amountInput.value).replace(/[^\d]/g, '')) || 0);
      const bankName = bankInput.value.trim();
      const bankAccount = acctInput.value.trim();
      const bankHolder = holderInput.value.trim();
      const note = noteInput.value.trim();

      // Chặn tại client những ca server cũng chặn - để khách thấy lỗi NGAY cạnh ô sai thay vì
      // đi một vòng mạng. Server vẫn kiểm lại y nguyên (đây chỉ là UX, KHÔNG phải cổng).
      if (!bankName || !bankAccount || !bankHolder) { showErr(withdrawErrText('BANK_REQUIRED', pol)); return; }
      if (amount < (Number(pol.minWithdraw) || 0)) { showErr(withdrawErrText('BELOW_MIN', pol)); return; }
      if (amount > avail) { showErr(withdrawErrText('INSUFFICIENT', pol)); return; }

      // ⛔ CHẾ ĐỘ DIỄN TẬP: TUYỆT ĐỐI KHÔNG gọi vt.affiliate.withdraw - số dư đang hiện là số
      // bịa, gửi đi là tạo một yêu cầu rút THẬT trên tài khoản thật (admin sẽ thấy nó, và nó
      // không hoàn tác được). Thay vào đó mô phỏng tại chỗ để nhìn được trạng thái "đang chờ
      // duyệt": dòng mới trong tab "Lịch sử rút tiền" + lần bấm "Rút tiền" sau đó ra modal CHẶN.
      // (Dữ liệu diễn tập CỐ Ý không có dòng 'pending' nào nên lần gửi ĐẦU luôn tới được đây;
      // từ lần thứ hai thì `withdrawBlock()` bắt ở ca HAS_PENDING và không dựng form nữa.
      // ⚠️ Chú thích cũ ở đây viết "nút Rút tiền bị khoá" - SAI từ 2026-10-20: nút không bao giờ
      // khoá nữa. Phép gác `demo` vẫn PHẢI có: nó là thứ duy nhất chặn một yêu cầu rút THẬT.)
      if (demo) {
        const wd = {
          id: 'demo-w-' + Date.now(), requestedAt: Date.now(), amount,
          bankName, bankAccount, bankHolder, status: 'pending', adminNote: note || '',
        };
        snap.withdrawals = [wd, ...(snap.withdrawals || [])];
        snap.pendingWithdrawal = wd;
        snap.balance = { ...(snap.balance || {}), available: Math.max(0, avail - amount) };
        closeModal();
        paint();
        toast('(diễn tập) Đã tạo yêu cầu rút ' + fmtVnd(amount) + ' - không gửi lên server.', 'ok');
        return;
      }

      busy = true;
      btn.disabled = true;
      showErr('');
      try {
        const data = await unwrap(
          vt.affiliate.withdraw({ amount, bankName, bankAccount, bankHolder, note }),
          t('Gửi yêu cầu rút thất bại'));
        // Phản hồi mang theo snapshot mới ⇒ nhận luôn, khỏi gọi lại GET (và khỏi có một nhịp
        // trang hiện số CŨ sau khi đã trừ `available`).
        if (data && data.state) snap = data.state;
        closeModal();
        paint();
        toast(tf('Đã gửi yêu cầu rút {0}. Chờ admin duyệt.', fmtVnd(amount)), 'ok');
      } catch (e) {
        const mapped = withdrawErrText(e && e.code, pol);
        showErr(mapped || (e && e.message) || t('Gửi yêu cầu rút thất bại'));
      } finally {
        busy = false;
        btn.disabled = false;
      }
    };

    // ⛔ CHỈ CHỮ, KHÔNG icon (user chốt 2026-10-20) - cùng luật đã áp cho nút "Rút tiền" ở ô 1.
    // Dùng `text:` thay vì `html:` luôn: còn `html` với một `<span>` trần là lượt sau dễ có người
    // nhét icon trở lại cho "cân".
    const okBtn = el('button.btn.primary', {
      text: t('Gửi yêu cầu'),
      onclick: (e) => submit(e.currentTarget),
    });

    // ⛔ KHÔNG truyền `sub:` nữa (user chốt 2026-10-20 bỏ dòng "Số dư có thể rút: …" ở tiêu đề).
    // Con số đó KHÔNG bị mất: ô số tiền đã điền sẵn trọn `available`, và nhãn "Tối thiểu …" ngay
    // dưới nó nói mức sàn - dòng ở tiêu đề là bản thứ ba của cùng một thông tin.
    openModal({
      title: t('Yêu cầu rút hoa hồng'),
      width: 560,
      body: [
        row(t('Số tiền'), amountInput, tf('Tối thiểu {0}', fmtVnd(pol.minWithdraw))),
        row(t('Ngân hàng'), bankInput),
        row(t('Số tài khoản'), acctInput),
        row(t('Chủ tài khoản'), holderInput),
        row(t('Ghi chú'), noteInput),
        errEl,
        // Nói TRƯỚC hai điều khách hay khiếu nại sau: tiền bị khoá ngay (nên số dư rút được
        // tụt xuống 0 là đúng), và admin duyệt tay nên không tức thì.
        el('div.aff-wd-note', {}, [
          el('div', { text: t('Khi gửi yêu cầu, số tiền sẽ được tạm giữ và trừ khỏi số dư có thể rút.') }),
          el('div', { text: t('Yêu cầu được admin kiểm duyệt thủ công. Nếu bị từ chối, tiền sẽ trả lại số dư có thể rút.') }),
          el('div', { text: t('Mỗi lần chỉ gửi được một yêu cầu. Hãy kiểm tra kỹ số tài khoản trước khi gửi.') }),
        ]),
      ],
      footer: [
        el('button.btn', { text: t('Huỷ'), onclick: closeModal }),
        okBtn,
      ],
    });
  }

  // ─────────────────────── THẺ 1: HÀNG TRÊN (BỐN ô trên MỘT hàng) ───────────────────────
  //
  // Ô 1 "Có thể rút": KHÔNG viền, không nền (user chốt) - nó là ô hành động, nút rút nằm trong
  // nó nên tự đủ nổi, bọc thêm viền là hai lớp khung chồng nhau.
  // Ô 2-4: CÓ viền mảnh, bo 8px, nền xanh nhạt - đúng ảnh mẫu user đưa.

  // Ô 1 - CÓ THỂ RÚT. Chỉ ba thứ: nhãn, số, nút. `pending`/`locked` xuống dòng phụ `.aff-hold`
  // (vẫn phải hiện - xem luật bốn số dư ở đầu tệp), `withdrawn` nằm ở ô "Tổng đã rút".
  function buildRewardPane() {
    const bal = (snap && snap.balance) || {};

    // ⛔ CHỈ CHỮ, KHÔNG icon: icon ví đã nằm trong huy hiệu tròn ngay phía trên rồi - để cả hai
    // là một ô có hai cái ví cách nhau 40px.
    // ⛔⛔ KHÔNG `disabled`, KHÔNG `title`, KHÔNG điều kiện nào quanh `onclick` (user chốt
    // 2026-10-20 lượt 4: "nút 'rút tiền' cho nó không bao giờ bị ẩn, khi bấm vào sẽ show modal
    // nếu không đủ điều kiện gì đó thì báo rõ ở modal"). Lý do chưa rút được nay nằm TRONG modal
    // - xem `withdrawBlock()` và nhánh `blk` ở đầu `openWithdrawModal()`.
    // ⚠️ Vì nút luôn mở, mọi phép gác PHẢI nằm ở `openWithdrawModal` + `submit` + server. Đừng
    // tưởng "nút mở rồi nên chắc là rút được": `openWithdrawModal` không dựng form khi còn vướng.
    const wdBtn = el('button.btn.primary.aff-wd-btn', {
      html: `<span>${t('Rút tiền')}</span>`,
      onclick: openWithdrawModal,
    });

    // ── Ô 1 DỰNG THEO THẺ "Tóm tắt dữ liệu" CỦA ADSPOWER (soi thẳng app của họ 2026-10-20) ──
    //   | Thông tin chi trả        ← tiêu đề, vạch xanh 3px bên trái (AdsPower ghi "Tóm tắt dữ
    //                                liệu"; user đổi chữ 2026-10-20, BỐ CỤC thì vẫn theo họ)
    //   [huy hiệu TRÒN]  nhãn "Số dư"
    //                    SỐ TIỀN lớn
    //   [ Rút tiền ]              ← nút vừa đúng bề ngang chữ
    //
    // ⚠️ Ô này KHÔNG dùng chung khuôn `rowTop`/`rowVal` với ba ô kia: nó có hình dạng riêng
    // (icon trong huy hiệu tròn, nhãn nhỏ trên - số to dưới).
    // ⚠️ TIÊU ĐỀ chiếm trọn bề ngang (vạch xanh bám mép TRÁI, nút tải lại bám mép PHẢI), còn
    // CỤM BÊN DƯỚI - huy hiệu, số dư, nút rút tiền - CANH GIỮA ô (user chốt 2026-10-20).
    // ⚠️ KHÔNG còn dòng "Đang giữ … · Chờ duyệt …" và dòng lý do khoá nút (user chốt bỏ cả
    // hai). `pending`/`locked` nay chỉ còn xuất hiện ở tab "Lịch sử hoa hồng".
    return el('div.aff-pane', {}, [
      el('div.aff-pane-title', {}, [
        el('span', { text: t('Thông tin chi trả') }),
        // ⛔ `icon('refresh')` - icon ĐƠN SẮC (vẽ bằng currentColor). Mọi icon đặt trong nút/ô
        // có đổi màu theo trạng thái đều phải đơn sắc; icon nhiều màu sẽ trơ ra một mảng màu lạ.
        // Gọi `reload(true)` chứ không phải `reload()`: `again` quyết định hỏng thì GIỮ hay XOÁ
        // dữ liệu đang hiện - bỏ tham số là một lần mạng chớp xoá trắng cả trang.
        el('button.aff-reload', {
          html: icon('refresh'),
          title: t('Tải lại'),
          onclick: () => reload(true),
        }),
      ]),
      el('div.aff-pane-top', {}, [
        // ⛔ ĐÚNG icon của AdsPower: chồng trụ tròn (`database`), KHÔNG phải cái ví. Vì thế ô
        // "Tổng hoa hồng" đã phải nhường `database` sang `activity` - hai icon y hệt nhau cách
        // nhau 60px trên cùng một hàng thì đọc ra là lỗi dựng trang.
        el('span.aff-pane-ico', { html: icon('database') }),
        el('div.aff-pane-txt', {}, [
          // ⛔ 'Số dư' chứ KHÔNG phải 'Có thể rút' - đúng nhãn của AdsPower. Tiện thể: 'Số dư'
          // ĐÃ có sẵn trong từ điển, còn 'Có thể rút' thì chưa bao giờ có (en/ru/zh đang in ra
          // tiếng Việt ở chính chỗ này).
          statKey(t('Số dư')),
          el('div.aff-v.main', { text: fmtVnd(bal.available) }),
        ]),
      ]),
      wdBtn,
    ]);
  }

  // Ô 2-4 - BA Ô CÓ VIỀN. Mỗi ô đúng: icon + nhãn, một con số lớn, một dòng phụ. Tất cả canh
  // giữa. (Liên kết "Lịch sử …" đã bị gỡ - xem ⛔ ở `statBox`.)
  // ⛔ 'Đã rút' chứ KHÔNG phải 'Đã nhận': trang Chợ đã có khoá từ điển 'Đã nhận' (bộ lọc kịch
  // bản, dịch là "Received"); DICT khoá theo chuỗi tiếng Việt nên khai lại cùng khoá với nghĩa
  // tiền tệ sẽ GHI ĐÈ bản của trang Chợ - không lỗi nào báo, chỉ là bộ lọc bên đó đổi nghĩa.
  function buildStatBoxes() {
    const bal = (snap && snap.balance) || {};
    const st = (snap && snap.stats) || {};
    return [
      // ⛔ ĐỪNG dùng `planCoin` ở đây: nó là icon NHIỀU MÀU (43 mã vàng cam ghi cứng), không ăn
      // `color: #3F4654` của `.aff-box-ico` nên ra một đồng xu vàng chóe giữa ba icon đen nhạt.
      // Mọi icon trong ba ô này phải là icon ĐƠN SẮC (vẽ bằng currentColor).
      // Icon: `activity` (đường đồ thị) -> `moneyBag` (túi tiền có dấu $), SVG user đưa
      // 2026-10-20. ⚠️ Đổi ở ĐÂY thì phải đổi CẢ bản web (`public/affiliate.js`) - cùng một
      // trang, hai bản chép tay.
      statBox('moneyBag', t('Tổng hoa hồng'), fmtVnd(st.earnedTotal),
        tf('Tháng này {0}', fmtVnd(st.earnedMonth))),
      statBox('walletCard', t('Tổng đã rút'), fmtVnd(bal.withdrawn), ''),
      // Đơn vị ("người") nằm trong NHÃN/dòng phụ, không phải một text node riêng cạnh con số:
      // DICT khoá theo CHÍNH chuỗi tiếng Việt và MutationObserver dịch mọi text node khớp khoá,
      // nên một khoá-một-từ-thông-dụng như 'người' sẽ đổi chữ ở những trang chẳng liên quan gì.
      // Dòng phụ nói ra số người ĐÃ CHI TIÊU: mời 100 người mà không ai mua thì hoa hồng bằng 0,
      // và đây là chỗ duy nhất trên trang nói ra điều đó.
      statBox('usersGroup', t('Số người đã giới thiệu'), String(Number(st.referrals) || 0),
        tf('{0} người đã phát sinh giao dịch', Number(st.payingReferees) || 0)),
    ];
  }

  // THẺ 2 - MÃ GIỚI THIỆU + LINK MỜI: một thẻ RIÊNG, full bề ngang, xuống dòng dưới hàng trên
  // (user chốt). Mã là chuỗi 8 ký tự từ bộ không có 0/O/1/I/L (xem affiliate.repo.js) nên đọc
  // qua điện thoại không nhầm - hiện bằng font monospace + giãn chữ cho khớp chủ ý đó.
  //
  // ⚠️ HAI ô, KHÔNG phải một (user chốt 2026-10-20): MÃ để đọc qua điện thoại / gõ tay vào form
  // đăng ký, LINK để dán vào chat. Hai việc khác nhau, và dán link vào ô "Mã giới thiệu" của
  // form đăng ký thì không khớp định dạng 8 ký tự ⇒ phải tách rõ ngay tại đây.
  function buildCodeCard() {
    const code = (snap && snap.refCode) || '';
    const pol = (snap && snap.policy) || {};
    const link = inviteLink(code);
    // Nút sao chép dùng chung MỘT khuôn cho cả hai ô: hai nút viết rời nhau thì sớm muộn một bản
    // được sửa (icon, class, cách bắt lỗi clipboard) còn bản kia không.
    // `getText` là HÀM chứ không phải chuỗi - để nút luôn đọc giá trị ở thời điểm bấm.
    const copyBtn = (getText, okMsg) => el('button.btn.primary.aff-copy', {
      // `copyLines` (không phải `copy`): icon user đưa 2026-10-20, hai tờ giấy + hai dòng kẻ.
      html: `${icon('copyLines')}<span>${t('Sao chép')}</span>`,
      onclick: async () => {
        const v = getText();
        if (!v) return;
        try {
          await navigator.clipboard.writeText(v);
          toast(okMsg, 'ok');
        } catch { toast(t('Không sao chép được, bạn hãy chọn và copy thủ công'), 'err'); }
      },
    });
    // CÂU DẪN thay cho tiêu đề "Mã giới thiệu của bạn" (user chốt 2026-10-20, dựng theo ảnh
    // AdsPower). Chữ to, in đậm, đứng đầu thẻ.
    // ⛔ TỶ LỆ % vẫn PHẢI đọc từ `pol.percent`, đừng ghi cứng "10%": admin sửa được bên web admin
    // (affiliate-config.js) và ghi cứng là trang lặng lẽ nói sai chính sách.
    //
    // ⚠️ "chu kỳ kéo dài tối đa 24 tháng" là chữ USER CHỌN (2026-10-20), KHÔNG phải mô tả cơ chế
    // đang chạy. Toàn hệ thống KHÔNG có khái niệm chu kỳ/24 tháng ở bất kỳ đâu: `affiliate-config`
    // chỉ có percent / holdDays / maxPerReferee / maxPerMonth, và job tính hoa hồng không hề cắt
    // theo mốc tháng ⇒ thực tế vẫn trả TRỌN ĐỜI. Câu này hứa ÍT HƠN cái đang chạy (khách thiệt về
    // kỳ vọng chứ không thiệt về tiền), nhưng nó vẫn là chữ KHÔNG khớp code.
    // ⛔ Muốn cắt thật ở 24 tháng thì phải thêm phanh ở SERVER, không phải sửa thêm chữ ở đây.
    const pct = Number(pol.percent) || 0;
    const hold = Number(pol.holdDays) || 0;
    let lead = tf('Khi bạn bè đăng ký gói của CGTBrowser bằng mã giới thiệu của bạn, bạn sẽ nhận được {0}% hoa hồng từ mọi giao dịch của họ, với chu kỳ kéo dài tối đa 24 tháng.', pct);
    if (hold > 0) lead += ' ' + tf('Mỗi khoản hoa hồng được giữ {0} ngày rồi chuyển sang số dư có thể rút.', hold);

    return el('div.aff-card.aff-card-code', {}, [
      el('div.aff-code-lead', { text: lead }),
      // MỘT hàng, HAI cặp (user chốt 2026-10-20: "textbox link mời nằm cùng 1 hàng với textbox
      // mã mời, thay vì xuống dòng như cũ"). Trước đó là HAI khối `.aff-codebox` xếp dọc.
      // Ô nhập giả + nút bên ngoài - theo ảnh AdsPower. Nhãn nằm TRONG ô, xám nhạt, trước giá trị.
      // ⚠️ PHẢI có lớp bọc `.aff-codepair` cho TỪNG cặp (ô + nút), đừng để bốn con trần trong
      // `.aff-codebox`: ở màn hẹp lưới/`flex-wrap` sẽ ngắt ở ranh giới bất kỳ ⇒ nút "Sao chép"
      // của mã rơi xuống cạnh ô LINK. Không vỡ, không lỗi, chỉ là bấm sao chép xong dán ra thứ
      // khác.
      // ⚠️⚠️ HAI CẶP NAY GIỐNG HỆT NHAU VỀ LỚP (user chốt 2026-10-20 lượt 4: "textbox link mời
      // set chiều ngang bằng với mã giới thiệu"): `.is-link` ĐÃ BỊ BỎ ở tầng cặp và tầng ô, chỉ
      // còn ở `.aff-code.is-link` (cỡ chữ + cách ngắt dòng của GIÁ TRỊ).
      // ⛔ ĐỪNG dán lại `.aff-codepair.is-link` / `.aff-codefield.is-link`: CSS nay KHÔNG có
      // rule nào cho hai selector đó, nên để lại là lớp CHẾT - vô hại hôm nay nhưng chính là mồi
      // để lượt sau viết một rule riêng cho ô link và phá đúng yêu cầu "hai ô bằng nhau".
      el('div.aff-codebox', {}, [
        el('div.aff-codepair', {}, [
          el('div.aff-codefield', {}, [
            el('span.aff-codefield-k', { text: t('Mã giới thiệu') }),
            el('div.aff-code', { text: code || '-' }),
          ]),
          copyBtn(() => code, t('Đã sao chép mã giới thiệu')),
        ]),
        // Ô LINK KHÔNG CÓ NHÃN (user chốt 2026-10-20: "textbox link mời: bỏ text 'link mời'
        // trong textbox"). Đây là chỗ DUY NHẤT hai cặp khác nhau về cấu trúc con.
        // ⛔ ĐỪNG thêm lại `.aff-codefield-k` ở đây - và cũng đừng "bù" bằng cách đặt nhãn
        // "Link mời" ra NGOÀI ô: hàng chỉ có hai cụm sát nhau 10px, chèn chữ vào giữa là đẩy
        // cụm 2 ra xa đúng cái khoảng user vừa yêu cầu thu lại.
        // ⚠️ Nhãn bỏ đi trả thêm ~65px bề ngang cho URL - đó là một phần lý do `.aff-code.is-link`
        // quay về được MỘT DÒNG + ellipsis (xem chú thích rule đó trong CSS).
        // ⚠️ Khoá i18n 'Link mời' nay KHÔNG còn chỗ gọi nào trong `src/` (đây là chỗ cuối cùng).
        // CỐ Ý GIỮ khoá trong `i18n.js` (cả app lẫn web) chứ không dọn: nhãn này đã bị thêm/bỏ
        // hai lượt, dọn đi rồi lượt sau cần lại thì en/ru/zh sẽ IN TIẾNG VIỆT - thiếu khoá không
        // báo lỗi, chỉ sai. `_diag-i18n-coverage.js` có thể liệt nó là khoá chết: ĐÚNG, bỏ qua.
        // Toast 'Đã sao chép link mời' là khoá RIÊNG và VẪN DÙNG - đừng gộp hai thứ.
        el('div.aff-codepair', {}, [
          el('div.aff-codefield', {}, [
            el('div.aff-code.is-link', { text: link || '-' }),
          ]),
          copyBtn(() => link, t('Đã sao chép link mời')),
        ]),
      ]),
    ]);
  }

  /* ⛔⛔ ĐÃ XOÁ HẲN nhãn "Cách tính hoa hồng" VÀ CẢ CHUỖI phía sau nó (user chốt 2026-10-20:
     "bỏ label 'cách tính hoa hồng'"). Những thứ đã đi cùng nó:
       • `.aff-code-howrow` + `<button class="aff-howlink">` ở chân thẻ 2 (chính cái nhãn);
       • `openPolicyModal()` - modal "Cách tính hoa hồng chi trả";
       • `buildPolicyList()` - danh sách 8 dòng chính sách đọc từ `snap.policy`;
       • các rule `.aff-code-howrow` / `.aff-howlink` / `.aff-policy` trong `app.css`.
     ⚠️ LÝ DO XOÁ CẢ CHUỖI, không chỉ xoá riêng cái nhãn: nhãn đó là CỬA DUY NHẤT vào modal
        (`openPolicyModal` không có chỗ gọi nào khác, và `buildPolicyList` chỉ được
        `openPolicyModal` gọi). Bỏ nhãn mà giữ hai hàm kia là để lại ~40 dòng mã CHẾT không có
        đường nào chạy tới - vô hại hôm nay nhưng chính là mồi cho lượt sau "dùng lại cho tiện"
        rồi dựng lại đúng cái nhãn user vừa bỏ.
     ⛔ ĐỪNG "bù" bằng cách rải mấy câu chính sách đó ra thành chữ nhỏ trên trang: user đã bác
        bản cũ vì "text quá nhiều, lề mề quá" (xem chú thích đầu tệp) - đó là lý do chúng được
        dồn vào modal ngay từ đầu, và giờ modal cũng bỏ.
     ⚠️ CÁC KHOÁ i18n của 8 dòng chính sách + 'Cách tính hoa hồng' + 'Cách tính hoa hồng chi trả'
        CỐ Ý GIỮ LẠI trong `i18n.js` (cả app lẫn web), KHÔNG dọn - y như khoá 'Link mời' đã bỏ
        trước đó. Nhãn này đã bị thêm/chuyển/bỏ ba lượt rồi; dọn khoá đi mà lượt sau cần lại thì
        en/ru/zh IN TIẾNG VIỆT, mà thiếu khoá KHÔNG báo lỗi - chỉ sai. `_diag-i18n-coverage.js`
        sẽ liệt chúng là khoá chết: ĐÚNG, bỏ qua.
     ⚠️ `snap.policy` vẫn được server trả về và admin vẫn sửa được bên web admin - chỉ là trang
        này không còn in nó ra. ĐỪNG đi xoá `policy` ở tầng API/server theo. */

  // ─────────────── THẺ 3: TAB CONTROL - ba bảng lịch sử, mỗi bảng một tab ───────────────
  //
  // Trước đây ba bảng xếp DỌC trong cùng một khung: trang dài gấp ba và phải cuộn qua hai bảng
  // không liên quan mới tới bảng cần xem. Giờ mỗi bảng một tab, tab đang chọn có GẠCH DƯỚI
  // (cùng khuôn `.px-tab.is-active::after` của trang Proxies).
  // Chỉ dựng bảng của TAB ĐANG CHỌN, không dựng cả ba rồi ẩn hai: bảng hoa hồng tới 200 dòng.
  // ⛔ KHÔNG còn dòng chú thích `.aff-sub` trên đầu bảng (user bỏ 2026-10-20: "bỏ các label bên
  // trên datagrid"). ĐỪNG THÊM LẠI - cả ba bảng đều đã bỏ, thêm lại một bảng là lệch bộ. Hai câu
  // đã mất: "Email được che một phần..." (chính cột Email đã hiện ab***@gmail.com, tự nói ra rồi)
  // và "Hiển thị 200 khoản gần nhất" (nay có pager hiện thẳng tổng số dòng).
  function buildReferralsBlock() {
    return pagedBlock(0, newestFirst(snap && snap.referrals, 'referredAt'), (r) => el('tr', {}, [
      el('td', { text: r.email || '-' }),
      el('td', { text: fmtDay(r.referredAt) }),
      el('td.num', { text: String(Number(r.orders) || 0) }),
      el('td.num', { text: fmtVnd(r.earned) }),
    ]),
    [[t('Email'), ''], [t('Ngày đăng ký'), ''], [t('Số giao dịch'), 'num'], [t('Hoa hồng'), 'num']],
    t('Chưa có ai đăng ký bằng mã của bạn.'));
  }

  function buildCommissionsBlock() {
    return pagedBlock(1, newestFirst(snap && snap.commissions, 'createdAt'), (c) => {
      const [label, tone] = COMM_STATUS[c.status] || [c.status || '-', ''];
      return el('tr', {}, [
        el('td', { text: fmtDay(c.createdAt) }),
        el('td', { text: c.refereeEmail || '-' }),
        el('td.num', { text: fmtVnd(c.baseAmount) }),
        el('td.num', { text: (Number(c.percent) || 0) + '%' }),
        el('td.num', {}, [
          el('b', { text: fmtVnd(c.amount) }),
          // Chỉ gắn dấu "chạm trần" khi đơn BỊ KẸP - đây là lý do duy nhất khiến số tiền
          // không bằng base × percent, và khách sẽ tự cộng tay để kiểm.
          c.capped ? el('span.aff-cap', { text: t('chạm trần') }) : null,
        ]),
        el('td', {}, [el('span.pill.aff-pill' + (tone ? '.' + tone : ''), { text: label })]),
      ]);
    },
    [[t('Ngày'), ''], [t('Từ người'), ''], [t('Giá trị giao dịch'), 'num'], [t('Tỷ lệ'), 'num'], [t('Hoa hồng'), 'num'], [t('Trạng thái'), '']],
    t('Chưa có khoản hoa hồng nào.'));
  }

  function buildWithdrawalsBlock() {
    return pagedBlock(2, newestFirst(snap && snap.withdrawals, 'requestedAt'), (w) => {
      const [label, tone] = WD_STATUS[w.status] || [w.status || '-', ''];
      return el('tr', {}, [
        el('td', { text: fmtTs(w.requestedAt) }),
        el('td.num', { text: fmtVnd(w.amount) }),
        el('td', { text: [w.bankName, w.bankAccount].filter(Boolean).join(' · ') || '-' }),
        el('td', {}, [el('span.pill.aff-pill' + (tone ? '.' + tone : ''), { text: label })]),
        // Ghi chú của admin là chỗ DUY NHẤT nói vì sao một yêu cầu bị từ chối. Không hiện nó
        // thì "Bị từ chối" là một chữ không giải thích gì và khách gửi lại y nguyên.
        el('td', { text: w.adminNote || (w.status === 'pending' ? t('Đang chờ admin xử lý') : '-') }),
      ]);
    },
    [[t('Thời điểm gửi'), ''], [t('Số tiền'), 'num'], [t('Tài khoản nhận'), ''], [t('Trạng thái'), ''], [t('Ghi chú của admin'), '']],
    t('Bạn chưa gửi yêu cầu rút nào.'));
  }

  // Dải cảnh báo khi admin TẮT chương trình. Phải nói rõ "số dư vẫn được giữ": tắt chương
  // trình không xoá tiền đã ghi nhận, và đó là điều đầu tiên khách lo.
  function buildDisabledBanner() {
    return el('div.aff-off', {}, [
      el('span.aff-off-ico', { html: icon('warnCircle') }),
      el('div', {}, [
        el('div.aff-off-t', { text: t('Chương trình hoa hồng đang tạm dừng') }),
        el('div.aff-off-s', { text: t('Hiện chưa ghi nhận hoa hồng mới và chưa gửi được yêu cầu rút. Số dư đã có vẫn được giữ nguyên.') }),
      ]),
    ]);
  }

  // Dải cảnh báo CHẾ ĐỘ DIỄN TẬP. Bắt buộc phải có, và phải ĐỎ: một trang hoa hồng hiện
  // 4.600.000₫ mà không nói đó là số giả thì chính mình cũng sẽ đọc nó như số thật sau vài ngày,
  // tệ hơn nữa là chụp màn hình gửi cho người khác.
  //
  // ⚠️ Chuỗi ở đây CỐ Ý KHÔNG đi qua t(): đây là tiện ích dev, không phải mặt hàng cho khách, và
  //    thêm 4 khoá vào DICT chỉ để cảnh báo cho chính mình là làm nặng từ điển thật.
  //    `_diag-i18n-coverage.js` sẽ liệt kê mấy câu này là "chưa dịch" - ĐÚNG, và bỏ qua được.
  // ⚠️ Nút tắt là BẮT BUỘC: bật cờ bằng devtools thì tắt cũng phải mở devtools, mà người ngắm UI
  //    rất dễ quên tên khoá rồi để trang treo ở số giả. Tắt = xoá cờ + nạp lại CẢ CỬA SỔ
  //    (`location.reload()`) chứ không chỉ paint(): cờ đọc một lần khi dựng view.
  function buildDemoBanner() {
    return el('div.aff-demo', {}, [
      el('span.aff-demo-ico', { html: icon('warnCircle') }),
      el('div', {}, [
        el('div.aff-demo-t', { text: 'DỮ LIỆU DIỄN TẬP - không phải số thật' }),
        el('div.aff-demo-s', {
          text: 'Trang đang vẽ dữ liệu giả để xem giao diện (cờ localStorage "polyAffDemo"). '
            + 'Mọi con số, người được giới thiệu và lượt rút dưới đây đều là bịa.',
        }),
      ]),
      el('button.btn.aff-demo-off', {
        text: 'Tắt diễn tập',
        onclick: () => {
          try { localStorage.removeItem(DEMO_KEY); } catch { /* chặn localStorage: bỏ qua */ }
          location.reload();
        },
      }),
    ]);
  }

  // Nhãn tab = tên ba bảng, theo thứ tự: 0 = người đã giới thiệu, 1 = lịch sử hoa hồng,
  // 2 = lịch sử rút tiền. (Trước đây thứ tự này là HỢP ĐỒNG với các liên kết "Lịch sử …" trong
  // ba ô ở hàng trên - user đã bỏ hẳn các liên kết đó, nay không còn chỗ nào ghim theo chỉ số.)
  const TABS = [
    ['Người bạn đã giới thiệu', buildReferralsBlock],
    ['Lịch sử hoa hồng', buildCommissionsBlock],
    ['Lịch sử rút tiền', buildWithdrawalsBlock],
  ];

  function buildTabsCard() {
    const idx = Math.min(Math.max(activeTab | 0, 0), TABS.length - 1);
    const tabsRow = el('div.aff-tabs', {}, TABS.map(([label], i) => el(
      'button.aff-tab' + (i === idx ? '.is-active' : ''),
      // Nhãn đi qua t() như mọi chuỗi khác; MutationObserver của i18n cũng dịch được text node
      // này khi đổi ngôn ngữ mà không cần vẽ lại.
      { text: t(label), onclick: () => { if (i === idx) return; activeTab = i; paint(); } },
    )));
    return el('div.aff-card.aff-card-tabs', {}, [
      tabsRow,
      el('div.aff-tabbody', {}, [TABS[idx][1]()]),
    ]);
  }

  // ─────────────────────────────── vẽ lại toàn trang ───────────────────────────────
  //
  // BA thẻ cắt rời xếp dọc (xem sơ đồ bố cục ở đầu tệp), KHÔNG còn một khung bọc tất cả.
  // Thêm khối mới thì cho vào một trong ba thẻ đó, hoặc làm thẻ thứ tư cùng class `.aff-card` -
  // đừng dựng hộp có viền lồng trong hộp có viền.
  function paint() {
    clear(bodyEl);
    if (!snap) {
      bodyEl.appendChild(el('div.aff-load', { text: t('Đang tải dữ liệu hoa hồng...') }));
      return;
    }
    // Dải diễn tập đứng TRÊN CÙNG, trước cả dải "tạm dừng": nếu đang là số giả thì đó là điều
    // đầu tiên phải biết, mọi dải khác dưới nó cũng là giả.
    if (snap.__demo) bodyEl.appendChild(buildDemoBanner());
    if (snap.enabled === false) bodyEl.appendChild(buildDisabledBanner());
    // THẺ 1 nay CHỈ còn hàng BỐN ô (ô đầu không viền, ba ô sau có viền mảnh bo 8px). Liên kết
    // "Cách tính hoa hồng" đã chuyển sang THẺ 2 (user yêu cầu 2026-10-20) và mở MODAL thay vì
    // bật/tắt danh sách tại chỗ ⇒ ở đây không còn `.aff-rowf`/`.aff-more` lẫn nhánh
    // `policyOpen ? … : null` nào.
    bodyEl.appendChild(el('div.aff-card.aff-card-row', {}, [
      el('div.aff-row4', {}, [buildRewardPane(), ...buildStatBoxes()]),
    ]));
    bodyEl.appendChild(buildCodeCard());          // THẺ 2: mã giới thiệu + link mời
    bodyEl.appendChild(buildTabsCard());          // THẺ 3: tab control ba bảng lịch sử
  }

  // Trang KHÔNG có khung bọc ngoài và KHÔNG có `.page-head`: ba thẻ con tự mang bóng + bo góc,
  // còn `.page-head` thì tự vẽ một gạch ngang dưới chân - đúng cái gạch user yêu cầu bỏ.
  // Vùng cuộn là `.view-host` (app.js, position:absolute + overflow:auto) nên ở đây KHÔNG khai
  // thêm overflow: lồng hai vùng cuộn là con lăn chuột kẹt ở vùng trong.
  // Dải gradient DÙNG CHO ICON SVG (huy hiệu ô "Số dư"). Phải là một <linearGradient> thật nằm
  // trong tài liệu thì `stroke: url(#affIcoGrad)` bên app.css mới giải được.
  // ⛔ Dựng bằng `html:` trên một <div> chứ ĐỪNG `document.createElement('svg')`: createElement
  // đẻ ra thẻ thuộc không gian tên HTML, trình duyệt KHÔNG coi đó là SVG - thẻ vẫn nằm trong
  // DOM, không lỗi gì, chỉ là gradient không tồn tại và icon biến mất.
  // ⛔ Đặt ở `page` (anh em với `bodyEl`) chứ không trong `bodyEl`: `paint()` xoá sạch `bodyEl`
  // mỗi lượt vẽ lại, để trong đó là đổi tab một cái là mất gradient.
  const gradDefs = el('div.aff-grad-defs', {
    html: '<svg aria-hidden="true" focusable="false"><defs>'
      + '<linearGradient id="affIcoGrad" x1="0" y1="0" x2="1" y2="0">'
      + '<stop class="aff-g0" offset="0"/><stop class="aff-g1" offset="1"/>'
      + '</linearGradient></defs></svg>',
  });
  const page = el('div.aff-root', {}, [gradDefs, bodyEl]);
  ctx.container.appendChild(page);
  paint();

  // Nạp snapshot. Lỗi MẠNG phải hiện ngay trong thân trang (không chỉ toast rồi để trang
  // trống): toast biến mất sau 3s và khách còn lại một màn hình trắng không biết chuyện gì.
  //
  // Dùng CHUNG cho lượt nạp đầu và nút "Tải lại" ⇒ hai lối vào không bao giờ xử lý lỗi khác
  // nhau. Khác biệt duy nhất là `again`:
  //  - lượt đầu (`false`): hỏng thì THAY thân trang bằng khối lỗi (màn hình đang trống rỗng).
  //  - bấm tải lại (`true`): hỏng thì GIỮ NGUYÊN dữ liệu cũ trên màn, chỉ toast. Xoá sạch một
  //    trang đang có số liệu chỉ vì một lần mạng chớp là phá hoại chứ không phải báo lỗi.
  // ⛔ `loadingSnap` chặn bấm chồng: hai lượt gọi song song về KHÔNG theo thứ tự gửi, lượt cũ
  // về sau sẽ ghi đè snapshot mới - sai số mà không có lỗi nào báo.
  // ⛔ ĐỪNG dùng chung cờ `busy` ở dòng ~109: cờ đó chặn GỬI YÊU CẦU RÚT (thao tác không hoàn
  // tác được). Gộp hai cờ là một lượt tải lại đang chạy sẽ khoá luôn nút rút tiền, và ngược lại.
  let loadingSnap = false;
  async function reload(again) {
    if (loadingSnap) return;
    loadingSnap = true;
    if (again) document.querySelectorAll('.aff-reload').forEach((b) => b.classList.add('is-busy'));
    try {
      // CHẾ ĐỘ DIỄN TẬP: KHÔNG gọi server, dựng snapshot giả tại chỗ.
      // ⛔ `await import()` ĐỘNG, đừng đổi thành import tĩnh ở đầu tệp: import tĩnh nạp VÔ ĐIỀU
      //    KIỆN nên mọi bản cài đều mang bảng số liệu giả theo, và chỉ cần một lỗi gán nhầm là
      //    khách thấy tiền ảo. Cờ localStorage + nạp động là HAI tầng chặn, giữ cả hai.
      // ⚠️ Vẫn gọi lại demoSnapshot() mỗi lượt "Tải lại" chứ không cache: các mốc thời gian
      //    tính từ Date.now() nên lượt sau cho ra bảng mới - đúng cảm giác dữ liệu sống.
      snap = demo
        ? (await import('./affiliate-demo.js')).demoSnapshot()
        : await unwrap(vt.affiliate.get(), t('Không tải được dữ liệu hoa hồng'));
      paint();
      if (again) toast(t('Đã tải lại dữ liệu hoa hồng'), 'ok');
    } catch (e) {
      if (again) {
        notifyError(e, t('Không tải được dữ liệu hoa hồng'));
      } else {
        clear(bodyEl);
        bodyEl.appendChild(el('div.aff-err', {
          text: (e && e.message) || t('Không tải được dữ liệu hoa hồng'),
        }));
        notifyError(e, t('Không tải được dữ liệu hoa hồng'));
      }
    } finally {
      loadingSnap = false;
      // paint() đã dựng lại nút MỚI nên không cần gỡ `.is-busy` ở nhánh thành công, nhưng nhánh
      // lỗi thì nút cũ vẫn còn đó và sẽ quay mãi mãi.
      document.querySelectorAll('.aff-reload').forEach((b) => b.classList.remove('is-busy'));
    }
  }
  reload(false);

  return null;
}
