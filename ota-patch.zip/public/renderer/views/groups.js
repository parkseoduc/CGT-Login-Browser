// "Nhóm" - group management page, cloned 1:1 from AdsPower's "Nhóm" screen:
// a member-filter + search toolbar, a sortable table (Nhóm / Tổng số hồ sơ chia
// nhóm / Ghi chú / Thời gian tạo / Tạo thành viên/Email / Thao tác) with a
// system "Chưa chia nhóm" row pinned on top, per-row Reset + "…" menu, and a
// footer pager. Create/edit use the "Nhóm mới" modal.
import { el, clear, toast, openModal, closeModal, customSelect, pageSizeSelect, hoverMenu, confirmDialog } from '../ui.js';
import { icon } from '../icons.js';
import { remote } from '../data/remote-ds.js';
import { notifyError } from '../data/errors.js';
import { t, tf } from '../i18n.js';

const UNGROUPED_ID = '__ungrouped__';

function fmtDate(v) {
  if (!v) return '-';
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return String(v);
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}

export function render(ctx) {
  let groups = [];
  let members = []; // TẤT CẢ thành viên workspace (cho combobox lọc), không chỉ người đã tạo nhóm
  let ungroupedCount = 0;
  let search = '';
  let memberFilter = 'all';
  let sort = { key: 'created', dir: 'desc' };
  let page = 0;
  let pageSize = 50;
  const selected = new Set();
  const pinned = new Set(); // client-side "Ghim đầu trang"

  const tbody = el('tbody');
  const totalText = el('span.muted');
  const pageNumbers = el('div.page-nums');
  const selectAll = el('input', { type: 'checkbox' });

  async function load() {
    try {
      groups = await remote.groups.list();
    } catch (e) {
      groups = [];
      toast('Không tải được nhóm: ' + e.message, 'error');
    }
    try {
      // list('') KHÔNG lọc theo nhóm → trả TẤT CẢ hồ sơ (cả đã lẫn chưa chia nhóm).
      // Dòng "Chưa chia nhóm" chỉ được đếm hồ sơ groupId rỗng (chưa gán nhóm nào).
      const ung = await remote.profiles.list('');
      ungroupedCount = Array.isArray(ung) ? ung.filter((p) => !p.groupId).length : 0;
    } catch { ungroupedCount = 0; }
    // TẤT CẢ thành viên của workspace (kể cả người chưa tạo nhóm nào) cho combobox lọc.
    try {
      const ms = await remote.team.members.list();
      members = Array.isArray(ms) ? ms : [];
    } catch { members = []; }
    buildMemberSel();
    renderRows();
  }

  // The synthetic default row + the real groups, in display order.
  function rows() {
    const def = {
      id: UNGROUPED_ID, name: 'Chưa chia nhóm', note: '', createdAt: null,
      profileCount: ungroupedCount, _system: true,
    };
    let list = groups.filter((g) => {
      if (search && !String(g.name || '').toLowerCase().includes(search.toLowerCase())) return false;
      // Lọc theo thành viên đã tạo nhóm (email người tạo thật).
      if (memberFilter !== 'all' && (g.creatorEmail || '') !== memberFilter) return false;
      return true;
    });
    const { key, dir } = sort;
    const sgn = dir === 'asc' ? 1 : -1;
    list = list.slice().sort((a, b) => {
      let av, bv;
      if (key === 'name') { av = (a.name || '').toLowerCase(); bv = (b.name || '').toLowerCase(); }
      else if (key === 'count') { av = a.profileCount || 0; bv = b.profileCount || 0; }
      else if (key === 'note') { av = (a.note || '').toLowerCase(); bv = (b.note || '').toLowerCase(); }
      else { av = a.createdAt || ''; bv = b.createdAt || ''; }
      if (av < bv) return -1 * sgn;
      if (av > bv) return 1 * sgn;
      return 0;
    });
    // pinned first (Ghim đầu trang)
    list.sort((a, b) => (pinned.has(b.id) ? 1 : 0) - (pinned.has(a.id) ? 1 : 0));
    // default row always on top, and only when not filtering it out by search or by a
    // specific member (the "Chưa chia nhóm" bucket is system-owned, không thuộc ai).
    const showDef = memberFilter === 'all' && (!search || 'chưa chia nhóm'.includes(search.toLowerCase()));
    return showDef ? [def, ...list] : list;
  }

  function renderRows() {
    const all = rows();
    const pages = Math.max(1, Math.ceil(all.length / pageSize));
    if (page >= pages) page = pages - 1;
    const slice = all.slice(page * pageSize, page * pageSize + pageSize);
    clear(tbody);
    slice.forEach((g) => tbody.appendChild(renderRow(g)));
    totalText.textContent = `${t('Toàn bộ')}: ${all.length}`;
    renderPager(pages);
    syncSelAll();
  }

  function renderRow(g) {
    const sys = !!g._system;
    const cb = el('input', { type: 'checkbox', checked: selected.has(g.id),
      onchange: (e) => { e.target.checked ? selected.add(g.id) : selected.delete(g.id); syncSelAll(); } });

    // Reset = bỏ TOÀN BỘ hồ sơ trong nhóm về "Chưa chia nhóm" (không xoá hồ sơ). Dòng
    // hệ thống "Chưa chia nhóm" vốn đã không có nhóm → vô hiệu hoá.
    const resetBtn = el('button.grp-reset' + (sys ? '.disabled' : ''),
      { html: `${icon('sync')}<span>Reset</span>`, title: sys ? '' : 'Bỏ tất cả hồ sơ ra khỏi nhóm',
        onclick: sys ? null : () => resetGroup(g) });
    if (sys) resetBtn.disabled = true;

    const moreBtn = el('button.icon-btn' + (sys ? '.disabled' : ''), { html: icon('moreHorizontal') });
    if (sys) moreBtn.disabled = true;
    else hoverMenu(moreBtn, () => [
      { label: 'Chỉnh sửa', icon: 'edit', onClick: () => editGroup(g) },
      { label: 'Xuất', icon: 'upload', onClick: () => toast('Tính năng đang được phát triển') },
      { label: 'Hợp nhất', icon: 'mergeGroup', onClick: () => toast('Tính năng đang được phát triển') },
      { label: 'Chia sẻ', icon: 'share', onClick: () => toast('Tính năng đang được phát triển') },
      { label: pinned.has(g.id) ? 'Bỏ ghim đầu trang' : 'Ghim đầu trang', icon: 'pin', onClick: () => { pinned.has(g.id) ? pinned.delete(g.id) : pinned.add(g.id); renderRows(); } },
      { label: 'Xoá', icon: 'trash', danger: true, onClick: () => deleteGroup(g) },
    ]);

    // Người tạo THẬT của nhóm (từ created_by trên server), không phải người đang đăng
    // nhập - để cột "Tạo thành viên/Email" liệt kê chính xác ai đã tạo từng nhóm. Tên
    // hiển thị đã bị loại bỏ khỏi hệ thống → chỉ hiển thị email.
    const cEmail = g.creatorEmail || '-';
    const creator = sys
      ? el('div.grp-creator', {}, [el('span', { text: 'Hệ thống tạo mặc định' })])
      : el('div.grp-creator', {}, [el('span', { text: cEmail })]);

    return el('tr' + (sys ? '.grp-system' : ''), {}, [
      el('td.col-check', {}, [cb]),
      el('td', {}, [el('div.grp-name', {}, [
        el('span', { text: g.name }),
        pinned.has(g.id) ? el('span.grp-pin', { html: icon('pin'), title: 'Đã ghim' }) : null,
      ])]),
      el('td', { text: String(g.profileCount || 0) }),
      el('td.muted', { text: g.note || '-' }),
      el('td.muted', { text: sys ? '-' : fmtDate(g.createdAt) }),
      el('td', {}, [creator]),
      el('td.col-action', {}, [el('div.grp-actions', {}, [resetBtn, moreBtn])]),
    ]);
  }

  function renderPager(pages) {
    clear(pageNumbers);
    for (let i = 0; i < pages; i++) {
      if (pages > 7 && i > 1 && i < pages - 2 && Math.abs(i - page) > 1) {
        if (i === 2 || i === pages - 3) pageNumbers.appendChild(el('span.muted', { text: '…' }));
        continue;
      }
      pageNumbers.appendChild(el('button.page-num' + (i === page ? '.active' : ''), { text: String(i + 1), onclick: () => { page = i; renderRows(); } }));
    }
  }

  function selIds() { return [...selected].filter((id) => id !== UNGROUPED_ID); }
  function syncSelAll() {
    const all = rows().filter((g) => !g._system);
    selectAll.checked = all.length > 0 && all.every((g) => selected.has(g.id));
  }

  // -------------------------------------------------- create / edit / delete
  function groupModal(g) {
    const isEdit = !!g;
    let nameInput, noteInput, nameCount, noteCount;
    const nameWrap = el('div.grp-input', {}, [
      (nameInput = el('input.input', { value: isEdit ? g.name : '', maxlength: 30, placeholder: 'Hãy nhập tên nhóm mới',
        oninput: () => { nameCount.textContent = `${nameInput.value.length} / 30`; } })),
      (nameCount = el('span.grp-count', { text: `${isEdit ? (g.name || '').length : 0} / 30` })),
    ]);
    const noteWrap = el('div.grp-input', {}, [
      (noteInput = el('input.input', { value: isEdit ? (g.note || '') : '', maxlength: 200, placeholder: 'Hãy nhập notes',
        oninput: () => { noteCount.textContent = `${noteInput.value.length} / 200`; } })),
      (noteCount = el('span.grp-count', { text: `${isEdit ? (g.note || '').length : 0} / 200` })),
    ]);

    const save = async () => {
      const n = nameInput.value.trim();
      if (!n) { nameInput.focus(); return; }
      closeModal();
      try {
        if (isEdit) await remote.groups.update(g.id, { name: n, note: noteInput.value.trim() });
        else await remote.groups.create({ name: n, note: noteInput.value.trim() });
        await load();
        toast(isEdit ? 'Đã lưu nhóm' : 'Đã thêm nhóm', 'ok');
      } catch (e) { toast('Lỗi: ' + e.message, 'error'); }
    };

    openModal({
      title: isEdit ? 'Chỉnh sửa nhóm' : 'Nhóm mới',
      width: 544,
      body: [el('div.grp-form', {}, [
        el('div.grp-row', {}, [el('label.grp-label.req', { text: 'Tên nhóm' }), nameWrap]),
        el('div.grp-row', {}, [el('label.grp-label', { text: 'Ghi chú' }), noteWrap]),
      ])],
      footer: [
        el('button.grp-cancel', { text: 'Hủy', onclick: closeModal }),
        el('button.btn.primary', { text: 'OK', onclick: save }),
      ],
    });
    setTimeout(() => nameInput.focus(), 30);
  }

  const addGroup = () => groupModal(null);
  const editGroup = (g) => groupModal(g);

  // Shared "Xóa nhóm" confirm modal (single + bulk). `names` = group name(s); the
  // note states the delete is permanent ("xóa luôn", không chuyển về "Chưa chia nhóm").
  function delGroupModal(names, onConfirm, question) {
    const { modal } = openModal({
      title: 'Xóa nhóm',
      width: 528,
      body: [el('div.grp-del', {}, [
        el('p.grp-del-q', { text: question || 'Bạn có chắc chắn muốn xoá nhóm bên dưới không?' }),
        el('div.grp-del-row', {}, [
          el('span.grp-del-label', { text: 'Nhóm' }),
          el('div.grp-del-chips', {}, names.map((n) => el('span.grp-del-chip', { text: n }))),
        ]),
        el('p.grp-del-warn', { text: 'Lưu ý: Thao tác này sẽ xóa cả hồ sơ và dữ liệu trong nhóm.' }),
      ])],
      footer: [
        el('button.grp-cancel', { text: 'Hủy', onclick: closeModal }),
        el('button.btn.primary', { text: 'Xác nhận xoá', onclick: onConfirm }),
      ],
    });
    const head = modal.querySelector('.modal-head > div');
    if (head) head.insertBefore(el('span.grp-del-badge', { html: icon('warning') }), head.firstChild);
  }

  function deleteGroup(g) {
    delGroupModal([g.name], async () => {
      closeModal();
      try { await remote.groups.remove(g.id); selected.delete(g.id); await load(); toast('Đã xóa nhóm', 'ok'); }
      catch (e) { toast('Lỗi: ' + e.message, 'error'); }
    });
  }

  // Reset nhóm: đưa TẤT CẢ hồ sơ trong nhóm về "Chưa chia nhóm" (group_id = null).
  // KHÔNG xoá hồ sơ - chỉ gỡ khỏi nhóm. Nhóm vẫn tồn tại (rỗng) sau khi reset.
  function resetGroup(g) {
    const n = g.profileCount || 0;
    if (!n) { toast('Nhóm chưa có hồ sơ nào để bỏ ra.'); return; }
    confirmDialog({
      title: 'Reset nhóm',
      message: tf('Bỏ toàn bộ {0} hồ sơ ra khỏi nhóm “{1}” về “Chưa chia nhóm”? Hồ sơ KHÔNG bị xoá, nhóm vẫn được giữ lại.', n, g.name),
      confirmLabel: 'Bỏ khỏi nhóm',
      onConfirm: async () => {
        try {
          const ps = await remote.profiles.list(g.id);
          const ids = (Array.isArray(ps) ? ps : []).map((p) => p.id).filter(Boolean);
          if (ids.length) await remote.profiles.move(ids, null);
          await load();
          toast(tf('Đã bỏ {0} hồ sơ ra khỏi nhóm “{1}”', ids.length, g.name), 'ok');
        } catch (e) { notifyError(e, 'Reset nhóm thất bại'); }
      },
    });
  }

  function deleteSelected() {
    const ids = selIds();
    if (!ids.length) { toast('Vui lòng chọn ít nhất một nhóm'); return; }
    // Bulk: show the TOTAL count instead of listing each group name.
    delGroupModal([`${ids.length} ${t('nhóm')}`], async () => {
      closeModal();
      try { for (const id of ids) await remote.groups.remove(id); selected.clear(); await load(); toast('Đã xóa nhóm', 'ok'); }
      catch (e) { toast('Lỗi: ' + e.message, 'error'); }
    }, 'Bạn có chắc chắn muốn xóa tất cả nhóm đã chọn không?');
  }

  // -------------------------------------------------- toolbar / table / pager
  // Bộ lọc thành viên - DANH SÁCH các thành viên đã thực sự tạo nhóm trong workspace
  // hiện tại (rút ra từ creatorEmail của các nhóm đã tải), không phải chỉ mình tôi.
  // Dựng lại mỗi lần load() vì tập thành viên đổi theo workspace.
  const memberSelWrap = el('div.grp-memfilter');
  function memberOptions() {
    // TẤT CẢ thành viên workspace (không chỉ người đã tạo nhóm). Gộp thêm creatorEmail
    // của các nhóm phòng khi người tạo không còn trong danh sách members hiện tại.
    const seen = new Set(); // email (tên hiển thị đã bỏ → chỉ dùng email)
    members.forEach((m) => { if (m && m.email) seen.add(m.email); });
    groups.forEach((g) => { if (g.creatorEmail) seen.add(g.creatorEmail); });
    return [{ value: 'all', label: 'Tất cả thành viên' }]
      .concat([...seen].map((email) => ({ value: email, label: email })));
  }
  function buildMemberSel() {
    const opts = memberOptions();
    // Thành viên đang chọn không còn (đổi workspace) → về "Tất cả thành viên".
    if (!opts.some((o) => o.value === memberFilter)) memberFilter = 'all';
    clear(memberSelWrap);
    memberSelWrap.appendChild(customSelect(opts, { value: memberFilter, width: 190,
      onChange: (v) => { memberFilter = v; page = 0; renderRows(); } }));
  }
  buildMemberSel();

  const searchBar = el('div.searchbar', {}, [
    el('span.ico', { html: icon('search') }),
    el('input.search-input', { placeholder: 'Tìm kiếm từ khóa...', oninput: (e) => { search = e.target.value.trim(); page = 0; renderRows(); } }),
  ]);

  const usersBtn = el('button.icon-btn.grp-fbtn', { html: icon('users'), title: 'Thành viên', onclick: () => toast('Tính năng đang được phát triển') });
  const trashBtn = el('button.icon-btn.grp-fbtn.grp-fbtn-del', { html: icon('trash'), title: 'Xóa', onclick: deleteSelected });

  const sortTh = (label, key, extraClass) => {
    const arrow = el('button.sort-arrow', { html: icon('chevronDown'), title: 'Sắp xếp' });
    const th = el('th.sortable' + (extraClass ? extraClass : ''), {}, [el('span.th-inner', {}, [el('span', { text: label }), arrow])]);
    const sync = () => arrow.classList.toggle('up', sort.key === key && sort.dir === 'asc');
    th.onclick = () => { if (sort.key === key) sort.dir = sort.dir === 'asc' ? 'desc' : 'asc'; else { sort.key = key; sort.dir = 'asc'; } sync(); renderRows(); };
    sync();
    return th;
  };

  selectAll.onchange = (e) => {
    const all = rows().filter((g) => !g._system);
    all.forEach((g) => e.target.checked ? selected.add(g.id) : selected.delete(g.id));
    renderRows();
  };

  const table = el('table.grid.groups-grid', {}, [
    el('thead', {}, [el('tr', {}, [
      el('th.col-check', {}, [selectAll]),
      sortTh('Nhóm', 'name'),
      sortTh('Tổng số hồ sơ chia nhóm', 'count'),
      sortTh('Ghi chú', 'note'),
      sortTh('Thời gian tạo', 'created'),
      el('th', { text: 'Tạo thành viên/Email' }),
      el('th.col-action', { text: 'Thao tác' }),
    ])]),
    tbody,
  ]);

  const sizeSel = pageSizeSelect([10, 25, 50, 100], { value: pageSize, onChange: (v) => { pageSize = v; page = 0; renderRows(); } });

  const pager = el('div.pager.groups-pager', {}, [
    totalText,
    el('div.pg-right', {}, [
      el('button.icon-btn', { html: icon('chevron'), style: { transform: 'rotate(180deg)' }, onclick: () => { if (page > 0) { page--; renderRows(); } } }),
      pageNumbers,
      el('button.icon-btn', { html: icon('chevron'), onclick: () => { const pages = Math.ceil(rows().length / pageSize); if (page < pages - 1) { page++; renderRows(); } } }),
      sizeSel,
    ]),
  ]);

  const page_ = el('div.page.groups-page', {}, [
    el('div.page-head', {}, [
      el('div.grp-toolbar-left', {}, [memberSelWrap, searchBar, usersBtn, trashBtn]),
      el('div.toolbar', {}, [el('button.btn.primary', { html: `${icon('folderPlus')}<span>Nhóm mới</span>`, onclick: addGroup })]),
    ]),
    el('div.grid-area', {}, [el('div.grid-card', {}, [table]), pager]),
  ]);
  ctx.container.appendChild(page_);

  load();
  // Làm mới khi quay lại trang (số hồ sơ/nhóm có thể đã đổi ở nơi khác). Khi ĐỔI
  // workspace, app.js resetHosts() dựng lại view mới nên dữ liệu luôn theo workspace.
  return { onShow: () => { load(); } };
}
