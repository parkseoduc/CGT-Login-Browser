// Port of SyncView.xaml - "Đồng bộ thao tác" (action mirroring across windows).
//
// UI-ONLY: the action-sync engine has been removed. "Bắt đầu đồng bộ" (and the
// "Khởi động lại"/options controls) are an inert UI shell with no effect. The only
// live utilities on this view are "Sắp xếp cửa sổ" (vt.sync.arrange → PowerShell
// window tiling) and "Xem cửa sổ" (vt.profiles.show). The left list + Console UI
// faithfully recreate MKTLogin.
import { el, clear, toast, customSelect, pageSizeSelect, withSpin, noBrowserSvg } from '../ui.js';
import { icon } from '../icons.js';
import { t, tf } from '../i18n.js';
import { remote } from '../data/remote-ds.js';
import { buildSyncConsole } from './sync-console.js';

// Read the Console's "Mô phỏng hành động" settings so the engine can honour them. The
// Console (sync-console.js) persists them under localStorage['polySyncConsole'].sim; the
// engine normalises/coerces the values, so we just hand the raw object through.
function readSyncSim() {
  try { const s = JSON.parse(localStorage.getItem('polySyncConsole')); return (s && s.sim) || null; }
  catch { return null; }
}

export function render(ctx) {
  let running = [];        // [{id,name,group,profileId}]
  let page = 0;
  let pageSize = 25;
  const selected = new Set();

  const tbody = el('tbody');
  const pagerText = el('span.muted');
  const pageNumbers = el('div.page-nums');
  const selectAll = el('input', { type: 'checkbox' });
  const empty = el('div.sync-empty', { style: { display: 'none' } }, [
    el('div.sync-empty-ico', { html: noBrowserSvg }),
    el('div.muted', { text: 'Không mở trình duyệt' }),
  ]);

  function renderPage() {
    const total = running.length;
    const from = total === 0 ? 0 : page * pageSize;
    const slice = running.slice(from, from + pageSize);
    clear(tbody);
    slice.forEach((p, i) => {
      const cb = el('input', { type: 'checkbox', checked: selected.has(p.id),
        onchange: (e) => { e.target.checked ? selected.add(p.id) : selected.delete(p.id); syncSelAll(); } });
      tbody.appendChild(el('tr', {}, [
        el('td.col-check', {}, [cb]),
        el('td', { text: p.profileId || String(from + i + 1) }),
        el('td', { text: p.name }),
        el('td', { text: p.group }),
      ]));
    });
    empty.style.display = total === 0 ? 'flex' : 'none';
    pagerText.textContent = total === 0 ? `0 - 0 ${t('trên')} 0` : `${from + 1} - ${Math.min(from + pageSize, total)} ${t('trên')} ${total}`;
    renderPager(Math.max(1, Math.ceil(total / pageSize)));
    syncSelAll();
  }

  // Numbered page buttons (house style - same as log/profiles/trash pagers). Collapses
  // to first-2 / current±1 / last-2 with an ellipsis when there are many pages.
  function renderPager(pages) {
    clear(pageNumbers);
    for (let i = 0; i < pages; i++) {
      if (pages > 7 && i > 1 && i < pages - 2 && Math.abs(i - page) > 1) {
        if (i === 2 || i === pages - 3) pageNumbers.appendChild(el('span.muted', { text: '…' }));
        continue;
      }
      pageNumbers.appendChild(el('button.page-num' + (i === page ? '.active' : ''), { text: String(i + 1), onclick: () => { page = i; renderPage(); } }));
    }
  }

  function syncSelAll() {
    const slice = running.slice(page * pageSize, page * pageSize + pageSize);
    selectAll.checked = slice.length > 0 && slice.every((p) => selected.has(p.id));
  }

  function scopeIds() {
    const selectedOnly = scopeCombo.value === 'selected';
    return selectedOnly ? running.filter((p) => selected.has(p.id)).map((p) => p.id) : running.map((p) => p.id);
  }

  async function load() {
    const ids = await remote.profiles.runningIds();
    const all = await remote.profiles.list(null);
    const byId = new Map(all.map((p) => [p.id, p]));
    running = ids.map((id) => byId.get(id) || { id, name: id, group: '-', profileId: '' });
    selected.clear();
    page = 0;
    renderPage();
  }

  // Live-refresh the running list when a browser opens/closes (or dies externally) so
  // the table, the scope (scopeIds derives from `running`) and the "Bắt đầu/Dừng" count
  // always reflect the ACTUAL set of open Chrome windows - not a one-time snapshot.
  // Preserves the current selection (drops only ids that are no longer open).
  async function refreshRunning(ids) {
    const list = Array.isArray(ids) ? ids : await remote.profiles.runningIds();
    const all = await remote.profiles.list(null);
    const byId = new Map(all.map((p) => [p.id, p]));
    running = list.map((id) => byId.get(id) || { id, name: id, group: '-', profileId: '' });
    for (const id of [...selected]) { if (!list.includes(id)) selected.delete(id); }
    const maxPage = Math.max(0, Math.ceil(running.length / pageSize) - 1);
    if (page > maxPage) page = maxPage;
    renderPage();
    // Reconcile the Bắt đầu/Dừng button with reality. Sync needs ≥2 open windows
    // (1 master + ≥1 slave); once the user closes enough that fewer remain, the sync
    // can no longer be running, so flip the button back to its initial "Bắt đầu đồng
    // bộ" state and tell the engine to stop (idempotent). This covers the case where
    // the windows are closed by hand and the engine doesn't emit its own stop status.
    if (syncRunning && running.length < 2) {
      syncRunning = false;
      try { vt.sync.stop(); } catch { /* ignore */ }
      paintStart();
    }
  }

  const notSupported = () => toast('Sắp xếp/đồng bộ cửa sổ cần API Win32 - không khả dụng trong bản Electron.', 'warn');

  // ---------- top toolbar ----------
  const scopeCombo = customSelect(
    [{ value: 'all', label: 'Tất cả nhóm' }, { value: 'selected', label: 'Nhóm đã chọn' }],
    { value: 'all', width: 180 });

  // The "Console" panel (Cửa sổ / Văn bản / Tab) - shared with the floating overlay.
  // getLayout() returns the window-layout choice picked in the "Cửa sổ" tab.
  // Clicking the header "Thu gọn" detaches the Console into its OWN floating window and
  // leaves a placeholder ("Khôi phục") in its place; clicking Khôi phục (or closing the
  // floating window) docks it back.
  const consoleApi = buildSyncConsole({ getScopeIds: scopeIds, collapseTitle: 'Thu gọn', onCollapse: () => collapseConsole() });

  // ---- action-sync (đồng bộ thao tác) wiring ----
  let syncRunning = false;
  const startBtn = el('button.btn.primary', {
    html: `${icon('playFill')}<span>Bắt đầu đồng bộ</span>`,
  });

  function paintStart(st) {
    // Any repaint (incl. the live onStatus push) clears the transient loading state so the
    // button can never get stuck disabled/dim after the spinner was shown during connect.
    startBtn.classList.remove('is-loading');
    if (syncRunning) {
      const n = st && st.slaves ? st.slaves.filter((s) => s.connected && !s.paused).length : 0;
      const lat = st && st.latencyMs ? ` · ${st.latencyMs}ms` : '';
      startBtn.innerHTML = `${icon('stopFill')}<span>${tf('Dừng đồng bộ ({0}){1}', n, lat)}</span>`;
      // red 3-stop gradient (mirrors the blue "Bắt đầu" gradient) instead of the
      // transparent/red-text .danger look, which read as broken next to .primary.
      startBtn.classList.add('danger-mix');
    } else {
      startBtn.innerHTML = `${icon('playFill')}<span>Bắt đầu đồng bộ</span>`;
      startBtn.classList.remove('danger-mix');
    }
  }

  async function startSync() {
    const ids = scopeIds();
    if (ids.length < 2) return toast('Yêu cầu mở từ 2 hồ sơ trở lên để thực hiện tính năng này', 'warn');
    // Master = first window in scope; the rest mirror it. Connecting CDP to every window
    // takes a beat, so show a spinner ON the button immediately (instead of a frozen-looking
    // click) until the engine reports it's up. paintStart() rewrites the label at the end.
    startBtn.disabled = true;
    startBtn.classList.add('is-loading');
    startBtn.innerHTML = '<span class="btn-spin"></span><span>Đang bật đồng bộ…</span>';
    try {
      const r = await vt.sync.start(ids, { masterId: ids[0], sim: readSyncSim() });
      if (r && r.ok) {
        syncRunning = true;
        // Surface + tile every window in scope so the user can see all of them (master +
        // slaves) the moment sync starts - non-activating, so the master keeps focus. Honour
        // the Console config: auto layout, or the manual placement when auto is turned off.
        try {
          let store = {};
          try { store = JSON.parse(localStorage.getItem('polySyncConsole')) || {}; } catch { /* ignore */ }
          const autoArrange = store.autoArrange !== undefined ? !!store.autoArrange : true;
          if (autoArrange) {
            await vt.sync.arrange(ids, consoleApi.getLayout());
          } else {
            const man = store.man || {};
            const num = (v, d) => { const n = parseInt(v, 10); return Number.isFinite(n) ? n : d; };
            await vt.sync.arrange(ids, 'manual', {
              x: num(man.x, 0), y: num(man.y, 0), w: num(man.w, 500), h: num(man.h, 640),
              hs: num(man.hs, 0), vs: num(man.vs, 0), perRow: Math.max(1, num(man.per, 1)),
            });
          }
        } catch { /* ignore */ }
        // Pop the Console out as its OWN floating window - same behaviour as starting sync
        // from the "Hồ sơ" (Profiles) toolbar. The user wants it detached regardless of which
        // menu started the sync, instead of staying only as the in-view side panel.
        vt.console.open(ids).catch(() => {});
        // r.count = số hồ sơ THỰC SỰ đồng bộ (main có thể đã loại hồ sơ Firefox). Dùng nó
        // thay cho ids.length, nếu không sẽ khoe nhầm số slave khi có hồ sơ bị bỏ qua.
        const n = (r && Number.isFinite(r.count) ? r.count : ids.length) - 1;
        toast(tf('Đã bật đồng bộ: master + {0} slave', n), 'ok');
        // Hồ sơ bị loại PHẢI được nói ra - im lặng thì người dùng tưởng đủ cả.
        if (r && r.warning) toast(r.warning, 'warn');
      } else {
        toast((r && r.error) || 'Không bật được đồng bộ.', 'err');
      }
    } catch { toast('Không bật được đồng bộ.', 'err'); }
    startBtn.classList.remove('is-loading');
    startBtn.disabled = false;
    paintStart();
  }

  async function stopSync() {
    startBtn.disabled = true;
    startBtn.classList.add('is-loading');
    startBtn.innerHTML = '<span class="btn-spin"></span><span>Đang dừng…</span>';
    try { await vt.sync.stop(); } catch { /* ignore */ }
    try { await vt.console.close(); } catch { /* ignore */ }
    syncRunning = false;
    startBtn.classList.remove('is-loading');
    startBtn.disabled = false;
    paintStart();
    toast('Đã dừng đồng bộ.', 'ok');
  }

  startBtn.onclick = () => { syncRunning ? stopSync() : startSync(); };

  const toolbar = el('div.page-head.sync-toolbar', {}, [
    scopeCombo,
    startBtn,
    el('button.btn', { html: `${icon('restore')}<span>Khởi động lại</span>`,
      onclick: (e) => withSpin(e.currentTarget, async () => { if (syncRunning) { await stopSync(); } await startSync(); }) }),
  ]);

  // Live status: keep the button label current (synced count + latency) and reflect
  // engine-side stop (e.g. all slaves closed). Replaces any prior subscription.
  if (window.__syncUnsub) { try { window.__syncUnsub(); } catch { /* ignore */ } }
  window.__syncUnsub = vt.sync.onStatus((st) => {
    syncRunning = !!(st && st.running);
    paintStart(st);
  });
  vt.sync.status().then((st) => { syncRunning = !!(st && st.running); paintStart(st); }).catch(() => {});

  // Keep the running-window list (and thus the scope + counts) in step with the real
  // set of open Chrome windows, live. Drop any prior subscription so handlers from a
  // re-entered view don't pile up on 'profile:running-changed'.
  if (window.__syncRunUnsub) { try { window.__syncRunUnsub(); } catch { /* ignore */ } }
  window.__syncRunUnsub = remote.profiles.onRunningChanged
    ? remote.profiles.onRunningChanged((ids) => { refreshRunning(ids); })
    : null;

  // ---------- left: running-window table ----------
  selectAll.onchange = (e) => {
    const slice = running.slice(page * pageSize, page * pageSize + pageSize);
    slice.forEach((p) => e.target.checked ? selected.add(p.id) : selected.delete(p.id));
    renderPage();
  };

  const table = el('table.grid', {}, [
    el('thead', {}, [el('tr', {}, [
      el('th.col-check', {}, [selectAll]),
      el('th', { text: 'ID hồ sơ' }), el('th', { text: 'Tên hồ sơ' }), el('th', { text: 'Nhóm' }),
    ])]),
    tbody,
  ]);

  const sizeSel = pageSizeSelect([25, 50, 100], { value: pageSize, onChange: (v) => { pageSize = v; page = 0; renderPage(); } });

  const pager = el('div.pager', {}, [
    el('span.muted', { text: 'Số dòng mỗi trang' }), sizeSel,
    el('span', { style: { flex: '1' } }),
    pagerText,
    el('button.icon-btn', { html: icon('chevron'), style: { transform: 'rotate(180deg)' }, onclick: () => { if (page > 0) { page--; renderPage(); } } }),
    pageNumbers,
    el('button.icon-btn', { html: icon('chevron'), onclick: () => { if ((page + 1) * pageSize < running.length) { page++; renderPage(); } } }),
  ]);

  const main = el('div.sync-main', {}, [
    el('div.sync-table-wrap', {}, [table, empty]),
    pager,
  ]);

  // ---------- right: shared "Console" panel (Cửa sổ / Văn bản / Tab) ----------
  // The host swaps between the live console and a "detached" placeholder. `display:contents`
  // (CSS) makes the host transparent to the flex layout so whichever child is shown sits in
  // the column directly and keeps the bordered panel frame.
  const collapsedPlaceholder = el('div.sync-console.is-collapsed', {}, [
    el('button.sync-restore-btn', { type: 'button', text: 'Khôi phục', onclick: () => restoreConsole() }),
    el('div.sync-collapsed-text', { text: 'Nhấp vào Khôi phục cửa sổ/Đóng cửa sổ để khôi phục thanh hành động về vị trí ban đầu' }),
  ]);
  const consoleHost = el('div.sync-console-host', {}, [consoleApi.el]);

  let consoleDetached = false;
  function collapseConsole() {
    if (consoleDetached) return;
    consoleDetached = true;
    vt.console.open(scopeIds()).catch(() => {});
    clear(consoleHost);
    consoleHost.appendChild(collapsedPlaceholder);
  }
  function restoreConsole() {
    if (!consoleDetached) return;
    consoleDetached = false;
    try { vt.console.close(); } catch { /* ignore */ }
    clear(consoleHost);
    consoleHost.appendChild(consoleApi.el);
  }
  // When the floating Console window is closed (its own ✕, or sync stop), dock the bar back.
  if (window.__consoleClosedUnsub) { try { window.__consoleClosedUnsub(); } catch { /* ignore */ } }
  window.__consoleClosedUnsub = vt.console.onClosed ? vt.console.onClosed(() => restoreConsole()) : null;

  const layout = el('div.sync-layout', {}, [main, consoleHost]);

  const page1 = el('div.page', {}, [toolbar, layout]);
  ctx.container.appendChild(page1);
  load();
  return null;
}
