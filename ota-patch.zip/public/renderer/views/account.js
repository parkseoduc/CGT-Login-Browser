// "Hồ sơ đăng ký" - trang thông tin cá nhân của tài khoản đang đăng nhập.
// Hiển thị email/trạng thái/ngày tạo + cho ĐỔI MẬT KHẨU ngay tại app (không cần
// xác thực email). Server vẫn bắt nhập ĐÚNG mật khẩu hiện tại để bảo mật.
import { el, toast, withSpin } from '../ui.js';
import { icon } from '../icons.js';
import { notifyError } from '../data/errors.js';

// Bảng gradient theo chữ cái - GIỐNG avatar ở header (app.js AVATAR_GRADIENTS) để
// hai nơi luôn cùng một màu cho cùng một email.
const AVATAR_GRADIENTS = [
  'linear-gradient(135deg,#FF6B6B 0%,#D8365D 100%)', 'linear-gradient(135deg,#FF8E53 0%,#FE6B8B 100%)',
  'linear-gradient(135deg,#FFB13C 0%,#FF7A18 100%)', 'linear-gradient(135deg,#F9D423 0%,#F76B1C 100%)',
  'linear-gradient(135deg,#C2E059 0%,#5FA803 100%)', 'linear-gradient(135deg,#43E97B 0%,#159957 100%)',
  'linear-gradient(135deg,#2AF598 0%,#009EFD 100%)', 'linear-gradient(135deg,#43CEA2 0%,#187FA0 100%)',
  'linear-gradient(135deg,#4FACFE 0%,#00C6FB 100%)', 'linear-gradient(135deg,#5B9BFF 0%,#1D7BD8 100%)',
  'linear-gradient(135deg,#667EEA 0%,#3A47C6 100%)', 'linear-gradient(135deg,#7367F0 0%,#4634C9 100%)',
  'linear-gradient(135deg,#9D50BB 0%,#6E48AA 100%)', 'linear-gradient(135deg,#B24592 0%,#8E2DE2 100%)',
  'linear-gradient(135deg,#DA22FF 0%,#9733EE 100%)', 'linear-gradient(135deg,#F857A6 0%,#B5179E 100%)',
  'linear-gradient(135deg,#FF5FA2 0%,#E1306C 100%)', 'linear-gradient(135deg,#F5515F 0%,#A1051D 100%)',
  'linear-gradient(135deg,#E65C00 0%,#C0392B 100%)', 'linear-gradient(135deg,#F2994A 0%,#C97B1C 100%)',
  'linear-gradient(135deg,#B8C400 0%,#6A8500 100%)', 'linear-gradient(135deg,#11998E 0%,#065C55 100%)',
  'linear-gradient(135deg,#00B4DB 0%,#0083B0 100%)', 'linear-gradient(135deg,#396AFC 0%,#2948FF 100%)',
  'linear-gradient(135deg,#8E54E9 0%,#4776E6 100%)', 'linear-gradient(135deg,#c04848 0%,#480048 100%)',
];
function avatarGradient(ch) {
  const c = (ch || 'V').toUpperCase();
  const code = c.charCodeAt(0);
  const idx = code >= 65 && code <= 90 ? code - 65 : code % AVATAR_GRADIENTS.length;
  return AVATAR_GRADIENTS[idx % AVATAR_GRADIENTS.length];
}

// Định dạng ngày ISO → DD/MM/YYYY HH:mm (giống lưới hồ sơ).
function fmtDate(iso) {
  if (!iso) return '-';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return String(iso);
  const p = (n) => String(n).padStart(2, '0');
  return `${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

export function render(ctx) {
  // Một dòng thông tin chỉ-đọc (nhãn trái, giá trị phải).
  function infoRow(label, valueNode) {
    return el('div.set-row', {}, [
      el('div.set-row-text', {}, [el('div.set-row-title', { text: label })]),
      el('div.set-row-ctl', {}, [typeof valueNode === 'string' ? el('div.acc-value', { text: valueNode }) : valueNode]),
    ]);
  }
  function section(title) {
    return el('div.set-section-head', {}, [el('span', { text: title })]);
  }

  // --- Hero: avatar lớn + email ---
  const heroAvatar = el('div.acc-hero-avatar');
  const heroMail = el('div.acc-hero-mail', { text: '-' });
  const heroSub = el('div.acc-hero-sub.muted', { text: 'Tài khoản CGTBrowser' });
  const hero = el('div.card.acc-hero', {}, [
    heroAvatar,
    el('div.acc-hero-text', {}, [heroMail, heroSub]),
  ]);

  // --- Thông tin tài khoản ---
  const vEmail = el('div.acc-value', { text: '-' });
  const vStatus = el('span.pill.acc-pill', { text: '-' });
  const vVerified = el('span.pill.acc-pill', { text: '-' });
  const vCreated = el('div.acc-value.muted', { text: '-' });
  const vId = el('div.acc-value.muted', { style: { fontFamily: 'monospace', fontSize: '12px' }, text: '-' });

  const infoCard = el('div.card.set-card', {}, [
    section('Thông tin tài khoản'),
    infoRow('Email', vEmail),
    infoRow('Trạng thái', vStatus),
    infoRow('Xác thực email', vVerified),
    infoRow('Ngày tạo', vCreated),
    infoRow('ID tài khoản', vId),
  ]);

  // --- Đổi mật khẩu ---
  const curInput = el('input.input', { type: 'password', placeholder: 'Mật khẩu hiện tại', autocomplete: 'current-password' });
  const newInput = el('input.input', { type: 'password', placeholder: 'Mật khẩu mới (tối thiểu 6 ký tự)', autocomplete: 'new-password' });
  const confirmInput = el('input.input', { type: 'password', placeholder: 'Nhập lại mật khẩu mới', autocomplete: 'new-password' });

  function pwRow(label, inputEl) {
    return el('div.set-row', {}, [
      el('div.set-row-text', {}, [el('div.set-row-title', { text: label })]),
      el('div.set-row-ctl', {}, [inputEl]),
    ]);
  }

  const saveBtn = el('button.btn.primary', {
    html: `${icon('check')}<span>Đổi mật khẩu</span>`,
    onclick: (e) => withSpin(e.currentTarget, async () => {
      const currentPassword = curInput.value;
      const newPassword = newInput.value;
      const confirm = confirmInput.value;

      if (!currentPassword) { toast('Vui lòng nhập mật khẩu hiện tại', 'err'); curInput.focus(); return; }
      if (newPassword.length < 6) { toast('Mật khẩu mới tối thiểu 6 ký tự', 'err'); newInput.focus(); return; }
      if (newPassword !== confirm) { toast('Mật khẩu nhập lại không khớp', 'err'); confirmInput.focus(); return; }
      if (newPassword === currentPassword) { toast('Mật khẩu mới trùng mật khẩu hiện tại', 'err'); newInput.focus(); return; }

      let res;
      try {
        res = await vt.auth.changePassword({ currentPassword, newPassword });
      } catch (err) { notifyError(err, 'Đổi mật khẩu thất bại'); return; }
      if (!res || res.ok === false) { notifyError(res, 'Đổi mật khẩu thất bại'); return; }

      curInput.value = ''; newInput.value = ''; confirmInput.value = '';
      toast('Đã đổi mật khẩu thành công', 'ok');
    }),
  });

  const pwCard = el('div.card.set-card', {}, [
    section('Đổi mật khẩu'),
    el('div.set-row', {}, [
      el('div.set-row-text', {}, [
        el('div.set-row-sub.muted', { text: 'Đổi mật khẩu ngay tại đây, không cần xác thực qua email. Bạn chỉ cần nhập đúng mật khẩu hiện tại.' }),
      ]),
    ]),
    pwRow('Mật khẩu hiện tại', curInput),
    pwRow('Mật khẩu mới', newInput),
    pwRow('Nhập lại mật khẩu mới', confirmInput),
    el('div.acc-pw-actions', {}, [saveBtn]),
  ]);

  const page = el('div.page.account-page', {}, [
    el('div.page-head.settings-head', {}, [
      el('div.muted', { text: 'Thông tin tài khoản và bảo mật' }),
    ]),
    el('div.set-scroll', {}, [hero, infoCard, pwCard]),
  ]);
  ctx.container.appendChild(page);

  // Nạp thông tin tài khoản hiện tại từ server (fallback về bản cache của phiên).
  vt.auth.status().then((s) => {
    const acc = (s && s.account) || {};
    const mail = (acc.email || 'Tài khoản').trim();
    const initial = (mail.charAt(0) || 'V').toUpperCase();

    heroAvatar.textContent = initial;
    heroAvatar.style.background = avatarGradient(initial);
    heroMail.textContent = mail;

    vEmail.textContent = mail;

    const active = acc.status === 'active';
    vStatus.textContent = active ? 'Đang hoạt động' : (acc.status || '-');
    vStatus.classList.toggle('ok', active);
    vStatus.classList.toggle('warn', !active);

    const verified = !!acc.emailVerified;
    vVerified.textContent = verified ? 'Đã xác thực' : 'Chưa xác thực';
    vVerified.classList.toggle('ok', verified);
    vVerified.classList.toggle('warn', !verified);

    vCreated.textContent = fmtDate(acc.createdAt);
    vId.textContent = acc.id || '-';
  }).catch((err) => notifyError(err, 'Không tải được thông tin tài khoản'));

  return null;
}
