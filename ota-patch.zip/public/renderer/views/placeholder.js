// Generic "coming soon" view used by routes that mirror the WPF
// PlaceholderView (Kho kịch bản, API, Nhật ký, Hỗ trợ).
import { el } from '../ui.js';
import { icon } from '../icons.js';

export function render(ctx) {
  const meta = (ctx && ctx.meta) || ['about', 'Sắp ra mắt', ''];
  ctx.container.appendChild(el('div.placeholder-view', {}, [
    el('div.big', { html: icon(meta[0]) }),
    el('h2', { text: meta[1] }),
    el('div.muted', { text: meta[2] }),
  ]));
  return null;
}
