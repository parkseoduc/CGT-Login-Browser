// Quản lý "Nhân trình duyệt" (Chromium/Firefox) phía APP - mô hình đa nhân tải-về-sau
// (giống AdsPower/GoLogin). Hiển thị TRONG trang Cài đặt (tab "Trình duyệt"): danh sách
// nhân hợp nhất server∪đã-cài, cho phép Tải / Dùng / Gỡ. Khi tải: modal PROGRESS HÌNH TRÒN
// pha trộn 3 màu đặc trưng của app (#88C4FF → #6AA9FF → #1D7BD8, giống --brand-gradient),
// ở giữa hiển thị % + dung lượng đang tải / tổng.
//
// Nguồn dữ liệu: window.vt.kernel.* (IPC → kernel-manager ở main). list/download/
// ensureAtLeastOne trả envelope { ok, data }; installed/setActive/remove trả trực tiếp.
import { el, toast, withSpin, confirmDialog } from '../ui.js';
import { icon } from '../icons.js';
import { setActiveKernel, registerKernelBuild } from '../data/fingerprint.js';
// Mọi câu có nhúng tên nhân/phiên bản phải đi qua tf(): i18n tra từ điển bằng ĐÚNG
// nội dung text node, mà "Tải nhân Chromium 140" thì không bao giờ có trong từ điển.
import { tf } from '../i18n.js';
// Nhãn engine dùng chung (bản sao thứ ba trước đây nằm ngay tại file này) - xem
// data/browser-badge.js. Một chỗ khai báo thì mọi nơi KHÔNG THỂ gọi khác tên nhau.
import { ENGINE_LABEL } from '../data/browser-badge.js';

// App chỉ đóng gói bản Windows x64 → cố định platform (server lọc theo đây).
const PLATFORM = 'win-x64';

// ---------------------------------------------------------------- tiện ích định dạng
function fmtBytes(n) {
  const b = Number(n) || 0;
  if (b >= 1024 * 1024 * 1024) return (b / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
  if (b >= 1024 * 1024) return (b / (1024 * 1024)).toFixed(1) + ' MB';
  if (b >= 1024) return (b / 1024).toFixed(0) + ' KB';
  return b + ' B';
}
function fmtSizeMb(mb) {
  const v = Number(mb);
  if (!Number.isFinite(v) || v <= 0) return null;
  return v >= 1024 ? (v / 1024).toFixed(2) + ' GB' : v.toFixed(v < 10 ? 1 : 0) + ' MB';
}

// ---------------------------------------------------------------- vòng tròn tiến độ
// Trả { node, setPercent(p), setCenter(main, sub), setPhase(text), indeterminate(on) }.
// Dùng SVG 2 vòng: TRACK mờ + ARC gradient 3 màu brand (#88C4FF → #6AA9FF → #1D7BD8), đầu
// arc BO TRÒN (stroke-linecap round) cho gọn gàng. Tiến độ = stroke-dashoffset (transition
// mượt). Lúc verify/extract (chưa biết %) → arc ngắn cố định + xoay tròn kiểu spinner.
const RING_R = 54;
const RING_CIRC = 2 * Math.PI * RING_R; // ~339.29
function makeRing() {
  const pct = el('div.kn-ring-pct', { text: '0%' });
  const sub = el('div.kn-ring-sub', { text: '' });
  const center = el('div.kn-ring-center', {}, [pct, sub]);

  const ring = el('div.kn-ring', {
    html: `
      <svg class="kn-ring-svg" viewBox="0 0 128 128" aria-hidden="true">
        <defs>
          <linearGradient id="knRingGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#88C4FF"/>
            <stop offset="0.5" stop-color="#6AA9FF"/>
            <stop offset="1" stop-color="#1D7BD8"/>
          </linearGradient>
        </defs>
        <circle class="kn-ring-track" cx="64" cy="64" r="${RING_R}"/>
        <circle class="kn-ring-arc" cx="64" cy="64" r="${RING_R}"
          stroke="url(#knRingGrad)"
          stroke-dasharray="${RING_CIRC.toFixed(2)}"
          stroke-dashoffset="${RING_CIRC.toFixed(2)}"
          transform="rotate(-90 64 64)"/>
      </svg>`,
  });
  ring.appendChild(center);
  const arc = ring.querySelector('.kn-ring-arc');
  const setOffset = (pctVal) => {
    const off = RING_CIRC * (1 - Math.max(0, Math.min(100, pctVal)) / 100);
    arc.style.strokeDashoffset = off.toFixed(2);
  };

  const phase = el('div.kn-phase', {}, [el('span.kn-phase-dot'), el('span.kn-phase-txt', { text: '' })]);
  const phaseTxt = phase.querySelector('.kn-phase-txt');
  const node = el('div.kn-prog', {}, [ring, phase]);
  return {
    node,
    setPercent(p) {
      const v = Math.max(0, Math.min(100, Math.round(Number(p) || 0)));
      ring.classList.remove('indet');
      arc.style.strokeDasharray = RING_CIRC.toFixed(2);
      setOffset(v);
      pct.textContent = v + '%';
    },
    setCenter(mainText, subText) {
      pct.textContent = mainText;
      sub.textContent = subText || '';
    },
    setSub(subText) { sub.textContent = subText || ''; },
    setPhase(text) { phaseTxt.textContent = text || ''; },
    // Trạng thái lỗi: đổi "pill" tiến độ sang đỏ + tắt chấm nhấp nháy.
    phaseError(on) { phase.classList.toggle('err', !!on); },
    // Chưa biết % (verify/extract) → arc ngắn (~25%) + xoay tròn như spinner.
    indeterminate(on) {
      if (on) {
        ring.classList.add('indet');
        arc.style.strokeDasharray = `${(RING_CIRC * 0.25).toFixed(2)} ${(RING_CIRC * 0.75).toFixed(2)}`;
        arc.style.strokeDashoffset = '0';
      } else {
        ring.classList.remove('indet');
        arc.style.strokeDasharray = RING_CIRC.toFixed(2);
      }
    },
  };
}

// ---------------------------------------------------------------- modal tải 1 nhân
// item: phần tử combined-list (cần engine, version, url, sha256, sizeMb…). Trả Promise
// resolve(true) khi tải xong, resolve(false) khi người dùng đóng/huỷ. mandatory=true ⇒ ẩn
// nút đóng cho tới khi xong (dùng cho tự-tải lần đầu bắt buộc).
let _activeKernelDownloadPromise = null;

export function openKernelDownloadModal(item, { mandatory = false, onDone } = {}) {
  if (_activeKernelDownloadPromise) {
    const host = document.getElementById('modal-host');
    if (host && !host.classList.contains('open')) host.classList.add('open');
    if (onDone) {
      _activeKernelDownloadPromise.then((ok) => { if (ok) onDone(); });
    }
    return _activeKernelDownloadPromise;
  }

  _activeKernelDownloadPromise = new Promise((resolve) => {
    const host = document.getElementById('modal-host');
    // Dọn host (giống closeModal) rồi dựng modal riêng.
    while (host.firstChild) host.removeChild(host.firstChild);

    const engine = item && item.engine === 'firefox' ? 'firefox' : 'chromium';
    const sizeLabel = fmtSizeMb(item && item.sizeMb);
    const ring = makeRing();

    let settled = false;
    let off = null; // huỷ đăng ký onProgress
    const finish = (ok) => {
      if (settled) return;
      settled = true;
      _activeKernelDownloadPromise = null;
      try { off && off(); } catch { /* ignore */ }
      host.classList.remove('open');
      while (host.firstChild) host.removeChild(host.firstChild);
      resolve(ok);
      if (ok && typeof onDone === 'function') { try { onDone(); } catch { /* ignore */ } }
    };

    const title = el('h3.kn-dl-title', {
      text: tf('Tải trình duyệt {0} {1}', ENGINE_LABEL[engine], (item && item.version) || '').trim(),
    });
    const subTitle = el('div.kn-dl-sub', {
      text: sizeLabel ? tf('Dung lượng gói ~ {0}', sizeLabel) : 'Đang chuẩn bị tải…',
    });
    // Huy hiệu engine (icon Chrome/Firefox) cho đầu modal thêm nhận diện.
    const engBadge = el('div.kn-dl-eng.' + engine, { html: icon(engine === 'firefox' ? 'firefox' : 'chrome') });

    // Nút đóng (X) - chỉ hiện khi KHÔNG bắt buộc. Trong lúc tải sẽ bị ẩn để tránh đóng nhầm.
    const closeX = el('button.icon-btn.x', { html: icon('close'), title: 'Đóng', onclick: () => finish(false) });
    const head = el('div.modal-head.kn-dl-head', {}, [
      el('div.kn-dl-headmain', {}, [engBadge, el('div', {}, [title, subTitle])]),
      mandatory ? null : closeX,
    ]);

    // Vùng nút hành động (ẩn lúc đang tải; hiện khi lỗi để "Thử lại"/"Đóng").
    const retryBtn = el('button.btn.primary', { text: 'Thử lại', style: { display: 'none' } });
    const closeBtn = el('button.btn', { text: 'Đóng', style: { display: 'none' } });
    const foot = el('div.modal-foot.kn-dl-foot', {}, [closeBtn, retryBtn]);

    const modal = el('div.modal.kn-dl-modal', { style: { width: '500px' } }, [
      head,
      el('div.modal-body.kn-dl-body', {}, [ring.node]),
      foot,
    ]);
    // Scrim: bấm ra ngoài chỉ đóng khi KHÔNG bắt buộc và không đang tải.
    const scrim = el('div.scrim', { onclick: () => { if (!mandatory && !downloading) finish(false); } });
    host.appendChild(scrim);
    host.appendChild(modal);
    host.classList.add('open');

    let downloading = false;

    const showError = (msg) => {
      downloading = false;
      ring.indeterminate(false);
      ring.setPercent(0);
      ring.setCenter('Lỗi', '');
      ring.phaseError(true);
      ring.setPhase(msg || 'Tải thất bại');
      retryBtn.style.display = 'inline-flex';
      closeBtn.style.display = 'inline-flex';
      if (!mandatory) closeX.style.display = 'inline-flex';
    };

    const start = async () => {
      downloading = true;
      retryBtn.style.display = 'none';
      closeBtn.style.display = 'none';
      closeX.style.display = 'none';
      ring.phaseError(false);
      ring.setPercent(0);
      ring.setCenter('0%', sizeLabel ? `0 / ${sizeLabel}` : '');
      ring.setPhase('Đang kết nối…');

      // Đăng ký nhận tiến độ (huỷ đăng ký cũ trước, tránh chồng khi Thử lại).
      try { off && off(); } catch { /* ignore */ }
      off = vt.kernel.onProgress((p) => {
        if (!p) return;
        if (p.phase === 'download') {
          const total = Number(p.total) || 0;
          const recv = Number(p.received) || 0;
          const pctVal = total > 0 ? (recv / total) * 100 : (Number(p.percent) || 0);
          ring.setPercent(pctVal);
          const totalTxt = total > 0 ? fmtBytes(total) : (sizeLabel || '');
          ring.setCenter(Math.round(pctVal) + '%', totalTxt ? `${fmtBytes(recv)} / ${totalTxt}` : fmtBytes(recv));
          ring.setPhase('Đang tải…');
        } else if (p.phase === 'verify') {
          ring.indeterminate(true);
          ring.setCenter('Kiểm tra', '');
          ring.setPhase('Đang kiểm tra toàn vẹn (SHA256)…');
        } else if (p.phase === 'extract') {
          ring.indeterminate(true);
          ring.setCenter('Giải nén', '');
          ring.setPhase('Đang giải nén trình duyệt…');
        } else if (p.phase === 'done') {
          ring.indeterminate(false);
          ring.setPercent(100);
          ring.setCenter('Xong', '');
          ring.setPhase('Hoàn tất');
        }
      });

      const res = await vt.kernel.download(item);
      downloading = false;
      try { off && off(); off = null; } catch { /* ignore */ }
      if (res && res.ok) {
        toast(tf('Đã cài trình duyệt {0} {1}', ENGINE_LABEL[engine], item.version), 'ok');
        try {
          window.dispatchEvent(new CustomEvent('cgt:kernel-installed', {
            detail: { engine, major: item.major || 153, version: item.version }
          }));
        } catch {}
        finish(true);
      } else {
        showError((res && res.error) || 'Tải thất bại');
      }
    };

    retryBtn.addEventListener('click', () => { start().catch((e) => showError(e && e.message)); });
    closeBtn.addEventListener('click', () => finish(false));

    // Tự bắt đầu ngay.
    start().catch((e) => showError(e && e.message));
  });
}

// ---------------------------------------------------------------- thẻ quản lý (trong Cài đặt)
// Trả về 1 phần tử DOM tự nạp danh sách. Có segmented Chromium/Firefox; mỗi hàng là 1 major.
export function renderKernelCard() {
  let engine = 'chromium';

  const listBox = el('div.kn-list');
  const note = el('div.kn-note', { style: { display: 'none' } });

  // Segmented Chromium / Firefox (kiểu .seg giống web admin).
  const seg = el('div.seg.kn-seg');
  const segBtns = {};
  ['chromium', 'firefox'].forEach((e) => {
    const b = el('button.seg-opt' + (e === engine ? '.active' : ''), {
      type: 'button',
      text: ENGINE_LABEL[e],
      onclick: () => {
        if (engine === e) return;
        engine = e;
        Object.values(segBtns).forEach((x) => x.classList.remove('active'));
        b.classList.add('active');
        reload();
      },
    });
    segBtns[e] = b;
    seg.append(b);
  });

  const refreshBtn = el('button.btn.kn-refresh', {
    type: 'button',
    html: icon('refresh') + '<span>Làm mới</span>',
    title: 'Tải lại danh sách từ máy chủ',
    onclick: (ev) => withSpin(ev.currentTarget, () => reload()),
  });

  const localZipBtn = el('button.btn.kn-localzip', {
    type: 'button',
    html: icon('folder') + '<span>Cài từ gói .zip</span>',
    title: 'Cài nhanh nhân trình duyệt từ tệp .zip / .tar.gz cục bộ',
    onclick: (ev) => withSpin(ev.currentTarget, async () => {
      const zipPath = await vt.dialog.openFile({
        title: 'Chọn gói nén nhân trình duyệt (.zip / .tar.gz)',
        filters: [{ name: 'Kernel Archive', extensions: ['zip', 'gz', 'tgz'] }],
      });
      if (!zipPath) return;
      const r = await vt.kernel.installLocal({ engine, zipPath });
      if (r && r.ok) {
        toast('Đã cài đặt nhân cục bộ thành công', 'ok');
        reload();
      } else {
        toast((r && r.error) || 'Không cài đặt được gói nhân cục bộ', 'error');
      }
    }),
  });

  const header = el('div.kn-head', {}, [seg, el('div.kn-head-actions', {}, [localZipBtn, refreshBtn])]);

  function badge(cls, text) { return el('span.kn-badge.' + cls, { text }); }

  function rowFor(it) {
    const meta = [];
    const sizeLabel = fmtSizeMb(it.sizeMb);
    if (sizeLabel) meta.push(sizeLabel);
    meta.push(tf('bản {0}', it.major));
    if (it.mandatory && !it.installed) meta.push('khuyến nghị');

    const badges = [];
    if (it.active) badges.push(badge('on', 'Đang dùng'));
    else if (it.installed) badges.push(badge('inst', 'Đã cài'));
    if (!it.installed && it.source === 'server') badges.push(badge('new', 'Chưa cài'));
    if (it.source === 'local') badges.push(badge('local', 'Chỉ có ở máy'));

    const actions = [];
    if (!it.installed) {
      // Có URL mới tải được (nhân 'local' không có URL server → không thể tải lại).
      const canDownload = !!it.url;
      actions.push(el('button.btn.primary.kn-act', {
        type: 'button',
        text: 'Tải',
        disabled: canDownload ? null : true,
        title: canDownload ? 'Tải & cài nhân này' : 'Không có nguồn tải',
        onclick: () => openKernelDownloadModal({ ...it, engine }, { onDone: reload }),
      }));
    } else {
      if (!it.active) {
        actions.push(el('button.btn.kn-act', {
          type: 'button',
          text: 'Dùng',
          title: 'Đặt làm nhân đang dùng',
          onclick: (ev) => withSpin(ev.currentTarget, async () => {
            const ok = await vt.kernel.setActive(engine, it.major);
            if (ok) { toast(tf('Đang dùng {0} {1}', ENGINE_LABEL[engine], it.version), 'ok'); reload(); }
            else toast('Không đặt được nhân đang dùng', 'error');
          }),
        }));
      }
      actions.push(el('button.icon-btn.kn-del', {
        type: 'button',
        html: icon('trash'),
        title: it.active ? 'Gỡ nhân (đang dùng)' : 'Gỡ nhân',
        onclick: () => confirmDialog({
          title: 'Gỡ nhân trình duyệt',
          message: tf('Gỡ {0} {1} khỏi máy? Có thể tải lại sau.', ENGINE_LABEL[engine], it.version),
          danger: true,
          confirmLabel: 'Gỡ',
          onConfirm: async () => {
            const ok = await vt.kernel.remove(engine, it.major);
            if (ok) { toast('Đã gỡ nhân', 'ok'); reload(); }
            else toast('Không gỡ được nhân', 'error');
          },
        }),
      }));
    }

    return el('div.kn-row' + (it.active ? '.active' : ''), {}, [
      el('div.kn-row-main', {}, [
        el('div.kn-row-ver', {}, [el('span.kn-row-name', { text: `${ENGINE_LABEL[engine]} ${it.version}` }), ...badges]),
        el('div.kn-row-meta', { text: meta.join(' · ') }),
      ]),
      el('div.kn-row-act', {}, actions),
    ]);
  }

  async function reload() {
    listBox.innerHTML = '';
    note.style.display = 'none';
    listBox.append(el('div.kn-loading', { text: 'Đang tải danh sách…' }));

    const res = await vt.kernel.list(engine, PLATFORM);
    listBox.innerHTML = '';

    if (!res || !res.ok) {
      listBox.append(el('div.set-empty', { text: 'Không lấy được danh sách nhân. Kiểm tra kết nối rồi Làm mới.' }));
      return;
    }
    const data = res.data || {};
    const items = Array.isArray(data.items) ? data.items : [];
    if (!items.length) {
      listBox.append(el('div.set-empty', { text: tf('Chưa có nhân {0} nào trên máy chủ.', ENGINE_LABEL[engine]) }));
      return;
    }
    items.forEach((it) => listBox.append(rowFor(it)));

    // Nhắc nếu chưa có nhân nào đã cài cho engine này.
    const anyInstalled = items.some((it) => it.installed);
    if (!anyInstalled) {
      note.textContent = tf('Bạn chưa cài nhân {0} nào - bấm "Tải" ở bản mới nhất để bắt đầu.', ENGINE_LABEL[engine]);
      note.style.display = 'block';
    }

    // Đổi nhân đang dùng / vừa cài → đồng bộ ngay phiên bản cho vân tay (không cần khởi động lại).
    syncActiveKernelToFingerprint();
  }

  const card = el('div.set-list.kn-card', {}, [header, note, listBox]);
  reload();
  return card;
}

// ---------------------------------------------------------------- đồng bộ vân tay
// Đọc nhân ĐANG DÙNG (Chromium + Firefox) rồi cập nhật phiên bản engine cho fingerprint.js
// → UA/Client-Hints mặc định luôn khớp binary thật đang chạy (không còn hardcode 140.x).
// Gọi lúc boot và sau mỗi lần đổi nhân/tải nhân. Best-effort - lỗi không ảnh hưởng luồng.
export async function syncActiveKernelToFingerprint() {
  try {
    const [chr, fx] = await Promise.all([
      vt.kernel.installed('chromium'),
      vt.kernel.installed('firefox'),
    ]);
    const pick = (list) => {
      if (!Array.isArray(list) || !list.length) return null;
      return list.find((k) => k.active) || list[0]; // list đã sắp major giảm dần
    };
    const activeChr = pick(chr);
    const activeFx = pick(fx);
    // Nạp full-version THẬT của MỌI nhân chromium đã cài vào bảng build của
    // fingerprint.js - không chỉ nhân đang dùng. Nhờ vậy dropdown "User-Agent" và
    // randomChromeFull() biết cả những major MỚI HƠN bảng chụp lúc phát hành app
    // (vd tải 151 từ server) mà KHÔNG phải sửa source. Số đưa vào là số đọc từ
    // binary trên đĩa nên không có chuyện bịa build.
    if (Array.isArray(chr)) for (const k of chr) registerKernelBuild(k && k.version);
    setActiveKernel({
      chromiumFull: activeChr ? activeChr.version : undefined,
      firefoxVersion: activeFx ? activeFx.version : undefined,
    });
  } catch { /* giữ mặc định */ }
}

// ---------------------------------------------------------------- tự-tải lần đầu
// Gọi lúc app khởi động: nếu CHƯA có nhân Chromium 153 tùy biến nào đã cài → lấy bản mới nhất từ server
// và mở modal tải gợi ý. Trả true nếu đã cài xong (hoặc đã có sẵn), false nếu không.
export async function ensureKernelOnStartup(engine = 'chromium') {
  try {
    if (engine === 'chromium') {
      const isCustom = await vt.kernel.isCustomInstalled();
      if (isCustom) return true; // đã có nhân 153 tùy biến chuẩn → thôi
    } else {
      const installed = await vt.kernel.installed(engine);
      if (Array.isArray(installed) && installed.length) return true;
    }

    const res = await vt.kernel.list(engine, PLATFORM);
    if (!res || !res.ok) return false;
    const items = (res.data && res.data.items) || [];
    // items đã sắp major giảm dần; ưu tiên bản 153 khuyến nghị
    const target = items.find((it) => it.major === 153 && !it.installed && it.url) || items.find((it) => it.url && !it.installed);
    if (!target) return false;

    return await openKernelDownloadModal({ ...target, engine }, { mandatory: false });
  } catch {
    return false;
  }
}

// ---------------------------------------------------------------- cổng "phải có nhân"
// Gọi TRƯỚC khi mở hồ sơ (phương án B - bản thương mại không fallback vendor/hệ thống).
// Nếu đã có nhân đã cài → true ngay. Nếu chưa → mở modal tải (CÓ THỂ HUỶ, không bắt buộc);
// tải xong đồng bộ vân tay + trả true, người dùng huỷ → false. Không có nhân nào trên
// server để tải → toast lỗi + false. Best-effort: mọi lỗi → false (không mở bừa).
export async function ensureKernelReady(engine = 'chromium') {
  try {
    // Chế độ admin "Vendor": KHÔNG ép tải nhân - để main chạy vendor bundle cục bộ.
    try { const s = await vt.settings.all(); if (s && s.browserSource === 'vendor') return true; } catch { /* coi như storage */ }

    if (engine === 'chromium') {
      const isCustom = await vt.kernel.isCustomInstalled();
      if (isCustom) return true; // đã có nhân 153 chuẩn → cho mở
    } else {
      const installed = await vt.kernel.installed(engine);
      if (Array.isArray(installed) && installed.length) return true;
    }

    const res = await vt.kernel.list(engine, PLATFORM);
    const items = (res && res.ok && res.data && res.data.items) || [];
    const target = items.find((it) => it.major === 153 && !it.installed && it.url) || items.find((it) => it.url && !it.installed);
    if (!target) {
      toast('Chưa có nhân trình duyệt khả dụng để tải. Vui lòng liên hệ quản trị viên.', 'error');
      return false;
    }

    const ok = await openKernelDownloadModal({ ...target, engine }, { mandatory: false });
    if (ok) { try { await syncActiveKernelToFingerprint(); } catch { /* giữ mặc định */ } }
    return ok;
  } catch {
    return false;
  }
}
