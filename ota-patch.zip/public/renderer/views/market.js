// "Chợ" (Marketplace) - kho kịch bản RPA. LOGIC theo mô hình MKTLogin (danh mục CÔNG
// KHAI do tài khoản is_publisher đăng; người dùng CÀI về = copy public → flow riêng của
// workspace; kịch bản trả phí cần entitlement, mua trừ ví workspace ở server). GIAO DIỆN
// bố trí GIỐNG trang "Tiện ích": thanh đầu [nút chính + ô tìm kiếm + bộ lọc], hàng chip
// nền tảng, lưới thẻ (.ext-grid/.ext-card). Thẻ ĐƠN GIẢN kiểu AdsPower: icon + tên + pill
// danh mục (trái), gem trả phí + 👥 lượt tải (phải), mô tả 2 dòng, dòng "Nhà phát triển".
// Bấm cả thẻ → mở MODAL Chi tiết (Read Me/Changelog + mọi hành động tải/mua/báo cáo/sửa).
//
// Dữ liệu qua window.vt.market.* (IPC → server /marketplace).
//   market.list()  → { items, canPublish, owned:[flowId] }  (GET, raw)
//   market.get(id) → { item, owned }                          (GET, raw)
//   market.install/purchase/publish/update/remove             (envelope { ok, data, code })
import { el, clear, toast, customSelect, confirmDialog,
  openModal, closeModal, noDataSvg, pageSizeSelect, openMenu, hoverMenu } from '../ui.js';
import { icon } from '../icons.js';
import { brandLogoSvg, brandTileBg, hasBrandLogo } from '../data/brand-icons.js';
import { notifyError } from '../data/errors.js';
import { openDevProfileEditor } from '../data/dev-profile.js';
import { ensureQuill } from '../vendor-quill.js';
import { hasFeature, gateFeature } from '../data/plan-features.js';
import { openLegalModal, TERMS_SECTIONS } from './login.js';
import { t, tf } from '../i18n.js';

// Tem "đã xác minh" giống tích xanh Facebook: đài răng cưa xanh (currentColor) + dấu tích
// TRẮNG nổi ở giữa. Canh chỉnh + kích thước xử lý ở CSS (.mkt-verified-badge).
const VERIFIED_SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="currentColor" d="m23 12l-2.44-2.79l.34-3.69l-3.61-.82l-1.89-3.2L12 2.96L8.6 1.5L6.71 4.69L3.1 5.5l.34 3.7L1 12l2.44 2.79l-.34 3.7l3.61.82L8.6 22.5l3.4-1.47l3.4 1.46l1.89-3.19l3.61-.82l-.34-3.69z"/><path fill="#fff" d="M10.09 16.72l-3.8-3.81l1.48-1.48l2.32 2.33l5.85-5.87l1.48 1.48z"/></svg>`;

// Dấu tích xanh "đã xác minh" (xanh FB #1877F2). Kích thước + canh giữa ở app.css.
function verifiedBadge() {
  return el('span.mkt-verified-badge', {
    html: VERIFIED_SVG, title: 'Đã xác minh', 'aria-label': 'Đã xác minh',
  });
}

// Nhãn tên nhà phát triển kèm dấu tích xanh đã xác minh (dùng ở thẻ người bán + trang hồ sơ).
function devName(name) {
  return el('span.mkt-dt-seller-name', {}, [name, verifiedBadge()]);
}

// Danh mục nền tảng (phân loại kịch bản). 'other' = khác. Nhãn hiển thị tiếng Việt.
const PLATFORMS = [
  { value: 'amazon', label: 'Amazon' },
  { value: 'ebay', label: 'Ebay' },
  { value: 'facebook', label: 'Facebook' },
  { value: 'google', label: 'Google' },
  { value: 'instagram', label: 'Instagram' },
  { value: 'reddit', label: 'Reddit' },
  { value: 'twitter', label: 'Twitter X' },
  { value: 'linkedin', label: 'LinkedIn' },
  { value: 'esty', label: 'Esty' },
  { value: 'discord', label: 'Discord' },
  { value: 'telegram', label: 'Telegram' },
  { value: 'zalo', label: 'Zalo' },
  { value: 'tiktok', label: 'Tiktok' },
  { value: 'youtube', label: 'YouTube' },
  { value: 'website', label: 'Website' },
  { value: 'other', label: 'Khác' },
];
const platformLabel = (v) => (PLATFORMS.find((p) => p.value === v) || {}).label || 'Khác';
// Màu icon vuông theo nền tảng (giống thẻ Tiện ích dùng màu nền + chữ cái đầu).
const PLATFORM_COLORS = {
  amazon: '#FF9900', ebay: '#E53238', facebook: '#1877F2', google: '#4285F4',
  instagram: '#E1306C', reddit: '#FF4500', twitter: '#111827', linkedin: '#0A66C2',
  esty: '#F1641E', discord: '#5865F2', telegram: '#229ED9', zalo: '#0068FF', tiktok: '#EE1D52',
  youtube: '#FF0000', website: '#2563EB', other: '#6B7280',
};
const platformColor = (p) => PLATFORM_COLORS[p] || '#1BB15C';

// ── format helpers ───────────────────────────────────────────────────────────
const fmtMoney = (n) => (Number(n) || 0).toLocaleString('vi-VN');
// Trả phí = mua MỘT LẦN, sở hữu VĨNH VIỄN → chỉ hiện số tiền, không kèm kỳ hạn (/tháng, /năm).
const feeLabel = (item) => (Number(item.price) > 0
  ? tf('{0} VND', fmtMoney(item.price))
  : 'Miễn phí');
// Trạng thái duyệt của kịch bản: chờ duyệt / đã duyệt / bị từ chối.
const STATUS_META = {
  pending: { label: 'Chờ duyệt', cls: 'pending' },
  approved: { label: 'Đã duyệt', cls: 'approved' },
  rejected: { label: 'Bị từ chối', cls: 'rejected' },
};
const statusPill = (status) => {
  const m = STATUS_META[status] || STATUS_META.pending;
  return el(`span.mkt-status-pill.${m.cls}`, { text: m.label });
};
// "cách đây …" gần đúng.
const timeAgo = (ms) => {
  if (!ms) return '-';
  const diff = Date.now() - Number(ms);
  const day = 86400000;
  if (diff < day) return 'hôm nay';
  const d = Math.floor(diff / day);
  if (d < 30) return tf('{0} ngày trước', d);
  const mo = Math.floor(d / 30);
  if (mo < 12) return tf('{0} tháng trước', mo);
  return tf('{0} năm trước', Math.floor(mo / 12));
};
// Chữ cái đầu (icon vuông / avatar).
const initial = (name) => (String(name || '?').trim()[0] || '?').toUpperCase();
// Đổ nội dung ảnh đại diện kịch bản vào ô `box` (đã có sẵn class kích thước):
//   (1) item.icon = ảnh tự tải (data URL/URL) → <img>;
//   (2) không có ảnh nhưng danh mục có logo thương hiệu → logo trên nền brand;
//   (3) fallback ô màu nền theo nền tảng + chữ cái đầu.
function fillIcon(box, item) {
  const ic = String((item && item.icon) || '');
  if (ic) {
    box.classList.add('has-img');
    box.appendChild(el('img.mkt-icon-img', { src: ic, alt: item.title || '' }));
    return box;
  }
  if (hasBrandLogo(item && item.platform)) {
    box.classList.add('has-brand');
    box.style.background = brandTileBg(item.platform);
    box.innerHTML = brandLogoSvg(item.platform);
    return box;
  }
  box.style.background = platformColor(item && item.platform);
  box.textContent = initial((item && (item.platform || item.title)));
  return box;
}
// 💎 (premium/trả phí) + 👥 (số lượt tải) - inline vì icons.js chưa có.
const GEM_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor"><path d="M3.1.7a.5.5 0 0 1 .4-.2h9a.5.5 0 0 1 .4.2l2.976 3.974c.149.185.156.45.01.644L8.4 15.3a.5.5 0 0 1-.8 0L.1 5.318a.5.5 0 0 1 .01-.644zm11.386 3.785-1.806-2.41-.776 2.413zm-3.633.004.961-2.989H4.186l.963 2.995zM5.47 5.495 8 13.366l2.532-7.876zm-1.371-.999-.78-2.422-1.818 2.425zM1.499 5.5l5.113 6.817-2.192-6.82zm7.889 6.817 5.123-6.83-2.928.002z"/></svg>';
const PEOPLE_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor"><path d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6m-5.784 6A2.24 2.24 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.3 6.3 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1zM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5"/></svg>';

export function render(ctx) {
  // ── state ──────────────────────────────────────────────────────────────────
  let items = [];
  let owned = new Set();
  let canPublish = true;   // MỌI tài khoản đều đăng được (bản đăng ở trạng thái chờ duyệt)
  let isAdmin = false;     // chỉ admin (accounts.is_publisher) được duyệt/từ chối
  let pendingCount = 0;    // tổng số kịch bản đang CHỜ DUYỆT (hiện trên nút "Chờ duyệt")
  let search = '';
  let platform = 'all';
  let sort = 'popular';    // popular | new | featured
  let priceFilter = 'all'; // all | free | paid  (combobox riêng)
  let pageNo = 1;          // trang hiện tại (phân trang lưới chợ)
  let pageSize = 24;       // số thẻ mỗi trang (đổi qua ô "Số dòng mỗi trang")
  let totalPages = 1;      // tổng số trang hiện tại (nút "sau" dựa vào đây)

  const grid = el('div.ext-grid');
  // Thanh phân trang DÙNG CHUNG mẫu với các trang khác của dự án (.pager): "Số dòng mỗi
  // trang:" + ô chọn cỡ trang + tổng "x-y trên z" + nút lùi + số trang + nút tiến. Tạo MỘT
  // LẦN rồi cập nhật tại chỗ (giống profiles.js) thay vì dựng lại mỗi lần vẽ.
  const pageNumbers = el('div.page-nums');
  const totalText = el('span.muted');
  const sizeSel = pageSizeSelect([12, 24, 48, 96], { value: pageSize, onChange: (v) => { pageSize = v; pageNo = 1; draw(); } });
  const prevBtn = el('button.icon-btn', { html: icon('chevron'), style: { transform: 'rotate(180deg)' },
    onclick: () => { if (pageNo > 1) { pageNo--; draw(); } } });
  const nextBtn = el('button.icon-btn', { html: icon('chevron'),
    onclick: () => { if (pageNo < totalPages) { pageNo++; draw(); } } });
  const pager = el('div.mkt-pager', {}, [
    el('div.pager', {}, [
      el('span.muted', { text: 'Số dòng mỗi trang:' }), sizeSel, totalText, prevBtn, pageNumbers, nextBtn,
    ]),
  ]);
  // Đổi bộ lọc/tìm kiếm/sắp xếp → về trang 1 rồi vẽ lại.
  function applyFilter() { pageNo = 1; draw(); }

  // ── data load ──────────────────────────────────────────────────────────────
  async function loadAll() {
    try {
      const r = (await window.vt?.market?.list()) || {};
      items = Array.isArray(r.items) ? r.items : [];
      owned = new Set(r.owned || []);
      canPublish = r.canPublish !== false;
      isAdmin = !!r.isAdmin;
      // Đếm số kịch bản chờ duyệt (chỉ admin mới gọi được /pending) để hiện trên nút.
      if (isAdmin) {
        try { const p = (await window.vt?.market?.pending()) || []; pendingCount = Array.isArray(p) ? p.length : 0; }
        catch { pendingCount = 0; }
      } else pendingCount = 0;
    } catch (e) { items = []; console.error('[market.list]', e && e.message); }
  }

  // ── list filtering/sorting ─────────────────────────────────────────────────
  function visibleItems() {
    let list = items.slice();
    if (platform !== 'all') list = list.filter((x) => (x.platform || 'other') === platform);
    if (priceFilter === 'free') list = list.filter((x) => !(Number(x.price) > 0));
    else if (priceFilter === 'paid') list = list.filter((x) => Number(x.price) > 0);
    if (search) {
      const q = search;
      list = list.filter((x) => `${x.title} ${x.description} ${x.author} ${platformLabel(x.platform)}`.toLowerCase().includes(q));
    }
    list.sort((a, b) => {
      if (sort === 'new') return (b.publishedAt || 0) - (a.publishedAt || 0);
      // popular / featured → theo lượt tải giảm dần
      return (b.downloads || 0) - (a.downloads || 0);
    });
    return list;
  }

  // ── actions ────────────────────────────────────────────────────────────────
  // Tải về: copy public → flow riêng của workspace. Kịch bản trả phí phải mua trước
  // (server chặn PURCHASE_REQUIRED → chuyển sang mua). Tăng downloads → reload nhẹ.
  async function doInstall(item, btn) {
    if (btn) { btn.disabled = true; btn.dataset.busy = '1'; }
    let res;
    try { res = await window.vt?.market?.install(item.id); }
    catch (e) { res = { ok: false, code: e && e.code, status: e && e.status }; }
    if (res && res.ok) {
      toast('Đã tải kịch bản vào "Quy trình" của workspace', 'ok');
      await loadAll(); draw();
    } else {
      if (res && res.code === 'PURCHASE_REQUIRED') { if (btn) { btn.disabled = false; delete btn.dataset.busy; } return doPurchase(item); }
      // Kịch bản chưa duyệt bị chặn cài về (403 NOT_APPROVED) - KHÔNG phải lỗi quyền hạn,
      // báo đúng bản chất thay vì "không có đủ quyền hạn".
      if (res && res.code === 'NOT_APPROVED') toast('Kịch bản chưa được duyệt nên chưa thể tải về. Hãy duyệt hoặc "Chạy thử" để kiểm tra.', 'err');
      else notifyError(res, 'Tải kịch bản thất bại');
      if (btn) { btn.disabled = false; delete btn.dataset.busy; }
    }
  }

  // Mua kịch bản trả phí. Luồng bảo mật: GIÁ luôn do SERVER lấy từ DB (client không quyết
  // định được), số dư ví do server kiểm trong TRANSACTION + khoá dòng (repo.purchase). Tiền
  // kiểm số dư ở client CHỈ để trải nghiệm (mở sớm modal nạp tiền) - server vẫn là chốt chặn.
  async function doPurchase(item) {
    const price = Math.max(0, Math.round(Number(item.price) || 0));
    // Đọc số dư ví hiện tại; thiếu → mở thẳng modal "Số dư không đủ" + nút Nạp tiền.
    let balance = 0;
    try { const w = await window.vt?.wallet?.get(); balance = Number(w && w.balance) || 0; }
    catch (e) { notifyError(e, 'Không đọc được số dư ví'); return; }
    if (balance < price) { showInsufficientModal(item, balance); return; }
    // Đủ tiền → xác nhận mua rồi mới gọi server.
    confirmDialog({
      title: 'Mua kịch bản',
      confirmLabel: 'Mua',
      message: tf('Mua "{0}" với giá {1}? Phí sẽ trừ vào ví của bạn.', item.title, feeLabel(item)),
      onConfirm: async () => {
        let res;
        try { res = await window.vt?.market?.purchase(item.id); }
        catch (e) { res = { ok: false, code: e && e.code, status: e && e.status, error: e && e.message }; }
        if (res && res.ok) {
          owned.add(item.id);
          toast('Mua thành công! Đang tải về...', 'ok');
          await doInstall(item);
        } else if (res && res.code === 'INSUFFICIENT_FUNDS') {
          // Số dư đổi giữa chừng (đua lệnh) → server báo thiếu: đọc lại số dư rồi mở modal nạp.
          let bal = 0;
          try { const w = await window.vt?.wallet?.get(); bal = Number(w && w.balance) || 0; } catch { /* giữ 0 */ }
          showInsufficientModal(item, bal);
        } else {
          notifyError(res, 'Mua kịch bản thất bại');
        }
      },
    });
  }

  // Modal "Số dư không đủ" - mẫu GIỐNG trang mua gói (upgrade.js): icon X động + 1 dòng
  // thông báo + nút "Nạp tiền" sang MÀN Nạp tiền (y trang Thủ tục thanh toán - chủ sở hữu 2026-10-29: không bật thẳng QR).
  function showInsufficientModal(item, balance) {
    const body = [
      el('div.ap-fail-anim', { html: '<svg class="ap-fail-svg" viewBox="0 0 52 52"><circle class="ap-fail-circle" cx="26" cy="26" r="24"/><path class="ap-fail-x" d="M18 18 L34 34 M34 18 L18 34"/></svg>' }),
      el('div.ap-fund-note.ap-fail-note', { text: tf('Số dư ví không đủ để mua "{0}". Bạn cần nạp thêm để tiếp tục.', item.title) }),
    ];
    const footer = [
      el('button.btn', { text: 'Để sau', onclick: closeModal }),
      el('button.btn.primary', { text: 'Nạp tiền', onclick: () => { closeModal(); ctx.navigate('topup'); } }),
    ];
    openModal({ title: 'Số dư không đủ', body, footer, width: 560 });
  }

  // Báo cáo kịch bản (nội bộ ghi nhận).
  function doReport(item) {
    confirmDialog({
      title: 'Báo cáo kịch bản',
      confirmLabel: 'Gửi báo cáo',
      message: tf('Báo cáo "{0}" vì nội dung không phù hợp hoặc lỗi? Đội ngũ sẽ xem xét.', item.title),
      onConfirm: () => toast('Đã gửi báo cáo. Cảm ơn bạn!', 'ok'),
    });
  }

  // onDone: callback tuỳ chọn gọi sau khi gỡ thành công (trang "Quản lý script" dùng để làm
  // mới lại danh sách "Đã duyệt").
  async function doRemove(item, onDone) {
    confirmDialog({
      title: 'Gỡ kịch bản', danger: true, confirmLabel: 'Gỡ',
      message: tf('Gỡ "{0}" khỏi chợ? Người dùng sẽ không còn thấy kịch bản này.', item.title),
      onConfirm: async () => {
        let res;
        try { res = await window.vt?.market?.remove(item.id); }
        catch (e) { res = { ok: false, code: e && e.code, status: e && e.status }; }
        if (res && res.ok) { toast('Đã gỡ kịch bản', 'ok'); closeModal(); await loadAll(); draw(); if (onDone) onDone(); }
        else notifyError(res, 'Gỡ kịch bản thất bại');
      },
    });
  }

  // ── publish dialog (chỉ publisher) ─────────────────────────────────────────
  // Nguồn graph = một flow sẵn có trong workspace của publisher (vt.flows.list).
  async function openPublishDialog(existing, onSaved) {
    // Cổng gói: "Đăng chợ kịch bản" là tính năng trả phí → gói Free hiện modal nâng cấp.
    if (!hasFeature('market_publish')) { gateFeature('market_publish', {}); return; }
    let flows = [];
    try { flows = (await window.vt?.flows?.list()) || []; } catch { flows = []; }

    const fTitle = el('input.inp', { value: (existing && existing.title) || '', placeholder: 'Tên kịch bản' });
    const fDesc = el('input.inp', { value: (existing && existing.description) || '', placeholder: 'Mô tả ngắn' });
    const fVersion = el('input.inp', { value: (existing && existing.version) || '1.0.0', placeholder: '1.0.0' });
    const fAuthor = el('input.inp', { value: (existing && existing.author) || '', placeholder: 'Tên người bán / nhóm' });
    const fPrice = el('input.inp', { type: 'number', min: '0', value: String((existing && existing.price) || 0) });
    // "Read Me" + "Changelog" = trình soạn thảo RICH TEXT (Quill snow) GIỐNG HỆT MKTLogin,
    // KHÔNG phải textarea trơn. readme/changelog lưu dưới dạng HTML. Nạp Quill từ vendor.
    let QuillCtor = null;
    try { QuillCtor = await ensureQuill(); }
    catch { return toast('Không tải được trình soạn thảo', 'err'); }
    const readmeHost = el('div.mkt-quill-host');
    const changelogHost = el('div.mkt-quill-host');
    let readmeQ = null, changelogQ = null;
    const RTE_TOOLBAR = [
      [{ header: [1, 2, 3, 4, 5, 6, false] }],
      ['bold', 'italic', 'underline', 'strike'],
      [{ color: [] }, { background: [] }],
      [{ list: 'ordered' }, { list: 'bullet' }],
      [{ indent: '-1' }, { indent: '+1' }],
      [{ script: 'super' }, { script: 'sub' }],
      ['code-block', 'blockquote'],
      [{ direction: 'rtl' }],
      [{ align: [] }],
      ['link', 'image', 'video'],
      ['formula'],
      ['clean'],
    ];
    const htmlOf = (q) => (q && !q.getText().trim() ? '' : (q ? q.root.innerHTML : ''));

    let platformVal = (existing && existing.platform) || 'other';
    const platSel = customSelect(PLATFORMS, { value: platformVal, width: 200, onChange: (v) => { platformVal = v; } });
    let billingVal = (existing && existing.billing) || 'free';
    const billSel = customSelect(
      [{ value: 'free', label: 'Miễn phí' }, { value: 'monthly', label: 'Trả phí (sở hữu vĩnh viễn)' }],
      { value: billingVal, width: 200, onChange: (v) => { billingVal = v; } });

    // Bộ chọn flow nguồn (chỉ khi tạo mới - sửa giữ nguyên graph cũ).
    let flowId = '';
    const flowOpts = [{ value: '', label: '- Chọn quy trình để đăng -' }].concat(
      flows.map((f) => ({ value: String(f.id), label: f.name || '(không tên)' })));
    const flowSel = customSelect(flowOpts, { value: '', width: 320, onChange: (v) => { flowId = v; } });

    const field = (label, node) => el('div.mkt-fld', {}, [el('label.mkt-lbl', { text: label }), node]);

    openModal({
      title: existing ? 'Sửa kịch bản trên chợ' : 'Đăng kịch bản lên chợ',
      width: 560,
      body: [el('div.mkt-form', {}, [
        field('Tên kịch bản', fTitle),
        field('Mô tả', fDesc),
        el('div.mkt-row2', {}, [field('Nền tảng', platSel), field('Phiên bản', fVersion)]),
        el('div.mkt-row2', {}, [field('Giá (VND, 0 = miễn phí)', fPrice), field('Hình thức', billSel)]),
        field('Người bán', fAuthor),
        existing ? el('div.muted', { text: 'Giữ nguyên quy trình gốc đã đăng.' }) : field('Quy trình nguồn', flowSel),
        field('Read Me', el('div.mkt-editor', {}, [readmeHost])),
        field('Changelog', el('div.mkt-editor', {}, [changelogHost])),
      ])],
      footer: [
        el('button.btn', { text: 'Hủy', onclick: closeModal }),
        el('button.btn.primary', { text: existing ? 'Lưu' : 'Đăng', onclick: async (e) => {
          const title = fTitle.value.trim();
          if (!title) return toast('Vui lòng nhập tên kịch bản', 'err');
          const payload = {
            title, description: fDesc.value.trim(), platform: platformVal,
            version: fVersion.value.trim() || '1.0.0', author: fAuthor.value.trim(),
            price: Math.max(0, Math.round(Number(fPrice.value) || 0)), billing: billingVal,
            readme: htmlOf(readmeQ), changelog: htmlOf(changelogQ),
          };
          if (!existing) {
            if (!flowId) return toast('Vui lòng chọn quy trình nguồn để đăng', 'err');
            let graph = null;
            try { graph = await window.vt?.flows?.get(flowId); } catch { graph = null; }
            if (!graph) return toast('Không đọc được quy trình đã chọn', 'err');
            payload.data = graph;
          }
          const btn = e.target; btn.disabled = true;
          let res;
          try {
            res = existing
              ? await window.vt?.market?.update(existing.id, payload)
              : await window.vt?.market?.publish(payload);
          } catch (err) { res = { ok: false, code: err && err.code, status: err && err.status }; }
          if (res && res.ok) {
            closeModal(); toast(existing ? 'Đã cập nhật, kịch bản chờ duyệt lại' : 'Đã gửi kịch bản, đang chờ quản trị viên duyệt', 'ok');
            await loadAll(); draw(); if (onSaved) onSaved();
          } else { btn.disabled = false; notifyError(res, existing ? 'Cập nhật thất bại' : 'Đăng kịch bản thất bại'); }
        } }),
      ],
    });

    // Khởi tạo Quill SAU khi host đã nằm trong DOM (thanh công cụ đúng thứ tự MKTLogin).
    const mkQuill = (host, ph) => new QuillCtor(host, {
      theme: 'snow', placeholder: ph, modules: { toolbar: RTE_TOOLBAR },
    });
    readmeQ = mkQuill(readmeHost, 'Hướng dẫn sử dụng (Read Me)...');
    changelogQ = mkQuill(changelogHost, 'Nhật ký thay đổi (Changelog)...');
    if (existing && existing.readme) readmeQ.root.innerHTML = existing.readme;
    if (existing && existing.changelog) changelogQ.root.innerHTML = existing.changelog;
  }

  // ── Chỉnh sửa quy trình của kịch bản đã đăng ────────────────────────────────
  // Mở trình sửa RPA (view "automation") với đồ thị của kịch bản trên Chợ. Khi lưu,
  // onSave ghi NGƯỢC toàn bộ metadata + đồ thị mới lên Chợ qua market.update - kịch bản
  // trở lại trạng thái "chờ duyệt". PHẢI gửi ĐỦ metadata (upsert server thay TOÀN BỘ cột)
  // để không xoá mất tiêu đề/mô tả/ảnh… khi chỉ đổi đồ thị.
  async function editMarketFlow(it) {
    let d = null;
    try { d = await window.vt?.market?.get(it.id); } catch { d = null; }
    const full = (d && d.item) || null;
    if (!full) { toast('Không đọc được kịch bản trên chợ', 'err'); return; }
    const graph = (full.data && typeof full.data === 'object') ? full.data : { nodes: [], connections: [], variables: [] };
    const nav = window.__vtApp && window.__vtApp.navigate;
    if (typeof nav !== 'function') return;
    nav('automation', { marketEdit: {
      name: full.title || 'Kịch bản',
      graph,
      onSave: async (newGraph) => {
        const payload = {
          title: full.title || '', description: full.description || '',
          platform: full.platform || 'other', version: full.version || '1.0.0',
          author: full.author || '', icon: full.icon || '',
          price: Math.max(0, Math.round(Number(full.price) || 0)),
          billing: full.billing || 'free', readme: full.readme || '', changelog: full.changelog || '',
          data: newGraph,
        };
        let res = null;
        try { res = await window.vt?.market?.update(full.id, payload); }
        catch (err) { res = { ok: false, code: err && err.code, status: err && err.status }; }
        if (res && res.ok) { toast('Đã cập nhật quy trình, kịch bản chờ duyệt lại', 'ok'); return true; }
        notifyError(res, 'Cập nhật quy trình thất bại');
        return false;
      },
    } });
  }

  // ── Chạy thử (admin xem trước khi duyệt) ────────────────────────────────────
  // Admin CHẠY THỬ 1 kịch bản đang chờ duyệt trên MỘT hồ sơ thật (trình duyệt mở +
  // thực thi) trước khi quyết định Duyệt/Từ chối. Không cần cài về: lấy graph đầy đủ
  // qua market.get rồi gọi rpa.run trực tiếp (giống "Gỡ lỗi" trong trình chỉnh sửa RPA).
  async function openTestRun(item) {
    let data = null;
    try { data = await window.vt?.market?.get(item.id); } catch { data = null; }
    const full = data && data.item;
    const graph = full && full.data;
    const realNodes = graph && Array.isArray(graph.nodes) ? graph.nodes.filter((n) => n.type !== 'start') : [];
    if (!realNodes.length) { toast('Kịch bản không có nội dung để chạy', 'err'); return; }

    // THAM SỐ ĐẦU VÀO: quy trình khai báo biến ở node "Bắt đầu" (graph.variables). Chạy thử
    // PHẢI cho admin điền các biến này (giống tab "Đầu vào" khi chạy quy trình đã tải) rồi
    // truyền vào graph.variables - nếu bỏ qua, kịch bản chạy với giá trị rỗng/mặc định, vô nghĩa.
    const vars = Array.isArray(graph.variables) ? graph.variables.map((v) => ({ ...v })) : [];
    // 1 ô nhập cho mỗi biến, theo kiểu dữ liệu (Boolean=switch, Number, Text/Array/Object=
    // textarea, còn lại=input). Giá trị ghi thẳng vào bản sao vars (không đụng graph gốc).
    const buildInputField = (v) => {
      const type = v.type || 'String';
      const cur = v.value != null ? v.value : '';
      const box = (inner, multi) => el('div.rpp-invar' + (multi ? '.is-multi' : ''), {}, [
        el('label.rpp-invar-label', { text: v.label || v.name }), inner,
      ]);
      if (type === 'Boolean') {
        const on = cur === true || cur === 'true' || cur === 1 || cur === '1';
        v.value = on;
        const sw = el('button.switch' + (on ? '.on' : ''), { type: 'button' }, [el('span.knob')]);
        sw.addEventListener('click', () => { const next = !sw.classList.contains('on'); sw.classList.toggle('on', next); v.value = next; });
        return box(el('div.rpp-invar-line', {}, [sw]));
      }
      if (type === 'Number') {
        const inp = el('input.rpp-invar-input', { type: 'number', value: cur, placeholder: v.desc || '' });
        inp.addEventListener('input', () => { v.value = inp.value; });
        return box(el('div.rpp-invar-line', {}, [inp]));
      }
      if (type === 'Array' || type === 'List' || type === 'Object' || type === 'Text') {
        const ta = el('textarea.rpp-invar-input.rpp-invar-area', { rows: '3', placeholder: v.desc || '' });
        ta.value = typeof cur === 'object' ? JSON.stringify(cur, null, 2) : String(cur == null ? '' : cur);
        ta.addEventListener('input', () => { v.value = ta.value; });
        return box(ta, true);
      }
      const inp = el('input.rpp-invar-input', { value: cur, placeholder: v.desc || '' });
      inp.addEventListener('input', () => { v.value = inp.value; });
      return box(el('div.rpp-invar-line', {}, [inp]));
    };
    const inputPanel = el('div.mkt-test-inputs');
    // CHỈ tham số đầu vào mới cần ô nhập. Biến làm việc (local: true) là biến nội bộ
    // của quy trình - vẫn giữ trong `vars` để truyền vào runGraph bên dưới với giá trị
    // mặc định, nhưng không phơi ra cho người chạy điền.
    const inputVars = vars.filter((v) => v && v.name && !v.local);
    if (!inputVars.length) inputPanel.appendChild(el('div.rpp-input-empty', { text: 'Kịch bản này không có tham số đầu vào.' }));
    else inputVars.forEach((v) => inputPanel.appendChild(buildInputField(v)));

    // Danh sách hồ sơ (remote trả envelope {ok,data}; local trả mảng) - chuẩn hoá.
    const asList = (r) => (Array.isArray(r) ? r : (r && Array.isArray(r.data) ? r.data : []));
    let profiles = [];
    try { profiles = asList(await window.vt?.remote?.profiles?.list(null)); } catch { profiles = []; }
    if (!profiles.length) { try { profiles = asList(await window.vt?.profiles?.list(null)); } catch { /* ignore */ } }

    let selectedId = profiles[0] ? String(profiles[0].id) : '';
    let running = false, runId = null, unsub = null;

    const logBox = el('div.mkt-test-log');
    const appendLog = (entry) => {
      const lvl = (entry && entry.level) || 'info';
      logBox.appendChild(el('div.mkt-test-logline.lvl-' + lvl, { text: (entry && entry.msg != null) ? String(entry.msg) : '' }));
      logBox.scrollTop = logBox.scrollHeight;
    };

    const profSel = customSelect(
      profiles.map((p) => ({ value: String(p.id), label: p.name || '-' })),
      { value: selectedId, placeholder: profiles.length ? 'Chọn hồ sơ để chạy' : 'Chưa có hồ sơ nào', width: '100%', onChange: (v) => { selectedId = v; } },
    );

    const runBtn = el('button.btn.primary', { text: 'Chạy thử', disabled: !profiles.length });
    const stopBtn = el('button.btn.danger', { text: 'Dừng', disabled: true });

    const cleanup = () => { if (unsub) { try { unsub(); } catch { /* ignore */ } unsub = null; } };
    const doStop = async () => { if (running && runId) { try { await window.vt?.rpa?.stop(runId); } catch { /* ignore */ } } };
    const doRun = async () => {
      if (running) return;
      if (!selectedId) { toast('Vui lòng chọn hồ sơ để chạy', 'err'); return; }
      running = true; runBtn.disabled = true; stopBtn.disabled = false;
      clear(logBox);
      runId = 'mktrun_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
      try { unsub = window.vt?.rpa?.onLog(runId, appendLog); } catch { /* ignore */ }
      const started = Date.now();
      // Gộp giá trị biến admin vừa nhập vào graph trước khi chạy (giống runConfigFlow).
      const runGraph = { ...graph, variables: vars.map((v) => ({ name: v.name, type: v.type || 'String', value: v.value != null ? v.value : '', desc: v.desc || '', local: v.local ? true : undefined })) };
      try {
        // debug: true → CHẠY THỬ, không đồng bộ dữ liệu hồ sơ lên/xuống đám mây.
        const res = await window.vt?.rpa?.run({ runId, profileId: selectedId, graph: runGraph, flowName: full.title || 'Chạy thử', flowId: 'mkt_preview', debug: true });
        if (res && res.ok) toast('Chạy thử hoàn tất', 'ok');
        else if (res && res.stopped) toast('Đã dừng chạy thử');
        else toast('Chạy thử thất bại: ' + ((res && res.error) || ''), 'err');
      } catch (e) {
        appendLog({ level: 'error', msg: 'Lỗi: ' + (e && e.message) });
        toast('Chạy thử thất bại', 'err');
      } finally {
        appendLog({ level: 'info', msg: tf('- Kết thúc sau {0}s -', ((Date.now() - started) / 1000).toFixed(1)) });
        cleanup();
        running = false; runBtn.disabled = !profiles.length; stopBtn.disabled = true; runId = null;
      }
    };
    runBtn.addEventListener('click', doRun);
    stopBtn.addEventListener('click', doStop);

    openModal({
      title: 'Chạy thử: ' + (full.title || '(không tên)'), width: 640,
      body: [
        el('div.mkt-test-seclbl', { html: `${icon('tabInput')}<span>Tham số đầu vào</span>` }),
        inputPanel,
        el('div.mkt-test-seclbl', { html: `${icon('user')}<span>Hồ sơ chạy</span>` }),
        el('div.mkt-test-row', {}, [el('div.mkt-test-prof', {}, [profSel]), runBtn, stopBtn]),
        el('div.mkt-test-hint.muted', { text: 'Trình duyệt của hồ sơ sẽ mở và chạy toàn bộ kịch bản với tham số ở trên. Theo dõi nhật ký bên dưới.' }),
        logBox,
      ],
      footer: [el('button.btn', { text: 'Đóng', onclick: async () => { await doStop(); cleanup(); closeModal(); } })],
    });
    // Bấm X hoặc nền tối cũng phải DỪNG run + gỡ listener (openModal gọi closeModal trực tiếp).
    const host = document.getElementById('modal-host');
    host.querySelectorAll('.scrim, .icon-btn.x').forEach((btn) => {
      btn.addEventListener('click', () => { doStop(); cleanup(); }, { capture: true });
    });
  }

  // ── Hồ sơ NHÀ PHÁT TRIỂN ────────────────────────────────────────────────────
  // Bấm tên nhà phát triển (ở thẻ hoặc màn chi tiết) → mở hồ sơ: thông tin + thống kê
  // THẬT (số kịch bản đã duyệt, tổng lượt tải, ngày tham gia) + danh sách kịch bản họ đăng.
  // Avatar nhà phát triển: ảnh nếu có, ngược lại chữ cái đầu (nền brand).
  const devAvatar = (dev) => (dev && dev.avatar
    ? el('div.mkt-devp-avatar.has-img', {}, [el('img.mkt-devp-avatar-img', { src: dev.avatar })])
    : el('div.mkt-devp-avatar', { text: initial(dev && dev.name) }));

  // Trang phủ toàn màn hiển thị THAY cho lưới chợ (không phải modal): dùng chung cho trang
  // NHÀ PHÁT TRIỂN và trang CHỜ DUYỆT. Giữ tham chiếu + tiêu đề để gỡ/khôi phục header.
  let overlayEl = null;
  let overlayTitle = '';
  // Trang phủ "bare" = KHÔNG đụng header app (#header-title vẫn là "Chợ"); trang tự vẽ link
  // "Quay lại chợ" bên trong nội dung (dùng cho trang Chi tiết - tránh tiêu đề dài tràn header).
  let overlayBare = false;
  // "Quay lại chợ" nằm TRÊN header app (#header-title) giống trình sửa quy trình: back
  // label + divider + tiêu đề. Lưu tiêu đề gốc để khôi phục khi rời trang phủ.
  const headerEl = () => document.getElementById('header-title');
  let savedHeaderText = null;
  // Nhãn nút back trên header app; mặc định "Quay lại chợ", trang Chi tiết dùng "Quay lại"
  // (giống trình sửa quy trình). Lưu lại để onShow gắn lại đúng nhãn.
  let overlayBackLabel = '';
  function setOverlayHeader(title, backLabel) {
    if (title != null) overlayTitle = title;
    if (backLabel !== undefined) overlayBackLabel = backLabel;
    const t = headerEl(); if (!t) return;
    if (savedHeaderText == null) savedHeaderText = t.textContent;
    t.classList.add('is-flow');
    t.innerHTML = '';
    t.appendChild(el('button.rpa-back', { html: `${icon('chevron')}<span>${overlayBackLabel || 'Quay lại chợ'}</span>`, onclick: closeOverlay }));
    t.appendChild(el('div.rpa-top-div'));
    t.appendChild(el('span.header-flow-title', { text: overlayTitle || 'Chợ' }));
  }
  function restoreMarketHeader() {
    const t = headerEl(); if (!t) return;
    t.classList.remove('is-flow');
    t.textContent = savedHeaderText != null ? savedHeaderText : 'Chợ';
    savedHeaderText = null;
  }
  function closeOverlay() {
    if (overlayEl) { overlayEl.remove(); overlayEl = null; }
    overlayTitle = '';
    if (!overlayBare) restoreMarketHeader();
    overlayBare = false;
    page.style.display = '';
  }
  // Gắn 1 trang phủ (đóng trang cũ nếu có), ẩn lưới chợ, đặt header back + tiêu đề.
  // opts.bare = true → KHÔNG chỉnh header app (trang tự lo back link).
  function mountOverlay(contentEl, title, opts = {}) {
    closeOverlay();
    page.style.display = 'none';
    overlayBare = !!opts.bare;
    overlayTitle = title || '';
    overlayBackLabel = opts.backLabel || '';
    if (!overlayBare) setOverlayHeader(title, overlayBackLabel);
    overlayEl = contentEl;
    ctx.container.appendChild(overlayEl);
  }

  async function openDeveloper(accountId) {
    if (!accountId) { toast('Kịch bản này chưa có thông tin nhà phát triển', 'err'); return; }
    let data = null;
    try { data = await window.vt?.market?.developer(accountId); } catch { data = null; }
    const dev = data && data.developer;
    if (!dev) { toast('Không tìm thấy nhà phát triển', 'err'); return; }
    const list = Array.isArray(data.items) ? data.items : [];

    // Có phải hồ sơ của CHÍNH mình? → cho nút "Chỉnh sửa hồ sơ".
    const me = (window.__vtApp && window.__vtApp.getAccount && window.__vtApp.getAccount()) || {};
    const isSelf = !!(me && me.id && me.id === dev.id);

    // PANEL PHẢI (75%): kịch bản đã đăng - DÙNG ĐÚNG lưới thẻ + phân trang GIỐNG trang chợ
    // (itemCard, .ext-grid, .ext-scroll, .mkt-pager), chỉ khác nằm trong panel.
    const devGrid = el('div.ext-grid');
    let dPageNo = 1, dPageSize = 24, dTotalPages = 1;
    const dPageNumbers = el('div.page-nums');
    const dTotalText = el('span.muted');
    const dSizeSel = pageSizeSelect([12, 24, 48, 96], { value: dPageSize, onChange: (v) => { dPageSize = v; dPageNo = 1; drawDev(); } });
    const dPrev = el('button.icon-btn', { html: icon('chevron'), style: { transform: 'rotate(180deg)' },
      onclick: () => { if (dPageNo > 1) { dPageNo--; drawDev(); } } });
    const dNext = el('button.icon-btn', { html: icon('chevron'),
      onclick: () => { if (dPageNo < dTotalPages) { dPageNo++; drawDev(); } } });
    const devPager = el('div.mkt-pager', {}, [
      el('div.pager', {}, [
        el('span.muted', { text: 'Số dòng mỗi trang:' }), dSizeSel, dTotalText, dPrev, dPageNumbers, dNext,
      ]),
    ]);
    function drawDevPager(total, pages, start) {
      dTotalPages = Math.max(1, pages);
      const from = total === 0 ? 0 : start + 1;
      const to = Math.min(start + dPageSize, total);
      dTotalText.textContent = tf('{0}-{1} trên {2}', from, to, total);
      clear(dPageNumbers);
      for (let i = 0; i < dTotalPages; i++) {
        if (dTotalPages > 7 && i > 1 && i < dTotalPages - 2 && Math.abs(i - (dPageNo - 1)) > 1) {
          if (i === 2 || i === dTotalPages - 3) dPageNumbers.appendChild(el('span.muted', { text: '…' }));
          continue;
        }
        dPageNumbers.appendChild(el('button.page-num' + (i === dPageNo - 1 ? '.active' : ''),
          { text: String(i + 1), onclick: () => { dPageNo = i + 1; drawDev(); } }));
      }
    }
    function drawDev() {
      clear(devGrid);
      if (!list.length) {
        devGrid.appendChild(el('div.placeholder-view', { style: { gridColumn: '1/-1' } }, [
          el('div.big', { html: noDataSvg || icon('search') }),
          el('div.muted', { text: 'Nhà phát triển này chưa có kịch bản nào được duyệt.' }),
        ]));
        drawDevPager(0, 1, 0); return;
      }
      const total = list.length;
      const pages = Math.max(1, Math.ceil(total / dPageSize));
      if (dPageNo > pages) dPageNo = pages;
      if (dPageNo < 1) dPageNo = 1;
      const start = (dPageNo - 1) * dPageSize;
      list.slice(start, start + dPageSize).forEach((it) => devGrid.appendChild(itemCard(it)));
      drawDevPager(total, pages, start);
    }
    drawDev();

    // PANEL TRÁI (25%): thông tin cá nhân (avatar, tên [cỡ chữ như cũ], ngày tham gia + thống kê).
    const editBtn = isSelf ? el('button.btn.sm.mkt-dev-edit', {
      text: 'Chỉnh sửa hồ sơ',
      onclick: async () => {
        let profile = null;
        try { profile = await window.vt?.market?.me(); } catch { profile = null; }
        const saved = await openDevProfileEditor(profile || { id: dev.id, name: dev.name, avatar: dev.avatar });
        if (saved) openDeveloper(accountId); // vẽ lại để thấy thông tin mới
      },
    }) : null;

    const leftPanel = el('div.mkt-dev-left', {}, [
      devAvatar(dev),
      el('div.mkt-devp-name', {}, [
        dev.name || 'Ẩn danh',
        verifiedBadge(),
      ]),
      el('div.mkt-devp-meta', { text: tf('Đã tham gia {0}', dev.joinedAt ? timeAgo(dev.joinedAt) : t('không rõ')) }),
      el('div.mkt-dev-stats', {}, [
        el('span.mkt-devp-stat', { html: `${icon('automation')}<span>${tf('{0} kịch bản', dev.scriptCount || 0)}</span>` }),
        el('span.mkt-devp-stat', { html: `${icon('download')}<span>${tf('{0} lượt tải', dev.totalDownloads || 0)}</span>` }),
      ]),
      editBtn,
    ]);

    const rightPanel = el('div.mkt-dev-right', {}, [
      el('div.ext-scroll', {}, [devGrid]),
      devPager,
    ]);

    // Gắn trang NPT (mountOverlay tự ẩn lưới chợ + đặt header back). "Quay lại chợ" đặt TRÊN
    // header app (không phải trong thân trang) - giống trình "Chỉnh sửa quy trình".
    mountOverlay(el('div.page.mkt-devpage', {}, [
      el('div.mkt-dev-body', {}, [leftPanel, rightPanel]),
    ]), dev.name || 'Nhà phát triển');
  }

  // ── Quản lý script (chỉ admin) ──────────────────────────────────────────────
  // Trang phủ THAY lưới chợ, có Segmented Control 2 tab:
  //   • "Chờ kiểm duyệt" (kèm badge tổng số) - duyệt/từ chối (đơn lẻ + hàng loạt).
  //   • "Đã duyệt" - chỉnh sửa hoặc gỡ kịch bản đã công khai.
  // Đóng gói mỗi tab thành 1 panel dựng SẴN rồi ẩn/hiện (giữ nguyên trạng thái tìm kiếm/chọn).
  async function openManageScripts(initialTab) {
    await loadAll();            // làm mới items (đã duyệt) + pendingCount + buildHead
    let pending = [];
    try { pending = (await window.vt?.market?.pending()) || []; } catch { pending = []; }
    let approved = items.slice();
    pendingCount = pending.length; buildHead();

    let tab = initialTab === 'approved' ? 'approved' : 'pending';

    // Nạp lại cả 2 nguồn dữ liệu + vẽ lại 2 panel + lưới chợ + badge (gọi sau mọi thay đổi).
    async function reload() {
      await loadAll();
      try { pending = (await window.vt?.market?.pending()) || []; } catch { pending = []; }
      approved = items.slice();
      pendingCount = pending.length; buildHead(); draw();
      paintPending(); paintApproved(); paintSeg();
    }

    // ══════════ PANEL 1: CHỜ KIỂM DUYỆT ══════════
    let q = '';                 // từ khoá tìm kiếm
    let filterBy = 'all';       // phạm vi lọc: all | title | author (chọn qua icon lọc phải)
    const FILT_OPTS = [
      { value: 'all', label: 'Tất cả' },
      { value: 'title', label: 'Tên kịch bản' },
      { value: 'author', label: 'Người viết' },
    ];
    const selected = new Set(); // id đã tick

    const listBox = el('div.mkt-mine-list.mkt-rv-list');
    const selectAll = el('input.mkt-rv-check', { type: 'checkbox' });
    const selInfo = el('span.muted.mkt-rv-selinfo');
    const bulkApproveBtn = el('button.btn.sm.primary', { text: 'Duyệt đã chọn', disabled: true });
    const bulkRejectBtn = el('button.btn.sm.danger', { text: 'Từ chối đã chọn', disabled: true });
    const headRow = el('div.mkt-rv-headrow', {}, [
      el('label.mkt-rv-cbcell', {}, [selectAll]),
      el('span.mkt-rv-headlbl', { text: 'Chọn tất cả' }),
    ]);

    const filtered = () => pending.filter((it) => {
      if (!q) return true;
      const title = String(it.title || '').toLowerCase();
      const author = String(it.author || '').toLowerCase();
      if (filterBy === 'title') return title.includes(q);
      if (filterBy === 'author') return author.includes(q);
      return `${title} ${author}`.includes(q);
    });

    // Gọi review lên server. Thành công → gỡ khỏi mảng pending (KHÔNG tự reload; nơi gọi tự
    // reload() 1 lần sau khi xong để đồng bộ cả tab "Đã duyệt"). Trả boolean.
    async function submitReview(item, status, reason) {
      let res;
      try { res = await window.vt?.market?.review(item.id, status, reason); }
      catch (e) { res = { ok: false, code: e && e.code, status: e && e.status, error: e && e.message }; }
      if (res && res.ok) {
        pending = pending.filter((x) => x.id !== item.id);
        selected.delete(item.id);
        pendingCount = pending.length;
        return true;
      }
      notifyError(res, 'Thao tác duyệt thất bại');
      return false;
    }

    function openReject(itemsArr) {
      const arr = itemsArr.filter(Boolean);
      if (!arr.length) return;
      const many = arr.length > 1;
      const reasonInp = el('textarea.input.mkt-reject-reason',
        { rows: '4', placeholder: 'Nhập lý do để nhà phát triển biết cần chỉnh sửa gì…' });
      const submitBtn = el('button.btn.solid-red', { text: 'Từ chối' });
      submitBtn.addEventListener('click', async () => {
        const reason = reasonInp.value.trim();
        if (!reason) { toast('Vui lòng nhập lý do từ chối', 'err'); reasonInp.focus(); return; }
        submitBtn.disabled = true;
        let ok = 0;
        for (const it of arr) { if (await submitReview(it, 'rejected', reason)) ok++; }
        closeModal();
        if (ok) toast(many ? tf('Đã từ chối {0} kịch bản', ok) : 'Đã từ chối kịch bản', 'ok');
        await reload();
      });
      openModal({
        title: many ? tf('Từ chối {0} kịch bản', arr.length) : 'Từ chối kịch bản', width: 520,
        body: [
          el('div.mkt-reject-name', { text: many ? tf('{0} kịch bản đã chọn', arr.length) : (arr[0].title || '(không tên)') }),
          el('label.dvp-lbl', { html: 'Lý do từ chối <span class="dvp-req">*</span>' }),
          reasonInp,
        ],
        footer: [
          el('button.btn', { text: 'Hủy', onclick: closeModal }),
          submitBtn,
        ],
      });
      setTimeout(() => { try { reasonInp.focus(); } catch { /* ignore */ } }, 30);
    }

    async function bulkApprove() {
      const arr = filtered().filter((it) => selected.has(it.id));
      if (!arr.length) { toast('Chưa chọn kịch bản nào', 'err'); return; }
      bulkApproveBtn.disabled = true;
      let ok = 0;
      for (const it of arr) { if (await submitReview(it, 'approved', '')) ok++; }
      if (ok) toast(tf('Đã duyệt {0} kịch bản', ok), 'ok');
      await reload();
    }
    function bulkReject() {
      const arr = filtered().filter((it) => selected.has(it.id));
      if (!arr.length) { toast('Chưa chọn kịch bản nào', 'err'); return; }
      openReject(arr);
    }

    function syncSel() {
      const rows = filtered();
      const chosen = rows.filter((it) => selected.has(it.id)).length;
      selectAll.checked = rows.length > 0 && chosen === rows.length;
      selInfo.textContent = chosen ? tf('Đã chọn {0}', chosen) : '';
      bulkApproveBtn.disabled = !chosen;
      bulkRejectBtn.disabled = !chosen;
      headRow.style.display = rows.length ? '' : 'none';
    }

    function paintPending() {
      clear(listBox);
      const rows = filtered();
      if (!rows.length) {
        listBox.appendChild(el('div.placeholder-view', {}, [
          el('div.big', { html: noDataSvg || icon('search') }),
          el('div.muted', { text: pending.length ? 'Không có kịch bản nào khớp tìm kiếm.' : 'Không có kịch bản nào đang chờ duyệt.' }),
        ]));
        syncSel();
        return;
      }
      rows.forEach((it) => {
        const cb = el('input.mkt-rv-check', { type: 'checkbox', checked: selected.has(it.id),
          onchange: (e) => { e.target.checked ? selected.add(it.id) : selected.delete(it.id); syncSel(); } });
        listBox.appendChild(el('div.mkt-mine-row.mkt-rv-row', {}, [
          el('label.mkt-rv-cbcell', {}, [cb]),
          fillIcon(el('div.mkt-mine-ico'), it),
          el('div.mkt-mine-main', {}, [
            el('div.mkt-mine-title', { text: it.title || '(không tên)' }),
            el('div.mkt-mine-sub', {}, [
              el('span.muted', { text: `${platformLabel(it.platform)} · ${feeLabel(it)} · ${tf('Người viết: {0}', it.author || 'Ẩn danh')} · ${tf('gửi {0}', timeAgo(it.publishedAt))}` }),
            ]),
            it.description ? el('div.mkt-mine-reason', { text: it.description }) : null,
          ]),
          el('div.mkt-mine-actions', {}, [
            el('button.btn.sm', { text: 'Xem', onclick: () => openDetail(it.id) }),
            el('button.btn.sm', { text: 'Chạy thử', onclick: () => openTestRun(it) }),
            el('button.btn.sm.primary', { text: 'Duyệt', onclick: async (e) => {
              const b = e.currentTarget; b.disabled = true;
              if (await submitReview(it, 'approved', '')) { toast('Đã duyệt kịch bản', 'ok'); await reload(); } else b.disabled = false;
            } }),
            el('button.btn.sm.danger', { text: 'Từ chối', onclick: () => openReject([it]) }),
          ]),
        ]));
      });
      syncSel();
    }

    selectAll.addEventListener('change', () => {
      const rows = filtered();
      if (selectAll.checked) rows.forEach((it) => selected.add(it.id));
      else rows.forEach((it) => selected.delete(it.id));
      paintPending();
    });
    bulkApproveBtn.addEventListener('click', bulkApprove);
    bulkRejectBtn.addEventListener('click', bulkReject);

    const filtBtn = el('button.icon-btn.scope-btn', { type: 'button', html: icon('filter'), title: 'Chọn phạm vi lọc' });
    const syncFiltBtn = () => filtBtn.classList.toggle('active', filterBy !== 'all');
    filtBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      openMenu(filtBtn, FILT_OPTS.map((o) => ({
        label: o.label,
        icon: filterBy === o.value ? 'check' : undefined,
        onClick: () => { filterBy = o.value; syncFiltBtn(); paintPending(); },
      })));
    });
    syncFiltBtn();
    const searchBar = el('div.searchbar.mkt-rv-search', {}, [
      el('span.ico', { html: icon('search') }),
      el('input.search-input', { placeholder: 'Tìm kiếm',
        oninput: (e) => { q = e.target.value.trim().toLowerCase(); paintPending(); } }),
      filtBtn,
    ]);
    const pendingToolbar = el('div.page-head.mkt-rv-toolbar', {}, [
      searchBar,
      el('span.spacer'),
      bulkApproveBtn,
      bulkRejectBtn,
      selInfo,
    ]);
    const pendingPanel = el('div.mkt-ms-panel', {}, [
      pendingToolbar,
      el('div.ext-scroll.mkt-rv-scroll', {}, [el('div.mkt-rv-box', {}, [headRow, listBox])]),
    ]);

    // ══════════ PANEL 2: ĐÃ DUYỆT ══════════
    let qa = '';
    const listBoxA = el('div.mkt-mine-list.mkt-rv-list');
    const filteredA = () => approved.filter((it) => {
      if (!qa) return true;
      return `${it.title || ''} ${it.author || ''}`.toLowerCase().includes(qa);
    });
    function paintApproved() {
      clear(listBoxA);
      const rows = filteredA();
      if (!rows.length) {
        listBoxA.appendChild(el('div.placeholder-view', {}, [
          el('div.big', { html: noDataSvg || icon('search') }),
          el('div.muted', { text: approved.length ? 'Không có kịch bản nào khớp tìm kiếm.' : 'Chưa có kịch bản nào được duyệt.' }),
        ]));
        return;
      }
      rows.forEach((it) => {
        listBoxA.appendChild(el('div.mkt-mine-row.mkt-rv-row', {}, [
          fillIcon(el('div.mkt-mine-ico'), it),
          el('div.mkt-mine-main', {}, [
            el('div.mkt-mine-title', { text: it.title || '(không tên)' }),
            el('div.mkt-mine-sub', {}, [
              el('span.muted', { text: `${platformLabel(it.platform)} · ${feeLabel(it)} · ${tf('Người viết: {0}', it.author || 'Ẩn danh')} · ${tf('{0} lượt tải', it.downloads || 0)}` }),
            ]),
            it.description ? el('div.mkt-mine-reason', { text: it.description }) : null,
          ]),
          el('div.mkt-mine-actions', {}, [
            el('button.btn.sm', { text: 'Xem', onclick: () => openDetail(it.id) }),
            el('button.btn.sm', { text: 'Sửa', onclick: async () => {
              let d = null; try { d = await window.vt?.market?.get(it.id); } catch { d = null; }
              openPublishDialog((d && d.item) || it, reload);
            } }),
            el('button.btn.sm.danger', { text: 'Xóa', onclick: () => doRemove(it, reload) }),
          ]),
        ]));
      });
    }
    const searchBarA = el('div.searchbar.mkt-rv-search', {}, [
      el('span.ico', { html: icon('search') }),
      el('input.search-input', { placeholder: 'Tìm kiếm',
        oninput: (e) => { qa = e.target.value.trim().toLowerCase(); paintApproved(); } }),
    ]);
    const approvedPanel = el('div.mkt-ms-panel', {}, [
      el('div.page-head.mkt-rv-toolbar', {}, [searchBarA]),
      el('div.ext-scroll.mkt-rv-scroll', {}, [el('div.mkt-rv-box', {}, [listBoxA])]),
    ]);

    // ══════════ Segmented Control + ghép panel ══════════
    const seg = el('div.seg.pc-seg.mkt-ms-seg');
    function showTab() {
      pendingPanel.style.display = tab === 'pending' ? '' : 'none';
      approvedPanel.style.display = tab === 'approved' ? '' : 'none';
    }
    function paintSeg() {
      clear(seg);
      const mk = (v, html) => el('button.seg-opt' + (tab === v ? '.active' : ''), {
        type: 'button', html, onclick: () => { if (tab === v) return; tab = v; showTab(); paintSeg(); },
      });
      seg.appendChild(mk('pending', `<span>Chờ kiểm duyệt</span><span class="mkt-ms-badge">${pendingCount}</span>`));
      seg.appendChild(mk('approved', '<span>Đã duyệt</span>'));
    }

    paintPending(); paintApproved(); paintSeg(); showTab();
    mountOverlay(el('div.page.mkt-ms-page', {}, [
      el('div.mkt-ms-head', {}, [seg]),
      el('div.mkt-ms-panels', {}, [pendingPanel, approvedPanel]),
    ]), 'Quản lý script');
  }

  // ── Kịch bản của tôi (MỌI người dùng) ───────────────────────────────────────
  // Trang phủ liệt kê kịch bản do CHÍNH mình đăng ở MỌI trạng thái (Chờ duyệt / Đã
  // duyệt / Bị từ chối) - để tác giả theo dõi + Sửa/Gỡ chính kịch bản của mình.
  // Sửa → server đưa về 'pending' để admin DUYỆT LẠI (chống tráo mã độc sau khi đã có
  // tem duyệt). Dòng bị từ chối kèm LÝ DO để tác giả biết đường sửa.
  async function openMyScripts() {
    let mine = [];
    try { mine = (await window.vt?.market?.mine()) || []; } catch { mine = []; }

    let tab = 'all';   // all | pending | approved | rejected
    let q = '';
    let mPageNo = 1, mPageSize = 24, mTotalPages = 1;
    const listBox = el('div.mkt-mine-list.mkt-rv-list.mkt-my-list');
    const countBy = (st) => mine.filter((x) => (x.status || 'pending') === st).length;
    const filtered = () => mine.filter((it) => {
      if (tab !== 'all' && (it.status || 'pending') !== tab) return false;
      if (!q) return true;
      return `${it.title || ''} ${platformLabel(it.platform)}`.toLowerCase().includes(q);
    });

    // Nạp lại danh sách của tôi + lưới chợ công khai (sau Sửa/Gỡ) rồi vẽ lại.
    async function reload() {
      try { mine = (await window.vt?.market?.mine()) || []; } catch { /* giữ nguyên */ }
      await loadAll(); draw();
      paint(); paintSeg();
    }

    function paint() {
      clear(listBox);
      const rows = filtered();
      if (!rows.length) {
        listBox.appendChild(el('div.placeholder-view', {}, [
          el('div.big', { html: noDataSvg || icon('search') }),
          el('div.muted', { text: mine.length ? 'Không có kịch bản nào khớp.' : 'Bạn chưa đăng kịch bản nào lên chợ.' }),
        ]));
        drawMinePager(0, 1, 0);
        return;
      }
      const total = rows.length;
      const pages = Math.max(1, Math.ceil(total / mPageSize));
      if (mPageNo > pages) mPageNo = pages;
      if (mPageNo < 1) mPageNo = 1;
      const start = (mPageNo - 1) * mPageSize;
      rows.slice(start, start + mPageSize).forEach((it) => {
        listBox.appendChild(el('div.mkt-mine-row.mkt-rv-row', {}, [
          fillIcon(el('div.mkt-mine-ico'), it),
          el('div.mkt-mine-main', {}, [
            el('div.mkt-mine-title', {}, [
              el('span', { text: it.title || '(không tên)' }),
              statusPill(it.status),
            ]),
            el('div.mkt-mine-sub', {}, [
              el('span.muted', { text: `${platformLabel(it.platform)} · ${feeLabel(it)} · ${tf('{0} lượt tải', it.downloads || 0)} · ${tf('cập nhật {0}', timeAgo(it.updatedAt || it.publishedAt))}` }),
            ]),
            (it.status === 'rejected' && it.rejectReason)
              ? el('div.mkt-mine-reason', { text: tf('Lý do bị từ chối: {0}', it.rejectReason) })
              : null,
          ]),
          (() => {
            // Gộp mọi thao tác vào 1 nút 3-chấm (kebab) mở dropdown khi hover/click -
            // gọn hàng, đồng bộ với datagrid hồ sơ.
            const kebab = el('button.icon-btn.kebab', { html: icon('moreVertical'), title: 'Thao tác' });
            hoverMenu(kebab, () => [
              { label: 'Xem', icon: 'eye', onClick: () => openDetail(it.id) },
              { label: 'Chạy thử', icon: 'play', onClick: () => openTestRun(it) },
              // Sửa: nạp bản ĐẦY ĐỦ (readme/changelog) qua market.get trước khi mở dialog.
              { label: 'Sửa', icon: 'edit', onClick: async () => {
                let d = null; try { d = await window.vt?.market?.get(it.id); } catch { d = null; }
                openPublishDialog((d && d.item) || it, reload);
              } },
              // Chỉnh sửa quy trình: mở trình sửa RPA với ĐỒ THỊ của kịch bản đã đăng.
              // Khi quy trình cần vá lỗi thì sửa đồ thị rồi lưu → cập nhật NGƯỢC lên Chợ
              // (giữ nguyên thông tin, chỉ thay đồ thị) → kịch bản quay lại "chờ duyệt".
              { label: 'Chỉnh sửa quy trình', icon: 'diagram', onClick: () => editMarketFlow(it) },
              '-',
              { label: 'Gỡ', icon: 'trash', danger: true, onClick: () => doRemove(it, reload) },
            ]);
            return el('div.mkt-mine-actions', {}, [kebab]);
          })(),
        ]));
      });
      drawMinePager(total, pages, start);
    }

    // Phân trang trang "Quy trình đã đăng" (tự chứa, mẫu như trang nhà phát triển).
    const mPageNumbers = el('div.page-nums');
    const mTotalText = el('span.muted');
    const mSizeSel = pageSizeSelect([12, 24, 48, 96], { value: mPageSize, onChange: (v) => { mPageSize = v; mPageNo = 1; paint(); } });
    const mPrev = el('button.icon-btn', { html: icon('chevron'), style: { transform: 'rotate(180deg)' },
      onclick: () => { if (mPageNo > 1) { mPageNo--; paint(); } } });
    const mNext = el('button.icon-btn', { html: icon('chevron'),
      onclick: () => { if (mPageNo < mTotalPages) { mPageNo++; paint(); } } });
    const minePager = el('div.mkt-pager', {}, [
      el('div.pager', {}, [
        el('span.muted', { text: 'Số dòng mỗi trang:' }), mSizeSel, mTotalText, mPrev, mPageNumbers, mNext,
      ]),
    ]);
    function drawMinePager(total, pages, start) {
      mTotalPages = Math.max(1, pages);
      const from = total === 0 ? 0 : start + 1;
      const to = Math.min(start + mPageSize, total);
      mTotalText.textContent = tf('{0}-{1} trên {2}', from, to, total);
      clear(mPageNumbers);
      for (let i = 0; i < mTotalPages; i++) {
        if (mTotalPages > 7 && i > 1 && i < mTotalPages - 2 && Math.abs(i - (mPageNo - 1)) > 1) {
          if (i === 2 || i === mTotalPages - 3) mPageNumbers.appendChild(el('span.muted', { text: '…' }));
          continue;
        }
        mPageNumbers.appendChild(el('button.page-num' + (i === mPageNo - 1 ? '.active' : ''),
          { text: String(i + 1), onclick: () => { mPageNo = i + 1; paint(); } }));
      }
    }

    const seg = el('div.seg.pc-seg.mkt-ms-seg');
    function paintSeg() {
      clear(seg);
      // Mỗi tab mang class ngữ cảnh .mkt-seg-<v> để tô màu nền/viền theo trạng thái khi active.
      const mk = (v, label, n) => el('button.seg-opt.mkt-seg-' + v + (tab === v ? '.active' : ''), {
        type: 'button',
        html: `<span>${label}</span><span class="mkt-ms-badge">${n}</span>`,
        onclick: () => { if (tab === v) return; tab = v; mPageNo = 1; paintSeg(); paint(); },
      });
      seg.appendChild(mk('all', 'Tất cả', mine.length));
      seg.appendChild(mk('pending', 'Chờ duyệt', countBy('pending')));
      seg.appendChild(mk('approved', 'Đã duyệt', countBy('approved')));
      seg.appendChild(mk('rejected', 'Bị từ chối', countBy('rejected')));
    }

    const searchBar = el('div.searchbar.mkt-rv-search', {}, [
      el('span.ico', { html: icon('search') }),
      el('input.search-input', { placeholder: 'Tìm kiếm',
        oninput: (e) => { q = e.target.value.trim().toLowerCase(); mPageNo = 1; paint(); } }),
    ]);

    paintSeg(); paint();
    // Bố cục: 1 hàng công cụ = ô tìm kiếm · Segmented Control NẰM SÁT bên cạnh · rồi danh sách.
    mountOverlay(el('div.page.mkt-ms-page', {}, [
      el('div.mkt-ms-panels', {}, [
        el('div.mkt-ms-panel', {}, [
          el('div.page-head.mkt-rv-toolbar', {}, [searchBar, seg]),
          el('div.ext-scroll.mkt-rv-scroll', {}, [el('div.mkt-rv-box', {}, [listBox])]),
          minePager,
        ]),
      ]),
    ]), 'Quy trình đã đăng');
  }

  // ── card (bố trí .ext-card như trang Tiện ích) ──────────────────────────────
  // Thẻ Chợ = bố trí ĐƠN GIẢN (kiểu AdsPower): icon + tên + pill danh mục (trái),
  // gem trả phí + 👥 lượt tải (phải), mô tả 2 dòng, dòng "Nhà phát triển". Bấm cả thẻ
  // → mở modal Chi tiết (mọi hành động tải/mua/báo cáo/sửa nằm trong đó, thẻ để trống).
  function itemCard(item) {
    const isOwned = owned.has(item.id);
    const paid = Number(item.price) > 0;
    const badge = isOwned
      ? el('span.mkt-gem.owned', { html: icon('check'), title: 'Đã sở hữu' })
      : (paid ? el('span.mkt-gem', { html: GEM_SVG, title: feeLabel(item) }) : null);

    return el('div.card.ext-card.mkt-card', { onclick: () => openDetail(item.id) }, [
      el('div.ext-head', {}, [
        fillIcon(el('div.ext-icon'), item),
        el('div.ext-meta', {}, [
          el('div.ext-name', { text: item.title || '(không tên)', title: item.title }),
          el('span.mkt-cat-pill', { text: platformLabel(item.platform) }),
        ]),
        el('div.mkt-card-right', {}, [badge]),
      ]),
      el('div.ext-desc.muted', { text: item.description || 'Chưa có mô tả.' }),
      // Chân thẻ (bottom): tên nhà phát triển bên trái + lượt xem/lượt tải bên phải.
      el('div.mkt-card-foot', {}, [
        el('div.mkt-dev', {}, [
          el('span', { text: 'Nhà phát triển: ' }),
          // Tên có thể bấm → mở hồ sơ nhà phát triển (chặn nổi bọt để không mở Chi tiết).
          item.publishedBy
            ? el('span.mkt-dev-name.link', { text: item.author || 'Ẩn danh',
                onclick: (e) => { e.stopPropagation(); openDeveloper(item.publishedBy); } })
            : el('span.mkt-dev-name', { text: item.author || 'Ẩn danh' }),
          verifiedBadge(),
        ]),
        el('div.mkt-stats', {}, [
          el('span.mkt-stat', { html: `${icon('eye')}<span>${item.views || 0}</span>`, title: 'Lượt xem' }),
          el('span.mkt-stat', { html: `${icon('download')}<span>${item.downloads || 0}</span>`, title: 'Lượt tải' }),
        ]),
      ]),
    ]);
  }

  // ── chi tiết = TRANG RIÊNG (overlay) thay cho modal (Read Me / Changelog +
  //    tải/mua/báo cáo/publisher). Bấm thẻ ở chợ → mở trang này, header có "Quay lại chợ".
  async function openDetail(id) {
    let data = null;
    try { data = await window.vt?.market?.get(id); } catch { data = null; }
    const item = data && data.item;
    if (!item) { toast('Không tìm thấy kịch bản', 'err'); return; }
    const isOwned = owned.has(item.id) || (data && data.owned);
    const paid = Number(item.price) > 0;
    // Kịch bản CHƯA DUYỆT (chờ duyệt/bị từ chối) chưa công khai → server chặn cài về. Chỉ
    // admin xem được (từ hàng đợi duyệt): thay "Tải về" bằng "Chạy thử" để kiểm tra.
    const approved = (item.status || 'approved') === 'approved';

    // Read Me / Changelog lưu dưới dạng HTML (Quill). Hiển thị trong khung ql-editor
    // (chỉ đọc) để render đúng định dạng - bao ql-snow để dùng theme styling của Quill.
    let tab = 'readme';
    const tabBody = el('div.mkt-dt-doc.ql-snow');
    const paint = () => {
      const html = tab === 'readme' ? item.readme : item.changelog;
      const empty = tab === 'readme' ? 'Chưa có hướng dẫn.' : 'Chưa có nhật ký thay đổi.';
      tabBody.innerHTML = (html && html.trim()) ? `<div class="ql-editor">${html}</div>` : `<div class="ql-editor muted">${empty}</div>`;
    };
    // Tab control giống màn "mở script đã tải từ chợ về" (rpp-tabs: gạch chân) - CHỈ nhãn,
    // không icon ở header tab.
    const tabBtns = {};
    const showDocTab = (tid) => {
      tab = tid;
      Object.entries(tabBtns).forEach(([k, b]) => b.classList.toggle('active', k === tid));
      paint();
    };
    const mkTab = (tid, label) => {
      const b = el('button.rpp-tab' + (tab === tid ? '.active' : ''), {
        type: 'button', html: `<span>${label}</span>`, onclick: () => showDocTab(tid),
      });
      tabBtns[tid] = b;
      return b;
    };

    // Nút luôn là "Tải về" (kịch bản trả phí vẫn trừ ví khi bấm, nhưng nhãn giữ gọn "Tải về").
    // Bấm "Tải về" → mở modal "Điều khoản sử dụng" (dùng chung với trang đăng nhập/đăng ký);
    // chỉ khi người dùng bấm "Đã hiểu" mới CHO tải/mua (onAccept).
    const dlBtn = approved
      ? el('button.btn.primary.mkt-dt-dl', { html: `${icon('download')}<span>Tải về</span>`,
          onclick: () => openLegalModal('Điều khoản sử dụng', TERMS_SECTIONS,
            () => (paid && !isOwned ? doPurchase(item) : doInstall(item, dlBtn))) })
      : el('button.btn.primary.mkt-dt-dl', { html: `${icon('playFill') || ''}<span>Chạy thử</span>`, onclick: () => openTestRun(item) });

    // Khối mua (góc trên phải): nút tải/chạy thử + nhãn giá. LUÔN hiện SỐ TIỀN (kể cả 0 VND),
    // KHÔNG hiện chữ "Miễn phí".
    const buyBox = el('div.mkt-dt-buy', {}, [
      dlBtn,
      el('div.mkt-dt-price' + (paid ? '' : '.free'), { text: `${fmtMoney(item.price)}₫` }),
      isOwned ? el('div.mkt-dt-owned', { text: 'Đã sở hữu' }) : null,
    ]);

    // Hành động phụ (Báo cáo + Sửa/Gỡ) - đặt trong cột thông tin người bán.
    // Sửa/Gỡ mở cho CHỦ SỞ HỮU (người đăng) hoặc admin - khớp guard server (assertOwnerOrAdmin).
    // Sửa → server tự đưa về 'pending' để admin DUYỆT LẠI (chống tráo mã độc sau khi đã có tem duyệt).
    const myId = (window.__vtApp && window.__vtApp.getAccount && window.__vtApp.getAccount().id) || null;
    const canEdit = isAdmin || !!(item.publishedBy && item.publishedBy === myId);
    const sideActions = [
      el('button.btn.sm.mkt-dt-sidebtn', { html: `${icon('warning')}<span>Báo cáo</span>`, onclick: () => doReport(item) }),
    ];
    if (canEdit) {
      sideActions.push(el('button.btn.sm.mkt-dt-sidebtn', { html: `${icon('edit')}<span>Sửa</span>`, onclick: () => openPublishDialog(item, () => closeOverlay()) }));
      sideActions.push(el('button.btn.sm.danger.mkt-dt-sidebtn', { html: `${icon('trash')}<span>Gỡ</span>`, onclick: () => doRemove(item, () => closeOverlay()) }));
    }

    // Thông tin người bán (fetch hồ sơ nhà phát triển để có thống kê thật; bỏ qua nếu lỗi).
    let dev = null;
    if (item.publishedBy) {
      try { dev = (await window.vt?.market?.developer(item.publishedBy))?.developer || null; } catch { dev = null; }
    }
    const sellerCard = el('div.mkt-dt-seller-card' + (item.publishedBy ? '.link' : ''),
      item.publishedBy ? { onclick: () => openDeveloper(item.publishedBy) } : {}, [
        devAvatar(dev || { name: item.author, avatar: item.authorAvatar }),
        el('div.mkt-dt-seller-mn', {}, [
          devName((dev && dev.name) || item.author || 'Ẩn danh'),
        ]),
      ]);
    const sideStats = el('div.mkt-dt-side-stats', {}, [
      el('span.mkt-dt-sstat', { html: `${icon('automation')}<span>${tf('{0} kịch bản', (dev && dev.scriptCount) || 0)}</span>` }),
      el('span.mkt-dt-sstat', { html: `${icon('download')}<span>${tf('{0} lượt tải', (dev && dev.totalDownloads) || item.downloads || 0)}</span>` }),
      el('span.mkt-dt-sstat', { html: `${icon('calendar')}<span>${tf('Tham gia {0}', dev && dev.joinedAt ? timeAgo(dev.joinedAt) : t('không rõ'))}</span>` }),
    ]);
    const sidebar = el('div.mkt-dt-side', {}, [
      el('div.mkt-dt-side-title', { text: 'Nhà phát triển' }),
      sellerCard,
      sideStats,
      el('div.mkt-dt-side-acts', {}, sideActions),
    ]);

    const content = el('div.page.mkt-dt-page', {}, [
      // Nút back "Quay lại" nằm TRÊN header app (#header-title), giống trình sửa quy trình.
      el('div.mkt-dt-scroll', {}, [
        el('div.mkt-dt-head', {}, [
          fillIcon(el('div.mkt-dt-ico'), item),
          el('div.mkt-dt-info', {}, [
            el('div.mkt-dt-title', { text: item.title }),
            el('div.mkt-dt-meta', {}, [
              el('span.mkt-dt-m', { html: `${icon('clock')}<span>${tf('Cập nhật {0}', timeAgo(item.updatedAt || item.publishedAt))}</span>` }),
              el('span.mkt-dt-m', { html: `${icon('eye')}<span>${item.views || 0}</span>` }),
              el('span.mkt-dt-m', { html: `${icon('download')}<span>${item.downloads || 0}</span>` }),
              el('span.mkt-cat-pill', { text: platformLabel(item.platform) }),
              !approved ? statusPill(item.status) : null,
            ]),
            el('div.mkt-dt-seller' + (item.publishedBy ? '.link' : ''),
              item.publishedBy ? { onclick: () => openDeveloper(item.publishedBy) } : {}, [
                // Avatar người bán: ảnh THẬT nếu đã tải lên (dev.avatar / authorAvatar), ngược lại chữ đầu.
                ((dev && dev.avatar) || item.authorAvatar)
                  ? el('span.mkt-avatar.has-img', {}, [el('img.mkt-avatar-img', { src: (dev && dev.avatar) || item.authorAvatar })])
                  : el('span.mkt-avatar', { text: initial((dev && dev.name) || item.author) }),
                el('span.mkt-dt-seller-name', { text: (dev && dev.name) || item.author || 'Ẩn danh' }),
              ]),
          ]),
          buyBox,
        ]),
        item.description ? el('div.mkt-dt-desc', { text: item.description }) : null,
        !approved ? el('div.mkt-dt-pending-note', {
          text: item.status === 'rejected'
            ? 'Kịch bản đã bị từ chối nên chưa công khai. Hãy "Chạy thử" để kiểm tra lại.'
            : 'Kịch bản đang chờ duyệt nên chưa thể tải về. Hãy "Chạy thử" để kiểm tra trước khi duyệt.',
        }) : null,
        el('div.mkt-dt-cols', {}, [
          el('div.mkt-dt-main', {}, [
            el('div.rpp-tabs.mkt-dt-tabs', {}, [mkTab('readme', 'Read Me'), mkTab('changelog', 'Changelog')]),
            tabBody,
          ]),
          sidebar,
        ]),
      ]),
    ]);
    mountOverlay(content, 'Thông tin quy trình', { backLabel: 'Quay lại' });
    paint();
  }

  // ── grid draw (kèm phân trang) ───────────────────────────────────────────────
  function draw() {
    clear(grid);
    const list = visibleItems();
    if (!list.length) {
      grid.appendChild(el('div.placeholder-view', { style: { gridColumn: '1/-1' } }, [
        el('div.big', { html: noDataSvg || icon('search') }),
        el('div.muted', { text: 'Chưa có kịch bản nào phù hợp.' }),
      ]));
      renderPager(0, 1, 0);
      return;
    }
    const total = list.length;
    const totalPages = Math.max(1, Math.ceil(total / pageSize));
    if (pageNo > totalPages) pageNo = totalPages;
    if (pageNo < 1) pageNo = 1;
    const start = (pageNo - 1) * pageSize;
    list.slice(start, start + pageSize).forEach((it) => grid.appendChild(itemCard(it)));
    renderPager(total, totalPages, start);
  }

  // Cập nhật thanh phân trang tại chỗ (LUÔN hiển thị đủ như các trang khác: tổng dòng + ô
  // cỡ trang + số trang). start = chỉ số thẻ đầu của trang hiện tại.
  function renderPager(total, pages, start) {
    totalPages = Math.max(1, pages);
    const from = total === 0 ? 0 : start + 1;
    const to = Math.min(start + pageSize, total);
    totalText.textContent = tf('{0}-{1} trên {2}', from, to, total);
    clear(pageNumbers);
    for (let i = 0; i < totalPages; i++) {
      if (totalPages > 7 && i > 1 && i < totalPages - 2 && Math.abs(i - (pageNo - 1)) > 1) {
        if (i === 2 || i === totalPages - 3) pageNumbers.appendChild(el('span.muted', { text: '…' }));
        continue;
      }
      pageNumbers.appendChild(el('button.page-num' + (i === pageNo - 1 ? '.active' : ''),
        { text: String(i + 1), onclick: () => { pageNo = i + 1; draw(); } }));
    }
  }

  // ── head bar (giống Tiện ích: [nút chính] [tìm kiếm] [bộ lọc bên trái]) ───────
  const searchBar = el('div.searchbar', {}, [
    el('span.ico', { html: icon('search') }),
    el('input.search-input', { placeholder: 'Tìm kiếm',
      oninput: (e) => { search = e.target.value.trim().toLowerCase(); applyFilter(); } }),
  ]);
  // Nền tảng = HÀNG CHIP bo tròn 20px (thay combobox). Tất Cả + các nền tảng.
  const chipsWrap = el('div.mkt-chips');
  function paintChips() {
    clear(chipsWrap);
    const chip = (value, label) => el('button.mkt-chip' + (platform === value ? '.active' : ''), { text: label,
      onclick: () => { platform = value; paintChips(); applyFilter(); } });
    chipsWrap.appendChild(chip('all', 'Tất Cả'));
    PLATFORMS.forEach((p) => chipsWrap.appendChild(chip(p.value, p.label)));
  }
  paintChips();
  const sortSel = customSelect(
    [{ value: 'popular', label: 'Phổ biến' }, { value: 'new', label: 'Mới nhất' },
      { value: 'featured', label: 'Gợi ý' }],
    { value: sort, width: 130, onChange: (v) => { sort = v; applyFilter(); } });
  // combobox RIÊNG lọc miễn phí / trả phí.
  const priceSel = customSelect(
    [{ value: 'all', label: 'Tất cả' }, { value: 'free', label: 'Miễn phí' },
      { value: 'paid', label: 'Trả phí' }],
    { value: priceFilter, width: 130, onChange: (v) => { priceFilter = v; applyFilter(); } });
  // Nút "Làm mới" = icon nền TRẮNG, viền + đổ bóng (boderbrush) - đặt NGAY SAU combobox "Tất cả".
  const refreshBtn = el('button.icon-btn.mkt-refresh', { html: icon('sync'), title: 'Làm mới',
    onclick: async () => { await loadAll(); buildHead(); draw(); } });

  const headBar = el('div.page-head.mkt-head-bar');
  function buildHead() {
    clear(headBar);
    if (isAdmin) headBar.appendChild(el('button.btn', { text: 'Quản lý script', onclick: () => openManageScripts() }));
    headBar.appendChild(searchBar);
    // combobox nằm SÁT bên phải ô tìm kiếm; refresh ngay sau combobox "Tất cả".
    headBar.appendChild(sortSel);
    headBar.appendChild(priceSel);
    headBar.appendChild(refreshBtn);
    headBar.appendChild(el('span.spacer'));
    // "Kịch bản của tôi" - MỌI người dùng: theo dõi + Sửa/Gỡ kịch bản do chính mình đăng.
    // Nút tô nền gradient 3 màu đặc trưng (.solid-blue) như các nút chính khác, đẩy sát mép phải.
    headBar.appendChild(el('button.btn.solid-blue', { text: 'Quy trình đã đăng', onclick: () => openMyScripts() }));
  }

  buildHead();
  const page = el('div.page.mkt-page', {}, [
    headBar,
    // hàng chip nền tảng XUỐNG DÒNG RIÊNG (không nằm chung với ô tìm kiếm).
    el('div.mkt-chipbar', {}, [chipsWrap]),
    // CHỈ lưới thẻ cuộn; thanh phân trang nằm NGOÀI vùng cuộn → panel CỐ ĐỊNH ở dưới cùng.
    el('div.ext-scroll', {}, [grid]),
    pager,
  ]);
  ctx.container.appendChild(page);

  (async () => { await loadAll(); buildHead(); draw(); })();

  return {
    onShow() {
      // Quay lại trang chợ khi đang mở trang phủ (NPT/Chờ duyệt) → app đã đặt lại tiêu đề
      // header 'Chợ', gắn lại back label + tiêu đề trang phủ để giữ đồng bộ.
      if (overlayEl && !overlayBare) { savedHeaderText = null; setOverlayHeader(overlayTitle); }
      (async () => { await loadAll(); buildHead(); draw(); })();
    },
    destroy() { restoreMarketHeader(); },
  };
}
