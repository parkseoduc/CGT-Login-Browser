// DÙNG CHUNG cho trang "Nâng cấp gói" (upgrade.js), "Thủ tục thanh toán" (checkout.js) và "Nạp tiền" (topup.js) -
// port từ web landing (public/fx.js + dashboard-upgrade.js) để app thanh toán GIỐNG HỆT web (chủ sở hữu 2026-10-29).
//
//   • Tỷ giá Vietcombank (mua chuyển khoản) lấy từ server app GET /fx. Làm tròn: VNĐ→USD LÊN tới cent (giá phải trả),
//     USD→VNĐ XUỐNG tới đồng (số được cộng) - y hệt server (modules/billing/fx-rate.js + intl-pay.js).
//   • 4 phương thức: Số dư / VietQR / PayPal / Thẻ ngân hàng (Dodo Payments). PayPal & thẻ: server app tạo đơn (số USD + phí do
//     SERVER tính), app mở trang cổng trong TRÌNH DUYỆT NGOÀI rồi hỏi server finalize đến khi tiền về. Renderer không bao
//     giờ tự khai "đã trả": server tự đọc lại đơn ở cổng bằng secret mới cộng ví.
import { el, openModal, closeModal, toast } from '../ui.js';
import { t, tf, getLang } from '../i18n.js';

export const fmtVnd = (n) => (Number(n) || 0).toLocaleString('vi-VN') + '₫';
const vt = () => window.vt;
const unwrap = (r) => (r && r.ok ? r.data : null);

// ── Tỷ giá ─────────────────────────────────────────────────────────────────────────────────────────────────
const FX = { rate: 0, quotedAt: null };
let fxPromise = null;
export function loadFx() {
  if (!fxPromise) {
    fxPromise = Promise.resolve(vt().fx && vt().fx.get ? vt().fx.get() : null).then((r) => {
      const d = unwrap(r);
      const v = d && Number(d.usdVnd);
      if (v > 10000 && v < 60000) { FX.rate = v; FX.quotedAt = d.quotedAt ? new Date(d.quotedAt) : null; }
      return FX;
    }).catch(() => FX);
    // Hết 10 phút thì lần sau gọi lại (giá VCB đổi vài lần/ngày).
    setTimeout(() => { fxPromise = null; }, 10 * 60 * 1000);
  }
  return fxPromise;
}
export const fx = {
  state: FX,
  show: () => FX.rate > 0,
  usdFirst: () => getLang() !== 'vi',
  up: (vnd, scale) => (FX.rate ? Math.max(0, Math.ceil(Math.round((Number(vnd) || 0) * scale) / FX.rate - 1e-9)) / scale : 0),
  toUsd: (vnd) => fx.up(vnd, 100),
  toUsdUnit: (vnd) => fx.up(vnd, 10000),
  toVnd: (usd) => (FX.rate ? Math.floor((Math.round((Number(usd) || 0) * 100) * FX.rate) / 100 + 1e-9) : 0),
  fmt: (usd) => {
    const x = Number(usd) || 0;
    const whole = Math.abs(x - Math.round(x)) < 1e-9;
    const max = x > 0 && x < 1 && Math.abs(x * 100 - Math.round(x * 100)) > 1e-6 ? 4 : 2;
    return '$' + x.toLocaleString('en-US', { minimumFractionDigits: whole ? 0 : 2, maximumFractionDigits: max });
  },
};
export const usdC = (c) => fx.fmt(c / 100);
export const usdOf = (n) => (fx.show() ? '≈ ' + fx.fmt(fx.toUsd(n)) : '');
export const withUsd = (n) => { const u = usdOf(n); return fmtVnd(n) + (u ? ' (' + u + ')' : ''); };
// Khối TỔNG: ngôn ngữ ≠ vi ⇒ USD to lên đầu, VNĐ phụ (VNĐ là số thật bị trừ nên không kèm "≈"); vi ⇒ VNĐ chính.
export function totalMoney(n) {
  const [a, b] = fx.show() && fx.usdFirst() ? [fx.fmt(fx.toUsd(n)), fmtVnd(n)] : [fmtVnd(n), fx.show() ? usdOf(n) : ''];
  return el('div.ap-money.ap-money-total', {}, [el('span.ap-total-amt', { text: a }), b ? el('span.ap-usd', { text: b }) : null]);
}
// Đơn giá 1 hồ sơ cạnh thanh kéo (4 số lẻ USD để nhân lên khớp tổng).
export function unitPrice(n) {
  if (!fx.show()) return { main: fmtVnd(n), alt: '' };
  const u = fx.fmt(fx.toUsdUnit(n)), v = fmtVnd(n);
  return fx.usdFirst() ? { main: u, alt: '≈ ' + v } : { main: v, alt: '≈ ' + u };
}

// ── Phương thức + phí ──────────────────────────────────────────────────────────────────────────────────────
const WALLET_ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20 7V5a2 2 0 0 0-2-2H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3v3a1 1 0 0 1-1 1H5a2 2 0 0 1-2-2V5"/><path d="M18 12v4"/></svg>';
export const PAY_METHODS = [
  { key: 'balance', name: 'Số dư', desc: 'Trừ thẳng vào số dư ví CGTBrowser bạn đang có.', ready: true, logo: '<span class="co-logo-wallet">' + WALLET_ICON + '</span>' },
  { key: 'vietqr', name: 'VietQR', desc: 'Chuyển khoản ngân hàng Việt Nam bằng mã QR. Tiền vào ví xong, bấm thanh toán để trừ ví.', ready: true, logo: '<img src="assets/pay/vietqr.svg" alt="VietQR">' },
  { key: 'paypal', gateway: 'paypal', name: 'PayPal', desc: 'Trả bằng USD qua tài khoản PayPal. Tiền về thành công được quy ra VNĐ theo tỷ giá Vietcombank lúc đó và cộng vào ví.', ready: false, logo: '<img src="assets/pay/paypal.svg" alt="PayPal">' },
  { key: 'card', gateway: 'dodo', name: 'Thẻ ngân hàng', desc: 'Trả bằng USD qua thẻ quốc tế Visa, Mastercard, JCB, American Express (cổng Dodo Payments). Tiền về thành công được quy ra VNĐ theo tỷ giá Vietcombank lúc đó và cộng vào ví.', ready: false, logo: '<img src="assets/pay/cards.webp" alt="Visa Mastercard">' },
];
export const PAY = { limits: { minVnd: 0, maxVnd: Infinity }, fees: null };
export async function loadPayConfig() {
  const d = unwrap(await Promise.resolve(vt().pay && vt().pay.config ? vt().pay.config() : null).catch(() => null));
  if (!d) return;
  PAY_METHODS.forEach((p) => { if (p.gateway) p.ready = !!d[p.gateway]; });
  PAY.limits = { minVnd: Number(d.minVnd) || 0, maxVnd: Number(d.maxVnd) || Infinity };
  if (d.fees && d.fees.paypal && d.fees.dodo) PAY.fees = d.fees;
}
// Báo giá cổng USD (cùng công thức server quoteFee): gốc = cents (nhập USD) hoặc toUsd(VNĐ); phí = ceil(gốc × % / 100).
export function intlQuote(gateway, amt) {
  const fees = PAY.fees && PAY.fees[gateway];
  if (!fees || !fx.show() || !amt) return null;
  const base = amt.cents != null ? amt.cents : Math.round(fx.toUsd(amt.vnd) * 100);
  let tier = fees.tiers[0];
  fees.tiers.forEach((x) => { if (Math.round(x.from * 100) <= base) tier = x; });
  const fee = Math.ceil((base * Math.round(tier.pct * 100)) / 10000 - 1e-9);
  return { base, fee, pct: tier.pct, total: base + fee };
}
export const intlLimitWarn = (vnd) => (vnd < PAY.limits.minVnd
  ? tf('Thanh toán quốc tế tối thiểu {0}', withUsd(PAY.limits.minVnd))
  : tf('Thanh toán quốc tế tối đa {0}', withUsd(PAY.limits.maxVnd)));
function feeNote(name, tiers) {
  const parts = tiers.map((x, i) => {
    const nx = tiers[i + 1], p = x.pct > 0;
    if (i === 0 && !nx) return p ? tf('mọi mức giá tính phí {0}%', x.pct) : t('mọi mức giá không tính thêm phí');
    if (i === 0) return p ? tf('giá dưới ${0} tính phí {1}%', nx.from, x.pct) : tf('giá dưới ${0} không tính thêm phí', nx.from);
    if (nx) return p ? tf('từ ${0} đến dưới ${1} tính phí {2}%', x.from, nx.from, x.pct) : tf('từ ${0} đến dưới ${1} không tính thêm phí', x.from, nx.from);
    return p ? tf('từ ${0} trở lên tính phí {1}%', x.from, x.pct) : tf('từ ${0} trở lên không tính thêm phí', x.from);
  });
  return tf('Với phương thức {0}, {1}.', name, parts.join(', '));
}

const CHECK_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4.5 12.5l5 5L19.5 7"/></svg>';
export const OK_ANIM = '<svg class="ap-success-svg" viewBox="0 0 52 52"><circle class="ap-success-circle" cx="26" cy="26" r="24"/><path class="ap-success-check" d="M14 27l7 7 16-16"/></svg>';
export const FAIL_ANIM = '<svg class="ap-fail-svg" viewBox="0 0 52 52"><circle class="ap-fail-circle" cx="26" cy="26" r="24"/><path class="ap-fail-x" d="M18 18 L34 34 M34 18 L18 34"/></svg>';

// Hàng ô phương thức: CHỈ logo (tên ở tooltip data-tip), riêng ô "Số dư" giữ chữ + số tiền (đỏ khi short > 0).
export function methodTiles(list, method, balance, short, onPick) {
  return el('div.co-methods' + (list.length === 3 ? '.co-methods-3' : ''), { role: 'radiogroup' }, list.map((p) => el('button.co-method' + (p.key === method ? '.active' : '') + (p.key === 'balance' ? '.co-method-wallet' : ''), {
    type: 'button', role: 'radio', 'aria-checked': p.key === method ? 'true' : 'false', 'aria-label': t(p.name),
    'data-tip': t(p.name) + (p.ready ? '' : ' - ' + t('Sắp ra mắt')),
    onclick: () => onPick(p.key),
  }, [
    p.ready ? null : el('span.co-soon', { text: 'Sắp ra mắt' }),
    p.key === method ? el('span.co-check', { html: CHECK_SVG }) : null,
    el('span.co-method-logo', { html: p.logo }),
    p.key === 'balance' ? el('span.co-method-txt', {}, [
      el('span.co-method-name', { text: p.name }),
      balance != null ? el('span.co-method-bal' + (short ? '.short' : ''), { text: fmtVnd(balance) }) : null,
    ]) : null,
  ])));
}
// Khung mô tả phương thức đang chọn: ghi chú phí CỦA ĐÚNG phương thức đó thay cho câu mô tả.
export function methodDetail(cur, warns) {
  const notes = [];
  if (cur.gateway && PAY.fees) {
    if (cur.gateway === 'paypal') notes.push(feeNote('PayPal', PAY.fees.paypal.tiers));
    else {
      if (PAY.fees.dodo.tiers.some((x) => x.pct > 0)) notes.push(feeNote(t('Thẻ ngân hàng'), PAY.fees.dodo.tiers));
      if (PAY.fees.dodo.vatPct > 0) notes.push(tf('Thanh toán bằng thẻ sẽ chịu thêm {0}% thuế VAT, được tính trên số tiền thanh toán ban đầu và tự động cộng vào tổng số tiền khi thanh toán.', PAY.fees.dodo.vatPct));
    }
  }
  return el('div.co-method-detail', {}, [
    el('div.co-method-detail-name', { text: cur.name }),
    ...(notes.length
      ? notes.map((x) => el('div.co-method-desc', {}, [el('b', { text: t('Ghi chú') + ': ' }), document.createTextNode(x)]))
      : [el('div.co-method-desc', { text: cur.desc })]),
    ...(warns || []).filter(Boolean).map((w) => el('div.co-method-warn', { text: w })),
  ]);
}

// ── Loại đơn của trang Thủ tục thanh toán ──
export const ORDER_KEY = 'polyCheckoutOrder';
export const PAY_KEY = 'polyPayMethod';
export function saveOrder(order) { try { localStorage.setItem(ORDER_KEY, JSON.stringify(order)); } catch { /* bỏ qua */ } }
export function readOrder() {
  try { const o = JSON.parse(localStorage.getItem(ORDER_KEY) || 'null'); if (o && (o.kind === 'plan' || o.kind === 'devices')) return o; } catch { /* bỏ qua */ }
  return { kind: 'plan' };
}

// ── Cổng USD từ APP: tạo đơn → mở trình duyệt ngoài → hỏi server đến khi tiền về ──────────────────────────────
// body = { provider, amountVnd | amountUsdCents }. onPaid(r) = { status, paidCents, creditVnd, creditRate, balance }.
export async function payViaGateway(body, onPaid) {
  const r = await vt().pay.create(body);
  if (!r || !r.ok || !r.data || !r.data.url) { toast((r && r.error) || 'Cổng thanh toán đang lỗi, vui lòng thử lại', 'err'); return; }
  const pid = r.data.id, url = r.data.url;
  const opened = await vt().pay.openUrl(url);
  if (!opened) { toast('Không mở được trang thanh toán', 'err'); return; }
  let stopped = false, timer = null;
  const started = Date.now();
  const MAX_MS = 20 * 60 * 1000, POLL_MS = 3000;
  const statusEl = el('div.ap-qr-status', {}, [el('span.ap-qr-spinner'), el('span.ap-qr-status-txt', { text: 'Đang chờ thanh toán…' })]);
  const stop = () => { stopped = true; if (timer) clearTimeout(timer); };
  openModal({
    title: 'Hoàn tất thanh toán trong trình duyệt',
    width: 560,
    body: [
      el('div.ap-fund-note', { text: 'Trang thanh toán đã mở trong trình duyệt. Sau khi bạn thanh toán xong, ứng dụng tự cập nhật ví - không cần thao tác thêm.' }),
      statusEl,
    ],
    footer: [
      el('button.btn', { text: 'Mở lại trang thanh toán', onclick: () => vt().pay.openUrl(url) }),
      el('button.btn', { text: 'Đóng', onclick: () => { stop(); closeModal(); } }),
    ],
  });
  const tick = async () => {
    if (stopped) return;
    // Khách đóng modal (nút X / bấm nền) ⇒ ngừng hỏi; tiền về sau vẫn được web landing (webhook + vòng quét) cộng.
    const host = document.getElementById('modal-host');
    if (!document.body.contains(statusEl) || !(host && host.classList.contains('open'))) { stop(); return; }
    if (Date.now() - started > MAX_MS) {
      stop();
      const s = statusEl.querySelector('.ap-qr-status-txt'); if (s) s.textContent = t('Đã dừng kiểm tra tự động. Nếu đã trả tiền, ví sẽ tự được cộng trong ít phút.');
      return;
    }
    const f = await vt().pay.finalize(pid).catch(() => null);
    const d = unwrap(f);
    if (stopped) return;
    if (d && d.status === 'completed') {
      stop(); closeModal();
      try { window.__vtApp && window.__vtApp.refreshWalletBalance && window.__vtApp.refreshWalletBalance(); } catch { /* bỏ qua */ }
      onPaid(d);
      return;
    }
    // Mọi trạng thái KẾT THÚC khác 'completed' (refunded / mismatch / failed / expired…) ⇒ báo chưa hoàn tất - y web gatewayReturn
    // (web: ngoài completed / paid / created / pending đều là chưa hoàn tất). Trước đây app bỏ sót 'expired' ⇒ hỏi tiếp tới 20 phút.
    if (d && d.status && !['completed', 'paid', 'created', 'pending'].includes(d.status)) {
      stop(); closeModal();
      openModal({
        title: 'Thanh toán chưa hoàn tất',
        width: 560,
        body: [el('div.ap-fail-anim', { html: FAIL_ANIM }), el('div.ap-fund-note.ap-fail-note', { text: tf('Giao dịch chưa được ghi nhận. Nếu bạn đã bị trừ tiền, hãy liên hệ hỗ trợ kèm mã {0}.', pid) })],
        footer: [el('button.btn.primary', { text: 'Đóng', onclick: closeModal })],
      });
      return;
    }
    if (d && d.status === 'paid') { const s = statusEl.querySelector('.ap-qr-status-txt'); if (s) s.textContent = t('Đã nhận thanh toán. Ví sẽ được cộng ngay khi có tỷ giá Vietcombank.'); }
    timer = setTimeout(tick, POLL_MS);
  };
  timer = setTimeout(tick, POLL_MS);
}
// Modal "Nạp tiền thành công" sau cổng USD (footer do nơi gọi quyết định).
export function showGatewaySuccess(d, footer) {
  openModal({
    title: 'Nạp tiền thành công',
    width: 560,
    body: [
      el('div.ap-success-anim', { html: OK_ANIM }),
      el('div.ap-fund-note.ap-success-note', { text: tf('Đã nhận {0}. Ví của bạn được cộng {1}.', '$' + (Number(d.paidCents) / 100).toFixed(2), fmtVnd(d.creditVnd)) }),
      el('div.ap-topup-breakdown', {}, [
        el('div.ap-topup-line', {}, [el('span', { text: t('Tỷ giá Vietcombank') }), el('b', { text: '1 USD = ' + fmtVnd(d.creditRate) })]),
        el('div.ap-topup-line.total', {}, [el('span', { text: t('Cộng vào ví') }), el('b', { text: fmtVnd(d.creditVnd) })]),
      ]),
    ],
    footer,
  });
}
