// "Chỉnh sửa nhiệm vụ" - the task-edit page reached from the Nhiệm vụ list's
// row kebab ("Chỉnh sửa"). A param-driven volatile route (navigate('task_edit',
// taskId)) that loads one task from the shared rpa-store (window.__rpaTasks) and
// lets the user edit it across four tabs - Thông tin / Đầu vào / Hồ sơ / Cấu
// hình chạy - mirroring MKTLogin's task editor. Saving writes back to the task
// object + saveTasks(); Hủy/Lưu both navigate back to the "tasks" list.
import { el, clear, toast, customSelect } from '../ui.js';
import { icon } from '../icons.js';
import { getTask, saveTask } from '../data/rpa-store.js';
import { remote } from '../data/remote-ds.js';
import { notifyError } from '../data/errors.js';
import { t } from '../i18n.js';

const vt = window.vt;

// Short numeric id shown next to the name ("#25892"): a stable 5-digit hash of
// the task id so the header matches MKTLogin's look without a real backend seq.
function shortNum(id) {
  let h = 0;
  const s = String(id || '');
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return String(10000 + (h % 90000));
}

const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
function headerDate(v) {
  const d = new Date(v);
  if (isNaN(d.getTime())) return '';
  const pad = (n) => String(n).padStart(2, '0');
  let h = d.getHours();
  const ap = h >= 12 ? 'PM' : 'AM';
  h = h % 12 || 12;
  return `${pad(d.getDate())} ${MON[d.getMonth()]} ${d.getFullYear()} ${pad(h)}:${pad(d.getMinutes())} ${ap}`;
}

const shortId = (p) => {
  const pid = p && (p.profileId || p.id) ? String(p.profileId || p.id) : '';
  return pid ? pid.slice(0, 8).toUpperCase() : '';
};

export function render(ctx) {
  const navigate = ctx.navigate;
  const task = getTask(ctx.param);

  const root = el('div.task-edit');
  ctx.container.appendChild(root);

  if (!task) {
    root.appendChild(el('div.te-missing', {}, [
      el('div.te-missing-icon', { html: icon('automation') }),
      el('div', { text: 'Không tìm thấy nhiệm vụ.' }),
      el('button.btn.primary', { text: 'Quay lại danh sách', onclick: () => navigate('tasks') }),
    ]));
    return {};
  }

  // Working copy - committed to the real task only on Lưu.
  const draft = {
    name: task.name || '',
    note: task.note || '',
    flowId: task.flowId || '',
    group: '',
    order: task.order === 'random' ? 'random' : 'ordered',
    ids: Array.isArray(task.profileIds) ? task.profileIds.slice() : [],
    inputs: { ...(task.inputs || {}) },
  };

  let flowsList = [];       // [{id,name,group}]
  let profilesList = [];    // full profile records (for chip names)
  const profById = new Map();
  const varsCache = {};

  // ---------------------------------------------------------------- app header
  // Reuse the flow editor's header pattern: the app title bar (#header-title)
  // becomes "‹ Quay lại | Chỉnh sửa nhiệm vụ" (same .rpa-back / .rpa-top-div /
  // .header-flow-title styling). Restored on destroy().
  const headerEl = () => document.getElementById('header-title');
  function setEditorHeader() {
    const t = headerEl(); if (!t) return;
    t.classList.add('is-flow');
    t.innerHTML = '';
    t.appendChild(el('button.rpa-back', { html: `${icon('chevron')}<span>Quay lại</span>`, onclick: () => navigate('tasks') }));
    t.appendChild(el('div.rpa-top-div'));
    t.appendChild(el('span.header-flow-title', { text: 'Chỉnh sửa nhiệm vụ' }));
  }

  // ---------------------------------------------------------------- header card
  const nameEl = el('span.te-name', { text: draft.name || '(không tên)' });
  const dateEl = el('span.te-date', { text: headerDate(task.createdAt) });
  const header = el('div.te-header', {}, [
    el('div.te-head-main', {}, [
      el('div.te-title-row', {}, [
        nameEl,
        el('span.te-id', { text: '#' + shortNum(task.id) }),
        el('span.badge.green.te-badge', { text: 'Nhiệm Vụ' }),
      ]),
      dateEl,
    ]),
  ]);

  // ---------------------------------------------------------------- tabs
  // Reuse the "Automation" (RPA Plus) modal's tab-body + row styling so the tab
  // CONTENT matches that dialog 1:1 (.rpp-modal / .rpp-tabpanel / formRow rows).
  const tabBody = el('div.rpp-tabbody');
  const panelInfo = el('div.rpp-tabpanel');
  const panelInput = el('div.rpp-tabpanel');
  const panelProf = el('div.rpp-tabpanel');
  const panelRun = el('div.rpp-tabpanel');

  const TABS = [
    ['info', 'Thông tin', 'tabInfo', panelInfo],
    ['input', 'Đầu vào', 'tabInput', panelInput],
    ['prof', 'Hồ sơ', 'tabProfile', panelProf],
    ['run', 'Cấu hình chạy', 'tabRun', panelRun],
  ];
  const tabBtns = {};
  const showTab = (key) => {
    TABS.forEach(([k, , , panel]) => {
      const on = k === key;
      tabBtns[k].classList.toggle('active', on);
      panel.style.display = on ? '' : 'none';
    });
  };
  const tabBar = el('div.rpp-tabs', {}, TABS.map(([k, label, ic]) => {
    const b = el('button.rpp-tab', { type: 'button', html: `${icon(ic)}<span>${label}</span>`, onclick: () => showTab(k) });
    tabBtns[k] = b;
    return b;
  }));
  TABS.forEach(([, , , panel]) => tabBody.appendChild(panel));

  // Left-label / right-control row identical to the Automation modal's formRow.
  function formRow(label, control, required) {
    return el('div.rpp-row', {}, [
      el('div.rpp-label', {}, [required ? el('span.req', { text: '*' }) : null, document.createTextNode(label)]),
      el('div.rpp-ctrlcol', {}, [control]),
    ]);
  }

  // ---------------------------------------------------------------- Thông tin
  const nameInput = el('input.input', { value: draft.name, maxlength: '64', placeholder: 'Tên nhiệm vụ' });
  nameInput.addEventListener('input', () => { draft.name = nameInput.value; nameEl.textContent = draft.name || '(không tên)'; });
  const noteInput = el('textarea.input.rpp-textarea', { rows: '4', placeholder: 'Ghi chú' });
  noteInput.value = draft.note;
  noteInput.addEventListener('input', () => { draft.note = noteInput.value; });
  panelInfo.appendChild(formRow('Tên nhiệm vụ', nameInput, true));
  panelInfo.appendChild(formRow('Ghi chú', noteInput));

  // ---------------------------------------------------------------- Đầu vào
  const switchBtn = (cur, on) => {
    const sw = el('button.switch' + (cur ? '.on' : ''), { type: 'button' }, [el('span.knob')]);
    sw.addEventListener('click', () => { const next = !sw.classList.contains('on'); sw.classList.toggle('on', next); on(next); });
    return sw;
  };
  function invarBox(name, inner, multi) {
    return el('div.rpp-invar' + (multi ? '.is-multi' : ''), {}, [
      el('label.rpp-invar-label', { text: name }), inner,
    ]);
  }
  function inputField(v) {
    const key = v.name;
    const disp = v.label || v.name;   // nhãn hiển thị thân thiện; key vẫn là tên biến sạch
    const t = v.type || 'String';
    const has = Object.prototype.hasOwnProperty.call(draft.inputs, key);
    const cur = has ? draft.inputs[key] : (v.value != null ? v.value : '');
    if (t === 'Boolean') {
      const on = cur === true || cur === 'true' || cur === 1 || cur === '1';
      draft.inputs[key] = on;
      return invarBox(disp, el('div.rpp-invar-line', {}, [switchBtn(on, (val) => { draft.inputs[key] = val; })]));
    }
    if (t === 'Number') {
      const inp = el('input.rpp-invar-input', { type: 'number', value: cur, placeholder: v.desc || '' });
      inp.addEventListener('input', () => { draft.inputs[key] = inp.value; });
      return invarBox(disp, el('div.rpp-invar-line', {}, [inp]));
    }
    if (t === 'Range') {
      const r = (cur && typeof cur === 'object') ? cur : { min: '', max: '' };
      draft.inputs[key] = r;
      const mkNum = (fld, ph) => {
        const i = el('input.rpp-invar-input', { type: 'number', value: r[fld] != null ? r[fld] : '', placeholder: ph });
        i.addEventListener('input', () => { r[fld] = i.value; });
        return i;
      };
      return invarBox(disp, el('div.rpp-invar-range', {}, [mkNum('min', 'Min'), el('span', { text: '-' }), mkNum('max', 'Max')]));
    }
    if (t === 'Array' || t === 'List' || t === 'Object' || t === 'Text') {
      const init = typeof cur === 'object' ? JSON.stringify(cur, null, 2) : String(cur == null ? '' : cur);
      const ta = el('textarea.rpp-invar-input.rpp-invar-area', { rows: '3', placeholder: v.desc || (t === 'Object' ? '{}' : t === 'Text' ? '' : '[]') });
      ta.value = init;
      ta.addEventListener('input', () => { draft.inputs[key] = ta.value; });
      return invarBox(disp, ta, true);
    }
    const inp = el('input.rpp-invar-input', { value: cur, placeholder: v.desc || '' });
    inp.addEventListener('input', () => { draft.inputs[key] = inp.value; });
    return invarBox(disp, el('div.rpp-invar-line', {}, [inp]));
  }
  async function loadVars(flowId) {
    if (!flowId) return [];
    if (varsCache[flowId]) return varsCache[flowId];
    let vars = [];
    try {
      const f = await vt.flows.get(flowId);
      const g = typeof f?.graph === 'string' ? JSON.parse(f.graph) : (f?.graph || {});
      // Bỏ biến làm việc (local: true) - đó là biến nội bộ để gán/tính toán trong
      // quy trình, không phải tham số người chạy phải điền. Biến cũ không có cờ
      // vẫn được coi là tham số đầu vào (giữ nguyên hành vi quy trình đã lưu).
      vars = Array.isArray(g.variables) ? g.variables.filter((v) => v && v.name && !v.local) : [];
    } catch { vars = []; }
    varsCache[flowId] = vars;
    return vars;
  }
  async function renderInput() {
    clear(panelInput);
    if (!draft.flowId) { panelInput.appendChild(el('div.rpp-input-empty', { text: 'Vui lòng chọn quy trình ở tab "Cấu hình chạy".' })); return; }
    const fid = draft.flowId;
    const vars = await loadVars(fid);
    if (fid !== draft.flowId) return;
    clear(panelInput);
    if (!vars.length) { panelInput.appendChild(el('div.rpp-input-empty', { text: 'Quy trình này không có tham số đầu vào.' })); return; }
    vars.forEach((v) => panelInput.appendChild(inputField(v)));
  }

  // ---------------------------------------------------------------- Hồ sơ
  const chipsWrap = el('div.rpp-chips');
  function renderChips() {
    clear(chipsWrap);
    if (!draft.ids.length) { chipsWrap.appendChild(el('div.rpp-input-empty', { text: 'Nhiệm vụ chưa có hồ sơ nào.' })); return; }
    draft.ids.forEach((id) => {
      const p = profById.get(id);
      const label = p ? shortId(p) : id;
      const title = p ? (p.name || '') : id;
      chipsWrap.appendChild(el('span.rpp-chip', { title }, [
        el('span', { text: label }),
        el('button', { html: icon('close'), title: 'Bỏ', onclick: () => { draft.ids = draft.ids.filter((x) => x !== id); renderChips(); syncCount(); } }),
      ]));
    });
  }
  const countBadge = el('span.rpp-suffix');
  const syncCount = () => { countBadge.textContent = `${draft.ids.length} ${t('hồ sơ')}`; };
  panelProf.appendChild(formRow('Hồ sơ', el('div.rpp-hosonum', {}, [countBadge, chipsWrap])));

  // ---------------------------------------------------------------- Cấu hình chạy
  const procWrap = el('div', { style: { flex: '1 1 0', minWidth: '0' } });
  const flowsInGroup = () => flowsList.filter((f) => !draft.group || (f.group || '') === draft.group);
  const buildProc = () => {
    clear(procWrap);
    const opts = flowsInGroup().map((f) => ({ value: f.id, label: f.name || '(không tên)' }));
    procWrap.appendChild(customSelect(opts, {
      value: draft.flowId, placeholder: 'Vui lòng chọn quy trình', height: 38, width: '100%',
      onChange: (v) => { draft.flowId = v; draft.inputs = {}; renderInput(); },
    }));
  };
  const radio = (name, val, label, cur, on) => {
    const input = el('input', { type: 'radio', name });
    if (cur === val) input.checked = true;
    input.addEventListener('change', () => { if (input.checked) on(val); });
    return el('label.radio', {}, [input, el('span', { text: label })]);
  };
  const orderRow = el('div.rpp-radios', {}, [
    radio('te-order', 'ordered', 'Đã đặt hàng', draft.order, (v) => { draft.order = v; }),
    radio('te-order', 'random', 'Ngẫu nhiên', draft.order, (v) => { draft.order = v; }),
  ]);
  let groupSel = el('div');
  const flowLine = el('div.rpp-inline');
  function buildGroupSel() {
    const groupOpts = [{ value: '', label: 'Tất cả' }];
    const seen = new Set();
    flowsList.forEach((f) => { const g = (f && f.group) || ''; if (g && !seen.has(g)) { seen.add(g); groupOpts.push({ value: g, label: g }); } });
    const sel = customSelect(groupOpts, {
      value: draft.group, width: 160, height: 38,
      onChange: (v) => { draft.group = v; draft.flowId = ''; draft.inputs = {}; buildProc(); renderInput(); },
    });
    clear(flowLine);
    flowLine.appendChild(sel);
    flowLine.appendChild(procWrap);
    groupSel = sel;
  }
  panelRun.appendChild(formRow('Quy trình', flowLine, true));
  panelRun.appendChild(formRow('Thứ tự thực hiện', orderRow));

  // ---------------------------------------------------------------- footer
  const footer = el('div.te-footer', {}, [
    el('button.btn.primary', { text: 'Lưu', onclick: save }),
    el('button.btn', { text: 'Hủy', onclick: () => navigate('tasks') }),
  ]);

  async function save() {
    if (save._busy) return;
    const name = draft.name.trim();
    if (!name) { toast('Vui lòng nhập tên nhiệm vụ', 'err'); showTab('info'); nameInput.focus(); return; }
    if (!draft.flowId) { toast('Vui lòng chọn quy trình', 'err'); showTab('run'); return; }
    if (!draft.ids.length) { toast('Nhiệm vụ cần ít nhất một hồ sơ', 'err'); showTab('prof'); return; }
    task.name = name;
    task.note = draft.note;
    task.flowId = draft.flowId;
    task.order = draft.order === 'random' ? 'random' : 'ordered';
    task.profileIds = draft.ids.slice();
    task.inputs = { ...draft.inputs };
    save._busy = true;
    try {
      await saveTask(task);
      toast('Đã lưu nhiệm vụ', 'ok');
      navigate('tasks');
    } catch (e) {
      notifyError(e, 'Lưu nhiệm vụ thất bại');
    } finally { save._busy = false; }
  }

  root.appendChild(header);
  root.appendChild(el('div.te-tabcard', {}, [el('div.rpp-form.rpp-modal', {}, [tabBar, tabBody])]));
  root.appendChild(footer);

  // ---------------------------------------------------------------- data load
  (async () => {
    try { const fl = await vt.flows.list(); flowsList = Array.isArray(fl) ? fl : []; } catch { flowsList = []; }
    try { const ps = await remote.profiles.list(); profilesList = Array.isArray(ps) ? ps : []; } catch { profilesList = []; }
    profilesList.forEach((p) => { if (p && p.id) profById.set(p.id, p); });
    buildGroupSel();
    buildProc();
    renderChips();
    syncCount();
    renderInput();
  })();

  setEditorHeader();
  showTab('info');
  return { destroy() { const t = headerEl(); if (t) t.classList.remove('is-flow'); } };
}
