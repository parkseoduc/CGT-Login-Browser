// Trang NÂNG CẤP GÓI - clone bố cục AdsPower Upgrade (UI-first, dữ liệu MẪU, chưa ráp IPC).
// Bố cục: cột trái (3 tab gói · slider số hồ sơ · giá/hồ sơ · thời gian hiệu lực · thành viên ·
// mã KM · bảng tính năng) + cột phải (tiền tệ · gói hiện tại · chi tiết gói · giá · Đặt mua).
// Mô hình giá: hồ sơ tính BẬC THANG LŨY TIẾN; thành viên 100k/người (1 admin miễn phí);
// thời hạn 90/180/360 ngày có chiết khấu 10/15/20%. Khi chốt UI xong sẽ ráp dữ liệu thật.
import { el, clear, toast, openModal, closeModal } from '../ui.js';
import { icon } from '../icons.js';
import { remote } from '../data/remote-ds.js';
import { t, tf } from '../i18n.js';
import { loadFx, usdOf, totalMoney, unitPrice, saveOrder, fx } from './pay-common.js';

// Mã giảm giá đã nhập { code, sig } - đọc lại ở views/checkout.js. Lưu ở sessionStorage (user 2026-11-07: "không phải nhập 1 lần hợp lệ là lưu
// mãi, mỗi lần tắt bật app tự reset") ⇒ còn trong lúc app mở (đi nạp tiền rồi quay lại vẫn còn), đóng app là mất; đăng xuất cũng xoá
// (app.js showLogin). Bản app cũ lưu localStorage ⇒ xoá một lần khi nạp module.
const COUPON_KEY = 'polyCheckoutCoupon';
try { localStorage.removeItem(COUPON_KEY); } catch { /* bỏ qua */ }

const fmtVnd = (n) => (Number(n) || 0).toLocaleString('vi-VN') + '₫';
const iso = (d) => d.toISOString().slice(0, 10);

// ── Dữ liệu mẫu (mô phỏng AdsPower) ──────────────────────────────────────────
// Đã bao gồm trong gói hiện tại (Free): 2 hồ sơ + 1 quản trị viên.
const OWNED_PROFILES = 2;
const OWNED_MEMBERS = 1;

// Thuê bao HIỆN TẠI (MẪU - sẽ ráp dữ liệu thật qua IPC billing sau).
//   plan        : 'free' | 'professional' | 'business' | 'enterprise'
//   daysLeft    : số ngày CÒN LẠI của kỳ hiện tại (0 = free hoặc đã hết hạn)
//   profilesOwned: số hồ sơ ĐÃ mua trong gói (mốc để tính CHÊNH LỆCH khi nâng cấp)
const CURRENT_SUB = {
  plan: 'free',
  planName: 'Phiên bản miễn phí',
  daysLeft: 0,
  profilesOwned: 0,
  membersOwned: OWNED_MEMBERS,   // số thành viên gói hiện tại (thật, đọc từ server)
  // Số hồ sơ / thành viên của thuê bao (quota_profiles / quota_members) - ĐÚNG số server dùng khi tính tiền
  // GIA HẠN lúc còn hạn (billing.repo.js). Chỉ có nghĩa khi còn hạn.
  quotaProfiles: 0,
  quotaMembers: 1,
  periodEnd: null,               // ISO hạn kỳ (null = vô hạn / chưa có gói)
  expiryText: '-',               // ngày hết hạn hiển thị ở border "Gói hiện tại"
};
// Đang còn hạn thuê bao trả phí → chế độ "Nâng cấp" (tính chênh lệch cho ngày còn lại);
// ngược lại (free/đã hết hạn) → chế độ "Mua gói" (mua kỳ mới đầy đủ).
const subIsActive = () => CURRENT_SUB.plan !== 'free' && CURRENT_SUB.daysLeft > 0;

// ── GÓI CỐ ĐỊNH (2026-11-12, bỏ thanh kéo chọn số hồ sơ) ─────────────────────────────────────────────
// Mỗi gói có SỐ HỒ SƠ + GIÁ THÁNG do web admin đặt (vt.billing.pricingConfig). KHÔNG ghi cứng số nào (chủ sở hữu 2026-11-12):
// tên/số hồ sơ/giá để trống tới khi applyPricingConfig() nạp bảng giá thật. Server tính lại tiền theo cùng config nên khớp
// từng đồng (upgrade-pricing.computeCost). Y web landing dashboard-upgrade.js.
const TABS = [
  { key: 'professional', name: '', desc: 'Mở khóa tất cả tính năng trả phí', profiles: 0, price: 0 },
  { key: 'business', name: '', desc: 'Hỗ trợ riêng cho việc di chuyển dữ liệu', profiles: 0, price: 0 },
  { key: 'enterprise', name: '', desc: 'Dịch vụ chăm sóc khách hàng riêng và hỗ trợ phát triển tính năng tùy chỉnh', profiles: 0, price: 0 },
];
// Đã nạp bảng giá web admin chưa. Chưa ⇒ trang hiện "Đang tải bảng giá…" thay vì tính tiền (KHÔNG có số mặc định nào).
let PRICING_READY = false;
let FREE_REFUND = true;      // gói Free có hoàn lượt tạo khi xoá vĩnh viễn (badge trên thẻ Miễn phí) - cfg.freeRefund
let PLAN_DEVICES = {};
let PLAN_LIMITS = {};        // limit tạo/mở mỗi ngày theo khoá gói (cfg.planLimits: {create, open}, 0 = vô hạn)
// Gói VĨNH VIỄN (cfg.lifetime, chỉ có khi admin BẬT bán): {name, profiles, price, realFp, fpCount}. null = không bán ⇒ không có tab.
let LIFETIME = null;
const LIFE_KEY = 'lifetime';
// Gói theo khoá kể cả vĩnh viễn (tabKey 'lifetime'); costFor/checkout dùng chung.
const pkgOrLife = (key) => (key === LIFE_KEY && LIFETIME ? { key: LIFE_KEY, name: LIFETIME.name, profiles: LIFETIME.profiles, price: LIFETIME.price, realFp: LIFETIME.realFp, fpCount: LIFETIME.fpCount, lifetime: true } : pkgOf(key));       // số máy mỗi gói theo plans.code (cfg.planDevices, admin đặt ở web admin → Quản lý thiết bị)
let FREE_PROFILES = 0;       // số hồ sơ gói Free (dòng đầu thẻ Miễn phí) - plans.default_profiles
const pkgOf = (key) => TABS.find((t) => t.key === key) || TABS[0];
// Gói nhỏ nhất chứa được q hồ sơ (vượt gói lớn nhất → gói lớn nhất) - khớp packageFor phía server.
const tierFor = (q) => (TABS.find((t) => t.profiles >= q) || TABS[TABS.length - 1]).key;
let MEMBER_UNIT = 0;   // Thành viên nhóm: 35.000đ/người, KHÔNG giảm giá.

let VALIDITY = [];

// GHI ĐÈ số hồ sơ + giá từng gói, giá thành viên, chiết khấu thời hạn từ BẢNG GIÁ THẬT. Cấu trúc hỏng -> giữ mặc định.
function applyPricingConfig(cfg) {
  if (!cfg || !Array.isArray(cfg.plans) || !cfg.plans.length || !Array.isArray(cfg.validity)) return false;
  for (const p of cfg.plans) {
    const tb = TABS.find((t) => t.key === p.key);
    if (tb && Number(p.profiles) > 0) {
      tb.profiles = Math.round(Number(p.profiles));
      tb.price = Math.max(0, Math.round(Number(p.price) || 0));
      if (p.name) tb.name = String(p.name);
      tb.realFp = p.realFp === true;
      tb.fpCount = Math.max(0, Math.round(Number(p.fpCount) || 0));
    }
  }
  // Gói không có trong bảng giá admin ⇒ bỏ khỏi trang (không hiện gói giá 0).
  for (let i = TABS.length - 1; i >= 0; i--) if (!(TABS[i].profiles > 0)) TABS.splice(i, 1);
  // KHÔNG sắp theo số hồ sơ: giữ thứ tự Solo → Team → Company như admin (2026-11-12).
  MEMBER_UNIT = Math.max(0, Math.round(Number(cfg.memberUnit) || 0));
  VALIDITY = cfg.validity.map((v) => ({ days: Math.max(1, Math.round(Number(v.days) || 30)), disc: Math.max(0, Math.min(90, Number(v.d) || 0)) / 100 }));
  if (!TABS.length || !VALIDITY.length) return false;
  FREE_REFUND = cfg.freeRefund !== false;
  PLAN_DEVICES = cfg.planDevices && typeof cfg.planDevices === 'object' ? cfg.planDevices : {};
  PLAN_LIMITS = cfg.planLimits && typeof cfg.planLimits === 'object' ? cfg.planLimits : {};
  const lt = cfg.lifetime;
  LIFETIME = lt && lt.enabled && Number(lt.profiles) > 0
    ? { name: String(lt.name || 'Vĩnh viễn'), profiles: Math.round(Number(lt.profiles)), price: Math.max(0, Math.round(Number(lt.price) || 0)), realFp: lt.realFp === true, fpCount: Math.max(0, Math.round(Number(lt.fpCount) || 0)) }
    : null;
  PRICING_READY = true;
  return true;
}
// Lý do đơn gói không hợp lệ (cùng mã + câu với server billing.routes PLAN_ERRORS). checkout.js dùng lại.
export const PLAN_INVALID_MSG = {
  DOWNGRADE_ACTIVE: 'Gói hiện tại còn hạn và có nhiều hồ sơ hơn gói này. Bạn chỉ đổi sang gói nhỏ hơn khi gói hiện tại hết hạn.',
  NOTHING_TO_BUY: 'Bạn đang dùng gói này. Hãy chọn thời hạn gia hạn, thêm thành viên hoặc chọn gói lớn hơn.',
  LIFETIME_ACTIVE: 'Tài khoản đang dùng gói vĩnh viễn nên không cần mua thêm gói tháng.',
};

// Tiền của lựa chọn gói (state = {tabKey, members, validity}) - CÙNG công thức server (upgrade-pricing.computeCost). Trang
// "Thủ tục thanh toán" (checkout.js) gọi lại đúng hàm này để số tiền khớp từng đồng với trang gói.
//   • Mua mới: round(giá gói × (1 - chiết khấu)) × số tháng + thành viên.
//   • Còn hạn: phần hồ sơ THÊM (gói lớn hơn số đang có) tính theo tỷ lệ giá gói cho số ngày còn lại; chọn thời hạn ⇒
//     gia hạn trọn gói như mua một kỳ mới + thành viên đã có (trừ 1 quản trị). Gói nhỏ hơn số đang có ⇒ không hợp lệ.
export function costFor(state) {
  const pk = pkgOrLife(state.tabKey);
  const isLife = !!pk.lifetime;   // vĩnh viễn: trả một lần, không kỳ hạn/chiết khấu; đang có gói tháng ⇒ đổi hẳn sang vĩnh viễn
  const P = pk.profiles;
  const pTotal = pk.price;                            // giá gói/tháng
  const mTotal = state.members * MEMBER_UNIT;         // Thành viên: ĐỒNG GIÁ, tính RIÊNG
  // validity < 0 → "Không gia hạn" (0 ngày, không giảm) - chỉ khi đang còn hạn.
  // VALIDITY[i] lạ (lựa chọn cũ ngoài phạm vi sau khi admin đổi bảng kỳ hạn) ⇒ về kỳ đầu, không vỡ trang.
  const v = state.validity < 0 || isLife ? { days: 0, disc: 0 } : (VALIDITY[state.validity] || VALIDITY[0]);
  const discounted = Math.round(pTotal * (1 - v.disc));
  const months = Math.max(1, Math.round(v.days / 30)); // 30/90/180/360 → 1/3/6/12 tháng
  const monthly = pTotal;
  const total = discounted * months + mTotal;

  const upgrade = subIsActive() && !isLife;
  let payNow = total;
  let prorateDays = v.days;
  let profileCharge = pTotal;
  let memberCharge = mTotal;
  let addProfiles = P, invalid = null;
  let remainCharge = 0, extendCharge = 0, extendProfiles = 0, extendMembers = 0, extendMemberCharge = 0, extendMonthly = 0;
  let curPrice = 0, upDays = 0;
  if (upgrade) {
    const cur = CURRENT_SUB.quotaProfiles;
    const remain = CURRENT_SUB.daysLeft;
    if (P < cur) invalid = 'DOWNGRADE_ACTIVE';
    addProfiles = Math.max(0, P - cur);
    if (addProfiles > 0) {
      // NÂNG CẤP lên gói lớn hơn (kiểu Claude, y server upgrade-pricing.js): chỉ trả CHÊNH LỆCH giá tháng (gói mới − gói đang
      // dùng) × ngày còn lại / 30; hạn giữ nguyên; kỳ hạn đang chọn bị bỏ qua. Gói đang dùng = gói có đúng số hồ sơ đang có.
      const curPk = TABS.find((x) => x.profiles === cur);
      curPrice = curPk ? curPk.price : Math.round(pTotal * cur / P);
      upDays = remain;
      remainCharge = Math.round(Math.max(0, pTotal - curPrice) * remain / 30);
    } else if (v.days > 0) {
      // CÙNG gói + kỳ hạn = GIA HẠN trọn kỳ; thành viên đang có không thu lại (y server).
      extendProfiles = cur;
      extendMonthly = discounted;
      extendCharge = discounted * months;
      extendMembers = Math.max(0, CURRENT_SUB.quotaMembers - 1);
      extendMemberCharge = 0;
    }
    if (CURRENT_SUB.lifetime) invalid = 'LIFETIME_ACTIVE';
    if (!invalid && addProfiles === 0 && state.members === 0 && !(v.days > 0)) invalid = 'NOTHING_TO_BUY';
    profileCharge = remainCharge + extendCharge;
    memberCharge = mTotal + extendMemberCharge; // ĐỒNG GIÁ - KHÔNG nhân theo ngày
    payNow = profileCharge + memberCharge;
    prorateDays = addProfiles > 0 ? remain : remain + v.days;
  }
  if (isLife && CURRENT_SUB.lifetime) invalid = 'LIFETIME_ACTIVE';
  const bigger = upgrade && addProfiles > 0;   // nâng cấp: không kỳ hạn, không chiết khấu kỳ hạn (y server)
  const vOut = bigger ? { days: 0, disc: 0 } : v;
  return { lifetime: isLife, pTotal, mTotal, monthly, discounted, disc: vOut.disc, days: vOut.days, months: bigger ? 1 : months, total, upgrade, payNow, prorateDays, profileCharge, memberCharge,
    remainCharge, extendCharge, extendProfiles, extendMembers, extendMemberCharge, extendMonthly, curPrice, upDays, bigger,
    addProfiles, packageProfiles: P, planName: pk.name, invalid };
}


// Nạp BẢNG GIÁ THẬT (pricing_config) vào các hằng số giá của module. Trả true nếu đã áp.
export async function loadPricingTables() {
  try {
    const cfg = (window.vt && vt.billing && vt.billing.pricingConfig) ? await vt.billing.pricingConfig() : null;
    return !!applyPricingConfig(cfg);
  } catch { return false; }
}
// Số hồ sơ gói Free (dòng đầu thẻ Miễn phí): plans.default_profiles (admin đặt) qua vt.billing.plans().
async function loadFreeProfiles() {
  try {
    const plans = await vt.billing.plans();
    const f = (plans || []).find((p) => p && p.code === 'free');
    FREE_PROFILES = Math.max(0, Number(f && f.default_profiles) || 0);
  } catch { /* giữ 0 */ }
}
// Nạp THUÊ BAO THẬT vào CURRENT_SUB (server là nguồn chuẩn). fallbackQty = mốc hồ sơ khi gói vô hạn. Trả { active }.
export async function loadCurrentSub(fallbackQty) {
  try {
    const bal = await remote.team.balance();
    // Gói trả phí = planTier > 0 - ĐÚNG luật server (billing.repo: paid = tier > 0) và web. Gói tier 0 khác tên 'Free' (vd 'Team
    // Plus' tier 0 do admin cấp) KHÔNG phải gói trả phí: tính như mua mới, không phải nâng cấp. planTier thiếu (server cũ) ⇒ theo tên.
    const isPaid = bal.planTier != null ? Number(bal.planTier) > 0 : !!(bal.planName && bal.planName !== 'Free');
    const active = isPaid && !bal.expired;
    let daysLeft = 0;
    if (active) {
      if (bal.periodEnd) daysLeft = Math.max(0, Math.ceil((new Date(bal.periodEnd) - Date.now()) / 86400000));
      else daysLeft = 30;
    }
    CURRENT_SUB.plan = active ? 'paid' : 'free';
    CURRENT_SUB.planName = isPaid ? (bal.expired ? tf('{0} (đã hết hạn)', bal.planName || t('Gói trả phí')) : (bal.planName || 'Gói trả phí')) : 'Phiên bản miễn phí';
    CURRENT_SUB.daysLeft = daysLeft;
    const owned = (bal.poolLimit != null) ? bal.poolLimit : ((bal.limit != null) ? bal.limit : null);
    CURRENT_SUB.profilesOwned = (owned == null) ? fallbackQty : owned;
    CURRENT_SUB.membersOwned = (bal.memberLimit != null) ? bal.memberLimit : OWNED_MEMBERS;
    // Hạn mức gói (= quota_profiles / quota_members của thuê bao trả phí) - số server nhân khi gia hạn lúc còn hạn.
    // quotaProfiles/quotaMembers do server app trả THẲNG từ subscriptions (members.service); server cũ chưa có ⇒ dùng hạn mức hiệu lực.
    CURRENT_SUB.quotaProfiles = active ? Math.max(0, Number(bal.quotaProfiles != null ? bal.quotaProfiles : owned) || 0) : 0;
    CURRENT_SUB.quotaMembers = active ? Math.max(1, Number(bal.quotaMembers != null ? bal.quotaMembers : bal.memberLimit) || 1) : 1;
    CURRENT_SUB.periodEnd = active ? (bal.periodEnd || null) : null;
    // Gói VĨNH VIỄN (admin cấp, không hết hạn): server không bán thêm gói tháng chồng lên (LIFETIME_ACTIVE).
    CURRENT_SUB.lifetime = active && bal.planCode === 'lifetime';
    // Ngày hết hạn ở border "Gói hiện tại": có periodEnd thì LUÔN hiện (gói Free admin cấp có hạn, gói đã hết hạn - ghi rõ);
    // không có ⇒ "Không giới hạn". Trước 2026-10-29 chỉ hiện khi gói trả phí còn hạn ⇒ "-".
    const endD = bal.periodEnd ? new Date(bal.periodEnd) : null;
    CURRENT_SUB.expiryText = endD && !isNaN(endD.getTime())
      ? (bal.expired || endD.getTime() <= Date.now() ? tf('{0} (đã hết hạn)', iso(endD)) : iso(endD))
      : 'Không giới hạn';
    return { active, ok: true };
  } catch {
    CURRENT_SUB.plan = 'free'; CURRENT_SUB.daysLeft = 0; CURRENT_SUB.profilesOwned = 0;
    CURRENT_SUB.membersOwned = OWNED_MEMBERS; CURRENT_SUB.periodEnd = null; CURRENT_SUB.expiryText = '-';
    CURRENT_SUB.quotaProfiles = 0; CURRENT_SUB.quotaMembers = 1; CURRENT_SUB.lifetime = false;
    return { active: false, ok: false };
  }
}
// Số kỳ hạn của bảng giá đang áp (trang Thủ tục thanh toán kẹp lựa chọn đã lưu theo đúng bảng này, y web).
export const validityCount = () => VALIDITY.length;
export const pricingReady = () => PRICING_READY;
export const lifetimePkg = () => LIFETIME;
export { pkgOrLife };
export { TABS, pkgOf, tierFor, subIsActive, CURRENT_SUB, iso };

export function render(ctx) {
  const host = el('div.upgrade-page');
  ctx.container.appendChild(host);

  // Tự LƯU cấu hình người dùng nhập ở trang này (localStorage) → refresh không mất dữ liệu.
  const STORAGE_KEY = 'polyUpgradeState';
  const loadState = () => {
    try { const s = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null'); return (s && typeof s === 'object') ? s : null; } catch { return null; }
  };
  const _saved = loadState() || {};
  const state = { tabKey: 'professional', qty: 0, members: 0, validity: 0, promo: '', ..._saved };
  // Người dùng ĐÃ từng chọn thời hạn hay chưa (có giá trị hợp lệ trong localStorage). Chỉ khi
  // CHƯA chọn (fresh) mới áp mặc định theo trạng thái gói ở loadSub; đã chọn thì giữ nguyên.
  // Bảng giá chưa nạp lúc này ⇒ chỉ kiểm khuôn (số nguyên ≥ -1); kẹp theo số kỳ hạn thật ở loadPricing.
  const hasSavedValidity = _saved.validity != null
    && Number.isInteger(Number(_saved.validity)) && Number(_saved.validity) >= 0;
  // Chuẩn hoá lại giá trị đã lưu để tránh dữ liệu hỏng/ngoài phạm vi.
  // Gói cố định: nhớ GÓI. Lựa chọn lưu từ thời thanh kéo (chỉ có qty) ⇒ suy ra gói nhỏ nhất chứa được số đó.
  if (state.tabKey !== LIFE_KEY && !TABS.some((tb) => tb.key === state.tabKey)) state.tabKey = tierFor(Number(state.qty) || 0);
  state.members = Math.max(0, Math.floor(Number(state.members) || 0));
  // validity = -1 nghĩa là "Không gia hạn" (chỉ có ở chế độ nâng cấp giữa kỳ).
  if (!(Number.isInteger(Number(state.validity)) && Number(state.validity) >= 0)) state.validity = 0;   // -1 ("Không gia hạn" cũ) ⇒ 30 ngày
  state.validity = Number(state.validity);
  if (typeof state.promo !== 'string') state.promo = '';
  state.qty = pkgOf(state.tabKey).profiles;
  const save = () => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify({ tabKey: state.tabKey, qty: state.qty, members: state.members, validity: state.validity, promo: state.promo })); } catch { /* bỏ qua */ }
  };
  // "Quay lại" ở HEADER LỚN (#header-title) - giống trang "Chỉnh sửa quy trình".
  function mountBackLink() {
    const t = document.getElementById('header-title');
    if (!t) return;
    t.classList.add('is-flow');
    t.innerHTML = '';
    t.appendChild(el('button.rpa-back', { html: `${icon('chevron')}<span>Quay lại</span>`, onclick: () => ctx.navigate('profiles') }));
    t.appendChild(el('div.rpa-top-div'));
    t.appendChild(el('span.header-flow-title', { text: 'Nâng cấp gói' }));
  }
  function unmountBackLink() {
    const t = document.getElementById('header-title');
    if (t) t.classList.remove('is-flow');
  }

  // Vùng cập nhật động (không repaint cả trang): bubble slider · giá lớn · ô số · panel phải.
  let bubbleEl, bigPriceEl, unitAltEl, qtyInput, sideBodyEl, tabBtns = {};

  const currentCost = () => costFor(state);

  // MÃ GIẢM GIÁ ở bước 1 (user 2026-11-07, lượt 4): CHỈ ô nhập, KHÔNG nút. Kiểm với server khi chuột RỜI ô, khi rời tiêu điểm
  // hoặc Enter ⇒ báo hợp lệ/lỗi ngay dưới ô + khung "Tổng thanh toán" hiện dòng giảm và tổng SAU giảm (khách biết số tiền trước khi
  // bấm "Thủ tục thanh toán"). Đổi lựa chọn (qty/members/validity) ⇒ tự kiểm lại sau 400ms. Bấm "Thủ tục thanh toán" ⇒ mang mã
  // sang COUPON_KEY { code, sig }; trang thanh toán kiểm LẦN NỮA, server kiểm lần cuối khi trừ ví. Số ở đây chỉ để hiển thị.
  let cp = null;                     // kết quả hợp lệ { code, base, discount, pay, sig }
  let cpDraft = '', cpErr = '', cpBusy = false, cpTimer = null, cpSeq = 0, cpKey = '', cpFocus = false;
  const planOrder = () => ({ kind: 'plan', plan: state.tabKey, qty: state.qty, members: state.members, validity: state.validity });
  const planSig = () => JSON.stringify(planOrder());
  const cpNorm = (v) => String(v || '').trim().toUpperCase();
  const cpLive = () => (cp && cp.sig === planSig() && cp.code === cpNorm(cpDraft) ? cp : null);
  try { const sv = JSON.parse(sessionStorage.getItem(COUPON_KEY) || 'null'); if (sv && typeof sv.code === 'string') cpDraft = sv.code; } catch { /* bỏ qua */ }
  const saveCouponForCheckout = () => {
    const code = String(cpDraft || '').trim();
    try { if (code) sessionStorage.setItem(COUPON_KEY, JSON.stringify({ code, sig: planSig() })); else sessionStorage.removeItem(COUPON_KEY); } catch { /* bỏ qua */ }
  };
  const cpMsg = (r) => (r && r.code === 'COUPON_MIN_ORDER' && r.minOrder ? tf('Mã chỉ áp dụng cho đơn từ {0}', fmtVnd(r.minOrder))
    : r && r.code === 'COUPON_MIN_DAYS' && r.minDays ? tf('Mã chỉ áp dụng cho gói từ {0} ngày', r.minDays)
    : t((r && r.message) || 'Mã giảm giá không hợp lệ'));
  // Kiểm mã đang gõ cho lựa chọn hiện tại. Bỏ qua nếu ĐÚNG mã này đã kiểm cho ĐÚNG lựa chọn này (rê chuột ra vào nhiều lần không
  // gọi lại server). Sai định dạng (dưới 3 ký tự, có dấu/khoảng trắng giữa) ⇒ báo ngay, không gửi server (khỏi tốn lượt chống dò mã).
  async function checkCoupon() {
    const code = String(cpDraft || '').trim();
    if (!code) {
      if (cp || cpErr || cpBusy) { cpSeq++; cp = null; cpErr = ''; cpBusy = false; cpKey = ''; renderSide(); }
      return;
    }
    const key = cpNorm(code) + '|' + planSig();
    if (key === cpKey) return;
    cpKey = key;
    if (!/^[A-Z0-9_-]{3,32}$/.test(cpNorm(code))) { cpSeq++; cp = null; cpBusy = false; cpErr = t('Mã giảm giá không hợp lệ'); renderSide(); return; }
    const seq = ++cpSeq;
    const sig = planSig();
    cpBusy = true; cpErr = ''; renderSide();
    let r = null, failMsg = '';
    try {
      const env = await vt.billing.couponPreview({ code, order: planOrder() });
      if (env && env.ok) r = env.data; else failMsg = t((env && env.error) || 'Không kiểm tra được mã, vui lòng thử lại');
    } catch { failMsg = t('Không kiểm tra được mã, vui lòng thử lại'); }
    if (seq !== cpSeq) return;   // đã có lượt kiểm mới hơn - bỏ kết quả cũ
    cpBusy = false;
    if (r && r.ok) { cp = { code: r.code, base: Number(r.base), discount: Number(r.discount), pay: Number(r.pay), sig }; cpErr = ''; }
    else { cp = null; cpErr = failMsg || cpMsg(r); if (failMsg) cpKey = ''; }   // lỗi mạng: lần rê chuột sau thử lại
    renderSide();
  }
  // Lựa chọn vừa đổi (hoặc mã nhớ từ lần trước) mà chưa kiểm cho lựa chọn này ⇒ kiểm (gom thao tác kéo thanh trượt, 400ms).
  function recheckCoupon() {
    if (!String(cpDraft || '').trim() || cpBusy) return;
    if (cpNorm(cpDraft) + '|' + planSig() === cpKey) return;
    clearTimeout(cpTimer);
    cpTimer = setTimeout(() => checkCoupon(), 400);
  }
  // Số tiền GIẢM theo hai đơn vị [chính, phụ] - y quy tắc khung tổng (totalMoney): tiếng Việt ⇒ VNĐ chính, "≈ $" phụ; ngôn ngữ khác
  // ⇒ $ chính, VNĐ phụ. $ giảm = $(gốc) − $(sau giảm) (cùng làm tròn lên như số tổng) ⇒ cộng trừ khớp từng cent với khung tổng.
  const cpDiscMoney = (live) => {
    const vnd = fmtVnd(live.discount);
    if (!(fx.show())) return [vnd, ''];
    const usd = fx.fmt(Math.max(0, Math.round((fx.toUsd(live.base) - fx.toUsd(live.pay)) * 100) / 100));
    return fx.usdFirst() ? [usd, vnd] : [vnd, '≈ ' + usd];
  };
  // Ô nhập: gõ chữ KHÔNG vẽ lại. Kết quả về mà ô đang được gõ ⇒ trả lại tiêu điểm + con trỏ cuối chữ cho ô mới vẽ.
  function couponField() {
    const inp = el('input.cpf-inp', { type: 'text', maxlength: '32', autocomplete: 'off', spellcheck: 'false', placeholder: t('Nhập mã giảm giá (nếu có)') });
    inp.value = cpDraft;
    inp.addEventListener('input', () => { cpDraft = inp.value; });
    inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); checkCoupon(); } });
    inp.addEventListener('focus', () => { cpFocus = true; });
    // blur cũng bắn khi ô bị GỠ lúc vẽ lại cột phải ⇒ hoãn 1 nhịp: ô đã rời DOM thì bỏ qua (giữ cpFocus để ô mới lấy lại tiêu điểm).
    inp.addEventListener('blur', () => { setTimeout(() => { if (!inp.isConnected) return; cpFocus = false; checkCoupon(); }, 0); });
    const box = el('div.cpf.cpf-solo', {}, [inp]);
    box.addEventListener('mouseleave', () => checkCoupon());
    if (cpFocus) requestAnimationFrame(() => { if (!document.body.contains(inp)) return; inp.focus(); const n = inp.value.length; try { inp.setSelectionRange(n, n); } catch { /* bỏ qua */ } });
    const live = cpLive();
    const status = cpBusy ? el('div.cpf-status', { text: t('Đang kiểm tra…') })
      : live ? el('div.cpf-status.ok', { text: tf('Mã hợp lệ, giảm {0}', (([a, b2]) => a + (b2 ? ' (' + b2 + ')' : ''))(cpDiscMoney(live))) })
      : cpErr ? el('div.cpf-err', { text: cpErr }) : null;
    return el('div.cpf-wrap', {}, [box, status]);
  }
  // Dòng mã trong khung "Tổng thanh toán" (chỉ khi mã hợp lệ cho đúng lựa chọn đang xem).
  function couponTotalRow() {
    const live = cpLive();
    if (!live) return null;
    const [main, sub] = cpDiscMoney(live);
    return el('div.ap-total-cp', {}, [
      el('span.ap-total-cp-k', {}, [document.createTextNode(t('Mã giảm giá') + ' '), el('span.ap-total-cp-code', { text: live.code })]),
      el('span.ap-total-cp-v', {}, [
        el('span', { text: '-' + main }),
        sub ? el('span.ap-total-cp-sub', { text: sub.charAt(0) === '≈' ? '≈ -' + sub.slice(2) : '-' + sub }) : null,
      ]),
    ]);
  }

  function updateDynamic() {
    Object.keys(tabBtns).forEach((k) => tabBtns[k] && tabBtns[k].classList.toggle('is-selected', k === state.tabKey));
    renderSide();
  }

  // ── Cột phải (chi tiết gói + giá + Đặt mua) ───────────────────────────────
  function renderSide() {
    if (!sideBodyEl) return;
    clear(sideBodyEl);
    const c = currentCost();
    // Nâng cấp: hiển thị hồ sơ TĂNG THÊM + hạn dùng MỚI (ngày còn lại + thời hạn mới).
    const addProfilesCost = c.profileCharge; // giá hồ sơ THỰC tính (đã prorate ngày còn lại + gia hạn)
    const totalDays = c.upgrade ? c.prorateDays : c.days;
    // Nâng cấp lúc còn hạn: server GIỮ hạn cũ rồi cộng đúng số ngày mua (billing.repo keepPeriod) ⇒ hạn mới = HẠN CŨ + c.days,
      // không phải hôm nay + số ngày còn lại (làm tròn lên) - lệch tới 1 ngày.
      const expire = c.upgrade && CURRENT_SUB.periodEnd && !isNaN(new Date(CURRENT_SUB.periodEnd).getTime())
        ? new Date(new Date(CURRENT_SUB.periodEnd).getTime() + c.days * 86400000)
        : (() => { const d = new Date(); d.setDate(d.getDate() + totalDays); return d; })();

    const row = (label, value, opts = {}) => el('div.ap-detail-row', {}, [
      el('span.ap-detail-k', {}, [
        document.createTextNode(label),
        opts.sub ? el('span.ap-detail-sub', { text: opts.sub }) : null,
      ]),
      el('span.ap-detail-v' + (opts.strike ? '.strike' : ''), { text: value }),
    ]);

    const detail = el('div.ap-detail', {}, [
      el('div.ap-detail-title', { text: 'Chi tiết gói' }),
      row('Gói', c.planName),   // tên gói đang chọn (chủ sở hữu 2026-11-12)
      // Nâng cấp lên gói lớn hơn khi còn hạn: chỉ trả chênh lệch giá tháng cho số ngày còn lại (kiểu Claude) - nói rõ ở dòng phụ.
      row('Hồ sơ trình duyệt', fmtVnd(c.profileCharge), { sub: c.bigger ? tf('(nâng cấp: chênh lệch {0} cho {1} ngày còn lại)', fmtVnd(Math.max(0, c.pTotal - c.curPrice)) + t('/tháng'), c.upDays) : tf('{0} hồ sơ trình duyệt', c.packageProfiles) }),
      // Còn hạn + gia hạn: cả thuê bao kéo dài ⇒ tính TOÀN BỘ hồ sơ cho thời hạn mới (dòng riêng cho rõ).
      row('Thành viên của nhóm', fmtVnd(c.memberCharge), { sub: c.upgrade
        ? tf('(mua thêm {0})', state.members)
        : `(${OWNED_MEMBERS}+${state.members})` }),
      row('Chu kỳ đăng ký', c.lifetime ? t('Vĩnh viễn') : c.upgrade
        ? (c.bigger ? tf('{0} ngày còn lại (giữ nguyên hạn)', CURRENT_SUB.daysLeft) : c.days > 0 ? tf('{0} + {1} ngày', CURRENT_SUB.daysLeft, c.days) : tf('{0} ngày (không gia hạn)', CURRENT_SUB.daysLeft))
        : tf('{0} ngày', c.days)),
      row('Thời gian hết hạn', c.lifetime ? t('Không giới hạn') : iso(expire)),
    ]);

    // Khối giá: có chiết khấu → hiện giá gốc gạch + giá thanh toán; không → Cost.
    // KHÔNG thêm lại hàng "Gói giảm giá | Giảm N%" (user bỏ 2026-09-27): mức giảm đã đọc được
    // từ chính hai hàng dưới (giá gốc gạch ngang → giá thanh toán), và dải "Tiết kiệm tới N%"
    // cạnh nút mua vẫn nói con số % - ghi ba lần một thông tin chỉ làm khung chi tiết rối.
    let priceBlock;
    if (c.disc > 0) {
      priceBlock = el('div.ap-pricebox', {}, [
        el('div.ap-detail-row', {}, [
          el('span.ap-detail-k', { text: 'gói giá gốc' }),
          el('span.ap-detail-v.strike', { text: fmtVnd(c.monthly) }),
        ]),
        el('div.ap-detail-row.ap-paynow', {}, [
          el('span.ap-detail-k', { text: 'giá thanh toán' }),
          el('div.ap-money', {}, [
            el('span.ap-pay-amt', { text: tf('{0}/tháng', fmtVnd(c.discounted)) }),
            usdOf(c.discounted) ? el('span.ap-usd', { text: tf('{0}/tháng', usdOf(c.discounted)) }) : null,
          ]),
        ]),
      ]);
    } else {
      priceBlock = el('div.ap-pricebox', {}, [
        el('div.ap-detail-row.ap-cost', {}, [
          el('span.ap-detail-k', { text: c.lifetime ? 'Trả một lần' : 'Cost' }),
          el('div.ap-money', {}, [
            el('span.ap-pay-amt', { text: c.lifetime ? fmtVnd(c.monthly) : tf('{0}/tháng', fmtVnd(c.monthly)) }),
            usdOf(c.monthly) ? el('span.ap-usd', { text: tf('{0}/tháng', usdOf(c.monthly)) }) : null,
          ]),
        ]),
      ]);
    }

    // Giá CUỐI CÙNG phải trả (đã gồm chiết khấu × số tháng) → người dùng biết cần nạp bao nhiêu.
    // Nhãn một dòng riêng, số tiền một cột canh phải bên dưới (totalMoney: tiếng Việt VNĐ chính + "≈ $" phụ; ngôn ngữ
    // khác USD lên đầu - bước cuối ví vẫn trừ VNĐ). Giống web landing.
    recheckCoupon();
    const totalBlock = el('div.ap-total-box', {}, [
      el('div.ap-total-k', {}, [
        document.createTextNode('Tổng thanh toán'),
        c.upgrade || c.lifetime ? null : el('span.ap-total-sub', { text: tf('({0} tháng)', c.months) }),
      ]),
      couponTotalRow(),
      totalMoney(cpLive() ? cpLive().pay : (c.upgrade ? c.payNow : c.total)),
    ]);

    // BƯỚC 1 → BƯỚC 2: lưu lựa chọn rồi sang trang "Thủ tục thanh toán" (chọn Số dư / VietQR / PayPal / thẻ ở đó).
    const buyWrap = el('div.ap-buy-wrap', {}, [
      el('button.btn.primary.ap-buy', { text: 'Thủ tục thanh toán', disabled: c.invalid ? 'disabled' : null, onclick: () => { if (c.invalid) return; save(); saveCouponForCheckout(); saveOrder({ kind: 'plan' }); ctx.navigate('checkout'); } }),
    ]);
    // Đơn không hợp lệ (gói nhỏ hơn số hồ sơ đang có khi còn hạn / không có gì để mua / gói vĩnh viễn) ⇒ nói rõ lý do ngay trên nút.
    const invalidNote = c.invalid ? el('div.cpf-err.ap-invalid', { text: PLAN_INVALID_MSG[c.invalid] || '' }) : null;

    // Giá + nút "Đặt mua" nằm TRONG khối viền "Chi tiết gói"; gạch ngang ngăn với các dòng chi tiết.
    detail.appendChild(el('div.ap-detail-div'));
    detail.appendChild(priceBlock);
    detail.appendChild(totalBlock);
    detail.appendChild(couponField());   // ô mã giảm giá - ngay TRÊN nút "Thủ tục thanh toán"
    if (invalidNote) detail.appendChild(invalidNote);
    detail.appendChild(buyWrap);
    // Border "Gói hiện tại": số hồ sơ / thành viên / ngày hết hạn THẬT (đọc từ server qua
    // loadSub). Nâng cấp thành công → cộng dồn; gia hạn (sau khi hết hạn) → reset về gói mới.
    const curProfiles = (CURRENT_SUB.profilesOwned != null) ? CURRENT_SUB.profilesOwned : OWNED_PROFILES;
    const curMembers = (CURRENT_SUB.membersOwned != null) ? CURRENT_SUB.membersOwned : OWNED_MEMBERS;
    sideBodyEl.appendChild(el('div.ap-side-plan', {}, [
      el('div.ap-side-cur-label', { text: tf('Gói hiện tại: {0}', CURRENT_SUB.planName) + (CURRENT_SUB.plan === 'paid' ? ' ' + tf('· còn {0} ngày', CURRENT_SUB.daysLeft) : '') }),
      el('div.ap-side-usage', {}, [el('span', { text: 'Số hồ sơ:' }), el('b', { text: `${curProfiles}` })]),
      el('div.ap-side-usage', {}, [el('span', { text: 'Số lượng thành viên:' }), el('b', { text: `${curMembers}` })]),
      el('div.ap-side-usage', {}, [el('span', { text: 'Ngày hết hạn:' }), el('b', { text: CURRENT_SUB.expiryText || '-' })]),
    ]));
    sideBodyEl.appendChild(el('div.ap-side-div'));
    sideBodyEl.appendChild(detail);
    save(); // renderSide chạy sau MỌI thay đổi (qty/tab/validity/members) → lưu ngay.
  }

  // ── Tooltip giá thành viên (hover icon info) ──────────────────────────────
  function memberTooltip() {
    return el('div.ap-tip.ap-tip-sm', {}, [
      el('div.ap-tip-title', { text: 'Giá thành viên' }),
      el('div.ap-tip-desc', { text: 'Mỗi gói bao gồm một Quản trị viên cấp cao miễn phí' }),
      el('div.ap-tip-table', {}, [
        el('div.ap-tip-row.ap-tip-head', {}, [el('span', { text: 'Số lượng thành viên' }), el('span', { text: 'Unit Price' })]),
        el('div.ap-tip-row', {}, [el('span', { text: '1' }), el('span.ap-tip-price', { text: fmtVnd(MEMBER_UNIT) })]),
      ]),
      el('div.ap-tip-eg', { text: 'Ví dụ, nếu bạn cần 10 thành viên, thì: 10*35000₫ = 350000₫' }),
    ]);
  }
  function infoIcon(tooltipFn) {
    const wrap = el('span.ap-info', { html: icon('infoCircle') });
    let tip = null;
    wrap.addEventListener('mouseenter', () => { if (tip) return; tip = tooltipFn(); wrap.appendChild(tip); });
    wrap.addEventListener('mouseleave', () => { if (tip) { tip.remove(); tip = null; } });
    return wrap;
  }

  // ── Stepper (- N +) ───────────────────────────────────────────────────────
  function stepper(value, onChange, opts = {}) {
    const min = opts.min ?? 0;
    const max = opts.max ?? Infinity;
    const step = opts.step ?? 1;
    const input = el('input.ap-step-input', { type: 'text', value: String(value) });
    const commit = (v) => { const n = Math.max(min, Math.min(max, v)); input.value = String(n); onChange(n); };
    input.addEventListener('change', () => { const n = parseInt(input.value, 10); commit(Number.isFinite(n) ? n : min); });
    const dec = el('button.ap-step-btn', { text: '-', onclick: () => commit((parseInt(input.value, 10) || min) - step) });
    const inc = el('button.ap-step-btn', { text: '+', onclick: () => commit((parseInt(input.value, 10) || min) + step) });
    if (opts.expose) opts.expose(input);
    return el('div.ap-stepper', {}, [dec, input, inc]);
  }

  // ── Vẽ cả trang ───────────────────────────────────────────────────────────
  function paint() {
    if (!PRICING_READY) { paintPricingWait(); return; }
    clear(host);
    mountBackLink();
    bubbleEl = bigPriceEl = qtyInput = sideBodyEl = null;
    tabBtns = {};

    // 3 tab gói. Bấm tab → đặt số lượng về mặc định bậc đó rồi vẽ lại.
    // ── THẺ GIÁ kiểu trang chủ (chủ sở hữu 2026-11-12): kỳ hạn chung trên đầu, MỘT thẻ mỗi gói (không thẻ Miễn phí, không nút -
  // bấm thẻ là chọn; thẻ rời nhau, viền nét đứt, hover/chọn = nét liền gradient + nền nhạt) ──
  // Mọi số đều từ bảng giá web admin (TABS/VALIDITY/MEMBER_UNIT/PLAN_DEVICES/FREE_REFUND/FREE_PROFILES), không ghi cứng.
  // Tổng trên thẻ = giá mua mới của kỳ đang chọn (y trang chủ); tiền thật phải trả (kể cả nâng cấp giữa kỳ) ở panel phải (costFor).
  const DEV_CODE = { free: 'free', professional: 'pro', business: 'team', enterprise: 'custom' };   // thẻ → plans.code (y index.html data-dev-plan)
  const POP_SVG = '<svg class="pop-badge-ico" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="6"/><path d="M15.477 12.89 17 22l-5-3-5 3 1.523-9.11"/></svg>';
  const MINUS_SVG = '<svg class="pc-ico" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"/></svg>';
  // Dấu tích góc thẻ đang chọn - y ô "Chọn phương thức thanh toán" (pay-common CHECK_SVG + .co-check).
  const CHECK_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4.5 12.5l5 5L19.5 7"/></svg>';
  const PLUS_SVG = '<svg class="pc-ico" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>';
  const periodV = () => (state.validity < 0 ? { days: 30, disc: 0 } : (VALIDITY[state.validity] || VALIDITY[0]));
  const validLabel = (d) => (d === 30 ? t('Hàng tháng') : (d % 30 === 0 ? tf('{0} tháng', d / 30) : tf('{0} ngày', d)));
  // Không còn "Không gia hạn" (chủ sở hữu 2026-11-12): gói cố định ⇒ chọn gói là chọn kỳ hạn; còn hạn mà lên gói lớn hơn thì
  // tiền = phần hồ sơ thêm cho ngày còn lại + gia hạn trọn gói kỳ đã chọn (costFor).
  // Tab "Vĩnh viễn" (idx -2) chỉ khi admin bật bán: chọn ⇒ lưới chỉ còn thẻ gói vĩnh viễn; chọn kỳ khác ⇒ về 3 gói tháng.
  const isLifeTab = state.tabKey === LIFE_KEY;
  const validOpts = VALIDITY.map((v, i) => ({ idx: i, label: validLabel(v.days), disc: v.disc }))
    .concat(LIFETIME ? [{ idx: -2, label: t('Vĩnh viễn'), disc: 0 }] : []);
  const validBtns = [];
  const validSeg = el('div.pcalc-seg.pricing-valid.ap-valid' + (LIFETIME ? '.has-life' : ''), {}, validOpts.map((o) => {
    const active = o.idx === -2 ? isLifeTab : (!isLifeTab && o.idx === state.validity);
    const b = el('button' + (active ? '.active' : ''), {
      type: 'button',
      onclick: () => {
        if (o.idx === -2) { if (!isLifeTab) { state.prevTab = state.tabKey; state.tabKey = LIFE_KEY; paint(); } return; }
        if (isLifeTab) { state.tabKey = TABS.some((tb) => tb.key === state.prevTab) ? state.prevTab : TABS[0].key; state.validity = o.idx; paint(); return; }
        state.validity = o.idx; validBtns.forEach((bb) => bb.classList.toggle('active', bb._optIdx === o.idx)); refreshCards(); renderSide();
      },
    }, [document.createTextNode(o.label), o.disc > 0 ? el('i', { text: '-' + Math.round(o.disc * 100) + '%' }) : null]);
    b._optIdx = o.idx;
    validBtns.push(b);
    return b;
  }));

  // Số thành viên NHẬP RIÊNG trên từng thẻ; thẻ đang chọn quyết định state.members (panel phải).
  const memBy = {};
  TABS.forEach((tb) => { memBy[tb.key] = tb.key === state.tabKey ? state.members : 0; });
  memBy[LIFE_KEY] = state.tabKey === LIFE_KEY ? state.members : 0;
  const cardRefs = {};
  const cardTotal = (tb) => { if (tb.lifetime) return tb.price + (memBy[tb.key] || 0) * MEMBER_UNIT; const v = periodV(); return Math.round(tb.price * (1 - v.disc)) * Math.max(1, Math.round(v.days / 30)) + (memBy[tb.key] || 0) * MEMBER_UNIT; };
  // 0 = VÔ HẠN (quy ước thang thiết bị); null = admin chưa đặt ⇒ không hiện dòng.
  const devBox = (code) => {
    const raw = PLAN_DEVICES[code];
    if (raw == null) return null;
    const n = Math.max(0, Math.trunc(Number(raw)) || 0);
    return el('div.pc-devices', {}, [
      el('span.pc-dev-label', { text: 'Giới hạn thiết bị' }),
      el('b.pc-dev-val' + (n === 0 ? '.pc-dev-unl' : ''), { text: n === 0 ? t('Không giới hạn') : n.toLocaleString('vi-VN') }),
    ]);
  };
  // DANH SÁCH TÍNH NĂNG của gói (đòn bẩy bán gói, chủ sở hữu 2026-11-12): limit tạo/mở mỗi ngày (admin đặt hệ số ở web admin →
  // Limit hồ sơ; 0 = không giới hạn) + "vân tay thật" (admin bật/tắt theo gói ở Bảng giá). Viết thành câu, KHÔNG giống bảng phụ phí.
  // BẢNG đòn bẩy (chủ sở hữu 2026-11-12): 3 dòng nhãn | giá trị, viền mờ. Vân tay thực: gói tắt ⇒ "Không hỗ trợ"; bật ⇒ số kéo về
  // (0 = Không giới hạn) - cả hai do admin đặt ở Bảng giá.
  const featTable = (tb) => {
    const l = PLAN_LIMITS[tb.key];
    const num = (n) => Number(n).toLocaleString('vi-VN');
    const dayVal = (n) => (Number(n) > 0 ? num(n) : t('Không giới hạn'));   // chỉ số, không '/ngày' (nhãn đã nói 'mỗi ngày')
    const rows = [];
    if (l) {
      rows.push(['Tạo hồ sơ mỗi ngày', dayVal(l.create), false]);
      rows.push(['Mở hồ sơ mỗi ngày', dayVal(l.open), false]);
    }
    // Đòn bẩy vân tay: NHÃN là câu đầy đủ, GIÁ TRỊ = số lượng admin đặt (0 = Không giới hạn; tắt = Không hỗ trợ).
    rows.push(['Vân tay trình duyệt cấu hình tùy chỉnh', tb.realFp ? (tb.fpCount > 0 ? num(tb.fpCount) : t('Không giới hạn')) : t('Không hỗ trợ'), !tb.realFp]);
    // Tên bảng "Giới hạn" = một hàng tiêu đề trải hết chiều ngang (chủ sở hữu 2026-11-12), không bo góc.
    return el('table.pc-table', {}, [
      el('thead', {}, [el('tr', {}, [el('th', { colspan: '2', text: 'Giới hạn số lượng' })])]),
      el('tbody', {}, rows.map(([k, v, off]) => el('tr' + (off ? '.off' : ''), {}, [el('td', { text: k }), el('td', { text: v })]))),
    ]);
  };
  const featList = (tb) => {
    const l = PLAN_LIMITS[tb.key];
    const items = [];
    if (l) {
      items.push(el('li', { text: Number(l.create) > 0 ? tf('Tạo tối đa {0} hồ sơ mỗi ngày', Number(l.create).toLocaleString('vi-VN')) : 'Không giới hạn lượt tạo hồ sơ mỗi ngày' }));
      items.push(el('li', { text: Number(l.open) > 0 ? tf('Mở tối đa {0} lượt mỗi ngày', Number(l.open).toLocaleString('vi-VN')) : 'Không giới hạn lượt mở hồ sơ mỗi ngày' }));
    }
    items.push(el('li' + (tb.realFp ? '' : '.off'), { text: 'Vân tay trình duyệt cấu hình tùy chỉnh' }));
    return el('ul.pc-feats.pc-feats-plan', {}, items);
  };
  const refundBadge = () => el('span.pc-refund-badge', {}, [el('span', { text: 'Xóa hồ sơ được hoàn lại lượt tạo mới' })]);
  const curTag = () => el('span.pc-current-tag', { text: 'Gói hiện tại' });
  function selectCard(key) {
    state.tabKey = key;
    state.members = memBy[key] || 0;
    Object.keys(cardRefs).forEach((k) => cardRefs[k].card.classList.toggle('is-selected', k === key));
    renderSide();
  }
  function refreshCards() {
    const v = periodV();
    CARD_PKGS.forEach((tb) => {
      const r = cardRefs[tb.key]; if (!r) return;
      // Giá y trang chủ: "300.000₫/$11.77" - số chính TO, dấu "/" cao, số phụ nhỏ nằm thấp (.pc-alt). Trang khác tiếng Việt: USD
      // đứng trước, VNĐ phụ (y public/app.js priceHtml). Chưa có tỷ giá ⇒ chỉ VNĐ.
      const total = cardTotal(tb);
      const vnd = (Math.round(total) || 0).toLocaleString('vi-VN');
      const usd = fx.show() ? fx.fmt(fx.toUsd(total)) : '';
      r.total.innerHTML = !usd ? vnd + '<span class="pc-cur">₫</span>'
        : fx.usdFirst() ? usd + '<span class="pc-sep">/</span><span class="pc-alt">' + vnd + '₫</span>'
        : vnd + '<span class="pc-cur">₫</span><span class="pc-sep">/</span><span class="pc-alt">' + usd + '</span>';
      r.period.textContent = tb.lifetime ? t('trả một lần') : (v.days === 30 ? t('mỗi tháng') : (v.days % 30 === 0 ? tf('mỗi {0} tháng', v.days / 30) : tf('mỗi {0} ngày', v.days)));
      r.minus.disabled = (memBy[tb.key] || 0) <= 0;
      if (document.activeElement !== r.input) r.input.value = String(memBy[tb.key] || 0);
    });
  }

  // Tab Vĩnh viễn ⇒ lưới một thẻ (gói vĩnh viễn, khoá 'lifetime'); còn lại ⇒ 3 gói tháng.
  const CARD_PKGS = isLifeTab ? [pkgOrLife(LIFE_KEY)] : TABS;
  const cards = CARD_PKGS.map((tb, idx) => {
    const input = el('input.pc-mem-val', { type: 'text', inputmode: 'numeric', value: String(memBy[tb.key] || 0), 'aria-label': 'Thành viên nhóm' });
    const minus = el('button.pc-mem-btn', { type: 'button', html: MINUS_SVG });
    const plus = el('button.pc-mem-btn.pc-mem-btn--plus', { type: 'button', html: PLUS_SVG });
    // Chỉnh thành viên trên thẻ chưa chọn ⇒ chọn luôn thẻ đó (panel phải phải phản ánh đúng số vừa gõ).
    const setMem = (n) => {
      memBy[tb.key] = Math.max(0, Math.floor(Number(n) || 0));
      if (state.tabKey !== tb.key) selectCard(tb.key); else { state.members = memBy[tb.key]; renderSide(); }
      refreshCards();
    };
    minus.onclick = (e) => { e.stopPropagation(); setMem((memBy[tb.key] || 0) - 1); };
    plus.onclick = (e) => { e.stopPropagation(); setMem((memBy[tb.key] || 0) + 1); };
    input.addEventListener('click', (e) => e.stopPropagation());
    input.addEventListener('input', () => { input.value = input.value.replace(/\D/g, ''); setMem(input.value); });
    input.addEventListener('blur', () => { input.value = String(memBy[tb.key] || 0); });
    const total = el('b.pc-total');
    const period = el('span.pc-period');
    const isCur = tb.lifetime ? !!CURRENT_SUB.lifetime : (subIsActive() && !CURRENT_SUB.lifetime && CURRENT_SUB.quotaProfiles === tb.profiles);
    // title ⇒ tooltip kiểu app (ui.js chuyển title thành .app-tooltip): "Chọn gói Team Plus".
    const card = el('article.price-card.pc-plan' + (idx === 0 && !tb.lifetime ? '.price-card--pop' : '') + (tb.key === state.tabKey ? '.is-selected' : ''), {
      title: tf('Chọn gói {0}', tb.name), 'data-tip-instant': '',   // tooltip hiện NGAY, không chờ 280ms
      onclick: () => selectCard(tb.key),
    }, [
      idx === 0 && !tb.lifetime ? el('span.pop-badge', {}, [el('span.pop-badge-ico-wrap', { html: POP_SVG }), document.createTextNode(t('Phổ biến'))]) : null,
      el('h3', {}, [document.createTextNode(tb.name), isCur ? curTag() : null]),
      el('div.pc-box', {}, [el('div.pc-mem-top', {}, [el('span', { text: 'Số hồ sơ' })]), el('b.pc-pkg-num', { text: tb.profiles.toLocaleString('vi-VN') })]),
      refundBadge(),
      el('div.pc-members', {}, [
        el('div.pc-mem-top', {}, [el('span', { text: 'Thành viên nhóm' })]),
        el('div.pc-mem-ctrl', {}, [el('span.pc-mem-box.pc-numbox', {}, [input]), minus, plus]),
      ]),
      devBox(tb.lifetime ? 'lifetime' : DEV_CODE[tb.key]),
      featTable(tb),
      el('div.pc-total-box', {}, [total, period]),
      el('span.co-check', { html: CHECK_SVG }),
    ]);
    cardRefs[tb.key] = { card, total, period, input, minus };
    tabBtns[tb.key] = card;
    return card;
  });
  refreshCards();

  const left = el('div.ap-left.ap-pricing', {}, [validSeg, el('div.pricing-grid' + (isLifeTab ? '.is-lifetime' : ''), {}, cards)]);


    // ── Panel phải (20%): chỉ tổng tiền của gói, không viền, không chọn loại tiền ──
    sideBodyEl = el('div.ap-side-body');
    const side = el('div.ap-side', {}, [sideBodyEl]);

    renderSide();

    host.appendChild(el('div.ap-wrap', {}, [
      el('div.px-card.ap-card', {}, [el('div.ap-cols', {}, [left, side])]),
    ]));
  }

  // Chưa có bảng giá web admin: chỉ báo đang tải / lỗi - KHÔNG tính tiền bằng số tự đặt.
  let pricingFailed = false;
  function paintPricingWait() {
    clear(host);
    mountBackLink();
    sideBodyEl = null; tabBtns = {};
    host.appendChild(el('div.ap-wrap', {}, [el('div.px-card.ap-card', {}, [
      el('div.ap-pricing-wait', { text: pricingFailed ? 'Không tải được bảng giá. Vui lòng mở lại trang.' : 'Đang tải bảng giá…' }),
    ])]));
  }

  paint();

  // Nạp BẢNG GIÁ THẬT (pricing_config, do web admin sửa) rồi mới vẽ pane gói. Lỗi ⇒ báo lỗi, không dùng số tự đặt.
  async function loadPricing() {
    const [okCfg] = await Promise.all([loadPricingTables(), loadFreeProfiles()]);
    if (okCfg) {
      pricingFailed = false;
      if (state.tabKey === LIFE_KEY && !LIFETIME) state.tabKey = TABS[0].key;   // admin đã tắt bán vĩnh viễn
      if (state.tabKey !== LIFE_KEY && !TABS.some((tb) => tb.key === state.tabKey)) state.tabKey = tierFor(Number(state.qty) || 0);
      state.qty = pkgOrLife(state.tabKey).profiles;
      if (!(state.validity >= 0 && state.validity < VALIDITY.length)) state.validity = 0;
    } else pricingFailed = true;
    paint();
  }
  loadPricing();
  // Tỷ giá VCB về ⇒ vẽ lại để hiện số USD quy đổi.
  loadFx().then(() => { if (document.body.contains(host)) paint(); });

  // Nạp THUÊ BAO THẬT của workspace (server là nguồn chuẩn) → quyết định nút
  // "Mua gói" (free/hết hạn) hay "Nâng cấp" (còn hạn trả phí) + prorate chênh lệch.
  async function loadSub() {
    const { active, ok } = await loadCurrentSub(state.qty);
    // Lần đầu vào trang: áp thời hạn mặc định CHỈ khi khách chưa từng chọn (gói còn hạn ⇒ "Không gia hạn").
    if (ok && !CURRENT_SUB._loaded) {
      if (!hasSavedValidity) state.validity = 0;
      CURRENT_SUB._loaded = true;
      paint();
      return;
    }
    renderSide();
  }
  loadSub();

  return {
    // Quay lại trang: nạp lại CẢ thuê bao và (nếu đang ở tab thiết bị) danh sách máy. Khách
    // rời trang rồi quay về thường là vì vừa làm gì đó ở chỗ khác - hiện số cũ là hiện số sai.
    onShow: () => { mountBackLink(); loadSub(); },
    onHide: () => unmountBackLink(),
    destroy: () => unmountBackLink(),
  };
}
