// "Quy trình" (RPA workflow editor) - UI ONLY, drawn fresh to match AdsPower's
// RPA "Tạo quy trình" editor 1:1 (see docs/adspower-rpa-capture.md).
//
// This is purely the DRAWN interface: a flow list + the graph editor (a left
// node library whose rows each carry a circular "+" add button, an auto-chaining
// canvas with a fixed "Bắt đầu quy trình" start node, a minimap, a right-hand
// config drawer that renders each node's full AdsPower param schema, a "Cài đặt"
// settings modal and the "Biến quy trình" drawer). There is NO engine / IPC /
// persistence - all state lives in memory and is lost on navigation. Nothing
// here executes a workflow.
//
// The visual language is a fresh `rpa-` namespace (app.css) modelled on
// AdsPower's actual editor; it deliberately shares nothing with the old Poly
// workflow design that was removed.
import { el, clear, toast, openModal, closeModal, confirmDialog, confirmUnsavedDialog, promptDialog, customSelect, pageSizeSelect, iconBtn, openMenu, hoverMenu, setRichTooltip, hideTooltip, openUpgradeModal } from '../ui.js';
import { icon } from '../icons.js';
import { t, tf } from '../i18n.js';
import { NODES, CATEGORIES, CAT_COLOR, COL_START, OPS, VAR_TYPES, SYS_VARS, VAR_OUT_KEYS, COND_OPS, COND_OPS_UNARY, COND_OPS_LIST, COND_OP_HINTS, COND_OP_SYMBOLS, find, byCategory, initial, fieldDefault } from '../data/node-catalog.js';
import { loadPermissions, can, describeError } from '../data/team-permissions.js';
import { hasFeature, gateFeature, loadPlanFeatures, planFeaturesSync } from '../data/plan-features.js';

// Hạn mức quy trình gói Free (khớp server flows.routes FREE_MAX_FLOWS).
const FREE_MAX_FLOWS = 5;
import { ensureQuill } from '../vendor-quill.js';
import { brandLogoSvg, hasBrandLogo, brandTileBg } from '../data/brand-icons.js';
import { ensureDevProfile } from '../data/dev-profile.js';

const COL_WIRE = '#3F7CFF';
const COL_TEMP = '#9CA3AF'; // live "đang nối" rubber-band wire (solid gray, distinct from finished wires)

const BRANCH_COLORS = ['#3F7CFF', '#EF4444', '#10B981'];

// Bộ dựng điều kiện (trường `conds`): dòng điều kiện rỗng + tập toán tử một ngôi
// (chỉ xét vế trái nên ô "Giá trị so sánh" bị ẩn).
const newCond = () => ({ left: '', op: 'Bằng', right: '' });
const UNARY_OPS = new Set(COND_OPS_UNARY);
// Toán tử nhận vế phải là danh sách → ô nhập đổi nhãn thành "Danh sách so sánh".
const LIST_OPS = new Set(COND_OPS_LIST);

// Category header glyphs (the library's collapsible sections). Keyed by the
// real catalog category keys (CAT.*) - each matches the section's function.
const CAT_ICON = {
  GENERAL: 'components',   // Chung
  BROWSER: 'appWindow',    // Trình duyệt
  WEB: 'cursorClick',      // Tương tác Web
  DATA: 'database',        // Dữ liệu
  FLOW: 'branch',          // Luồng điều khiển
  FILE: 'folder',          // Xử lý tệp & thư mục
  API: 'api',              // API
  AI: 'sparkles',          // AI
  OTHER: 'more',           // Khác
};

// AdsPower draws node icons as a SOFT tint square + the category-colored glyph
// (never a solid saturated fill). Build the soft background by appending an
// alpha byte to the 6-digit hex (≈14%).
const tint = (hex) => (typeof hex === 'string' && /^#[0-9a-fA-F]{6}$/.test(hex)) ? hex + '24' : 'rgba(100,116,139,.14)';

// Node icons share the app's signature 3-colour mixed gradient (the same blend
// used on the "Lưu"/toolbar buttons), with a white glyph on top.
const ICON_GRAD = 'linear-gradient(135deg, #88C4FF 0%, #6AA9FF 50%, #1D7BD8 100%)';
function iconBg() { return ICON_GRAD; }

let uid = 1;
const newNodeId = () => 'n' + (uid++) + Date.now().toString(36);

// ── Monaco Editor (lazy, vendored AMD build) ────────────────────────────────
// The "Chạy mã Javascript" / JSON body editors (`code` fields) mount a real
// Monaco editor for syntax highlighting on a WHITE surface (theme `vs`). Monaco
// is vendored under renderer/vendor/monaco/vs so the CSP `script-src 'self'`
// serves it; the AMD loader (window.require) is injected from index.html. If
// Monaco fails to load we fall back to the plain monospace textarea.
let _monacoPromise = null;
function loadMonaco() {
  if (_monacoPromise) return _monacoPromise;
  _monacoPromise = new Promise((resolve, reject) => {
    const amd = window.require;
    if (!amd || typeof amd.config !== 'function') { reject(new Error('AMD loader missing')); return; }
    try {
      // Same-origin worker → no blob, satisfies CSP `worker-src 'self'`.
      self.MonacoEnvironment = { getWorkerUrl: () => 'renderer/vendor/monaco/vs/base/worker/workerMain.js' };
      amd.config({ paths: { vs: 'renderer/vendor/monaco/vs' } });
      amd(['vs/editor/editor.main'], () => {
        window.monaco ? resolve(window.monaco) : reject(new Error('monaco global missing'));
      }, reject);
    } catch (e) { reject(e); }
  }).catch((e) => { _monacoPromise = null; throw e; });
  return _monacoPromise;
}
// Dispose any Monaco editors inside `container` before its DOM is torn down, so
// re-rendering the config drawer doesn't leak editor instances + their models.
function disposeCodeEditors(container) {
  if (!container) return;
  container.querySelectorAll('.rpa-monaco').forEach((m) => {
    if (m.__monacoEditor) { try { m.__monacoEditor.dispose(); } catch { /* ignore */ } m.__monacoEditor = null; }
  });
}
const newFlowId = () => 'f' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

// Flow store - persisted to disk through the main process (vt.flows.*). The
// renderer keeps a working copy in FLOWS that mirrors flows.json.
let FLOWS = [];
async function loadFlows() {
  try { FLOWS = (await window.vt?.flows?.list()) || []; }
  catch { FLOWS = []; }
}
// Trả { ok, code, status }. IPC flows:save nay trả envelope { ok, data, code, status }
// (remoteCall) nên ta biết được lỗi thiếu quyền để báo cho đúng.
async function persistFlow(flow) {
  let res;
  try { res = await window.vt?.flows?.save(flow); }
  catch (e) { return { ok: false, code: e && e.code, status: e && e.status }; }
  if (res && res.ok) { if (res.data) Object.assign(flow, res.data); return { ok: true }; }
  return { ok: false, code: res && res.code, status: res && res.status };
}
async function deleteFlow(id) {
  let res;
  try { res = await window.vt?.flows?.remove(id); }
  catch (e) { return { ok: false, code: e && e.code, status: e && e.status }; }
  return { ok: !!(res && res.ok), code: res && res.code, status: res && res.status };
}

export function render(ctx) {
  const host = el('div.rpa-host');
  ctx.container.appendChild(host);

  let winHandlers = [];
  function cleanup() {
    winHandlers.forEach(([evt, fn]) => window.removeEventListener(evt, fn));
    winHandlers = [];
  }

  // The RPA editor auto-collapses the sidebar to give the canvas more room. We
  // remember the rail state on entry so leaving the editor restores it (and we
  // never persist this transient collapse to the saved preference).
  let sidebarPrev = null;
  function collapseSidebarForEditor() {
    const api = window.__vtApp;
    if (!api || typeof api.setSidebarCollapsed !== 'function') return;
    if (sidebarPrev === null) sidebarPrev = !!api.isSidebarCollapsed?.();
    api.setSidebarCollapsed(true, false);
  }
  function restoreSidebarAfterEditor() {
    const api = window.__vtApp;
    if (sidebarPrev !== null && api && typeof api.setSidebarCollapsed === 'function') {
      api.setSidebarCollapsed(sidebarPrev, false);
    }
    sidebarPrev = null;
  }

  // The app header (#header-title) doubles as this view's title bar. In the flow
  // LIST it shows the plain page title "Quá trình"; inside the EDITOR it carries
  // the "Quay lại" back link + "Chỉnh sửa quy trình" title (AdsPower-style).
  function headerEl() { return document.getElementById('header-title'); }
  function restoreHeader() {
    const t = headerEl(); if (!t) return;
    t.classList.remove('is-flow');
    t.textContent = 'Quy trình';
  }
  // ------------------------------------------------- chặn thoát khi chưa lưu
  // openEditor() giữ trạng thái đồ thị trong scope riêng của nó, nên nó "đăng ký"
  // một cầu nối {isDirty, save} ra đây để nút "Quay lại" và router hỏi được. Rời
  // trình sửa (showFlowList) thì gỡ cầu nối, khỏi hỏi nhầm khi đang ở danh sách.
  let editorGuard = null;

  // Trả về Promise<boolean> = "được phép rời đi".
  async function confirmLeaveEditor() {
    const g = editorGuard;
    if (!g || !g.isDirty()) return true;
    const act = await confirmUnsavedDialog({
      message: t('Quy trình hiện tại chưa được lưu, bạn có chắc chắn thoát không?'),
      sub: t('Thoát sẽ không được lưu lại'),
    });
    if (act === 'stay') return false;
    if (act === 'discard') return true;
    // Lưu LỖI thì ở lại - thoát tiếp là mất trắng công của người dùng.
    try { return (await g.save()) !== false; } catch { return false; }
  }

  // Chỉnh sửa quy trình của MỘT kịch bản trên Chợ (mở từ trang "Quy trình đã đăng"):
  // ctx.param.marketEdit = { name, graph, onSave(graph)->bool }. Trình sửa mở thẳng
  // với đồ thị của kịch bản, khi lưu thì ghi NGƯỢC lên Chợ (không đụng flows.json);
  // "Quay lại" trả về trang Chợ thay vì danh sách quy trình cục bộ.
  const marketCtx = (ctx && ctx.param && ctx.param.marketEdit) || null;

  async function leaveEditor() {
    if (await confirmLeaveEditor()) {
      if (marketCtx) { editorGuard = null; ctx.navigate('script_store'); }
      else showFlowList();
    }
  }

  function setEditorHeader() {
    const t = headerEl(); if (!t) return;
    t.classList.add('is-flow');
    t.innerHTML = '';
    t.appendChild(el('button.rpa-back', { html: `${icon('chevron')}<span>Quay lại</span>`, onclick: leaveEditor }));
    t.appendChild(el('div.rpa-top-div'));
    t.appendChild(el('span.header-flow-title', { text: 'Chỉnh sửa quy trình' }));
  }

  // ============================================================ FLOW LIST
  // Faithful clone of AdsPower's "Quá trình" process-list page (v8.6.3): a single
  // toolbar row (Tạo quy trình • group filter • search • bulk tools • guide link),
  // a source-tab row (Tất cả nguồn / Do tôi tạo / Quy trình tải về), a select-all + counter
  // sub-row, then a responsive GRID of process cards (or the robot empty-state),
  // closed by a right-aligned pager. Nothing of the old table list survives.
  const GROUP_NONE = 'Chưa chia nhóm';
  const RPA_QUOTA = 3000;
  // "Quy trình" empty-state: a pumped-up automation ROBOT - arms thrown up in
  // triumph, a lightning bolt on its chest and energy sparks around it (hừng hực
  // khí thế). Fully theme-aware: line work is currentColor (follows the brand
  // accent) and every "card" surface uses `.vec-paper` so it lifts correctly on
  // the dark datagrid instead of a harsh pure-white shape.
  const RPA_EMPTY_SVG = `<svg viewBox="0 0 200 150" fill="none" xmlns="http://www.w3.org/2000/svg">
    <ellipse cx="100" cy="136" rx="44" ry="8" fill="currentColor" opacity=".08"/>
    <!-- antenna + spark -->
    <path d="M100 30v-7" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/>
    <circle cx="100" cy="18" r="4.5" fill="currentColor"/>
    <path d="M100 9v-4M109 13l3-3M91 13l-3-3" stroke="currentColor" stroke-width="2" stroke-linecap="round" opacity=".5"/>
    <!-- raised arms (triumphant) -->
    <path d="M76 96L59 72M124 96l17-24" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>
    <circle cx="57" cy="68" r="5" fill="currentColor" opacity=".9"/>
    <circle cx="143" cy="68" r="5" fill="currentColor" opacity=".9"/>
    <!-- energy sparks near the fists -->
    <path d="M49 60l3-4M47 70l-4-1M151 60l-3-4M153 70l4-1" stroke="currentColor" stroke-width="2" stroke-linecap="round" opacity=".5"/>
    <!-- ears / side pods -->
    <rect x="56" y="46" width="9" height="20" rx="4.5" fill="currentColor" opacity=".28"/>
    <rect x="135" y="46" width="9" height="20" rx="4.5" fill="currentColor" opacity=".28"/>
    <!-- head -->
    <rect x="64" y="30" width="72" height="50" rx="16" fill="currentColor" opacity=".10"/>
    <rect x="64" y="30" width="72" height="50" rx="16" class="vec-paper" stroke="currentColor" stroke-opacity=".4" stroke-width="2.4"/>
    <!-- face screen -->
    <rect x="73" y="40" width="54" height="30" rx="8" fill="currentColor" opacity=".07"/>
    <circle cx="87" cy="52" r="5.5" fill="currentColor" opacity=".85"/>
    <circle cx="113" cy="52" r="5.5" fill="currentColor" opacity=".85"/>
    <!-- big open grin -->
    <path d="M86 62q14 13 28 0a2 2 0 0 0-2-3H88a2 2 0 0 0-2 3z" fill="currentColor" opacity=".55"/>
    <!-- neck -->
    <path d="M100 80v6" stroke="currentColor" stroke-width="2.4"/>
    <!-- body -->
    <rect x="72" y="86" width="56" height="36" rx="12" fill="currentColor" opacity=".08"/>
    <rect x="72" y="86" width="56" height="36" rx="12" class="vec-paper" stroke="currentColor" stroke-opacity=".4" stroke-width="2.4"/>
    <!-- lightning bolt (energy) -->
    <path d="M104 91l-11 15h7l-5 13 14-18h-7l6-10z" fill="currentColor" opacity=".6"/>
    <!-- motion lines -->
    <path d="M40 98h10M43 108h8M160 98h-10M157 108h-8" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" opacity=".3"/>
  </svg>`;

  async function showFlowList() {
    editorGuard = null;   // rời trình sửa → không còn gì để hỏi
    cleanup();
    restoreSidebarAfterEditor();
    restoreHeader();
    clear(host);
    // Quyền của tôi ở workspace hiện hành (server vẫn enforce thật - đây chỉ để UX
    // ẩn nút). Nhân viên chỉ có 'automation:run' → chỉ thấy + chạy, không tạo/sửa/xoá.
    await loadPermissions();
    const canCreate = can('automation:create');
    const canEdit = can('automation:edit');
    const canDelete = can('automation:delete');
    const canShare = can('automation:share');
    await loadFlows();

    let search = '';
    let tab = 'all';                 // all | mine | downloaded
    let group = '';                  // '' = Tất cả ; GROUP_NONE = Chưa chia nhóm
    let pageNo = 1;
    let pageSize = 50;
    const selected = new Set();

    const groupOf = (a) => a.group || GROUP_NONE;
    // Phân loại NGUỒN quy trình:
    //   • "Do tôi tạo" (mine)          = tạo tại chỗ (createFlow/duplicate/import) → source !== 'market'.
    //   • "Quy trình tải về" (downloaded) = cài từ Chợ → install ghi source:'market' (marketplace.routes).
    // Bug cũ: tab lọc theo source==='received' (không ai set) nên hồ sơ tải về LỌT sang
    // "Do tôi tạo" và tab tải về luôn rỗng. Nay khớp đúng cờ 'market'.
    const isDownloaded = (a) => a.source === 'market';
    function visibleRows() {
      let rows = FLOWS.slice();
      if (tab === 'downloaded') rows = rows.filter(isDownloaded);
      else if (tab === 'mine') rows = rows.filter((a) => !isDownloaded(a));
      if (group) rows = rows.filter((a) => groupOf(a) === group);
      if (search) rows = rows.filter((a) => (a.name || '').toLowerCase().includes(search.toLowerCase()));
      // pinned first (Ghim đầu trang), then most-recently updated
      rows.sort((x, y) => (y.pinnedAt || 0) - (x.pinnedAt || 0) || (y.updatedAt || 0) - (x.updatedAt || 0));
      return rows;
    }

    async function createFlow() {
      // Gói Free chỉ được tối đa 5 quy trình (chống spam, giảm phình metadata). Chặn SỚM
      // bằng modal nâng cấp; server vẫn enforce thật (QUOTA_EXCEEDED) nếu client lách.
      await loadPlanFeatures();
      const pf = planFeaturesSync();
      const isFree = pf && pf.planCode === 'free';
      if (isFree && FLOWS.length >= FREE_MAX_FLOWS) {
        openUpgradeModal({
          title: tf('Gói Free chỉ tạo tối đa {0} quy trình', FREE_MAX_FLOWS),
          onUpgrade: () => {
            const nav = window.__vtApp && window.__vtApp.navigate;
            if (typeof nav === 'function') nav('upgrade');
          },
        });
        return;
      }
      // Name + group, same design as the editor's "Chỉnh sửa thông tin" dialog
      // (right-aligned label column, full-width controls, creatable group select).
      const nameIn = el('input.input', { maxlength: 100, placeholder: 'Nhập tên quy trình' });
      const nameCount = el('span.rpa-fi-count', { text: '0/100' });
      nameIn.addEventListener('input', () => { nameCount.textContent = `${nameIn.value.length}/100`; });

      let groupVal = '';
      const groupNames = Array.from(new Set(FLOWS.map((f) => f.group).filter((g) => g && g !== GROUP_NONE)));
      const groupOpts = [{ value: '', label: 'Chưa chia nhóm' }].concat(groupNames.map((g) => ({ value: g, label: g })));
      const groupSelIn = customSelect(groupOpts, {
        value: '', placeholder: 'Hãy chọn nhóm.', width: '100%', creatable: true,
        createPlaceholder: 'Hãy nhập tên nhóm',
        onChange: (v) => { groupVal = v; },
        onCreate: (name) => { groupVal = name; return { value: name, label: name }; },
      });

      const okBtn = el('button.btn.primary.rpa-fi-ok', { type: 'button', text: 'OK', onclick: async () => {
        const nm = nameIn.value.trim();
        if (!nm) { toast('Vui lòng nhập tên quy trình', 'err'); return; }
        const a = { id: newFlowId(), name: nm, version: '1.0', remark: '', source: 'mine', group: groupVal || GROUP_NONE, graph: { variables: [], settings: {}, nodes: [], connections: [] } };
        const res = await persistFlow(a);
        if (!res.ok) { toast(describeError(res, 'Tạo quy trình thất bại'), 'err'); return; }
        FLOWS.unshift(a);
        closeModal();
        openEditor(a);
      } });
      const cancelBtn = el('button.btn.rpa-fi-cancel', { type: 'button', text: 'Hủy', onclick: closeModal });

      const row = (label, control, required) => el('div.rpa-fi-row', {}, [
        el('div.rpa-fi-label', {}, [required ? el('span.req', { text: '*' }) : null, document.createTextNode(label)]),
        el('div.rpa-fi-ctrl', {}, control),
      ]);

      openModal({
        title: 'Tạo quy trình', width: 676,
        body: [
          el('div.rpa-fi', {}, [
            row('Tên quy trình', [nameIn, nameCount], true),
            row('Nhóm', [groupSelIn]),
            el('div.rpa-fi-foot', {}, [el('div.rpa-fi-acts', {}, [okBtn, cancelBtn])]),
          ]),
        ],
      });
    }

    async function duplicateFlow(a) {
      const g = typeof a.graph === 'string' ? a.graph : JSON.parse(JSON.stringify(a.graph || {}));
      const copy = { id: newFlowId(), name: `${a.name} - Copy`, version: a.version || '1.0', remark: a.remark || '', source: 'mine', group: groupOf(a), graph: g };
      const res = await persistFlow(copy);
      if (!res.ok) { toast(describeError(res, 'Tạo bản sao thất bại'), 'err'); return; }
      FLOWS.unshift(copy);
      render();
      toast('Đã tạo bản sao quy trình');
    }

    async function togglePin(a) {
      const prev = a.pinnedAt;
      a.pinnedAt = a.pinnedAt ? 0 : Date.now();
      const res = await persistFlow(a);
      if (!res.ok) { a.pinnedAt = prev; toast(describeError(res, 'Cập nhật ghim thất bại'), 'err'); return; }
      render();
      toast(a.pinnedAt ? 'Đã ghim lên đầu trang' : 'Đã bỏ ghim');
    }

    // "Xuất" từ thẻ danh sách: ghi graph của quy trình ra tệp .json (cùng định dạng
    // với export trong editor: { name, version, graph }) nên nhập lại được bình thường.
    function exportFlowFile(a) {
      // Chốt chặn: quy trình TẢI VỀ từ Chợ không được xuất .json (chống bán chợ đen).
      if (isDownloaded(a)) { toast('Quy trình tải từ Chợ không được xuất', 'err'); return; }
      try {
        const graph = typeof a.graph === 'string' ? JSON.parse(a.graph || '{}') : (a.graph || {});
        const payload = { name: a.name, version: a.version || '1.0', graph };
        const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = (a.name || 'quy-trinh').replace(/[^\w\-]+/g, '_') + '.json';
        document.body.appendChild(link); link.click(); link.remove();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
        toast('Đã xuất quy trình', 'ok');
      } catch { toast('Xuất quy trình thất bại', 'err'); }
    }

    function removeFlows(list) {
      if (!list.length) return;
      const names = list.length === 1 ? `"${list[0].name}"` : `${list.length} ${t('quy trình')}`;
      confirmDialog({
        title: 'Xoá quy trình', danger: true, confirmLabel: 'Xoá', message: tf('Xoá {0}?', names),
        onConfirm: async () => {
          const removed = [];
          let lastErr = null;
          for (const a of list) {
            const res = await deleteFlow(a.id);
            if (res.ok) { removed.push(a); selected.delete(a.id); }
            else lastErr = res;
          }
          if (removed.length) FLOWS = FLOWS.filter((x) => !removed.includes(x));
          render();
          if (lastErr) toast(describeError(lastErr, 'Xoá quy trình thất bại'), 'err');
          else if (removed.length) toast('Đã xoá quy trình', 'ok');
        },
      });
    }

    // -- toolbar (row 1) -----------------------------------------------------
    // Chỉ người có quyền tạo mới thấy nút "Tạo quy trình" (nhân viên chạy-thôi thì ẩn).
    const createBtn = canCreate
      ? el('button.rpa-create', { html: `${icon('plusCircle')}<span>Tạo quy trình</span>`, onclick: createFlow })
      : null;
    const toolbarGroupNames = Array.from(new Set(FLOWS.map((a) => a.group).filter((g) => g && g !== GROUP_NONE)));
    const groupFilterOpts = [{ value: '', label: 'Tất cả' }, { value: GROUP_NONE, label: GROUP_NONE }]
      .concat(toolbarGroupNames.map((g) => ({ value: g, label: g })));
    const groupSel = customSelect(groupFilterOpts, {
      value: group, width: 150, height: 41, onChange: (v) => { group = v; pageNo = 1; render(); },
    });
    const searchBox = el('div.rpa-search', {}, [
      el('span.rpa-search-ico', { html: icon('search') }),
      el('input.rpa-search-input', { placeholder: 'Tìm kiếm quy trình...', value: search, oninput: (e) => { search = e.target.value.trim(); pageNo = 1; render(); } }),
    ]);
    const tool = (ic, title, fn) => iconBtn(ic, { title, onclick: () => { const sel = FLOWS.filter((a) => selected.has(a.id)); if (!sel.length) { toast('Hãy chọn ít nhất một quy trình', 'warn'); return; } fn(sel); } });
    const tools = el('div.rpa-tools', {}, [
      canEdit ? tool('importFlow', 'Di chuyển', () => toast('Tính năng di chuyển nhóm đang phát triển')) : null,
      tool('swap', 'Lấy quy trình', () => toast('Tính năng lấy quy trình đang phát triển')),
      canShare ? tool('share', 'Chia sẻ', () => toast('Tính năng chia sẻ đang phát triển')) : null,
      canDelete ? tool('trash', 'Xoá', (sel) => removeFlows(sel)) : null,
    ]);
    // Góc phải thanh công cụ: link "Hướng dẫn sử dụng" (gạch chân, màu brand) mở tài liệu
    // RPA online ở trình duyệt ngoài. (Trước đây link này chỉ bắn toast rỗng; nay trỏ thật
    // tới cgtdev.space/docs.) margin-left:auto trong CSS đẩy nó về sát mép phải cùng hàng.
    const guideIcon = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M0 0h24v24H0z" fill="none"/><path fill="currentColor" d="M15 4H6v16h12V7h-3zM6 2h10l4 4v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2m2 9h8v2H8zm0 4h8v2H8z"/></svg>';
    const guideLink = el('a.rpa-guide-link', {
      html: `${guideIcon}<span>${t('Hướng dẫn sử dụng')}</span>`,
      onclick: () => { try { window.vt.shell.openExternal('https://cgtdev.space/docs/'); } catch { /* ignore */ } },
    });
    const toolbar = el('div.rpa-toolbar', {}, [createBtn, groupSel, searchBox, tools, guideLink]);

    // -- source tabs (row 2) -------------------------------------------------
    const tabsRow = el('div.rpa-tabs');
    function renderTabs() {
      clear(tabsRow);
      const dlCount = FLOWS.filter(isDownloaded).length;
      const counts = { all: FLOWS.length, mine: FLOWS.length - dlCount, downloaded: dlCount };
      [['all', 'Tất cả nguồn'], ['mine', 'Do tôi tạo'], ['downloaded', 'Quy trình tải về']].forEach(([k, label]) => {
        const btn = el('button.rpa-tab' + (tab === k ? '.is-active' : ''), {
          onclick: () => { tab = k; pageNo = 1; selected.clear(); render(); },
        }, [
          document.createTextNode(label),
          el('span.rpa-tab-count', { text: String(counts[k]) }),
        ]);
        tabsRow.appendChild(btn);
      });
    }

    // -- select-all + counter (row 3) ---------------------------------------
    const subbar = el('div.rpa-subbar');

    // -- body (cards / empty) + pager ---------------------------------------
    const body = el('div.rpa-list-body');
    // pager lives OUTSIDE the bordered list card, below it
    const pagerEl = el('div.rpa-pager-wrap');

    // Vietnamese relative time ("26 ngày trước") for the "Cập nhật cuối" stamp.
    function relTimeVi(ms) {
      if (!ms) return '-';
      const sec = Math.floor((Date.now() - ms) / 1000);
      if (sec < 60) return t('vừa xong');
      const min = Math.floor(sec / 60); if (min < 60) return `${min} ${t('phút trước')}`;
      const hr = Math.floor(min / 60); if (hr < 24) return `${hr} ${t('giờ trước')}`;
      const day = Math.floor(hr / 24); if (day < 30) return `${day} ${t('ngày trước')}`;
      const mo = Math.floor(day / 30); if (mo < 12) return `${mo} ${t('tháng trước')}`;
      return `${Math.floor(mo / 12)} ${t('năm trước')}`;
    }
    // Absolute "Ngày tạo" stamp → DD/MM/YYYY HH:MM
    function fmtDateTime(ms) {
      if (!ms) return '-';
      const d = new Date(ms); const p = (n) => String(n).padStart(2, '0');
      return `${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()} ${p(d.getHours())}:${p(d.getMinutes())}`;
    }

    function renderCard(a) {
      const checked = selected.has(a.id);
      const cb = el('input.rpa-check', { type: 'checkbox', checked });
      cb.addEventListener('change', () => { if (cb.checked) selected.add(a.id); else selected.delete(a.id); renderSubbar(); });
      const moreBtn = iconBtn('moreVertical');
      // Menu chỉ liệt kê thao tác mà tôi có quyền. Nhân viên chạy-thôi chỉ thấy
      // "Chỉnh sửa"/"Xem sơ đồ"; không Copy/Ghim/Xuất/Xoá.
      hoverMenu(moreBtn, () => {
        // Quy trình tải từ Chợ: CHO PHÉP chỉnh sửa + lưu bình thường, chỉ KHOÁ MỀM "Xuất"
        // (chống dump graph plaintext ra .json để bán chợ đen). "Đăng chợ" khoá ở toolbar
        // editor (đã ẩn cho flow market). Mục "Xuất" bị khoá vẫn hiện nhưng mờ + con trỏ cấm.
        const lockExport = isDownloaded(a);
        const items = [
          { label: canEdit ? 'Chỉnh sửa' : 'Xem sơ đồ', icon: 'edit', onClick: () => openEditor(a) },
        ];
        if (canCreate) items.push({ label: 'Copy mẫu', icon: 'copy', onClick: () => duplicateFlow(a) });
        if (canEdit) items.push({ label: a.pinnedAt ? 'Bỏ ghim đầu trang' : 'Ghim đầu trang', icon: 'tag', onClick: () => togglePin(a) });
        items.push(lockExport
          ? { label: 'Xuất', icon: 'exportFlow', disabled: true }
          : { label: 'Xuất', icon: 'exportFlow', onClick: () => exportFlowFile(a) });
        if (canDelete) { items.push('-'); items.push({ label: 'Xoá', icon: 'trash', danger: true, onClick: () => removeFlows([a]) }); }
        return items;
      });
      const sep = () => el('span.rpa-meta-sep', { text: '|' });
      return el('div.rpa-row' + (checked ? '.is-sel' : ''), {}, [
        cb,
        el('div.rpa-row-body', {}, [
          el('div.rpa-row-top', {}, [
            el('div.rpa-row-name', { text: a.name, title: a.name, onclick: () => openEditor(a) }),
            a.pinnedAt ? el('span.rpa-row-pin', { html: icon('tag'), title: 'Đã ghim' }) : null,
          ]),
          el('div.rpa-row-meta', {}, [
            el('span.rpa-meta-time', { text: `${t('Cập nhật cuối')} ${relTimeVi(a.updatedAt)}` }),
            sep(),
            el('span.rpa-meta-time', { text: `${t('Ngày tạo')} ${fmtDateTime(a.createdAt)}` }),
            sep(),
            el('span.rpa-meta-group', { text: groupOf(a) }),
            sep(),
            el('a.rpa-row-diagram', { html: `${icon('diagram')}<span>Sơ đồ</span>`, title: 'Mở sơ đồ quy trình', onclick: () => openEditor(a) }),
          ]),
        ]),
        moreBtn,
      ]);
    }

    function renderSubbar() {
      clear(subbar);
      const rows = visibleRows();
      const pageRows = rows.slice((pageNo - 1) * pageSize, pageNo * pageSize);
      const allChecked = pageRows.length > 0 && pageRows.every((a) => selected.has(a.id));
      const selAll = el('input.rpa-check', { type: 'checkbox', checked: allChecked });
      selAll.addEventListener('change', () => { pageRows.forEach((a) => { if (selAll.checked) selected.add(a.id); else selected.delete(a.id); }); render(); });
      subbar.appendChild(el('label.rpa-selall', {}, [selAll, el('span', { text: 'Chọn tất cả' })]));
    }

    function renderBody() {
      clear(body);
      clear(pagerEl);
      const rows = visibleRows();
      if (!rows.length) {
        body.appendChild(el('div.rpa-empty', {}, [
          el('div.rpa-empty-art', { html: RPA_EMPTY_SVG }),
          (search || tab === 'downloaded' || group || !canCreate)
            ? el('div.rpa-empty-txt', { text: 'Không có dữ liệu' })
            : el('button.rpa-create.rpa-empty-create', { html: `${icon('plusCircle')}<span>Tạo một quy trình</span>`, onclick: createFlow }),
        ]));
        return;
      }
      const totalPages = Math.max(1, Math.ceil(rows.length / pageSize));
      if (pageNo > totalPages) pageNo = totalPages;
      const pageRows = rows.slice((pageNo - 1) * pageSize, pageNo * pageSize);
      const list = el('div.rpa-rows');
      pageRows.forEach((a) => list.appendChild(renderCard(a)));
      body.appendChild(list);

      // pager - matches the "Hồ sơ" (profiles) page layout
      const total = rows.length;
      const from = total === 0 ? 0 : (pageNo - 1) * pageSize + 1;
      const to = Math.min(pageNo * pageSize, total);
      const sizeSel = pageSizeSelect([20, 50, 100], { value: pageSize, onChange: (v) => { pageSize = v || 50; pageNo = 1; render(); } });
      const prev = el('button.icon-btn', { html: icon('chevron'), style: { transform: 'rotate(180deg)' }, onclick: () => { if (pageNo > 1) { pageNo--; render(); } } });
      const next = el('button.icon-btn', { html: icon('chevron'), onclick: () => { if (pageNo < totalPages) { pageNo++; render(); } } });
      const pageNums = el('div.page-nums');
      for (let i = 0; i < totalPages; i++) {
        if (totalPages > 7 && i > 1 && i < totalPages - 2 && Math.abs(i - (pageNo - 1)) > 1) {
          if (i === 2 || i === totalPages - 3) pageNums.appendChild(el('span.muted', { text: '…' }));
          continue;
        }
        pageNums.appendChild(el('button.page-num' + (i === pageNo - 1 ? '.active' : ''), { text: String(i + 1), onclick: () => { pageNo = i + 1; render(); } }));
      }
      pagerEl.appendChild(el('div.pager', {}, [
        el('span.muted', { text: 'Số dòng mỗi trang:' }),
        sizeSel,
        el('span.muted', { text: total === 0 ? `0 ${t('trên')} 0` : `${from}-${to} ${t('trên')} ${total}` }),
        prev,
        pageNums,
        next,
      ]));
    }

    function render() {
      // keep the group filter trigger in sync
      renderTabs();
      renderSubbar();
      renderBody();
    }

    const page = el('div.rpa-page', {}, [toolbar, el('div.rpa-list-card', {}, [tabsRow, subbar, body]), pagerEl]);
    host.appendChild(page);
    render();
  }

  // ============================================================ CONFIG (downloaded)
  // Kịch bản tải từ Chợ (source==='market') KHÔNG mở thẳng trình sửa. Bấm vào ⇒ màn
  // CẤU HÌNH có tab control DÙNG LẠI Y HỆT "Chỉnh sửa nhiệm vụ" (task_edit.js): thẻ
  // header .te-header + .te-tabcard(.rpp-form.rpp-modal) + .rpp-tabs/.rpp-tabpanel,
  // biến quy trình render bằng ô .rpp-invar. Tab: "Đầu vào" (điền giá trị biến) +
  // "Hướng dẫn sử dụng" (readme kèm khi cài). Nút "Chỉnh sửa quy trình" riêng mới mở
  // editor. Chỉnh biến rồi "Lưu lại" ⇒ persist, giữ nguyên nodes/connections/settings.
  function openConfig(flow) {
    cleanup();
    restoreSidebarAfterEditor();     // config là trang thường, KHÔNG thu gọn sidebar
    clear(host);

    // Header app: nút Quay lại | "Cấu hình quy trình" (giống setEditorHeader task_edit).
    const th = headerEl();
    if (th) {
      th.classList.add('is-flow');
      th.innerHTML = '';
      th.appendChild(el('button.rpa-back', { html: `${icon('chevron')}<span>Quay lại</span>`, onclick: showFlowList }));
      th.appendChild(el('div.rpa-top-div'));
      th.appendChild(el('span.header-flow-title', { text: 'Cấu hình quy trình' }));
    }

    // Sửa biến trên BẢN SAO (không đụng flow.graph tới khi bấm Lưu).
    const g = (flow.graph && typeof flow.graph === 'object') ? flow.graph : {};
    const vars = Array.isArray(g.variables) ? g.variables.map((v) => ({ ...v })) : [];

    // ---- LƯU TỰ ĐỘNG: không còn nút "Lưu lại". Mỗi lần người dùng nhập vào ô nào là
    // gọi scheduleSave() → chờ 500ms yên (debounce) rồi ghi lên server. Chỉ báo lỗi
    // (toast), lưu thành công thì IM LẶNG để không phiền khi gõ.
    let savingCfg = false, saveTimer = null, saveAgain = false;
    async function saveConfig() {
      if (savingCfg) { saveAgain = true; return; }   // đang lưu → xếp lượt sau
      savingCfg = true;
      flow.graph = {
        ...g,
        // Giữ nguyên cờ `local` (biến làm việc) để lần lưu này không biến chúng
        // thành tham số đầu vào.
        variables: vars.map((v) => ({ name: v.name, type: v.type || 'String', value: v.value != null ? v.value : '', desc: v.desc || '', label: v.label ? v.label : undefined, local: v.local ? true : undefined })),
      };
      const res = await persistFlow(flow);
      savingCfg = false;
      if (!res.ok) toast(describeError(res, 'Lưu cấu hình thất bại'), 'err');
      if (saveAgain) { saveAgain = false; saveConfig(); }  // gộp thay đổi trong lúc đang lưu
    }
    function scheduleSave() { clearTimeout(saveTimer); saveTimer = setTimeout(saveConfig, 500); }
    const soon = (label) => toast(tf('Tính năng "{0}" đang phát triển', label));

    // ---- CÁC DIALOG của thanh công cụ (đã soi từng thành phần trong MKTLogin 2.1.2 và
    // clone y hệt). Mọi thứ ghi thẳng vào `g` (config/resources/table) rồi scheduleSave()
    // → lưu tự động, khớp mô hình lưu-tự-động của màn cấu hình.
    // Tài nguyên (folder): danh sách cặp KHÓA / GIÁ TRỊ (Giá trị gõ tay hoặc tải tệp lên).
    // Soi MKTLogin: mỗi dòng = ô "Khóa" + ô "Giá trị" (có nút upload ↑ bên phải) + nút ✕.
    function openResourcesDlg() {
      const list = Array.isArray(g.resources)
        ? g.resources.map((r) => (r && typeof r === 'object' ? { key: r.key || '', value: r.value || '' } : { key: '', value: String(r || '') }))
        : [];
      const pickFile = (cb) => { const fi = document.createElement('input'); fi.type = 'file'; fi.addEventListener('change', () => { const f = fi.files && fi.files[0]; if (f) cb(f.path || f.name); }); fi.click(); };
      const rows = el('div.rpa-cfg-dlg-rows');
      const render = () => {
        rows.innerHTML = '';
        if (!list.length) { rows.appendChild(el('div.rpa-cfg-dlg-empty', { text: 'Không có dữ liệu' })); return; }
        list.forEach((r, i) => {
          const keyInp = el('input.rpa-cfg-dlg-inp.k', { type: 'text', value: r.key, placeholder: 'Khóa' });
          keyInp.addEventListener('input', () => { r.key = keyInp.value; });
          const valInp = el('input.rpa-cfg-dlg-inp', { type: 'text', value: r.value, placeholder: 'Giá trị' });
          valInp.addEventListener('input', () => { r.value = valInp.value; });
          const up = el('button.rpa-cfg-dlg-up', { type: 'button', html: icon('upload'), title: 'Tải tệp lên', onclick: () => pickFile((p) => { r.value = p; valInp.value = p; }) });
          rows.appendChild(el('div.rpa-cfg-dlg-row', {}, [
            keyInp,
            el('div.rpa-cfg-dlg-valwrap', {}, [valInp, up]),
            el('button.rpa-cfg-dlg-del', { type: 'button', html: icon('trash'), title: 'Xoá', onclick: () => { list.splice(i, 1); render(); } }),
          ]));
        });
      };
      render();
      openModal({
        title: 'Tài nguyên', width: 620,
        body: el('div.rpa-cfg-dlg', {}, [
          el('div.rpa-cfg-dlg-head', {}, [
            el('span', { text: 'Tài nguyên' }),
            el('button.rpa-cfg-dlg-add', { type: 'button', html: `${icon('plus')}<span>Thêm</span>`, onclick: () => { list.push({ key: '', value: '' }); render(); } }),
          ]),
          rows,
        ]),
        footer: [
          el('button.btn', { text: 'Đóng', onclick: () => closeModal() }),
          el('button.btn.primary', { text: 'Xác nhận', onclick: () => { g.resources = list.filter((r) => r.key !== '' || r.value !== ''); scheduleSave(); closeModal(); } }),
        ],
      });
    }

    // Bảng (table): mỗi cột = TÊN CỘT + KIỂU (Any/Text/Number/Boolean/Array) + nút ✕.
    // Soi MKTLogin: ô "Tên cột" + nút "Thêm" ở trên; mỗi cột có dropdown kiểu dữ liệu.
    const COL_TYPES = ['Any', 'Text', 'Number', 'Boolean', 'Array'];
    function openTableDlg() {
      const cols = Array.isArray(g.tableColumns)
        ? g.tableColumns.map((c) => (c && typeof c === 'object' ? { name: c.name || '', type: c.type || 'Text' } : { name: String(c || ''), type: 'Text' }))
        : [];
      const rows = el('div.rpa-cfg-dlg-rows');
      const render = () => {
        rows.innerHTML = '';
        if (!cols.length) { rows.appendChild(el('div.rpa-cfg-dlg-empty', { text: 'Không có dữ liệu' })); return; }
        cols.forEach((c, i) => {
          const nameInp = el('input.rpa-cfg-dlg-inp', { type: 'text', value: c.name, placeholder: 'Tên cột' });
          nameInp.addEventListener('input', () => { c.name = nameInp.value; });
          rows.appendChild(el('div.rpa-cfg-dlg-row', {}, [
            nameInp,
            customSelect(COL_TYPES, { value: c.type || 'Text', width: 150, onChange: (v) => { c.type = v; } }),
            el('button.rpa-cfg-dlg-del', { type: 'button', html: icon('trash'), title: 'Xoá', onclick: () => { cols.splice(i, 1); render(); } }),
          ]));
        });
      };
      render();
      const addInp = el('input.rpa-cfg-dlg-inp', { type: 'text', placeholder: 'Tên cột' });
      const addCol = () => { const v = addInp.value.trim(); if (!v) return; if (cols.some((c) => c.name === v)) { toast('Cột đã tồn tại', 'err'); return; } cols.push({ name: v, type: 'Text' }); addInp.value = ''; render(); };
      addInp.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); addCol(); } });
      openModal({
        title: 'Bảng', width: 620,
        body: el('div.rpa-cfg-dlg', {}, [
          el('div.rpa-cfg-dlg-head', {}, [addInp, el('button.rpa-cfg-dlg-add.dashed', { type: 'button', text: 'Thêm', onclick: addCol })]),
          rows,
        ]),
        footer: [
          el('button.btn', { text: 'Đóng', onclick: () => closeModal() }),
          el('button.btn.primary', { text: 'Xác nhận', onclick: () => { g.tableColumns = cols.filter((c) => c.name !== ''); scheduleSave(); closeModal(); } }),
        ],
      });
    }

    // Cấu hình (bánh răng): "Cấu hình quy trình" - kích thước màn hình cố định (ĐÃ BỎ 2 TOGGLE).
    function openProcessCfgDlg() {
      const c = (g.config && typeof g.config === 'object') ? { ...g.config } : {};
      const num = (k, def, label) => {
        const inp = el('input.rpa-cfg-dlg-inp', { type: 'number', value: c[k] != null ? c[k] : def });
        inp.addEventListener('input', () => { c[k] = inp.value; });
        return el('label.rpa-cfg-dlg-field', {}, [el('span', { text: label }), inp]);
      };
      openModal({
        title: 'Cấu hình quy trình', width: 560,
        body: el('div.rpa-cfg-dlg', {}, [
          el('div.rpa-cfg-dlg-grid', {}, [num('screenW', 500, 'Screen Width'), num('screenH', 640, 'Sreen Height'), num('scale', 0.8, 'Scale')]),
        ]),
        footer: [
          el('button.btn', { text: 'Đóng', onclick: () => closeModal() }),
          el('button.btn.primary', { text: 'Lưu', onclick: () => { g.config = c; scheduleSave(); closeModal(); } }),
        ],
      });
    }

    // ---- Nhật ký debug: panel neo đáy view (clone y hệt log dock ở "chỉnh sửa quy trình").
    const cfgLogEmptyState = () => el('div.rpa-logdock-empty', {}, [
      el('div.rpa-empty-ico', { html: icon('automation') }),
      el('div', { text: 'Chưa có nhật ký. Nhật ký sẽ hiển thị khi bạn chạy quy trình.' }),
    ]);
    const cfgLogBody = el('div.rpa-logdock-body', {}, [cfgLogEmptyState()]);
    const cfgLogSN = el('span.rpa-logdock-sn');
    let cfgLogBig = false;
    const cfgLogExpandBtn = el('button.rpa-logdock-btn', { html: icon('expandDiag'), title: 'Mở rộng' });
    const cfgLogDock = el('div.rpa-logdock.rpa-cfg-logdock', {}, [
      el('div.rpa-logdock-head', {}, [
        el('span.rpa-logdock-title', { text: 'Nhật ký debug' }),
        cfgLogSN,
        el('div.rpa-logdock-tools', {}, [
          cfgLogExpandBtn,
          el('button.rpa-logdock-btn', { html: icon('clearLog'), title: 'Dọn nhật ký', onclick: () => cfgResetLog() }),
          el('button.rpa-logdock-btn', { html: icon('close'), title: 'Đóng', onclick: () => toggleCfgLog(false) }),
        ]),
      ]),
      cfgLogBody,
    ]);
    function cfgResetLog() { clear(cfgLogBody); cfgLogBody._list = null; cfgLogBody.appendChild(cfgLogEmptyState()); }
    cfgLogExpandBtn.onclick = () => { cfgLogBig = !cfgLogBig; cfgLogDock.classList.toggle('big', cfgLogBig); cfgLogExpandBtn.title = cfgLogBig ? 'Thu nhỏ' : 'Mở rộng'; };
    function toggleCfgLog(force) {
      const on = force == null ? !cfgLogDock.classList.contains('open') : !!force;
      cfgLogDock.classList.toggle('open', on);
      if (on) cfgLogSN.textContent = `Log (Process: ${flow.name || '-'}, Serial number: ${flow.id || '-'})`;
    }
    function cfgClearLog() { clear(cfgLogBody); cfgLogBody._list = el('div.rpa-logdock-list'); cfgLogBody.appendChild(cfgLogBody._list); }
    function cfgFmtTs(t) { const p = (n) => String(n).padStart(2, '0'); return `[ ${t.getFullYear()}-${p(t.getMonth() + 1)}-${p(t.getDate())} ${p(t.getHours())}:${p(t.getMinutes())}:${p(t.getSeconds())} ]`; }
    function cfgBuildMsg(text) {
      const cell = el('span.rpa-log-msg'); const str = String(text || '');
      const re = /(https?:\/\/[^\s"'<>]+)/g; let last = 0, m;
      while ((m = re.exec(str)) !== null) {
        if (m.index > last) cell.appendChild(document.createTextNode(str.slice(last, m.index)));
        cell.appendChild(el('span.rpa-log-link', { text: m[0] })); last = m.index + m[0].length;
      }
      if (last < str.length) cell.appendChild(document.createTextNode(str.slice(last)));
      return cell;
    }
    function cfgAppendLog(entry) {
      if (!entry) return; if (!cfgLogBody._list) cfgClearLog();
      const t = entry.ts ? new Date(entry.ts) : new Date();
      const row = el('div.rpa-logrow.' + (entry.level || 'info'), {}, [
        el('span.rpa-log-ts', { text: cfgFmtTs(t) }),
        ...(entry.title ? [el('span.rpa-log-node', { text: entry.title })] : []),
        cfgBuildMsg(entry.msg),
      ]);
      cfgLogBody._list.appendChild(row); cfgLogBody.scrollTop = cfgLogBody.scrollHeight;
    }
    function cfgAppendSummary(ms) {
      if (!cfgLogBody._list) return;
      const secs = Math.max(0, ms) / 1000;
      const human = secs < 60 ? tf('{0} giây', secs.toFixed(secs < 10 ? 2 : 1)) : tf('{0} phút {1} giây', Math.floor(secs / 60), Math.round(secs % 60));
      cfgLogBody._list.appendChild(el('div.rpa-log-summary', { text: tf('Tổng thời gian chạy: {0}', human) }));
      cfgLogBody.scrollTop = cfgLogBody.scrollHeight;
    }

    // Chạy: chạy quy trình tải về trên hồ sơ được chọn (dùng lại rpa.run + stream log như graph editor).
    let cfgRunUnsub = null;
    async function runConfigFlow(profile) {
      // Truyền ĐỦ vars (kể cả biến làm việc) - chỉ phần HIỂN THỊ ô nhập mới lọc.
      const graph = { ...g, variables: vars.map((v) => ({ name: v.name, type: v.type || 'String', value: v.value != null ? v.value : '', desc: v.desc || '', local: v.local ? true : undefined })) };
      const realNodes = Array.isArray(graph.nodes) ? graph.nodes.filter((n) => n.type !== 'start') : [];
      if (!realNodes.length) { toast('Quy trình trống', 'err'); return; }
      const pid = profile.id != null ? profile.id : profile.profileId;
      const runId = 'run_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
      toggleCfgLog(true);
      cfgClearLog();
      if (cfgRunUnsub) { try { cfgRunUnsub(); } catch { /* ignore */ } cfgRunUnsub = null; }
      try { cfgRunUnsub = window.vt?.rpa?.onLog(runId, (entry) => cfgAppendLog(entry)); } catch { /* ignore */ }
      const startedAt = Date.now();
      try {
        // debug: true → CHẠY THỬ, không đồng bộ dữ liệu hồ sơ lên/xuống đám mây.
        const res = await window.vt?.rpa?.run({ runId, profileId: pid, graph, flowName: flow.name, flowId: flow.id, debug: true });
        if (res && res.ok) toast('Quy trình hoàn tất', 'ok');
        else if (res && res.stopped) toast('Đã dừng quy trình');
        else toast('Quy trình thất bại: ' + ((res && res.error) || ''), 'err');
      } catch (e) {
        cfgAppendLog({ level: 'error', msg: 'Lỗi: ' + (e && e.message) });
        toast('Quy trình thất bại' + (e && e.message ? ': ' + e.message : ''), 'err');
      } finally {
        cfgAppendSummary(Date.now() - startedAt);
        if (cfgRunUnsub) { try { cfgRunUnsub(); } catch { /* ignore */ } cfgRunUnsub = null; }
      }
    }

    // Modal "Chạy" - chọn Nhóm + Hồ sơ rồi chạy (giống picker ở màn chỉnh sửa quy trình).
    async function openRunPicker() {
      const asList = (r) => Array.isArray(r) ? r : (r && Array.isArray(r.data) ? r.data : []);
      let groups = [];
      try {
        groups = asList(await window.vt?.remote?.groups?.list());
        if (!groups.length) groups = asList(await window.vt?.groups?.list());
      } catch { groups = []; }
      let profiles = [];
      let groupFilter = '';
      let selectedProfile = null;
      async function loadProfiles() {
        const filter = groupFilter || null;
        try { profiles = asList(await window.vt?.remote?.profiles?.list(filter)); }
        catch { profiles = []; }
        if (!profiles.length) { try { profiles = asList(await window.vt?.profiles?.list(filter)); } catch { /* ignore */ } }
      }
      const comboWrap = el('div', { style: { flex: '1', minWidth: '0' } });
      const runBtn2 = el('button.btn.solid-blue', {
        html: `${icon('playCircle')}<span>Chạy</span>`, disabled: true,
        onclick: () => { if (!selectedProfile) return; closeModal(); runConfigFlow(selectedProfile); },
      });
      function rebuildCombo() {
        clear(comboWrap);
        selectedProfile = null; runBtn2.disabled = true;
        const opts = profiles.map((p) => ({ value: String(p.id), label: p.name || '-' }));
        comboWrap.appendChild(customSelect(opts, {
          placeholder: profiles.length ? 'Chọn hồ sơ để chạy' : 'Không có hồ sơ',
          width: '100%',
          onChange: (v) => { selectedProfile = profiles.find((p) => String(p.id) === v) || null; runBtn2.disabled = !selectedProfile; },
        }));
      }
      const groupWrap = el('div', { style: { flex: '1', minWidth: '0' } });
      const groupOpts = [{ value: '', label: 'Tất cả các nhóm' }].concat(groups.map((gr) => ({ value: String(gr.id), label: gr.name })));
      groupWrap.appendChild(customSelect(groupOpts, { value: '', width: '100%', onChange: async (v) => { groupFilter = v; await loadProfiles(); rebuildCombo(); } }));
      await loadProfiles();
      rebuildCombo();
      const pickRow = (label, control) => el('div', { style: { display: 'flex', alignItems: 'center', gap: '12px' } }, [
        el('span.muted', { text: label, style: { flex: '0 0 44px' } }), control,
      ]);
      const m = openModal({
        title: 'Chạy', width: 520,
        body: [el('div', { style: { display: 'flex', flexDirection: 'column', gap: '14px', padding: '4px 0' } }, [pickRow('Nhóm', groupWrap), pickRow('Hồ sơ', comboWrap)])],
        footer: [el('button.btn', { text: 'Đóng', onclick: closeModal }), runBtn2],
      });
      const h3 = m?.modal?.querySelector('.modal-head h3');
      if (h3) h3.appendChild(el('span.rpa-dtitle-sub', { text: ' Chọn hồ sơ chạy tự động hóa' }));
    }

    // ---- thanh công cụ bên PHẢI tiêu đề (clone MKTLogin 100%, đã click-through từng nút):
    //   [Chia sẻ ✕ · Xuất ✕]  [Tài nguyên · Bảng · Cấu hình]  [▶]  [⋮]
    //   Chia sẻ/Xuất VÔ HIỆU với quy trình tải về (giống MKTLogin). Folder/Bảng/Cấu hình mở
    //   dialog thật (đã soi). ▶ và ⋮ đều có khung viền như các nhóm. KHÔNG còn "Lưu lại".
    const DL_TIP = 'Tính năng này không khả dụng với quy trình được tải về';
    const toolBtn = (ic, tip, onClick, extra) => {
      const b = el('button.rpa-cfg-tool' + (extra || ''), { type: 'button', html: icon(ic), title: tip });
      if (onClick) b.addEventListener('click', onClick); else b.disabled = true;
      return b;
    };
    const kebabBtn = el('button.rpa-cfg-tool', { type: 'button', html: icon('moreVertical'), title: 'Thêm' });
    kebabBtn.addEventListener('click', () => openMenu(kebabBtn, [
      { label: 'Cài đặt', onClick: () => soon('Cài đặt') },
      { label: 'Sắp xếp mã', onClick: () => soon('Sắp xếp mã') },
      { label: 'Hiển thị kết quả', onClick: () => soon('Hiển thị kết quả') },
    ]));
    const toolbar = el('div.rpa-cfg-toolbar', {}, [
      // Nhóm 1: Chia sẻ | Xuất - GỘP chung 1 khung (giống MKTLogin), cả 2 VÔ HIỆU với quy trình tải về.
      el('div.rpa-cfg-toolgroup', {}, [
        toolBtn('share', DL_TIP, null),
        toolBtn('exportFlow', DL_TIP, null),
      ]),
      // Nhóm 2: Tài nguyên | Bảng | Cấu hình - mỗi cái mở dialog thật (soi từ MKTLogin).
      el('div.rpa-cfg-toolgroup', {}, [
        toolBtn('folder', 'Tài nguyên', openResourcesDlg),
        toolBtn('table', 'Bảng', openTableDlg),
        toolBtn('settings', 'Cấu hình', openProcessCfgDlg),
      ]),
      // Chạy: nút CHỮ (thay icon play), thiết kế giống nút chính.
      el('button.rpa-cfg-runbtn.btn.primary', { type: 'button', text: 'Chạy', onclick: openRunPicker }),
      // ⋮: menu Cài đặt / Sắp xếp mã / Hiển thị kết quả.
      kebabBtn,
    ]);

    // ---- thẻ header (giống task_edit: tên + badge + phiên bản) - PHẲNG, không viền/nền
    const header = el('div.te-header.rpa-cfg-head', {}, [
      el('div.te-head-main', {}, [
        el('div.te-title-row', {}, [
          el('span.te-name', { text: flow.name || '(không tên)' }),
          el('span.badge.green.te-badge', { text: 'Tải về' }),
          el('span.te-id', { text: 'Phiên bản ' + (flow.version || '1.0.0') }),
        ]),
      ]),
      toolbar,
    ]);

    // ---- tabs (DÙNG LẠI .rpp-tabs / .rpp-tabbody / .rpp-tabpanel của task_edit)
    const panelInput = el('div.rpp-tabpanel');
    const panelGuide = el('div.rpp-tabpanel');
    const tabBody = el('div.rpp-tabbody', {}, [panelInput, panelGuide]);
    const TABS = [
      ['input', 'Đầu vào', 'tabInput', panelInput],
      ['guide', 'Hướng dẫn sử dụng', 'fileText', panelGuide],
    ];
    const tabBtns = {};
    const showTab = (key) => {
      TABS.forEach(([k, , , panel]) => {
        const on = k === key;
        tabBtns[k].classList.toggle('active', on);
        panel.style.display = on ? '' : 'none';
      });
    };
    const tabBar = el('div.rpp-tabs', {}, TABS.map(([k, label, ic]) => {
      const b = el('button.rpp-tab', { type: 'button', html: `${icon(ic)}<span>${label}</span>`, onclick: () => showTab(k) });
      tabBtns[k] = b;
      return b;
    }));

    // ---- Đầu vào: mỗi biến = 1 ô .rpp-invar (khớp inputField của task_edit)
    function invarBox(name, inner, multi) {
      return el('div.rpp-invar' + (multi ? '.is-multi' : ''), {}, [
        el('label.rpp-invar-label', { text: name }), inner,
      ]);
    }
    function switchBtn(cur, on) {
      const sw = el('button.switch' + (cur ? '.on' : ''), { type: 'button' }, [el('span.knob')]);
      sw.addEventListener('click', () => { const next = !sw.classList.contains('on'); sw.classList.toggle('on', next); on(next); scheduleSave(); });
      return sw;
    }
    function inputField(v) {
      const type = v.type || 'String';
      const cur = v.value != null ? v.value : '';
      const disp = v.label || v.name;   // hiện nhãn thân thiện nếu có, nếu không dùng tên biến
      if (type === 'Boolean') {
        const on = cur === true || cur === 'true' || cur === 1 || cur === '1';
        v.value = on;
        return invarBox(disp, el('div.rpp-invar-line', {}, [switchBtn(on, (val) => { v.value = val; })]));
      }
      if (type === 'Number') {
        const inp = el('input.rpp-invar-input', { type: 'number', value: cur, placeholder: v.desc || '' });
        inp.addEventListener('input', () => { v.value = inp.value; scheduleSave(); });
        return invarBox(disp, el('div.rpp-invar-line', {}, [inp]));
      }
      if (type === 'Array' || type === 'Object' || type === 'Text') {
        const ta = el('textarea.rpp-invar-input.rpp-invar-area', { rows: '3', placeholder: v.desc || '' });
        ta.value = typeof cur === 'object' ? JSON.stringify(cur, null, 2) : String(cur == null ? '' : cur);
        ta.addEventListener('input', () => { v.value = ta.value; scheduleSave(); });
        return invarBox(disp, ta, true);
      }
      if (type === 'Folder') {
        const inp = el('input.rpp-invar-input', { value: cur, placeholder: v.desc || 'Chọn thư mục hoặc nhập đường dẫn' });
        inp.addEventListener('input', () => { v.value = inp.value; scheduleSave(); });
        const browse = iconBtn('folder', { title: 'Chọn thư mục', onclick: async () => {
          try { const p = await window.vt?.dialog?.openFile({ directory: true }); if (p) { inp.value = p; v.value = p; scheduleSave(); } } catch { /* huỷ */ }
        } });
        return invarBox(disp, el('div.rpp-invar-line.rpp-invar-file', {}, [inp, browse]));
      }
      if (type === 'File') {
        // Chọn được NHIỀU tệp: dùng textarea (mỗi dòng 1 tệp) + nút duyệt gom thêm.
        const ta = el('textarea.rpp-invar-input.rpp-invar-area', { rows: '3', placeholder: v.desc || 'Chọn tệp (chọn được nhiều) hoặc nhập đường dẫn, mỗi dòng 1 tệp' });
        ta.value = String(cur == null ? '' : cur);
        ta.addEventListener('input', () => { v.value = ta.value; scheduleSave(); });
        const addPaths = (picked) => {
          const arr = Array.isArray(picked) ? picked : [picked];
          const list = ta.value.split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
          for (const p of arr) { if (p && !list.includes(p)) list.push(p); }
          ta.value = list.join('\n'); v.value = ta.value; scheduleSave();
        };
        const browse = iconBtn('folder', { title: 'Chọn tệp (chọn được nhiều)', onclick: async () => {
          try { const p = await window.vt?.dialog?.openFile({ multi: true }); if (p) addPaths(p); } catch { /* huỷ */ }
        } });
        return invarBox(disp, el('div.rpp-invar-line.rpp-invar-file', {}, [ta, browse]), true);
      }
      const inp = el('input.rpp-invar-input', { value: cur, placeholder: v.desc || '' });
      inp.addEventListener('input', () => { v.value = inp.value; scheduleSave(); });
      return invarBox(disp, el('div.rpp-invar-line', {}, [inp]));
    }
    // CHỈ biến là tham số đầu vào mới hiện ô nhập. Biến làm việc (local) vẫn nằm
    // trong `vars` để được lưu / truyền vào lúc chạy, nhưng không phơi ra đây.
    const inputVars = vars.filter((v) => v && v.name && !v.local);
    if (!inputVars.length) panelInput.appendChild(el('div.rpp-input-empty', { text: 'Chưa tạo biến đầu vào.' }));
    else inputVars.forEach((v) => panelInput.appendChild(inputField(v)));

    // ---- Hướng dẫn sử dụng (readme kèm khi cài)
    // readme lưu dưới dạng HTML (Quill). Render trong khung ql-editor (chỉ đọc) để hiện
    // ĐÚNG định dạng chữ - trước đây dùng `text:` nên phơi luôn các thẻ <p>… ra màn hình.
    const doc = (flow.readme || '').trim();
    if (!doc) panelGuide.appendChild(el('div.rpp-input-empty', { text: 'Kịch bản này chưa có hướng dẫn sử dụng.' }));
    else {
      const docBox = el('div.mkt-dt-doc.rpa-cfg-doc.ql-snow');
      docBox.innerHTML = `<div class="ql-editor">${doc}</div>`;
      panelGuide.appendChild(docBox);
      // Nạp CSS Quill (idempotent) để readme hiện ĐÚNG định dạng (list/heading…) như
      // ô soạn thảo ở modal đăng chợ - openConfig không tự nạp Quill.
      ensureQuill().catch(() => {});
    }

    host.appendChild(el('div.task-edit', {}, [
      header,
      el('div.te-tabcard.rpa-cfg-tabcard', {}, [el('div.rpp-form.rpp-modal', {}, [tabBar, tabBody]), cfgLogDock]),
    ]));
    showTab('input');
  }

  // ============================================================ EDITOR
  function openEditor(flow, opts) {
    cleanup();
    collapseSidebarForEditor();
    clear(host);

    // ---- graph state
    let nodes = [];            // {id,type,title,icon,color,x,y,params}
    let connections = [];      // {source,target,branch,color}
    let variables = [];        // process variables (start node)
    let scale = 1, tx = 90, ty = 120;
    let chainTail = 'start';   // id of last node in chain (for auto-connect)
    let selectedId = null;

    // editor settings (gear → "Cài đặt")
    const settings = {
      layout: 'Ngang', autoConnect: true,
      onError: 'Bỏ qua', onCompleteBrowser: 'Giữ trình duyệt',
      timeoutSec: 0, delayMin: 0,
    };

    // load graph from the in-memory flow object
    try {
      if (flow.graph) {
        const g = typeof flow.graph === 'string' ? JSON.parse(flow.graph) : flow.graph;
        nodes = (g.nodes || []).map((n) => ({ ...n, params: n.params || {} }));
        connections = g.connections || [];
        variables = g.variables || [];
        if (g.settings) Object.assign(settings, g.settings);
        uid = nodes.length + 2;
      }
    } catch { /* ignore */ }
    if (!nodes.some((n) => n.type === 'start')) {
      nodes.unshift({ id: 'start', type: 'start', title: 'Bắt đầu quy trình', x: 360, y: 40, params: {} });
    }
    (function () { const last = nodes[nodes.length - 1]; chainTail = last ? last.id : 'start'; })();

    // ---- canvas elements
    const wires = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    wires.classList.add('rpa-wires');
    const nodeLayer = el('div.rpa-nodelayer');
    const world = el('div.rpa-world', {}, [wires, nodeLayer]);
    const viewport = el('div.rpa-viewport', {}, [world]);

    function applyTransform() { world.style.transform = `translate(${tx}px, ${ty}px) scale(${scale})`; renderMini(); }

    function nodeOutputs(n) { const d = find(n.type); return (d && d.branches) ? d.branches : null; }
    // Measured node box (filled in after each render). Falls back to estimates.
    function box(n) { return { w: n._w || (n.type === 'start' ? 190 : 224), h: n._h || 64 }; }

    // Port anchor positions in world coords. The input dot sits ~13px left of the
    // node, vertically centred (matching the output ring); the wire ends at the
    // dot's left edge so the arrowhead points straight INTO it.
    function inPos(n) { return { x: n.x - 13, y: n.y + box(n).h / 2 }; }
    function outPositions(n) {
      const b = box(n);
      const outs = nodeOutputs(n);
      if (outs) {
        return outs.map((branch, i) => ({ branch, x: n.x + b.w * ((i + 0.5) / outs.length), y: n.y + b.h, down: true }));
      }
      // Start the wire at the output ring's centre (it sits ~8px outside the edge).
      return [{ branch: null, x: n.x + b.w + 8, y: n.y + b.h / 2, down: false }];
    }

    // ---- pending connection (drag from an output port to an input)
    let pending = null; // {sourceId, branch, color, portEl}

    // Arrowhead drawn as a plain filled triangle pointing right (toward +x). SVG
    // <marker> elements weren't being painted in this environment, so we render
    // the head ourselves as a sibling <path> of the wire.
    const SVGNS = 'http://www.w3.org/2000/svg';
    function buildArrowHead(x, y, color) {
      const tri = document.createElementNS(SVGNS, 'path');
      // Tip at (x,y); 7px long, 6px half-height → total height 12px so the
      // arrowhead's vertical span equals the 12px port-circle diameter.
      tri.setAttribute('d', `M ${x} ${y} L ${x - 7} ${y - 6} L ${x - 7} ${y + 6} Z`);
      // Inline style (NOT the fill attribute) so it beats the `svg.rpa-wires path
      // { fill: none }` rule in app.css that would otherwise blank the head out.
      tri.style.fill = color || COL_WIRE;
      tri.style.stroke = 'none';
      tri.style.pointerEvents = 'none';
      return tri;
    }

    // Build an SVG path that walks an orthogonal poly-line (right-angle segments)
    // through `pts`, rounding every interior corner with radius `r`. Used for the
    // AdsPower-style elbow connector when the target isn't ahead to the right.
    function roundedPath(pts, r) {
      let d = `M ${pts[0].x} ${pts[0].y}`;
      for (let i = 1; i < pts.length - 1; i++) {
        const p0 = pts[i - 1], p1 = pts[i], p2 = pts[i + 1];
        const v1 = { x: p0.x - p1.x, y: p0.y - p1.y };
        const v2 = { x: p2.x - p1.x, y: p2.y - p1.y };
        const l1 = Math.hypot(v1.x, v1.y) || 1, l2 = Math.hypot(v2.x, v2.y) || 1;
        const rr = Math.min(r, l1 / 2, l2 / 2);
        const a = { x: p1.x + (v1.x / l1) * rr, y: p1.y + (v1.y / l1) * rr };
        const b = { x: p1.x + (v2.x / l2) * rr, y: p1.y + (v2.y / l2) * rr };
        d += ` L ${a.x} ${a.y} Q ${p1.x} ${p1.y} ${b.x} ${b.y}`;
      }
      const last = pts[pts.length - 1];
      d += ` L ${last.x} ${last.y}`;
      return d;
    }
    // Elbow connector for a node that is NOT ahead to the right (vertically aligned
    // or leaning left): exit the right port, drop down, wrap left past the target,
    // drop again and enter the left input - matching AdsPower 1:1.
    function elbowPath(sx, sy, tx, ty) {
      const ext = 24;
      // Run the horizontal segment through the MIDDLE of the vertical gap between
      // the two ports so it never grazes either node's border.
      const ymid = (sy + ty) / 2;
      const x1 = sx + ext, x2 = tx - ext;
      return roundedPath([
        { x: sx, y: sy }, { x: x1, y: sy }, { x: x1, y: ymid },
        { x: x2, y: ymid }, { x: x2, y: ty }, { x: tx, y: ty },
      ], 12);
    }

    function renderWires() {
      clear(wires);
      connections.forEach((c) => {
        const s = nodes.find((n) => n.id === c.source); const t = nodes.find((n) => n.id === c.target);
        if (!s || !t) return;
        const outs = outPositions(s);
        const sp = outs.find((o) => o.branch === c.branch) || outs[0];
        const tp = inPos(t);
        const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        let d;
        // Decide the wire style from the NODES' positions (not the ports): the
        // target only counts as "ahead" when its body sits CLEARLY to the right of
        // the source (about a node-width away). As soon as the two nodes show any
        // sign of being vertically aligned ("thẳng trục dọc") - or the target leans
        // even a little to the LEFT - we switch to the orthogonal elbow connector.
        const ahead = t.x > s.x + box(s).w;
        if (sp.down) {
          const dy = Math.max(40, Math.abs(tp.y - sp.y) / 2);
          d = `M ${sp.x} ${sp.y} C ${sp.x} ${sp.y + dy}, ${tp.x - 40} ${tp.y}, ${tp.x} ${tp.y}`;
        } else if (ahead) {
          // Target clearly ahead to the right → simple forward bezier.
          const dx = Math.max(40, (tp.x - sp.x) / 2);
          d = `M ${sp.x} ${sp.y} C ${sp.x + dx} ${sp.y}, ${tp.x - dx} ${tp.y}, ${tp.x} ${tp.y}`;
        } else {
          // Vertically-aligned / left-leaning nodes → orthogonal elbow connector
          // (out-right, down, wrap-left, down, into-left-input) with rounded corners,
          // matching AdsPower's screenshot 1:1. (Validated in test/wire-preview.html.)
          d = elbowPath(sp.x, sp.y, tp.x, tp.y);
        }
        path.setAttribute('d', d);
        path.setAttribute('stroke', c.color || COL_WIRE);
        path.setAttribute('fill', 'none');
        path.setAttribute('stroke-width', '2');
        path.addEventListener('dblclick', () => { connections = connections.filter((x) => x !== c); renderWires(); snapshot(); });
        wires.appendChild(path);
        // Arrowhead drawn as an explicit filled triangle (SVG markers weren't
        // painting here). The bezier always arrives horizontally from the left,
        // so the head points right into the target's input dot.
        wires.appendChild(buildArrowHead(tp.x, tp.y, c.color || COL_WIRE));
      });
    }

    // Dòng mô tả dưới tên node trên canvas. Nhãn trường PHẢI qua t(): trước đây ghép thẳng f.label (tiếng Việt trong
    // node-catalog) ⇒ app ở tiếng Anh vẫn hiện "Điều kiện: …", "Đợi theo thời gian: …" (phát hiện 2026-10-31).
    function nodeSummary(n, def) {
      if (!def || !def.fields.length) return t('Không cần cấu hình');
      const lab = (f) => (f.label ? t(f.label) + ': ' : '');
      for (const f of def.fields) {
        if (f.t === 'note' || f.t === 'info') continue;
        const v = n.params[f.k];
        if ((f.t === 'selector' || f.t === 'selradio') && v && v.value) return v.value;
        if (f.t === 'conds') { const s = condsSummary(v); if (s) return lab(f) + s; continue; }
        if (typeof v === 'string' && v.trim()) return lab(f) + v;
        if (typeof v === 'number') return lab(f) + v;
      }
      return def.subtitle ? t(def.subtitle) : t('Nhấn để cấu hình');
    }
    // A node is "missing config" when a field that the executor will actually read
    // is left blank - that would throw at runtime. Two rules, both gated on the
    // field being VISIBLE (a field hidden by its `when` clause is not in play):
    //   1. selector / selradio fields are ALWAYS required - every selector node in
    //      the executor calls resolveOne() and throws "Không tìm thấy phần tử" when
    //      the selector is empty (click/type_text/hover/focus/select_dropdown/
    //      element_data/wait_element/for_elements …). scroll's selector is the
    //      exception, but it carries a `when` so visibility already handles it.
    //   2. any field explicitly flagged `req: true` in the catalog.
    function requiredMissing(n, def) {
      if (!def) return false;
      return def.fields.some((f) => {
        if (!fieldVisible(n, f, def)) return false;
        const isSel = f.t === 'selector' || f.t === 'selradio';
        if (!isSel && !f.req) return false;
        const v = n.params[f.k];
        if (isSel) return !(v && v.value);
        // `conds` là object - coi là thiếu khi chưa có dòng điều kiện nào có nội dung.
        if (f.t === 'conds') return !condsSummary(v);
        return v == null || v === '';
      });
    }

    function renderNodes() {
      clear(nodeLayer);
      nodes.forEach((n) => {
        const def = find(n.type);
        const isStart = n.type === 'start';
        const container = !!(def && def.container);
        const hasConfig = !!(def && def.fields && def.fields.length);  // có gì để cấu hình?
        const outs = nodeOutputs(n);
        // Status colour split: red (.miss) when a required/selector field the
        // executor needs is empty (would error); green (.ok) once the node is
        // fully configured. Start node has its own styling.
        const miss = !isStart && requiredMissing(n, def);
        const ok = !isStart && !miss;
        const node = el('div.rpa-node' + (isStart ? '.start' : '') + (n.id === selectedId ? '.sel' : '') + (container ? '.container' : '') + (n.disabled ? '.off' : '') + (miss ? '.miss' : '') + (ok ? '.ok' : ''), {
          style: { left: n.x + 'px', top: n.y + 'px' },
        });

        if (isStart) {
          node.appendChild(el('div.rpa-start-pill', { html: `${icon('settings')}` }));
          node.appendChild(el('div.rpa-start-head', {}, [
            el('div.rpa-ico', { style: { background: iconBg(COL_START), color: '#fff' }, html: icon('play') }),
            el('div.rpa-node-title', { text: 'Bắt đầu quy trình' }),
          ]));
          node.appendChild(el('div.rpa-start-foot', {}, [
            document.createTextNode('Có thể thiết lập '),
            el('span.rpa-varlink', { text: 'Biến quy trình', onclick: (e) => { e.stopPropagation(); openVariablesDrawer(); } }),
          ]));
        } else {
          node.appendChild(el('div.rpa-node-head', {}, [
            el('div.rpa-ico', Object.assign({ style: { background: iconBg(n.color || '#64748B'), color: '#fff' } }, def && def.icon ? { html: icon(def.icon) } : { text: initial(n.title) })),
            el('div.rpa-node-title', { text: n.title }),
          ]));
          if (container) {
            node.appendChild(el('div.rpa-drop', { text: 'Kéo tùy chọn thao tác vào đây' }));
          } else {
            node.appendChild(el('div.rpa-node-sub', { text: nodeSummary(n, def) }));
            if (requiredMissing(n, def)) node.appendChild(el('div.rpa-node-warn', { html: `${icon('warnCircle')}<span>Chưa cấu hình mục bắt buộc</span>` }));
          }
        }

        // input port
        if (!isStart) {
          const inPort = el('div.rpa-port.in', { title: 'Đầu vào' });
          inPort.addEventListener('mouseup', (e) => { e.stopPropagation(); if (pending && pending.sourceId !== n.id) { connect(pending.sourceId, n.id, pending.branch, pending.color); clearPending(); } });
          node.appendChild(inPort);
        }

        // output ports - branch row for branch nodes, single right port otherwise
        if (outs) {
          const row = el('div.rpa-branches');
          outs.forEach((label, i) => {
            const color = BRANCH_COLORS[i] || COL_WIRE;
            const port = el('div.rpa-port.out', { title: label, style: { borderColor: color } });
            armOut(port, n.id, label, color);
            row.appendChild(el('div.rpa-branch', {}, [el('span', { text: label }), port]));
          });
          node.appendChild(row);
        } else {
          const port = el('div.rpa-port.out', { title: 'Đầu ra', style: { top: '50%', transform: 'translateY(-50%)' } });
          armOut(port, n.id, null, COL_WIRE);
          node.appendChild(port);
        }

        // hover toolbar (AdsPower-style bar above the node) - 6 controls in
        // AdsPower order: Gỡ lỗi · Xóa · Sao chép · Xử lý lỗi · Kéo vào nhóm · Bật/tắt.
        if (!isStart) {
          const bar = el('div.rpa-nodebar');
          // Gỡ lỗi - same behaviour as the toolbar "Chạy": opens the picker first
          // time, then runs the remembered profile directly + shows the selected-
          // profile tooltip ("Hồ sơ đã chọn: <tên>" + "Chọn lại") on hover.
          const dbgBtn = el('button.rpa-nodebtn', { html: icon('bug'), title: 'Gỡ lỗi' });
          wireRunTrigger(dbgBtn, 'Gỡ lỗi');
          bar.appendChild(dbgBtn);
          // Xóa
          bar.appendChild(el('button.rpa-nodebtn', { html: icon('trash'), title: 'Xóa', onclick: (e) => { e.stopPropagation(); removeNode(n); } }));
          // Sao chép
          bar.appendChild(el('button.rpa-nodebtn', { html: icon('copy'), title: 'Sao chép', onclick: (e) => { e.stopPropagation(); duplicateNode(n); } }));
          // Xử lý lỗi (per-node override of the global "Bất thường" setting)
          const errLabel = n.onError || 'Mặc định';
          const errBtn = el('button.rpa-nodebtn', { html: icon('warnCircle'), title: 'Xử lý lỗi: ' + errLabel });
          errBtn.onclick = (e) => {
            e.stopPropagation();
            openMenu(errBtn, ['Mặc định', 'Gián đoạn', 'Bỏ qua'].map((o) => ({ label: o, onClick: () => { n.onError = o; renderNodes(); snapshot(); } })));
          };
          bar.appendChild(errBtn);
          // Kéo vào nhóm - press-and-hold drag to move into a group container.
          const dragBtn = el('button.rpa-nodebtn', { html: icon('dragMove'), title: 'Nhấn và kéo lâu để di chuyển vào một nhóm' });
          dragBtn.addEventListener('mousedown', (e) => { e.stopPropagation(); startNodeDrag(e, n); });
          bar.appendChild(dragBtn);
          // Bắt đầu dùng - enable/disable this step.
          const sw = el('button.switch.sm' + (n.disabled ? '' : '.on'), { type: 'button', title: n.disabled ? 'Đã tắt bước này' : 'Bắt đầu dùng' }, [el('span.knob')]);
          sw.addEventListener('click', (e) => { e.stopPropagation(); n.disabled = !n.disabled; renderNodes(); snapshot(); });
          bar.appendChild(sw);
          node.appendChild(bar);
        }

        node.addEventListener('mousedown', (e) => startNodeDrag(e, n));
        // drop a trailing wire anywhere on this node (not just the input port)
        if (!isStart) node.addEventListener('mouseup', (e) => { if (pending && pending.sourceId !== n.id) { e.stopPropagation(); connect(pending.sourceId, n.id, pending.branch, pending.color); clearPending(); } });
        node.addEventListener('click', () => { if (drag && drag.moved) return; if (!isStart && !container && hasConfig) selectNode(n); });
        nodeLayer.appendChild(node);
        n._el = node;
      });
      // measure rendered boxes then lay out the wires accurately
      nodes.forEach((n) => { if (n._el) { n._w = n._el.offsetWidth; n._h = n._el.offsetHeight; } });
      renderWires();
      renderMini();
    }

    function armOut(portEl, sourceId, branch, color) {
      portEl.addEventListener('mousedown', (e) => { e.stopPropagation(); pending = { sourceId, branch, color, portEl }; portEl.classList.add('arming'); nodeLayer.classList.add('wiring'); });
    }
    function clearPending() {
      removeTempWire();
      if (pending && pending.portEl) pending.portEl.classList.remove('arming');
      nodeLayer.querySelectorAll('.rpa-port.arming').forEach((p) => p.classList.remove('arming'));
      pending = null; nodeLayer.classList.remove('wiring');
    }

    // ---- live "rubber-band" wire that trails the cursor while connecting
    let tempPath = null;
    function updateTempWire(world) {
      if (!pending) return;
      const s = nodes.find((n) => n.id === pending.sourceId); if (!s) return;
      const outs = outPositions(s);
      const sp = outs.find((o) => o.branch === pending.branch) || outs[0];
      if (!tempPath) {
        tempPath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        tempPath.setAttribute('fill', 'none');
        tempPath.setAttribute('stroke', COL_TEMP);
        tempPath.style.strokeWidth = '1px'; // inline style beats the svg.rpa-wires CSS rule (stroke-width:2)
        wires.appendChild(tempPath);
      }
      let d;
      if (sp.down) { const dy = Math.max(40, Math.abs(world.y - sp.y) / 2); d = `M ${sp.x} ${sp.y} C ${sp.x} ${sp.y + dy}, ${world.x} ${world.y - dy}, ${world.x} ${world.y}`; }
      else if (world.x > sp.x + box(s).w) { const dx = Math.max(40, (world.x - sp.x) / 2); d = `M ${sp.x} ${sp.y} C ${sp.x + dx} ${sp.y}, ${world.x - dx} ${world.y}, ${world.x} ${world.y}`; }
      else { d = elbowPath(sp.x, sp.y, world.x, world.y); }
      tempPath.setAttribute('d', d);
    }
    function removeTempWire() { if (tempPath) { tempPath.remove(); tempPath = null; } }

    function connect(source, target, branch, color) {
      if (source === target) return;
      if (connections.some((c) => c.source === source && c.target === target && c.branch === branch)) return;
      connections.push({ source, target, branch: branch || null, color: color || COL_WIRE });
      renderWires();
      snapshot();
    }

    function duplicateNode(n) {
      const copy = { ...n, id: newNodeId(), x: n.x + 36, y: n.y + 36, params: JSON.parse(JSON.stringify(n.params || {})) };
      delete copy._el; delete copy._w; delete copy._h;
      nodes.push(copy);
      // Nhân bản node mở vòng lặp mà bê nguyên loop_id thì hai vòng lặp cùng ID -
      // lúc chạy, engine dò "Điểm cuối vòng lặp" theo loop_id nên bản sao sẽ bám vào
      // ĐIỂM CUỐI CỦA VÒNG LẶP GỐC, nhảy loạn và bỏ qua hàng loạt node. Cấp ID mới
      // và sinh luôn điểm cuối riêng, đúng như khi kéo một node vòng lặp mới vào.
      if (LOOP_STARTS.has(copy.type)) spawnLoopEnd(copy);
      chainTail = copy.id;
      renderNodes();
      const def = find(copy.type);
      if (!(def && def.container)) selectNode(copy);
      ensureInView(copy);
      snapshot();
    }

    function removeNode(n) {
      nodes = nodes.filter((x) => x !== n);
      connections = connections.filter((c) => c.source !== n.id && c.target !== n.id);
      if (selectedId === n.id) { selectedId = null; closeDrawer(); }
      if (chainTail === n.id) { const last = nodes[nodes.length - 1]; chainTail = last ? last.id : 'start'; }
      renderNodes();
      snapshot();
    }

    // ---- node drag
    let drag = null;
    function startNodeDrag(e, n) {
      if (e.button !== 0) return;
      if (e.target.closest('.rpa-port') || e.target.closest('.rpa-badge') || e.target.closest('.rpa-varlink')) return;
      drag = { n, sx: e.clientX, sy: e.clientY, ox: n.x, oy: n.y, moved: false };
      e.stopPropagation();
    }

    // ---- canvas pan + wheel zoom
    let pan = null;
    // Clicking ANYWHERE on the canvas (empty space, a node, a wire…) rolls the
    // search input back up - it bubbles to the viewport from every child.
    viewport.addEventListener('mousedown', () => { if (searchOpen) toggleSearch(false); });
    viewport.addEventListener('mousedown', (e) => { if (e.target === viewport || e.target === world || e.target === wires) { pan = { sx: e.clientX, sy: e.clientY, ox: tx, oy: ty }; if (pending) clearPending(); if (selectedId) closeDrawer(); if (logDock && logDock.classList.contains('open')) toggleLog(false); } });
    window.addEventListener('mousemove', onMove); winHandlers.push(['mousemove', onMove]);
    window.addEventListener('mouseup', onUp); winHandlers.push(['mouseup', onUp]);
    function onMove(e) {
      if (pending) { updateTempWire(screenToWorld(e.clientX, e.clientY)); return; }
      if (drag) {
        drag.n.x = drag.ox + (e.clientX - drag.sx) / scale;
        drag.n.y = drag.oy + (e.clientY - drag.sy) / scale;
        drag.moved = true;
        if (drag.n._el) { drag.n._el.style.left = drag.n.x + 'px'; drag.n._el.style.top = drag.n.y + 'px'; }
        renderWires();
        renderMini();
      } else if (pan) { tx = pan.ox + (e.clientX - pan.sx); ty = pan.oy + (e.clientY - pan.sy); applyTransform(); }
    }
    function onUp() { if (drag && drag.moved) snapshot(); drag = null; pan = null; if (pending) clearPending(); }
    viewport.addEventListener('wheel', (e) => {
      e.preventDefault();
      const factor = e.deltaY < 0 ? 1.1 : 1 / 1.1;
      scale = Math.min(2, Math.max(0.4, scale * factor)); applyTransform();
    }, { passive: false });

    // ---- node factory + placement
    function makeNode(def, x, y) {
      const n = { id: newNodeId(), type: def.type, title: def.title, icon: def.icon, color: def.color, x, y, params: {} };
      def.fields.forEach((f) => { if (f.k) n.params[f.k] = fieldDefault(f); });
      return n;
    }
    function ensureInView(n) {
      const nb = box(n);
      const vw = viewport.clientWidth, vh = viewport.clientHeight;
      const px = n.x * scale + tx, py = n.y * scale + ty;
      if (px < 40 || px > vw - 280 || py < 40 || py > vh - 140) { tx = vw / 2 - (n.x + nb.w / 2) * scale; ty = vh / 2 - (n.y + nb.h / 2) * scale; applyTransform(); }
    }
    // Convert a screen point to world (canvas) coordinates.
    function screenToWorld(clientX, clientY) {
      const r = viewport.getBoundingClientRect();
      return { x: (clientX - r.left - tx) / scale, y: (clientY - r.top - ty) / scale };
    }

    // Loop-start nodes that must be dropped together with a matching
    // "Điểm cuối vòng lặp" (MKTLogin parity).
    const LOOP_STARTS = new Set(['lap_du_lieu', 'lap_co_dieu_kien']);
    // A fresh, unused loop_id (loop1, loop2, …) - shared by the pair so the two
    // nodes read as "the same loop". KHÔNG chỉ để hiển thị: lúc chạy, findLoopEnd()
    // trong executor.js dò điểm cuối THEO loop_id trước (chỉ khi hụt mới đi dọc dây
    // và đếm độ sâu). Hai vòng lặp trùng ID là chạy sai - nên mọi đường sinh node
    // vòng lặp (kéo thả, nhân bản) đều phải đi qua đây.
    function nextLoopId() {
      const used = new Set(nodes.map((n) => n && n.params && n.params.loop_id).filter(Boolean));
      let i = 1, id;
      do { id = 'loop' + (i++); } while (used.has(id));
      return id;
    }
    // Auto-connect `n` right after `src`. If `src` already flows onward on the
    // main (branch=null) wire, `n` is INSERTED into that link (src→n→old) so it
    // lands mid-chain - this is what lets body nodes drop INSIDE a loop, between
    // its start and its end.
    function autoLink(src, n) {
      const outs = nodeOutputs(src);
      // Node nhiều cổng ra (vd. Điều kiện: Đúng/Sai) - nối vào cổng CÒN TRỐNG đầu
      // tiên; hết cổng trống thì mới chèn vào cổng đầu (đẩy nhánh cũ xuống).
      const branch = outs ? (outs.find((b) => !connections.some((c) => c.source === src.id && (c.branch || null) === b)) || outs[0]) : null;
      const existing = connections.find((c) => c.source === src.id && (c.branch || null) === (branch || null));
      if (existing) {
        const old = existing.target;
        if (old && old !== n.id) {
          // shove the displaced tail (and everything after it) one slot along so
          // the inserted node occupies the freed space instead of overlapping.
          const nb = box(n);
          if (settings.layout === 'Dọc') shiftChain(old, 0, nb.h + 70);
          else shiftChain(old, nb.w + 90, 0);
        }
        existing.target = n.id;                                     // src → n
        if (old && old !== n.id) connect(n.id, old, null, COL_WIRE); // n → old
        renderWires();
      } else {
        connect(src.id, n.id, branch, COL_WIRE);
      }
    }
    // Slide a node and its linear successors by (dx,dy) so an insertion doesn't
    // stack nodes on top of each other.
    function shiftChain(fromId, dx, dy) {
      const seen = new Set();
      let cur = fromId;
      while (cur && !seen.has(cur)) {
        seen.add(cur);
        const node = nodes.find((x) => x.id === cur);
        if (!node) break;
        node.x += dx; node.y += dy;
        if (node._el) { node._el.style.left = node.x + 'px'; node._el.style.top = node.y + 'px'; }
        const c = connections.find((cc) => cc.source === cur && !cc.branch);
        cur = c ? c.target : null;
      }
    }
    // Dropping a loop-start spawns its matching "Điểm cuối vòng lặp", wires
    // start→end and shares one auto-generated loop_id. Returns the end node.
    function spawnLoopEnd(startNode) {
      const lid = nextLoopId();
      startNode.params.loop_id = lid;
      const endDef = find('diem_cuoi_vong_lap');
      if (!endDef) return null;
      const sb = box(startNode);
      let ex, ey;
      // Leave a body gap so the end node doesn't sit on top of the start. The two
      // are NOT auto-wired to each other - the user wires the body themselves - so a
      // fresh loop just shows two loose nodes, not a "closed" start→end wire.
      if (settings.layout === 'Dọc') { ex = startNode.x; ey = startNode.y + sb.h + 150; }
      else { ex = startNode.x + sb.w + 190; ey = startNode.y; }
      const end = makeNode(endDef, ex, ey);
      end.params.loop_id = lid;
      nodes.push(end);
      return end;
    }

    // "+" button: append to the chain tail (honours "Tự động kết nối").
    function addNode(def) {
      const tail = nodes.find((n) => n.id === chainTail) || nodes[0];
      const tb = tail ? box(tail) : { w: 200, h: 64 };
      let x, y;
      if (settings.layout === 'Dọc') { x = tail ? tail.x : 200; y = tail ? tail.y + tb.h + 70 : 200; }
      else { x = tail ? tail.x + tb.w + 90 : 260; y = tail ? tail.y : 200; }
      const n = makeNode(def, x, y);
      nodes.push(n);
      if (settings.autoConnect && tail && !def.container) autoLink(tail, n);
      // A loop-start drags its matching end node along; keep the insertion point
      // INSIDE the loop so the next node lands between start and end.
      if (LOOP_STARTS.has(def.type)) { spawnLoopEnd(n); chainTail = n.id; }
      else chainTail = n.id;
      renderNodes();
      if (!def.container) selectNode(n);
      ensureInView(n);
      snapshot();
      return n;
    }

    // Kéo-thả từ thư viện. Node mới NẰM ĐÚNG CHỖ THẢ - vị trí do người dùng quyết
    // định, không tự xếp cạnh node nguồn. `srcNode` là node ĐANG MANG DẤU CỘNG lúc
    // thả (node còn cổng ra trống và gần con trỏ nhất): chỉ dùng để tự kéo dây nối
    // tới node mới. Không còn node nào nhận dây được thì `srcNode` là null, node mới
    // đứng độc lập.
    function dropNode(def, wx, wy, srcNode) {
      const x = Math.round(wx - 100), y = Math.round(wy - 22);
      const n = makeNode(def, x, y);
      nodes.push(n);
      if (settings.autoConnect && srcNode && !def.container) autoLink(srcNode, n);
      if (LOOP_STARTS.has(def.type)) { spawnLoopEnd(n); chainTail = n.id; }
      else chainTail = n.id;
      renderNodes();
      if (!def.container) selectNode(n);
      ensureInView(n);
      snapshot();
      return n;
    }

    // ---- drag a node FROM the library ONTO the canvas (ghost follows cursor)
    let libDrag = null;
    function startLibDrag(e, def) { libDrag = { def, ghost: null, started: false, sx: e.clientX, sy: e.clientY }; e.preventDefault(); }
    // Node GẦN con trỏ nhất trong số các node còn nhận dây được (chưa có dây ra, không
    // phải node nhóm). KHÔNG giới hạn bán kính: luôn có đúng một node được chấm, nên
    // trên canvas lúc nào cũng chỉ thấy DUY NHẤT MỘT dấu cộng, và thả ở đâu cũng tự
    // nối vào node đang mang dấu cộng đó. Khoảng cách đo tới khung node (0 khi ở trong)
    // nên chỉ cần kéo lại gần là dấu cộng nhảy sang node đó, không cần thả trúng.
    // Còn cổng ra nào chưa nối dây không? Node thường có 1 cổng; node rẽ nhánh
    // (Điều kiện) có nhiều cổng nên vẫn nhận dây tiếp cho tới khi kín hết nhánh.
    function hasFreeOut(n) {
      const outs = nodeOutputs(n);
      if (!outs) return !connections.some((c) => c.source === n.id);
      return outs.some((b) => !connections.some((c) => c.source === n.id && (c.branch || null) === b));
    }
    function libTargetNode(clientX, clientY) {
      let best = null, bestD = Infinity;
      for (let i = nodes.length - 1; i >= 0; i--) {
        const n = nodes[i]; if (!n._el) continue;
        const def = find(n.type); if (def && def.container) continue;   // can't chain off a group
        if (!hasFreeOut(n)) continue;                                   // only nodes with a free out port
        const r = n._el.getBoundingClientRect();
        const dx = Math.max(r.left - clientX, 0, clientX - r.right);
        const dy = Math.max(r.top - clientY, 0, clientY - r.bottom);
        const d = Math.sqrt(dx * dx + dy * dy);
        if (d < bestD) { bestD = d; best = n; }
      }
      return best;
    }
    // Gắn `linkable` (cổng ra đậm + dấu cộng) cho ĐÚNG MỘT node - node vừa được
    // libTargetNode chấm. TUYỆT ĐỐI không bật hàng loạt: nhiều dấu cộng cùng hiện thì
    // người dùng không biết dây sẽ nối vào đâu. Không dùng `link-target` (viền sáng dày).
    function setLibTarget(overNode) {
      if (!libDrag) return;
      const dragDef = libDrag.def;
      const tgt = (settings.autoConnect && !(dragDef && dragDef.container)) ? overNode : null;
      if (libDrag.tgt === tgt) return;
      if (libDrag.tgt && libDrag.tgt._el) libDrag.tgt._el.classList.remove('linkable');
      libDrag.tgt = tgt;
      if (tgt && tgt._el) tgt._el.classList.add('linkable');
    }
    function onLibMove(e) {
      if (!libDrag) return;
      if (!libDrag.started) {
        if (Math.abs(e.clientX - libDrag.sx) + Math.abs(e.clientY - libDrag.sy) < 4) return;
        libDrag.started = true;
        // The ghost is a 1:1 copy of the LIBRARY row (name + "+"), so dragging
        // looks identical to the node item in the library panel - just floating.
        const def = libDrag.def;
        libDrag.ghost = el('div.rpa-noderow.rpa-dragghost', {}, [
          el('span.rpa-noderow-ico', { html: icon(def.icon) || initial(def.title) }),
          el('span.rpa-noderow-name', { text: def.title }),
          el('span.rpa-add', { html: icon('plusCircle') }),
        ]);
        document.body.appendChild(libDrag.ghost);
        viewport.classList.add('drop-active');
        // Chỉ bật cờ lớp; dấu cộng do setLibTarget() gắn cho đúng một node ngay ở
        // lần rê chuột đầu tiên (dòng cuối hàm này).
        nodeLayer.classList.add('linking');
      }
      libDrag.ghost.style.left = (e.clientX + 14) + 'px';
      libDrag.ghost.style.top = (e.clientY + 10) + 'px';
      setLibTarget(libTargetNode(e.clientX, e.clientY));
    }
    function onLibUp(e) {
      if (!libDrag) return;
      const ld = libDrag; libDrag = null;
      if (ld.ghost) ld.ghost.remove();
      viewport.classList.remove('drop-active');
      nodeLayer.classList.remove('linking');
      nodeLayer.querySelectorAll('.rpa-node.linkable').forEach((x) => x.classList.remove('linkable'));
      if (!ld.started) return;               // a plain click, not a drag
      const r = viewport.getBoundingClientRect();
      if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) return; // dropped off-canvas
      const w = screenToWorld(e.clientX, e.clientY);
      // Nối ĐÚNG vào node đang mang dấu cộng lúc thả - thấy sao thì ra vậy.
      dropNode(ld.def, w.x, w.y, ld.tgt || null);
    }
    window.addEventListener('mousemove', onLibMove); winHandlers.push(['mousemove', onLibMove]);
    window.addEventListener('mouseup', onLibUp); winHandlers.push(['mouseup', onLibUp]);

    // Open the config drawer for a node. Nodes that need no configuration never
    // open a drawer at all (no empty "config border" is shown).
    function selectNode(n) {
      const def = find(n.type);
      if (!def || !def.fields || !def.fields.length) return;
      selectedId = n.id; renderNodes(); openDrawer(n);
    }

    // ============================================== RIGHT CONFIG DRAWER
    const drawerBody = el('div.rpa-drawer-body');
    const drawerHead = el('div.rpa-drawer-head');
    const drawer = el('aside.rpa-drawer', {}, [drawerHead, drawerBody]);

    // When a node has conditional fields (descriptor `when` clauses), changing a
    // controlling field re-renders the visible field list. openDrawer sets this.
    let rerenderFields = null;
    function closeDrawer() { disposeCodeEditors(drawerBody); drawer.classList.remove('open'); selectedId = null; rerenderFields = null; renderNodes(); }

    // Evaluate one `when` clause against the node's current params.
    // Forms: { k, eq } | { k, ne } | { k, in:[…] } | { k, notIn:[…] } |
    //        { or:[ clause | [clause,…], … ] }  (any sub passes; a sub-array = AND)
    // Falls back to the controlling field's `def` when its param isn't set yet.
    function clauseOk(n, def, w) {
      if ('or' in w) {
        return (w.or || []).some((sub) =>
          Array.isArray(sub) ? sub.every((s) => clauseOk(n, def, s)) : clauseOk(n, def, sub));
      }
      const ctrl = def && def.fields.find((x) => x.k === w.k);
      let cur = n.params[w.k];
      if (cur == null || cur === '') cur = ctrl ? ctrl.def : undefined;
      if ('eq' in w) return cur === w.eq;
      if ('ne' in w) return cur !== w.ne;
      if ('in' in w) return Array.isArray(w.in) && w.in.includes(cur);
      if ('notIn' in w) return !(Array.isArray(w.notIn) && w.notIn.includes(cur));
      return true;
    }
    // A field's `when` is a single clause or an array of clauses (all must pass).
    function fieldVisible(n, f, def) {
      if (!f.when) return true;
      const arr = Array.isArray(f.when) ? f.when : [f.when];
      return arr.every((w) => clauseOk(n, def, w));
    }
    // Does any field's visibility depend on `key`? Recurses into `or` clauses.
    function clauseUsesKey(w, key) {
      if (!w) return false;
      if ('or' in w) {
        return (w.or || []).some((sub) =>
          Array.isArray(sub) ? sub.some((s) => clauseUsesKey(s, key)) : clauseUsesKey(sub, key));
      }
      return w.k === key;
    }
    function fieldControls(def, key) {
      return def && def.fields.some((f) => {
        if (!f.when) return false;
        const arr = Array.isArray(f.when) ? f.when : [f.when];
        return arr.some((w) => clauseUsesKey(w, key));
      });
    }

    function openDrawer(n) {
      const def = find(n.type);
      if (!def) return;
      disposeCodeEditors(drawerBody);
      clear(drawerHead); clear(drawerBody);
      drawerBody.classList.remove('has-pinbar');   // chỉ drawer "Biến quy trình" mới có thanh ghim đáy
      drawerHead.appendChild(el('div.rpa-dh-ico', Object.assign({ style: { background: iconBg(n.color || '#64748B'), color: '#fff' } }, def.icon ? { html: icon(def.icon) } : { text: initial(n.title) })));
      drawerHead.appendChild(el('div.rpa-dh-title', { text: n.title }));
      const tools = el('div.rpa-dh-tools');
      if (def.test) tools.appendChild(el('button.btn.subtle.sm', { text: 'Test thử', onclick: () => toast('Tính năng thử nghiệm chưa được cài đặt', 'warn') }));
      if (def.gear) tools.appendChild(iconBtn('settings', { title: 'Cấu hình', onclick: () => toast('Cần đăng nhập tài khoản dịch vụ', 'warn') }));
      tools.appendChild(iconBtn('close', { title: 'Đóng', onclick: closeDrawer }));
      drawerHead.appendChild(tools);

      let subNode = null;
      if (def.subtitle) {
        subNode = el('div.rpa-dsub', { text: def.subtitle + (def.learn ? ' ' : '') });
        if (def.learn) subNode.appendChild(el('a.rpa-learn', { text: 'Tìm hiểu thêm', href: '#', onclick: (e) => { e.preventDefault(); } }));
        drawerBody.appendChild(subNode);
      }
      // Nodes that need no configuration skip the field cascade animation.
      drawer.classList.toggle('plain', !def.fields.length);
      // Render (and re-render, when a `when`-controlling field changes) the visible
      // fields. Fields stay direct children of drawerBody so the cascade CSS holds.
      rerenderFields = () => {
        disposeCodeEditors(drawerBody);
        while (drawerBody.lastChild && drawerBody.lastChild !== subNode) drawerBody.removeChild(drawerBody.lastChild);
        if (!def.fields.length) { drawerBody.appendChild(el('div.muted', { style: { padding: '6px 2px' }, text: 'Thao tác này không cần cấu hình.' })); }
        else def.fields.forEach((f) => { if (!fieldVisible(n, f, def)) return; const fe = buildField(n, f); if (fe) drawerBody.appendChild(fe); });
        // Per-node free-text note (MKTLogin's "Ghi chú" tab), rendered as a textarea
        // at the bottom of every node's config.
        const ta = el('textarea.input', { rows: 3, placeholder: 'Nhập ghi chú cho node…' });
        ta.value = n.params.__note != null ? n.params.__note : '';
        ta.addEventListener('input', () => { n.params.__note = ta.value; scheduleSnapshot(); });
        drawerBody.appendChild(fieldWrap('Ghi chú', ta, false));
      };
      rerenderFields();
      drawer.classList.add('open');
    }

    // commit a field value + refresh the node card. When the changed key controls
    // a conditional field's visibility, re-render the drawer's field list.
    function commit(n, key, value) {
      n.params[key] = value; refreshNodeCard(n); scheduleSnapshot();
      const def = find(n.type);
      // Re-render when the changed key gates a `when` field OR when loop_id changes
      // and the node has loopexpr outputs (their expression embeds the loop_id).
      const feedsLoopExpr = key === 'loop_id' && def && def.fields.some((f) => f.t === 'loopexpr');
      if (rerenderFields && (fieldControls(def, key) || feedsLoopExpr)) rerenderFields();
    }
    function refreshNodeCard(n) {
      const def = find(n.type); const card = n._el; if (!card) return;
      const sub = card.querySelector('.rpa-node-sub'); if (sub) sub.textContent = nodeSummary(n, def);
      const warn = card.querySelector('.rpa-node-warn');
      const miss = requiredMissing(n, def);
      card.classList.toggle('miss', miss);
      card.classList.toggle('ok', !miss && !card.classList.contains('start'));
      if (miss && !warn) card.appendChild(el('div.rpa-node-warn', { html: `${icon('warnCircle')}<span>Chưa cấu hình mục bắt buộc</span>` }));
      if (!miss && warn) warn.remove();
    }

    // ---- field builders ------------------------------------------------
    // Insert text at the input's caret (so the variable picker drops ${name} where
    // the cursor is, not just at the end).
    function insertAtCursor(input, text) {
      const s = input.selectionStart != null ? input.selectionStart : input.value.length;
      const e = input.selectionEnd != null ? input.selectionEnd : input.value.length;
      input.value = input.value.slice(0, s) + text + input.value.slice(e);
      const pos = s + text.length;
      try { input.setSelectionRange(pos, pos); } catch { /* number inputs */ }
    }
    // Collect every "process variable" the current workflow defines: any node whose
    // params write an output (saveTo/returnTo/itemTo/indexTo) or a manage_vars
    // "Thêm biến" row. Mirrors AdsPower's {} picker "Biến quy trình" tab - each entry
    // carries its source-node label + value type.
    function collectProcessVars() {
      const out = []; const seen = new Set();
      const push = (name, desc, type) => { if (!name || seen.has(name)) return; seen.add(name); out.push({ name, desc, type }); };
      // custom variables declared in the start node's "Biến quy trình" drawer.
      // AdsPower always labels these with the origin node title "Bắt đầu quy trình"
      // in the picker's <source> slot - NOT the user's typed description.
      (variables || []).forEach((v) => { if (v && v.name) push(v.name, 'Bắt đầu quy trình', v.type || 'String'); });
      (nodes || []).forEach((n) => {
        const def = find(n.type); if (!def || !def.fields) return;
        def.fields.forEach((f) => {
          if (f.t === 'varrows') {
            const rows = n.params[f.k]; if (!Array.isArray(rows)) return;
            rows.forEach((r) => { if (r && r.name) push(r.name, def.title, r.type || 'String'); });
            return;
          }
          if (Object.prototype.hasOwnProperty.call(VAR_OUT_KEYS, f.k)) {
            const v = n.params[f.k] != null && n.params[f.k] !== '' ? n.params[f.k] : (f.def || '');
            if (v) push(v, def.title, f.varOut || VAR_OUT_KEYS[f.k]);
          }
        });
      });
      return out;
    }

    // The {} button opens AdsPower's variable picker: two tabs (Biến hệ thống /
    // Biến quy trình), each row shown as "name  <source><Type>". Clicking a row
    // inserts ${name} at the caret. Portaled to <body> with fixed positioning so the
    // drawer's overflow never clips it (same approach as customSelect).
    function openVarPicker(input, anchor) {
      document.querySelectorAll('.rpa-varpicker').forEach((m) => m.remove());
      let tab = 'process';
      const sysBtn = el('button.rpa-vp-tab', { type: 'button', text: 'Biến hệ thống', onclick: () => { tab = 'system'; sync(); } });
      const procBtn = el('button.rpa-vp-tab', { type: 'button', text: 'Biến quy trình', onclick: () => { tab = 'process'; sync(); } });
      const body = el('div.rpa-vp-body');
      const menu = el('div.rpa-varpicker', {}, [el('div.rpa-vp-tabs', {}, [sysBtn, procBtn]), body]);
      function sync() {
        sysBtn.classList.toggle('on', tab === 'system');
        procBtn.classList.toggle('on', tab === 'process');
        clear(body);
        const list = tab === 'system' ? SYS_VARS : collectProcessVars();
        if (!list.length) { body.appendChild(el('div.rpa-vp-empty', { text: 'Chưa có biến' })); return; }
        list.forEach((v) => body.appendChild(el('button.rpa-vp-row', {
          type: 'button',
          onclick: () => { insertAtCursor(input, '${' + v.name + '}'); input.dispatchEvent(new Event('input')); close(); input.focus(); },
        }, [el('span.rpa-vp-name', { text: v.name }), el('span.rpa-vp-meta', { text: `<${v.desc}><${v.type}>` })])));
      }
      function place() {
        const r = anchor.getBoundingClientRect(); const w = 300;
        menu.style.position = 'fixed';
        menu.style.left = Math.max(8, r.right - w) + 'px';
        menu.style.width = w + 'px';
        if ((window.innerHeight - r.bottom) < 290) { menu.style.top = 'auto'; menu.style.bottom = (window.innerHeight - r.top + 6) + 'px'; }
        else { menu.style.bottom = 'auto'; menu.style.top = (r.bottom + 6) + 'px'; }
      }
      function close() {
        if (menu.parentNode) menu.parentNode.removeChild(menu);
        document.removeEventListener('mousedown', onDoc);
        window.removeEventListener('scroll', onScroll, true);
        window.removeEventListener('resize', close);
      }
      const onDoc = (e) => { if (!menu.contains(e.target) && e.target !== anchor && !anchor.contains(e.target)) close(); };
      const onScroll = (e) => { if (e && e.target && menu.contains(e.target)) return; close(); };
      sync();
      document.body.appendChild(menu); place();
      setTimeout(() => { document.addEventListener('mousedown', onDoc); window.addEventListener('scroll', onScroll, true); window.addEventListener('resize', close); }, 0);
    }

    // MKTLogin "Tạo biến mới" popup. Every MKT variable dropdown (e.g. Gán biến's
    // "Biến") ends with a "Tạo biến mới" button that opens a small "Biến" dialog:
    // a note listing the PROFILE_*/GROUP_NAME/PROXY_INFO constants, then one or
    // more rows of {Kiểu dữ liệu / Tên biến / Giá trị} with a "Thêm" button and
    // Hủy/Lưu lại. Saving appends the rows to the start-node process-var registry
    // (`variables`) so collectProcessVars() surfaces them in every picker. We show
    // MKT's six type LABELS (String/Number/Boolean/Range/List/Object) but store
    // List→Array so Poly's existing varTypes type-gates keep matching. onDone is
    // called with the first created name so the opener can auto-select it.
    // AdsPower's eight "Kiểu biến" (variable) types for the "Biến quy trình"
    // declaration dropdown. The canonical list lives in node-catalog VAR_TYPES
    // (['String','Number','Boolean','Array','Object','Text','File','Folder']);
    // reuse it here and for the quick-create dialog so both match AdsPower 1:1.
    const CREATE_VAR_TYPES = VAR_TYPES;
    function openCreateVar(onDone) {
      const rows = [{ type: 'String', name: '', value: '' }];
      const listEl = el('div.rpa-vars');
      function rebuild() {
        clear(listEl);
        rows.forEach((row, i) => {
          const type = customSelect(CREATE_VAR_TYPES, { value: row.type || 'String', width: 130, onChange: (x) => { row.type = x; } });
          const name = el('input.input', { value: row.name, placeholder: 'Tên biến' });
          name.addEventListener('input', () => { row.name = name.value; });
          const val = el('input.input', { value: row.value, placeholder: 'Giá trị' });
          val.addEventListener('input', () => { row.value = val.value; });
          const acts = [];
          if (rows.length > 1) acts.push(iconBtn('close', { title: 'Xóa', onclick: () => { rows.splice(i, 1); rebuild(); } }));
          listEl.appendChild(el('div.rpa-varcard', {}, [
            el('div.rpa-varrow', {}, [type, name, el('div.rpa-varacts', {}, acts)]),
            el('div.rpa-field', {}, [el('label', {}, [el('span', { text: 'Giá trị' })]), val]),
          ]));
        });
      }
      rebuild();
      const addBtn = el('button.rpa-vp-create', { type: 'button', html: `${icon('plus')}<span>Thêm</span>`, onclick: () => { rows.push({ type: 'String', name: '', value: '' }); rebuild(); } });
      const head = el('div', { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', margin: '8px 0 4px' } }, [el('span', { style: { fontWeight: '600', fontSize: '13px' }, text: 'Biến' }), addBtn]);
      openModal({
        title: 'Biến', width: 560,
        body: [
          el('div.rpa-dsub', {}, [el('span', { style: { color: '#e8833a', marginRight: '4px' }, text: '*' }), el('span', { text: 'Hằng số PROFILE_ID, PROFILE_NAME, GROUP_NAME, PROXY_INFO' })]),
          head,
          listEl,
        ],
        footer: [
          el('button.btn', { text: 'Hủy', onclick: closeModal }),
          el('button.btn.primary', { text: 'Lưu lại', onclick: () => {
            let first = '';
            rows.forEach((r) => {
              const nm = (r.name || '').trim(); if (!nm) return;
              const ty = r.type === 'List' ? 'Array' : r.type;
              const existing = variables.find((v) => v && v.name === nm);
              if (existing) { existing.type = ty; existing.value = r.value || ''; }
              // local: true → BIẾN LÀM VIỆC (tạo nhanh ngay trong node để gán/tính toán),
              // KHÔNG phải tham số đầu vào nên không hiện ô nhập ở tab "Tham số đầu vào".
              // Muốn có tham số đầu vào thì phải khai báo ở drawer "Biến quy trình" (node Bắt đầu).
              else variables.push({ name: nm, type: ty, value: r.value || '', desc: '', local: true });
              if (!first) first = nm;
            });
            closeModal(); snapshot();
            if (onDone) onDone(first);
          } }),
        ],
      });
    }

    // MKTLogin "Biến nhận dữ liệu" / "Biến nhận giá trị" OUTPUT field. AUDIT 2026-06-30
    // (live, "Lấy nội dung HTML"): clicking the field opens an EDITABLE combobox - a
    // text input you can type a brand-new var name into, with a dropdown listing the
    // existing PROCESS variables (NO "Biến hệ thống" tab: outputs can't target read-only
    // system constants - flat list) and a "Tạo biến mới" footer button (pencil icon).
    // Picking a row or creating a var fills the input. This replaces the old plain
    // t:"text" rendering for every var-output field (user: "bấm vào là dạng combobox ra
    // list các biến đã tạo và nút tạo mới"). Routed from buildField's text case via
    // f.varOut OR the shared output placeholder VAR_OUT_PH.
    const VAR_OUT_PH = 'Hãy nhập biến để lưu kết quả';
    function varOutSelect(n, f) {
      const wrapEl = el('div.pc-select.rpa-varout'); wrapEl.style.width = '100%';
      const inp = el('input.input', { value: n.params[f.k] != null ? n.params[f.k] : '', placeholder: f.ph || 'Biến nhận giá trị' });
      const chev = el('span.rpa-varout-chev', { html: icon('chevronDown') });
      let menu = null; let body = null;
      const onDoc = (e) => { if (menu && !menu.contains(e.target) && !wrapEl.contains(e.target)) close(); };
      const onScroll = (e) => { if (e && e.target && menu && menu.contains(e.target)) return; close(); };
      function close() {
        if (menu && menu.parentNode) menu.parentNode.removeChild(menu);
        menu = null; body = null; wrapEl.classList.remove('open');
        document.removeEventListener('mousedown', onDoc);
        window.removeEventListener('scroll', onScroll, true);
        window.removeEventListener('resize', close);
      }
      function sync() {
        if (!body) return;
        clear(body);
        const q = (inp.value || '').toLowerCase();
        const list = collectProcessVars().filter((v) => v.name !== inp.value && (!q || v.name.toLowerCase().includes(q)));
        body.style.display = list.length ? '' : 'none';
        list.forEach((v) => body.appendChild(el('button.rpa-vp-row', {
          type: 'button',
          onmousedown: (e) => { e.preventDefault(); inp.value = v.name; commit(n, f.k, v.name); close(); },
        }, [el('span.rpa-vp-name', { text: v.name }), el('span.rpa-vp-meta', { text: `<${v.desc}><${v.type}>` })])));
      }
      function open() {
        if (menu) return;
        body = el('div.rpa-vp-body');
        const createBtn = el('button.rpa-vp-create', {
          type: 'button', html: `${icon('edit')}<span>Tạo biến mới</span>`,
          onmousedown: (e) => { e.preventDefault(); close(); openCreateVar((nm) => { if (nm) { inp.value = nm; commit(n, f.k, nm); } }); },
        });
        menu = el('div.rpa-varpicker.rpa-varout-pop', {}, [body, createBtn]);
        sync();
        document.body.appendChild(menu);
        const r = inp.getBoundingClientRect();
        menu.style.position = 'fixed'; menu.style.left = r.left + 'px'; menu.style.width = r.width + 'px';
        if ((window.innerHeight - r.bottom) < 250) { menu.style.top = 'auto'; menu.style.bottom = (window.innerHeight - r.top + 6) + 'px'; }
        else { menu.style.bottom = 'auto'; menu.style.top = (r.bottom + 6) + 'px'; }
        wrapEl.classList.add('open');
        setTimeout(() => { document.addEventListener('mousedown', onDoc); window.addEventListener('scroll', onScroll, true); window.addEventListener('resize', close); }, 0);
      }
      inp.addEventListener('input', () => { commit(n, f.k, inp.value); sync(); });
      inp.addEventListener('focus', open);
      inp.addEventListener('click', () => { if (!menu) open(); });
      chev.addEventListener('mousedown', (e) => { e.preventDefault(); if (menu) close(); else { inp.focus(); open(); } });
      wrapEl.appendChild(inp); wrapEl.appendChild(chev);
      return wrapEl;
    }

    // A select-style control whose dropdown IS AdsPower's 2-tab variable picker
    // (Biến hệ thống / Biến quy trình). Used by var-consumer fields (varsrc:true)
    // like "Đưa biến vào" / "Dữ liệu" / "Tên biến". Unlike openVarPicker
    // (which inserts ${name} at a text caret), picking a row here SETS the field
    // value to the chosen variable name. `f.varTypes` mirrors AdsPower's per-field
    // type gate: undefined → every variable; [] → only <Any>-typed; ['String',…]
    // → those types (plus <Any>, which fits anywhere). System vars are all String,
    // so a [] gate leaves the "Biến hệ thống" tab empty - exactly like AdsPower.
    function varSelect(n, f) {
      let val = n.params[f.k] != null && n.params[f.k] !== '' ? n.params[f.k] : (f.def || '');
      if (val) n.params[f.k] = val;
      const allows = (type) => !f.varTypes || type === 'Any' || f.varTypes.includes(type);
      const combo = el('div.pc-select'); combo.style.width = '100%';
      const trigger = el('button.pc-select-trigger', { type: 'button' });
      const renderTrigger = () => {
        trigger.innerHTML = `<span class="lbl${val ? '' : ' ph'}">${val || (f.ph || 'Hãy chọn biến')}</span><span class="chev">${icon('chevronDown')}</span>`;
      };
      let tab = 'process'; let menu = null;
      const onDoc = (e) => { if (menu && !menu.contains(e.target) && !combo.contains(e.target)) close(); };
      const onScroll = (e) => { if (e && e.target && menu && menu.contains(e.target)) return; close(); };
      function close() {
        if (menu && menu.parentNode) menu.parentNode.removeChild(menu);
        menu = null; combo.classList.remove('open');
        document.removeEventListener('mousedown', onDoc);
        window.removeEventListener('scroll', onScroll, true);
        window.removeEventListener('resize', close);
      }
      function open() {
        const sysBtn = el('button.rpa-vp-tab', { type: 'button', text: 'Biến hệ thống', onclick: () => { tab = 'system'; sync(); } });
        const procBtn = el('button.rpa-vp-tab', { type: 'button', text: 'Biến quy trình', onclick: () => { tab = 'process'; sync(); } });
        const body = el('div.rpa-vp-body');
        const createBtn = el('button.rpa-vp-create', {
          type: 'button',
          html: `${icon('plus')}<span>Tạo biến mới</span>`,
          onclick: () => { close(); openCreateVar((nm) => { if (nm) { val = nm; n.params[f.k] = val; commit(n, f.k, val); renderTrigger(); } }); },
        });
        menu = el('div.rpa-varpicker', {}, [el('div.rpa-vp-tabs', {}, [sysBtn, procBtn]), body, createBtn]);
        function sync() {
          sysBtn.classList.toggle('on', tab === 'system');
          procBtn.classList.toggle('on', tab === 'process');
          clear(body);
          const list = (tab === 'system' ? SYS_VARS : collectProcessVars()).filter((v) => allows(v.type));
          if (!list.length) { body.appendChild(el('div.rpa-vp-empty', { text: 'Không có dữ liệu' })); return; }
          list.forEach((v) => body.appendChild(el('button.rpa-vp-row' + (v.name === val ? '.sel' : ''), {
            type: 'button',
            onclick: () => { val = v.name; n.params[f.k] = val; commit(n, f.k, val); renderTrigger(); close(); },
          }, [el('span.rpa-vp-name', { text: v.name }), el('span.rpa-vp-meta', { text: `<${v.desc}><${v.type}>` })])));
        }
        sync();
        document.body.appendChild(menu);
        const r = trigger.getBoundingClientRect();
        menu.style.position = 'fixed';
        menu.style.left = r.left + 'px';
        menu.style.width = r.width + 'px';
        if ((window.innerHeight - r.bottom) < 290) { menu.style.top = 'auto'; menu.style.bottom = (window.innerHeight - r.top + 6) + 'px'; }
        else { menu.style.bottom = 'auto'; menu.style.top = (r.bottom + 6) + 'px'; }
        combo.classList.add('open');
        setTimeout(() => { document.addEventListener('mousedown', onDoc); window.addEventListener('scroll', onScroll, true); window.addEventListener('resize', close); }, 0);
      }
      trigger.onclick = () => { if (combo.classList.contains('open')) close(); else open(); };
      combo.appendChild(trigger); renderTrigger();
      return combo;
    }
    function varBtn(input) { return el('button.rpa-affix-btn.var', { type: 'button', html: icon('varInsert'), title: 'Chèn biến', onclick: (e) => { e.preventDefault(); e.stopPropagation(); openVarPicker(input, e.currentTarget); } }); }
    // Var button for a `code` field: when Monaco is mounted, sync its caret offset
    // into the hidden textarea first so the picker inserts ${var} at the real
    // cursor position, then mirror the result back into Monaco (via the textarea's
    // `input` listener). Falls back to plain textarea insertion if Monaco is absent.
    function codeVarBtn(ta, getEditor) {
      return el('button.rpa-affix-btn.var', { type: 'button', html: icon('varInsert'), title: 'Chèn biến', onclick: (e) => {
        e.preventDefault(); e.stopPropagation();
        const ed = getEditor && getEditor();
        if (ed) {
          try {
            const off = ed.getModel().getOffsetAt(ed.getPosition());
            ta.value = ed.getValue();
            ta.setSelectionRange(off, off);
          } catch { /* ignore */ }
        }
        openVarPicker(ta, e.currentTarget);
      } });
    }
    function folderBtn(input) {
      return el('button.rpa-affix-btn.folder', { type: 'button', html: icon('folder'), title: 'Chọn thư mục', onclick: async (e) => {
        e.preventDefault(); e.stopPropagation();
        const p = await window.vt?.dialog?.openFolder();
        if (p) { input.value = p; input.dispatchEvent(new Event('input')); }
      } });
    }
    // Chọn TỆP (không phải thư mục). Field khai `file: true` dùng nút này; kèm
    // `fileFilters` để hộp thoại chỉ hiện đúng loại tệp (vd .json, .csv).
    function fileBtn(input, filters) {
      return el('button.rpa-affix-btn.file', { type: 'button', html: icon('fileText'), title: 'Chọn tệp', onclick: async (e) => {
        e.preventDefault(); e.stopPropagation();
        const p = await window.vt?.dialog?.openFile(filters && filters.length ? { filters } : undefined);
        if (p) { input.value = p; input.dispatchEvent(new Event('input')); }
      } });
    }

    // Wrap an input/textarea so its action buttons (chèn biến, chọn thư mục) sit
    // INSIDE the field at the right edge - matching AdsPower's compact UI - instead
    // of as a separate box beside it. Returns the input untouched if no buttons.
    function affixInput(input, btns) {
      const list = (btns || []).filter(Boolean);
      if (!list.length) return input;
      input.classList.add('has-affix');
      const isArea = input.tagName === 'TEXTAREA';
      return el('div.rpa-inputwrap' + (isArea ? '.area' : ''), {}, [input, el('div.rpa-affix', {}, list)]);
    }

    // Icon "thông tin" (i trong vòng tròn) đặt cạnh nhãn; hover ra tooltip hướng dẫn.
    // Dùng CHUNG bộ tooltip toàn app (setRichTooltip) để đồng bộ giao diện và không
    // bị khung cấu hình cắt mất - tooltip được gắn vào <body>.
    const LBL_INFO_SVG = '<svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path d="M0 0h24v24H0z" fill="none"/><g fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4m0-4h.01"/></g></svg>';
    function fieldWrap(label, control, req, tip) {
      const lbl = label ? el('span.rpa-lbl', {}, [req ? el('span.req', { text: '*' }) : null, el('span', { text: label })]) : null;
      if (lbl && tip) {
        // `title` để installTooltips nhận diện được node; nội dung giàu định dạng do
        // setRichTooltip dựng (thẻ HTML nhiều dòng), render trong .app-tooltip.rich.
        const tipEl = el('span.rpa-lbl-tip', { html: LBL_INFO_SVG, title: 'Hướng dẫn điền Range' });
        setRichTooltip(tipEl, () => el('div.rpa-tip-guide', { html: tip }));
        lbl.appendChild(tipEl);
      }
      return el('div.rpa-field', {}, [
        lbl ? el('label', {}, [lbl]) : null,
        control,
      ]);
    }

    // Dòng gợi ý (hint) dưới ô nhập. Nếu field khai báo f.doc (URL tài liệu) thì
    // phần chữ khớp "Xem hướng dẫn" trong hint được tô MÀU BRAND + GẠCH CHÂN và
    // bấm vào sẽ mở trang docs ở trình duyệt ngoài. Field không có f.doc thì hiển
    // thị hint dạng chữ thường như cũ (không đổi hành vi các node khác).
    function hintEl(f) {
      const wrap = el('div.rpa-hint');
      const text = f.hint || '';
      if (f.doc) {
        const marker = f.docText || 'Xem hướng dẫn';
        const idx = text.toLowerCase().indexOf(marker.toLowerCase());
        if (idx >= 0) {
          const before = text.slice(0, idx);
          const label = text.slice(idx, idx + marker.length);
          const after = text.slice(idx + marker.length);
          if (before) wrap.appendChild(document.createTextNode(before));
          wrap.appendChild(el('a.rpa-doc-link', {
            text: label,
            onclick: () => { try { window.vt.shell.openExternal(f.doc); } catch { /* ignore */ } },
          }));
          if (after) wrap.appendChild(document.createTextNode(after));
          return wrap;
        }
      }
      wrap.textContent = text;
      return wrap;
    }

    function buildField(n, f) {
      switch (f.t) {
        case 'info': return el('div.rpa-info', { text: f.text });
        case 'note': {
          const ta = el('textarea.input', { rows: 3, maxlength: 100, placeholder: 'Tùy chọn' });
          ta.value = n.params[f.k] || '';
          const counter = el('span.rpa-counterer', { text: `${(n.params[f.k] || '').length}/100` });
          ta.addEventListener('input', () => { commit(n, f.k, ta.value); counter.textContent = `${ta.value.length}/100`; });
          return el('div.rpa-field', {}, [el('label', {}, [el('span', { text: f.label }), counter]), ta]);
        }
        case 'text': {
          // var-output fields (Biến nhận dữ liệu/giá trị) render as MKT's editable
          // var-combobox (typeable + dropdown of process vars + "Tạo biến mới"),
          // not a plain text box. Detected by explicit f.varOut or the shared
          // output placeholder. Hint still appended below.
          if (f.varOut || f.ph === VAR_OUT_PH) {
            const ow = fieldWrap(f.label || null, varOutSelect(n, f), f.req);
            if (f.hint) ow.appendChild(el('div.rpa-hint', { text: f.hint }));
            return ow;
          }
          const inp = el('input.input', { value: n.params[f.k] != null ? n.params[f.k] : '', placeholder: f.ph || '' });
          inp.addEventListener('input', () => commit(n, f.k, inp.value));
          const affixed = affixInput(inp, [f.varIns ? varBtn(inp) : null, f.file ? fileBtn(inp, f.fileFilters) : null, f.folder ? folderBtn(inp) : null]);
          const line = el('div.rpa-inline', {}, [affixed]);
          if (f.suffix) line.appendChild(el('span.rpa-suffix', { text: f.suffix }));
          const wrap = fieldWrap(f.label || null, line, f.req, f.labelTip);
          if (f.quick) wrap.appendChild(el('div.rpa-quick', {}, f.quick.map((q) => el('button.chip', { type: 'button', text: q, onclick: () => { inp.value = q; commit(n, f.k, q); } }))));
          if (f.hint) wrap.appendChild(hintEl(f));
          return wrap;
        }
        case 'loopexpr': {
          // MKTLogin loop output: a READ-ONLY, copyable expression that references
          // the current iteration's item / index, scoped by the loop's ID -
          //   {{loop.<loop_id>.data}}  /  {{loop.<loop_id>.loop_order}}
          // The user pastes it into any downstream field. It rebuilds live when the
          // sibling "ID" (loop_id) field changes (see commit()).
          const lid = (n.params.loop_id != null && n.params.loop_id !== '') ? n.params.loop_id : '<ID>';
          const expr = `{{loop.${lid}.${f.exprSuffix}}}`;
          n.params[f.k] = expr; // persist so serialize/summary show it
          const inp = el('input.input', { value: expr, readonly: 'readonly', title: expr });
          inp.style.cursor = 'text';
          inp.addEventListener('focus', () => inp.select());
          const copyBtn = el('button.rpa-affix-btn.copy', {
            type: 'button', html: icon('copy'), title: 'Sao chép biểu thức',
            onclick: (e) => {
              e.preventDefault(); e.stopPropagation();
              try { navigator.clipboard.writeText(expr); } catch { /* ignore */ }
              inp.focus(); inp.select();
              toast('Đã sao chép biểu thức', 'ok');
            },
          });
          const line = el('div.rpa-inline', {}, [affixInput(inp, [copyBtn])]);
          const wrap = fieldWrap(f.label || null, line, f.req);
          if (f.hint) wrap.appendChild(el('div.rpa-hint', { text: f.hint }));
          return wrap;
        }
        case 'textarea': {
          // NOTE: a <textarea>'s content lives in a child text node, NOT a `value`
          // attribute - el() applies unknown keys via setAttribute, which is a no-op
          // for textarea. Set `.value` as a PROPERTY so a saved value restores when
          // the node-config drawer is reopened (else the field shows empty).
          const ta = el('textarea.input', { rows: f.rows || 4, placeholder: f.ph || '' });
          ta.value = n.params[f.k] != null ? n.params[f.k] : '';
          ta.addEventListener('input', () => commit(n, f.k, ta.value));
          const wrap = affixInput(ta, [f.varIns ? varBtn(ta) : null]);
          return fieldWrap(f.label || null, wrap, f.req);
        }
        case 'number': {
          // persist the default so what's shown == what executes (else the
          // executor falls back to its own value and the config looks ignored)
          if (n.params[f.k] == null && f.def != null) n.params[f.k] = f.def;
          const inp = el('input.input', { type: 'number', value: n.params[f.k] != null ? n.params[f.k] : (f.def != null ? f.def : '') });
          inp.addEventListener('input', () => commit(n, f.k, inp.value));
          const line = el('div.rpa-inline', {}, [affixInput(inp, [f.varIns ? varBtn(inp) : null]), f.unit ? el('span.rpa-unit', { text: f.unit }) : null]);
          const wrap = fieldWrap(f.label || null, line, f.req);
          if (f.hint) wrap.appendChild(el('div.rpa-hint', { text: f.hint }));
          return wrap;
        }
        case 'timeout': {
          if (n.params[f.k] == null && f.def != null) n.params[f.k] = f.def;
          const inp = el('input.input', { type: 'number', value: n.params[f.k] != null ? n.params[f.k] : f.def });
          inp.addEventListener('input', () => commit(n, f.k, inp.value));
          const line = el('div.rpa-inline', {}, [inp, el('span.rpa-unit', { text: 'Mili giây' })]);
          return el('div.rpa-field', {}, [el('label', {}, [el('span', { text: f.label })]), line, el('div.rpa-hint', { text: '1 giây = 1000 mili giây' })]);
        }
        case 'select': {
          // var-consumer dropdowns (Đưa biến vào / Tên biến / Dữ liệu) open
          // AdsPower's 2-tab variable picker (system + process vars), type-filtered
          // by f.varTypes. Everything else is a plain hardcoded-option select.
          if (f.varsrc) return fieldWrap(f.label || null, varSelect(n, f), f.req);
          const cur = n.params[f.k] != null && n.params[f.k] !== '' ? n.params[f.k] : (f.def || '');
          const sel = customSelect(f.options || [], { value: cur, placeholder: f.ph || 'Hãy chọn', onChange: (v) => commit(n, f.k, v), width: '100%' });
          if (cur) n.params[f.k] = cur;
          const selWrap = fieldWrap(f.label || null, sel, f.req);
          if (f.hint) selWrap.appendChild(el('div.rpa-hint', { text: f.hint }));
          return selWrap;
        }
        case 'select2': {
          // Two inline controls under a single label (AdsPower's "Tình trạng"
          // / "Vị trí" pattern). The first is always a dropdown. The second is
          // a dropdown by default, but when `pxWhen` is set and the first
          // value === pxWhen the second becomes a number+var input (AdsPower's
          // "Vị trí / Pixel" scroll pattern, where Pixel turns the position
          // dropdown into a numeric offset).
          const c1 = n.params[f.k] != null && n.params[f.k] !== '' ? n.params[f.k] : (f.def || '');
          if (c1) n.params[f.k] = c1;
          const line = el('div.rpa-inline');
          let second = null;
          function buildSecond() {
            if (second && second.parentNode === line) line.removeChild(second);
            second = null;
            const cur1 = n.params[f.k] || f.def || '';
            if (f.pxWhen && cur1 === f.pxWhen) {
              // Pixel mode: second control becomes a number+var input.
              const inp = el('input.input', { type: 'number', value: n.params[f.k2] != null && n.params[f.k2] !== '' ? n.params[f.k2] : (f.pxDef != null ? f.pxDef : 0) });
              inp.addEventListener('input', () => commit(n, f.k2, inp.value));
              second = affixInput(inp, [varBtn(inp)]);
              second.style.width = '50%';
            } else if (f.txWhen && cur1 === f.txWhen) {
              // Text mode: second control becomes a free-text input (e.g. the
              // attribute name for "Thuộc tính" extraction).
              const inp = el('input.input', { value: n.params[f.k2] != null ? n.params[f.k2] : '', placeholder: f.txPh || '' });
              inp.addEventListener('input', () => commit(n, f.k2, inp.value));
              second = f.txVar ? affixInput(inp, [varBtn(inp)]) : inp;
              second.style.width = '50%';
            } else if (f.options2 || f.procsrc) {
              // procsrc: populate the second dropdown from the saved flow list
              // (every OTHER workflow), value = flow id, label = flow name. Used by
              // the "Sử dụng các quy trình khác" node.
              const opts2 = f.procsrc
                ? (FLOWS || []).filter((fl) => fl && fl.id !== flow.id).map((fl) => ({ value: fl.id, label: fl.name || '(không tên)' }))
                : (f.options2 || []);
              const c2 = n.params[f.k2] != null && n.params[f.k2] !== '' ? n.params[f.k2] : (f.def2 || '');
              if (c2 && !f.procsrc) n.params[f.k2] = c2;
              second = customSelect(opts2, { value: c2, placeholder: f.ph2 || 'Hãy chọn', onChange: (v) => commit(n, f.k2, v), width: '50%' });
            }
            if (second) line.appendChild(second);
          }
          const s1 = customSelect(f.options || [], { value: c1, placeholder: f.ph || 'Hãy chọn', onChange: (v) => { commit(n, f.k, v); buildSecond(); }, width: '50%' });
          line.appendChild(s1);
          buildSecond();
          return fieldWrap(f.label || null, line, f.req);
        }
        case 'waittime': {
          // mode dropdown + value inline under one label; "Cố định" => single
          // number, "Ngẫu nhiên" => min-max range. (AdsPower "Thời gian chờ".)
          const line = el('div.rpa-inline');
          function rebuild() {
            clear(line);
            const mode = n.params[f.k] || f.def || 'Cố định';
            n.params[f.k] = mode;
            line.appendChild(customSelect(['Cố định', 'Ngẫu nhiên'], { value: mode, width: 120, onChange: (v) => { commit(n, f.k, v); rebuild(); } }));
            if (mode === 'Ngẫu nhiên') {
              // persist defaults so the saved config matches what's shown
              if (n.params[f.kMin] == null) n.params[f.kMin] = f.minDef;
              if (n.params[f.kMax] == null) n.params[f.kMax] = f.maxDef;
              const mn = el('input.input', { type: 'number', value: n.params[f.kMin] != null ? n.params[f.kMin] : f.minDef, style: { width: '88px' } });
              mn.addEventListener('input', () => commit(n, f.kMin, mn.value));
              const mx = el('input.input', { type: 'number', value: n.params[f.kMax] != null ? n.params[f.kMax] : f.maxDef, style: { width: '88px' } });
              mx.addEventListener('input', () => commit(n, f.kMax, mx.value));
              line.appendChild(mn); line.appendChild(el('span.rpa-dash', { text: '-' })); line.appendChild(mx);
            } else {
              if (n.params[f.kFixed] == null) n.params[f.kFixed] = f.fixedDef;
              const num = el('input.input', { type: 'number', value: n.params[f.kFixed] != null ? n.params[f.kFixed] : f.fixedDef, style: { width: '120px' } });
              num.addEventListener('input', () => commit(n, f.kFixed, num.value));
              line.appendChild(num);
            }
            line.appendChild(el('span.rpa-unit', { text: f.unit || 'Mili giây' }));
          }
          rebuild();
          const wrap = fieldWrap(f.label || null, line, f.req);
          if (f.hint) wrap.appendChild(el('div.rpa-hint', { text: f.hint }));
          return wrap;
        }
        case 'seg': {
          const opts = (f.options || []).map((o) => (typeof o === 'string' ? { value: o, label: o } : o));
          const cur = n.params[f.k] != null && n.params[f.k] !== '' ? n.params[f.k] : (f.def != null ? f.def : (opts[0] && opts[0].value));
          n.params[f.k] = cur;
          const seg = el('div.pc-seg.rpa-seg');
          opts.forEach((o) => seg.appendChild(el('button.seg-opt' + (o.value === cur ? '.active' : ''), { type: 'button', text: o.label, onclick: () => { commit(n, f.k, o.value); seg.querySelectorAll('.seg-opt').forEach((x) => x.classList.toggle('active', x.textContent === o.label)); } })));
          return fieldWrap(f.label || null, seg, f.req);
        }
        case 'radio': {
          const opts = (f.options || []).map((o) => (typeof o === 'string' ? { value: o, label: o } : o));
          const cur = n.params[f.k] != null && n.params[f.k] !== '' ? n.params[f.k] : (f.def != null ? f.def : (opts[0] && opts[0].value));
          n.params[f.k] = cur;
          const grp = el('div.pc-radios'); const name = f.k + '_' + n.id;
          opts.forEach((o) => {
            const r = el('input', { type: 'radio', name, value: o.value }); if (o.value === cur) r.checked = true;
            r.addEventListener('change', () => { if (r.checked) commit(n, f.k, o.value); });
            grp.appendChild(el('label.pc-radio', {}, [r, el('span', { text: o.label })]));
          });
          return fieldWrap(f.label || null, grp, f.req);
        }
        case 'switch': {
          const on = n.params[f.k] != null ? !!n.params[f.k] : !!f.def;
          n.params[f.k] = on;
          const sw = el('button.switch' + (on ? '.on' : ''), { type: 'button' }, [el('span.knob')]);
          sw.addEventListener('click', () => { const v = !sw.classList.contains('on'); sw.classList.toggle('on', v); commit(n, f.k, v); });
          return el('div.rpa-field.row', {}, [el('label', {}, [el('span', { text: f.label })]), sw]);
        }
        case 'check': {
          const on = n.params[f.k] != null ? !!n.params[f.k] : !!f.def;
          n.params[f.k] = on;
          const cb = el('input', { type: 'checkbox' }); cb.checked = on;
          cb.addEventListener('change', () => commit(n, f.k, cb.checked));
          return el('label.rpa-check', {}, [cb, el('span', { text: f.label })]);
        }
        case 'checks': {
          const opts = (f.options || []).map((o) => (typeof o === 'string' ? { value: o, label: o } : o));
          if (!Array.isArray(n.params[f.k])) n.params[f.k] = [];
          const grp = el('div.rpa-checks');
          opts.forEach((o) => {
            const cb = el('input', { type: 'checkbox' }); cb.checked = n.params[f.k].includes(o.value);
            cb.addEventListener('change', () => { const set = new Set(n.params[f.k]); if (cb.checked) set.add(o.value); else set.delete(o.value); commit(n, f.k, [...set]); });
            grp.appendChild(el('label.rpa-check', {}, [cb, el('span', { text: o.label })]));
          });
          return fieldWrap(f.label || null, grp, f.req);
        }
        case 'range': {
          const v = n.params[f.k] || { min: f.min, max: f.max }; n.params[f.k] = v;
          const a = el('input.input', { type: 'number', value: v.min != null ? v.min : '' });
          const b = el('input.input', { type: 'number', value: v.max != null ? v.max : '' });
          a.addEventListener('input', () => { v.min = a.value; commit(n, f.k, v); });
          b.addEventListener('input', () => { v.max = b.value; commit(n, f.k, v); });
          const line = el('div.rpa-inline', {}, [a, el('span.rpa-dash', { text: '-' }), b, f.unit ? el('span.rpa-unit', { text: f.unit }) : null]);
          return fieldWrap(f.label || null, line, f.req);
        }
        case 'kvlist': {
          // MKTLogin's repeatable Key/Value section (URL Parameter, Custom Header,
          // Form-Data, Form-Urlencoded): a collapsible bar with the label + a "Thêm"
          // button, then one row per entry - Key input, Value input ({x} var-insert),
          // and a delete control. Stored as n.params[f.k] = [{key,value}, …].
          if (!Array.isArray(n.params[f.k])) n.params[f.k] = [];
          const rows = n.params[f.k];
          const sec = el('div.rpa-kv');
          const body = el('div.rpa-kv-body');
          let open = true;
          const chev = el('span.rpa-kv-chev', { html: icon('chevronDown') });
          const addBtn = el('button.rpa-kv-add', { type: 'button', html: `${icon('plusCircle') || '+'}<span>Thêm</span>` });
          const bar = el('div.rpa-kv-bar', {}, [el('div.rpa-kv-head', {}, [chev, el('span', { text: f.label || '' })]), addBtn]);
          function syncOpen() { sec.classList.toggle('collapsed', !open); }
          bar.addEventListener('click', (e) => { if (addBtn.contains(e.target)) return; open = !open; syncOpen(); });
          function renderRows() {
            clear(body);
            const selKey = Array.isArray(f.keyOptions);
            rows.forEach((r, i) => {
              let k;
              if (selKey) {
                // Key là dropdown: menu nới rộng tối thiểu 240px để hiện đủ nhãn value
                // (vd "Email recovery") dù ô key chỉ chiếm nửa hàng.
                k = customSelect(f.keyOptions, { value: r.key != null ? r.key : '', placeholder: f.keyPh || 'Key', onChange: (val) => { r.key = val; commit(n, f.k, rows); }, width: '100%', menuMinWidth: 240 });
                k.classList.add('rpa-kv-key');
              } else {
                k = el('input.input.rpa-kv-key', { value: r.key != null ? r.key : '', placeholder: 'Key' });
                k.addEventListener('input', () => { r.key = k.value; commit(n, f.k, rows); });
              }
              const v = el('input.input', { value: r.value != null ? r.value : '', placeholder: 'Value' });
              v.addEventListener('input', () => { r.value = v.value; commit(n, f.k, rows); });
              const del = el('button.rpa-kv-del', { type: 'button', html: icon('close') || '×', title: 'Xoá', onclick: () => { rows.splice(i, 1); commit(n, f.k, rows); renderRows(); } });
              // Hàng key-dropdown gắn thêm `.sel` để CSS cho key/value RỘNG BẰNG NHAU.
              body.appendChild(el('div.rpa-kv-row' + (selKey ? '.sel' : ''), {}, [k, affixInput(v, f.varIns !== false ? [varBtn(v)] : []), del]));
            });
          }
          addBtn.addEventListener('click', (e) => { e.stopPropagation(); rows.push({ key: '', value: '' }); commit(n, f.k, rows); open = true; syncOpen(); renderRows(); });
          renderRows(); syncOpen();
          sec.appendChild(bar); sec.appendChild(body);
          return sec;
        }
        case 'code': {
          // MKTLogin's JSON/script body editor. We mount a real Monaco editor for
          // syntax highlighting on a WHITE surface (theme `vs`). A hidden <textarea>
          // stays the source of truth (commit + the {x} var-picker) and is the
          // graceful fallback shown if Monaco fails to load.
          const rows = f.rows || 6;
          const ta = el('textarea.input.rpa-code', { rows, placeholder: f.ph || '' });
          ta.value = n.params[f.k] != null ? n.params[f.k] : (f.def != null ? f.def : '');

          const mount = el('div.rpa-monaco');
          mount.style.height = (rows * 19 + 16) + 'px';
          const host = el('div.rpa-code-host', {}, [ta, mount]);

          let editor = null, syncing = false;
          // commit on textarea edits (fallback) AND mirror picker inserts → Monaco
          ta.addEventListener('input', () => {
            commit(n, f.k, ta.value);
            if (editor && !syncing && ta.value !== editor.getValue()) {
              syncing = true; editor.setValue(ta.value); syncing = false;
            }
          });

          loadMonaco().then((monaco) => {
            editor = monaco.editor.create(mount, {
              value: ta.value,
              language: f.lang || 'javascript',
              theme: 'vs',
              automaticLayout: true,
              minimap: { enabled: false },
              scrollBeyondLastLine: false,
              fontSize: 13,
              fontFamily: '"Cascadia Code","Cascadia Mono",ui-monospace,SFMono-Regular,Menlo,Consolas,monospace',
              tabSize: 2,
              wordWrap: 'on',
              padding: { top: 8, bottom: 8 },
              scrollbar: { alwaysConsumeMouseWheel: false },
              // Keep IntelliSense (suggestions/hover) ON. `fixedOverflowWidgets`
              // renders the popups with position:fixed so the short editor box's
              // `overflow:hidden` can't clip them - they stay fully themed in the
              // editor's own DOM. For this to escape clipping, NO ancestor between
              // the editor and the viewport may have a `transform` (which would turn
              // fixed into a clipped containing block) - see the drawer CSS notes.
              fixedOverflowWidgets: true,
            });
            mount.__monacoEditor = editor; // for disposal on drawer rebuild
            host.classList.add('monaco-on'); // CSS hides the textarea, shows Monaco
            editor.onDidChangeModelContent(() => {
              if (syncing) return;
              syncing = true; ta.value = editor.getValue(); commit(n, f.k, ta.value); syncing = false;
            });
          }).catch(() => { /* keep textarea fallback */ });

          const btns = f.varIns !== false ? [codeVarBtn(ta, () => editor)] : [];
          const wrap = btns.length ? el('div.rpa-inputwrap.area', {}, [host, el('div.rpa-affix', {}, btns)]) : host;
          return fieldWrap(f.label || null, wrap, f.req);
        }
        case 'conds': return buildConds(n, f);
        case 'selector': return buildSelector(n, f);
        case 'selradio': return buildSelRadio(n, f);
        case 'varrows': return buildVarRows(n, f);
        default: return null;
      }
    }

    // ---------------------------------------------- bộ dựng điều kiện (`conds`)
    // Giao diện kiểu AdsPower/MKTLogin: mỗi dòng là "Giá trị - Toán tử - Giá trị so
    // sánh", các dòng nối nhau bằng VÀ / HOẶC. Lưu ở dạng
    //   { logic: 'AND'|'OR', conditions: [{ left, op, right }] }
    // - CHÍNH LÀ dạng executor.evalCondList() đọc, nên không phải chuyển đổi khi chạy.
    // Chuẩn hoá mọi kiểu dữ liệu cũ về dạng object trên. Biểu thức tự do kiểu
    // "{x} > 5" không tách được thành dòng nên giữ nguyên ở `expr`; executor vẫn
    // chạy `expr` khi danh sách dòng rỗng, và giao diện hiện nó ra để người dùng biết.
    function normalizeConds(raw) {
      let v = raw;
      if (typeof v === 'string') {
        const s = v.trim();
        let p = null;
        if (s.startsWith('[') || s.startsWith('{')) { try { p = JSON.parse(s); } catch { p = null; } }
        if (p && typeof p === 'object') v = p;
        else v = { logic: 'AND', conditions: [], expr: s || undefined };
      }
      if (!v || typeof v !== 'object') v = { logic: 'AND', conditions: [] };
      if (Array.isArray(v)) v = { logic: 'AND', conditions: v };
      const rows = Array.isArray(v.conditions) ? v.conditions : [];
      v.conditions = rows.map((c) => (c && typeof c === 'object' ? {
        left: c.left != null ? c.left : (c.variable != null ? c.variable : ''),
        op: c.op || c.operator || 'Bằng',
        right: c.right != null ? c.right : (c.value != null ? c.value : ''),
      } : newCond()));
      v.logic = /or/i.test(String(v.logic || '')) ? 'OR' : 'AND';
      if (!v.conditions.length && !v.expr) v.conditions.push(newCond());
      return v;
    }
    // Tóm tắt điều kiện cho thẻ node + kiểm tra "thiếu cấu hình".
    function condsSummary(v) {
      if (typeof v === 'string') return v.trim();
      if (!v || typeof v !== 'object') return '';
      const rows = Array.isArray(v.conditions) ? v.conditions : [];
      const parts = rows
        .filter((c) => c && (String(c.left || '').trim() || String(c.right || '').trim()))
        .map((c) => `${c.left || ''} ${COND_OP_SYMBOLS[c.op] || c.op || ''} ${UNARY_OPS.has(c.op) ? '' : (c.right || '')}`.replace(/\s+/g, ' ').trim());
      if (parts.length) return parts.join(/or/i.test(String(v.logic || '')) ? ' HOẶC ' : ' VÀ ');
      return v.expr ? String(v.expr).trim() : '';
    }
    // Drawer cấu hình node rất hẹp, nhồi [giá trị][toán tử][so sánh][xoá] vào một
    // hàng thì ô nào cũng bé tí và dính nhau. Nên mỗi điều kiện là MỘT THẺ riêng,
    // bên trong các ô xếp DỌC và có nhãn - đọc là hiểu ngay đang so sánh cái gì.
    // Giữa hai thẻ là dải phân cách VÀ / HOẶC.
    function buildConds(n, f) {
      const v = normalizeConds(n.params[f.k]);
      n.params[f.k] = v;
      const save = () => commit(n, f.k, v);
      const wrap = el('div.rpa-conds');
      const head = el('div.rpa-cond-head');
      const rowsBox = el('div.rpa-cond-rows');

      // Ô nhập có nhãn riêng, xếp dọc trong thẻ điều kiện. Nhãn nhận cả chuỗi lẫn phần
      // tử sẵn có (ô "Danh sách so sánh" cần giữ ref để đổi chữ theo toán tử).
      const sub = (label, ...children) => el('div.rpa-cond-sub', {}, [
        typeof label === 'string' ? el('span.rpa-cond-sublbl', { text: label }) : label,
        ...children,
      ]);

      // Chỉ một điều kiện thì VÀ/HOẶC vô nghĩa → giấu cả khối chọn đi cho gọn.
      function renderHead() {
        clear(head);
        head.style.display = v.conditions.length > 1 ? '' : 'none';
        if (v.conditions.length < 2) return;
        const seg = el('div.pc-seg.rpa-seg.rpa-cond-logic');
        [['AND', 'Tất cả'], ['OR', 'Bất kỳ']].forEach(([val, lbl]) => {
          seg.appendChild(el('button.seg-opt' + (v.logic === val ? '.active' : ''), {
            type: 'button', text: lbl,
            onclick: () => { v.logic = val; save(); renderAll(); },
          }));
        });
        head.appendChild(el('div.rpa-cond-headline', {}, [el('span.rpa-cond-lbl', { text: 'Khớp khi' }), seg]));
        head.appendChild(el('div.rpa-hint', { text: v.logic === 'OR' ? 'Chỉ cần MỘT điều kiện đúng là qua.' : 'MỌI điều kiện đều phải đúng mới qua.' }));
      }

      function renderRows() {
        clear(rowsBox);
        v.conditions.forEach((r, i) => {
          if (i) rowsBox.appendChild(el('div.rpa-cond-join', {}, [el('span', { text: v.logic === 'OR' ? 'HOẶC' : 'VÀ' })]));
          const left = el('input.input', { value: r.left != null ? r.left : '', placeholder: 'Ví dụ ${ten_bien} hoặc chuỗi cố định' });
          // Bẫy hay gặp: gõ TRẦN tên biến (abc) - lúc chạy nó là chuỗi "abc" chứ không
          // phải giá trị của biến, nên điều kiện đúng vẫn ra sai. Nhắc ngay tại chỗ.
          const leftWarn = el('div.rpa-hint.rpa-cond-warn', { text: 'Đây đang là chuỗi cố định. Muốn lấy giá trị của biến thì bấm nút chèn biến (thành ${…}).' });
          const syncLeft = () => {
            const s = String(r.left || '').trim();
            leftWarn.style.display = (s && !/[{}]/.test(s) && /^[A-Za-z_$][\w$]*$/.test(s)) ? '' : 'none';
          };
          left.addEventListener('input', () => { r.left = left.value; save(); syncLeft(); });
          const right = el('input.input', { value: r.right != null ? r.right : '' });
          right.addEventListener('input', () => { r.right = right.value; save(); });
          const rightLbl = el('span.rpa-cond-sublbl');
          const rightField = sub(rightLbl, affixInput(right, [varBtn(right)]));
          // Toán tử một ngôi (Tồn tại / Không tồn tại) không có vế phải → ẩn ô đi.
          // Còn "Nằm trong" thì vế phải là DANH SÁCH chứ không phải một giá trị - đổi
          // hẳn nhãn cho thấy, vì đây là điểm khác duy nhất so với "Bao gồm".
          const syncRight = () => {
            rightField.style.display = UNARY_OPS.has(r.op) ? 'none' : '';
            const isList = LIST_OPS.has(r.op);
            rightLbl.textContent = isList ? 'Danh sách so sánh' : 'Giá trị so sánh';
            right.placeholder = isList ? 'Nhiều giá trị, cách nhau bằng dấu phẩy. VD: vn, us, jp' : 'Giá trị so sánh';
          };
          // "Bao gồm" và "Nằm trong" NGƯỢC CHIỀU nhau (vế nào chứa vế nào) nên rất dễ
          // chọn nhầm rồi tưởng engine sai. Giải nghĩa ngay dưới ô chọn.
          const opHint = el('div.rpa-hint');
          const syncOpHint = () => { opHint.textContent = COND_OP_HINTS[r.op || 'Bằng'] || ''; };
          const op = customSelect(COND_OPS, {
            value: r.op || 'Bằng', width: '100%',
            onChange: (x) => { r.op = x; save(); syncRight(); syncOpHint(); },
          });
          syncRight(); syncLeft(); syncOpHint();
          const del = v.conditions.length > 1
            ? iconBtn('close', { title: 'Xóa điều kiện', onclick: () => { v.conditions.splice(i, 1); save(); renderAll(); } })
            : null;
          rowsBox.appendChild(el('div.rpa-cond-card', {}, [
            el('div.rpa-cond-cardhead', {}, [el('span.rpa-cond-no', { text: `Điều kiện ${i + 1}` }), del]),
            sub('Giá trị', affixInput(left, [varBtn(left)]), leftWarn),
            sub('Toán tử', op, opHint),
            rightField,
          ]));
        });
      }
      function renderAll() { renderHead(); renderRows(); }
      renderAll();

      wrap.appendChild(head);
      // Điều kiện cũ viết tay (biểu thức) - vẫn chạy được, nhưng không sửa bằng thẻ
      // được nên hiện ra kèm nút bỏ để người dùng chuyển sang dạng thẻ.
      if (v.expr) {
        wrap.appendChild(el('div.rpa-cond-expr', {}, [
          el('code', { text: v.expr }),
          el('button.btn.subtle.sm', { type: 'button', text: 'Bỏ biểu thức', onclick: () => { delete v.expr; if (!v.conditions.length) v.conditions.push(newCond()); save(); if (rerenderFields) rerenderFields(); } }),
        ]));
      }
      wrap.appendChild(rowsBox);
      wrap.appendChild(el('button.btn.subtle.sm.rpa-cond-add', {
        type: 'button', html: `${icon('plus')}<span>Thêm điều kiện</span>`,
        onclick: () => { v.conditions.push(newCond()); save(); renderAll(); },
      }));
      const out = fieldWrap(f.label || null, wrap, f.req);
      if (f.hint) out.appendChild(el('div.rpa-hint', { text: f.hint }));
      return out;
    }

    // Full "Bộ chọn / Element được lưu trữ" selector pattern.
    function buildSelector(n, f) {
      const v = n.params[f.k] || fieldDefault(f); n.params[f.k] = v;
      const body = el('div.rpa-selbody');
      function rebuild() {
        clear(body);
        const selSeg = el('div.pc-seg.rpa-seg.rpa-seg-tabs');
        [['sel', 'Bộ chọn'], ['stored', 'Phần tử đã lưu']].forEach(([key, label]) => {
          selSeg.appendChild(el('button.seg-opt' + (v.tab === key ? '.active' : ''), { type: 'button', text: label, onclick: () => { v.tab = key; commit(n, f.k, v); rebuild(); } }));
        });
        body.appendChild(selSeg);
        if (v.tab === 'stored') {
          body.appendChild(el('div.rpa-field', {}, [
            el('label', {}, [el('span', { text: 'Phần tử' })]),
            customSelect([], { placeholder: 'Chọn', width: '100%', onChange: (x) => { v.stored = x; commit(n, f.k, v); } }),
          ]));
          return;
        }
        const grp = el('div.pc-radios'); const name = f.k + '_mode_' + n.id;
        ['Selector', 'XPath', 'Text'].forEach((o) => {
          const r = el('input', { type: 'radio', name, value: o }); if (v.mode === o) r.checked = true;
          r.addEventListener('change', () => { if (r.checked) { v.mode = o; commit(n, f.k, v); } });
          grp.appendChild(el('label.pc-radio', {}, [r, el('span', { text: o })]));
        });
        body.appendChild(grp);
        const inp = el('input.input', { value: v.value || '', placeholder: 'Hãy nhập bộ chọn phần tử, ví dụ #...' });
        inp.addEventListener('input', () => { v.value = inp.value; commit(n, f.k, v); });
        body.appendChild(affixInput(inp, [varBtn(inp)]));
        const orderNo = el('input.input', { type: 'number', value: v.orderNo != null ? v.orderNo : 1, style: { width: '120px' } });
        orderNo.addEventListener('input', () => { v.orderNo = orderNo.value; commit(n, f.k, v); });
        if (f.noOrder) {
          // type_text / upload_file: no Cố định/Ngẫu nhiên dropdown - just number + var-insert.
          body.appendChild(el('div.rpa-field', {}, [el('label', {}, [el('span', { text: 'Thứ tự phần tử' })]), affixInput(orderNo, [varBtn(orderNo)])]));
        } else {
          const orderSel = customSelect(['Cố định', 'Ngẫu nhiên'], { value: v.order || 'Cố định', width: 140, onChange: (x) => { v.order = x; commit(n, f.k, v); } });
          body.appendChild(el('div.rpa-field', {}, [el('label', {}, [el('span', { text: 'Thứ tự phần tử' })]), el('div.rpa-inline', {}, [orderSel, affixInput(orderNo, [varBtn(orderNo)])])]));
        }
      }
      rebuild();
      return fieldWrap(f.label || null, body, f.req);
    }

    // Compact selector (radio + input + order) used by wait/loop nodes.
    function buildSelRadio(n, f) {
      const v = n.params[f.k] || fieldDefault(f); n.params[f.k] = v;
      const grp = el('div.pc-radios'); const name = f.k + '_m_' + n.id;
      ['Selector', 'XPath', 'Text'].forEach((o) => {
        const r = el('input', { type: 'radio', name, value: o }); if (v.mode === o) r.checked = true;
        r.addEventListener('change', () => { if (r.checked) { v.mode = o; commit(n, f.k, v); } });
        grp.appendChild(el('label.pc-radio', {}, [r, el('span', { text: o })]));
      });
      const inp = el('input.input', { value: v.value || '', placeholder: 'Hãy nhập bộ chọn phần tử, ví dụ #...' });
      inp.addEventListener('input', () => { v.value = inp.value; commit(n, f.k, v); });
      const orderNo = el('input.input', { type: 'number', value: v.order != null ? v.order : 1, style: { width: '120px' } });
      orderNo.addEventListener('input', () => { v.order = orderNo.value; commit(n, f.k, v); });
      return el('div.rpa-field', {}, [
        f.label ? el('label', {}, [el('span.rpa-lbl', {}, [f.req ? el('span.req', { text: '*' }) : null, el('span', { text: f.label })])]) : null,
        grp,
        affixInput(inp, [varBtn(inp)]),
        el('div.rpa-field', {}, [el('label', {}, [el('span', { text: 'Thứ tự phần tử' })]), affixInput(orderNo, [varBtn(orderNo)])]),
      ]);
    }

    // Repeatable variable rows (node-local).
    function buildVarRows(n, f) {
      if (!Array.isArray(n.params[f.k]) || !n.params[f.k].length) n.params[f.k] = [{ name: '', type: 'String', value: '' }];
      const wrap = el('div.rpa-varrows');
      function rebuild() {
        clear(wrap);
        n.params[f.k].forEach((row, i) => {
          const name = el('input.input', { value: row.name, placeholder: 'Tên biến' });
          name.addEventListener('input', () => { row.name = name.value; });
          const type = customSelect(VAR_TYPES, { value: row.type || 'String', width: 116, onChange: (x) => { row.type = x; } });
          const val = el('input.input', { value: row.value, placeholder: 'Giá trị mặc định' });
          val.addEventListener('input', () => { row.value = val.value; });
          const del = iconBtn('close', { title: 'Xóa', onclick: () => { n.params[f.k].splice(i, 1); if (!n.params[f.k].length) n.params[f.k].push({ name: '', type: 'String', value: '' }); rebuild(); } });
          wrap.appendChild(el('div.rpa-varrow', {}, [name, type, val, del]));
        });
        wrap.appendChild(el('button.btn.subtle.sm', { type: 'button', html: `${icon('plus')}<span>Thêm biến</span>`, onclick: () => { n.params[f.k].push({ name: '', type: 'String', value: '' }); rebuild(); } }));
      }
      rebuild();
      return fieldWrap(f.label || null, wrap, f.req);
    }

    // ============================================== VARIABLES (start node)
    function openVariablesDrawer() {
      rerenderFields = null;
      clear(drawerHead); clear(drawerBody);
      drawerBody.classList.add('has-pinbar');   // nút "Thêm biến" ghim đáy, không cuộn theo danh sách
      drawerHead.appendChild(el('div.rpa-dh-ico', { style: { background: iconBg(COL_START), color: '#fff' }, html: icon('tune') }));
      drawerHead.appendChild(el('div.rpa-dh-title', { text: 'Biến quy trình' }));
      drawerHead.appendChild(el('div.rpa-dh-tools', {}, [iconBtn('close', { title: 'Đóng', onclick: () => drawer.classList.remove('open') })]));
      drawerBody.appendChild(el('div.rpa-dsub.rpa-varnote', { text: 'Biến khai báo ở đây là THAM SỐ ĐẦU VÀO: người chạy quy trình phải điền giá trị trước khi chạy.' }));
      const list = el('div.rpa-vars');
      // AdsPower always shows at least one editable variable row when the drawer
      // opens (an empty template), so the user never faces a bare "Thêm biến"
      // button. Empty-named rows are ignored everywhere (collectProcessVars / save).
      // Chỉ tính các biến ĐẦU VÀO - biến thường (local) không thay được ô trống này.
      if (!variables.some((v) => v && !v.local)) variables.push({ name: '', type: 'String', value: '', desc: '' });
      // AdsPower renders the "Giá trị mặc định" editor differently per type:
      //   Number → numeric input · Boolean → toggle switch (False/True) ·
      //   Text/Array/Object → multi-line textarea (Array/Object carry a JSON hint) ·
      //   File/Folder → path input + a browse button opening the OS file/folder
      //   dialog (vt.dialog.openFile) · String (default) → plain text input.
      function varValueEditor(row) {
        const t = row.type || 'String';
        if (t === 'Boolean') {
          const on = row.value === true || row.value === 'true' || row.value === 1 || row.value === '1';
          const lbl = el('span.rpa-bool-lbl', { text: on ? 'True' : 'False' });
          const sw = el('button.switch' + (on ? '.on' : ''), { type: 'button' }, [el('span.knob')]);
          sw.addEventListener('click', () => { const v = !sw.classList.contains('on'); sw.classList.toggle('on', v); lbl.textContent = v ? 'True' : 'False'; row.value = v; scheduleSnapshot(); });
          return el('div.rpa-inline', {}, [sw, lbl]);
        }
        if (t === 'Number') {
          const inp = el('input.input', { type: 'number', value: row.value, placeholder: 'Giá trị mặc định' });
          inp.addEventListener('input', () => { row.value = inp.value; scheduleSnapshot(); });
          return inp;
        }
        if (t === 'Text' || t === 'Array' || t === 'Object') {
          const ph = t === 'Array' ? '["item1", "item2", "item3"]' : t === 'Object' ? '{"key1": "value1", "key2": "value2"}' : 'Giá trị mặc định';
          const ta = el('textarea.input', { rows: 3, placeholder: ph });
          ta.value = row.value != null ? row.value : '';
          ta.addEventListener('input', () => { row.value = ta.value; scheduleSnapshot(); });
          return ta;
        }
        if (t === 'File' || t === 'Folder') {
          // Nút chọn tệp/thư mục thuộc về ô ĐẦU VÀO (tab "Xem trước" & lúc chạy) - nơi
          // người chạy tải tệp lên. Ở "Tạo biến" chỉ khai đường dẫn mặc định (tuỳ chọn).
          const inp = el('input.input', { value: row.value, placeholder: t === 'Folder' ? 'Đường dẫn thư mục mặc định' : 'Đường dẫn tệp mặc định' });
          inp.addEventListener('input', () => { row.value = inp.value; scheduleSnapshot(); });
          return inp;
        }
        const inp = el('input.input', { value: row.value, placeholder: 'Giá trị mặc định' });
        inp.addEventListener('input', () => { row.value = inp.value; scheduleSnapshot(); });
        return inp;
      }
      // Một thẻ biến. Xóa phải dò lại vị trí thật bằng indexOf vì danh sách render
      // đã được lọc (chỉ còn tham số đầu vào), index của mảng lọc KHÁC index thật.
      function varCard(row, canDelete) {
        if (row._open === undefined) row._open = true;   // cards open by default (AdsPower)
        const name = el('input.input', { value: row.name, placeholder: 'Tên biến' });
        name.addEventListener('input', () => { row.name = name.value; scheduleSnapshot(); });
        // Switching type re-renders the card so the "Giá trị mặc định" editor
        // swaps to the control AdsPower uses for that type (see varValueEditor).
        const type = customSelect(VAR_TYPES, { value: row.type || 'String', width: 130, onChange: (x) => { row.type = x; rebuild(); snapshot(); } });
        // Tên cấu hình: chuỗi hiển thị cho người chạy, được phép có dấu & khoảng trắng.
        // Tên biến (row.name) mới là mã định danh dùng trong quy trình - phải sạch.
        const label = el('input.input', { value: row.label != null ? row.label : '', placeholder: 'Nhập tên cấu hình' });
        label.addEventListener('input', () => { row.label = label.value; scheduleSnapshot(); });
        const desc = el('input.input', { value: row.desc, placeholder: 'Hãy nhập mô tả tóm tắt' });
        desc.addEventListener('input', () => { row.desc = desc.value; scheduleSnapshot(); });
        // Per-card actions mirror AdsPower: an expand/collapse toggle (⤢/⤡) and a
        // trash delete.
        const toggle = iconBtn(row._open ? 'arrowsContract' : 'arrowsExpand', { title: row._open ? 'Thu gọn' : 'Mở rộng', onclick: () => { row._open = !row._open; rebuild(); } });
        const acts = [toggle];
        if (canDelete) acts.push(iconBtn('trash', { title: 'Xóa biến', onclick: () => { const at = variables.indexOf(row); if (at >= 0) variables.splice(at, 1); rebuild(); snapshot(); } }));
        const card = [el('div.rpa-varrow', {}, [name, type, el('div.rpa-varacts', {}, acts)])];
        if (row._open) {
          card.push(el('div.rpa-field', {}, [el('label', {}, [el('span', { text: 'Tên cấu hình' })]), label]));
          card.push(el('div.rpa-field', {}, [el('label', {}, [el('span', { text: 'Giá trị mặc định' })]), varValueEditor(row)]));
          card.push(el('div.rpa-field', {}, [el('label', {}, [el('span', { text: 'Mô tả' })]), desc]));
        }
        return el('div.rpa-varcard', {}, card);
      }
      // Drawer này CHỈ quản lý THAM SỐ ĐẦU VÀO (biến tạo bằng nút "Thêm biến" bên dưới).
      // Biến thường (local: true - tạo nhanh trong modal cấu hình node) KHÔNG hiện ở đây:
      // chúng thuộc về node, chỉ dùng nội bộ để gán/tính toán. Vẫn nằm trong `variables`
      // để lưu và chạy, và vẫn xuất hiện trong mọi ô chọn biến (collectProcessVars).
      function rebuild() {
        clear(list);
        const inputs = variables.filter((v) => v && !v.local);
        inputs.forEach((row) => list.appendChild(varCard(row, inputs.length > 1)));
      }
      rebuild();

      // Panel "Tạo biến" (danh sách thẻ biến) + thanh "Thêm biến" ghim đáy.
      const createPanel = el('div.rpa-varpanel', {}, [list]);
      const addBar = el('div.rpa-addvar-bar', {}, [
        el('button.btn.rpa-addvar', { type: 'button', html: `${icon('plusCircle')}<span>Thêm biến</span>`, onclick: () => { variables.push({ name: '', type: 'String', value: '', desc: '' }); rebuild(); snapshot(); } }),
      ]);

      // Panel "Xem trước": mô phỏng ĐÚNG ô đầu vào mà người chạy quy trình sẽ thấy
      // (giống tab "Đầu vào" của modal chạy). Dùng lại .rpp-invar bằng cách bọc trong
      // .rpp-modal để thừa hưởng nguyên style. Sửa ở đây = sửa giá trị mặc định.
      const previewPanel = el('div.rpa-varpanel', { style: { display: 'none' } });
      function previewField(row) {
        const t = row.type || 'String';
        const box = (inner, multi) => el('div.rpp-invar' + (multi ? '.is-multi' : ''), {}, [el('label.rpp-invar-label', { text: row.label || row.name }), inner]);
        if (t === 'Boolean') {
          const on = row.value === true || row.value === 'true' || row.value === 1 || row.value === '1';
          row.value = on;
          const sw = el('button.switch' + (on ? '.on' : ''), { type: 'button' }, [el('span.knob')]);
          sw.addEventListener('click', () => { const next = !sw.classList.contains('on'); sw.classList.toggle('on', next); row.value = next; scheduleSnapshot(); });
          return box(el('div.rpp-invar-line', {}, [sw]));
        }
        if (t === 'Number') {
          const inp = el('input.rpp-invar-input', { type: 'number', value: row.value != null ? row.value : '', placeholder: row.desc || '' });
          inp.addEventListener('input', () => { row.value = inp.value; scheduleSnapshot(); });
          return box(el('div.rpp-invar-line', {}, [inp]));
        }
        if (t === 'Array' || t === 'Object' || t === 'Text') {
          const ta = el('textarea.rpp-invar-input.rpp-invar-area', { rows: '3', placeholder: row.desc || '' });
          const cur = row.value; ta.value = (typeof cur === 'object' && cur != null) ? JSON.stringify(cur, null, 2) : String(cur == null ? '' : cur);
          ta.addEventListener('input', () => { row.value = ta.value; scheduleSnapshot(); });
          return box(ta, true);
        }
        if (t === 'Folder') {
          // Đây là ô ĐẦU VÀO: người chạy quy trình bấm nút để chọn thư mục.
          const inp = el('input.rpp-invar-input', { value: row.value != null ? row.value : '', placeholder: row.desc || 'Chọn thư mục hoặc nhập đường dẫn' });
          inp.addEventListener('input', () => { row.value = inp.value; scheduleSnapshot(); });
          const browse = iconBtn('folder', { title: 'Chọn thư mục', onclick: async () => {
            try { const p = await window.vt?.dialog?.openFile({ directory: true }); if (p) { inp.value = p; row.value = p; scheduleSnapshot(); } } catch { /* huỷ */ }
          } });
          return box(el('div.rpp-invar-line.rpp-invar-file', {}, [inp, browse]));
        }
        if (t === 'File') {
          // Ô ĐẦU VÀO tệp: chọn được NHIỀU tệp (textarea, mỗi dòng 1 tệp) + nút duyệt gom thêm.
          const ta = el('textarea.rpp-invar-input.rpp-invar-area', { rows: '3', placeholder: row.desc || 'Chọn tệp (chọn được nhiều) hoặc nhập đường dẫn, mỗi dòng 1 tệp' });
          ta.value = row.value != null ? String(row.value) : '';
          ta.addEventListener('input', () => { row.value = ta.value; scheduleSnapshot(); });
          const addPaths = (picked) => {
            const arr = Array.isArray(picked) ? picked : [picked];
            const list = ta.value.split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
            for (const p of arr) { if (p && !list.includes(p)) list.push(p); }
            ta.value = list.join('\n'); row.value = ta.value; scheduleSnapshot();
          };
          const browse = iconBtn('folder', { title: 'Chọn tệp (chọn được nhiều)', onclick: async () => {
            try { const p = await window.vt?.dialog?.openFile({ multi: true }); if (p) addPaths(p); } catch { /* huỷ */ }
          } });
          return box(el('div.rpp-invar-line.rpp-invar-file', {}, [ta, browse]), true);
        }
        const inp = el('input.rpp-invar-input', { value: row.value != null ? row.value : '', placeholder: row.desc || '' });
        inp.addEventListener('input', () => { row.value = inp.value; scheduleSnapshot(); });
        return box(el('div.rpp-invar-line', {}, [inp]));
      }
      function renderPreview() {
        clear(previewPanel);
        const box = el('div.rpp-modal.rpa-varpreview');
        const inputs = variables.filter((v) => v && v.name && !v.local);
        if (!inputs.length) box.appendChild(el('div.rpp-input-empty', { text: 'Chưa tạo biến đầu vào.' }));
        else inputs.forEach((row) => box.appendChild(previewField(row)));
        previewPanel.appendChild(box);
      }

      // Segment 2 tab: Tạo biến | Xem trước.
      const seg = el('div.pc-seg.rpa-seg.rpa-varseg');
      const segBtns = {};
      const showVTab = (k) => {
        Object.keys(segBtns).forEach((key) => segBtns[key].classList.toggle('active', key === k));
        const isCreate = k === 'create';
        createPanel.style.display = isCreate ? '' : 'none';
        addBar.style.display = isCreate ? '' : 'none';
        previewPanel.style.display = isCreate ? 'none' : '';
        if (!isCreate) renderPreview();
      };
      [['create', 'Tạo biến', null], ['preview', 'Xem trước', 'eyePreview']].forEach(([k, label, ic]) => {
        const b = el('button.seg-opt' + (k === 'create' ? '.active' : ''), { type: 'button', html: `${ic ? icon(ic) : ''}<span>${label}</span>`, onclick: () => showVTab(k) });
        segBtns[k] = b; seg.appendChild(b);
      });

      drawerBody.appendChild(seg);
      drawerBody.appendChild(createPanel);
      drawerBody.appendChild(previewPanel);
      // Thanh ghim đáy (.rpa-addvar-bar) - nút đứng yên, chỉ danh sách biến cuộn.
      drawerBody.appendChild(addBar);
      drawer.classList.remove('plain');
      drawer.classList.add('open');
    }

    // ============================================== SETTINGS MODAL "Cài đặt"
    function openSettings() {
      const swRow = (label, key, desc) => {
        const sw = el('button.switch' + (settings[key] ? '.on' : ''), { type: 'button' }, [el('span.knob')]);
        sw.addEventListener('click', () => { settings[key] = !settings[key]; sw.classList.toggle('on', settings[key]); });
        return el('div.rpa-set-row.top', {}, [el('div.rpa-set-label', { text: label }), el('div.rpa-set-ctl', {}, [sw, desc ? el('div.rpa-set-desc', { text: desc }) : null])]);
      };
      const segRow = (label, key, options) => {
        const seg = el('div.pc-seg.rpa-seg');
        options.forEach((o) => seg.appendChild(el('button.seg-opt' + (settings[key] === o ? '.active' : ''), { type: 'button', text: o, onclick: () => { settings[key] = o; seg.querySelectorAll('.seg-opt').forEach((x) => x.classList.toggle('active', x.textContent === o)); } })));
        return el('div.rpa-set-row', {}, [el('div.rpa-set-label', { text: label }), el('div.rpa-set-ctl', {}, [seg])]);
      };
      const tInput = el('input.input', { type: 'number', value: settings.timeoutSec, style: { width: '120px' } });
      const dInput = el('input.input', { type: 'number', value: settings.delayMin, style: { width: '120px' } });
      const errGrp = el('div.pc-radios', { style: { flexDirection: 'column', gap: '8px' } });
      [['Gián đoạn', 'Khi xảy ra lỗi, dừng quy trình'], ['Bỏ qua', 'Khi xảy ra lỗi, tiếp tục thực thi']].forEach(([o, d]) => {
        const r = el('input', { type: 'radio', name: 'set_err', value: o }); if (settings.onError === o) r.checked = true;
        r.addEventListener('change', () => { if (r.checked) settings.onError = o; });
        errGrp.appendChild(el('label.pc-radio', {}, [r, el('span', {}, [el('b', { text: o }), el('span.rpa-set-desc', { text: '  ' + d })])]));
      });
      const onCompleteBrowser = customSelect(['Đóng trình duyệt', 'Giữ trình duyệt'], { value: settings.onCompleteBrowser, width: 190, onChange: (v) => { settings.onCompleteBrowser = v; } });

      // CHỈ giữ những mục thực sự có tác dụng khi CHẠY quy trình. Các tùy chọn cấp
      // TRÌNH DUYỆT (headless / tham số khởi động / tự điền / lưu mật khẩu / xóa cache)
      // đã bỏ khỏi đây: quy trình chạy bằng cách BÁM CDP vào trình duyệt hồ sơ đang mở,
      // nên cờ khởi động không áp được — chúng thuộc phần cấu hình HỒ SƠ, không phải quy
      // trình. Giữ lại chỉ tạo nút "chết" gây hiểu nhầm.
      openModal({
        title: 'Cài đặt', width: 640,
        body: [
          el('div.rpa-set-title', { text: 'Tùy chọn' }),
          segRow('Bố cục', 'layout', ['Ngang', 'Dọc']),
          swRow('Tự động kết nối', 'autoConnect', 'Tự động ghép kết nối khi thêm nút'),
          el('div.rpa-set-title', { text: 'Cài đặt quy trình' }),
          el('div.rpa-set-row.top', {}, [el('div.rpa-set-label', { text: 'Bất thường' }), el('div.rpa-set-ctl', {}, [errGrp, el('div.rpa-set-note', { text: 'Thiết lập phương thức xử lý lỗi mặc định cho toàn bộ quy trình. Nếu một bước thao tác có thiết lập riêng, thì sẽ không bị ảnh hưởng bởi thiết lập này.' })])]),
          el('div.rpa-set-row', {}, [el('div.rpa-set-label', { text: 'Hoàn thành nhiệm vụ' }), el('div.rpa-set-ctl', {}, [el('div.rpa-inline', {}, [onCompleteBrowser])])]),
          el('div.rpa-set-row', {}, [el('div.rpa-set-label', {}, [el('span', { text: 'Hết giờ' }), el('span.rpa-help', { html: icon('about'), title: 'Thời gian chờ tối đa cho mỗi bước chờ phần tử. Quá thời gian này, bước sẽ bị coi là lỗi. 0 = mặc định 30 giây.' })]), el('div.rpa-set-ctl', {}, [el('div.rpa-inline', {}, [tInput, el('span.rpa-unit', { text: 'Giây' })])])]),
          el('div.rpa-set-row', {}, [el('div.rpa-set-label', { text: 'Trì hoãn thực hiện' }), el('div.rpa-set-ctl', {}, [el('div.rpa-inline', {}, [dInput, el('span.rpa-unit', { text: 'phút' })])])]),
        ],
        footer: [
          el('button.btn', { text: 'Hủy', onclick: closeModal }),
          el('button.btn.primary', { text: 'OK', onclick: () => { settings.timeoutSec = tInput.value; settings.delayMin = dInput.value; closeModal(); renderNodes(); snapshot(); } }),
        ],
      });
    }

    // ============================================== MINIMAP
    const miniDots = el('div.rpa-mini-dots');
    const miniView = el('div.rpa-mini-view');
    const miniScreen = el('div.rpa-mini-screen', {}, [miniDots, miniView]);
    const mini = el('div.rpa-mini', {}, [miniScreen]);
    const MINI_RATIO = 0.18;  // minimap zoom = canvas zoom × this, so zooming the canvas zooms the minimap the same way
    function renderMini() {
      if (!nodes.length) return;
      const mw = miniScreen.clientWidth || 170, mh = miniScreen.clientHeight || 106;
      // The minimap is a scaled copy of the canvas (k follows the live canvas zoom),
      // centered on whatever world point sits at the centre of the canvas viewport.
      const k = scale * MINI_RATIO;
      const wcx = (viewport.clientWidth / 2 - tx) / scale;
      const wcy = (viewport.clientHeight / 2 - ty) / scale;
      clear(miniDots);
      nodes.forEach((n) => {
        const b = box(n);
        const def = find(n.type);
        // Color rule (AdsPower-style): a node with a required field left empty → red; otherwise → blue.
        const color = (n.type !== 'start' && requiredMissing(n, def)) ? '#EF4444' : 'var(--brand)';
        miniDots.appendChild(el('div.rpa-mini-node', { style: { left: (n.x - wcx) * k + mw / 2 + 'px', top: (n.y - wcy) * k + mh / 2 + 'px', width: Math.max(3, b.w * k) + 'px', height: Math.max(2, b.h * k) + 'px', background: color } }));
      });
      const vw = (viewport.clientWidth / scale) * k, vh = (viewport.clientHeight / scale) * k;
      miniView.style.left = (mw - vw) / 2 + 'px';
      miniView.style.top = (mh - vh) / 2 + 'px';
      miniView.style.width = vw + 'px';
      miniView.style.height = vh + 'px';
      mini._k = k; mini._wcx = wcx; mini._wcy = wcy; mini._mw = mw; mini._mh = mh;
    }
    let miniDrag = null;
    mini.addEventListener('mousedown', (e) => { miniDrag = true; moveMini(e); e.stopPropagation(); });
    function moveMini(e) {
      if (!miniDrag || !mini._k) return;
      const r = miniScreen.getBoundingClientRect();
      const wx = mini._wcx + (e.clientX - r.left - mini._mw / 2) / mini._k;
      const wy = mini._wcy + (e.clientY - r.top - mini._mh / 2) / mini._k;
      tx = viewport.clientWidth / 2 - wx * scale; ty = viewport.clientHeight / 2 - wy * scale;
      applyTransform();
    }
    window.addEventListener('mousemove', moveMini); winHandlers.push(['mousemove', moveMini]);
    const stopMini = () => { miniDrag = null; };
    window.addEventListener('mouseup', stopMini); winHandlers.push(['mouseup', stopMini]);

    // ============================================== LIBRARY PANEL
    let libSearch = '';
    const collapsedCats = new Set();
    const libBody = el('div.rpa-lib-body');
    function renderLib() {
      clear(libBody);
      CATEGORIES.forEach(([catKey, catName]) => {
        let items = byCategory(catKey);
        if (libSearch) items = items.filter((n) => n.title.toLowerCase().includes(libSearch.toLowerCase()));
        if (!items.length) return;
        const open = !collapsedCats.has(catKey) || !!libSearch;
        libBody.appendChild(el('button.rpa-cat', { onclick: () => { if (collapsedCats.has(catKey)) collapsedCats.delete(catKey); else collapsedCats.add(catKey); renderLib(); } }, [
          el('span.rpa-cat-ico', { html: icon(CAT_ICON[catKey] || 'tune') }),
          el('span.rpa-cat-name', { text: catName }),
          el('span.rpa-cat-chev', { html: icon('chevron'), style: { transform: open ? 'rotate(90deg)' : 'none' } }),
        ]));
        if (open) {
          const wrap = el('div.rpa-cat-items');
          items.forEach((def) => {
            const nameEl = el('span.rpa-noderow-name', { text: def.title });
            // Leading function icon (matches MKTLogin's node panel - each node shows
            // its own glyph). Colour inherits the row text colour (uniform, not tinted).
            const icoEl = el('span.rpa-noderow-ico', { html: icon(def.icon) || initial(def.title) });
            const row = el('div.rpa-noderow', {}, [
              icoEl,
              nameEl,
              el('button.rpa-add', { html: icon('plusCircle'), title: 'Thêm', onclick: (e) => { e.stopPropagation(); addNode(def); } }),
            ]);
            // Full-name tooltip ONLY when the label is actually truncated ("…").
            // Measured live on hover so it's correct regardless of the panel's
            // open animation / width / resize (a one-shot render-time measure was
            // unreliable while the panel was still animating to its final size).
            nameEl.setAttribute('data-tip', def.title);
            row.addEventListener('mouseenter', () => {
              if (nameEl.scrollWidth > nameEl.clientWidth + 1) nameEl.setAttribute('data-tip', def.title);
              else nameEl.removeAttribute('data-tip');
            });
            row.addEventListener('mousedown', (e) => { if (e.button !== 0 || e.target.closest('.rpa-add')) return; startLibDrag(e, def); });
            wrap.appendChild(row);
          });
          libBody.appendChild(wrap);
        }
      });
      if (!libBody.children.length) libBody.appendChild(el('div.muted', { style: { padding: '12px' }, text: 'Không có kết quả' }));
    }

    // ============================================== HISTORY (undo / redo)
    // Snapshot-based: each entry is a serialized graph string. Structural edits
    // snapshot immediately; field typing is debounced so one edit ≈ one undo.
    let history = [];
    let histIdx = -1;
    let histLock = false;     // true while restoring, so applyGraph won't re-snapshot
    let snapTimer = null;
    let undoBtn = null, redoBtn = null;

    function updateUndoRedo() {
      if (undoBtn) undoBtn.disabled = histIdx <= 0;
      if (redoBtn) redoBtn.disabled = histIdx >= history.length - 1;
    }
    function snapshot() {
      if (histLock) return;
      clearTimeout(snapTimer); snapTimer = null;
      const snap = JSON.stringify(serialize());
      if (history[histIdx] === snap) return;     // no real change
      history = history.slice(0, histIdx + 1);
      history.push(snap);
      if (history.length > 100) history.shift();  // cap memory
      histIdx = history.length - 1;
      updateUndoRedo();
    }
    function scheduleSnapshot() { clearTimeout(snapTimer); snapTimer = setTimeout(snapshot, 500); }
    function undo() {
      if (histIdx <= 0) return;
      clearTimeout(snapTimer); snapTimer = null;
      histIdx--; histLock = true; applyGraph(JSON.parse(history[histIdx])); histLock = false;
      updateUndoRedo();
    }
    function redo() {
      if (histIdx >= history.length - 1) return;
      histIdx++; histLock = true; applyGraph(JSON.parse(history[histIdx])); histLock = false;
      updateUndoRedo();
    }

    // Replace the whole working graph from a serialized object (undo/redo, import).
    function applyGraph(g) {
      nodes = (g.nodes || []).map((n) => ({ ...n, params: n.params || {} }));
      connections = (g.connections || []).map((c) => ({ ...c }));
      variables = (g.variables || []).map((v) => ({ ...v }));
      if (g.settings) Object.assign(settings, g.settings);
      if (!nodes.some((n) => n.type === 'start')) {
        nodes.unshift({ id: 'start', type: 'start', title: 'Bắt đầu quy trình', x: 360, y: 40, params: {} });
      }
      const last = nodes[nodes.length - 1]; chainTail = last ? last.id : 'start';
      selectedId = null; drawer.classList.remove('open');
      renderNodes();
    }

    // ============================================== CANVAS NAVIGATION
    // Center the viewport on a node.
    function centerNode(n) {
      const b = box(n);
      tx = viewport.clientWidth / 2 - (n.x + b.w / 2) * scale;
      ty = viewport.clientHeight / 2 - (n.y + b.h / 2) * scale;
      applyTransform();
    }
    // Zoom + pan so the whole graph fits the viewport.
    function fitScreen() {
      if (!nodes.length) return;
      let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
      nodes.forEach((n) => { const b = box(n); minX = Math.min(minX, n.x); minY = Math.min(minY, n.y); maxX = Math.max(maxX, n.x + b.w); maxY = Math.max(maxY, n.y + b.h); });
      const pad = 60;
      const gw = (maxX - minX) + pad * 2, gh = (maxY - minY) + pad * 2;
      const vw = viewport.clientWidth, vh = viewport.clientHeight;
      scale = Math.min(1.2, Math.max(0.3, Math.min(vw / gw, vh / gh)));
      tx = (vw - gw * scale) / 2 - (minX - pad) * scale;
      ty = (vh - gh * scale) / 2 - (minY - pad) * scale;
      applyTransform();
    }
    // Auto-layout: layer nodes by their distance from the start node along the
    // connection graph (columns when "Ngang", rows when "Dọc"), then fit.
    function tidy() {
      const start = nodes.find((n) => n.type === 'start') || nodes[0];
      if (!start) return;
      const adj = new Map();
      connections.forEach((c) => { if (!adj.has(c.source)) adj.set(c.source, []); adj.get(c.source).push(c.target); });
      const depth = new Map(); depth.set(start.id, 0);
      const queue = [start.id];
      while (queue.length) {
        const id = queue.shift(); const d = depth.get(id);
        (adj.get(id) || []).forEach((t) => { if (!depth.has(t)) { depth.set(t, d + 1); queue.push(t); } });
      }
      let maxD = 0; depth.forEach((d) => { maxD = Math.max(maxD, d); });
      nodes.forEach((n) => { if (!depth.has(n.id)) { maxD += 1; depth.set(n.id, maxD); } });
      const byDepth = new Map();
      nodes.forEach((n) => { const d = depth.get(n.id); if (!byDepth.has(d)) byDepth.set(d, []); byDepth.get(d).push(n); });
      const GAPX = 300, GAPY = 150, baseX = 40, baseY = 40;
      const horizontal = settings.layout !== 'Dọc';
      [...byDepth.keys()].sort((a, b) => a - b).forEach((d) => {
        byDepth.get(d).forEach((n, i) => {
          if (horizontal) { n.x = baseX + d * GAPX; n.y = baseY + i * GAPY; }
          else { n.x = baseX + i * GAPX; n.y = baseY + d * GAPY; }
        });
      });
      renderNodes(); fitScreen(); snapshot();
      toast('Đã sắp xếp node', 'ok');
    }

    // "Gộp nhóm nhanh" - drop a group container onto the canvas; nodes can then be
    // dragged into it (matches AdsPower's quick-group toolbar action).
    function mergeGroupQuick() {
      const def = find('group');
      if (!def) { toast('Không có loại nhóm', 'err'); return; }
      addNode(def);
      toast('Đã thêm nhóm', 'ok');
    }

    // ============================================== CANVAS SEARCH
    const searchInput = el('input.rpa-csearch-input', { placeholder: 'Nhập tên hành động', oninput: () => doCanvasSearch(searchInput.value) });
    const searchBox = el('div.rpa-csearch', {}, [
      searchInput,
    ]);
    let searchOpen = false;
    function toggleSearch(force) {
      searchOpen = force == null ? !searchOpen : !!force;
      searchBox.classList.toggle('open', searchOpen);
      if (searchOpen) { searchInput.focus(); searchInput.select(); }
      else { searchInput.value = ''; doCanvasSearch(''); }
    }
    function doCanvasSearch(q) {
      q = (q || '').trim().toLowerCase();
      let first = null;
      nodes.forEach((n) => {
        const match = !!q && (n.title || '').toLowerCase().includes(q);
        if (n._el) n._el.classList.toggle('found', match);
        if (match && !first) first = n;
      });
      if (first) centerNode(first);
    }

    // ============================================== DEBUG (chọn hồ sơ) PICKER
    // AdsPower's "Gỡ lỗi": pick a profile to run the flow against, step by step.
    // Reached from the toolbar bug icon AND every node's hover "Gỡ lỗi" button.
    async function openDebugPicker() {
      // window.vt.remote.* returns the IPC envelope { ok, data }; window.vt.* (local)
      // returns the raw array. Normalize both so groups/profiles are always arrays -
      // otherwise groups.map(...) below throws and the modal never opens.
      const asList = (r) => Array.isArray(r) ? r : (r && Array.isArray(r.data) ? r.data : []);
      let groups = [];
      try {
        groups = asList(await window.vt?.remote?.groups?.list());
        if (!groups.length) groups = asList(await window.vt?.groups?.list());
      } catch { groups = []; }
      let profiles = [];
      let groupFilter = '';   // '' = all groups; otherwise a group id
      let selectedProfile = null;   // hồ sơ đang chọn trong combobox

      async function loadProfiles() {
        const filter = groupFilter || null;
        try { profiles = asList(await window.vt?.remote?.profiles?.list(filter)); }
        catch { profiles = []; }
        if (!profiles.length) { try { profiles = asList(await window.vt?.profiles?.list(filter)); } catch { /* ignore */ } }
      }

      // Chọn hồ sơ = MỘT combobox có sẵn tìm kiếm (customSelect lọc khi gõ) THAY cho
      // lưới trước đây. customSelect chốt option lúc khởi tạo → đổi nhóm thì dựng lại.
      const comboWrap = el('div', { style: { flex: '1', minWidth: '0' } });
      const runBtn2 = el('button.btn.solid-blue', {
        html: `${icon('playCircle')}<span>Chạy</span>`, disabled: true,
        onclick: () => { if (!selectedProfile) return; lastRunProfile = selectedProfile; closeModal(); runFlowDebug(selectedProfile); },
      });
      function rebuildCombo() {
        clear(comboWrap);
        selectedProfile = null; runBtn2.disabled = true;
        const opts = profiles.map((p) => ({ value: String(p.id), label: p.name || '-' }));
        comboWrap.appendChild(customSelect(opts, {
          placeholder: profiles.length ? 'Chọn hồ sơ để chạy' : 'Không có hồ sơ',
          width: '100%',
          onChange: (v) => { selectedProfile = profiles.find((p) => String(p.id) === v) || null; runBtn2.disabled = !selectedProfile; },
        }));
      }

      const groupWrap = el('div', { style: { flex: '1', minWidth: '0' } });
      const groupOpts = [{ value: '', label: 'Tất cả các nhóm' }].concat(groups.map((g) => ({ value: String(g.id), label: g.name })));
      groupWrap.appendChild(customSelect(groupOpts, { value: '', width: '100%', onChange: async (v) => { groupFilter = v; await loadProfiles(); rebuildCombo(); } }));

      await loadProfiles();
      rebuildCombo();

      const pickRow = (label, control) => el('div', { style: { display: 'flex', alignItems: 'center', gap: '12px' } }, [
        el('span.muted', { text: label, style: { flex: '0 0 44px' } }),
        control,
      ]);

      const dbgModal = openModal({
        title: 'Chạy', width: 520,
        body: [
          el('div', { style: { display: 'flex', flexDirection: 'column', gap: '14px', padding: '4px 0' } }, [
            pickRow('Nhóm', groupWrap),
            pickRow('Hồ sơ', comboWrap),
          ]),
        ],
        footer: [
          el('button.btn', { text: 'Đóng', onclick: closeModal }),
          runBtn2,
        ],
      });
      // Append the "choose profile" label into the title line, but keep its
      // original small/muted size (don't inherit the big h3 title size).
      const dbgH3 = dbgModal?.modal?.querySelector('.modal-head h3');
      if (dbgH3) dbgH3.appendChild(el('span.rpa-dtitle-sub', { text: ' Chọn hồ sơ chạy tự động hóa' }));
    }

    // ============================================== IMPORT / EXPORT / LOG
    function exportFlow() {
      // Chặn xuất quy trình TẢI VỀ từ Chợ (kể cả khi ai đó gọi hàm qua console/phím tắt):
      // xuất ra .json sẽ lộ graph plaintext để bán chợ đen. UI đã ẩn nút, đây là chốt chặn.
      if (flow.source === 'market') { toast('Quy trình tải từ Chợ không được xuất', 'err'); return; }
      try {
        const payload = { name: flow.name, version: flow.version || '1.0', graph: serialize() };
        const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = (flow.name || 'quy-trinh').replace(/[^\w\-]+/g, '_') + '.json';
        document.body.appendChild(a); a.click(); a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
        toast('Đã xuất quy trình', 'ok');
      } catch { toast('Xuất quy trình thất bại', 'err'); }
    }
    // Merge an imported graph either by replacing the canvas or appending (with
    // fresh ids + position offset so nothing collides with the current chain).
    function applyImportedGraph(g, mode) {
      if (!g || !Array.isArray(g.nodes)) { toast('Tệp quy trình không hợp lệ', 'err'); return false; }
      if (mode === 'Thêm vào') {
        const idMap = new Map();
        const incoming = g.nodes.filter((n) => n.type !== 'start');
        incoming.forEach((n) => idMap.set(n.id, newNodeId()));
        incoming.forEach((n) => nodes.push({ ...n, id: idMap.get(n.id), x: (n.x || 0) + 40, y: (n.y || 0) + 40, params: n.params || {} }));
        (g.connections || []).forEach((c) => {
          const s = idMap.get(c.source); const t = idMap.get(c.target);
          if (s && t) connections.push({ source: s, target: t, branch: c.branch || null, color: c.color || COL_WIRE });
        });
        (g.variables || []).forEach((v) => variables.push({ ...v }));
        const last = nodes[nodes.length - 1]; chainTail = last ? last.id : 'start';
        renderNodes();
      } else {
        applyGraph(g);
      }
      snapshot();
      return true;
    }

    // "Nhập quy trình" - AdsPower-style modal: two source tabs (RPA Plus .gz file
    // / RPA pasted JSON) + "Nội dung nhập" mode (Thêm vào / Thay thế).
    function importFlow() {
      let tab = 'plus';            // 'plus' = file (.gz/.json) · 'rpa' = paste JSON
      let mode = 'Thay thế';
      let pickedPath = '';
      let pickedText = '';

      const fileName = el('span.rpa-imp-fname.muted', { text: 'Chưa chọn tệp' });
      const browseBtn = el('button.btn.sm', { type: 'button', text: 'Chọn tệp', onclick: async () => {
        try {
          const p = await window.vt?.dialog?.openFile({ filters: [{ name: 'Quy trình RPA', extensions: ['json'] }] });
          if (!p) return;
          pickedPath = p; pickedText = (await window.vt?.dialog?.readTextFile(p)) || '';
          fileName.textContent = String(p).split(/[\\/]/).pop();
          fileName.classList.remove('muted');
        } catch { toast('Không đọc được tệp', 'err'); }
      } });
      const fileTab = el('div.rpa-imp-pane', {}, [
        el('div.rpa-imp-filerow', {}, [browseBtn, fileName]),
        el('div.rpa-set-desc', { text: 'Chọn tệp quy trình (.json) đã xuất từ chức năng "Xuất quy trình".' }),
      ]);
      const pasteTa = el('textarea.input', { rows: 8, placeholder: 'Dán nội dung JSON của quy trình vào đây…' });
      const rpaTab = el('div.rpa-imp-pane', { style: { display: 'none' } }, [pasteTa]);

      const tabsEl = el('div.pc-seg.rpa-seg', {}, [
        el('button.seg-opt.active', { type: 'button', text: 'Từ tệp', onclick: (e) => { tab = 'plus'; sel(e.target); fileTab.style.display = ''; rpaTab.style.display = 'none'; } }),
        el('button.seg-opt', { type: 'button', text: 'Dán JSON', onclick: (e) => { tab = 'rpa'; sel(e.target); fileTab.style.display = 'none'; rpaTab.style.display = ''; } }),
      ]);
      function sel(btn) { tabsEl.querySelectorAll('.seg-opt').forEach((x) => x.classList.toggle('active', x === btn)); }

      const modeGrp = el('div.pc-radios', {});
      ['Thêm vào', 'Thay thế'].forEach((o) => {
        const r = el('input', { type: 'radio', name: 'imp_mode', value: o }); if (mode === o) r.checked = true;
        r.addEventListener('change', () => { if (r.checked) mode = o; });
        modeGrp.appendChild(el('label.pc-radio', {}, [r, el('span', { text: o })]));
      });

      openModal({
        title: 'Nhập', width: 560,
        body: [
          tabsEl,
          fileTab,
          rpaTab,
          el('div.rpa-set-row.col', {}, [el('div.rpa-set-label', { text: 'Nội dung nhập' }), modeGrp]),
        ],
        footer: [
          el('button.btn', { text: 'Hủy', onclick: closeModal }),
          el('button.btn.primary', { text: 'OK', onclick: () => {
            const raw = tab === 'plus' ? pickedText : pasteTa.value;
            if (!raw || !raw.trim()) { toast(tab === 'plus' ? 'Hãy chọn tệp quy trình' : 'Hãy dán nội dung quy trình', 'err'); return; }
            let data;
            try { data = JSON.parse(raw); } catch { toast('Nội dung quy trình không hợp lệ', 'err'); return; }
            const g = data.graph || data;
            if (!applyImportedGraph(g, mode)) return;
            if (mode === 'Thay thế' && data.name) flow.name = data.name;
            closeModal();
            toast('Đã nhập quy trình', 'ok');
          } }),
        ],
      });
    }

    // "Nhật ký debug" - a bottom-docked panel over the canvas (NOT a modal), like
    // AdsPower. Toggled by the toolbar log icon; collapsible + closable.
    let logExpanded = false;
    function toggleLog(force) {
      const on = force == null ? !logDock.classList.contains('open') : !!force;
      logDock.classList.toggle('open', on);
      if (on) renderLogHead();
    }
    function renderLogHead() {
      logTitleSN.textContent = `Log (Process: ${flow.name || '-'}, Serial number: ${flow.id || '-'})`;
    }
    // Trạng thái rỗng - dựng lại được để nút "Dọn nhật ký" trả panel về đúng vẻ ban đầu
    // thay vì để lại một vùng trắng trơn không nói gì.
    const logEmptyState = () => el('div.rpa-logdock-empty', {}, [
      el('div.rpa-empty-ico', { html: icon('automation') }),
      el('div', { text: 'Chưa có nhật ký. Nhật ký debug sẽ hiển thị khi bạn chạy gỡ lỗi quy trình.' }),
    ]);
    const logBody = el('div.rpa-logdock-body', {}, [logEmptyState()]);
    const logTitleSN = el('span.rpa-logdock-sn');
    const logExpandBtn = el('button.rpa-logdock-btn', { html: icon('expandDiag'), title: 'Mở rộng' });
    logExpandBtn.onclick = () => { logExpanded = !logExpanded; logDock.classList.toggle('big', logExpanded); logExpandBtn.title = logExpanded ? 'Thu nhỏ' : 'Mở rộng'; };
    const logDock = el('div.rpa-logdock', {}, [
      el('div.rpa-logdock-head', {}, [
        el('span.rpa-logdock-title', { text: 'Nhật ký debug' }),
        logTitleSN,
        el('div.rpa-logdock-tools', {}, [
          logExpandBtn,
          el('button.rpa-logdock-btn', { html: icon('clearLog'), title: 'Dọn nhật ký', onclick: () => resetLog() }),
          el('button.rpa-logdock-btn', { html: icon('close'), title: 'Đóng', onclick: () => toggleLog(false) }),
        ]),
      ]),
      logBody,
    ]);
    // Dọn TAY: xoá sạch dòng log và trả về trạng thái rỗng. Khác clearLog() (dùng lúc bắt
    // đầu chạy) vì clearLog() dựng sẵn danh sách trống để log mới đổ vào ngay.
    function resetLog() {
      clear(logBody);
      logBody._list = null;
      logBody.appendChild(logEmptyState());
    }

    // Replace the empty-state with a fresh scrollable log list.
    function clearLog() {
      clear(logBody);
      logBody._list = el('div.rpa-logdock-list');
      logBody.appendChild(logBody._list);
    }
    // Format a Date as "[ 2026-06-27 15:00:08 ]".
    function fmtLogTs(t) {
      const p = (n) => String(n).padStart(2, '0');
      return `[ ${t.getFullYear()}-${p(t.getMonth() + 1)}-${p(t.getDate())} ${p(t.getHours())}:${p(t.getMinutes())}:${p(t.getSeconds())} ]`;
    }
    // Build the message cell, colouring any URL / link tokens blue (these are the
    // kind of values that get imported into the browser config, e.g. visited URLs).
    function buildLogMsg(text) {
      const cell = el('span.rpa-log-msg');
      const str = String(text || '');
      const re = /(https?:\/\/[^\s"'<>]+)/g;
      let last = 0, m;
      while ((m = re.exec(str)) !== null) {
        if (m.index > last) cell.appendChild(document.createTextNode(str.slice(last, m.index)));
        cell.appendChild(el('span.rpa-log-link', { text: m[0] }));
        last = m.index + m[0].length;
      }
      if (last < str.length) cell.appendChild(document.createTextNode(str.slice(last)));
      return cell;
    }
    // Append one streamed log entry (timestamp · node · message). No dot icon.
    function appendLog(entry) {
      if (!entry) return;
      if (!logBody._list) clearLog();
      const t = entry.ts ? new Date(entry.ts) : new Date();
      const lvl = entry.level || 'info';
      const row = el('div.rpa-logrow.' + lvl, {}, [
        el('span.rpa-log-ts', { text: fmtLogTs(t) }),
        ...(entry.title ? [el('span.rpa-log-node', { text: entry.title })] : []),
        buildLogMsg(entry.msg),
      ]);
      logBody._list.appendChild(row);
      logBody.scrollTop = logBody.scrollHeight;
    }
    // After a run finishes, append a bordered box showing the total run time.
    function appendRunSummary(ms) {
      if (!logBody._list) return;
      const secs = Math.max(0, ms) / 1000;
      const human = secs < 60
        ? `${secs.toFixed(secs < 10 ? 2 : 1)} ${t('giây')}`
        : `${Math.floor(secs / 60)} ${t('phút')} ${Math.round(secs % 60)} ${t('giây')}`;
      const box = el('div.rpa-log-summary', { text: `${t('Tổng thời gian chạy')}: ${human}` });
      logBody._list.appendChild(box);
      logBody.scrollTop = logBody.scrollHeight;
    }

    // ============================================== RUN / DEBUG
    // Execute the current graph against a chosen profile, streaming live logs into
    // the bottom log dock (AdsPower's "Gỡ lỗi"). One run at a time.
    let currentRunId = null;
    let unsubLog = null;
    // Remember the profile picked for the last run so "Chạy" can re-run it directly
    // (no picker) and the hover tooltip can show which profile is selected.
    let lastRunProfile = null;
    async function runFlowDebug(profile) {
      const graph = serialize();
      if (!graph.nodes || graph.nodes.filter((n) => n.type !== 'start').length === 0) { toast('Quy trình trống', 'err'); return; }
      toggleLog(true);
      clearLog();
      const runId = 'run_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
      currentRunId = runId;
      if (unsubLog) { try { unsubLog(); } catch { /* ignore */ } unsubLog = null; }
      try { unsubLog = window.vt?.rpa?.onLog(runId, (entry) => appendLog(entry)); } catch { /* ignore */ }
      const pid = profile.id != null ? profile.id : profile.profileId;
      const startedAt = Date.now();
      try {
        // debug: true → CHẠY THỬ ("Gỡ lỗi"), không đồng bộ dữ liệu hồ sơ lên/xuống đám mây.
        const res = await window.vt?.rpa?.run({ runId, profileId: pid, graph, flowName: flow.name, flowId: flow.id, debug: true });
        if (res && res.ok) toast('Quy trình hoàn tất', 'ok');
        else if (res && res.stopped) toast('Đã dừng quy trình');
        else toast('Quy trình thất bại: ' + ((res && res.error) || ''), 'err');
      } catch (e) {
        appendLog({ level: 'error', msg: 'Lỗi: ' + (e && e.message) });
        toast('Quy trình thất bại', 'err');
      } finally {
        appendRunSummary(Date.now() - startedAt);
        if (unsubLog) { try { unsubLog(); } catch { /* ignore */ } unsubLog = null; }
        currentRunId = null;
      }
    }

    // ============================================== TOP BAR
    function tool(name, title, onclick, cls) { return el('button.rpa-tool' + (cls ? '.' + cls : ''), { html: icon(name), title, onclick }); }

    function serialize() {
      return {
        // `local` phải được giữ lại khi lưu, nếu không biến làm việc sẽ bị coi là
        // tham số đầu vào ngay lần mở lại kế tiếp. Không có cờ = tham số đầu vào.
        variables: (variables || []).filter((v) => v && v.name).map((v) => ({ name: v.name, type: v.type || 'String', value: v.value || '', desc: v.desc || '', label: v.label ? v.label : undefined, local: v.local ? true : undefined })),
        settings: { ...settings },
        nodes: nodes.map((n) => ({ id: n.id, type: n.type, title: n.title, icon: n.icon, color: n.color, x: Math.round(n.x), y: Math.round(n.y), params: n.params, disabled: n.disabled || undefined, onError: n.onError || undefined })),
        connections: connections.map((c) => ({ source: c.source, target: c.target, branch: c.branch, color: c.color })),
      };
    }
    // Ảnh chụp đồ thị ở lần lưu gần nhất, để biết có thay đổi chưa lưu hay không.
    // serialize() luôn sinh khoá theo THỨ TỰ CỐ ĐỊNH nên so sánh chuỗi JSON là đủ.
    let savedSnap = null;
    function isDirty() { return savedSnap !== null && JSON.stringify(serialize()) !== savedSnap; }

    let saving = false;
    async function save() {
      if (saving) return false;
      saving = true;
      const graph = serialize();
      // Chế độ Chợ: KHÔNG lưu vào flows.json - bàn giao đồ thị cho onSave (ghi ngược
      // lên Chợ). onSave tự lo toast/kết quả, chỉ trả bool để trình sửa chốt ảnh chụp.
      if (opts && typeof opts.onSave === 'function') {
        const snap = JSON.stringify(graph);
        let ok = false;
        try { ok = await opts.onSave(graph); } catch { ok = false; }
        saving = false;
        if (ok) { savedSnap = snap; return true; }
        return false;
      }
      flow.graph = graph;
      // Chốt ảnh chụp TRƯỚC khi gửi: persistFlow() gán đè flow.graph bằng bản server
      // trả về, đọc sau sẽ so nhầm với dữ liệu đã bị thay.
      const snap = JSON.stringify(flow.graph);
      const res = await persistFlow(flow);
      saving = false;
      if (res.ok) { savedSnap = snap; toast('Đã lưu quy trình', 'ok'); return true; }
      toast(describeError(res, 'Lưu quy trình thất bại'), 'err');
      return false;
    }

    // "Quay lại" + "Chỉnh sửa quy trình" now live in the app header (setEditorHeader).
    undoBtn = tool('undo', 'Hoàn tác (Ctrl+Z)', undo);
    redoBtn = tool('redo', 'Làm lại (Ctrl+Y)', redo);

    // Run trigger, used by BOTH the toolbar "Chạy" button AND every node's "Gỡ lỗi"
    // button. Behaviour once a profile has been chosen for a run:
    //   • clicking RUNS that profile directly (no picker modal);
    //   • hovering shows the SHARED app tooltip but in its "rich" state - "Hồ sơ đã
    //     chọn: <tên>" with a blue "Chọn lại" link that reopens the picker. When no
    //     profile is chosen yet, the same tooltip falls back to its plain title text.
    // We do NOT build a separate tooltip element; we just change the state/content of
    // the existing shared tooltip via setRichTooltip().
    function wireRunTrigger(btn, defaultTitle) {
      btn.title = defaultTitle;
      setRichTooltip(btn, () => {
        if (!lastRunProfile) return null; // fall back to plain `title` text
        return el('div.rpa-run-tip-card', {}, [
          el('span.rpa-run-tip-label', { text: 'Hồ sơ đã chọn: ' + (lastRunProfile.name || lastRunProfile.profileId || '') }),
          el('a.rpa-run-tip-reselect', { text: 'Chọn lại', onclick: () => { hideTooltip(); openDebugPicker(); } }),
        ]);
      });
      btn.addEventListener('click', (e) => { e.stopPropagation(); hideTooltip(); if (lastRunProfile) runFlowDebug(lastRunProfile); else openDebugPicker(); });
    }

    // "Chia sẻ" - chia sẻ (xuất) quy trình hiện tại ra tệp để gửi cho người khác.
    function shareFlow() { exportFlow(); }

    // "Đăng chợ" - đăng quy trình hiện tại lên Chợ. Clone 1:1 dialog "Đăng quy trình lên chợ"
    // của MKTLogin (đã soi trực tiếp): [Tiêu đề · Chọn danh mục] / [Mô tả · Tải hình ảnh] /
    // [Mã hóa quy trình (Mã hóa/Không mã hóa) · Phí tải về (VND, phí dùng mỗi tháng)] /
    // Hướng dẫn sử dụng. Nguồn graph = flow đang mở (serialize()).
    async function openPublishMarket() {
      // Cổng gói: "Đăng chợ kịch bản" là tính năng trả phí → gói Free hiện modal nâng cấp.
      if (!hasFeature('market_publish')) { gateFeature('market_publish', {}); return; }
      // BẮT cập nhật thông tin cá nhân (tên hiển thị) TRƯỚC khi cho đăng - chỉ hiện với tài
      // khoản chưa đặt tên hiển thị (người đăng phải có danh xưng). Cập nhật 1 lần rồi thôi;
      // muốn sửa sau thì vào hồ sơ nhà phát triển ở trang Chợ. Huỷ → không mở form đăng.
      if (!(await ensureDevProfile())) return;
      // MỌI tài khoản đều đăng được; bản đăng ở trạng thái "chờ duyệt" cho tới khi admin duyệt.
      // Nếu quy trình này ĐÃ đăng và đang CHỜ DUYỆT → hiện lại modal chờ duyệt (muốn đăng lại
      // từ đầu phải bấm "Huỷ yêu cầu"). openPublishPending được hoist trong hàm này nên gọi được.
      if (flow.marketPendingId) {
        let existing = null;
        try { const r = await window.vt?.market?.get(flow.marketPendingId); existing = r && r.item; }
        catch { existing = null; }
        if (existing && existing.status === 'pending') { openPublishPending(existing.id); return; }
        // Không còn 'pending' (đã duyệt/từ chối/bị xoá) → quên liên kết, cho đăng mới.
        flow.marketPendingId = ''; persistFlow(flow).catch(() => {});
      }
      const CATS = [
        { value: 'amazon', label: 'Amazon' }, { value: 'ebay', label: 'Ebay' },
        { value: 'facebook', label: 'Facebook' }, { value: 'google', label: 'Google' },
        { value: 'instagram', label: 'Instagram' }, { value: 'reddit', label: 'Reddit' },
        { value: 'twitter', label: 'Twitter X' }, { value: 'linkedin', label: 'LinkedIn' },
        { value: 'esty', label: 'Esty' }, { value: 'discord', label: 'Discord' },
        { value: 'telegram', label: 'Telegram' }, { value: 'zalo', label: 'Zalo' },
        { value: 'tiktok', label: 'Tiktok' }, { value: 'youtube', label: 'YouTube' },
        { value: 'website', label: 'Website' }, { value: 'other', label: 'Khác' },
      ];

      const titleInp = el('input.input.rpa-pub-title-inp', { value: flow.name || '', placeholder: 'Tiêu đề' });
      let catVal = '';
      // onChange gọi refreshImg (định nghĩa bên dưới) để ô ảnh hiện logo danh mục vừa chọn.
      // Chọn danh mục sẽ GHI ĐÈ ảnh tải lên bằng tay: reset uploaded/iconVal để logo danh mục thắng.
      const catSel = customSelect(CATS, { value: '', placeholder: 'Chọn danh mục', width: '100%', height: 46, onChange: (v) => { catVal = v; uploaded = false; iconVal = ''; imgDismissed = false; refreshImg(); } });
      const descInp = el('textarea.input.rpa-pub-desc', { rows: '4', placeholder: 'Mô tả' });

      // Ô ảnh: (1) chưa chọn gì → placeholder "Tải hình ảnh"; (2) đã chọn danh mục (chưa tự
      // tải ảnh) → hiện LOGO THƯƠNG HIỆU của danh mục (nền màu brand + logo trắng); (3) tự
      // tải ảnh riêng → ảnh đó ưu tiên, đè logo. Bấm ô luôn mở hộp thoại chọn tệp để đè.
      let iconVal = '';        // data URL người dùng tự tải (ưu tiên hơn logo danh mục)
      let uploaded = false;
      let imgDismissed = false; // đã bấm "x" xoá ảnh (ẩn cả logo danh mục cho tới khi đổi danh mục)
      const imgBox = el('button.rpa-pub-img', { type: 'button' });
      // Nút "x" xoá ảnh - dùng <span> (không lồng <button> trong <button> imgBox); chặn sự kiện
      // nổi bọt để không kích hoạt hộp chọn file. Xoá ảnh tải LẪN logo danh mục (đặt imgDismissed).
      const addRemoveBtn = () => {
        const x = el('span.rpa-pub-img-x', { html: icon('close'), title: 'Xóa ảnh' });
        x.addEventListener('click', (e) => { e.stopPropagation(); e.preventDefault(); iconVal = ''; uploaded = false; imgDismissed = true; refreshImg(); });
        imgBox.appendChild(x);
      };
      const UPLOAD_ICON = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M0 0h24v24H0z" fill="none"/><path fill="currentColor" d="M19.35 10.04A7.49 7.49 0 0 0 12 4C9.11 4 6.6 5.64 5.35 8.04A5.994 5.994 0 0 0 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5c0-2.64-2.05-4.78-4.65-4.96M14 13v4h-4v-4H7l5-5l5 5z"/></svg>';
      const showPlaceholder = () => {
        clear(imgBox); imgBox.classList.remove('has-brand', 'has-thumb'); imgBox.style.removeProperty('--brand-tile');
        imgBox.appendChild(el('span.rpa-pub-img-ico', { html: UPLOAD_ICON }));
        imgBox.appendChild(el('span.rpa-pub-img-txt', { text: 'Tải lên ảnh' }));
      };
      const showBrand = (plat) => {
        clear(imgBox); imgBox.classList.remove('has-thumb'); imgBox.classList.add('has-brand');
        imgBox.style.setProperty('--brand-tile', brandTileBg(plat));
        imgBox.appendChild(el('span.rpa-pub-brand', { html: brandLogoSvg(plat) }));
        addRemoveBtn();
      };
      const showThumb = () => {
        clear(imgBox); imgBox.classList.remove('has-brand'); imgBox.classList.add('has-thumb'); imgBox.style.removeProperty('--brand-tile');
        imgBox.appendChild(el('img.rpa-pub-thumb', { src: iconVal }));
        addRemoveBtn();
      };
      const refreshImg = () => { if (uploaded) showThumb(); else if (!imgDismissed && catVal && hasBrandLogo(catVal)) showBrand(catVal); else showPlaceholder(); };
      refreshImg();
      imgBox.addEventListener('click', () => {
        const fi = document.createElement('input'); fi.type = 'file'; fi.accept = 'image/*';
        fi.addEventListener('change', () => {
          const f = fi.files && fi.files[0]; if (!f) return;
          const rd = new FileReader();
          rd.onload = () => { iconVal = String(rd.result || ''); uploaded = true; showThumb(); };
          rd.readAsDataURL(f);
        });
        fi.click();
      });

      // Mã hóa quy trình - SEGMENTED CONTROL (kiểu ở "Tạo hồ sơ" .pc-seg), mặc định "Mã hóa".
      let encrypt = true;
      const encSeg = el('div.seg.pc-seg.rpa-pub-seg');
      const encOpts = [[true, 'Mã hóa'], [false, 'Không mã hóa']];
      const renderEncSeg = () => {
        clear(encSeg);
        encOpts.forEach(([v, l]) => encSeg.appendChild(el('button.seg-opt' + (v === encrypt ? '.active' : ''), {
          type: 'button', html: `<span>${l}</span>`, onclick: () => { encrypt = v; renderEncSeg(); },
        })));
      };
      renderEncSeg();

      // Phí tải về (VND) - phí sử dụng cho mỗi tháng. Dùng type=text + inputmode=numeric (KHÔNG
      // dùng type=number: trình duyệt vẽ vạch đỏ "invalid" dưới nhãn nổi khi mở modal) + lọc số.
      const feeInp = el('input.input.rpa-pub-fee', { type: 'text', inputmode: 'numeric', spellcheck: 'false', value: '0' });
      feeInp.addEventListener('input', () => { const c = feeInp.value.replace(/[^0-9]/g, ''); if (c !== feeInp.value) feeInp.value = c; });

      // "Hướng dẫn sử dụng" = trình soạn thảo RICH TEXT (Quill snow theme) - GIỐNG HỆT
      // MKTLogin: thanh công cụ đầy đủ (heading, B/I/U/S, màu chữ/nền, danh sách, thụt lề,
      // upper/subscript, code, trích dẫn, hướng đoạn, canh lề, link/ảnh/video, công thức,
      // xoá định dạng). readme lưu dưới dạng HTML. Quill nạp từ vendor (ensureQuill).
      const editorHost = el('div.rpa-pub-quill-host');
      const editorWrap = el('div.rpa-pub-editor', {}, [editorHost]);
      let quill = null;

      // Nạp Quill (idempotent) TRƯỚC khi mở modal để khởi tạo editor ngay khi DOM sẵn sàng.
      let Quill = null;
      try { Quill = await ensureQuill(); }
      catch (err) { toast('Không tải được trình soạn thảo hướng dẫn', 'err'); return; }

      const doPublish = async (btn) => {
        const title = titleInp.value.trim();
        if (!title) return toast('Vui lòng nhập tiêu đề', 'err');
        if (!catVal) return toast('Vui lòng chọn danh mục', 'err');
        const price = Math.max(0, Math.round(Number(feeInp.value) || 0));
        // readme = HTML của editor; rỗng nếu Quill chỉ chứa placeholder (`<p><br></p>`).
        const readmeHtml = quill && !quill.getText().trim() ? '' : (quill ? quill.root.innerHTML : '');
        const payload = {
          title, platform: catVal, description: descInp.value.trim(),
          icon: iconVal, readme: readmeHtml,
          price, billing: price > 0 ? 'monthly' : 'free',
          version: flow.version || '1.0.0', encrypt,
          data: serialize(),
        };
        if (btn) btn.disabled = true;
        let res;
        try { res = await window.vt?.market?.publish(payload); }
        catch (err) { res = { ok: false, code: err && err.code, status: err && err.status }; }
        // IPC bọc kết quả: thành công = { ok:true, data:item }, lỗi = { ok:false, error, code, status }.
        if (res && res.ok) {
          // Ghi nhớ id bản đăng ĐANG CHỜ DUYỆT lên flow (persist) để lần sau bấm "Đăng chợ"
          // sẽ hiện lại modal chờ duyệt thay vì form đăng mới.
          const item = res.data || {};
          if (item.id) { flow.marketPendingId = item.id; persistFlow(flow).catch(() => {}); }
          closeModal();
          openPublishPending(item.id);
        }
        else { if (btn) btn.disabled = false; toast(describeError(res, 'Đăng quy trình thất bại'), 'err'); }
      };

      // Modal xác nhận: quy trình đang CHỜ PHÊ DUYỆT. "Huỷ yêu cầu" gỡ bản pending + xoá
      // liên kết trên flow (cho phép đăng mới sau đó); "Đóng" chỉ đóng. KHÔNG có số điện thoại.
      function openPublishPending(pendingId) {
        openModal({
          title: 'QUY TRÌNH ĐANG CHỜ PHÊ DUYỆT', width: 460,
          body: [el('div.rpa-pub-pending', {}, [
            el('div.rpa-pub-pending-txt', {
              text: 'Thời gian phê duyệt quy trình trong vòng 24h, nếu bạn chờ lâu hơn có thể liên hệ trực tiếp qua chúng tôi.',
            }),
          ])],
          footer: [
            el('button.btn', { text: 'Huỷ yêu cầu', onclick: async (e) => {
              const b = e.currentTarget; b.disabled = true;
              try {
                if (pendingId) await window.vt?.market?.remove(pendingId);
                flow.marketPendingId = ''; persistFlow(flow).catch(() => {});
                closeModal(); toast('Đã huỷ yêu cầu đăng quy trình', 'ok');
              }
              catch (err) { b.disabled = false; toast(describeError(err, 'Huỷ yêu cầu thất bại'), 'err'); }
            } }),
            el('button.btn.primary', { text: 'Đóng', onclick: closeModal }),
          ],
        });
      }

      // Bố cục 2 CỘT (khác MKTLogin để tránh giống hệt): CỘT CHÍNH bên trái = tiêu đề +
      // [danh mục · phí] + trình soạn "Hướng dẫn sử dụng" chiếm phần lớn; CỘT PHỤ bên phải
      // = ảnh bìa + mô tả + mã hóa. Nút [Hủy][Đăng] về FOOTER chuẩn của app (không ở header).
      // Ô nhập chữ dùng NHÃN NỔI: bỏ nhãn tĩnh phía trên, đặt nhãn NẰM TRONG ô như placeholder,
      // khi focus/có nội dung thì nhãn "trượt lên" trên. Cần placeholder=' ' để :placeholder-shown chạy.
      const floatField = (labelText, node, area) => {
        node.setAttribute('placeholder', ' ');
        return el('div.rpa-ff' + (area ? '.area' : ''), {}, [node, el('label.rpa-ff-lbl', { text: labelText })]);
      };
      // Nhãn tĩnh CHỈ còn cho nhóm không phải ô chữ (radio + trình soạn thảo).
      const labeled = (label, node, cls) => el('div.rpa-pub2-fld' + (cls ? '.' + cls : ''), {}, [
        el('div.rpa-pub-lbl', { text: label }), node,
      ]);
      feeInp.setAttribute('placeholder', ' ');
      const feeField = el('div.rpa-pub2-fld.fee', {}, [
        el('div.rpa-ff.fee', {}, [feeInp, el('label.rpa-ff-lbl', { text: 'Phí tải về' }), el('span.rpa-pub-fee-suffix', { text: 'VND/tháng' })]),
      ]);
      openModal({
        title: 'Đăng quy trình lên chợ', width: 900,
        body: [el('div.rpa-pub2-wrap', {}, [
          // Tiêu đề TRÀN NGANG toàn modal.
          floatField('Tiêu đề', titleInp),
          el('div.rpa-pub2', {}, [
            el('div.rpa-pub2-main', {}, [
              el('div.rpa-pub2-row', {}, [
                el('div.rpa-pub2-fld', {}, [catSel]),
                feeField,
              ]),
              // Bỏ nhãn tĩnh "Hướng dẫn sử dụng" - editor đã có placeholder tương ứng.
              el('div.rpa-pub2-fld.grow', {}, [editorWrap]),
            ]),
            el('div.rpa-pub2-side', {}, [
              floatField('Mô tả', descInp, true),
              labeled('Mã hóa quy trình', encSeg),
              // Ô "tải lên ảnh" đưa xuống DƯỚI CÙNG cột phụ (dưới "Mã hóa quy trình").
              el('div.rpa-pub2-topimg', {}, [imgBox]),
            ]),
          ]),
        ])],
        footer: [
          el('button.btn', { text: 'Hủy', onclick: closeModal }),
          el('button.btn.primary', { text: 'Đăng', onclick: (e) => doPublish(e.currentTarget) }),
        ],
      });

      // Khởi tạo Quill sau khi container đã ở trong DOM.
      quill = new Quill(editorHost, {
        theme: 'snow',
        placeholder: 'Hướng dẫn sử dụng...',
        modules: {
          toolbar: [
            [{ header: [1, 2, 3, 4, 5, 6, false] }],
            ['bold', 'italic', 'underline', 'strike'],
            [{ color: [] }, { background: [] }],
            [{ list: 'ordered' }, { list: 'bullet' }],
            [{ indent: '-1' }, { indent: '+1' }],
            [{ script: 'super' }, { script: 'sub' }],
            ['code-block', 'blockquote'],
            [{ direction: 'rtl' }],
            [{ align: [] }],
            ['link', 'image', 'video'],
            ['formula'],
            ['clean'],
          ],
        },
      });
      if (flow.readme) quill.root.innerHTML = flow.readme;
    }

    const runBtn = el('button.rpa-run', { html: `${icon('playFill')}<span>Chạy</span>`, title: 'Chạy quy trình' });
    wireRunTrigger(runBtn, 'Chạy quy trình');

    const topRight = el('div.rpa-float-tr', {}, [
      // Search cluster: the magnifier sits at the right of the pill (next to "Chạy").
      // Clicking it slides the input OUT to the right while the magnifier itself
      // glides LEFT (the pill is right-anchored, so it grows leftward). No "x" - the
      // magnifier toggles the input shut again. Placeholder "nhập tên hành động".
      el('div.rpa-tools.rpa-search-group', {}, [
        tool('search', 'Tìm kiếm', () => toggleSearch()),
        searchBox,
      ]),
      // "Chạy" pill sits right next to the search group.
      runBtn,
      el('div.rpa-tools.rpa-tools-mid', {}, [
        undoBtn,
        redoBtn,
        el('div.rpa-tool-sep'),
        tool('share', 'Chia sẻ', shareFlow),
        // Quy trình TẢI VỀ từ Chợ (source='market') chỉ được CHỈNH SỬA, KHÔNG cho đăng
        // lại lên Chợ → ẩn nút "Đăng chợ". Quy trình tự tạo (source='mine') vẫn đăng được.
        flow.source === 'market' ? null : tool('store', 'Đăng chợ', openPublishMarket),
        tool('fitScreen', 'Vừa màn hình', fitScreen),
      ].filter(Boolean)),
      el('div.rpa-tools', {}, [
        tool('importFlow', 'Nhập quy trình', importFlow),
        // Quy trình TẢI VỀ từ Chợ (source='market') KHÔNG cho "Xuất" ra .json (chống dump
        // graph plaintext bán chợ đen) → nút khoá mềm: mờ + con trỏ cấm, không bấm được.
        flow.source === 'market'
          ? el('button.rpa-tool.is-locked', { html: icon('exportFlow'), title: 'Quy trình tải từ Chợ không được xuất', onclick: () => toast('Quy trình tải từ Chợ không được xuất', 'err') })
          : tool('exportFlow', 'Xuất quy trình', exportFlow),
        el('div.rpa-tool-sep'),
        tool('settings', 'Cài đặt', openSettings),
        tool('log', 'Nhật ký debug', toggleLog),
        el('button.rpa-save', { html: `${icon('save')}<span>Lưu</span>`, onclick: save }),
      ]),
    ]);

    // "Chỉnh sửa thông tin" - edit this flow's name / group / note (AdsPower's
    // pencil dialog). Persists onto the flow object via vt.flows.save.
    function openFlowInfo() {
      // 1:1 with AdsPower's "Chỉnh sửa thông tin": right-aligned narrow label column,
      // full-width controls, char counter floated inside each input, group = creatable
      // dropdown, OK (flat blue) + Hủy (link) left-aligned under the control column.
      const nameIn = el('input.input', { value: flow.name || '', maxlength: 100 });
      const nameCount = el('span.rpa-fi-count', { text: `${(flow.name || '').length}/100` });
      nameIn.addEventListener('input', () => { nameCount.textContent = `${nameIn.value.length}/100`; });

      const noteIn = el('input.input', { value: flow.note || '', maxlength: 200, placeholder: 'Nhập ghi chú' });
      const noteCount = el('span.rpa-fi-count', { text: `${(flow.note || '').length}/200` });
      noteIn.addEventListener('input', () => { noteCount.textContent = `${noteIn.value.length}/200`; });

      let groupVal = flow.group || '';
      const groupNames = Array.from(new Set(FLOWS.map((f) => f.group).filter(Boolean)));
      const groupOpts = [{ value: '', label: 'Chưa chia nhóm' }].concat(groupNames.map((g) => ({ value: g, label: g })));
      const groupSel = customSelect(groupOpts, {
        value: groupVal,
        placeholder: 'Hãy chọn nhóm.',
        width: '100%',
        creatable: true,
        createPlaceholder: 'Hãy nhập tên nhóm',
        onChange: (v) => { groupVal = v; },
        onCreate: (name) => { groupVal = name; return { value: name, label: name }; },
      });

      const okBtn = el('button.btn.primary.rpa-fi-ok', { type: 'button', text: 'OK', onclick: async () => {
        const nm = nameIn.value.trim();
        if (!nm) { toast('Vui lòng nhập tên luồng', 'err'); return; }
        flow.name = nm; flow.group = groupVal; flow.note = noteIn.value;
        const res = await persistFlow(flow);
        if (!res.ok) { toast(describeError(res, 'Lưu thông tin luồng thất bại'), 'err'); return; }
        libTitle.textContent = flow.name;
        libTitle.title = flow.name;
        libSub.textContent = flow.group || 'Chưa chia nhóm';
        closeModal();
        toast('Đã lưu thông tin luồng', 'ok');
      } });
      const cancelBtn = el('button.btn.rpa-fi-cancel', { type: 'button', text: 'Hủy', onclick: closeModal });

      const row = (label, control, required) => el('div.rpa-fi-row', {}, [
        el('div.rpa-fi-label', {}, [required ? el('span.req', { text: '*' }) : null, document.createTextNode(label)]),
        el('div.rpa-fi-ctrl', {}, control),
      ]);

      openModal({
        title: 'Chỉnh sửa thông tin', width: 676,
        body: [
          el('div.rpa-fi', {}, [
            row('Tên luồng', [nameIn, nameCount], true),
            row('Nhóm', [groupSel]),
            row('Ghi chú', [noteIn, noteCount]),
            el('div.rpa-fi-foot', {}, [el('div.rpa-fi-acts', {}, [okBtn, cancelBtn])]),
          ]),
        ],
      });
    }

    const libSub = el('div.rpa-lib-sub', { text: flow.group || 'Chưa chia nhóm' });
    const libTitle = el('span.rpa-lib-name', { text: flow.name || 'Quy trình chưa đặt tên', title: flow.name || '' });
    const libCollapseBtn = el('button.rpa-lib-collapse', { html: icon('chevronDown'), title: 'Thu gọn' });
    const libPanel = el('aside.rpa-lib', {}, [
      el('div.rpa-lib-head', {}, [
        el('div.rpa-lib-title', {}, [
          libTitle,
          el('button.rpa-lib-pencil', { html: icon('edit'), title: 'Chỉnh sửa thông tin', onclick: openFlowInfo }),
          libCollapseBtn,
        ]),
        libSub,
      ]),
      el('div.rpa-lib-search', {}, [el('div.searchbar.sm', {}, [el('span.ico', { html: icon('search') }), el('input.search-input', { placeholder: 'Tìm kiếm', oninput: (e) => { libSearch = e.target.value.trim(); renderLib(); } })])]),
      libBody,
    ]);
    // Vertical roll-up collapse: clicking the down-arrow rolls the panel's body up
    // (bottom→top) until only the header + search box remain, with a slow smooth
    // animation; clicking again rolls it back down. We animate the panel's own
    // max-height (it has overflow:hidden) so the rounded border itself slides up.
    libCollapseBtn.onclick = () => {
      const willCollapse = !libPanel.classList.contains('lib-collapsed');
      if (willCollapse) {
        const full = libPanel.offsetHeight;
        const head = libPanel.querySelector('.rpa-lib-head');
        const headOnly = (head ? head.offsetHeight : 56) + 2; // roll up OVER the textbox too
        libPanel.style.maxHeight = full + 'px';
        void libPanel.offsetHeight;                     // commit the start frame
        libPanel.classList.add('lib-collapsed');
        libPanel.style.maxHeight = headOnly + 'px';
      } else {
        const collapsedH = libPanel.offsetHeight;
        libPanel.classList.remove('lib-collapsed');
        libPanel.style.maxHeight = '';                  // measure natural full height
        const full = libPanel.offsetHeight;
        libPanel.style.maxHeight = collapsedH + 'px';
        void libPanel.offsetHeight;
        libPanel.style.maxHeight = full + 'px';
        const onEnd = (ev) => {
          if (ev.target !== libPanel || ev.propertyName !== 'max-height') return;
          libPanel.style.maxHeight = '';               // release so it can flex/scroll
          libPanel.removeEventListener('transitionend', onEnd);
        };
        libPanel.addEventListener('transitionend', onEnd);
      }
      libCollapseBtn.title = willCollapse ? 'Mở rộng' : 'Thu gọn';
      libCollapseBtn.classList.toggle('is-collapsed', willCollapse);
    };

    // The toolbar floats top-right OVER the canvas (no separate header row), so the
    // library card and the canvas both start at the very top - the library border
    // lines up with the toolbar cluster that holds "Lưu".
    const canvasCol = el('div.rpa-canvas-col', {}, [viewport, logDock]);
    // topRight (Lưu + tools) and searchBox anchor to the full-width .rpa-mid so
    // they keep a FIXED screen position even when the config drawer opens/closes.
    const editor = el('div.rpa-editor', {}, [
      el('div.rpa-mid', {}, [libPanel, canvasCol, mini, drawer, topRight]),
    ]);
    host.appendChild(editor);

    // keyboard shortcuts: undo/redo, save, delete selected, search, escape
    function onKey(e) {
      const t = e.target;
      const typing = t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable);
      const mod = e.ctrlKey || e.metaKey;
      if (mod && e.key.toLowerCase() === 'z' && !e.shiftKey) { e.preventDefault(); undo(); }
      else if (mod && (e.key.toLowerCase() === 'y' || (e.key.toLowerCase() === 'z' && e.shiftKey))) { e.preventDefault(); redo(); }
      else if (mod && e.key.toLowerCase() === 's') { e.preventDefault(); save(); }
      else if (mod && e.key.toLowerCase() === 'f') { e.preventDefault(); toggleSearch(true); }
      else if (e.key === 'Escape') { if (searchOpen) toggleSearch(false); else if (selectedId) closeDrawer(); }
      else if ((e.key === 'Delete' || e.key === 'Backspace') && !typing && selectedId && selectedId !== 'start') {
        const n = nodes.find((x) => x.id === selectedId); if (n) { e.preventDefault(); removeNode(n); }
      }
    }
    window.addEventListener('keydown', onKey); winHandlers.push(['keydown', onKey]);

    setEditorHeader();
    applyTransform();
    renderNodes();
    renderLib();
    renderMini();
    snapshot();          // baseline history entry
    updateUndoRedo();
    savedSnap = JSON.stringify(serialize());   // mốc "chưa có thay đổi nào"
    editorGuard = { isDirty, save };
  }

  // boot
  if (marketCtx) {
    openEditor({ name: marketCtx.name || 'Kịch bản', graph: marketCtx.graph }, { onSave: marketCtx.onSave });
  } else {
    showFlowList();
  }

  // On leaving the view, drop the editor-header styling (navigate() has already
  // set the new route's title text - we only strip the leftover flow class).
  // confirmLeave: router gọi TRƯỚC khi điều hướng (destroy() thì đã muộn - lúc đó
  // view sắp bị xoá, hỏi xong cũng không giữ lại được đồ thị nữa).
  return {
    confirmLeave: () => confirmLeaveEditor(),
    destroy() { cleanup(); const t = headerEl(); if (t) t.classList.remove('is-flow'); },
  };
}
