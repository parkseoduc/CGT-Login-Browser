// "Nhiệm vụ" (Tasks) page - lists the RPA tasks created by the profiles-grid
// "Tự động hóa" dialog (window.__rpaTasks). A task is a saved run definition: a
// chosen automation flow ("Quy trình") plus the profiles it runs on. From here a
// task can be run on demand ("Chạy"), scheduled ("Lên lịch" → opens the Lập lịch
// dialog which creates a window.__rpaSchedules entry), edited or deleted.
//
// Mirrors MKTLogin's Nhiệm Vụ list; reuses the shared "Hồ sơ" datagrid look
// (grid-card + profiles-grid + pager) and the rpa-store module for all state.
import { el, clear, toast, confirmDialog, customSelect, pageSizeSelect, gridEmpty, noTaskSvg, noLogSvg, openModal, closeModal, openMenu } from '../ui.js';
import { icon } from '../icons.js';
import { t, tf } from '../i18n.js';
import { tasks, removeTask, runTask, stopTask, isTaskRunning, onRunningChange,
  openScheduleDialog, fmtDateTime, schedules, ready, onTasksChange,
  taskLogs, clearTaskLogs, fmtStamp, fmtDuration, runStatusLabel } from '../data/rpa-store.js';
import { notifyError } from '../data/errors.js';

const vt = window.vt;

export function render(ctx) {
  const navigate = ctx.navigate;
  let flowsList = [];         // [{ id, name, group }]
  let filtered = [];
  let page = 0;
  let pageSize = 10;
  let searchText = '';
  const selected = new Set();

  const tbody = el('tbody');
  const emptyEl = gridEmpty('Chưa có nhiệm vụ nào. Tạo nhiệm vụ từ trang "Hồ sơ" → nút "Tự động hóa".', noTaskSvg);
  const totalText = el('span.muted');
  const pageNumbers = el('div.page-nums');
  const selectAll = el('input', { type: 'checkbox' });

  const flowName = (id) => { const f = flowsList.find((x) => x && x.id === id); return f ? (f.name || '(không tên)') : '-'; };
  const schedCount = (taskId) => schedules().filter((s) => s.taskId === taskId).length;

  function matches(t) {
    if (!searchText) return true;
    const hay = `${t.name} ${flowName(t.flowId)} ${t.note || ''}`.toLowerCase();
    return hay.includes(searchText);
  }
 function applyFilter() {
  filtered = tasks()
    .filter(matches)
    .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0)); // mới nhất lên đầu
  page = 0;
  renderPage();
}

  function renderPage() {
    const pages = Math.max(1, Math.ceil(filtered.length / pageSize));
    if (page >= pages) page = pages - 1;
    const slice = filtered.slice(page * pageSize, page * pageSize + pageSize);
    clear(tbody);
    slice.forEach((tk, i) => {
      const cb = el('input', { type: 'checkbox', checked: selected.has(tk.id),
        onchange: (e) => { e.target.checked ? selected.add(tk.id) : selected.delete(tk.id); syncSelAll(); } });
      const created = fmtDateTime(tk.createdAt);
      const nSched = schedCount(tk.id);

      // action cell: Chạy/Dừng (toggles theo trạng thái chạy thực) · Lên lịch · Nhật ký · kebab
      const runningNow = isTaskRunning(tk.id);
      const runBtn = runningNow
        ? el('button.btn.danger.sm.task-run.is-stop', { html: `${icon('stopFill')}<span>Dừng</span>`,
            onclick: () => stopTask(tk.id) })
        : el('button.btn.primary.sm.glow.task-run', { html: `${icon('playFill')}<span>Chạy</span>`,
            onclick: () => runTask(tk) });
      const schedBtn = el('button.icon-btn', { html: icon('scheduleClock'), title: 'Lên lịch',
        onclick: () => openScheduleDialog(tk, null, () => renderPage()) });
      const logBtn = el('button.icon-btn', { html: icon('journal'), title: 'Nhật ký',
        onclick: () => openLogModal(tk) });
      const kebab = el('button.icon-btn.kebab', { html: icon('moreVertical'), title: 'Thêm',
        onclick: (e) => {
          e.stopPropagation();
          openMenu(kebab, [
            { label: 'Chỉnh sửa', icon: 'edit', onClick: () => navigate('task_edit', tk.id) },
            { label: 'Xóa', icon: 'trash', danger: true, onClick: () => {
              confirmDialog({ title: 'Xóa nhiệm vụ', danger: true, confirmLabel: 'Xóa',
                message: `${t('Xóa nhiệm vụ "')}${tk.name}${t('"? Các lịch của nhiệm vụ này cũng sẽ bị xóa.')}`,
                onConfirm: async () => { selected.delete(tk.id); try { await removeTask(tk.id); applyFilter(); toast('Đã xóa nhiệm vụ', 'ok'); } catch (e) { applyFilter(); notifyError(e, 'Xóa nhiệm vụ thất bại'); } } });
            } },
          ]);
        } });

      tbody.appendChild(el('tr', {}, [
        el('td.col-check', {}, [cb]),
        el('td', { text: String(page * pageSize + i + 1) }),
        el('td', {}, [el('div.name-main.task-name-link', { text: tk.name || '(không tên)', title: 'Chỉnh sửa nhiệm vụ', onclick: () => navigate('task_edit', tk.id) })]),
        el('td', {}, [el('span.task-flow', { html: `${icon('automation')}<span>${flowName(tk.flowId)}</span>`, title: flowName(tk.flowId) })]),
        el('td', {}, [el('span.task-prof', { html: `${icon('users')}<b>${(tk.profileIds || []).length}</b><span>hồ sơ</span>` })]),
        el('td', {}, [nSched ? el('span.chip.sched-chip', { html: `${icon('clock')}<span>${nSched}</span>` }) : el('span.muted', { text: '-' })]),
        el('td.muted', { text: created ? `${created.date} ${created.time}` : '-' }),
        el('td.col-action', {}, [el('div.row-actions', {}, [runBtn, schedBtn, logBtn, kebab])]),
      ]));
    });
    const total = filtered.length;
    const from = total === 0 ? 0 : page * pageSize + 1;
    const to = Math.min((page + 1) * pageSize, total);
    totalText.textContent = total === 0 ? `0 ${t('trên')} 0` : `${from}-${to} ${t('trên')} ${total}`;
    emptyEl.style.display = total === 0 ? 'flex' : 'none';
    renderPager(pages);
    syncSelAll();
  }

  function syncSelAll() {
    const slice = filtered.slice(page * pageSize, page * pageSize + pageSize);
    selectAll.checked = slice.length > 0 && slice.every((t) => selected.has(t.id));
  }

  function renderPager(pages) {
    clear(pageNumbers);
    for (let i = 0; i < pages; i++) {
      if (pages > 7 && i > 1 && i < pages - 2 && Math.abs(i - page) > 1) {
        if (i === 2 || i === pages - 3) pageNumbers.appendChild(el('span.muted', { text: '…' }));
        continue;
      }
      pageNumbers.appendChild(el('button.page-num' + (i === page ? '.active' : ''), { text: String(i + 1), onclick: () => { page = i; renderPage(); } }));
    }
  }

  // Nạp danh sách quy trình để cell "Quy trình" map flowId → tên. PHẢI nạp lại mỗi
  // lần hiển thị lại: flowsList theo TỪNG workspace, mà list này re-render qua
  // onTasksChange/onShow (vd sau khi ĐỔI không gian làm việc: refresh() thay mới tác
  // vụ nhưng flowsList vẫn giữ quy trình của workspace CŨ) → mọi flowId tra không
  // khớp và rơi về "-". Nạp lại giữ flowsList đồng bộ với tác vụ đang hiển thị.
  async function loadFlows() {
    try { const fl = await vt.flows.list(); flowsList = Array.isArray(fl) ? fl : []; }
    catch { flowsList = []; }
  }

  async function load() {
    // Chờ tác vụ tải xong từ server (workspace hiện hành) rồi mới lọc/hiển thị.
    try { await ready(); } catch { /* offline → cache rỗng */ }
    await loadFlows();
    selected.clear();
    applyFilter();
  }

  // ---- "Nhật ký" modal: a task's run history (start / end / duration / status)
  const RUN_BADGE = { done: 'green', partial: 'amber', error: 'red' };
  function openLogModal(task) {
    let lgPage = 0;
    let lgSize = 10;
    const body = el('div.log-modal');
    function renderLogs() {
      clear(body);
      const logs = taskLogs(task.id);
      if (!logs.length) {
        // gridEmpty() defaults to display:none (grids toggle it on); this one is
        // shown unconditionally, so force it visible.
        const lgEmpty = gridEmpty('Nhiệm vụ này chưa có lần chạy nào.', noLogSvg);
        lgEmpty.style.display = 'flex';
        body.appendChild(lgEmpty);
        return;
      }
      const pages = Math.max(1, Math.ceil(logs.length / lgSize));
      if (lgPage >= pages) lgPage = pages - 1;
      const slice = logs.slice(lgPage * lgSize, lgPage * lgSize + lgSize);
      const rows = slice.map((lg, i) => el('tr', {}, [
        el('td', { text: String(lgPage * lgSize + i + 1) }),
        el('td', { text: fmtStamp(lg.startedAt) }),
        el('td', { text: fmtStamp(lg.endedAt) }),
        el('td', { text: fmtDuration(lg.endedAt - lg.startedAt) }),
        el('td', {}, [el('span.badge.' + (RUN_BADGE[lg.status] || 'ready'), { text: runStatusLabel(lg.status) })]),
        el('td.col-action', {}, [el('div.row-actions', {}, [
          el('button.btn.sm.log-detail', { html: `${icon('log')}<span>Chi tiết</span>`, onclick: () => openLogDetail(task, lg) }),
        ])]),
      ]));
      const th = (label, cls) => el('th' + (cls || ''), {}, [el('span', { text: label })]);
      const table = el('table.grid.profiles-grid.task-grid.log-grid', {}, [
        el('thead', {}, [el('tr', {}, [
          th('STT'), th('Bắt đầu lúc'), th('Hồ sơ kết thúc lúc'),
          th('Thời gian chạy'), th('Trạng thái'), th('Hành động', '.col-action'),
        ])]),
        el('tbody', {}, rows),
      ]);
      const from = lgPage * lgSize + 1;
      const to = Math.min((lgPage + 1) * lgSize, logs.length);
      const sizeSel = pageSizeSelect([10, 25, 50], { value: lgSize, onChange: (v) => { lgSize = v; lgPage = 0; renderLogs(); } });
      const pager = el('div.pager', {}, [
        el('span.muted', { text: 'Số dòng mỗi trang:' }), sizeSel,
        el('span.muted', { text: `${from}-${to} ${t('trên')} ${logs.length}` }),
        el('button.icon-btn', { html: icon('chevron'), style: { transform: 'rotate(180deg)' }, onclick: () => { if (lgPage > 0) { lgPage--; renderLogs(); } } }),
        el('button.icon-btn', { html: icon('chevron'), onclick: () => { if (lgPage < pages - 1) { lgPage++; renderLogs(); } } }),
      ]);
      body.appendChild(el('div.grid-card', {}, [table]));
      body.appendChild(pager);
    }
    renderLogs();
    openModal({
      title: `${t('Danh sách nhật ký của')} ${task.name || '(không tên)'}`, width: 900,
      body: [body],
      footer: [
        el('button.btn', { html: `${icon('trash')}<span>Xóa nhật ký</span>`, onclick: () => {
          confirmDialog({ title: 'Xóa nhật ký', danger: true, confirmLabel: 'Xóa',
            message: `${t('Xóa toàn bộ nhật ký chạy của nhiệm vụ "')}${task.name}"?`,
            onConfirm: () => { clearTaskLogs(task.id); renderLogs(); toast('Đã xóa nhật ký', 'ok'); } });
        } }),
        el('button.btn.primary', { text: 'Đóng', onclick: closeModal }),
      ],
    });
  }

  // Per-run detail: profile-by-profile result of one execution.
  function openLogDetail(t, lg) {
    const rows = (lg.results || []).map((r, i) => el('tr', {}, [
      el('td', { text: String(i + 1) }),
      el('td', { text: String(r.profileId || '').slice(0, 8).toUpperCase() }),
      el('td', { text: fmtStamp(r.startedAt) }),
      el('td', { text: fmtDuration((r.endedAt || 0) - (r.startedAt || 0)) }),
      el('td', {}, [el('span.badge.' + (r.ok ? 'green' : 'red'), { text: r.ok ? 'Hoàn Thành' : 'Thất bại' })]),
    ]));
    const th = (label) => el('th', {}, [el('span', { text: label })]);
    const table = el('table.grid.profiles-grid.log-grid', {}, [
      el('thead', {}, [el('tr', {}, [th('STT'), th('Hồ sơ'), th('Bắt đầu lúc'), th('Thời gian chạy'), th('Trạng thái')])]),
      el('tbody', {}, rows),
    ]);
    openModal({
      title: tf('Chi tiết lần chạy · {0}', fmtStamp(lg.startedAt)), width: 720,
      body: [el('div.grid-card', {}, [table])],
      footer: [el('button.btn', { text: 'Quay lại', onclick: () => openLogModal(t) }),
        el('button.btn.primary', { text: 'Đóng', onclick: closeModal })],
    });
  }

  // ---- toolbar
  const searchInput = el('input.search-input', { placeholder: 'Tìm kiếm nhiệm vụ...',
    oninput: (e) => { searchText = e.target.value.trim().toLowerCase(); applyFilter(); } });
  const searchBar = el('div.searchbar', {}, [el('span.ico', { html: icon('search') }), searchInput]);

  const toolbar = el('div.toolbar.trash-bar', {}, [
    searchBar,
    el('button.icon-btn.tr-del', { html: icon('trash'), title: 'Xóa các nhiệm vụ đã chọn', onclick: () => {
      if (!selected.size) return toast('Chưa chọn nhiệm vụ nào');
      confirmDialog({ title: 'Xóa nhiệm vụ', danger: true, confirmLabel: 'Xóa',
        message: `${t('Xóa')} ${selected.size} ${t('nhiệm vụ đã chọn? Các lịch liên quan cũng sẽ bị xóa.')}`,
        onConfirm: async () => { const ids = [...selected]; selected.clear(); try { for (const id of ids) await removeTask(id); applyFilter(); toast('Đã xóa nhiệm vụ', 'ok'); } catch (e) { applyFilter(); notifyError(e, 'Xóa nhiệm vụ thất bại'); } } });
    } }),
    el('span.spacer'),
    el('button.icon-btn.reload', { html: icon('sync'), title: 'Làm mới', onclick: load }),
  ]);

  selectAll.onchange = (e) => {
    const slice = filtered.slice(page * pageSize, page * pageSize + pageSize);
    slice.forEach((t) => e.target.checked ? selected.add(t.id) : selected.delete(t.id));
    renderPage();
  };

  const sizeSel = pageSizeSelect([10, 25, 50, 100], { value: pageSize, onChange: (v) => { pageSize = v; page = 0; renderPage(); } });

  const th = (label, cls) => el('th' + (cls || ''), {}, [el('span', { text: label })]);
  const table = el('table.grid.profiles-grid.task-grid', {}, [
    el('thead', {}, [el('tr', {}, [
      el('th.col-check', {}, [selectAll]),
      th('STT'), th('Tên nhiệm vụ'), th('Quy trình'), th('Hồ sơ'),
      th('Lịch'), th('Ngày tạo'), th('Hành động', '.col-action'),
    ])]),
    tbody,
  ]);

  const pager = el('div.pager', {}, [
    el('span.muted', { text: 'Số dòng mỗi trang:' }),
    sizeSel,
    totalText,
    el('button.icon-btn', { html: icon('chevron'), style: { transform: 'rotate(180deg)' }, onclick: () => { if (page > 0) { page--; renderPage(); } } }),
    pageNumbers,
    el('button.icon-btn', { html: icon('chevron'), onclick: () => { const pages = Math.ceil(filtered.length / pageSize); if (page < pages - 1) { page++; renderPage(); } } }),
  ]);

  const pageEl = el('div.page', {}, [
    toolbar,
    el('div.grid-area', {}, [el('div.grid-card', {}, [table, emptyEl]), pager]),
  ]);
  ctx.container.appendChild(pageEl);
  load();

  // Re-render the action cell whenever any task's running state flips (start/stop),
  // so the Chạy/Dừng toggle stays in sync with real execution.
  const offRunning = onRunningChange(() => renderPage());
  // Re-render when the task collection changes (created from another view, or a
  // workspace-switch refresh() replaced the list). Nạp lại quy trình trước khi lọc
  // vì đổi workspace cũng đổi bộ quy trình → tránh cell "Quy trình" rơi về "-".
  const offTasks = onTasksChange(() => { loadFlows().then(applyFilter); });

  return {
    // Keep-alive route: refresh the list when returning (e.g. a run just started
    // from the profiles "Tự động hóa" dialog created a new task and navigated here).
    // Nạp lại quy trình để đồng bộ với workspace hiện hành khi quay lại trang.
    onShow() { loadFlows().then(applyFilter); },
    destroy() { offRunning(); offTasks(); },
  };
}
