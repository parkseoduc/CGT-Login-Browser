// Trang "Quản lý thiết bị" của APP - route 'devices' (mục sidebar). Trước 2026-11-12 là tab thứ hai trong trang Nâng cấp
// gói (views/upgrade.js); chủ sở hữu tách ra trang riêng. Toàn bộ logic dv* bê nguyên, chỉ đổi vỏ: pane = chính trang này.
// Đơn mua thiết bị vẫn đi qua trang Thủ tục thanh toán (saveOrder kind 'devices' → route 'checkout'), quay lại về đây.
import { el, clear, toast, openModal, closeModal } from '../ui.js';
import { icon } from '../icons.js';
import { t, tf } from '../i18n.js';
import { saveOrder } from './pay-common.js';

const fmtVnd = (n) => (Number(n) || 0).toLocaleString('vi-VN') + '₫';

export function render(ctx) {
  const host = el('div.upgrade-page.dv-route');
  ctx.container.appendChild(host);

  /* ══════════════════════════════════════════════════════════════════════════
     TRANG "QUẢN LÝ THIẾT BỊ" (route 'devices', mục sidebar - tách khỏi trang Nâng cấp gói 2026-11-12)
     ─────────────────────────────────────────────────────────────────────────
     BẢN SONG SINH của tab cùng tên ở dashboard web landing
     (web landing anti-browser/public/dashboard-upgrade.js -> renderDevices). Cùng server, cùng
     con số, cùng câu chữ, cùng cơ chế "số dư không đủ -> modal nạp tiền -> mua". Sửa một bên
     thì sửa cả bên kia, nếu không khách thấy hai con số khác nhau cho CÙNG một tài khoản.

     Vì sao tab này tồn tại: từ 2026-10-01 một MÁY chiếm một CHỖ từ lần đăng nhập đầu tiên và
     KHÔNG tự nhả - đăng xuất không trả chỗ, token hết hạn không trả chỗ. Chỗ chỉ được trả khi
     DÒNG `devices` bị xoá. Luật đó bịt đường lách "đăng xuất máy cũ là dùng được máy mới",
     nhưng tạo một ngõ cụt thật: khách CÀI LẠI MÁY thì hwid đổi, dòng cũ thành xác chết vẫn
     giữ chỗ. Tab này là lối tự phục vụ: GỠ máy cũ, hoặc MUA thêm chỗ.

     ⚠️ KHÁC bản landing ĐÚNG hai chỗ, cả hai vì CHÍNH APP NÀY là một trong các máy trong bảng
     (phiên web của landing có `device_id = NULL` nên nó không gặp chuyện này):
       • mỗi dòng có cờ `current` - khách phải biết dòng nào là máy mình đang ngồi;
       • nút gỡ của máy đang dùng bị VÔ HIỆU và reset giữ lại máy đang dùng. Gỡ chính mình =
         tự đăng xuất mà KHÔNG nhả được chỗ (lần đăng nhập sau `upsertDevice` dựng lại dòng).
     ═════════════════════════════════════════════════════════════════════════ */

  // Thoát HTML cho mấy chỗ dùng `html:` - TÊN MÁY do máy khách gửi lên, không phải chuỗi của
  // ta. Thiếu hàm này là một tên máy chứa `<img onerror=...>` chạy được script trong app.
  const esc = (s) => String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');

  // "2 phút trước" / "3 ngày trước". Mốc tuyệt đối không giúp khách nhận ra máy nào là máy
  // nào, còn "4 tháng trước" thì nói ngay đó là máy cũ nên gỡ.
  // ⚠️ PHẢI đi qua tf(), đừng nối chuỗi `m + ' phút trước'`: kết quả là MỘT text node
  // "5 phút trước" mà DICT không có khoá nào khớp ⇒ cột "Lần cuối" đứng nguyên tiếng Việt
  // giữa giao diện ngoại ngữ. tf() tra MẪU rồi mới chèn số, nên mỗi ngôn ngữ tự quyết
  // thứ tự lẫn khoảng trắng (tiếng Trung viết liền "5分钟前", tiếng Việt có dấu cách).
  //
  // Dùng dạng VIẾT TẮT cho en/ru là có chủ ý: "{0} minutes ago" in ra "1 minutes ago",
  // còn tiếng Nga đổi đuôi theo số (1 минута / 2 минуты / 5 минут) mà một mẫu duy nhất
  // không diễn tả được. "min / мин." đúng với mọi con số.
  function dvAgo(ms) {
    if (!ms) return '-';
    const s = Math.max(0, Math.floor((Date.now() - ms) / 1000));
    if (s < 60) return t('vừa xong');
    const m = Math.floor(s / 60); if (m < 60) return tf('{0} phút trước', m);
    const h = Math.floor(m / 60); if (h < 24) return tf('{0} giờ trước', h);
    const d = Math.floor(h / 24); if (d < 30) return tf('{0} ngày trước', d);
    const mo = Math.floor(d / 30); if (mo < 12) return tf('{0} tháng trước', mo);
    return tf('{0} năm trước', Math.floor(mo / 12));
  }

  // Trạng thái tab thiết bị sống ở phạm vi render() chứ KHÔNG phải trong paint(): paint() bị
  // gọi lại mỗi lần nạp bảng giá (loadPricing) và thuê bao (loadSub), mà danh sách máy đã tải
  // + số lượng khách đang gõ không được biến mất theo những lượt vẽ lại đó.
  let dvSnap = null;
  let dvBuyQty = 1;
  let dvBusy = false;     // chặn bấm kép: gỡ/reset/mua đều KHÔNG hoàn tác được
  let dvPaneEl = null;    // pane tab thiết bị của lượt paint() gần nhất
  let dvLoaded = false;   // đã gọi devices:list lần nào chưa

  // Mọi phản hồi của server đều kèm snapshot mới ⇒ nhận luôn, khỏi gọi lại GET.
  const dvTake = (d) => { if (d && Array.isArray(d.devices)) dvSnap = d; dvPaint(); };

  // Bóc vỏ { ok, data, error, code } của remoteCall thành giá trị/ngoại lệ bình thường. Giữ
  // `code` trên ngoại lệ vì UI phản ứng KHÁC NHAU theo mã (INSUFFICIENT_FUNDS mở modal nạp
  // tiền, NO_SUB thì không có gì để nạp, CURRENT_DEVICE là lỗi của chính máy này).
  async function dvUnwrap(p, failMsg) {
    const r = await p;
    if (!r || !r.ok) {
      const e = new Error((r && r.error) || failMsg);
      e.code = (r && r.code) || 'ERROR';
      throw e;
    }
    return r.data;
  }

  async function dvLoad() {
    dvLoaded = true;
    try { dvTake(await dvUnwrap(vt.devices.list(), 'Không tải được danh sách thiết bị')); }
    catch (e) {
      dvSnap = null;
      if (dvPaneEl) {
        clear(dvPaneEl);
        dvPaneEl.appendChild(el('div.dv-empty.dv-err', { text: (e && e.message) || 'Không tải được danh sách thiết bị' }));
      }
    }
  }

  async function dvGuard(fn, failMsg) {
    if (dvBusy) return;
    dvBusy = true; dvPaint();
    try { await fn(); }
    catch (e) { toast((e && e.message) || failMsg, 'err'); }
    finally { dvBusy = false; dvPaint(); }
  }

  // ── Gỡ 1 máy ──
  // Hỏi lại TRƯỚC khi gọi: máy đó bị đăng xuất khỏi app ngay. Nói rõ "được một chỗ" để khách
  // hiểu đây chính là hành động trả chỗ (đăng xuất thì không).
  function dvAskRemove(d) {
    const nm = d.name || 'Máy không tên';
    openModal({
      title: 'Gỡ thiết bị',
      width: 560,
      body: [
        // ⚠️ CẢ CÂU là một mẫu tf(), KHÔNG chắp từ nhiều mảnh.
        // Nối chuỗi kiểu `Gỡ <b>${nm}</b> khỏi tài khoản? ...` xé câu thành ba text node
        // ("Gỡ ", tên máy, " khỏi tài khoản? ...") và DICT chỉ dịch được từng mảnh ⇒ câu
        // tiếng Anh/Nga/Trung đứng sai trật tự từ, vì ngôn ngữ khác KHÔNG đặt tên máy ở
        // giữa đúng chỗ đó. Một mẫu trọn câu thì mỗi ngôn ngữ tự chọn vị trí của {0}.
        el('div.ap-fund-note', { html: tf('Gỡ <b>{0}</b> khỏi tài khoản? Máy này sẽ bị đăng xuất khỏi ứng dụng ngay, và bạn được lại <b>một chỗ thiết bị</b> để đăng nhập máy khác.', esc(nm)) }),
        d.online ? el('div.dv-warn', { text: 'Máy này ĐANG đăng nhập. Nếu đang chạy hồ sơ hoặc quy trình, công việc đó sẽ dừng.' }) : null,
        el('div.dv-note-sm', { text: 'Lần sau đăng nhập lại trên chính máy này vẫn được, miễn là còn chỗ trống.' }),
      ],
      footer: [
        el('button.btn', { text: 'Hủy', onclick: closeModal }),
        el('button.btn.danger', { text: 'Gỡ thiết bị', onclick: () => {
          closeModal();
          dvGuard(async () => {
            dvTake(await dvUnwrap(vt.devices.remove(d.id), 'Gỡ thiết bị thất bại'));
            toast(tf('Đã gỡ {0}. Bạn có thêm một chỗ thiết bị.', nm), 'ok');
          }, 'Gỡ thiết bị thất bại');
        } }),
      ],
    });
  }

  // ── Reset: gỡ mọi máy KHÁC ──
  // Phá hơn nút gỡ từng máy nên modal phải nói ra đúng con số sẽ mất. KHÁC landing: máy đang
  // ngồi được GIỮ LẠI, nên câu chữ phải nói "các máy khác" chứ không phải "toàn bộ" - hứa sai
  // là khách tưởng mình vừa dọn sạch rồi vẫn thấy một dòng còn đó.
  function dvAskReset() {
    const all = dvSnap ? dvSnap.devices : [];
    const others = all.filter((d) => !d.current);
    if (!others.length) { toast('Không có máy nào khác để reset', ''); return; }
    const hasCur = all.length !== others.length;
    openModal({
      title: 'Reset thiết bị',
      width: 560,
      body: [
        // Trọn câu trong MỘT mẫu tf() - xem ghi chú ở dvAskRemove.
        el('div.ap-fund-note', { html: tf('Gỡ <b>{0} thiết bị khác</b> khỏi tài khoản và trả lại chỗ của chúng?', others.length) }),
        el('div.dv-warn', { text: 'Mọi máy đó sẽ bị đăng xuất khỏi ứng dụng ngay. Công việc đang chạy trên các máy đó sẽ dừng.' }),
        // Nhánh "Gỡ sạch mọi máy một lượt..." đã BỎ (người dùng chốt 2026-10-01) - đừng thêm
        // lại. Khi không có máy hiện tại trong danh sách thì KHÔNG in dòng nào, chứ đừng in
        // chuỗi rỗng: `.dv-note-sm` có lề trên nên thẻ trống vẫn đội modal cao thêm.
        hasCur
          ? el('div.dv-note-sm', { text: 'Máy bạn đang dùng được giữ lại - bạn không bị đăng xuất khỏi ứng dụng này.' })
          : null,
      ].filter(Boolean),
      footer: [
        el('button.btn', { text: 'Hủy', onclick: closeModal }),
        el('button.btn.danger', { text: 'Reset thiết bị', onclick: () => {
          closeModal();
          dvGuard(async () => {
            const d = await dvUnwrap(vt.devices.reset(), 'Reset thiết bị thất bại');
            dvTake(d);
            toast(tf('Đã gỡ {0} thiết bị, trả lại chỗ của chúng.', d.removed), 'ok');
          }, 'Reset thiết bị thất bại');
        } }),
      ],
    });
  }

  // ── Mua thêm chỗ ⇒ trang "Thủ tục thanh toán" (Số dư / VietQR / PayPal / thẻ). Server vẫn tính lại giá + kiểm số dư ở
  // POST /devices/purchase khi khách bấm thanh toán; chưa có giá (unit 0) thì nút bị khoá và server cũng từ chối.
  function dvOnBuy() {
    if (dvBusy || !dvSnap || dvSnap.lifetime || !(Number(dvSnap.unit) > 0)) return;
    const qty = Math.max(1, Math.min(dvSnap.maxBuy || 1, Math.trunc(dvBuyQty) || 1));
    saveOrder({ kind: 'devices', qty });
    ctx.navigate('checkout');
  }

  // ── Panel TRÁI (70%): datagrid máy đã đăng nhập ──
  function dvGridPanel() {
    const rows = (dvSnap.devices || []).map((d) => el('tr' + (d.online ? '.dv-on' : '') + (d.current ? '.dv-cur' : ''), {}, [
      el('td.dv-c-name', {}, [
        el('span.dv-mon', { html: icon('monitor') }),
        el('span.dv-nm', {}, [
          el('span.dv-nm-main', {}, [
            document.createTextNode(d.name || 'Máy không tên'),
            d.current ? el('span.dv-you', { text: 'máy này' }) : null,
          ]),
          el('span.dv-nm-sub', { text: [d.os, d.lastIp].filter(Boolean).join(' · ') || 'không rõ hệ điều hành' }),
        ]),
      ]),
      // Máy đã đăng xuất là 'amber' chứ KHÔNG phải xám: xám đọc như "không sao cả", mà thực
      // tế đó là một chỗ đang bị giữ và chính là lý do khách không thêm được máy nào.
      el('td.dv-c-st', {}, [d.online
        ? el('span.dv-badge.on', { text: 'Đã đăng nhập' })
        : el('span.dv-badge.off', { text: 'đã đăng xuất' })]),
      el('td.dv-c-seen', { text: dvAgo(d.lastSeenAt) }),
      el('td.dv-c-act', {}, [
        el('button.dv-del', {
          html: icon('trash'),
          // Máy đang dùng: VÔ HIỆU + nói rõ lý do ngay trên tooltip. Để bấm được thì khách tự
          // đăng xuất mình mà chỗ vẫn bị giữ (lần đăng nhập sau dựng lại dòng) - vừa mất phiên
          // vừa không được gì, nên chặn ở đây và chỉ sang web.
          title: d.current
            ? 'Không thể gỡ máy đang dùng. Hãy gỡ máy này từ trang quản lý trên cgtdev.space.'
            // Đuôi "- trả lại một chỗ" đã BỎ (người dùng chốt 2026-10-01) - đừng thêm lại.
            : 'Gỡ thiết bị này',
          'aria-label': 'Gỡ thiết bị',
          disabled: (dvBusy || d.current) ? 'disabled' : null,
          onclick: () => dvAskRemove(d),
        }),
      ]),
    ]));

    return el('div.dv-left', {}, [
      // Chỉ còn tiêu đề: dòng phụ giải thích luật chiếm chỗ đã BỊ BỎ (người dùng chốt
      // 2026-10-01) - đừng thêm lại. Giữ `.dv-head` dù chỉ có một con: lề/đường kẻ dưới của
      // bảng đang ăn theo nó.
      el('div.dv-head', {}, [
        el('div.dv-h-title', { text: 'Thiết bị đã đăng nhập' }),
      ]),
      rows.length
        ? el('div.dv-grid-wrap', {}, [el('table.dv-grid', {}, [
          el('thead', {}, [el('tr', {}, [
            el('th', { text: 'Thiết bị' }),
            el('th', { text: 'Trạng thái' }),
            el('th', { text: 'Lần cuối' }),
            el('th'),
          ])]),
          el('tbody', {}, rows),
        ])])
        : el('div.dv-empty', { text: 'Chưa có máy nào đăng nhập tài khoản này.' }),
    ]);
  }

  // ── Panel PHẢI (30%): reset + numberrich + mua ──
  function dvSidePanel() {
    const unit = Number(dvSnap.unit) || 0;
    const used = Number(dvSnap.used) || 0;
    const limit = Number(dvSnap.limit) || 0;    // 0 = VÔ HẠN (quy ước toàn hệ thống)
    const unlimited = limit === 0;
    const full = !unlimited && used >= limit;
    const others = (dvSnap.devices || []).filter((d) => !d.current).length;

    // numberrich "số lượng thiết bị": ô số + hai nút -/+, cùng khuôn stepper của trang gói.
    const qtyInput = el('input.dv-step-input', { type: 'text', value: String(dvBuyQty), disabled: dvBusy ? 'disabled' : null });
    const costEl = el('b.dv-cost', { text: fmtVnd(dvBuyQty * unit) });
    const commit = (v) => {
      const n = Math.max(1, Math.min(dvSnap.maxBuy, Math.trunc(Number(v)) || 1));
      dvBuyQty = n;
      qtyInput.value = String(n);
      costEl.textContent = fmtVnd(n * unit);
    };
    qtyInput.addEventListener('change', () => commit(qtyInput.value));
    // Chỉ cho gõ số: dán chữ vào rồi bấm mua thì Math.trunc ra NaN và im lặng tụt về 1.
    qtyInput.addEventListener('input', () => { qtyInput.value = qtyInput.value.replace(/[^\d]/g, ''); });

    return el('div.dv-side', {}, [
      // Thẻ số: CHỖ ĐÃ DÙNG / GIỚI HẠN. Tách rõ "của gói" và "đã mua" - khách bỏ tiền ra thì
      // phải thấy phần tiền của mình trong con số, không thì tưởng mua xong không có gì.
      el('div.dv-stat' + (full ? '.full' : ''), {}, [
        el('div.dv-stat-k', { text: 'Thiết bị đã dùng' }),
        el('div.dv-stat-v', {}, [
          el('b', { text: String(used) }),
          el('span', { text: ' / ' + (unlimited ? t('không giới hạn') : String(limit)) }),
        ]),
        // Dòng phụ "{0} chỗ của {1}" (số chỗ của gói Pro...) đã BỎ (user chốt 2026-10-03).
        // Giữ lại CHỈ dòng báo gói vô hạn - đó là thông tin khác, không phải label bị bỏ.
        unlimited
          ? el('div.dv-stat-sub', { text: 'Gói của bạn không giới hạn số thiết bị.' })
          : null,
        full ? el('div.dv-stat-warn', { text: dvSnap.lifetime ? 'Đã hết chỗ. Gỡ một máy cũ để đăng nhập máy mới.' : 'Đã hết chỗ. Gỡ một máy cũ hoặc mua thêm thiết bị để đăng nhập máy mới.' }) : null,
      ]),

      el('button.btn.dv-reset', {
        html: icon('refresh') + '<span>Reset thiết bị</span>',
        title: 'Gỡ mọi máy khác và trả lại chỗ của chúng',
        disabled: (dvBusy || !others) ? 'disabled' : null,
        onclick: dvAskReset,
      }),
      // (Dòng chú thích dưới nút Reset đã BỎ - người dùng chốt 2026-10-01. Đừng thêm lại.)

      el('div.dv-sep'),

      // GÓI VĨNH VIỄN: không bán thêm thiết bị (server trả LIFETIME_NO_DEVICES) ⇒ thay khối mua bằng một dòng báo.
      dvSnap.lifetime ? el('div.dv-buy', {}, [
        el('div.dv-buy-k', { text: 'Mua thêm thiết bị' }),
        el('div.dv-buy-unit', { text: 'Gói vĩnh viễn không hỗ trợ mua thêm thiết bị.' }),
      ]) : el('div.dv-buy', {}, [
        el('div.dv-buy-k', { text: 'Mua thêm thiết bị' }),
        // Đuôi " · phí một lần" đã BỎ (người dùng chốt 2026-10-01) - chỉ còn đơn giá. Khoá dịch
        // cũng phải đổi theo, không thì tf() không tra được và tiếng Anh/Nga/Trung rơi về chuỗi
        // thô có đuôi tiếng Việt.
        el('div.dv-buy-unit', { text: unit > 0 ? tf('{0} / thiết bị', fmtVnd(unit)) : 'Chưa có giá - vui lòng liên hệ hỗ trợ' }),
        el('div.dv-stepper', {}, [
          el('button.dv-step-btn', { text: '\u2212', disabled: dvBusy ? 'disabled' : null, onclick: () => commit(dvBuyQty - 1) }),
          qtyInput,
          el('button.dv-step-btn', { text: '+', disabled: dvBusy ? 'disabled' : null, onclick: () => commit(dvBuyQty + 1) }),
        ]),
        el('div.dv-buy-total', {}, [el('span', { text: 'Thành tiền' }), costEl]),
        el('button.btn.primary.dv-buy-btn', {
          html: icon('walletCard') + '<span>Mua thiết bị</span>',
          // unit = 0 thì chặn: để bấm được là khách mua 0đ, tức là tặng chỗ không giới hạn mỗi
          // khi admin quên đặt giá.
          disabled: (dvBusy || unit <= 0) ? 'disabled' : null,
          onclick: dvOnBuy,
        }),
        // (Dòng chú thích dưới nút Mua đã BỎ - người dùng chốt 2026-10-01. Đừng thêm lại.)
      ]),
    ]);
  }

  function dvPaint() {
    if (!dvPaneEl) return;
    clear(dvPaneEl);
    if (!dvSnap) { dvPaneEl.appendChild(el('div.dv-empty', { text: 'Đang tải thiết bị…' })); return; }
    dvPaneEl.appendChild(el('div.dv-cols' + (dvBusy ? '.busy' : ''), {}, [dvGridPanel(), dvSidePanel()]));
  }


  // Khung trang: cùng khung viền lớn với trang gói, pane thiết bị chiếm trọn.
  const pane = el('div.dash-pane.dash-pane-dv');
  host.appendChild(el('div.ap-wrap', {}, [el('div.px-card.ap-card', {}, [pane])]));
  dvPaneEl = pane;
  dvPaint();
  dvLoad();

  return {
    // Quay lại trang: nạp lại danh sách máy (khách có thể vừa đăng nhập/đăng xuất một máy ở chỗ khác).
    onShow: () => { dvLoad(); },
  };
}
