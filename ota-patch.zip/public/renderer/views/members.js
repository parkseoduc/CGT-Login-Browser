// "Thành viên nhóm" - group-members page, cloned 1:1 from MKTLogin 2.1.2.
// Left rail lists member GROUPS (+ "Thêm" to create); the right side has a search
// bar, three tabs (Thành viên / Đã mời / Quyền truy cập), a "Làm mới" +
// "Mời thành viên" action row, and either a members/invites datagrid or the
// permission matrix. Create/edit groups use the two-panel "Tạo nhóm thành viên"
// permission picker; inviting uses the "Mời thành viên" dialog.
//
// DATA = SERVER (remote.team.*): member GROUPS are permission bundles; MEMBERS and
// INVITES are workspace-scoped, each carrying member_group_id → the view filters
// them by the selected group. Mutations (create/invite/delete) are enforced
// server-side by permission; the UI hides manage controls when the current user
// lacks the "quản lý thành viên" capability (owner/admin base role or team_role
// admin/manager). PERMISSION_CATEGORIES/MEMBER_ROLES labels come from the local
// catalog metadata (members-store.js) - the server only stores flat keys.
import { el, clear, toast, openModal, closeModal, confirmDialog, customSelect, pageSizeSelect, hoverMenu, gridEmpty, noDataSvg, noMemberSvg, iconBtn } from '../ui.js';
import { icon } from '../icons.js';
import { remote } from '../data/remote-ds.js';
import { PERMISSION_CATEGORIES, MEMBER_ROLES, roleLabel } from '../data/members-store.js';
import { loadPermissions, canManageMembers } from '../data/team-permissions.js';
import { notifyError } from '../data/errors.js';
import { tf } from '../i18n.js';

function fmtDate(v) {
  if (!v) return '-';
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return String(v);
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}

// Hết ghế thành viên của gói (MEMBER_QUOTA_EXCEEDED) KHÔNG phải lỗi quyền → modal kèm
// gif dấu X (đồng bộ style với modal thiếu số dư), không toast nhầm "thiếu quyền hạn".
function showMemberQuotaModal(message) {
  const body = [
    el('div.ap-fail-anim', { html: '<svg class="ap-fail-svg" viewBox="0 0 52 52"><circle class="ap-fail-circle" cx="26" cy="26" r="24"/><path class="ap-fail-x" d="M18 18 L34 34 M34 18 L18 34"/></svg>' }),
    el('div.ap-fund-note.ap-fail-note', { text: 'Bạn đã hết số dư thành viên. Vui lòng nâng cấp gói để mời thêm thành viên mới.' }),
  ];
  const footer = [el('button.btn.primary', { text: 'Đã hiểu', onclick: closeModal })];
  openModal({ title: 'Vượt hạn mức thành viên', body, footer, width: 560 });
}

// Flat "cat:perm" key helpers
const pkey = (cat, perm) => `${cat}:${perm}`;

// Empty-state illustration for the group rail - a small "team" of three people
// (center figure + two faded side figures), tinted with the brand colour via
// currentColor. Conveys "member group" rather than a generic no-data box.
const membersEmptySvg = `<svg viewBox="0 0 160 120" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
  <ellipse cx="80" cy="106" rx="54" ry="7" fill="currentColor" opacity="0.08"/>
  <g opacity="0.38">
    <circle cx="40" cy="54" r="12" fill="currentColor"/>
    <path d="M22 90c0-9.9 8.1-18 18-18s18 8.1 18 18z" fill="currentColor"/>
  </g>
  <g opacity="0.38">
    <circle cx="120" cy="54" r="12" fill="currentColor"/>
    <path d="M102 90c0-9.9 8.1-18 18-18s18 8.1 18 18z" fill="currentColor"/>
  </g>
  <circle cx="80" cy="46" r="17" fill="currentColor"/>
  <path d="M53 98c0-14.9 12.1-27 27-27s27 12.1 27 27z" fill="currentColor"/>
</svg>`;

export function render(ctx) {
  let groups = [];      // member groups (permission bundles) from server
  let members = [];     // all workspace members (filtered by group in the grid)
  let invites = [];     // pending invites (filtered by group in the grid)
  let selectedId = null;
  let tab = 'members'; // 'members' | 'invited' | 'access'
  let search = '';
  let page = 0;
  let pageSize = 50;
  let profileGroups = []; // for the "Nhóm hồ sơ chia sẻ" dropdown (legacy group model)
  let workspaceProfiles = []; // danh sách hồ sơ của workspace (chọn chia sẻ theo tên)
  let loadErr = null;

  // Load the workspace's profile groups + profiles (used by the invite dialog).
  // Đổ lại mỗi lần load() (đổi workspace) qua reloadShareSources() bên dưới.
  function reloadShareSources() {
    remote.groups.list().then((gs) => { profileGroups = Array.isArray(gs) ? gs : []; }).catch(() => { profileGroups = []; });
    remote.profiles.list().then((ps) => { workspaceProfiles = Array.isArray(ps) ? ps : []; }).catch(() => { workspaceProfiles = []; });
  }
  reloadShareSources();

  const sideList = el('div.mem-side-list');
  const mainArea = el('div.mem-body');

  const manage = () => canManageMembers();

  function selGroup() { return selectedId ? groups.find((g) => g.id === selectedId) || null : null; }
  function groupMembers(g) { return g ? members.filter((m) => m.memberGroupId === g.id) : []; }
  function groupInvites(g) { return g ? invites.filter((i) => i.memberGroupId === g.id) : []; }

  // Fetch groups + members + pending invites together, then paint.
  async function load() {
    reloadShareSources();
    try {
      const [gs, ms, invs] = await Promise.all([
        remote.team.groups.list(),
        remote.team.members.list(),
        remote.team.invites.list('pending'),
      ]);
      groups = Array.isArray(gs) ? gs : [];
      members = Array.isArray(ms) ? ms : [];
      invites = Array.isArray(invs) ? invs : [];
      loadErr = null;
    } catch (e) {
      groups = []; members = []; invites = [];
      loadErr = e;
    }
    if (!groups.find((g) => g.id === selectedId)) selectedId = groups.length ? groups[0].id : null;
    syncManageUi();
    renderSide();
    renderMain();
  }

  // ----------------------------------------------------- left rail (groups)
  function renderSide() {
    clear(sideList);
    if (loadErr) {
      sideList.appendChild(el('div.mem-side-empty', {}, [
        el('div.mem-empty-ico', { html: membersEmptySvg }),
        el('p.mem-empty-text', { text: 'Không tải được dữ liệu (cần đăng nhập máy chủ)' }),
      ]));
      return;
    }
    if (!groups.length) {
      sideList.appendChild(el('div.mem-side-empty', {}, [
        el('div.mem-empty-ico', { html: membersEmptySvg }),
        el('p.mem-empty-text', { text: 'Chưa có nhóm thành viên nào' }),
      ]));
      return;
    }
    groups.forEach((g) => {
      const kebab = el('button.icon-btn.mem-group-more', { html: icon('moreVertical'), title: 'Thao tác' });
      hoverMenu(kebab, () => [
        { label: 'Chỉnh sửa', icon: 'edit', onClick: () => groupModal(g) },
        { label: 'Xóa', icon: 'trash', danger: true, onClick: () => delGroupModal(g) },
      ]);
      const row = el('div.mem-group-row' + (g.id === selectedId ? '.active' : ''), {
        onclick: (e) => { if (e.target.closest('.mem-group-more')) return; selectedId = g.id; page = 0; renderSide(); renderMain(); },
      }, [
        el('span.mem-group-name', { text: g.name || '(không tên)' }),
        ...(manage() ? [kebab] : []),
      ]);
      sideList.appendChild(row);
    });
  }

  // ----------------------------------------------------- right main
  function renderMain() {
    clear(mainArea);
    const g = selGroup();
    const canManage = manage();

    // Invite button now lives to the LEFT of the search box (its own row).
    const inviteBtn = el('button.btn.primary.mem-invite' + (g && canManage ? '' : '.disabled'), {
      html: `${icon('plus')}<span>Mời thành viên</span>`,
      onclick: () => { if (g && canManage) inviteModal(g); } });
    if (!g || !canManage) inviteBtn.disabled = true;

    const searchBar = el('div.searchbar.mem-search', {}, [
      el('span.ico', { html: icon('search') }),
      el('input.search-input', { placeholder: 'Tìm kiếm...', value: search,
        oninput: (e) => { search = e.target.value.trim(); page = 0; renderBody(); } }),
    ]);
    // Bộ chọn "Không gian làm việc" nay ở HEADER chung (app.js) - không còn ở đây.
    const searchRow = el('div.mem-searchrow', {}, [...(canManage ? [inviteBtn] : []), searchBar]);

    const mkTab = (key, label) => el('button.mem-tab' + (tab === key ? '.active' : ''), {
      text: label, onclick: () => { tab = key; page = 0; renderMain(); },
    });

    const refreshBtn = el('button.btn.ghost.mem-refresh', { html: `${icon('sync')}<span>Làm mới</span>`,
      onclick: () => { load().then(() => toast('Đã làm mới', 'ok')).catch((e) => notifyError(e, 'Làm mới thất bại')); } });

    const bar = el('div.mem-bar', {}, [
      el('div.mem-tabs', {}, [mkTab('members', 'Thành viên'), mkTab('invited', 'Đã mời'), mkTab('access', 'Quyền truy cập')]),
      el('div.mem-bar-right', {}, [refreshBtn]),
    ]);

    const body = el('div.mem-tabbody');
    mainArea.appendChild(el('div.mem-main-inner', {}, [searchRow, bar, body]));

    function renderBody() {
      clear(body);
      if (tab === 'access') { body.appendChild(renderAccess(g)); return; }
      body.appendChild(renderTable(g));
    }
    // expose for search/pager to re-render just the body
    renderMain._body = body;
    renderMain._renderBody = renderBody;
    renderBody();
  }

  function renderBody() { if (renderMain._renderBody) renderMain._renderBody(); }

  // ----------------------------------------------------- members / invited grids
  function renderTable(g) {
    const invited = tab === 'invited';
    const rowsAll = g ? (invited ? groupInvites(g) : groupMembers(g)) : [];
    const q = search.toLowerCase();
    const filtered = rowsAll.filter((r) => !q
      || String(r.name || '').toLowerCase().includes(q)
      || String(r.email || '').toLowerCase().includes(q));

    const pages = Math.max(1, Math.ceil(filtered.length / pageSize));
    if (page >= pages) page = pages - 1;
    const slice = filtered.slice(page * pageSize, page * pageSize + pageSize);

    const head = invited
      ? ['Tên', 'Email', 'Ngày mời', 'Quyền hạn', 'Ghi chú', 'Hành động']
      : ['Tên', 'Email', 'Quyền hạn', 'Ghi chú', 'Hành động'];

    const tbody = el('tbody');
    const empty = gridEmpty(invited ? 'Chưa có lời mời nào' : 'Chưa có thành viên nào', noMemberSvg);
    empty.style.display = slice.length ? 'none' : '';

    const canManage = manage();
    slice.forEach((r) => {
      // Luôn hiện icon 3 chấm. Không đủ quyền (vd vai trò "nhân viên") → khóa
      // (mờ + not-allowed), không mở menu, hover hiện tooltip báo thiếu quyền.
      const kebab = el('button.icon-btn' + (canManage ? '' : '.is-locked'), {
        html: icon('moreVertical'),
        title: canManage ? 'Thao tác' : 'Bạn không đủ quyền thực hiện',
      });
      if (canManage) hoverMenu(kebab, () => [
        ...(invited ? [] : [
          { label: 'Chỉnh sửa', icon: 'edit', onClick: () => editMemberModal(r, g) },
        ]),
        { label: invited ? 'Thu hồi' : 'Xóa', icon: 'trash', danger: true, onClick: () => {
          if (invited) revokeInvite(r); else deleteMember(r);
        } },
      ]);
      const actionCell = [kebab];
      const cells = invited
        ? [
            el('td', { text: r.name || '-' }),
            el('td', { text: r.email || '-' }),
            el('td.muted', { text: fmtDate(r.invitedAt) }),
            el('td', {}, [el('span.mem-role-pill', { text: roleLabel(r.teamRole) })]),
            el('td.muted', { text: r.note || '-' }),
            el('td.col-action', {}, actionCell),
          ]
        : [
            el('td', { text: r.name || '-' }),
            el('td', { text: r.email || '-' }),
            el('td', {}, [el('span.mem-role-pill', { text: roleLabel(r.teamRole) })]),
            el('td.muted', { text: r.note || '-' }),
            el('td.col-action', {}, actionCell),
          ];
      tbody.appendChild(el('tr', {}, cells));
    });

    const table = el('table.grid.mem-grid', {}, [
      el('thead', {}, [el('tr', {}, head.map((h, i) => el('th' + (i === head.length - 1 ? '.col-action' : ''), { text: h })))]),
      tbody,
    ]);

    // pager
    const sizeSel = pageSizeSelect([10, 25, 50, 100], { value: pageSize, onChange: (v) => { pageSize = v; page = 0; renderBody(); } });
    const from = filtered.length ? page * pageSize + 1 : 0;
    const to = Math.min(filtered.length, (page + 1) * pageSize);
    const pager = el('div.pager.mem-pager', {}, [
      el('span.muted', { text: 'Số dòng mỗi trang:' }),
      sizeSel,
      el('span.muted.mem-pg-count', { text: tf('{0}-{1} trên {2}', from, to, filtered.length) }),
      iconBtn('chevron', { style: { transform: 'rotate(180deg)' }, title: 'Trước',
        onclick: () => { if (page > 0) { page--; renderBody(); } } }),
      iconBtn('chevron', { title: 'Sau',
        onclick: () => { if (page < pages - 1) { page++; renderBody(); } } }),
    ]);

    return el('div.mem-grid-wrap', {}, [
      el('div.grid-card.mem-grid-card', {}, [table, empty]),
      pager,
    ]);
  }

  // ----------------------------------------------------- Quyền truy cập matrix
  function renderAccess(g) {
    if (!g) {
      // gridEmpty() defaults to display:none; this prompt is shown unconditionally.
      const ae = gridEmpty('Chọn một nhóm thành viên để xem quyền truy cập', noDataSvg);
      ae.style.display = 'flex';
      return el('div.mem-access-empty', {}, [ae]);
    }
    const readOnly = !manage();
    const perms = new Set(g.permissions || []);
    const grid = el('div.mem-access');

    PERMISSION_CATEGORIES.forEach((cat) => {
      const childCbs = [];
      const catCb = el('input', { type: 'checkbox', disabled: readOnly });
      const syncCat = () => {
        const on = cat.perms.filter((p) => perms.has(pkey(cat.key, p.key))).length;
        catCb.checked = on === cat.perms.length && on > 0;
        catCb.indeterminate = on > 0 && on < cat.perms.length;
      };
      catCb.onchange = () => {
        cat.perms.forEach((p) => { const k = pkey(cat.key, p.key); catCb.checked ? perms.add(k) : perms.delete(k); });
        childCbs.forEach((cb) => { cb.checked = catCb.checked; });
        syncCat();
      };

      const permsWrap = el('div.mem-access-perms');
      cat.perms.forEach((p) => {
        const k = pkey(cat.key, p.key);
        const cb = el('input', { type: 'checkbox', checked: perms.has(k), disabled: readOnly,
          onchange: (e) => { e.target.checked ? perms.add(k) : perms.delete(k); syncCat(); } });
        childCbs.push(cb);
        permsWrap.appendChild(el('label.mem-perm', {}, [cb, el('span', { text: p.label })]));
      });
      syncCat();

      grid.appendChild(el('div.mem-access-row', {}, [
        el('label.mem-access-cat', {}, [catCb, el('span', { text: cat.label })]),
        permsWrap,
      ]));
    });

    const foot = [];
    if (!readOnly) {
      const saveBtn = el('button.btn.primary.mem-access-save', { text: 'Lưu',
        onclick: async () => {
          try {
            await remote.team.groups.update(g.id, { permissions: [...perms] });
            await load();
            toast('Đã lưu quyền truy cập', 'ok');
          } catch (e) { notifyError(e, 'Lưu quyền truy cập thất bại'); }
        } });
      foot.push(saveBtn);
    }

    return el('div.mem-access-wrap', {}, [grid, el('div.mem-access-foot', {}, foot)]);
  }

  // ----------------------------------------------------- create / edit group
  // Two-panel permission picker: LEFT category list (checkbox + chevron, active
  // highlight), RIGHT the active category's permission checkboxes.
  function groupModal(g) {
    const isEdit = !!g;
    const perms = new Set(isEdit ? (g.permissions || []) : []);
    let activeCat = PERMISSION_CATEGORIES[0].key;
    let nameInput, noteInput;

    const catList = el('div.mem-pk-cats');
    const permPanel = el('div.mem-pk-perms');

    const renderCats = () => {
      clear(catList);
      PERMISSION_CATEGORIES.forEach((cat) => {
        const cb = el('input', { type: 'checkbox' });
        const on = cat.perms.filter((p) => perms.has(pkey(cat.key, p.key))).length;
        cb.checked = on === cat.perms.length && on > 0;
        cb.indeterminate = on > 0 && on < cat.perms.length;
        cb.onclick = (e) => e.stopPropagation();
        cb.onchange = () => { cat.perms.forEach((p) => { const k = pkey(cat.key, p.key); cb.checked ? perms.add(k) : perms.delete(k); }); if (activeCat === cat.key) renderPerms(); renderCats(); };
        const row = el('div.mem-pk-cat' + (cat.key === activeCat ? '.active' : ''), {
          onclick: () => { activeCat = cat.key; renderCats(); renderPerms(); },
        }, [cb, el('span.mem-pk-cat-label', { text: cat.label }), el('span.mem-pk-chev', { html: icon('chevron') })]);
        catList.appendChild(row);
      });
    };
    const renderPerms = () => {
      clear(permPanel);
      const cat = PERMISSION_CATEGORIES.find((c) => c.key === activeCat);
      cat.perms.forEach((p) => {
        const k = pkey(cat.key, p.key);
        const cb = el('input', { type: 'checkbox', checked: perms.has(k),
          onchange: (e) => { e.target.checked ? perms.add(k) : perms.delete(k); renderCats(); } });
        permPanel.appendChild(el('label.mem-perm', {}, [cb, el('span', { text: p.label })]));
      });
    };
    renderCats(); renderPerms();

    const save = async () => {
      const n = nameInput.value.trim();
      if (!n) { nameInput.focus(); return; }
      const payload = { name: n, note: noteInput.value.trim(), permissions: [...perms] };
      try {
        if (isEdit) {
          await remote.team.groups.update(g.id, payload);
        } else {
          const ng = await remote.team.groups.create(payload);
          if (ng && ng.id) selectedId = ng.id;
        }
        closeModal();
        await load();
        toast(isEdit ? 'Đã lưu nhóm thành viên' : 'Thêm thành công!', 'ok');
      } catch (e) { notifyError(e, isEdit ? 'Lưu nhóm thành viên thất bại' : 'Tạo nhóm thành viên thất bại'); }
    };

    openModal({
      title: isEdit ? 'Chỉnh sửa nhóm thành viên' : 'Tạo nhóm thành viên',
      width: 900,
      body: [el('div.mem-form', {}, [
        el('div.mem-form-row', {}, [
          el('label.mem-form-label', { text: 'Tên' }),
          (nameInput = el('input.input', { value: isEdit ? g.name : '', placeholder: 'Nhập tên nhóm' })),
        ]),
        el('div.mem-form-row', {}, [
          el('label.mem-form-label', { text: 'Ghi chú' }),
          (noteInput = el('textarea.input.mem-textarea', { rows: 3, placeholder: 'Giới thiệu nhóm' }, isEdit ? (g.note || '') : '')),
        ]),
        el('div.mem-form-row.mem-form-row-top', {}, [
          el('label.mem-form-label', { text: 'Cấp phép' }),
          el('div.mem-pk', {}, [
            el('p.mem-pk-desc', { text: 'Vui lòng cấp quyền cho các chức năng cho nhóm thành viên. Thành viên cùng một nhóm có quyền truy cập vào các chức năng giống nhau.' }),
            el('div.mem-pk-panels', {}, [catList, permPanel]),
          ]),
        ]),
      ])],
      footer: [
        el('button.grp-cancel', { text: 'Hủy', onclick: closeModal }),
        el('button.btn.primary', { text: isEdit ? 'Lưu' : 'Tạo', onclick: save }),
      ],
    });
    setTimeout(() => nameInput && nameInput.focus(), 30);
  }

  // ----------------------------------------------------- delete group confirm
  function delGroupModal(g) {
    openModal({
      title: 'Xóa nhóm thành viên',
      width: 460,
      body: [el('div.mem-del', {}, [el('p', { text: tf('Xóa {0}?', g.name) })])],
      footer: [
        el('button.grp-cancel', { text: 'Đóng', onclick: closeModal }),
        el('button.btn.solid-red', { text: 'Xóa', onclick: async () => {
          try {
            await remote.team.groups.remove(g.id);
            if (selectedId === g.id) selectedId = null;
            closeModal(); await load(); toast('Đã xóa nhóm thành viên', 'ok');
          } catch (e) { notifyError(e, 'Xóa nhóm thành viên thất bại'); }
        } }),
      ],
    });
  }

  // ----------------------------------------------------- member / invite delete
  function deleteMember(r) {
    confirmDialog({
      title: 'Xóa thành viên',
      danger: true,
      confirmLabel: 'Xóa',
      message: tf('Bạn có chắc muốn xóa thành viên "{0}" khỏi nhóm?', r.name || r.email || ''),
      onConfirm: async () => {
        try { await remote.team.members.remove(r.id); await load(); toast('Đã xóa thành viên', 'ok'); }
        catch (e) { notifyError(e, 'Xóa thành viên thất bại'); }
      },
    });
  }
  async function revokeInvite(r) {
    try { await remote.team.invites.revoke(r.id); await load(); toast('Đã thu hồi lời mời', 'ok'); }
    catch (e) { notifyError(e, 'Thu hồi lời mời thất bại'); }
  }

  // ----------------------------------------------------- invite member
  function inviteModal(g) {
    let nameInput, emailInput, limitInput, noteInput;
    let role = 'member';
    const shared = new Set();

    const roleDesc = el('p.mem-role-desc', { text: MEMBER_ROLES.find((r) => r.key === role).desc });
    const roleRow = el('div.mem-roles', {}, MEMBER_ROLES.map((r) => {
      const radio = el('input', { type: 'radio', name: 'mem-role', checked: r.key === role,
        onchange: () => { role = r.key; roleDesc.textContent = r.desc; } });
      return el('label.mem-role', {}, [radio, el('span', { text: r.label })]);
    }));

    // "Hồ sơ chia sẻ" - chọn Tất cả / Chưa chia nhóm / từng hồ sơ theo tên.
    const sharedField = buildSharedPicker(workspaceProfiles, shared);

    const save = async () => {
      const email = emailInput.value.trim();
      if (!email) { emailInput.focus(); return; }
      // Chống spam: chặn ngay tại client nếu email đã được mời (đang chờ) hoặc đã là
      // thành viên trong workspace - không cần round-trip. Server vẫn chặn (INVITE_EXISTS)
      // như lớp bảo vệ cuối. So khớp không phân biệt hoa/thường.
      const emailLc = email.toLowerCase();
      if (invites.some((i) => (i.email || '').toLowerCase() === emailLc)) {
        toast('Email này đã được mời và đang chờ chấp nhận', 'error'); return;
      }
      if (members.some((m) => (m.email || '').toLowerCase() === emailLc)) {
        toast('Email này đã là thành viên trong nhóm', 'error'); return;
      }
      const { shareAll, shareUngrouped, sharedProfileIds } = expandShared(shared);
      try {
        await remote.team.invites.create({
          memberGroupId: g.id,
          name: nameInput.value.trim(), email, teamRole: role,
          sharedGroupIds: [], shareAll, shareUngrouped, sharedProfileIds,
          balanceLimit: limitInput.value.trim(), note: noteInput.value.trim(),
        });
        closeModal();
        tab = 'invited';
        await load();
        showInviteSent(email);
      } catch (e) {
        // Hết ghế thành viên của gói KHÔNG phải lỗi quyền → modal kèm gif báo, không toast "thiếu quyền".
        if (e && e.code === 'MEMBER_QUOTA_EXCEEDED') showMemberQuotaModal(e.message || e.error);
        else notifyError(e, 'Mời thành viên thất bại');
      }
    };

    openModal({
      title: 'Mời thành viên',
      width: 780,
      body: [el('div.mem-form', {}, [
        el('div.mem-form-row', {}, [el('label.mem-form-label', { text: 'Tên nhóm' }), el('div.mem-form-static', { text: g.name || '-' })]),
        el('div.mem-form-row', {}, [el('label.mem-form-label', { text: 'Tên' }), (nameInput = el('input.input', { placeholder: 'Nhập tên thành viên' }))]),
        el('div.mem-form-row', {}, [el('label.mem-form-label', { text: 'Email' }), (emailInput = el('input.input', { placeholder: 'Nhập email thành viên' }))]),
        el('div.mem-form-row.mem-form-row-top', {}, [el('label.mem-form-label', { text: 'Vai trò' }), el('div.mem-role-box', {}, [roleRow, roleDesc])]),
        el('div.mem-form-row', {}, [el('label.mem-form-label', { text: 'Hồ sơ chia sẻ' }), sharedField]),
        el('div.mem-form-row', {}, [el('label.mem-form-label', { text: 'Giới hạn số dư hồ sơ' }), (limitInput = el('input.input', { placeholder: 'Nếu để trống sẽ không giới hạn số dư hồ sơ mà thành viên sử dụng' }))]),
        el('div.mem-form-row.mem-form-row-top', {}, [el('label.mem-form-label', { text: 'Ghi chú' }), (noteInput = el('textarea.input.mem-textarea', { rows: 3, placeholder: 'Không bắt buộc' }))]),
      ])],
      footer: [
        el('button.grp-cancel', { text: 'Hủy', onclick: closeModal }),
        el('button.btn.primary', { text: 'Mời', onclick: save }),
      ],
    });
    setTimeout(() => nameInput && nameInput.focus(), 30);
  }

  // ----------------------------------------------------- edit member
  function editMemberModal(r, g) {
    let nameInput, limitInput, noteInput;
    let role = r.teamRole || 'member';
    // Nâng/hạ quyền cho nhân viên = chuyển họ sang nhóm thành viên khác (mỗi nhóm là
    // một bó quyền). Mặc định giữ nhóm hiện tại.
    let memberGroupId = r.memberGroupId || (g && g.id) || '';
    const groupSel = customSelect(
      groups.map((x) => ({ value: x.id, label: x.name || '(không tên)' })),
      { value: memberGroupId, placeholder: 'Chọn nhóm thành viên', width: '100%',
        onChange: (v) => { memberGroupId = v; } }
    );
    const shared = new Set((r.sharedProfileIds || []).map((v) => String(v)));
    if (r.shareAll) shared.add('__all__');
    if (r.shareUngrouped) shared.add('__ungrouped__');

    const roleDesc = el('p.mem-role-desc', { text: (MEMBER_ROLES.find((x) => x.key === role) || MEMBER_ROLES[0]).desc });
    const roleRow = el('div.mem-roles', {}, MEMBER_ROLES.map((x) => {
      const radio = el('input', { type: 'radio', name: 'mem-role-edit', checked: x.key === role,
        onchange: () => { role = x.key; roleDesc.textContent = x.desc; } });
      return el('label.mem-role', {}, [radio, el('span', { text: x.label })]);
    }));

    const sharedField = buildSharedPicker(workspaceProfiles, shared);

    const save = async () => {
      const { shareAll, shareUngrouped, sharedProfileIds } = expandShared(shared);
      try {
        await remote.team.members.update(r.id, {
          memberGroupId: memberGroupId || null,
          teamRole: role,
          displayName: nameInput.value.trim(),
          sharedGroupIds: [],
          shareAll,
          shareUngrouped,
          sharedProfileIds,
          balanceLimit: limitInput.value.trim(),
          note: noteInput.value.trim(),
        });
        closeModal();
        await load();
        toast('Đã cập nhật thành viên', 'ok');
      } catch (e) { notifyError(e, 'Cập nhật thành viên thất bại'); }
    };

    openModal({
      title: 'Chỉnh sửa thành viên',
      width: 780,
      body: [el('div.mem-form', {}, [
        el('div.mem-form-row', {}, [el('label.mem-form-label', { text: 'Nhóm thành viên' }), groupSel]),
        el('div.mem-form-row', {}, [el('label.mem-form-label', { text: 'Tên' }), (nameInput = el('input.input', { placeholder: 'Nhập tên thành viên', value: r.name || '' }))]),
        el('div.mem-form-row', {}, [el('label.mem-form-label', { text: 'Email' }), el('div.mem-form-static', { text: r.email || '-' })]),
        el('div.mem-form-row.mem-form-row-top', {}, [el('label.mem-form-label', { text: 'Vai trò' }), el('div.mem-role-box', {}, [roleRow, roleDesc])]),
        el('div.mem-form-row', {}, [el('label.mem-form-label', { text: 'Hồ sơ chia sẻ' }), sharedField]),
        el('div.mem-form-row', {}, [el('label.mem-form-label', { text: 'Giới hạn số dư hồ sơ' }), (limitInput = el('input.input', { placeholder: 'Nếu để trống sẽ không giới hạn số dư hồ sơ mà thành viên sử dụng', value: r.balanceLimit || '' }))]),
        el('div.mem-form-row.mem-form-row-top', {}, [el('label.mem-form-label', { text: 'Ghi chú' }), (noteInput = el('textarea.input.mem-textarea', { rows: 3, placeholder: 'Không bắt buộc', value: r.note || '' }))]),
      ])],
      footer: [
        el('button.grp-cancel', { text: 'Hủy', onclick: closeModal }),
        el('button.btn.primary', { text: 'Lưu', onclick: save }),
      ],
    });
    setTimeout(() => nameInput && nameInput.focus(), 30);
  }

  // Xác nhận đã gửi lời mời. KHÔNG còn hiển thị mã token để copy - người được mời
  // sẽ thấy lời mời trong mục "Thông báo" (chuông) khi đăng nhập bằng đúng email này.
  function showInviteSent(email) {
    openModal({
      title: 'Đã gửi lời mời',
      width: 460,
      body: [el('div.mem-form', {}, [
        el('p.mem-token-desc', {}, [
          document.createTextNode('Đã gửi lời mời tới '),
          el('span.mem-sent-email', { text: email }),
          document.createTextNode('. Thành viên sẽ thấy lời mời trong mục Thông báo khi đăng nhập bằng đúng email này.'),
        ]),
      ])],
      footer: [el('button.btn.primary', { text: 'Đóng', onclick: closeModal })],
    });
  }

  // Chuyển tập chọn của picker (sentinel __all__/__ungrouped__ + id hồ sơ) thành
  // payload server: shareAll / shareUngrouped (boolean) + sharedProfileIds (uuid[]).
  //   "Tất cả"        → shareAll = true (thấy mọi hồ sơ, kể cả tạo sau).
  //   "Chưa chia nhóm"→ shareUngrouped = true.
  //   id hồ sơ        → sharedProfileIds.
  function expandShared(set) {
    const sel = [...set];
    const shareAll = sel.includes('__all__');
    const shareUngrouped = sel.includes('__ungrouped__');
    const sharedProfileIds = sel.filter((v) => v !== '__all__' && v !== '__ungrouped__');
    return { shareAll, shareUngrouped, sharedProfileIds };
  }

  // A searchable multi-select combobox for "Nhóm hồ sơ chia sẻ": a chip trigger +
  // a portaled panel with a search box on top and a filtered option list (Tất cả +
  // each profile group). Clicking a row toggles it; selected rows show a check.
  function buildSharedPicker(profs, selectedSet) {
    // "Tất cả" = mọi hồ sơ của workspace (kể cả tạo sau); "Chưa chia nhóm" = các
    // hồ sơ group_id IS NULL; còn lại là TỪNG hồ sơ chọn theo tên (per-profile).
    const options = [
      { value: '__all__', label: 'Tất cả' },
      { value: '__ungrouped__', label: 'Chưa chia nhóm' },
    ].concat((profs || []).map((p) => ({ value: String(p.id), label: p.name || '(không tên)' })));
    const trigger = el('div.mem-shared-trigger');
    const searchInput = el('input.mem-shared-search-input', { placeholder: 'Tìm hồ sơ...',
      oninput: () => renderList() });
    const list = el('div.mem-shared-list');
    const menu = el('div.mem-shared-menu', {}, [
      el('div.mem-shared-search', {}, [el('span.ico', { html: icon('search') }), searchInput]),
      list,
    ]);
    let open = false;

    const renderTrigger = () => {
      clear(trigger);
      const chosen = options.filter((o) => selectedSet.has(o.value));
      if (!chosen.length) trigger.appendChild(el('span.mem-shared-ph', { text: '+ hồ sơ' }));
      else chosen.forEach((o) => trigger.appendChild(el('span.mem-shared-chip', {}, [
        el('span', { text: o.label }),
        el('span.mem-shared-x', { html: icon('close'), onclick: (e) => { e.stopPropagation(); selectedSet.delete(o.value); renderTrigger(); if (open) renderList(); } }),
      ])));
      trigger.appendChild(el('span.chev', { html: icon('chevronDown') }));
    };
    const renderList = () => {
      clear(list);
      const q = searchInput.value.trim().toLowerCase();
      const shown = options.filter((o) => !q || o.label.toLowerCase().includes(q));
      if (!shown.length) { list.appendChild(el('div.mem-shared-none', { text: 'Không tìm thấy hồ sơ' })); return; }
      shown.forEach((o) => {
        const on = selectedSet.has(o.value);
        list.appendChild(el('div.mem-shared-opt' + (on ? '.selected' : ''), {
          onclick: () => { on ? selectedSet.delete(o.value) : selectedSet.add(o.value); renderTrigger(); renderList(); },
        }, [
          el('span.mem-shared-opt-label', { text: o.label }),
          el('span.mem-shared-check', { html: on ? icon('check') : '' }),
        ]));
      });
    };
    const place = () => {
      const r = trigger.getBoundingClientRect();
      menu.style.position = 'fixed';
      menu.style.left = r.left + 'px';
      menu.style.width = r.width + 'px';
      menu.style.top = (r.bottom + 4) + 'px';
    };
    const onDoc = (e) => { if (!wrap.contains(e.target) && !menu.contains(e.target)) doClose(); };
    // Đóng khi TRANG/modal cuộn (menu position:fixed sẽ lệch khỏi trigger) - NHƯNG
    // BỎ QUA cuộn phát sinh TỪ TRONG menu (lăn chuột duyệt danh sách hồ sơ trong
    // dropdown thì list tự cuộn, không được đóng menu).
    const onScroll = (e) => { const t = e.target; if (!(t instanceof Node) || !menu.contains(t)) doClose(); };
    const doOpen = () => { open = true; searchInput.value = ''; renderList(); document.body.appendChild(menu); place(); wrap.classList.add('open'); document.addEventListener('mousedown', onDoc); window.addEventListener('scroll', onScroll, true); setTimeout(() => searchInput.focus(), 20); };
    const doClose = () => { open = false; if (menu.parentNode) menu.parentNode.removeChild(menu); wrap.classList.remove('open'); document.removeEventListener('mousedown', onDoc); window.removeEventListener('scroll', onScroll, true); };
    trigger.addEventListener('click', () => { open ? doClose() : doOpen(); });

    const wrap = el('div.mem-shared', {}, [trigger]);
    renderTrigger();
    return wrap;
  }

  // ----------------------------------------------------- page shell
  const addBtn = el('button.btn.ghost.mem-add', { html: `${icon('plusCircle')}<span>Thêm</span>`, onclick: () => groupModal(null) });
  // Toggle manage-only controls once permissions are known.
  function syncManageUi() { addBtn.style.display = manage() ? '' : 'none'; }
  syncManageUi();

  const page_ = el('div.page.members-page', {}, [
    el('div.mem-side', {}, [
      el('div.mem-side-head', {}, [
        el('span.mem-side-title', { text: 'Nhóm thành viên' }),
        addBtn,
      ]),
      sideList,
    ]),
    el('div.mem-main', {}, [mainArea]),
  ]);
  ctx.container.appendChild(page_);

  // ------------------------------------------------ khoá khi ở workspace "Tất cả"
  // "Tất cả" là THÔNG TIN CHUNG (mọi hồ sơ của email), KHÔNG phải một team → không
  // có thành viên/nhóm để quản lý. Không ẩn mục sidebar; thay vào đó phủ một lớp
  // overlay: con trỏ "cấm click" + tooltip nhắc tạo không gian làm việc riêng, chặn
  // mọi thao tác bên trong. Chuyển sang một workspace RIÊNG thì overlay tự gỡ.
  // Nội dung khoá đổi theo bối cảnh:
  //  • CHƯA có workspace riêng nào → nhắc TẠO một không gian làm việc riêng.
  //  • ĐÃ có workspace riêng nhưng đang chọn "Tất cả" → nhắc CHỌN một workspace cụ thể
  //    (vì "Tất cả" là thông tin chung, không có thành viên để quản lý).
  const LOCK_MSG_CREATE = 'Hãy tạo một “không gian làm việc riêng” để sử dụng tính năng Thành viên nhóm.';
  const LOCK_MSG_PICK = 'Hãy chọn một “không gian làm việc” cụ thể để sử dụng tính năng Thành viên nhóm.';
  const lockMsg = () => {
    try { return (window.__vtHasTeamWorkspace && window.__vtHasTeamWorkspace()) ? LOCK_MSG_PICK : LOCK_MSG_CREATE; }
    catch { return LOCK_MSG_CREATE; }
  };
  let lockOverlay = null;
  let lockTextEl = null;
  const isLocked = () => { try { return !!(window.__vtIsDefaultWorkspace && window.__vtIsDefaultWorkspace()); } catch { return false; } };
  function applyLock() {
    const locked = isLocked();
    page_.classList.toggle('mem-locked', locked);
    if (locked) {
      const msg = lockMsg();
      if (!lockOverlay) {
        lockTextEl = el('span.mem-lock-text', { text: msg });
        lockOverlay = el('div.mem-lock-overlay', {}, [
          el('div.mem-lock-note', {}, [
            el('span.mem-lock-ico', { html: icon('lock') }),
            lockTextEl,
          ]),
        ]);
      }
      // Cập nhật lại nội dung + tooltip mỗi lần (workspace có thể vừa đổi qua onShow).
      lockTextEl.textContent = msg;
      lockOverlay.setAttribute('title', msg);
      if (!lockOverlay.parentNode) page_.appendChild(lockOverlay);
    } else if (lockOverlay && lockOverlay.parentNode) {
      lockOverlay.parentNode.removeChild(lockOverlay);
    }
  }
  applyLock();

  // Load permissions first (gates manage UI), then the data.
  loadPermissions().then(() => load());

  // onShow: app.js gọi lại khi ĐỔI workspace (kể cả khi màn đang mở, keep-alive) để
  // cập nhật trạng thái khoá theo workspace mới.
  return { destroy() {}, onShow() { applyLock(); } };
}
