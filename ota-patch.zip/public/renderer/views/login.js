// Login / Register gate. Shown by app.js before the shell when there is no valid
// server session. Talks to the API through window.vt.auth (which returns the
// { ok, data } / { ok:false, error, code } envelope).
//
// Layout (user 2026-11-02): MỘT thẻ trắng ở GIỮA màn hình (logo + chọn ngôn ngữ + form) trên nền gradient lớn phủ cả
// cửa sổ; bong bóng liên hệ ở góc. Panel trái "Tính năng nổi bật" (60/40) đã bỏ. Form clone từ AdsPower (ô nhập nền
// tím nhạt có icon, hàng nhớ mật khẩu + quên mật khẩu, vạch "người dùng mới tự đăng ký", đăng nhập Google, dòng điều
// khoản, chân chuyển đăng ký).
import { el, clear, toast, openModal, closeModal, linkifyNodes } from '../ui.js';
import { setLang, applyI18n, getLang, t, tf } from '../i18n.js';
import { contactFab } from '../ui/contact-fab.js';
import { icon } from '../icons.js';
import { LEGAL_TR, LEGAL_NOTE } from '../data/legal-i18n.js';

// --- Nội dung pháp lý (Điều khoản sử dụng / Chính sách bảo mật) hiển thị trong modal ---
// Nội dung ĐỒNG BỘ 1:1 với web landing (terms-of-service.html / privacy-policy.html).
// Mỗi phần tử trong `body` có thể là: chuỗi → đoạn văn <p>; { h5 } → tiêu đề phụ;
// { h6 } → tiêu đề phụ nhỏ hơn; { ul: [...] } → danh sách gạch đầu dòng.
export const TERMS_SECTIONS = [
  { h: '1. Quy định chung', body: [
    'Bản Điều khoản Sử dụng này xác lập các nội dung ràng buộc Bạn trong quá trình sử dụng Dịch vụ của CGTBrowser. Các từ “Bạn” và/hoặc “Người sử dụng” dưới đây được dùng chung để chỉ những cá nhân, tổ chức sử dụng Dịch vụ của CGTBrowser. Đề nghị Bạn đọc kỹ và giữ lại một bản Điều khoản Sử dụng này.',
    'Khi Bạn sử dụng Dịch vụ của chúng tôi, Bạn đã chấp nhận chịu ràng buộc bởi bản Điều khoản Sử dụng này. Trường hợp Bạn không chấp nhận sự ràng buộc đó, Bạn cần dừng ngay việc sử dụng Dịch vụ của CGTBrowser.',
    'Chúng tôi áp dụng bản Điều khoản Sử dụng này theo pháp luật hiện hành, và không có nội dung nào trong đây hạn chế quyền của CGTBrowser trong việc tuân thủ các quy định hoặc yêu cầu từ chính phủ, tòa án, cơ quan thi hành án liên quan tới việc Bạn sử dụng Dịch vụ của CGTBrowser hoặc liên quan tới thông tin mà chúng tôi tiếp nhận, thu được từ quá trình sử dụng Dịch vụ của Bạn.',
  ] },
  { h: '2. Từ chối bảo đảm', body: [
    'Website và Dịch vụ của CGTBrowser được cung cấp theo nguyên tắc không bảo hành, dựa trên dịch vụ và tính năng hiện có, không kèm bất cứ cam kết bảo đảm nào dù dưới hình thức thể hiện rõ ràng hay ngụ ý. CGTBrowser không cam kết rằng việc vận hành phần mềm hay Dịch vụ của CGTBrowser sẽ liên tục, không gián đoạn hoặc không phát sinh lỗi.',
    'CGTBrowser không nhận trách nhiệm về bất cứ sự mất mát dữ liệu, thiệt hại lợi ích hay vấn đề nào khác nảy sinh từ việc sử dụng Dịch vụ của CGTBrowser, bao gồm nhưng không giới hạn ở toàn bộ thông tin, dữ liệu, văn bản, phần mềm, âm nhạc, âm thanh, hình ảnh, đồ họa, video, thông điệp hoặc các tư liệu khác (“Nội dung”) mà Bạn lưu giữ, tải lên hay truyền tải qua Dịch vụ. Bạn chấp nhận sử dụng Dịch vụ của CGTBrowser cùng toàn bộ rủi ro đi kèm.',
  ] },
  { h: '3. Thay đổi điều khoản sử dụng', body: [
    'CGTBrowser bảo lưu quyền thay đổi và/hoặc điều chỉnh bất cứ nội dung nào trong bản Điều khoản Sử dụng này vào từng thời điểm mà không cần thông báo trước. Các thay đổi và/hoặc điều chỉnh đó phát sinh hiệu lực ngay khi được đăng tải lên website này. Trường hợp Bạn vẫn tiếp tục sử dụng Dịch vụ của CGTBrowser sau khi những thay đổi và/hoặc điều chỉnh đã được đăng tải, điều đó có nghĩa Bạn đã chấp nhận và đồng thuận với các thay đổi, điều chỉnh ấy.',
  ] },
  { h: '4. Hành vi bị cấm khi sử dụng dịch vụ', body: [
    'Bạn có nghĩa vụ sử dụng Dịch vụ của CGTBrowser đúng với quy định hiện hành của pháp luật Việt Nam. CGTBrowser không dung túng hay chấp thuận bất cứ hành vi trái pháp luật hoặc bị cấm nào liên quan tới Dịch vụ của CGTBrowser. Sau đây là một số hành vi trái pháp luật hoặc bị cấm khi Bạn sử dụng Dịch vụ của CGTBrowser. Chúng tôi bảo lưu quyền điều tra và áp dụng các biện pháp pháp lý cần thiết với bất cứ ai, theo quyết định của CGTBrowser, vi phạm quy định này, bao gồm nhưng không giới hạn ở việc trình báo tới các Cơ quan Quản lý Nhà nước.',
    'Bạn không được thực hiện các hành vi bị cấm, bao gồm nhưng không giới hạn ở việc lợi dụng Internet nhằm:',
    { ul: [
      'Chống phá nhà nước Cộng hòa Xã hội Chủ nghĩa Việt Nam; làm phương hại tới an ninh quốc gia, trật tự, an toàn xã hội; phá hoại khối đại đoàn kết toàn dân; cổ vũ chiến tranh xâm lược; khơi dậy hận thù, mâu thuẫn, kỳ thị giữa các dân tộc, sắc tộc, tôn giáo;',
      'Cổ vũ, kích động bạo lực, dâm ô, đồi trụy, tội ác, tệ nạn xã hội, mê tín dị đoan; làm tổn hại thuần phong, mỹ tục của dân tộc;',
      'Làm lộ bí mật nhà nước, bí mật quân sự, an ninh, kinh tế, đối ngoại cùng những bí mật khác mà pháp luật đã quy định;',
      'Phát tán thông tin xuyên tạc, vu khống, làm tổn hại uy tín của tổ chức, danh dự và nhân phẩm của công dân;',
      'Lợi dụng Internet nhằm quảng cáo, tuyên truyền, mua bán hàng hóa, dịch vụ nằm trong danh mục cấm theo quy định pháp luật;',
      'Xâm hại quyền sở hữu trí tuệ;',
      'Sản xuất, phát hành sản phẩm công nghệ thông tin trái pháp luật;',
      'Thiết lập đường dẫn trái phép tới tên miền của tổ chức, cá nhân đang sử dụng hợp pháp tên miền đó;',
      'Quấy rối, phá hoại hệ thống thiết bị và cản trở trái pháp luật hoạt động quản lý, cung cấp, sử dụng dịch vụ Internet cùng thông tin điện tử trên Internet;',
      'Chiếm đoạt và sử dụng trái phép mật khẩu, khóa mật mã, thông tin riêng của các tổ chức, cá nhân trên Internet;',
      'Tạo lập và cài đặt virus máy tính, phần mềm độc hại nhằm thực hiện một trong các hành vi trái pháp luật về công nghệ thông tin.',
    ] },
  ] },
  { h: '5. Quy định sử dụng dịch vụ', body: [
    'Trong quá trình sử dụng Dịch vụ của CGTBrowser, Bạn chịu ràng buộc phải chấp thuận và tuân thủ những điều kiện dưới đây:',
    'CGTBrowser trao cho Bạn quyền sử dụng miễn phí, không thu phí bản quyền, không được chuyển nhượng và không mang tính độc quyền đối với phần mềm trình duyệt CGTBrowser cùng Dịch vụ. Bạn không được phép và cũng không được để bất cứ ai khác sao chép, tạo sản phẩm phái sinh hay tìm cách trích xuất mã nguồn của phần mềm trình duyệt CGTBrowser.',
    'Phần mềm trình duyệt CGTBrowser mà Bạn sử dụng có thể tự động tải về và cài đặt định kỳ các bản cập nhật nhằm khắc phục lỗi, cải tiến, nâng cấp và hoàn thiện Dịch vụ của CGTBrowser. Bạn chấp thuận tiếp nhận và cho phép CGTBrowser vận hành cơ chế cập nhật phần mềm như vậy trong suốt quá trình Bạn sử dụng Dịch vụ.',
    'Bạn chấp thuận và thừa nhận rằng các Nội dung thuộc trách nhiệm riêng của người sở hữu Nội dung đó. CGTBrowser có quyền nhưng không mang nghĩa vụ kiểm duyệt, sàng lọc, khước từ, chỉnh sửa hay thay đổi bất cứ Nội dung nào hiện diện trên Dịch vụ của CGTBrowser. Bạn phải tự gánh chịu rủi ro khi sử dụng Dịch vụ của CGTBrowser, mặc dù trong quá trình cung cấp Dịch vụ, CGTBrowser vẫn áp dụng các công cụ nhằm sàng lọc thông tin có nội dung không phù hợp, vi phạm quy định của pháp luật Việt Nam.',
    'Bạn chấp thuận rằng Bạn phải gánh trách nhiệm cho hành vi của mình và cho bất cứ Nội dung nào mà Bạn thu được, tạo lập, trưng bày hay truyền tải khi sử dụng Dịch vụ của chúng tôi, cũng như những hậu quả nếu có phát sinh từ hành vi sử dụng và Nội dung của Bạn. Bạn chấp thuận rằng Bạn chỉ sử dụng Dịch vụ của chúng tôi vào các mục đích hợp pháp, hợp lệ, đúng với quy định trong Điều khoản Sử dụng và Chính sách Bảo mật của CGTBrowser cùng những hướng dẫn hay chính sách khác mà chúng tôi ban hành.',
    'Bạn chấp thuận rằng CGTBrowser sẽ không gánh trách nhiệm nếu bất cứ Nội dung nào của Bạn bị xóa hoặc không lưu trữ được trong quá trình chúng tôi duy trì và cung cấp Dịch vụ.',
    'Bạn chấp thuận rằng Bạn sẽ không kinh doanh, khai thác, sản xuất lại, sao chép hay sử dụng Dịch vụ của CGTBrowser vào mục đích thương mại, trừ khi có sự đồng thuận bằng văn bản của CGTBrowser.',
    'Bạn thừa nhận rằng CGTBrowser cung cấp một số Dịch vụ có kèm nội dung quảng cáo và trưng bày các quảng cáo, khuyến mãi. Bạn chấp thuận rằng CGTBrowser được phép đặt những thông tin quảng cáo, khuyến mãi như vậy tại Dịch vụ, và CGTBrowser sẽ không gánh bất cứ trách nhiệm nào đối với thiệt hại, mất mát mà Bạn phải chịu do sự xuất hiện của các dịch vụ quảng cáo, khuyến mãi, hoặc do Bạn thường xuyên phải tiếp nhận những thông tin quảng cáo, khuyến mãi ấy khi sử dụng Dịch vụ của CGTBrowser.',
    'Bạn thừa nhận rằng CGTBrowser có thể liên kết hoặc cung cấp đường dẫn tới các website khác, và Bạn chấp thuận rằng CGTBrowser không kiểm soát cũng như không gánh trách nhiệm với bất cứ Nội dung, quảng cáo, dịch vụ, sản phẩm nào mà Bạn thu được hay biết tới từ những website đó. Đồng thời Bạn cũng xác nhận rằng CGTBrowser sẽ không gánh trách nhiệm với thiệt hại, mất mát mà Bạn phải chịu bắt nguồn từ hoặc do việc Bạn sử dụng Nội dung, quảng cáo, dịch vụ, sản phẩm từ những website như vậy.',
    'Bạn chấp thuận rằng Bạn sẽ không tham gia bất cứ hoạt động hay thực hiện bất cứ hành vi nào có thể hoặc đe dọa gây gián đoạn, tạm ngừng Dịch vụ của CGTBrowser hay các dịch vụ, mạng lưới liên kết với Dịch vụ của CGTBrowser.',
    'Bạn chấp thuận rằng CGTBrowser, với toàn quyền quyết định của mình, được phép ngừng cung cấp Dịch vụ cho Bạn nếu CGTBrowser cho rằng Bạn đã vi phạm hoặc thực hiện không đúng các điều kiện sử dụng Dịch vụ của CGTBrowser.',
    'Bạn chấp thuận và thừa nhận rằng CGTBrowser có toàn quyền quyết định và vào bất cứ thời điểm nào chấm dứt việc cung cấp toàn bộ hay một phần Dịch vụ, có thể kèm hoặc không kèm thông báo. Bạn chấp thuận rằng mọi việc chấm dứt quyền sử dụng Dịch vụ của Bạn theo bất cứ quy định nào trong bản Điều khoản Sử dụng này đều phát sinh hiệu lực mà không cần báo trước. Đồng thời, Bạn chấp thuận rằng CGTBrowser không gánh trách nhiệm với Bạn hay với bất cứ bên thứ ba nào do việc Bạn bị chấm dứt quyền sử dụng Dịch vụ.',
  ] },
  { h: '6. Các điều khoản dịch vụ và chính sách bổ sung áp dụng cho một số sản phẩm, dịch vụ nhất định', body: [
    'Trước hết, bản Điều khoản Sử dụng này áp dụng cho toàn bộ Dịch vụ của CGTBrowser. Bên cạnh đó, chúng tôi liệt kê dưới đây các Điều khoản dịch vụ và chính sách bổ sung áp dụng riêng cho một số dịch vụ nhất định của CGTBrowser, cụ thể:',
    { h5: '6.1. Trình duyệt CGTBrowser' },
    { h6: 'Điều khoản dịch vụ - Quy định chung' },
    'Bản Điều khoản Sử dụng này xác lập các nội dung ràng buộc Bạn khi sử dụng Dịch vụ của CGTBrowser. Các từ “Bạn” và/hoặc “Người sử dụng” dưới đây được dùng chung để chỉ những cá nhân, tổ chức sử dụng Dịch vụ của CGTBrowser. Đề nghị Bạn đọc kỹ và giữ lại một bản Điều khoản Sử dụng này. Khi Bạn tải phần mềm và sử dụng Dịch vụ của chúng tôi, Bạn đã chấp nhận chịu ràng buộc bởi bản Điều khoản Sử dụng này. Trường hợp Bạn không chấp nhận sự ràng buộc đó, Bạn cần dừng ngay việc sử dụng Dịch vụ của CGTBrowser.',
    'Bạn xác nhận và chấp thuận rằng giữa Bạn và CGTBrowser không tồn tại bất cứ quan hệ liên doanh, đối tác, quan hệ lao động hay quan hệ đại lý nào phát sinh từ bản Điều khoản Sử dụng này hoặc từ việc Bạn sử dụng Dịch vụ của CGTBrowser. Chúng tôi áp dụng bản Điều khoản Sử dụng này theo pháp luật hiện hành, và không có nội dung nào trong đây hạn chế quyền của CGTBrowser trong việc tuân thủ các quy định hoặc yêu cầu từ chính phủ, tòa án, cơ quan thi hành án liên quan tới việc Bạn sử dụng Dịch vụ của CGTBrowser hoặc liên quan tới thông tin mà chúng tôi tiếp nhận, thu được từ quá trình sử dụng Dịch vụ của Bạn.',
    { h6: 'Từ chối bảo đảm' },
    'Website và Dịch vụ của CGTBrowser được cung cấp theo nguyên tắc không bảo hành, dựa trên dịch vụ và tính năng hiện có, không kèm bất cứ cam kết bảo đảm nào dù dưới hình thức thể hiện rõ ràng hay ngụ ý. CGTBrowser không cam kết rằng Dịch vụ của chúng tôi sẽ thỏa mãn các nhu cầu của Bạn, cũng không cam kết rằng việc vận hành phần mềm hay Dịch vụ của CGTBrowser sẽ liên tục, không gián đoạn hoặc không phát sinh lỗi.',
    'CGTBrowser không nhận trách nhiệm về bất cứ sự mất mát dữ liệu, thiệt hại lợi ích hay vấn đề nào khác nảy sinh từ việc sử dụng Dịch vụ của CGTBrowser, bao gồm nhưng không giới hạn ở toàn bộ thông tin, dữ liệu, văn bản, phần mềm, âm nhạc, âm thanh, hình ảnh, đồ họa, video, thông điệp hoặc các tư liệu khác (“Nội dung”) mà Bạn lưu giữ, tải lên hay truyền tải qua Dịch vụ. Bạn chấp nhận sử dụng Dịch vụ của CGTBrowser cùng toàn bộ rủi ro đi kèm.',
    { h6: 'Thay đổi điều khoản sử dụng' },
    'CGTBrowser bảo lưu quyền thay đổi và/hoặc điều chỉnh bất cứ nội dung nào trong bản Điều khoản Sử dụng này vào từng thời điểm mà không cần thông báo trước. Các thay đổi và/hoặc điều chỉnh đó phát sinh hiệu lực ngay khi được đăng tải lên website của chúng tôi. Trường hợp Bạn vẫn tiếp tục sử dụng Dịch vụ của CGTBrowser sau khi những thay đổi, điều chỉnh đã được đăng tải, điều đó có nghĩa Bạn đã chấp nhận và đồng thuận với các thay đổi, điều chỉnh ấy.',
    { h6: 'Hành vi cấm sử dụng dịch vụ' },
    'Bạn có nghĩa vụ sử dụng Dịch vụ của CGTBrowser đúng với quy định hiện hành của pháp luật Việt Nam. CGTBrowser không dung túng hay chấp thuận bất cứ hành vi trái pháp luật hoặc bị cấm nào liên quan tới Dịch vụ của CGTBrowser. Sau đây là một số hành vi trái pháp luật hoặc bị cấm khi Bạn sử dụng Dịch vụ của CGTBrowser. Chúng tôi bảo lưu quyền điều tra và áp dụng các biện pháp pháp lý cần thiết với bất cứ ai, theo quyết định của CGTBrowser, vi phạm quy định này, bao gồm nhưng không giới hạn ở việc trình báo tới các Cơ quan Quản lý Nhà nước.',
    'Những hành vi sau đây bị xem là lạm dụng CGTBrowser và bị nghiêm cấm:',
    { ul: [
      'Giới thiệu trình duyệt CGTBrowser dưới tên gọi Chrome hoặc bất cứ tên gọi nào khác không liên quan tới tên thật của CGTBrowser;',
      'Chi trả cho bất cứ bên thứ ba nào khác trong một chương trình hợp tác các khoản doanh thu quảng cáo thu được từ những lần nhấp chuột của người sử dụng trình duyệt CGTBrowser, nhưng không cho phép CGTBrowser tham gia chương trình hợp tác đó;',
      'Khóa trình duyệt CGTBrowser hoặc thông báo sai sự thật rằng trình duyệt CGTBrowser không được hỗ trợ;',
      'Ngăn cản việc tải trình duyệt CGTBrowser.',
    ] },
    { h6: 'Quy định sử dụng dịch vụ' },
    'CGTBrowser trao cho Bạn quyền sử dụng miễn phí, không thu phí bản quyền, không được chuyển nhượng và không mang tính độc quyền đối với phần mềm trình duyệt CGTBrowser cùng Dịch vụ. Bạn không được phép và cũng không được để bất cứ ai khác sao chép, tạo sản phẩm phái sinh hay tìm cách trích xuất mã nguồn của phần mềm trình duyệt CGTBrowser.',
    'Bạn chấp thuận rằng Bạn sẽ không kinh doanh, khai thác, sản xuất lại, sao chép hay sử dụng Dịch vụ của CGTBrowser vào mục đích thương mại, trừ khi có sự đồng thuận bằng văn bản của CGTBrowser.',
    { h6: 'Giới hạn trách nhiệm' },
    'Bạn xác nhận và chấp thuận rằng CGTBrowser chỉ sẵn sàng cung cấp Dịch vụ nếu Bạn đồng thuận giới hạn trách nhiệm của chúng tôi đối với Bạn và các bên thứ ba. Bạn chấp thuận rằng Bạn gánh trách nhiệm bồi thường duy nhất và toàn bộ đối với bất cứ khiếu nại, tố cáo nào gửi tới CGTBrowser liên quan tới bất cứ sự vi phạm quy định sử dụng nào do việc Bạn ngừng sử dụng Dịch vụ của CGTBrowser.',
    { h6: 'Bảo mật thông tin người dùng' },
    'Để nắm rõ cơ chế bảo mật thông tin người dùng, đề nghị Bạn tham khảo Chính sách bảo mật của CGTBrowser tại website của chúng tôi. Chính sách này trình bày cơ chế thu thập, xử lý và bảo vệ thông tin người dùng. Khi Bạn cài đặt và sử dụng trình duyệt này, Bạn đã chấp thuận tuân theo Chính sách bảo mật của CGTBrowser.',
    { h6: 'Bảo vệ bản quyền và quyền sở hữu trí tuệ khác' },
    'Dịch vụ của CGTBrowser cùng toàn bộ phần mềm cần thiết, yếu tố cấu thành Dịch vụ, bao gồm cả quyền sở hữu trí tuệ đối với Dịch vụ của CGTBrowser (“Sở hữu Trí tuệ”), được bảo hộ bởi bản quyền, quyền về thương hiệu, nhãn dịch vụ hoặc quyền tài sản khác mà CGTBrowser sở hữu, hoặc thuộc sở hữu của bên thứ ba đã cấp quyền sở hữu trí tuệ cho CGTBrowser. Bạn không có quyền sử dụng bất cứ tên thương mại, nhãn hiệu hàng hóa và dịch vụ, biểu tượng, tên miền cùng các hình thức nhận diện đặc trưng nào khác của CGTBrowser vào mục đích thương mại, trừ khi Bạn nhận được sự chấp thuận bằng văn bản của CGTBrowser.',
    { h5: '6.2. Dịch vụ đồng bộ đám mây CGTBrowser' },
    'Điều khoản dịch vụ.',
    { h5: '6.3. Dịch vụ không gian làm việc nhóm CGTBrowser' },
    'Điều khoản dịch vụ.',
    { h5: '6.4. Chương trình giới thiệu CGTBrowser' },
    'Điều khoản tham gia.',
    'Chúng tôi thường ra mắt các dịch vụ mới và đôi khi cập nhật những điều khoản, chính sách của mình. Chúng tôi cố gắng hết sức để giữ cho trang này luôn được cập nhật và làm mới nó thường xuyên.',
  ] },
  { h: '7. Thanh toán và hoàn tiền', body: [
    '7.1. Cơ chế thanh toán. CGTBrowser hoạt động theo hình thức trả trước qua Ví. Bạn nạp tiền vào Ví của tài khoản bằng cách chuyển khoản tới tài khoản ngân hàng do CGTBrowser công bố, kèm đúng mã định danh nạp tiền hiển thị trong ứng dụng ở phần nội dung chuyển khoản. Hệ thống tự động đối soát biến động số dư ngân hàng và cộng tiền vào Ví theo mã định danh đó. Số dư trong Ví được dùng để mua, gia hạn, nâng cấp gói dịch vụ và mua các kịch bản trả phí trên Chợ kịch bản.',
    '7.2. Nghĩa vụ ghi đúng nội dung chuyển khoản. Bạn chịu trách nhiệm ghi đúng và đầy đủ mã định danh nạp tiền của mình. Trường hợp nội dung chuyển khoản thiếu, sai mã định danh hoặc chuyển tới tài khoản ngân hàng không phải tài khoản do CGTBrowser công bố, hệ thống không thể xác định giao dịch thuộc về ai và tiền sẽ không tự động vào Ví. Khi đó Bạn cần liên hệ bộ phận hỗ trợ kèm chứng từ chuyển khoản để chúng tôi tra soát; CGTBrowser sẽ nỗ lực hợp lý để đối chiếu và cộng bù vào Ví của Bạn, nhưng không cam kết thời hạn xử lý và không chịu trách nhiệm với những giao dịch không thể tra soát được.',
    '7.3. Giá dịch vụ. Giá áp dụng cho mỗi giao dịch là giá được hệ thống tính và hiển thị tại thời điểm Bạn xác nhận giao dịch. CGTBrowser bảo lưu quyền điều chỉnh bảng giá, cấu hình gói, chính sách chiết khấu và các chương trình khuyến mãi vào từng thời điểm mà không cần thông báo trước; việc điều chỉnh không làm thay đổi các giao dịch đã hoàn tất trước đó.',
    '7.4. CHÍNH SÁCH KHÔNG HOÀN TIỀN. CGTBrowser áp dụng chính sách KHÔNG HOÀN TIỀN. Cụ thể:',
    { ul: [
      'Số dư đã nạp vào Ví không được hoàn lại, không rút ra tiền mặt, không quy đổi ngược thành tiền và không chuyển sang tài khoản khác. Số dư đó chỉ dùng để thanh toán các sản phẩm, dịch vụ của CGTBrowser;',
      'Số dư đã trừ khỏi Ví để mua, gia hạn, nâng cấp gói dịch vụ hoặc mua kịch bản trả phí là khoản thanh toán cuối cùng và không được hoàn lại trong mọi trường hợp, bao gồm nhưng không giới hạn ở: Bạn ngừng sử dụng hoặc không sử dụng hết thời hạn, hạn mức hồ sơ hay số ghế thành viên đã mua (cách tính hạn mức hồ sơ theo sức chứa được nêu tại Điều 7.8); Bạn thay đổi ý định sau khi đã xác nhận giao dịch; Bạn mua sai gói, sai cấu hình, sai kịch bản hoặc mua trùng lặp; Bạn tự xóa tài khoản, hồ sơ hoặc dữ liệu; hoặc tài khoản của Bạn bị tạm ngừng, chấm dứt theo Điều 4, Điều 5 và Điều 11.2 của bản Điều khoản Sử dụng này;',
      'Nâng cấp gói giữa kỳ không phát sinh hoàn tiền. Khi Bạn nâng cấp trong lúc gói hiện tại còn hiệu lực, số ngày còn lại được cộng vào thời hạn mới và được tính lại theo cấu hình mới mà Bạn chọn. Phần tiền Bạn đã trả cho gói cũ không được hoàn lại dưới bất cứ hình thức nào;',
      'Tiền khuyến mãi không phải là tiền Bạn nạp. Khoản cộng thêm từ các chương trình khuyến mãi nạp tiền là ưu đãi do CGTBrowser tặng, không được hoàn lại, không rút ra và không quy đổi thành tiền. Việc một chương trình khuyến mãi kết thúc hoặc bị hủy không ảnh hưởng tới khoản ưu đãi đã được cộng vào Ví trước đó;',
      'Kịch bản trên Chợ kịch bản là sản phẩm số được cung cấp và sử dụng ngay sau khi thanh toán, do đó không được hoàn tiền, kể cả khi kịch bản sau đó bị tác giả gỡ bỏ hoặc bị CGTBrowser đưa khỏi Chợ.',
    ] },
    '7.5. Điều chỉnh do sai sót hệ thống. Chính sách không hoàn tiền tại Điều 7.4 không loại trừ trường hợp lỗi kỹ thuật hoặc lỗi đối soát do phía CGTBrowser gây ra dẫn tới việc Ví của Bạn bị trừ hoặc cộng không đúng. Trong các trường hợp đó, CGTBrowser thực hiện điều chỉnh số dư Ví cho đúng, kèm ghi nhận vào sổ giao dịch của tài khoản. Đây là biện pháp điều chỉnh nội bộ trong Ví, không phải hoàn tiền ra ngoài hệ thống.',
    '7.6. Sổ giao dịch. Mọi lần cộng, trừ số dư Ví đều được ghi nhận vào sổ giao dịch của tài khoản và Bạn có thể tự tra cứu trong ứng dụng. Sổ giao dịch là căn cứ để đối chiếu khi phát sinh khiếu nại về thanh toán. Bạn có nghĩa vụ kiểm tra sổ giao dịch và thông báo cho CGTBrowser trong thời gian hợp lý nếu phát hiện sai lệch.',
    '7.7. Bảo mật tài khoản và giao dịch. Bạn chịu trách nhiệm bảo mật thông tin đăng nhập của mình. Mọi giao dịch được thực hiện từ tài khoản của Bạn được xem là do Bạn thực hiện. CGTBrowser không hoàn lại số dư đã bị sử dụng bởi bất cứ ai truy cập được vào tài khoản của Bạn, trừ trường hợp lỗi thuộc về hệ thống của chúng tôi theo Điều 7.5.',
    '7.8. Hạn mức hồ sơ tính theo sức chứa. Hạn mức hồ sơ của gói dịch vụ là số hồ sơ được phép tồn tại đồng thời trên tài khoản của Bạn, không phải số lần Bạn được tạo hồ sơ. Khi Bạn xóa vĩnh viễn một hồ sơ, chỗ của hồ sơ đó được trả lại ngay và Bạn được tạo hồ sơ mới thay thế mà không phải trả thêm tiền. Hồ sơ nằm trong Thùng rác vẫn chiếm chỗ cho tới khi bị xóa vĩnh viễn, vì dữ liệu của hồ sơ đó còn nguyên và Bạn có thể khôi phục bất cứ lúc nào. Cùng nguyên tắc này áp dụng cho “Giới hạn số dư hồ sơ” mà chủ tài khoản đặt cho từng thành viên trong nhóm: hồ sơ do thành viên tạo chiếm một chỗ trong giới hạn của chính thành viên đó và được hoàn lại khi hồ sơ bị xóa vĩnh viễn. Bạn lưu ý xóa vĩnh viễn là hành vi không thể hủy: toàn bộ cookie, phiên đăng nhập, dấu vân tay và dữ liệu duyệt web bên trong hồ sơ bị xóa cùng lúc, CGTBrowser không giữ bản sao và không có nghĩa vụ phục hồi. Riêng ghế thành viên không theo cơ chế này: một địa chỉ email đã nhận lời mời và vào không gian làm việc của Bạn được tính là đã tiêu một ghế, việc gỡ thành viên đó về sau không trả lại ghế.',
    '7.9. Giới hạn số lần tạo và mở hồ sơ theo ngày. Vì chỗ hồ sơ được hoàn lại theo Điều 7.8, CGTBrowser áp dụng thêm giới hạn số lần tạo hồ sơ và số lần mở hồ sơ trong một ngày nhằm chống lạm dụng và bảo vệ hạ tầng dùng chung. Các giới hạn này do CGTBrowser cấu hình, có thể khác nhau theo từng gói dịch vụ và có thể được điều chỉnh vào từng thời điểm mà không cần thông báo trước. Bộ đếm tính theo ngày dương lịch theo giờ Việt Nam (GMT+7) và tự đặt lại vào 00:00 mỗi ngày. Khi Bạn đạt giới hạn, thao tác tạo hoặc mở hồ sơ bị từ chối cho tới lần đặt lại kế tiếp; đây không phải sự cố dịch vụ, không làm giảm hạn mức hồ sơ Bạn đang có và không làm phát sinh quyền hoàn tiền. Số lần đã tạo, đã mở trong ngày cùng giới hạn đang áp dụng được hiển thị trong ứng dụng để Bạn tự theo dõi.',
  ] },
  { h: '8. Giới hạn trách nhiệm', body: [
    'Bạn xác nhận và chấp thuận rằng CGTBrowser chỉ sẵn sàng cung cấp Dịch vụ nếu Bạn đồng thuận giới hạn trách nhiệm của chúng tôi đối với Bạn và các bên thứ ba. Bạn chấp thuận rằng Bạn gánh trách nhiệm bồi thường duy nhất và toàn bộ đối với bất cứ khiếu nại, tố cáo nào gửi tới CGTBrowser liên quan tới bất cứ sự vi phạm quy định sử dụng nào do việc Bạn ngừng sử dụng Dịch vụ của CGTBrowser.',
    'Bạn chấp thuận bảo vệ, bồi thường và giữ cho CGTBrowser, các công ty liên kết của CGTBrowser cùng mỗi nhân viên, giám đốc, người lao động, đại lý, đại diện, người cung cấp thông tin và bên cấp phép của CGTBrowser không phải chịu tổn hại bởi bất cứ khiếu nại, khiếu kiện, chi phí, tổn thất, thiệt hại, phán quyết của tòa án và phí tổn nào, bao gồm nhưng không giới hạn ở phí luật sư, liên quan tới hoặc phát sinh từ việc vi phạm Điều khoản Sử dụng hoặc bất cứ sự sử dụng nào của Bạn đối với Dịch vụ, hoặc bất cứ người nào khác sử dụng Dịch vụ thông qua Bạn hay sử dụng máy tính của Bạn. CGTBrowser bảo lưu quyền, bằng chi phí của mình, đảm nhận trọn vẹn việc bảo vệ và kiểm soát (nhưng không mang trách nhiệm) đối với bất cứ vấn đề nào phát sinh như vậy, tùy thuộc vào sự bồi thường của Bạn.',
  ] },
  { h: '9. Bảo mật thông tin người dùng', body: [
    'CGTBrowser vận hành theo nguyên tắc phân định rạch ròi giữa dữ liệu đồng bộ của Bạn và dữ liệu vận hành của hệ thống:',
    'CGTBrowser không lưu trữ, không thu thập và không đọc dữ liệu đồng bộ của Bạn. Cookie, phiên đăng nhập, lịch sử duyệt web cùng toàn bộ dữ liệu phát sinh bên trong từng hồ sơ trình duyệt nằm trên thiết bị của Bạn. Khi Bạn bật đồng bộ, dữ liệu được mã hóa rồi chuyển thẳng tới kho lưu trữ do chính Bạn cấu hình và quản lý - không đi qua, không lưu lại trên hệ thống của chúng tôi.',
    'CGTBrowser quản lý dữ liệu vận hành gồm thông tin tài khoản, gói dịch vụ, cấu hình hồ sơ, thành viên trong không gian làm việc, trạng thái khóa hồ sơ và nhật ký thao tác. Đây là phần dữ liệu bắt buộc phải có để xác thực tài khoản, tính phí và vận hành các tính năng nhóm.',
    'Để nắm rõ cơ chế bảo mật thông tin người dùng, đề nghị Bạn đọc Chính sách bảo mật của CGTBrowser tại website của chúng tôi. Chính sách này cung cấp cho Bạn cơ chế thu thập, xử lý và bảo vệ thông tin người dùng.',
  ] },
  { h: '10. Bảo vệ bản quyền và quyền sở hữu trí tuệ khác', body: [
    '10.1. Dịch vụ của CGTBrowser cùng toàn bộ phần mềm cần thiết, yếu tố cấu thành Dịch vụ, bao gồm cả quyền sở hữu trí tuệ đối với Dịch vụ của CGTBrowser và toàn bộ phần mềm cần thiết, yếu tố cấu thành Dịch vụ (“Sở hữu Trí tuệ”), được bảo hộ bởi bản quyền, quyền về thương hiệu, nhãn dịch vụ hoặc quyền tài sản khác mà CGTBrowser sở hữu, hoặc thuộc sở hữu của bên thứ ba đã cấp quyền sở hữu trí tuệ cho CGTBrowser. Bạn không có quyền sử dụng bất cứ tên thương mại, nhãn hiệu hàng hóa và dịch vụ, biểu tượng, tên miền cùng các hình thức nhận diện hàng hóa, dịch vụ đặc trưng nào khác của CGTBrowser vào mục đích thương mại, trừ khi Bạn nhận được sự chấp thuận bằng văn bản của CGTBrowser, hoặc việc sử dụng của Bạn không gây ảnh hưởng, cản trở, tác động xấu tới hoạt động bình thường của CGTBrowser.',
    '10.2. Việc biên tập (tức là thu thập, sắp xếp và tập hợp) toàn bộ Sở hữu Trí tuệ của Dịch vụ là tài sản độc quyền của CGTBrowser, được bảo hộ bởi pháp luật Việt Nam và các công ước quốc tế về bản quyền. Sở hữu trí tuệ của Dịch vụ cùng các dịch vụ khác mà CGTBrowser sở hữu, vận hành, kiểm soát hoặc được cấp phép không được sao chụp, sản xuất lại, tái bản, tải lên, đăng tải, truyền tải hay phân phối dưới bất cứ hình thức nào. Việc sử dụng hoặc chỉnh sửa quyền sở hữu trí tuệ của CGTBrowser dưới bất cứ hình thức nào, bao gồm nhưng không giới hạn ở bất cứ website hay môi trường được kết nối máy vi tính nào, mà không có sự chấp thuận trước bằng văn bản là hành vi vi phạm bản quyền cùng các quyền tài sản khác của CGTBrowser và bị nghiêm cấm.',
    '10.3. Theo Điều khoản này, CGTBrowser tôn trọng và không tước đoạt quyền sở hữu hay các quyền khác của Bạn đối với những Nội dung Bạn gửi, đăng, chuyển giao hoặc hiển thị trên trình duyệt của chúng tôi. Bạn chấp thuận gánh trách nhiệm bảo vệ và thi hành các quyền đó, và CGTBrowser không mang nghĩa vụ thực hiện công việc ấy nhân danh Bạn, trừ khi giữa Bạn và CGTBrowser có thỏa thuận riêng bằng văn bản về vấn đề này.',
    '10.4. Chúng tôi tôn trọng quyền sở hữu trí tuệ của người khác và yêu cầu Người sử dụng của CGTBrowser cũng làm như vậy. Bạn không được tải lên, gắn vào, đăng tải, truyền đi hoặc bằng cách khác tạo sẵn bất cứ yếu tố cấu thành nào gây ảnh hưởng tới bản quyền, thương hiệu, bí mật thương mại hay quyền tài sản khác của bất cứ tổ chức, cá nhân nào. Chúng tôi có quyền chấm dứt đường truy cập vào Dịch vụ của CGTBrowser hoặc bất cứ dịch vụ nào do CGTBrowser cung cấp đối với người bị nghi ngờ xâm phạm.',
  ] },
  { h: '11. Điều khoản khác', body: [
    { h5: '11.1. Luật điều chỉnh' },
    'Bản Điều khoản Sử dụng này được điều chỉnh bởi và giải thích phù hợp với pháp luật Việt Nam. Nếu bất cứ điều khoản nào trong bản Điều khoản Sử dụng này không hợp pháp, vô hiệu hoặc vì bất cứ lý do nào không thể thực hiện được, thì điều khoản đó sẽ được xem là tách rời khỏi bản Điều khoản Sử dụng này và không ảnh hưởng tới hiệu lực cùng tính thực thi của những điều khoản còn lại.',
    { h5: '11.2. Chấm dứt' },
    'Bản Điều khoản Sử dụng này có hiệu lực cho tới khi bị chấm dứt bởi Bạn hoặc bởi CGTBrowser theo các trường hợp sau đây:',
    'Chấm dứt bởi Bạn: Bạn có thể chấm dứt bản Điều khoản Sử dụng này bằng cách không sử dụng Dịch vụ của CGTBrowser nữa.',
    'Chấm dứt bởi CGTBrowser: Bản Điều khoản Sử dụng này chấm dứt ngay lập tức mà CGTBrowser không cần thông báo trước nếu (i) theo quyết định của CGTBrowser, Bạn không tuân thủ bất cứ điều khoản nào của bản Điều khoản Sử dụng này, hoặc (ii) Pháp luật hoặc quyết định của chính phủ, tòa án, cơ quan thi hành án yêu cầu CGTBrowser chấm dứt Điều khoản Sử dụng.',
    'Khi chấm dứt bản Điều khoản Sử dụng này, Bạn phải hủy bỏ toàn bộ thông tin, tư liệu nhận được từ CGTBrowser và các website của CGTBrowser, cũng như toàn bộ bản sao của những thông tin, tư liệu đó.',
    { h5: '11.3. Liên hệ' },
    'Nếu Bạn có bất cứ câu hỏi nào về bản Điều khoản Sử dụng này, hoặc về sự kết nối của Bạn với CGTBrowser, đề nghị liên hệ với chúng tôi. Toàn bộ vấn đề hoặc mâu thuẫn sẽ được giải quyết nhanh chóng và hợp lý.',
  ] },
];

const PRIVACY_SECTIONS = [
  { h: 'Chính sách bảo mật CGTBrowser', body: [
    'Chính sách này mô tả cách CGTBrowser thu thập, sử dụng và bảo vệ thông tin khi bạn sử dụng phần mềm và các dịch vụ liên quan. Bằng việc cài đặt và sử dụng CGTBrowser, bạn đồng ý với các nội dung dưới đây.',
  ] },
  { h: '1. Nguyên tắc nền tảng', body: [
    'CGTBrowser vận hành theo nguyên tắc phân định rạch ròi giữa dữ liệu đồng bộ của bạn và dữ liệu vận hành của hệ thống.',
    { h5: '1.1. Dữ liệu đồng bộ - chúng tôi không lưu, không đọc' },
    'Hồ sơ trình duyệt, cookie, phiên đăng nhập, lịch sử duyệt web và toàn bộ dữ liệu phát sinh bên trong từng hồ sơ được mã hóa và lưu ngay trên máy của bạn. Các dữ liệu này không được gửi về máy chủ của chúng tôi.',
    'Khi bạn bật đồng bộ, bạn tự cấu hình kho lưu trữ của riêng mình. CGTBrowser không cung cấp và không vận hành kho lưu trữ đó. Dữ liệu được mã hóa rồi chuyển thẳng từ máy bạn tới đích lưu trữ bạn chọn - không đi qua và không lưu lại trên hệ thống của chúng tôi. Khóa mã hóa do bạn giữ.',
    'Hệ quả: chúng tôi không có khả năng kỹ thuật để đọc nội dung hồ sơ của bạn. Chúng tôi không biết bạn đăng nhập tài khoản nào, truy cập website nào hay lưu dữ liệu gì trong từng hồ sơ.',
    { h5: '1.2. Dữ liệu vận hành - chúng tôi quản lý' },
    'Để hệ thống hoạt động được, chúng tôi lưu trữ một số thông tin vận hành, tách biệt hoàn toàn với dữ liệu đồng bộ nêu trên. Chi tiết tại mục 2.',
  ] },
  { h: '2. Thông tin chúng tôi thu thập', body: [
    { h5: '2.1. Thông tin bạn cung cấp' },
    { ul: [
      'Thông tin tài khoản: email, tên hiển thị, mật khẩu (lưu ở dạng đã băm - chúng tôi không lưu mật khẩu dạng đọc được).',
      'Thông tin thanh toán: được xử lý bởi đối tác thanh toán. Chúng tôi không lưu số thẻ đầy đủ.',
      'Nội dung hỗ trợ: mô tả sự cố, ảnh chụp màn hình, tệp nhật ký bạn gửi khi liên hệ.',
    ] },
    { h5: '2.2. Thông tin vận hành' },
    { ul: [
      'Gói dịch vụ: loại gói, thời hạn, số dư, lịch sử giao dịch.',
      'Cấu hình hồ sơ: tên hồ sơ, ghi chú, nhóm, tham số vân tay, thiết lập proxy. Đây là thông số cấu hình, không phải nội dung phiên đăng nhập.',
      'Không gian làm việc: danh sách thành viên, phân quyền, hạn mức hồ sơ, trạng thái khóa hồ sơ đang được sử dụng.',
      'Nhật ký thao tác: thời điểm tạo, mở, đóng, xóa hồ sơ - phục vụ tính năng nhật ký hoạt động và xử lý tranh chấp trong nhóm.',
    ] },
    { h5: '2.3. Thông tin kỹ thuật' },
    { ul: [
      'Phiên bản phần mềm, hệ điều hành, mã định danh cài đặt.',
      'Địa chỉ IP và thời điểm truy cập, phục vụ bảo mật tài khoản và chống lạm dụng.',
      'Nhật ký sự cố khi phần mềm gặp lỗi.',
    ] },
  ] },
  { h: '3. Thông tin chúng tôi KHÔNG thu thập', body: [
    'Để tránh hiểu nhầm, chúng tôi nêu rõ những gì không bao giờ được gửi về máy chủ:',
    { ul: [
      'Nội dung cookie và token đăng nhập trong các hồ sơ của bạn.',
      'Danh sách website bạn truy cập trong từng hồ sơ.',
      'Tên đăng nhập, mật khẩu của bạn trên các nền tảng bên thứ ba.',
      'Nội dung biểu mẫu, tin nhắn, tài liệu hay bất kỳ dữ liệu nào phát sinh khi duyệt web.',
      'Ảnh chụp màn hình hoặc bản ghi thao tác bên trong hồ sơ.',
    ] },
    'Nhật ký sự cố cũng không bao gồm cookie, mật khẩu hay nội dung trang web.',
  ] },
  { h: '4. Cách chúng tôi sử dụng dữ liệu', body: [
    { ul: [
      'Cung cấp, duy trì và cải thiện phần mềm cùng các dịch vụ liên quan.',
      'Xác thực tài khoản và cấp quyền truy cập theo gói dịch vụ.',
      'Xử lý giao dịch và quản lý gói dịch vụ của bạn.',
      'Vận hành tính năng nhóm: mời thành viên, phân quyền, khóa hồ sơ đang được sử dụng, ghi nhật ký hoạt động.',
      'Gửi thông báo quan trọng về bảo mật, cập nhật hoặc thay đổi dịch vụ.',
      'Cung cấp hỗ trợ kỹ thuật và xử lý khiếu nại.',
      'Phát hiện, ngăn chặn gian lận và bảo đảm an toàn hệ thống.',
    ] },
  ] },
  { h: '5. Chia sẻ dữ liệu', body: [
    'Chúng tôi không bán, không cho thuê, không trao đổi dữ liệu cá nhân của bạn. Dữ liệu chỉ được chia sẻ trong các trường hợp giới hạn sau:',
    '5.1. Nhà cung cấp dịch vụ. Đối tác thanh toán, hạ tầng máy chủ, dịch vụ gửi email - chỉ tiếp cận thông tin cần thiết cho công việc của họ, theo hợp đồng bảo mật.',
    '5.2. Yêu cầu pháp luật. Khi có yêu cầu hợp pháp từ cơ quan nhà nước có thẩm quyền, tòa án hoặc cơ quan thi hành án.',
    '5.3. Bảo vệ quyền lợi. Khi cần phát hiện, ngăn chặn gian lận, tấn công hệ thống hoặc bảo vệ quyền lợi hợp pháp của chúng tôi và người dùng khác.',
    '5.4. Chuyển giao doanh nghiệp. Trong trường hợp sáp nhập, mua bán hoặc tái cơ cấu, dữ liệu có thể được chuyển giao cho bên tiếp nhận với cam kết duy trì mức bảo vệ tương đương. Chúng tôi sẽ thông báo trước.',
    '5.5. Trong phạm vi không gian làm việc. Chủ sở hữu và quản trị viên có thể xem thông tin hoạt động của thành viên trong nhóm: hồ sơ đã tạo, thời điểm truy cập, thiết bị đang giữ hồ sơ. Đây là tính năng quản lý nhóm mà bạn chấp nhận khi tham gia không gian làm việc của người khác.',
  ] },
  { h: '6. Cookie trên website', body: [
    'Website của chúng tôi sử dụng cookie để duy trì phiên đăng nhập, ghi nhớ tùy chọn giao diện và phân tích lưu lượng truy cập ở dạng thống kê tổng hợp. Bạn có thể quản lý hoặc chặn cookie trong cài đặt trình duyệt.',
    'Lưu ý phân biệt: cookie của website CGTBrowser hoàn toàn khác với cookie bên trong các hồ sơ trình duyệt bạn tạo. Hai loại này độc lập với nhau.',
  ] },
  { h: '7. Bảo mật', body: [
    'Chúng tôi áp dụng các biện pháp kỹ thuật và tổ chức hợp lý để bảo vệ dữ liệu:',
    { ul: [
      'Mã hóa dữ liệu hồ sơ khi lưu trên máy bạn.',
      'Mã hóa dữ liệu trước khi truyền khi bạn bật đồng bộ.',
      'Kết nối giữa phần mềm và máy chủ được mã hóa.',
      'Mật khẩu tài khoản lưu dưới dạng băm một chiều.',
      'Phân quyền truy cập nội bộ theo nguyên tắc tối thiểu cần thiết.',
    ] },
    'Tuy nhiên, không có phương thức nào an toàn tuyệt đối. Bạn cũng cần đặt mật khẩu mạnh, không chia sẻ thông tin đăng nhập và giữ thiết bị của mình an toàn.',
    'Với dữ liệu đồng bộ, việc bảo mật kho lưu trữ do bạn cấu hình thuộc trách nhiệm của bạn và chịu sự điều chỉnh bởi điều khoản của nhà cung cấp dịch vụ lưu trữ đó.',
  ] },
  { h: '8. Quyền của bạn', body: [
    'Tùy theo quy định pháp luật áp dụng, bạn có thể có các quyền sau:',
    { ul: [
      'Truy cập: yêu cầu biết chúng tôi đang lưu những thông tin gì về bạn.',
      'Chỉnh sửa: cập nhật thông tin không chính xác.',
      'Xóa: yêu cầu xóa tài khoản và dữ liệu liên quan.',
      'Xuất dữ liệu: yêu cầu bản sao dữ liệu ở định dạng đọc được.',
      'Từ chối: tắt các tính năng thu thập tùy chọn như gửi nhật ký sự cố.',
      'Rút lại đồng ý: tắt đồng bộ bất cứ lúc nào.',
    ] },
    'Vui lòng liên hệ để thực hiện các quyền này.',
  ] },
  { h: '9. Lưu giữ dữ liệu', body: [
    'Chúng tôi chỉ lưu giữ dữ liệu trong thời gian cần thiết để cung cấp dịch vụ hoặc theo yêu cầu của pháp luật:',
    { ul: [
      'Thông tin tài khoản: lưu trong suốt thời gian tài khoản còn hoạt động.',
      'Sau khi bạn yêu cầu xóa tài khoản: dữ liệu cá nhân được xóa hoặc ẩn danh hóa, trừ các dữ liệu phải lưu theo nghĩa vụ pháp lý (ví dụ chứng từ giao dịch).',
      'Nhật ký kỹ thuật và báo cáo sự cố: lưu trong thời gian giới hạn phục vụ chẩn đoán, sau đó xóa tự động.',
    ] },
    'Dữ liệu đồng bộ nằm trong kho lưu trữ của bạn, do bạn tự quyết định thời gian lưu giữ.',
  ] },
  { h: '10. Quyền Riêng Tư của Trẻ Em', body: [
    'Dịch vụ không hướng tới người dưới độ tuổi thành niên theo quy định pháp luật. Chúng tôi không kiểm soát được việc trẻ em tự truy cập website hoặc cài đặt ứng dụng khi không có sự giám sát của cha mẹ. Phụ huynh nên đọc Chính sách Bảo mật này trước khi đồng ý cho con em sử dụng ứng dụng và dịch vụ của chúng tôi.',
  ] },
  { h: '11. Thay đổi chính sách', body: [
    'Chính sách này có thể được cập nhật theo thời gian. Phiên bản mới có hiệu lực kể từ khi được đăng tải trên trang này. Với thay đổi trọng yếu ảnh hưởng đến quyền của bạn, chúng tôi sẽ thông báo qua email hoặc trong ứng dụng trước khi áp dụng.',
  ] },
  { h: '12. Liên hệ', body: [
    'Mọi câu hỏi về quyền riêng tư, vui lòng liên hệ với chúng tôi qua trang Liên hệ.',
  ] },
];

// Tô thương hiệu "CGTBrowser" trong một chuỗi: chèn <span class="pl"> (màu brand + in
// nghiêng) quanh mỗi lần xuất hiện, giống web landing (app.js → initLegalBrand). Trả về
// mảng các node (text + span) để nhét thẳng vào phần tử cha.
function brandParts(text) {
  const parts = String(text).split('CGTBrowser');
  const out = [];
  parts.forEach((chunk, i) => {
    if (chunk) out.push(document.createTextNode(chunk));
    if (i < parts.length - 1) out.push(el('span.pl', { text: 'CGTBrowser' }));
  });
  return out;
}

// Dịch một đoạn pháp lý theo ngôn ngữ đang chọn (data/legal-i18n.js - bản dịch đã duyệt của web landing). Chủ sở hữu bỏ
// luật "không dịch pháp lý" 2026-10-28 (web) và 2026-11-02 (app). Dịch TRƯỚC khi tách chữ "CGTBrowser" (brandParts), vì
// bộ dịch DOM của i18n.js chỉ khớp NGUYÊN VĂN một text node - đoạn đã bị tách thành nhiều mảnh thì không dịch được.
// Thiếu bản dịch ⇒ giữ tiếng Việt (bản có giá trị pháp lý).
function lt(text) {
  const lang = getLang();
  if (lang === 'vi') return text;
  const e = LEGAL_TR[text];
  return (e && e[lang]) || text;
}

// Dựng một phần tử nội dung pháp lý từ mô tả: chuỗi → <p>; { h5 } / { h6 } → tiêu đề
// phụ; { ul } → danh sách gạch đầu dòng. Trả về null cho mục không hợp lệ (được lọc bỏ).
function legalNode(item) {
  if (typeof item === 'string') return el('p', {}, brandParts(lt(item)));
  if (item && item.h5) return el('h5', {}, brandParts(lt(item.h5)));
  if (item && item.h6) return el('h6', {}, brandParts(lt(item.h6)));
  if (item && item.ul) return el('ul', {}, item.ul.map((li) => el('li', {}, brandParts(lt(li)))));
  return null;
}

// Câu "đồng ý điều khoản" (màn đăng ký + chân màn đăng nhập) dịch NGUYÊN CÂU kèm hai đường link: ghép từng mảnh
// ("Tôi đã đọc và đồng ý với " + link + " và " + link) thì tiếng Nga sai cách (sau "согласен с" phải là cách 5:
// "Условиями…", "Политикой…") và tiếng Trung thừa dấu cách. [..] = chữ của link theo đúng thứ tự: điều khoản, chính sách.
const LEGAL_SENTENCES = {
  agree: {
    vi: 'Tôi đã đọc và đồng ý với [Điều khoản sử dụng] và [Chính sách bảo mật]',
    en: 'I have read and agree to the [Terms of Use] and [Privacy Policy]',
    ru: 'Я прочитал(а) и принимаю [Условия использования] и [Политику конфиденциальности]',
    zh: '我已阅读并同意[使用条款]和[隐私政策]',
  },
  login: {
    vi: 'Đăng nhập đồng nghĩa với việc bạn đồng ý với [Điều khoản sử dụng] và [Chính sách bảo mật]',
    en: 'By signing in, you agree to the [Terms of Use] and [Privacy Policy]',
    ru: 'Выполняя вход, вы принимаете [Условия использования] и [Политику конфиденциальности]',
    zh: '登录即表示您同意[使用条款]和[隐私政策]',
  },
};
// Đổ câu vào `host` theo ngôn ngữ hiện tại. Gọi lại mỗi khi đổi ngôn ngữ (renderLogin → paintLegal): dựng node mới ở
// đúng ngôn ngữ, bộ dịch DOM không đụng tới vì chữ đã dịch không phải khoá DICT.
function fillLegalSentence(host, key) {
  const pat = LEGAL_SENTENCES[key][getLang()] || LEGAL_SENTENCES[key].vi;
  const links = [
    () => openLegalModal('Điều khoản sử dụng', TERMS_SECTIONS),
    () => openLegalModal('Chính sách bảo mật', PRIVACY_SECTIONS),
  ];
  clear(host);
  let n = 0;
  pat.split(/(\[[^\]]+\])/).forEach((part) => {
    if (!part) return;
    const m = /^\[(.+)\]$/.exec(part);
    if (!m) { host.appendChild(document.createTextNode(part)); return; }
    const open = links[n++];
    host.appendChild(el('a.auth-link', { text: m[1], href: '#', onclick: (e) => { e.preventDefault(); open(); } }));
  });
}

export function openLegalModal(title, sections, onAccept) {
  // Cột nội dung (phần cuộn). Mỗi mục có tiêu đề số → sinh 1 dòng mục lục tương ứng.
  const doc = el('div.auth-legal-doc');
  const tocItems = []; // { el, sec }
  // Ngôn ngữ khác tiếng Việt: ghi chú "bản tiếng Việt có giá trị pháp lý" ở đầu (giống trang pháp lý web landing).
  if (getLang() !== 'vi') doc.appendChild(el('p.auth-legal-note', { text: lt(LEGAL_NOTE) }));
  sections.forEach((s) => {
    const head = lt(s.h);
    // Mục được đánh số (vd "6. …") mới vào mục lục; mục không số = tiêu đề tài liệu.
    const m = /^(\d+)\.\s*(.*)$/.exec(head);
    const secEl = el('div.auth-legal-sec', {}, [
      // Tiêu đề tài liệu (không số): giữ chữ "CGTBrowser" đen + không nghiêng (khác thân bài).
      el(m ? 'h4' : 'h4.auth-legal-doctitle', {}, brandParts(head)),
      ...s.body.map(legalNode).filter(Boolean),
    ]);
    doc.appendChild(secEl);
    if (m) {
      const item = el('button.auth-toc-item', {
        onclick: () => doc.scrollTo({ top: Math.max(0, secEl.offsetTop - 6), behavior: 'smooth' }),
      }, [
        el('span.auth-toc-num', { text: m[1] }),
        el('span.auth-toc-label', {}, brandParts(m[2])),
      ]);
      tocItems.push({ el: item, sec: secEl });
    }
  });

  // Scroll-spy: tô sáng mục đang xem theo vị trí cuộn của cột nội dung.
  function setActive() {
    const top = doc.scrollTop;
    let active = 0;
    for (let i = 0; i < tocItems.length; i++) {
      if (tocItems[i].sec.offsetTop - 16 <= top) active = i; else break;
    }
    tocItems.forEach((t, i) => t.el.classList.toggle('is-active', i === active));
  }
  doc.addEventListener('scroll', setActive);
  setTimeout(setActive, 0); // đợi layout xong rồi mới xác định mục đầu

  const toc = el('aside.auth-toc', {}, [
    el('div.auth-toc-title', { text: lt('Nội dung') }),
    el('nav.auth-toc-list', {}, tocItems.map((t) => t.el)),
  ]);

  const body = el('div.auth-legal', {}, tocItems.length ? [toc, doc] : [doc]);
  openModal({
    title,
    width: 1104, // 960 + 15% (rộng hơn cho dễ đọc; .modal tự kẹp theo viewport nếu cửa sổ hẹp)
    body: [body],
    // "Đã hiểu": đóng modal; nếu được mở từ ô tích "đồng ý" thì gọi onAccept để CHÍNH
    // THỨC tích ô (người dùng phải đọc điều khoản rồi mới đồng ý được).
    footer: [el('button.btn.primary', { text: 'Đã hiểu', onclick: () => { closeModal(); if (typeof onAccept === 'function') onAccept(); } })],
  });
}

// Thanh tiến trình trên cùng (#topprogress ở index.html - luôn tồn tại, kể cả màn
// đăng nhập chưa dựng shell). Dùng chung cho submit đăng nhập/đăng ký + Google, để
// trang đăng nhập cũng có phản hồi "đang xử lý" như các trang trong app.
function startBar() {
  const p = document.getElementById('topprogress');
  if (!p) return;
  p.classList.remove('done');
  void p.offsetWidth; // restart animation từ 0
  p.classList.add('active');
}
function endBar() {
  const p = document.getElementById('topprogress');
  if (!p) return;
  p.classList.add('done');
  setTimeout(() => { p.classList.remove('active', 'done'); }, 280);
}

// ---- inline icons (stroke inherits currentColor unless a fill is given) ----
const ICO_MAIL = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M0 0h24v24H0z" fill="none"/><path fill="currentColor" d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2m0 4l-8 5l-8-5V6l8 5l8-5z"/></svg>`;
const ICO_LOCK = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M0 0h24v24H0z" fill="none"/><g fill="none" fill-rule="evenodd"><path d="m12.593 23.258l-.011.002l-.071.035l-.02.004l-.014-.004l-.071-.035q-.016-.005-.024.005l-.004.01l-.017.428l.005.02l.01.013l.104.074l.015.004l.012-.004l.104-.074l.012-.016l.004-.017l-.017-.427q-.004-.016-.017-.018m.265-.113l-.013.002l-.185.093l-.01.01l-.003.011l.018.43l.005.012l.008.007l.201.093q.019.005.029-.008l.004-.014l-.034-.614q-.005-.018-.02-.022m-.715.002a.02.02 0 0 0-.027.006l-.006.014l-.034.614q.001.018.017.024l.015-.002l.201-.093l.01-.008l.004-.011l.017-.43l-.003-.012l-.01-.01z"/><path fill="currentColor" d="M6 8a6 6 0 1 1 12 0h1a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V10a2 2 0 0 1 2-2zm6-4a4 4 0 0 1 4 4H8a4 4 0 0 1 4-4m2 10a2 2 0 0 1-1 1.732V17a1 1 0 1 1-2 0v-1.268A2 2 0 0 1 12 12a2 2 0 0 1 2 2"/></g></svg>`;
const ICO_EYE =`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>`;
const ICO_EYE_OFF = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M9.9 5.2A9.9 9.9 0 0 1 12 5c6.5 0 10 7 10 7a17 17 0 0 1-3 3.8M6.3 6.3A17 17 0 0 0 2 12s3.5 7 10 7a9.7 9.7 0 0 0 4-.85"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/><path d="M3 3l18 18"/></svg>`;
const ICO_GOOGLE = `<svg viewBox="0 0 48 48" width="18" height="18"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg>`;
const ICO_CARET = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg>`;
// Ô "Mã giới thiệu" ở màn đăng ký (chương trình hoa hồng, trang "Hoa hồng").
// ⚠️ ICON do user đưa 2026-10-20 - thay cái HỘP QUÀ cũ (vì thế tên biến còn là `ICO_GIFT`;
// giữ tên để không phải sửa hai chỗ gọi, nội dung mới là đồng xu/giảm giá có tia).
// GIỮ NGUYÊN markup gốc user dán: `stroke="currentColor"` + `fill="none"` khai trên <g>,
// `stroke-width="1.5"` (các icon khác của tệp này là 1.7 - ĐỪNG "đồng bộ" lại, đó là nét của
// chính icon này), cả `<path d="M0 0h24v24H0z" fill="none">` đệm khung 24×24.
// ⛔ ĐỪNG đổi sang `fill="currentColor"`: icon vẽ bằng ĐƯỜNG VIỀN, tô đặc là ra một khối đen.
// ⚠️ PHẢI khớp y hệt bản web (web landing anti-browser/public/auth.html → .auth-inp-ico):
// hai bản lệch icon là cùng một ô "Mã giới thiệu" mà app và web trông khác nhau.
const ICO_GIFT = `<svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path d="M0 0h24v24H0z" fill="none"/><g fill="none" stroke="currentColor" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M21.964 4.506s.177-1.785-.255-2.216m0 0c-.433-.433-2.215-.253-2.215-.253m2.215.253L19 5m2.964 14.494s.177 1.785-.255 2.215m0 0c-.433.434-2.215.254-2.215.254m2.215-.254L19 19M2.29 2.29L5 5M2.29 2.29c.434-.433 2.216-.253 2.216-.253M2.29 2.29c-.43.431-.254 2.216-.254 2.216M2.29 21.71L5 19m-2.71 2.71c.434.433 2.216.253 2.216.253m-2.216-.254c-.43-.43-.254-2.215-.254-2.215"/><path d="M19 12a7 7 0 1 1-14 0a7 7 0 0 1 14 0Z"/><path stroke-linecap="round" d="M11.914 9.301c-1.105 0-1.914.642-1.914 1.388s.522 1.21 2 1.21c1.628 0 2 .743 2 1.489c0 .745-.712 1.333-2.086 1.333m0-5.42c.87 0 1.331.305 1.695.716M11.914 9.3v-.844m0 6.264c-.87 0-1.21-.172-1.689-.606m1.689.606v.788"/></g></svg>`;

// f = icon lá cờ (icons.js) - CÙNG bộ cờ với nút ngôn ngữ ở header app chính (app.js LANG_FLAG).
const LANGS = [
  { c: 'vi', n: 'Tiếng Việt', s: 'VN', f: 'flagVi' },
  { c: 'en', n: 'English', s: 'EN', f: 'flagEn' },
  { c: 'ru', n: 'Русский', s: 'RU', f: 'flagRu' },
  { c: 'zh', n: '中文', s: 'ZH', f: 'flagZh' },
];

export function renderLogin(container, { onSuccess } = {}) {
  clear(container);
  let mode = 'login'; // 'login' | 'register' | 'otp' | 'forgot'

  const errorBox = el('div.auth-error', { style: { display: 'none' } });

  // Regex email chuẩn HTML5 - YÊU CẦU có TLD (ít nhất một ".<nhãn>" sau tên miền), nên
  // "a@gmail" (thiếu dấu chấm) là KHÔNG hợp lệ. Ký tự hợp lệ ở local-part + domain nhiều nhãn.
  const EMAIL_RE = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/;

  // Whitelist mail-rác ĐÃ BỎ theo yêu cầu: mọi email đúng định dạng đều đăng ký được.
  // Chống tạo tài khoản tự động/bot nay do Cloudflare Turnstile đảm nhiệm (ở server).

  // --- Khung validate từng ô (kiểu AdsPower): ô nào trống/sai định dạng → viền đỏ +
  // dòng chữ đỏ NGAY dưới ô. Chỉ báo sau khi ô đã được "chạm" (focus) để form không
  // đỏ rực ngay lúc mở; submit sẽ đánh dấu-chạm hết các ô đang hiển thị rồi validate. ---
  const touched = new Set();
  const fieldInputs = {};       // kind -> input element
  const fieldRefreshers = [];   // các hàm vẽ-lại trạng thái lỗi của từng ô
  function fieldMsg(kind, value) {
    const v = (value || '').trim();
    if (kind === 'email') {
      // Cho phép nhập nhanh 'admin' hoặc email đầy đủ
      if (v.toLowerCase() === 'admin') return '';
      // Whitelist (mail tạm/rác) KHÔNG báo đỏ inline nữa - đã có MODAL riêng khi đăng ký.
      return !v ? 'Vui lòng nhập email' : (!EMAIL_RE.test(v) ? 'Email không đúng định dạng' : '');
    }
    if (kind === 'code')  return !v ? 'Vui lòng nhập mã xác nhận' : (v.length < 6 ? 'Mã xác nhận gồm 6 số' : '');
    if (kind === 'pass') {
      if (!v) return mode === 'forgot' ? 'Vui lòng nhập mật khẩu mới' : 'Vui lòng nhập mật khẩu';
      if ((mode === 'register' || mode === 'forgot') && v.length < 6) return 'Mật khẩu tối thiểu 6 ký tự';
      return '';
    }
    return '';
  }
  function wireField(input, errEl, kind, filter) {
    fieldInputs[kind] = input;
    const refresh = () => {
      const msg = touched.has(kind) ? fieldMsg(kind, input.value) : '';
      errEl.textContent = msg;
      errEl.style.display = msg ? 'block' : 'none';
      input.classList.toggle('is-invalid', !!msg);
    };
    fieldRefreshers.push(refresh);
    input.addEventListener('focus', () => { touched.add(kind); });
    input.addEventListener('input', () => {
      if (filter) { const v = input.value.replace(filter, ''); if (v !== input.value) input.value = v; }
      refresh();
    });
    input.addEventListener('blur', () => { touched.add(kind); refresh(); });
    return refresh;
  }
  function refreshAllFields() { fieldRefreshers.forEach((fn) => fn()); }
  // Đánh dấu-chạm + validate danh sách ô; trả về true nếu TẤT CẢ hợp lệ.
  function validateFields(kinds) {
    kinds.forEach((k) => touched.add(k));
    refreshAllFields();
    return kinds.every((k) => !fieldMsg(k, fieldInputs[k] && fieldInputs[k].value));
  }

  const emailInput = el('input.auth-input', { type: 'text', placeholder: 'Nhập email', autocomplete: 'username' });
  const emailErr = el('div.auth-inline-err', { style: { display: 'none' } });
  // KHÔNG lọc ký tự khi gõ email: cho nhập bình thường (kể cả có dấu). Việc kiểm tra
  // định dạng email vẫn do fieldMsg('email', …) đảm nhiệm lúc validate.
  wireField(emailInput, emailErr, 'email');

  const passInput = el('input.auth-input', { type: 'password', placeholder: 'Nhập mật khẩu', autocomplete: 'current-password' });
  const passErr = el('div.auth-inline-err', { style: { display: 'none' } });
  wireField(passInput, passErr, 'pass');

  // Eye toggle inside the password box (show / hide the typed password).
  const eyeBtn = el('button.auth-inp-act', { type: 'button', html: ICO_EYE, title: 'Hiện mật khẩu' });
  eyeBtn.onclick = () => {
    const show = passInput.type === 'password';
    passInput.type = show ? 'text' : 'password';
    eyeBtn.innerHTML = show ? ICO_EYE_OFF : ICO_EYE;
    eyeBtn.title = show ? 'Ẩn mật khẩu' : 'Hiện mật khẩu';
  };

  // "Ghi nhớ mật khẩu": bật (mặc định) = nhớ email + MẬT KHẨU (điền sẵn form) +
  // giữ phiên đăng nhập (session 365d); tắt = quên thông tin + xoá phiên khi thoát
  // app. Cờ ở localStorage; email + mật khẩu lưu MÃ HOÁ ở main (safeStorage/DPAPI).
  const REMEMBER_KEY = 'polyRememberLogin';
  const remembered = localStorage.getItem(REMEMBER_KEY) !== '0'; // mặc định true
  let hadSavedCred = false;

  const rememberChk = el('input', { type: 'checkbox' });
  rememberChk.checked = remembered;
  const rememberRow = el('label.auth-remember', {}, [
    rememberChk,
    el('span', { text: 'Ghi nhớ mật khẩu' }),
  ]);

  // "Tôi đã đọc và đồng ý…": chỉ hiện ở màn đăng ký; bắt buộc tích trước khi Đăng ký.
  const agreeChk = el('input', { type: 'checkbox' });
  const agreeErr = el('div.auth-inline-err', { style: { display: 'none' } });
  const agreeText = el('span');
  const agreeRow = el('label.auth-agree', {}, [agreeChk, agreeText]);
  // Bấm ô tích khi CHƯA đồng ý → KHÔNG tự tích ngay: chặn lại, mở modal Điều khoản
  // dịch vụ; chỉ khi người dùng bấm "Đã hiểu" thì ô mới thực sự checked=true. Đang tích
  // sẵn mà bấm để BỎ tích thì cho phép bình thường (không cần mở modal).
  agreeChk.addEventListener('click', (e) => {
    // Trong sự kiện click của checkbox, .checked đã là trạng thái SAU khi lật: true =
    // người dùng vừa định BẬT → chặn (preventDefault revert về false) rồi hỏi điều khoản.
    if (agreeChk.checked) {
      e.preventDefault();
      openLegalModal('Điều khoản sử dụng', TERMS_SECTIONS, () => {
        agreeChk.checked = true;
        agreeErr.style.display = 'none';
        agreeRow.classList.remove('is-invalid');
      });
    }
  });

  const forgotLink = el('button.auth-forgot', { type: 'button', text: 'Quên mật khẩu?' });

  const submitBtn = el('button.auth-submit', { type: 'submit', text: 'Đăng nhập' });

  const switchLink = el('button.auth-switch', { type: 'button' });
  const title = el('h2.auth-title', { text: 'Đăng nhập' });

  // --- login-only blocks below the button (hidden in register mode) ---
  const dividerEl = el('div.auth-divider', {}, [
    el('span', { text: 'Người dùng mới sẽ tự động đăng ký tài khoản' }),
  ]);
  const gBtn = el('button.auth-soc.auth-soc-google', { type: 'button' }, [
    el('span.auth-soc-ico', { html: ICO_GOOGLE }),
    el('span', { text: 'Đăng nhập với Google' }),
  ]);
  const socialEl = el('div.auth-social', {}, [gBtn]);

  const termsEl = el('div.auth-terms');
  // Hai câu đồng ý điều khoản - dựng lại theo ngôn ngữ mỗi khi đổi (xem fillLegalSentence).
  const paintLegal = () => { fillLegalSentence(agreeText, 'agree'); fillLegalSentence(termsEl, 'login'); };

  // --- Các field tách ra biến để bật/tắt theo chế độ (login / register / forgot) ---
  const emailField = el('div.auth-field', {}, [
    el('label.auth-lbl', { text: 'Email' }),
    el('div.auth-inp', {}, [
      el('span.auth-inp-ico', { html: ICO_MAIL }),
      emailInput,
    ]),
    emailErr,
  ]);
  const passLabel = el('label.auth-lbl', { text: 'Mật khẩu' });
  const passField = el('div.auth-field', {}, [
    el('div.auth-lbl-row', {}, [
      passLabel,
      forgotLink,
    ]),
    el('div.auth-inp', {}, [
      el('span.auth-inp-ico', { html: ICO_LOCK }),
      passInput,
      eyeBtn,
    ]),
    passErr,
  ]);

  // --- Ô "Mã giới thiệu" (TUỲ CHỌN, chỉ hiện ở màn đăng ký) ---
  // Chương trình hoa hồng: người mới gõ mã của người giới thiệu → cả hai bên được thưởng
  // (xem trang "Hoa hồng", views/affiliate.js). Để TRỐNG là hợp lệ và là trường hợp
  // THƯỜNG GẶP NHẤT, nên ô này:
  //   • KHÔNG đi qua wireField (không có kind trong fieldMsg/validateFields) - thêm vào đó
  //     là biến ô tuỳ chọn thành ô bắt buộc, chặn đăng ký của mọi người không có mã.
  //   • chỉ báo lỗi SAU khi server từ chối (code REF_CODE_INVALID), và báo NGAY TẠI ô này
  //     chứ không ở hộp lỗi chung: lỗi duy nhất có thể xảy ra là "mã không tồn tại", mà
  //     người dùng cần biết là phải sửa Ô NÀY, không phải email/mật khẩu.
  //
  // Lọc lúc gõ: HOA hoá + bỏ ký tự không phải chữ/số (người ta hay dán "ABCD-2345"), rồi
  // kẹp 8 ký tự. maxlength đặt 16 CHỨ KHÔNG 8: maxlength chặn TRƯỚC khi handler input chạy,
  // nên dán "ABCD-2345" (9 ký tự) vào ô maxlength=8 sẽ bị nhân cắt còn "ABCD-234" → lọc ra
  // "ABCD234" = 7 ký tự, mã hỏng mà không ai thấy. Để rộng rồi tự slice sau khi lọc.
  // KHÔNG gạt O/0/I/L ở client dù bộ chữ của server không có chúng: gõ xong thấy ký tự tự
  // biến mất thì người dùng tưởng bàn phím lỗi. Server đã gạt khi so sánh và sẽ trả
  // "mã không tồn tại" - đúng với sự thật là họ gõ sai.
  const refInput = el('input.auth-input.auth-ref-input', {
    type: 'text', maxlength: '16', autocomplete: 'off', spellcheck: 'false',
    // ⚠️ Placeholder phải ĐỒNG NHẤT với web landing (user chốt 2026-10-20). Cùng một câu
    // "Không bắt buộc" ở cả hai nơi; ĐỪNG đổi riêng một bên.
    // Khoá i18n 'Không bắt buộc' ĐÃ CÓ SẴN trong DICT (en Optional / ru / zh) - ĐỪNG khai lại:
    // DICT là object literal, khoá trùng thì bản sau lặng lẽ thắng bản trước.
    placeholder: 'Không bắt buộc',
  });
  const refErr = el('div.auth-inline-err', { style: { display: 'none' } });
  refInput.addEventListener('input', () => {
    const v = refInput.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8);
    if (v !== refInput.value) refInput.value = v;
    // Người dùng vừa sửa mã → thu lỗi cũ của server lại, đừng để câu "không tồn tại" treo
    // trên một mã đã khác.
    if (refErr.style.display !== 'none') { refErr.style.display = 'none'; refInput.classList.remove('is-invalid'); }
  });
  const refField = el('div.auth-field', {}, [
    // ⚠️ NHÃN TRẦN, KHÔNG còn "(không bắt buộc)" (user chốt 2026-10-20: "bỏ chữ không bắt buộc
    // ở label"). Ô vẫn không bắt buộc thật - placeholder "Không bắt buộc" đã nói đủ, và không
    // có phép kiểm nào đòi nó.
    // ⛔ ĐỪNG đổi lại thành 'Mã giới thiệu (không bắt buộc)': khoá i18n cho câu đó đã bị xoá
    // khỏi i18n.js cùng lượt này ⇒ en/ru/zh sẽ in nguyên tiếng Việt.
    el('label.auth-lbl', { text: 'Mã giới thiệu' }),
    el('div.auth-inp', {}, [
      el('span.auth-inp-ico', { html: ICO_GIFT }),
      refInput,
    ]),
    refErr,
  ]);
  // Gán chuỗi TIẾNG VIỆT thô (không bọc t()) - y như wireField/agreeErr: MutationObserver
  // của i18n dịch text node mới khi ngôn ngữ khác tiếng Việt. Bọc t() ở đây là dịch HAI LẦN.
  function showRefErr(msg) {
    refErr.textContent = msg || '';
    refErr.style.display = msg ? 'block' : 'none';
    refInput.classList.toggle('is-invalid', !!msg);
  }

  // --- Khối riêng cho màn "Quên mật khẩu" (đặt lại mật khẩu qua mã OTP email) ---
  // Mô tả hướng dẫn (hiện suốt màn forgot): nhập email → nhận mã → đặt mật khẩu mới.
  const forgotDesc = el('div.auth-forgot-desc', {
    text: 'Nhập email tài khoản, bấm "Nhận mã xác minh" để nhận mã qua email, rồi nhập mã và mật khẩu mới để đặt lại.',
  });
  // Link quay lại đăng nhập (ở chân thẻ, chỉ hiện trong màn forgot).
  // text + ký tự "←" thẳng (không '&larr;'): chuỗi trong mã phải KHỚP CHÍNH XÁC chuỗi trong
  // DOM để bộ dịch tra được từ điển - xem ghi chú ở chỗ gán backLink.textContent bên dưới.
  const backLink = el('button.auth-switch', { type: 'button', text: '← Quay lại đăng nhập', style: { display: 'none' } });

  // --- Xác thực email bằng OTP NGAY TRÊN FORM đăng ký (kiểu AdsPower) ---
  // Ô "Mã xác thực" nằm giữa email và mật khẩu, có nút "Gửi mã" bên phải. Người dùng
  // nhập email → bấm Gửi mã → nhận mã ở email → nhập mã + mật khẩu → bấm Đăng ký (submit
  // gửi kèm mã, server xác thực rồi mới tạo tài khoản). Không có màn OTP riêng.
  let resendTimer = null;    // setInterval đếm ngược nút "Gửi mã"
  let cooldownActive = false;

  const otpInput = el('input.auth-input.auth-otp-input', {
    type: 'text', inputmode: 'numeric', maxlength: '6',
    placeholder: 'Nhập mã xác nhận', autocomplete: 'one-time-code',
  });
  const codeErr = el('div.auth-inline-err', { style: { display: 'none' } });
  wireField(otpInput, codeErr, 'code', /\D/g);   // chỉ giữ chữ số, validate ngay khi gõ
  // Nút "Nhận mã xác minh" nằm NGOÀI ô mã (bên phải, cùng hàng ngang) - bấm để gửi OTP tới
  // email đang nhập. Bố cục theo mẫu AdsPower: ô nhập mã + nút tách rời trên một hàng.
  const sendCodeBtn = el('button.auth-sendcode', { type: 'button', text: 'Nhận mã xác minh' });
  const codeField = el('div.auth-field', {}, [
    el('label.auth-lbl', { text: 'Mã xác nhận' }),
    el('div.auth-code-row', {}, [
      el('div.auth-inp', {}, [
        el('span.auth-inp-ico', { html: ICO_MAIL }),
        otpInput,
      ]),
      sendCodeBtn,
    ]),
    codeErr,
  ]);
  // Gợi ý mã ở chế độ DEV (server chưa cấu hình SMTP → không gửi mail thật, trả devCode).
  const otpDevHint = el('div.auth-otp-dev', { style: { display: 'none' } });

  function stopCooldown() {
    if (resendTimer) { clearInterval(resendTimer); resendTimer = null; }
    cooldownActive = false;
    sendCodeBtn.disabled = false;
    sendCodeBtn.textContent = 'Nhận mã xác minh';
  }
  function startResendCooldown(sec = 60) {
    stopCooldown();
    cooldownActive = true;
    let left = sec;
    sendCodeBtn.disabled = true;
    // "Gửi lại (Ns)" có phần đếm động → dịch phần chữ bằng t() để đúng ngữ pháp
    // ngôn ngữ đang chọn (observer không khớp được chuỗi có số thay đổi).
    sendCodeBtn.textContent = `${t('Gửi lại')} (${left}s)`;
    resendTimer = setInterval(() => {
      left -= 1;
      if (left <= 0) { stopCooldown(); sendCodeBtn.textContent = t('Gửi lại'); return; }
      sendCodeBtn.textContent = `${t('Gửi lại')} (${left}s)`;
    }, 1000);
  }

  // Vẽ lại hộp lỗi. Dùng linkifyNodes chứ KHÔNG `textContent = msg`: thông báo hết giới hạn
  // thiết bị do server trả về có kèm https://cgtdev.space/ - đó là LỐI THOÁT duy nhất của
  // khách (mua thêm/gỡ bớt thiết bị), để dạng chữ thường thì họ phải tự bôi đen rồi copy.
  // Vẫn an toàn với message bất kỳ của server: linkifyNodes chỉ sinh Text node + <a>, không
  // chạm innerHTML. clear() trước là bắt buộc - gán textContent='' không xoá được các <a> cũ
  // nếu sau này ai đổi lại, còn ở đây nó dọn toàn bộ con của lần báo lỗi trước.
  function showError(msg) {
    clear(errorBox);
    if (msg) linkifyNodes(msg).forEach((n) => errorBox.appendChild(n));
    errorBox.style.display = msg ? 'block' : 'none';
  }

  function applyMode() {
    showError('');
    const reg = mode === 'register';
    const forgot = mode === 'forgot';
    const login = mode === 'login';

    // Mô tả hướng dẫn của màn forgot.
    forgotDesc.style.display = forgot ? 'block' : 'none';

    // Các field. Màn forgot dùng lại: email + mã OTP + ô mật khẩu (làm mật khẩu MỚI).
    emailField.style.display = 'flex';
    codeField.style.display = (reg || forgot) ? 'flex' : 'none';          // ô mã OTP ở đăng ký & quên mật khẩu
    otpDevHint.style.display = ((reg || forgot) && otpDevHint.textContent) ? 'block' : 'none';
    passField.style.display = (login || reg || forgot) ? 'flex' : 'none'; // forgot: ô mật khẩu mới
    // Mã giới thiệu CHỈ ở màn đăng ký: nó chỉ có nghĩa lúc TẠO tài khoản (ràng buộc người
    // giới thiệu một lần duy nhất). Màn forgot cũng dùng lại email+OTP+mật khẩu nên nếu để
    // theo (reg || forgot) thì người đi đặt lại mật khẩu sẽ thấy ô này và tưởng mình nhập
    // được mã muộn - server không bao giờ đọc nó ở luồng đó.
    refField.style.display = reg ? 'flex' : 'none';
    if (!reg) showRefErr('');
    agreeRow.style.display = reg ? 'flex' : 'none';            // đồng ý điều khoản chỉ ở màn đăng ký
    if (!reg) { agreeErr.style.display = 'none'; agreeRow.classList.remove('is-invalid'); }
    rememberRow.style.display = login ? 'flex' : 'none';
    forgotLink.style.display = login ? 'block' : 'none';
    submitBtn.style.display = 'block';
    dividerEl.style.display = login ? 'flex' : 'none';
    socialEl.style.display = login ? 'flex' : 'none';
    termsEl.style.display = login ? 'block' : 'none';

    title.textContent = forgot ? 'Đặt lại mật khẩu' : reg ? 'Tạo tài khoản' : 'Đăng nhập';
    submitBtn.textContent = forgot ? 'Đặt lại mật khẩu' : reg ? 'Đăng ký' : 'Đăng nhập';
    passLabel.textContent = forgot ? 'Mật khẩu mới' : 'Mật khẩu';
    passInput.setAttribute('autocomplete', (reg || forgot) ? 'new-password' : 'current-password');

    // Chân thẻ: forgot → link quay lại; còn lại → link chuyển login/register.
    switchLink.style.display = forgot ? 'none' : 'block';
    backLink.style.display = forgot ? 'block' : 'none';
    // Ký tự "←" viết THẲNG, không dùng '&larr;': entity làm chuỗi trong mã nguồn khác chuỗi
    // trong DOM (đã giải mã) ⇒ khoá từ điển không khớp, câu này đứng lại tiếng Việt. Gán bằng
    // textContent + t() để dịch ngay, không chờ MutationObserver.
    if (forgot) backLink.textContent = t('← Quay lại đăng nhập');
    if (!forgot) {
      switchLink.innerHTML = reg
        ? 'Đã có tài khoản? <b>Đăng nhập</b>'
        : 'Không có tài khoản CGTBrowser ? <b>Đăng ký</b>';
    }
  }

  // Đổi chế độ → xoá trạng thái "đã chạm" để form mới không kế thừa viền đỏ của form cũ.
  function resetValidation() {
    touched.clear();
    refreshAllFields();
    agreeErr.style.display = 'none';
    agreeRow.classList.remove('is-invalid');
  }
  switchLink.onclick = () => {
    mode = mode === 'login' ? 'register' : 'login';
    if (mode !== 'register') stopCooldown();  // rời màn đăng ký → dừng đếm ngược Gửi mã
    resetValidation();
    applyMode();
  };
  // Vào màn quên mật khẩu: xoá ô mật khẩu/mã cũ để không kế thừa từ màn đăng nhập.
  forgotLink.onclick = () => {
    mode = 'forgot';
    passInput.value = ''; otpInput.value = ''; otpDevHint.textContent = '';
    stopCooldown();
    resetValidation(); applyMode();
    setTimeout(() => emailInput.focus(), 40);
  };
  backLink.onclick = () => {
    mode = 'login';
    passInput.value = ''; otpInput.value = ''; otpDevHint.textContent = '';
    stopCooldown();
    resetValidation(); applyMode();
    setTimeout(() => emailInput.focus(), 40);
  };

  // Màn "Quên mật khẩu": email + mã OTP + mật khẩu mới → gọi resetPassword. Thành công
  // → quay lại màn đăng nhập với email điền sẵn để người dùng đăng nhập bằng mật khẩu mới.
  async function submitForgot() {
    if (!validateFields(['email', 'code', 'pass'])) return;
    const email = emailInput.value.trim();
    const code = otpInput.value.trim();
    const newPassword = passInput.value;

    busy = true;
    submitBtn.disabled = true;
    submitBtn.textContent = 'Đang đặt lại…';
    showError('');
    startBar();
    try {
      const res = await vt.auth.resetPassword({ email, code, newPassword });
      if (res && res.ok) {
        stopCooldown();
        toast('Đặt lại mật khẩu thành công. Vui lòng đăng nhập lại.', 'ok');
        // Về màn đăng nhập, giữ email, xoá mật khẩu/mã để nhập lại.
        mode = 'login';
        passInput.value = ''; otpInput.value = ''; otpDevHint.textContent = '';
        resetValidation();
        applyMode();
        emailInput.value = email;
        setTimeout(() => passInput.focus(), 40);
        return;
      }
      const c = res && res.code;
      const msg =
        c === 'OTP_INVALID' ? ((res && res.error) || 'Mã xác thực không đúng')
        : c === 'OTP_EXPIRED' ? 'Mã xác thực đã hết hạn, hãy bấm "Gửi lại" để lấy mã mới'
        : c === 'OTP_TOO_MANY' ? 'Nhập sai quá nhiều lần, hãy bấm "Gửi lại" để lấy mã mới'
        : c === 'OTP_NOT_FOUND' ? 'Bạn chưa lấy mã hoặc mã đã hết hạn, hãy bấm "Nhận mã xác minh"'
        : c === 'ACCOUNT_NOT_FOUND' ? 'Email này chưa được đăng ký'
        : c === 'PASSWORD_TOO_SHORT' ? 'Mật khẩu mới tối thiểu 6 ký tự'
        : c === 'ACCOUNT_INACTIVE' ? 'Tài khoản đã bị khóa'
        : c === 'NETWORK' ? 'Không kết nối được máy chủ. Kiểm tra server đã chạy chưa.'
        : (res && res.error) || 'Đặt lại mật khẩu thất bại';
      showError(msg);
    } catch (e) {
      showError(String(e && e.message || e));
    } finally {
      busy = false;
      submitBtn.disabled = false;
      submitBtn.textContent = 'Đặt lại mật khẩu';
      endBar();
    }
  }

  let busy = false;
  async function submit() {
    if (busy) return;
    if (mode === 'forgot') { submitForgot(); return; }
    const email = emailInput.value.trim();
    const password = passInput.value;

    if (mode === 'register') {
      // Đăng ký kiểu AdsPower: đã xác minh email bằng mã OTP → submit kèm mã + mật khẩu.
      const code = otpInput.value.trim();
      // Mã giới thiệu KHÔNG vào validateFields (ô tuỳ chọn - xem ghi chú ở chỗ tạo refField).
      const refCode = refInput.value.trim();
      if (!validateFields(['email', 'code', 'pass'])) return;
      if (!agreeChk.checked) {
        agreeErr.textContent = 'Vui lòng đọc và đồng ý với điều khoản trước khi đăng ký';
        agreeErr.style.display = 'block';
        agreeRow.classList.add('is-invalid');
        return;
      }

      busy = true;
      submitBtn.disabled = true;
      submitBtn.textContent = 'Đang đăng ký…';
      showError('');
      showRefErr('');
      startBar();
      try {
        // ⚠️ `refCode` phải đi hết chuỗi preload → ipc.js → main/remote.js → server, và
        // mỗi hop đều có thể NUỐT nó mà không phát ra tiếng nào: thiếu khoá ở destructure
        // hoặc ở thân POST của `verifyRegisterOtp` (main/remote.js), destructure danh sách
        // khoá cố định ở preload/ipc, hoặc schema body ở `auth.routes.js` chưa khai refCode
        // (hôm nay vẫn đi qua được, nhưng sập ngay khi ai bật additionalProperties:false).
        // Triệu chứng của mọi hop: đăng ký THÀNH CÔNG, không lỗi, không log - chỉ là người
        // giới thiệu mãi không thấy hoa hồng. Giữ bằng `server/test/_t-app-refcode-live.js`.
        const res = await vt.auth.verifyOtp({ email, code, password, refCode });
        if (res && res.ok) {
          const keep = rememberChk.checked;
          localStorage.setItem(REMEMBER_KEY, keep ? '1' : '0');
          try {
            if (keep) await vt.auth.cred.save({ email, password });
            else await vt.auth.cred.clear();
          } catch { /* ignore */ }
          try { vt.settings.set({ rememberLogin: keep }); } catch { /* ignore */ }
          stopCooldown();
          toast('Tạo tài khoản thành công', 'ok');
          if (onSuccess) onSuccess(res.data.account);
          return;
        }
        const c = res && res.code;
        // Mã giới thiệu sai → báo NGAY TẠI Ô đó rồi dừng, KHÔNG đổ vào hộp lỗi chung: tài
        // khoản chưa được tạo (server chặn trước khi ghi), và thứ duy nhất cần sửa là ô này.
        // Mã OTP vẫn còn hiệu lực nên người dùng chỉ việc xoá/sửa mã rồi bấm lại.
        if (c === 'REF_CODE_INVALID') { showRefErr('Mã giới thiệu không tồn tại'); refInput.focus(); return; }
        const msg =
          c === 'OTP_INVALID' ? ((res && res.error) || 'Mã xác thực không đúng')
          : c === 'OTP_EXPIRED' ? 'Mã xác thực đã hết hạn, hãy bấm "Gửi lại" để lấy mã mới'
          : c === 'OTP_TOO_MANY' ? 'Nhập sai quá nhiều lần, hãy bấm "Gửi lại" để lấy mã mới'
          : c === 'OTP_NOT_FOUND' ? 'Bạn chưa lấy mã hoặc mã đã hết hạn, hãy bấm "Gửi mã"'
          : c === 'EMAIL_TAKEN' ? 'Email này đã được đăng ký'
          : c === 'EMAIL_INVALID' ? 'Email không đúng định dạng'
          : c === 'NETWORK' ? 'Không kết nối được máy chủ. Kiểm tra server đã chạy chưa.'
          : (res && res.error) || 'Đăng ký thất bại';
        showError(msg);
      } catch (e) {
        showError(String(e && e.message || e));
      } finally {
        busy = false;
        submitBtn.disabled = false;
        submitBtn.textContent = 'Đăng ký';
        endBar();
      }
      return;
    }

    // ----- Đăng nhập -----
    if (!validateFields(['email', 'pass'])) return;
    busy = true;
    submitBtn.disabled = true;
    submitBtn.textContent = 'Đang đăng nhập…';
    showError('');
    startBar();
    try {
      const res = await vt.auth.login({ email, password });
      if (res && res.ok) {
        const keep = rememberChk.checked;
        localStorage.setItem(REMEMBER_KEY, keep ? '1' : '0');
        try {
          if (keep) await vt.auth.cred.save({ email, password });
          else await vt.auth.cred.clear();
        } catch { /* ignore - không chặn đăng nhập nếu lưu lỗi */ }
        try { vt.settings.set({ rememberLogin: keep }); } catch { /* ignore */ }
        toast('Đăng nhập thành công', 'ok');
        if (onSuccess) onSuccess(res.data.account);
        return;
      }
      const code = res && res.code;
      const msg =
        code === 'BAD_CREDENTIALS' ? 'Email hoặc mật khẩu không đúng'
        : code === 'EMAIL_TAKEN' ? 'Email này đã được đăng ký'
        : code === 'NETWORK' ? 'Không kết nối được máy chủ. Kiểm tra server đã chạy chưa.'
        : (res && res.error) || 'Đăng nhập thất bại';
      showError(msg);
    } catch (e) {
      showError(String(e && e.message || e));
    } finally {
      busy = false;
      submitBtn.disabled = false;
      submitBtn.textContent = 'Đăng nhập';
      endBar();
    }
  }

  // Nút "Gửi mã": gửi OTP tới email đang nhập (chỉ cần email). Thành công → đếm ngược
  // 60s trên nút + hiện gợi ý mã dev (nếu máy chủ chưa cấu hình SMTP).
  async function sendCode() {
    if (busy || sendCodeBtn.disabled) return;
    if (!validateFields(['email'])) return;
    const email = emailInput.value.trim();

    busy = true;
    sendCodeBtn.disabled = true;
    sendCodeBtn.textContent = 'Đang gửi…';
    showError('');
    startBar();
    try {
      // Cùng ô mã cho 2 luồng: đăng ký (email CHƯA có) vs quên mật khẩu (email ĐÃ có).
      const res = mode === 'forgot'
        ? await vt.auth.requestPasswordReset({ email, lang: curLang })
        : await vt.auth.requestOtp({ email, lang: curLang });
      if (res && res.ok) {
        const dev = res.data && res.data.devCode;
        otpDevHint.textContent = dev
          ? tf('Chế độ thử nghiệm (máy chủ chưa cấu hình email): mã của bạn là {0}', dev)
          : '';
        applyMode();
        startResendCooldown();       // khoá nút + đếm ngược
        toast('Đã gửi mã xác thực tới email', 'ok');
        setTimeout(() => otpInput.focus(), 40);
        return;
      }
      // Thất bại → mở khoá nút để thử lại.
      sendCodeBtn.disabled = false;
      sendCodeBtn.textContent = 'Gửi mã';
      const code = res && res.code;
      // Email không nhận được thư (tên miền không tồn tại/không cắm MX): máy chủ đã CHẶN
      // không gửi để tránh Hard Bounce làm nhà cung cấp mail khoá tài khoản gửi của ta.
      // Báo bằng TOAST cho nổi bật, kèm lỗi cạnh ô nhập.
      if (code === 'EMAIL_UNDELIVERABLE') {
        toast('Email bạn nhập không tồn tại', 'err');
        showError('Email bạn nhập không tồn tại');
        return;
      }
      const msg =
        code === 'EMAIL_TAKEN' ? 'Email này đã được đăng ký'
        : code === 'ACCOUNT_NOT_FOUND' ? 'Email này chưa được đăng ký'
        : code === 'ACCOUNT_INACTIVE' ? 'Tài khoản đã bị khóa'
        : code === 'EMAIL_INVALID' ? 'Email không đúng định dạng'
        : code === 'NETWORK' ? 'Không kết nối được máy chủ. Kiểm tra server đã chạy chưa.'
        : (res && res.error) || 'Không gửi được mã xác thực';
      showError(msg);
    } catch (e) {
      sendCodeBtn.disabled = false;
      sendCodeBtn.textContent = 'Gửi mã';
      showError(String(e && e.message || e));
    } finally {
      busy = false;
      endBar();
    }
  }
  sendCodeBtn.onclick = sendCode;

  // Đăng nhập với Google (OAuth desktop: mở trình duyệt hệ thống, main-process bắt
  // code qua loopback rồi đổi phiên ở server). Dùng chung trạng thái busy + progress
  // bar + đường thành công như submit() để trải nghiệm nhất quán.
  const gLabelEl = gBtn.querySelector('span:last-child');
  async function googleLogin() {
    if (busy) return;
    busy = true;
    submitBtn.disabled = true;
    gBtn.disabled = true;
    const gPrev = gLabelEl ? gLabelEl.textContent : '';
    if (gLabelEl) gLabelEl.textContent = 'Đang mở Google…';
    showError('');
    startBar();
    try {
      const res = await vt.auth.google();
      if (res && res.ok) {
        // Đăng nhập Google KHÔNG dùng ô mật khẩu → tắt "lưu đăng nhập" mật khẩu.
        try { await vt.auth.cred.clear(); } catch { /* ignore */ }
        localStorage.setItem(REMEMBER_KEY, '0');
        toast('Đăng nhập thành công', 'ok');
        if (onSuccess) onSuccess(res.data.account);
        return;
      }
      const code = res && res.code;
      const msg =
        code === 'GOOGLE_NOT_CONFIGURED' ? 'Đăng nhập Google chưa được cấu hình trên máy chủ.'
        : code === 'NETWORK' ? 'Không kết nối được máy chủ. Kiểm tra server đã chạy chưa.'
        : (res && res.error) || 'Đăng nhập Google thất bại. Vui lòng thử lại.';
      showError(msg);
    } catch (e) {
      showError(String((e && e.message) || 'Đăng nhập Google thất bại. Vui lòng thử lại.'));
    } finally {
      busy = false;
      submitBtn.disabled = false;
      gBtn.disabled = false;
      if (gLabelEl) gLabelEl.textContent = gPrev;
      endBar();
    }
  }
  gBtn.onclick = googleLogin;

  const form = el('form.auth-form', { onsubmit: (e) => { e.preventDefault(); submit(); } }, [
    forgotDesc,
    emailField,
    codeField,
    otpDevHint,
    passField,
    // Mã giới thiệu đứng SAU mật khẩu và TRƯỚC dòng đồng ý điều khoản: nó là ô tuỳ chọn,
    // đặt trên mật khẩu sẽ chen vào giữa chuỗi bắt buộc email → mã → mật khẩu.
    refField,
    agreeRow,
    agreeErr,
    rememberRow,
    errorBox,
    submitBtn,
    dividerEl,
    socialEl,
    termsEl,
  ]);

  const card = el('div.auth-card', {}, [
    title,
    form,
    el('div.auth-foot', {}, [switchLink, backLink]),
  ]);

  // ---- Topbar (over the right pane): logo left, language picker right -------
  const logo = el('div.auth-logo', {}, [
    el('img', { src: 'assets/cgt-logo.svg', alt: 'CGTBrowser' }),
    el('span.auth-logo-name', { text: 'CGTBrowser' }),
  ]);

  // Language dropdown (globe + short code + caret), cloned from AdsPower's
  // top-right selector. Reads/writes settings.language; toast on change.
  // Ngôn ngữ hiện hành = ngôn ngữ boot đã áp (lựa chọn đã lưu, hoặc đoán theo quốc gia IP nếu
  // người dùng chưa từng chọn - y web landing). Chọn ở đây ⇒ languagePicked = true.
  let curLang = 'vi';
  try { curLang = getLang() || 'vi'; } catch { /* ignore */ }
  const langCur = LANGS.find((l) => l.c === curLang) || LANGS[0];
  const langCode = el('span.auth-lang-code', { text: langCur.s });
  const langFlag = el('span.auth-lang-flag', { html: icon(langCur.f) });
  const langMenu = el('div.auth-lang-menu', { style: { display: 'none' } });
  const langBtn = el('button.auth-lang-btn', { type: 'button' }, [
    langFlag,
    langCode,
    el('span.auth-lang-caret', { html: ICO_CARET }),
  ]);
  LANGS.forEach((l) => {
    const item = el('button.auth-lang-item', { type: 'button' }, [el('span.auth-lang-flag', { html: icon(l.f) }), el('span', { text: l.n })]);
    if (l.c === curLang) item.classList.add('is-active');
    item.onclick = () => {
      curLang = l.c;
      langCode.textContent = l.s;
      langFlag.innerHTML = icon(l.f);
      try { localStorage.setItem('polyLang', l.c); } catch { /* ignore */ }
      try { vt.settings.set({ language: l.c, languagePicked: true }); } catch { /* ignore */ }
      langMenu.querySelectorAll('.auth-lang-item').forEach((n) => n.classList.remove('is-active'));
      item.classList.add('is-active');
      langMenu.style.display = 'none';
      // Áp dụng ngôn ngữ NGAY trên trang đăng nhập/đăng ký (dịch DOM tại chỗ). Bật
      // observer để mọi chữ dựng động sau đó (modal điều khoản, thông báo lỗi, nút
      // "Đang xử lý…") cũng tự dịch theo. vi → khôi phục nguyên bản tiếng Việt.
      setLang(l.c);
      paintLegal();
      applyI18n(document.body);
    };
    langMenu.appendChild(item);
  });
  langBtn.onclick = (e) => {
    e.stopPropagation();
    langMenu.style.display = langMenu.style.display === 'none' ? 'block' : 'none';
  };
  document.addEventListener('click', () => { langMenu.style.display = 'none'; });
  const langWrap = el('div.auth-lang', {}, [langBtn, langMenu]);

  const topbar = el('div.auth-topbar', {}, [logo, langWrap]);

  // Bong bóng liên hệ (Zalo/Telegram/Messenger) ghim góc dưới phải - giống web landing.
  // Đặt trong .auth-shell chứ không phải body: showLogin() dọn #app mỗi lần dựng lại
  // (đăng xuất → đăng nhập lại), nên bong bóng đi theo và KHÔNG bị nhân bản, cũng không
  // sót lại lơ lửng trên giao diện sau khi đăng nhập.
  // Lớp hiệu ứng nền GIỮ NGUYÊN từ panel trái cũ (5 vệt sáng chạy chéo - CSS .auth-deco), nay phủ toàn màn hình.
  const deco = el('div.auth-deco', { 'aria-hidden': 'true', html: [1, 2, 3, 4, 5].map((i) => `<span class="ft-streak ft-streak--${i}"></span>`).join('') });
  // Logo (góc trên trái) + chọn ngôn ngữ (góc trên phải) nằm NGOÀI thẻ, ghim theo cửa sổ (user 2026-11-02).
  container.appendChild(el('div.auth-shell', {}, [
    deco,
    topbar,
    el('div.auth-pane', {}, [card]),
    contactFab(),
  ]));
  applyMode();
  // Dịch trang ngay khi dựng nếu ngôn ngữ đang chọn khác tiếng Việt (tránh nháy VI).
  try { setLang(curLang); paintLegal(); applyI18n(container); } catch { /* ignore */ }

  // Điền sẵn email + mật khẩu đã nhớ (mã hoá ở main). Bất đồng bộ.
  (async () => {
    if (!remembered) { setTimeout(() => emailInput.focus(), 40); return; }
    let cred = null;
    try { cred = await vt.auth.cred.get(); } catch { /* ignore */ }
    if (cred && (cred.email || cred.password) && mode === 'login') {
      if (cred.email) emailInput.value = cred.email;
      if (cred.password) passInput.value = cred.password;
      hadSavedCred = !!(cred.email && cred.password);
    }
    setTimeout(() => {
      if (hadSavedCred) submitBtn.focus();
      else (emailInput.value ? passInput : emailInput).focus();
    }, 40);
  })();
}
