// Port of ExtensionsView.xaml - "Tiện ích". Two tabs matching AdsPower:
//   • "Tiện ích nhóm"   - uploaded group extensions (toggle / open-folder / delete / upload)
//   • "Đề xuất cho bạn" - a curated grid of recommended extensions, each opening
//                          the Chrome Web Store (search) in the external browser.
//
// Non-1:1: the WPF "Chrome Web Store" tab downloaded a CRX over the network. That
// network/CRX-unzip logic lives in the main process in the WPF app; here the
// file-folder import path is wired through vt.ext.import() (a directory picker in
// the main process). Recommended cards link out to the Web Store instead.
import { el, clear, toast, openModal, closeModal, openMenu, pageSizeSelect } from '../ui.js';
import { icon } from '../icons.js';
import { notifyError } from '../data/errors.js';
import { tf } from '../i18n.js';

// curated list of real, widely-used extensions for this audience. We never guess
// a specific extension id; each link opens a Chrome Web Store *search* for the
// name, which always resolves to a valid store page.
const RECOMMENDED = [
  { name: 'Cookie-Editor', color: '#F59E0B', desc: 'Tạo, sửa, xóa và xuất/nhập cookie ngay trong trình duyệt.' },
  { name: 'EditThisCookie', color: '#EF4444', desc: 'Trình quản lý cookie mạnh mẽ, sao lưu và phục hồi nhanh.' },
  { name: 'Proxy SwitchyOmega', color: '#111827', desc: 'Quản lý và chuyển đổi nhiều proxy chỉ với một cú nhấp.' },
  { name: 'Google Translate', color: '#4285F4', desc: 'Dịch nhanh trang web và đoạn văn bản được chọn.' },
  { name: 'AdBlock', color: '#E11D48', desc: 'Chặn quảng cáo, pop-up và banner trên mọi trang web.' },
  { name: 'Authenticator', color: '#2563EB', desc: 'Tạo mã xác thực 2 bước (2FA / OTP) ngay trên trình duyệt.' },
  { name: 'Wappalyzer', color: '#6D28D9', desc: 'Nhận diện công nghệ đứng sau bất kỳ website nào.' },
  { name: 'JSON Formatter', color: '#0EA5E9', desc: 'Hiển thị dữ liệu JSON đẹp, dễ đọc và gấp gọn.' },
  { name: 'User-Agent Switcher and Manager', color: '#16A34A', desc: 'Đổi User-Agent để giả lập trình duyệt hoặc thiết bị khác.' },
  { name: 'ColorZilla', color: '#DB2777', desc: 'Lấy mã màu (eyedropper) và phân tích màu trên trang web.' },
  { name: 'Meta Pixel Helper', color: '#1877F2', desc: 'Kiểm tra Meta (Facebook) Pixel hoạt động trên website.' },
  { name: 'Tag Assistant', color: '#34A853', desc: 'Kiểm tra thẻ Google (GA, GTM) đã cài đặt đúng hay chưa.' },
];

// form-row helper - same label-left layout as "Tạo hồ sơ" (.pc-frow/.pc-flabel/.pc-fctl)
function frow(label, control) {
  return el('div.pc-frow', {}, [
    el('div.pc-flabel', { text: label }),
    el('div.pc-fctl', {}, Array.isArray(control) ? control : [control]),
  ]);
}

// segmented control - same look as the "Tạo hồ sơ" pills (.seg.pc-seg / .seg-opt)
function pills(options, value, onChange) {
  const norm = options.map((o) => (Array.isArray(o) ? o : [o, o]));
  const wrap = el('div.seg.pc-seg');
  function paint() {
    clear(wrap);
    norm.forEach(([v, l]) => {
      wrap.appendChild(el('button.seg-opt' + (v === value ? '.active' : ''), {
        type: 'button', html: `<span>${l}</span>`,
        onclick: () => { value = v; paint(); onChange && onChange(v); },
      }));
    });
  }
  paint();
  return wrap;
}

export function render(ctx) {
  let items = [];
  let search = '';
  let activeTab = 'group'; // 'group' | 'recommend'
  let pageNo = 1;          // trang hiện tại (phân trang lưới tiện ích)
  let pageSize = 12;       // số thẻ mỗi trang (đổi qua ô "Số dòng mỗi trang")
  let totalPages = 1;      // tổng số trang hiện tại (nút "sau" dựa vào đây)
  const grid = el('div.ext-grid');

  // Thanh phân trang DÙNG CHUNG mẫu với các trang khác của dự án (.pager). Tạo MỘT LẦN rồi
  // cập nhật tại chỗ (giống market.js / profiles.js) thay vì dựng lại mỗi lần vẽ.
  const pageNumbers = el('div.page-nums');
  const totalText = el('span.muted');
  const sizeSel = pageSizeSelect([12, 24, 48, 96], { value: pageSize, onChange: (v) => { pageSize = v; pageNo = 1; draw(); } });
  const prevBtn = el('button.icon-btn', { html: icon('chevron'), style: { transform: 'rotate(180deg)' },
    onclick: () => { if (pageNo > 1) { pageNo--; draw(); } } });
  const nextBtn = el('button.icon-btn', { html: icon('chevron'),
    onclick: () => { if (pageNo < totalPages) { pageNo++; draw(); } } });
  const pager = el('div.ext-pager', {}, [
    el('div.pager', {}, [
      el('span.muted', { text: 'Số dòng mỗi trang:' }), sizeSel, totalText, prevBtn, pageNumbers, nextBtn,
    ]),
  ]);

  // Cập nhật thanh phân trang tại chỗ. start = chỉ số thẻ đầu của trang hiện tại.
  function renderPager(total, pages, start) {
    totalPages = Math.max(1, pages);
    const from = total === 0 ? 0 : start + 1;
    const to = Math.min(start + pageSize, total);
    totalText.textContent = tf('{0}-{1} trên {2}', from, to, total);
    clear(pageNumbers);
    for (let i = 0; i < totalPages; i++) {
      if (totalPages > 7 && i > 1 && i < totalPages - 2 && Math.abs(i - (pageNo - 1)) > 1) {
        if (i === 2 || i === totalPages - 3) pageNumbers.appendChild(el('span.muted', { text: '…' }));
        continue;
      }
      pageNumbers.appendChild(el('button.page-num' + (i === pageNo - 1 ? '.active' : ''),
        { text: String(i + 1), onclick: () => { pageNo = i + 1; draw(); } }));
    }
  }

  // Cắt danh sách đã lọc theo trang hiện tại; kẹp pageNo hợp lệ + cập nhật thanh phân trang.
  function paginate(list) {
    const total = list.length;
    const pages = Math.max(1, Math.ceil(total / pageSize));
    if (pageNo > pages) pageNo = pages;
    if (pageNo < 1) pageNo = 1;
    const start = (pageNo - 1) * pageSize;
    renderPager(total, pages, start);
    return list.slice(start, start + pageSize);
  }

  function persist() { vt.ext.save(items); }

  function matchesText(...fields) {
    if (!search) return true;
    const q = search.toLowerCase();
    return fields.some((v) => String(v || '').toLowerCase().includes(q));
  }

  function fileUrl(p) { return 'file:///' + String(p).replace(/\\/g, '/'); }
  function storeSearchUrl(name) { return 'https://chromewebstore.google.com/search/' + encodeURIComponent(name); }

  function emptyState(text, ic) {
    grid.appendChild(el('div.placeholder-view', { style: { gridColumn: '1/-1' } }, [
      el('div.big', { html: icon(ic || 'extensions') }),
      el('div.muted', { text }),
    ]));
  }

  function renderGroupGrid() {
    clear(grid);
    const all = items.filter((it) => matchesText(it.name, it.author, it.description));
    if (!all.length) { renderPager(0, 1, 0); emptyState('Chưa có tiện ích nào. Bấm "Tải lên tiện ích" để thêm.'); return; }
    const list = paginate(all);
    list.forEach((it) => {
      const iconEl = it.iconImagePath
        ? el('img.ext-icon-img', { src: fileUrl(it.iconImagePath) })
        : el('div.ext-icon', { style: { background: (it.iconColor || '#1BB15C').replace(/^#FF/, '#') }, text: it.iconGlyph || (it.name || '?')[0].toUpperCase() });

      const toggle = el('button.switch' + (it.isEnabled ? '.on' : ''), {
        title: it.isEnabled ? 'Đang bật' : 'Đang tắt',
        onclick: () => { it.isEnabled = !it.isEnabled; persist(); renderGroupGrid(); },
      }, [el('span.knob')]);

      const vendor = it.storeId ? 'Cửa hàng Chrome' : (it.author || 'Tải lên');
      const kebab = el('button.ext-kebab', { html: icon('moreHorizontal'), title: 'Tùy chọn', onclick: () => openMenu(kebab, [
        { label: 'Cập nhật', icon: 'edit', onClick: () => updateExt(it) },
        { label: 'Xóa', icon: 'trash', danger: true, onClick: () => removeExt(it) },
      ]) });

      grid.appendChild(el('div.card.ext-card', {}, [
        el('div.ext-head', {}, [
          iconEl,
          el('div.ext-meta', {}, [
            el('div.ext-name', { text: it.name || 'Tiện ích' }),
          ]),
          toggle,
        ]),
        el('div.ext-desc.muted', { text: it.description || '' }),
        el('div.ext-foot', {}, [
          el('div.ext-vendor', {}, [
            el('span', { text: 'Nhà cung cấp: ' }),
            el('span.ext-vendor-name', { text: vendor }),
          ]),
          kebab,
        ]),
      ]));
    });
  }

  function removeExt(it) {
    openModal({
      title: 'Xóa ứng dụng',
      width: 560,
      body: [
        el('div.ext-del-warn', {}, [
          el('span.ext-del-warn-ico', { html: icon('warnCircle') }),
          el('span', { text: 'Nếu ứng dụng này bị xóa, nó sẽ bị gỡ cài đặt trong tất cả các trình duyệt.' }),
        ]),
        el('div.ext-del-q', { text: 'Xác nhận xóa các ứng dụng này?' }),
        el('div.ext-del-row', {}, [
          el('div.ext-del-label', { text: 'Tên ứng dụng' }),
          el('span.ext-del-chip', { text: it.name || 'Tiện ích' }),
        ]),
      ],
      footer: [
        el('button.btn', { text: 'Hủy', onclick: closeModal }),
        el('button.btn.primary', { text: 'OK', onclick: async () => {
          try {
            if (it.folderPath) await vt.ext.remove(it.folderPath);
            items = items.filter((x) => x !== it); persist(); renderGroupGrid(); closeModal();
          } catch (e) { notifyError(e, 'Xóa ứng dụng thất bại'); }
        } }),
      ],
    });
  }

  // "Cập nhật": re-download the latest CRX for store extensions; for uploaded
  // ones (no storeId) just open the folder so the user can swap files.
  async function updateExt(it) {
    if (!it.storeId) {
      if (it.folderPath) { vt.ext.openFolder(it.folderPath); } else { toast('Tiện ích chưa có thư mục'); }
      return;
    }
    toast('Đang cập nhật tiện ích…', 'ok');
    let res = null;
    try { res = await vt.ext.downloadStore(it.storeId); } catch { res = null; }
    if (!res || res.error) { toast('Cập nhật thất bại (kiểm tra mạng/URL)', 'err'); return; }
    it.name = res.name || it.name;
    it.version = res.version || it.version;
    it.description = res.description || it.description;
    it.iconImagePath = res.iconImagePath || it.iconImagePath;
    it.folderPath = res.folderPath;
    persist(); renderGroupGrid(); toast('Đã cập nhật tiện ích', 'ok');
  }

  function renderRecommendGrid() {
    clear(grid);
    const all = RECOMMENDED.filter((r) => matchesText(r.name, r.desc));
    if (!all.length) { renderPager(0, 1, 0); emptyState('Không tìm thấy tiện ích phù hợp.'); return; }
    const list = paginate(all);
    list.forEach((r) => {
      grid.appendChild(el('div.card.ext-card', {}, [
        el('div.ext-head', {}, [
          el('div.ext-icon', { style: { background: r.color }, text: (r.name || '?')[0].toUpperCase() }),
          el('div.ext-meta', {}, [el('div.ext-name', { text: r.name })]),
        ]),
        el('div.ext-desc.muted', { text: r.desc }),
        el('div.ext-store', {}, [
          el('span.muted', { text: 'Cài đặt ứng dụng:' }),
          el('a.ext-store-link', { text: 'Chrome Web Store', onclick: () => vt.shell.openExternal(storeSearchUrl(r.name)) }),
        ]),
      ]));
    });
  }

  function draw() { (activeTab === 'group' ? renderGroupGrid : renderRecommendGrid)(); }

  function openUpload() {
    let mode = 'file';        // 'file' | 'store'
    let picked = null;        // result of vt.ext.import(): {name, author, version, description, folderPath, iconImagePath}

    // --- "Tải lên file" tab: a single dashed drop zone ---
    const cloudUploadSvg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor"><path fill-rule="evenodd" d="M4.406 1.342A5.53 5.53 0 0 1 8 0c2.69 0 4.923 2 5.166 4.579C14.758 4.804 16 6.137 16 7.773 16 9.569 14.502 11 12.687 11H10a.5.5 0 0 1 0-1h2.688C13.979 10 15 8.988 15 7.773c0-1.216-1.02-2.228-2.313-2.228h-.5v-.5C12.188 2.825 10.328 1 8 1a4.53 4.53 0 0 0-2.941 1.1c-.757.652-1.153 1.438-1.153 2.055v.448l-.445.049C2.064 4.805 1 5.952 1 7.318 1 8.785 2.23 10 3.781 10H6a.5.5 0 0 1 0 1H3.781C1.708 11 0 9.366 0 7.318c0-1.763 1.266-3.223 2.942-3.593.143-.863.698-1.723 1.464-2.383"/><path fill-rule="evenodd" d="M7.646 4.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8.5 5.707V14.5a.5.5 0 0 1-1 0V5.707L5.354 7.854a.5.5 0 1 1-.708-.708z"/></svg>';
    const dzTitle = el('div.ext-dz-title', { text: 'Kéo & thả tiện ích mở rộng vào đây' });
    const dropzone = el('button.ext-dropzone', { type: 'button' }, [
      el('div.ext-dz-ico', { html: cloudUploadSvg }),
      dzTitle,
      el('div.ext-dz-sub', { text: 'Định dạng được hỗ trợ: FOLDER, ZIP' }),
    ]);
    function applyPicked(res) {
      if (!res) return;
      if (res.error === 'no-manifest') { toast('Thư mục không chứa manifest.json', 'err'); return; }
      picked = res;
      dzTitle.textContent = res.name || 'Đã chọn tiện ích';
      dropzone.classList.add('has');
    }
    dropzone.onclick = async () => { try { applyPicked(await vt.ext.import()); } catch (e) { notifyError(e, 'Nhập tiện ích thất bại'); } };
    dropzone.addEventListener('dragover', (e) => { e.preventDefault(); dropzone.classList.add('drag'); });
    dropzone.addEventListener('dragleave', () => dropzone.classList.remove('drag'));
    dropzone.addEventListener('drop', async (e) => {
      e.preventDefault(); dropzone.classList.remove('drag');
      const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
      const p = f && f.path;
      if (!p) { toast('Hãy thả thư mục tiện ích đã giải nén', 'err'); return; }
      try { applyPicked(await vt.ext.importPath(p)); } catch (err) { notifyError(err, 'Nhập tiện ích thất bại'); }
    });

    const fileBody = el('div.ext-up-body', {}, [dropzone]);

    // --- "Chrome Web Store" tab ---
    const urlInput = el('input.input', { placeholder: 'URL Chrome Web Store của tiện ích' });
    const storeBody = el('div.ext-up-body', {}, [
      frow('URL của tiện ích', urlInput),
      frow('', el('div.ext-note', {}, [
        el('div.ext-note-title', { text: 'Chú ý:' }),
        el('div', { text: '1. Yêu cầu mạng ngoài đại lục Trung Quốc.' }),
        el('div', { text: '2. Tiện ích mở rộng được cung cấp bởi bên thứ ba, tất cả quyền được bảo lưu.' }),
        el('div', { text: '3. Truy cập Chrome Web Store và sao chép liên kết của tiện ích mở rộng.' }),
      ])),
    ]);

    const bodyHost = el('div', {}, [fileBody]);
    const submitBtn = el('button.btn.primary', { text: 'Tải Tệp Lên', onclick: () => submit() });
    const typeSeg = pills([['file', 'Tải lên file'], ['store', 'Chrome Web Store']], 'file', (v) => {
      mode = v; clear(bodyHost); bodyHost.appendChild(v === 'file' ? fileBody : storeBody);
      submitBtn.textContent = v === 'file' ? 'Tải Tệp Lên' : 'Tải xuống';
    });

    function addToStore(meta) {
      const name = meta.name;
      // meta.id is "<crxid>_<timestamp>"; keep the bare 32-char id so "Cập nhật"
      // can re-download the latest version later.
      const storeId = (meta.id && /^[a-p]{32}_/i.test(meta.id)) ? meta.id.split('_')[0] : null;
      items.unshift({
        name, author: meta.author || 'Chrome Web Store', version: meta.version || '',
        iconGlyph: (name || '?')[0].toUpperCase(), iconColor: '#1BB15C',
        iconImagePath: meta.iconImagePath || null, isEnabled: true,
        description: meta.description || '',
        folderPath: meta.folderPath, storeId,
      });
      persist(); renderGroupGrid();
    }

    async function submit() {
      if (mode === 'store') {
        if (submitBtn.classList.contains('is-loading')) return;
        const url = urlInput.value.trim();
        if (!/^https?:\/\//i.test(url)) { toast('Vui lòng nhập URL Chrome Web Store hợp lệ', 'err'); return; }
        submitBtn.classList.add('is-loading');
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="btn-spin"></span><span>Đang tải…</span>';
        let res = null;
        try { res = await vt.ext.downloadStore(url); } catch { res = null; }
        if (!res || res.error) {
          const map = {
            'bad-url': 'Không nhận diện được ID tiện ích từ URL',
            'download-failed': 'Tải tiện ích thất bại (kiểm tra mạng/URL)',
            'unpack-failed': 'Không giải nén được tiện ích',
            'no-manifest': 'Gói tải về không hợp lệ (thiếu manifest.json)',
          };
          toast(map[res && res.error] || 'Tải tiện ích thất bại', 'err');
          submitBtn.classList.remove('is-loading');
          submitBtn.disabled = false;
          submitBtn.textContent = 'Tải xuống';
          return;
        }
        addToStore(res);
        closeModal();
        toast('Đã tải và thêm tiện ích', 'ok');
        return;
      }
      if (!picked) { toast('Vui lòng chọn gói cài đặt trước', 'err'); return; }
      const name = picked.name;
      if (!name) { toast('Tiện ích không hợp lệ (thiếu tên)', 'err'); return; }
      items.unshift({
        name, author: picked.author || 'Tải lên', version: picked.version || '',
        iconGlyph: (name || '?')[0].toUpperCase(), iconColor: '#1BB15C',
        iconImagePath: picked.iconImagePath || null, isEnabled: true,
        description: picked.description || '',
        folderPath: picked.folderPath,
      });
      persist(); renderGroupGrid(); closeModal(); toast('Đã thêm tiện ích', 'ok');
    }

    openModal({
      title: 'Tải lên tiện ích',
      width: 720,
      body: [frow('Loại', typeSeg), bodyHost],
      footer: [
        el('button.btn', { text: 'Hủy', onclick: closeModal }),
        submitBtn,
      ],
    });
  }

  const searchBar = el('div.searchbar', {}, [
    el('span.ico', { html: icon('search') }),
    el('input.search-input', { placeholder: 'Tìm kiếm tiện ích...', oninput: (e) => { search = e.target.value.trim(); pageNo = 1; draw(); } }),
  ]);

  const uploadBtn = el('button.btn.primary', { html: `${icon('upload')}<span>Tải lên tiện ích</span>`, onclick: openUpload });
  const storeHint = el('a.ext-hint', {
    html: 'Không thấy ứng dụng bạn cần? <span>Truy cập Chrome Web Store</span>',
    onclick: () => vt.shell.openExternal('https://chromewebstore.google.com/'),
  });

  // header bar: [upload button] [search]
  const headBar = el('div.page-head.ext-head-bar');
  function buildHead() {
    clear(headBar);
    headBar.appendChild(uploadBtn);
    headBar.appendChild(searchBar);
  }

  buildHead();
  const page = el('div.page.ext-page', {}, [
    headBar,
    el('div.ext-scroll', {}, [grid]),
    pager,
  ]);
  ctx.container.appendChild(page);

  vt.ext.list().then((list) => { items = list || []; draw(); });
  return null;
}
