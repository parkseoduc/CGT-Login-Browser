// Shared "Console" panel for "Đồng bộ thao tác" (action mirroring).
//
// Extracted from sync.js so the SAME console can be mounted in two places:
//   1. inside the full Sync view (right-hand panel), and
//   2. as a floating, right-docked overlay that pops out when the user starts
//      action-sync from the Profiles toolbar.
//
// UI-ONLY shell (matches MKTLogin): the only live utilities are window tiling
// (vt.sync.arrange) and "Xem cửa sổ" (vt.profiles.show); everything else is inert.
import { el, clear, toast, customSelect, withSpin } from '../ui.js';
import { icon } from '../icons.js';
import { tf } from '../i18n.js';

// stroke-style inline icons used by the Console panel (small, 1.7 weight)
const S = (d) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
const ICONS = {
  collapse: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M0 0h24v24H0z" fill="none"/><path fill="currentColor" d="M18 3.25H6A2.75 2.75 0 0 0 3.25 6v6a.75.75 0 0 0 1.5 0V6A1.25 1.25 0 0 1 6 4.75h12A1.25 1.25 0 0 1 19.25 6v12A1.25 1.25 0 0 1 18 19.25h-6a.75.75 0 0 0 0 1.5h6A2.75 2.75 0 0 0 20.75 18V6A2.75 2.75 0 0 0 18 3.25"/><path fill="currentColor" d="M11.21 13.19a.8.8 0 0 0 .29.06h4a.75.75 0 0 0 0-1.5h-2.19l3.22-3.22a.75.75 0 0 0-1.06-1.06l-3.22 3.22V8.5a.75.75 0 0 0-1.5 0v4a.8.8 0 0 0 .06.29a.7.7 0 0 0 .4.4M8 14.25H5A1.76 1.76 0 0 0 3.25 16v3A1.76 1.76 0 0 0 5 20.75h3A1.76 1.76 0 0 0 9.75 19v-3A1.76 1.76 0 0 0 8 14.25M8.25 19a.25.25 0 0 1-.25.25H5a.25.25 0 0 1-.25-.25v-3a.25.25 0 0 1 .25-.25h3a.25.25 0 0 1 .25.25Z"/></svg>',
  monitor: S('<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8M12 17v4"/>'),
  text: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M0 0h20v20H0z" fill="none"/><path fill="currentColor" d="M17.226 0C18.206 0 19 .814 19 1.818v16.364C19 19.186 18.206 20 17.226 20H4.542c-.98 0-1.774-.814-1.774-1.818l-.001-1.686H1.665a.674.674 0 0 1-.665-.68c0-.377.298-.682.665-.682h1.102v-2.419H1.665A.674.674 0 0 1 1 12.033c0-.377.298-.682.665-.682l1.102-.001V8.919H1.665A.674.674 0 0 1 1 8.239c0-.377.298-.682.665-.682l1.102-.001V5.122H1.665A.674.674 0 0 1 1 4.441c0-.377.298-.682.665-.682l1.102-.001l.001-1.94C2.768.814 3.562 0 4.542 0zm-3.248 1.364H4.466a.34.34 0 0 0-.246.118a.43.43 0 0 0-.12.268v2.008h.844a.67.67 0 0 1 .665.683a.674.674 0 0 1-.665.681H4.1v2.431h.873l.045.007l-.074-.004a.65.65 0 0 1 .313.08l.02.011a.5.5 0 0 1 .124.101l-.055-.053a.68.68 0 0 1 .261.509l-.007-.08q.01.055.01.114a.676.676 0 0 1-.606.679l-.03.001l-.016.001H4.1v2.431h.844a.65.65 0 0 1 .308.078q.092.044.15.111l-.03-.029a.69.69 0 0 1 .216.696l-.009.03l-.015.044a.7.7 0 0 1-.271.333l-.01.006a.64.64 0 0 1-.339.095H4.1v2.419h.873q.012 0 .023.004l-.052-.004c.367 0 .665.305.665.682c0 .222-.104.42-.265.544l-.013.01l-.062.04l-.008.004a.6.6 0 0 1-.275.082h-.013l-.015.002h-.014l-.844-.001v1.764q.009.1.072.19l.048.058q.11.115.27.13h9.488zm3.264-.002h-1.938v17.274h1.974q.136.001.256-.13a.47.47 0 0 0 .134-.267V1.794a.5.5 0 0 0-.134-.298a.42.42 0 0 0-.292-.134"/></svg>',
  tab: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M0 0h24v24H0z" fill="none"/><path fill="currentColor" d="M21 3H3c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2m-1 16H4c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1h9v3c0 .55.45 1 1 1h7v9c0 .55-.45 1-1 1"/></svg>',
  resize: S('<path d="M8 8 4 12l4 4M16 8l4 4-4 4M4 12h16"/>'),
  grid: S('<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>'),
  paste: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 14 14"><path d="M0 0h14v14H0z" fill="none"/><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" d="M8.5 3.5v-1a1 1 0 0 0-1-1h-1m-2.5 9H1.5a1 1 0 0 1-1-1v-7a1 1 0 0 1 1-1h1m10 4h-5a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h5a1 1 0 0 0 1-1v-6a1 1 0 0 0-1-1M6.75.5h-4.5l.41 1.62a.49.49 0 0 0 .48.38h2.72a.49.49 0 0 0 .48-.38zm1.75 8h3m-3 2h3"/></svg>',
  pause: S('<circle cx="12" cy="12" r="9"/><path d="M10 9v6M14 9v6"/>'),
  folder: S('<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>'),
  copy: S('<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h8"/>'),
  pin: S('<path d="M12 21s7-6.5 7-11a7 7 0 1 0-14 0c0 4.5 7 11 7 11z"/><circle cx="12" cy="10" r="2.4"/>'),
  blank: S('<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18"/>'),
  open: S('<path d="M14 4h6v6M20 4l-9 9M18 14v4a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4"/>'),
  plus: S('<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>'),
  // "Xóa văn bản" - filled clear/erase glyph (its own viewBox; CSS sizes the svg)
  clearText: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024"><path d="M0 0h1024v1024H0z" fill="none"/><path fill="currentColor" d="m899.1 869.6l-53-305.6H864c14.4 0 26-11.6 26-26V346c0-14.4-11.6-26-26-26H618V138c0-14.4-11.6-26-26-26H432c-14.4 0-26 11.6-26 26v182H160c-14.4 0-26 11.6-26 26v192c0 14.4 11.6 26 26 26h17.9l-53 305.6c-.3 1.5-.4 3-.4 4.4c0 14.4 11.6 26 26 26h723c1.5 0 3-.1 4.4-.4c14.2-2.4 23.7-15.9 21.2-30M204 390h272V182h72v208h272v104H204zm468 440V674c0-4.4-3.6-8-8-8h-48c-4.4 0-8 3.6-8 8v156H416V674c0-4.4-3.6-8-8-8h-48c-4.4 0-8 3.6-8 8v156H202.8l45.1-260H776l45.1 260z"/></svg>',
};

function switchEl(on, onChange) {
  let state = !!on;
  const btn = el('button.switch' + (state ? '.on' : ''), { type: 'button' }, [el('span.knob')]);
  btn.onclick = () => { state = !state; btn.classList.toggle('on', state); onChange && onChange(state); };
  Object.defineProperty(btn, 'on', { get: () => state });
  return btn;
}

// Native-radio group rendered as the MKTLogin-style "● label  ○ label" row.
function radioGroup(name, options, value, onChange) {
  const wrap = el('div.sync-radios');
  options.forEach(([v, l]) => {
    const input = el('input', { type: 'radio', name, checked: v === value,
      onchange: () => { value = v; onChange && onChange(v); } });
    wrap.appendChild(el('label.sync-radio', {}, [input, el('span', { text: l })]));
  });
  return wrap;
}

// Build the Console panel.
//   env.getScopeIds : () => string[]  - the windows the actions apply to
//   env.collapseTitle / env.onCollapse - optional; wires the header collapse button
//   env.extraClass   : optional extra class on the root (e.g. 'is-overlay')
// Returns { el, getLayout }.
export function buildSyncConsole(env) {
  const getScopeIds = env.getScopeIds || (() => []);
  const notSupported = () => toast('Sắp xếp/đồng bộ cửa sổ cần API Win32 - không khả dụng trong bản Electron.', 'warn');

  // ---- persisted settings -------------------------------------------------
  // Mọi thiết lập trong Console được LƯU CỐ ĐỊNH (localStorage) và khôi phục mỗi
  // lần mở - không còn reset về mặc định. Mọi onChange gọi persist(...) để ghi lại.
  const STORE_KEY = 'polySyncConsole';
  function loadStore() { try { return JSON.parse(localStorage.getItem(STORE_KEY)) || {}; } catch { return {}; } }
  const store = loadStore();
  function persist(patch) {
    if (patch) Object.assign(store, patch);
    try { localStorage.setItem(STORE_KEY, JSON.stringify(store)); } catch { /* ignore */ }
  }

  // "Mô phỏng hành động" settings - backed by the persisted store.
  const sim = Object.assign(
    { clickDelay: false, typeDelay: true, speed: '200', delay: '100', newTab: true },
    store.sim || {});
  // Persist AND, if sync is already running, push the change to the engine live so the new
  // pacing takes effect without a restart (Console is the source of truth). setOptions is a
  // no-op when sync is idle, so this is safe to call unconditionally.
  const saveSim = () => {
    persist({ sim });
    try { vt.sync.setOptions({ sim }); } catch { /* engine not running / unavailable */ }
  };
  // Window layout chosen in the "Cửa sổ" tab; read back via getLayout().
  let winLayoutChoice = store.winLayoutChoice || 'grid';

  const consoleBody = el('div.sync-console-body');

  // --- dynamic enable/disable of action buttons --------------------------------
  // Options are only usable when their preconditions hold (mirrors MKTLogin):
  //   • 'windows' ops ("Xem cửa sổ", "Sắp xếp cửa sổ") need ≥1 open Chrome window in scope;
  //   • 'sync'    ops ("Xóa/Dán văn bản", "Gõ như con người") need action-sync RUNNING.
  // Until then the button is disabled (greyed + non-clickable) instead of firing and then
  // toasting an error - e.g. Chrome not open ⇒ false, conditions met ⇒ true. State is kept
  // live from sync status + the running-window broadcast. Buttons self-register at build
  // time; the registry is reset on every repaint (each tab rebuilds its buttons).
  let syncRunning = false;
  let stateBtns = [];
  function regBtn(node, need) {
    node._need = need;
    // Swallow clicks in the CAPTURE phase while disabled (runs before the bubble-phase
    // onclick, so the action never fires). We deliberately do NOT set the native
    // `disabled` property: a disabled <button> suppresses hover/cursor, which would hide
    // the `cursor: not-allowed` we want to show on a disabled control.
    node.addEventListener('click', (e) => {
      if (node.classList.contains('is-disabled')) { e.stopImmediatePropagation(); e.preventDefault(); }
    }, true);
    stateBtns.push(node);
    return node;
  }
  function hasWindows() { try { return getScopeIds().length > 0; } catch { return false; } }
  function applyStates() {
    const win = hasWindows();
    for (const b of stateBtns) {
      const ok = b._need === 'sync' ? syncRunning : win;
      b.classList.toggle('is-disabled', !ok);
    }
  }

  function showAll() {
    const ids = getScopeIds();
    if (!ids.length) return toast('Không có cửa sổ nào.');
    ids.forEach((id) => { try { vt.profiles.show(id); } catch { /* ignore */ } });
    toast(tf('Đã hiện {0} cửa sổ', ids.length), 'ok');
  }

  // Short, stable display ID for a profile - first 8 hex chars of its md5 "Profile ID"
  // (matches the profiles grid / Proxies tags). Falls back to the GUID when absent.
  function shortId(p) {
    const pid = p && (p.profileId || p.id) ? String(p.profileId || p.id) : '';
    return pid ? pid.slice(0, 8).toUpperCase() : '';
  }

  // id → { name, short }, lazily loaded once and cached. Used by the "Được chỉ định"
  // editor to label each row with the open profile's SHORT ID (name kept in tooltip).
  let _nameCache = null;
  async function profileNameMap() {
    if (_nameCache) return _nameCache;
    try {
      const list = (vt.profiles && vt.profiles.list) ? await vt.profiles.list(null) : [];
      _nameCache = new Map((list || []).map((p) => [String(p.id), { name: p.name || String(p.id), short: shortId(p) }]));
    } catch { _nameCache = new Map(); }
    return _nameCache;
  }

  // a labelled toggle with a trailing info "(i)" glyph (Mô phỏng hành động)
  function toggleInfo(label, on, onChange) {
    return el('label.sync-tinfo', {}, [
      switchEl(on, onChange), el('span', { text: label }),
      el('span.sync-info-q', { html: icon('about'), title: label }),
    ]);
  }
  // a small bordered number field with a floating caption (Tốc độ/Độ trễ)
  function numField(caption, value, onChange) {
    return el('div.sync-numfield', {}, [
      el('span.sync-numcap', { text: caption }),
      el('input.sync-numinput', { value, oninput: (e) => onChange && onChange(e.target.value) }),
    ]);
  }
  // A bordered box wrapping a textarea plus a bottom-right "Gõ như con người" button.
  // Clicking the button types the textarea's text into every synced window like a human.
  // Shared by every "Gõ như con người" field (same-text + each text group).
  function typeBox(opts) {
    const ta = el('textarea.input.sync-ta', {
      rows: String(opts.rows || 3),
      placeholder: opts.placeholder || 'Vui lòng nhập',
      oninput: opts.oninput,
    });
    ta.value = opts.value || '';
    const typeBtn = regBtn(el('button.sync-typebtn', {
      type: 'button', text: 'Gõ như con người',
      title: 'Gõ văn bản này vào tất cả cửa sổ như con người',
      onclick: (e) => { e.preventDefault(); opts.onType(ta.value); },
    }), 'sync');
    return el('div.sync-sametext', {}, [
      ta,
      el('div.sync-sametext-foot', {}, [typeBtn]),
    ]);
  }

  // Drive the engine's "Gõ như con người": type `text` into every synced window at once,
  // char-by-char with human-like pacing. Needs sync running (engine connected).
  async function typeLikeHuman(text) {
    const str = (text || '').trim() ? text : '';
    if (!str) return toast('Vui lòng nhập văn bản trước.', 'warn');
    try {
      const r = await vt.sync.typeText(str);
      if (r && r.ok) toast(tf('Đã gõ vào {0} cửa sổ', r.count), 'ok');
      else toast((r && r.error) || 'Hãy bắt đầu đồng bộ trước khi gõ.', 'warn');
    } catch { toast('Không gõ được văn bản.', 'err'); }
  }
  // "Xóa văn bản": instantly reset the focused field of every synced window to empty.
  async function clearAllText() {
    try {
      const r = await vt.sync.clearText();
      if (r && r.ok) toast(tf('Đã xóa văn bản ở {0} cửa sổ', r.count), 'ok');
      else toast((r && r.error) || 'Hãy bắt đầu đồng bộ trước.', 'warn');
    } catch { toast('Không xóa được văn bản.', 'err'); }
  }
  // "Dán văn bản": read the clipboard, then paste it into every synced window at once.
  async function pasteAllText() {
    let text = '';
    try { text = await navigator.clipboard.readText(); } catch { /* clipboard blocked */ }
    if (!text) return toast('Bảng tạm trống hoặc không đọc được.', 'warn');
    try {
      const r = await vt.sync.pasteText(text);
      if (r && r.ok) toast(tf('Đã dán vào {0} cửa sổ', r.count), 'ok');
      else toast((r && r.error) || 'Hãy bắt đầu đồng bộ trước.', 'warn');
    } catch { toast('Không dán được văn bản.', 'err'); }
  }

  // -- Tab: Cửa sổ --
  function buildWindowTab() {
    const monitorCombo = customSelect(['Primary Screen (1920x1080)'], { value: 'Primary Screen (1920x1080)', width: 230 });
    let winLayout = store.winLayout || winLayoutChoice || 'grid';
    let autoArrange = store.autoArrange !== undefined ? !!store.autoArrange : true;
    const man = Object.assign({ x: '0', y: '0', w: '500', h: '640', hs: '0', vs: '0', per: '5' }, store.man || {});
    const mfield = (caption, key) => el('div.sync-numfield', {}, [
      el('span.sync-numcap', { text: caption }),
      el('input.sync-numinput', { value: man[key], type: 'number',
        oninput: (e) => { man[key] = e.target.value; persist({ man }); } }),
    ]);
    const manRow = (label, fields) => el('div.sync-manrow', {}, [
      el('span.sync-manlabel', { text: label }),
      el('div.sync-manfields', {}, fields),
    ]);

    const autoPanel = el('div.sync-frow', {}, [el('span.sync-flabel', { text: 'Bố cục' }),
      radioGroup('sync-layout', [['grid', 'Lưới'], ['columns', 'Hàng ngang'], ['cascade', 'Bậc thang'], ['stack', 'Chồng lên']], winLayout, (v) => { winLayout = v; winLayoutChoice = v; persist({ winLayout: v, winLayoutChoice: v }); })]);
    const manualPanel = el('div.sync-manlay', {}, [
      el('div.sync-sec-title.sm', { text: 'Bố cục' }),
      manRow('Vị trí', [mfield('X', 'x'), mfield('Y', 'y')]),
      manRow('Kích thước', [mfield('W', 'w'), mfield('H', 'h')]),
      manRow('Không gian', [mfield('HS', 'hs'), mfield('VS', 'vs')]),
      manRow('Số lượng', [mfield('/hàng', 'per')]),
    ]);
    // initial visibility follows the restored auto-arrange state
    autoPanel.style.display = autoArrange ? '' : 'none';
    manualPanel.style.display = autoArrange ? 'none' : '';

    async function arrange() {
      const ids = getScopeIds();
      if (!ids.length) return toast('Không có cửa sổ nào để sắp xếp.');
      try {
        let r;
        if (autoArrange) {
          r = await vt.sync.arrange(ids, winLayout);
        } else {
          const num = (v, d) => { const n = parseInt(v, 10); return Number.isFinite(n) ? n : d; };
          r = await vt.sync.arrange(ids, 'manual', {
            x: num(man.x, 0), y: num(man.y, 0), w: num(man.w, 500), h: num(man.h, 640),
            hs: num(man.hs, 0), vs: num(man.vs, 0), perRow: Math.max(1, num(man.per, 1)),
          });
        }
        const n = (r && r.count) || 0;
        toast(n > 0 ? tf('Đã sắp xếp {0} cửa sổ', n) : 'Không tìm thấy cửa sổ trình duyệt nào đang mở.', n > 0 ? 'ok' : 'warn');
      } catch { toast('Không sắp xếp được cửa sổ.', 'err'); }
    }
    // "Kích cỡ đồng nhất": resize every scoped window to the SAME size (the manual
    // Kích thước W×H), tiled without overlap via the existing manual arrange path.
    async function uniformSize() {
      const ids = getScopeIds();
      if (!ids.length) return toast('Không có cửa sổ nào để chỉnh kích cỡ.');
      const num = (v, d) => { const n = parseInt(v, 10); return Number.isFinite(n) ? n : d; };
      try {
        const r = await vt.sync.arrange(ids, 'manual', {
          x: num(man.x, 0), y: num(man.y, 0), w: num(man.w, 500), h: num(man.h, 640),
          hs: num(man.hs, 0), vs: num(man.vs, 0), perRow: Math.max(1, num(man.per, 1)),
        });
        const n = (r && r.count) || 0;
        toast(n > 0 ? tf('Đã đồng nhất kích cỡ {0} cửa sổ', n) : 'Không tìm thấy cửa sổ trình duyệt nào đang mở.', n > 0 ? 'ok' : 'warn');
      } catch { toast('Không chỉnh được kích cỡ.', 'err'); }
    }
    return el('div.sync-tabpane', {}, [
      el('div.sync-pane-actions', {}, [
        regBtn(el('button.sync-obtn', { html: `${ICONS.resize}<span>Kích cỡ đồng nhất</span>`, onclick: (e) => withSpin(e.currentTarget, uniformSize) }), 'windows'),
        regBtn(el('button.sync-obtn.is-on', { html: `${ICONS.grid}<span>Xem cửa sổ</span>`, onclick: (e) => withSpin(e.currentTarget, showAll) }), 'windows'),
      ]),
      el('div.sync-sec-title', { text: 'Bố cục cửa sổ' }),
      el('div.sync-panel', {}, [
        el('div.sync-frow', {}, [el('span.sync-flabel', { text: 'Màn hình' }), monitorCombo]),
        el('label.sync-toggle-row', {}, [
          switchEl(autoArrange, (on) => {
            autoArrange = on;
            autoPanel.style.display = on ? '' : 'none';
            manualPanel.style.display = on ? 'none' : '';
            persist({ autoArrange: on });
          }),
          el('span', { text: 'Sắp xếp tự động các cửa sổ đã chọn theo độ phân giải màn hình' }),
        ]),
        autoPanel,
        manualPanel,
      ]),
      regBtn(el('button.btn.primary.sync-cta', { html: `${ICONS.pause}<span>Sắp xếp cửa sổ</span>`, onclick: (e) => withSpin(e.currentTarget, arrange) }), 'windows'),
    ]);
  }

  // -- Tab: Văn bản --
  function buildTextTab() {
    const groupsWrap = el('div.sync-text-groups');
    // text groups are persisted as an array of { mode, lines, fixed }
    //  • lines : array of strings, one window's content per ENTRY (used by
    //            "Nhập theo thứ tự"/"Nhập ngẫu nhiên"); always ≥1 row.
    //  • fixed : { profileId: text } map (used by "Được chỉ định")
    // Legacy groups stored a single `text` string - migrate it by splitting on newlines.
    const toLines = (g) => {
      if (Array.isArray(g.lines) && g.lines.length) return g.lines.slice();
      if (typeof g.text === 'string' && g.text.length) return g.text.split('\n');
      return [''];
    };
    const tgState = Array.isArray(store.textGroups) && store.textGroups.length
      ? store.textGroups.map((g) => ({ mode: g.mode || 'order', lines: toLines(g), fixed: g.fixed || {} }))
      : [{ mode: 'order', lines: [''], fixed: {} }];
    const saveGroups = () => persist({ textGroups: tgState });

    // Run a single group's "Gõ như con người": map its content to per-window assignments
    // according to the chosen mode, then drive the engine's typePerWindow.
    //  • order  : textarea line[i] → scope window[i] (master first, then slaves)
    //  • random : the lines are shuffled before being assigned to the windows
    //  • fixed  : each profile's manually-typed text goes to that exact window
    async function typeGroup(g) {
      if (!g) return;
      const ids = getScopeIds();
      if (!ids.length) return toast('Hãy bắt đầu đồng bộ trước.', 'warn');
      let assignments;
      if (g.mode === 'fixed') {
        assignments = ids.map((id) => ({ id, text: (g.fixed && g.fixed[id]) || '' }));
      } else {
        let lines = Array.isArray(g.lines) ? g.lines.slice() : [];
        if (g.mode === 'random') {
          for (let i = lines.length - 1; i > 0; i -= 1) {
            const j = Math.floor(Math.random() * (i + 1));
            [lines[i], lines[j]] = [lines[j], lines[i]];
          }
        }
        assignments = ids.map((id, i) => ({ id, text: lines[i] != null ? lines[i] : '' }));
      }
      if (!assignments.some((a) => a.text && a.text.trim())) return toast('Vui lòng nhập văn bản trước.', 'warn');
      try {
        const r = await vt.sync.typePerWindow(assignments);
        if (r && r.ok) toast(tf('Đã gõ vào {0} cửa sổ', r.count), 'ok');
        else toast((r && r.error) || 'Hãy bắt đầu đồng bộ trước khi gõ.', 'warn');
      } catch { toast('Không gõ được văn bản.', 'err'); }
    }

    function buildGroup(data, idx) {
      const n = idx + 1;
      data.fixed = data.fixed || {};
      const title = el('div.sync-tgrp-head', {}, [
        el('span.sync-sec-title.sm', { text: tf('Nhóm văn bản {0}', n) }),
      ]);
      if (tgState.length > 1) {
        title.appendChild(el('button.sync-tgrp-del', {
          html: ICONS.clearText, title: 'Xóa nhóm văn bản',
          onclick: () => { tgState.splice(idx, 1); saveGroups(); renderGroups(); },
        }));
      }

      // order/random: a labeled-row editor - each row is one window's text, prefixed by a
      // persistent "Nội dung N:" label that never disappears while typing. An empty row 1
      // therefore reads "Nội dung 1: Hãy nhập nội dung" (the placeholder), exactly per spec.
      const linesWrap = el('div.sync-nidong');
      if (!Array.isArray(data.lines) || !data.lines.length) data.lines = [''];
      // Ctrl+A "select all" across the multi-row editor: since each line is a separate <input>,
      // a native select-all can only highlight one row. We add a box-wide selected state - the
      // whole editor is highlighted, and the next Delete/Backspace or typed character clears it
      // all (textarea-like). Any normal edit / click cancels the state.
      let allSel = false;
      function clearAllSel() { if (allSel) { allSel = false; linesWrap.classList.remove('sel-all'); } }
      function renderLines(focusIdx) {
        linesWrap.textContent = '';
        data.lines.forEach((val, i) => {
          const inp = el('input.sync-nd-input', {
            value: val, placeholder: 'Hãy nhập nội dung', spellcheck: 'false',
            oninput: (e) => { clearAllSel(); data.lines[i] = e.target.value; saveGroups(); },
            onmousedown: () => clearAllSel(),
            onkeydown: (e) => {
              const mod = e.ctrlKey || e.metaKey;
              if (mod && (e.key === 'a' || e.key === 'A')) {
                e.preventDefault();
                allSel = true;
                linesWrap.classList.add('sel-all');
                e.target.select();
                return;
              }
              if (allSel) {
                if (e.key === 'Backspace' || e.key === 'Delete') {
                  e.preventDefault();
                  data.lines = ['']; saveGroups();
                  clearAllSel(); renderLines(0);
                  return;
                }
                if (e.key.length === 1 && !mod) {
                  e.preventDefault();
                  data.lines = [e.key]; saveGroups();
                  clearAllSel(); renderLines(0);
                  return;
                }
                if (e.key !== 'Shift' && e.key !== 'Control' && e.key !== 'Meta' && e.key !== 'Alt') clearAllSel();
              }
              if (e.key === 'Enter' && !e.ctrlKey && !e.shiftKey) {
                e.preventDefault();
                data.lines.splice(i + 1, 0, '');
                saveGroups();
                renderLines(i + 1);
              } else if (e.key === 'Backspace' && e.target.value === '' && data.lines.length > 1) {
                e.preventDefault();
                data.lines.splice(i, 1);
                saveGroups();
                renderLines(Math.max(0, i - 1));
              }
            },
            onpaste: (e) => {
              const txt = (e.clipboardData || window.clipboardData).getData('text');
              if (txt.indexOf('\n') === -1) return; // single line → default behaviour
              e.preventDefault();
              const parts = txt.replace(/\r/g, '').split('\n');
              const cur = data.lines[i] || '';
              const pos = e.target.selectionStart || 0;
              parts[0] = cur.slice(0, pos) + parts[0];
              parts[parts.length - 1] += cur.slice(pos);
              data.lines.splice(i, 1, ...parts);
              saveGroups();
              renderLines(i + parts.length - 1);
            },
          });
          linesWrap.appendChild(el('div.sync-nd-row', {}, [
            el('span.sync-nd-label', { text: tf('Nội dung {0}:', i + 1) }),
            inp,
          ]));
        });
        if (focusIdx != null) {
          const rows = linesWrap.querySelectorAll('.sync-nd-input');
          const target = rows[focusIdx];
          if (target) { target.focus(); const L = target.value.length; target.setSelectionRange(L, L); }
        }
      }

      // fixed ("Được chỉ định"): one row per open window - left = profile SHORT ID, right = the
      // text the user types by hand for that specific window (full name kept in the tooltip).
      const fixedWrap = el('div.sync-fixed');
      function renderFixed() {
        fixedWrap.textContent = '';
        const ids = getScopeIds();
        if (!ids.length) { fixedWrap.appendChild(el('div.sync-fixed-empty.muted', { text: 'Không có cửa sổ nào đang mở.' })); return; }
        ids.forEach((id) => {
          // Same inline-row look as order/random, but the persistent label is the OPEN
          // PROFILE'S SHORT ID (not "Nội dung N") - each window's manual text on the right.
          const nameEl = el('span.sync-nd-label.is-name', { text: `${shortId({ id })}:`, title: String(id) });
          const inp = el('input.sync-nd-input', {
            value: data.fixed[id] || '', placeholder: 'Hãy nhập nội dung',
            oninput: (e) => { data.fixed[id] = e.target.value; saveGroups(); },
          });
          fixedWrap.appendChild(el('div.sync-nd-row', {}, [nameEl, inp]));
          profileNameMap().then((m) => { const info = m.get(String(id)); if (info) { nameEl.textContent = `${info.short}:`; nameEl.title = info.name; } });
        });
      }

      // "Gõ như con người" button (label fixed by the user - do NOT rename).
      const typeBtn = el('button.sync-typebtn', {
        type: 'button', text: 'Gõ như con người', title: 'Gõ văn bản vào từng cửa sổ',
        onclick: (e) => { e.preventDefault(); typeGroup(tgState[idx]); },
      });
      // AdsPower-style footer hint, shown only for the textarea (order/random) modes.
      const hint = el('span.sync-foot-hint', { text: 'Enter Văn bản tiếp theo / Enter Xuống dòng' });

      // ONE bordered box wraps the textarea/rows AND the footer (hint left, "Gõ như con người"
      // right) - matching the reference UI. The box swaps its body on mode change.
      const box = el('div.sync-sametext');
      const foot = el('div.sync-sametext-foot');
      function applyMode(mode) {
        box.textContent = '';
        foot.textContent = '';
        if (mode === 'fixed') {
          renderFixed();
          box.appendChild(fixedWrap);
          foot.appendChild(typeBtn);             // button only (margin-left:auto keeps it right)
        } else {
          renderLines();
          box.appendChild(linesWrap);
          foot.appendChild(hint);                // left
          foot.appendChild(typeBtn);             // right
        }
        box.appendChild(foot);
      }
      applyMode(data.mode || 'order');

      return el('div.sync-panel.sync-text-group', {}, [
        title,
        radioGroup(`sync-tgrp-${n}`, [['order', 'Nhập theo thứ tự'], ['random', 'Nhập ngẫu nhiên'], ['fixed', 'Được chỉ định']], data.mode || 'order',
          (v) => { if (tgState[idx]) { tgState[idx].mode = v; saveGroups(); } applyMode(v); }),
        box,
      ]);
    }
    function renderGroups() {
      groupsWrap.textContent = '';
      tgState.forEach((g, i) => groupsWrap.appendChild(buildGroup(g, i)));
    }
    function addGroupNew() { tgState.push({ mode: 'order', lines: [''], fixed: {} }); saveGroups(); renderGroups(); }
    renderGroups();

    const range = Object.assign({ min: '0.001', max: '0.009' }, store.range || {});
    return el('div.sync-tabpane', {}, [
      el('div.sync-pane-actions', {}, [
        regBtn(el('button.sync-obtn', { html: `${ICONS.clearText}<span>Xóa văn bản</span>`, onclick: clearAllText }), 'sync'),
        regBtn(el('button.sync-obtn', { html: `${ICONS.paste}<span>Dán văn bản</span>`, onclick: pasteAllText }), 'sync'),
      ]),
      el('div.sync-sec-title', { text: 'Mô phỏng hành động' }),
      el('div.sync-tinfo-row', {}, [
        toggleInfo('Độ trễ nhấp chuột', sim.clickDelay, (v) => { sim.clickDelay = v; saveSim(); }),
        toggleInfo('Độ trễ gõ phím', sim.typeDelay, (v) => { sim.typeDelay = v; saveSim(); }),
      ]),
      el('div.sync-num-row', {}, [
        numField('Tốc độ (ms)', sim.speed, (v) => { sim.speed = v; saveSim(); }),
        numField('Độ trễ (ms)', sim.delay, (v) => { sim.delay = v; saveSim(); }),
      ]),
      el('div.sync-sec-title', { text: 'Số ngẫu nhiên' }),
      el('div.sync-panel.sync-range', {}, [
        el('span.sync-flabel', { text: 'Phạm vi' }),
        el('input.input', { value: range.min, style: { width: '88px' }, oninput: (e) => { range.min = e.target.value; persist({ range }); } }),
        el('input.input', { value: range.max, style: { width: '88px' }, oninput: (e) => { range.max = e.target.value; persist({ range }); } }),
        el('button.sync-obtn.is-disabled', { text: 'Ngẫu nhiên', onclick: () => notSupported() }),
      ]),
      el('div.sync-sec-title', { text: 'Văn bản giống nhau' }),
      typeBox({
        value: store.sameText, placeholder: 'Vui lòng nhập',
        oninput: (e) => persist({ sameText: e.target.value }),
        onType: (v) => typeLikeHuman(v),
      }),
      el('div.sync-sec-title', { text: 'Văn bản chỉ định' }),
      groupsWrap,
      el('button.btn.sync-cta.sync-addbtn', { html: `${ICONS.plus}<span>Thêm nhóm văn bản</span>`, onclick: addGroupNew }),
    ]);
  }

  // -- Tab: Tab --
  // Live tab utilities over the synced windows. Every action drives the MASTER window and the
  // action-sync engine mirrors it to each slave (open/close/navigate), so they all need sync
  // RUNNING - registered as 'sync' so the buttons enable/disable with the engine state.
  function buildTabTab() {
    // Run a tab command, then toast its result. `okMsg` is a tf() template with {0} = window count.
    async function tabAction(fn, okMsg) {
      try {
        const r = await fn();
        if (r && r.ok) toast(tf(okMsg, r.count || 0), 'ok');
        else toast((r && r.error) || 'Hãy bắt đầu đồng bộ trước.', 'warn');
      } catch { toast('Thao tác không thành công.', 'err'); }
    }
    // "Mở": open the textarea's URLs across the synced windows, honouring the "tab mới" toggle.
    async function openUrls() {
      const urls = (urlTa.value || '').split('\n').map((s) => s.trim()).filter(Boolean);
      if (!urls.length) return toast('Vui lòng nhập URL trước.', 'warn');
      await tabAction(() => vt.sync.openTabs(urls, { newTab: sim.newTab }), 'Đã mở URL trên {0} cửa sổ');
    }

    const urlTa = el('textarea.input.sync-ta', {
      rows: '4', placeholder: 'Vui lòng nhập URL, phân tách bằng dòng',
      oninput: (e) => persist({ tabUrls: e.target.value }),
    });
    urlTa.value = store.tabUrls || '';

    return el('div.sync-tabpane', {}, [
      el('div.sync-tab-actions', {}, [
        regBtn(el('button.sync-obtn', { html: `${ICONS.folder}<span>Đồng bộ Tab</span>`,
          onclick: (e) => withSpin(e.currentTarget, () => tabAction(() => vt.sync.resyncTabs(), 'Đã đồng bộ tab cho {0} cửa sổ')) }), 'sync'),
        regBtn(el('button.sync-obtn', { html: `${ICONS.copy}<span>Đóng các tab khác</span>`,
          onclick: (e) => withSpin(e.currentTarget, () => tabAction(() => vt.sync.closeOtherTabs(), 'Đã đóng tab thừa ở {0} cửa sổ')) }), 'sync'),
        regBtn(el('button.sync-obtn', { html: `${ICONS.pin}<span>Đóng tab hiện tại</span>`,
          onclick: (e) => withSpin(e.currentTarget, () => tabAction(() => vt.sync.closeCurrentTab(), 'Đã đóng tab hiện tại ở {0} cửa sổ')) }), 'sync'),
        regBtn(el('button.sync-obtn', { html: `${ICONS.blank}<span>Đóng tab trống</span>`,
          onclick: (e) => withSpin(e.currentTarget, () => tabAction(() => vt.sync.closeBlankTabs(), 'Đã đóng tab trống ở {0} cửa sổ')) }), 'sync'),
      ]),
      el('div.sync-sec-title', { text: 'Truy cập trang web' }),
      urlTa,
      el('label.sync-toggle-row', {}, [switchEl(sim.newTab, (v) => { sim.newTab = v; saveSim(); }), el('span', { text: 'Mở link trong tab mới' })]),
      regBtn(el('button.btn.primary.sync-cta', { html: `${ICONS.open}<span>Mở</span>`,
        onclick: (e) => withSpin(e.currentTarget, openUrls) }), 'sync'),
    ]);
  }

  const TABS = [
    ['window', 'Cửa sổ', ICONS.monitor, buildWindowTab],
    ['text', 'Văn bản', ICONS.text, buildTextTab],
    ['tab', 'Tab', ICONS.tab, buildTabTab],
  ];
  let activeTab = 'window';
  const ctabs = el('div.sync-ctabs');
  function paintTabs() {
    clear(ctabs);
    TABS.forEach(([id, label, ic]) => {
      ctabs.appendChild(el('button.sync-ctab' + (id === activeTab ? '.active' : ''), {
        type: 'button', html: `<span class="sync-ctab-ico">${ic}</span><span>${label}</span>`,
        onclick: () => { activeTab = id; paintTabs(); paintBody(); },
      }));
    });
  }
  function paintBody() {
    clear(consoleBody);
    // Each tab rebuilds its buttons, which re-register on the (reset) state registry.
    stateBtns = [];
    const builder = TABS.find(([id]) => id === activeTab)[3];
    consoleBody.appendChild(builder());
    applyStates();
  }
  paintTabs();
  paintBody();

  // Keep button enable/disable in sync with reality: window ops need ≥1 open window in
  // scope; sync ops (Xóa/Dán/Gõ văn bản) need action-sync running. Seed from current
  // status, then follow the live broadcasts (sync status + running-window set).
  try {
    if (vt.sync && vt.sync.status) {
      vt.sync.status().then((st) => { syncRunning = !!(st && st.running); applyStates(); }).catch(() => {});
    }
  } catch { /* ignore */ }
  if (vt.sync && vt.sync.onStatus) {
    vt.sync.onStatus((st) => { syncRunning = !!(st && st.running); applyStates(); });
  }
  if (vt.profiles && vt.profiles.onRunningChanged) {
    vt.profiles.onRunningChanged(() => applyStates());
  }

  const collapseBtn = el('button.sync-collapse', { html: ICONS.collapse, title: env.collapseTitle || 'Thu gọn' });
  if (env.onCollapse) collapseBtn.onclick = env.onCollapse;

  const root = el('div.sync-console' + (env.extraClass ? '.' + env.extraClass : ''), {}, [
    el('div.sync-console-head', {}, [
      el('div.sync-console-title', { text: 'Console' }),
      collapseBtn,
    ]),
    ctabs,
    consoleBody,
  ]);

  // ctabsEl / bodyEl are exposed so the detached Console window can re-compose
  // them under its own custom (compact/hover-expand) header instead of `root`.
  return { el: root, getLayout: () => winLayoutChoice, ctabsEl: ctabs, bodyEl: consoleBody };
}
