// Port of AboutView.xaml - build/license/credits page (static info card stack).
import { el } from '../ui.js';

function row(k, v) {
  return el('div.about-row', {}, [
    el('div', { style: { fontWeight: 400 }, text: k }),
    el('div.muted', { text: v }),
  ]);
}

function card(children) {
  return el('div.card', { style: { padding: '22px', marginBottom: '20px' } }, children);
}

export function render(ctx) {
  const page = el('div.page.about-page', {}, [
    el('div.page-head', {}, [el('div.muted', { text: 'Build, license and credits' })]),

    el('div.about-scroll', {}, [
      // hero card
      el('div.card', { style: { padding: '32px', marginBottom: '20px', textAlign: 'center' } }, [
        el('div.about-logo', { html: '<img src="assets/cgt-logo.svg" alt="CGTBrowser">' }),
        el('h2', { style: { margin: '18px 0 2px', fontSize: '28px' }, text: 'CGTBrowser' }),
        el('div.muted', { text: 'Anti-detect browser manager · UI preview' }),
        el('div.about-chips', {}, [
          // Số phiên bản ĐỌC TỪ package.json qua window.vt.appVersion - không ghi cứng,
          // nếu không mỗi lần nâng bản là chip này kẹt lại ở số cũ.
          el('span.chip.accent', { text: `Version ${(window.vt && window.vt.appVersion) || ''}`.trim() }),
          el('span.chip', { text: 'Build 2026.09.21' }),
          el('span.chip', { text: '.NET → Electron' }),
        ]),
        el('button.btn.primary', { style: { marginTop: '18px' }, text: 'Check for updates' }),
      ]),

      // build info
      card([
        el('h3', { text: 'Build information' }),
        row('Browser core', 'Chromium (puppeteer-core)'),
        el('div.hairline'),
        row('UI engine', 'Electron · Chromium + Node'),
        el('div.hairline'),
        row('OS', 'Windows'),
        el('div.hairline'),
        row('License', 'Free plan - preview UI'),
      ]),

      // links
      card([
        el('h3', { text: 'Useful links' }),
        el('div.about-link', { onclick: () => vt.shell.openExternal('https://cgtdev.space') }, [el('span', { text: 'Website · cgtdev.space' })]),
        el('div.about-link', {}, [el('span', { text: 'Documentation' })]),
        el('div.about-link', {}, [el('span', { text: 'Changelog' })]),
        el('div.about-link', {}, [el('span', { text: 'Report a security issue' })]),
      ]),

      // credits
      card([
        el('h3', { text: 'Credits' }),
        el('div.muted', { text: 'Icons: inline stroke SVG set (Segoe Fluent equivalents).' }),
        el('div.muted', { text: 'UI font: Nunito.' }),
        el('div.muted', { text: 'Browser engine: Chromium (BSD).' }),
      ]),

      el('div.muted', { style: { textAlign: 'center', marginBottom: '24px' }, text: '© 2026 CGTBrowser. All rights reserved.' }),
    ]),
  ]);
  ctx.container.appendChild(page);
  return null;
}
