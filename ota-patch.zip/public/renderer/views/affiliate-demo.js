// DỮ LIỆU DIỄN TẬP cho trang "Hoa hồng" (user yêu cầu 2026-10-20: "thêm dữ liệu diễn tập khi
// mở Hoa hồng để hình dung mô phỏng thực tế").
//
// VÌ SAO CẦN: tài khoản dùng để xem UI thường chưa mời được ai, nên trang thật chỉ hiện 0₫ và
// ba bảng rỗng ("Chưa có ai đăng ký bằng mã của bạn."). Không nhìn được bảng có dòng, pager,
// pill trạng thái, số tiền 7 chữ số có vỡ cột hay không... tức không duyệt được giao diện.
//
// ⚠️⚠️ ĐÂY LÀ TỆP DEV-ONLY VÀ NÓ KHÔNG BAO GIỜ ĐƯỢC NẠP Ở ĐƯỜNG CHẠY THẬT.
//   `views/affiliate.js` chỉ `await import()` tệp này KHI cờ `localStorage.polyAffDemo === '1'`.
//   ⛔ ĐỪNG đổi sang `import` tĩnh ở đầu affiliate.js cho "gọn": import tĩnh là nạp VÔ ĐIỀU
//      KIỆN, tức mọi bản cài đều mang theo bảng số liệu giả này trong bộ nhớ, và chỉ cần một
//      lỗi gán nhầm biến là khách thấy tiền ảo. Động + có cờ là HAI tầng chặn, giữ cả hai.
//   ⛔ ĐỪNG gọi tệp này từ bất kỳ chỗ nào khác (kể cả test): nó là dữ liệu để NGẮM, không phải
//      fixture để khẳng định. Test cần fixture thì tự khai trong tệp test - fixture dùng chung
//      với dữ liệu demo là mỗi lần sửa demo cho đẹp mắt lại làm test đổi kết quả.
//
// ⚠️ MỌI MỐC THỜI GIAN TÍNH TỪ `Date.now()`, KHÔNG ghi cứng epoch: ghi cứng thì sang tháng sau
//    là bảng toàn ngày cũ và cột "Ngày" mất ý nghĩa, còn ô "Tháng này" thì không khớp dòng nào.
// ⚠️ Các con số PHẢI khớp nhau theo đúng luật của server, nếu không trang tự mâu thuẫn và
//    người duyệt UI sẽ đi tìm lỗi không tồn tại:
//      - `stats.earnedTotal` = tổng `amount` của MỌI dòng commissions (kể cả dòng 'void' = 0);
//      - `balance.pending`   = tổng `amount` các dòng status 'pending';
//      - `balance.available` = tổng 'available' TRỪ phần đã rút/đang chờ rút;
//      - `stats.referrals`   = số dòng referrals; `payingReferees` = số dòng có `orders > 0`;
//      - `referrals[i].earned` = tổng hoa hồng của chính người đó trong commissions.
//    Hàm dưới đây TỰ TÍNH mấy tổng đó từ danh sách thay vì ghi tay - sửa một dòng là mọi ô
//    trên trang vẫn khớp.
// ⚠️ Email phải ở dạng ĐÃ CHE (`ab***@gmail.com`) vì server thật trả về dạng che - để email
//    đầy đủ ở đây là người duyệt UI tưởng cột đó rộng hơn thực tế.

const DAY = 86400000;

// 23 người được mời. Chủ ý trộn: người nhiều đơn, người 0 đơn (mời được nhưng chưa mua), tên
// email dài/ngắn khác nhau để soi cột Email co giãn.
// Mỗi dòng: [email ĐÃ CHE, số ngày trước tính từ hôm nay, số giao dịch].
//
// ⚠️ SỐ GIAO DỊCH KHÔNG ĐƯỢC HẠ TUỲ Ý. Hai con số dưới đây phụ thuộc vào nó:
//   - Phải có người vượt `MAX_PER_REFEREE`, nếu không thì KHÔNG dòng nào `capped`/`void` và mất
//     đúng hai trạng thái chỉ nhìn được bằng dữ liệu diễn tập (hiện: `do.` 5 đơn và `lam` 7 đơn
//     đều chạm trần, cho ra 2 dòng chạm trần + 2 dòng 'void').
//   - `available` = earnedTotal - pending - đã chi, phải DƯƠNG và ≥ `minWithdraw` (200.000) để
//     nút "Rút tiền" MỞ. Bảng cũ (27 đơn) cho earnedTotal 2.041.300 trong khi riêng pending đã
//     1.055.300 ⇒ available ra ÂM 714.000 và bị kẹp về 0 ⇒ ô "Có thể rút" hiện 0₫, nút bị khoá,
//     tức đúng cái màn hình trống rỗng mà dữ liệu diễn tập sinh ra để tránh. Kẹp sàn 0 che mất
//     lỗi này nên nó KHÔNG tự lộ ra - chạy `test/_diag-aff-demo.mjs` sau khi sửa bảng.
const PEOPLE = [
  ['ngu***@gmail.com', 2, 4], ['tra***@gmail.com', 5, 2], ['hoa***@outlook.com', 6, 1],
  ['le.***@gmail.com', 9, 3], ['pha***@yahoo.com', 12, 0], ['dan***@gmail.com', 14, 3],
  ['vu.***@gmail.com', 18, 2], ['bui***@hotmail.com', 21, 0], ['do.***@gmail.com', 24, 5],
  ['ngo***@gmail.com', 27, 2], ['duo***@gmail.com', 31, 0], ['hu0***@gmail.com', 35, 4],
  ['ma.***@proton.me', 38, 0], ['truc**@gmail.com', 42, 3], ['kha***@gmail.com', 47, 0],
  ['lam***@gmail.com', 51, 7], ['tie***@gmail.com', 56, 0], ['qua***@gmail.com', 61, 2],
  ['bao***@gmail.com', 68, 0], ['chi***@gmail.com', 74, 1], ['die***@gmail.com', 83, 3],
  ['gia***@gmail.com', 91, 0], ['huy***@gmail.com', 104, 0],
];

// Giá trị đơn hàng có thật của app: gói tháng/quý/năm + mua kịch bản ở Chợ.
const ORDER_VALUES = [199000, 549000, 1990000, 99000, 350000];

const PERCENT = 10;
const HOLD_DAYS = 7;
// Trần hoa hồng mỗi người được mời. BẬT (≠ 0) là có chủ ý: đó là cách duy nhất nhìn được dòng
// "chạm trần" và dòng 'void'. ⚠️ Trị số phải VỚI TỚI ĐƯỢC bằng số đơn trong PEOPLE: bản đầu để
// 2.000.000 trong khi người mua nhiều nhất chỉ gom được 318.700 ⇒ trần không bao giờ chạm, không
// một dòng capped/void nào, và chú thích "bật trần để nhìn được pill" thành ra nói sai.
const MAX_PER_REFEREE = 300000;

export function demoSnapshot() {
  const now = Date.now();
  const commissions = [];
  const referrals = [];

  PEOPLE.forEach(([email, daysAgo, orders], idx) => {
    const referredAt = now - daysAgo * DAY;
    let earnedForThisPerson = 0;

    for (let k = 0; k < orders; k += 1) {
      // Đơn luôn SAU ngày đăng ký và TRƯỚC hôm nay - dữ liệu diễn tập mà có đơn trước ngày
      // đăng ký thì người duyệt sẽ báo đó là lỗi sắp xếp của bảng.
      const createdAt = referredAt + Math.round((k + 1) * (daysAgo * DAY) / (orders + 1));
      const baseAmount = ORDER_VALUES[(idx + k) % ORDER_VALUES.length];
      const raw = Math.round(baseAmount * PERCENT / 100);

      // Kẹp theo trần mỗi người, ĐÚNG như server: phần vượt bị cắt, và khi đã đủ trần thì
      // dòng tiếp theo là 'void' (amount 0) chứ không bị bỏ qua.
      const room = Math.max(0, MAX_PER_REFEREE - earnedForThisPerson);
      const amount = Math.min(raw, room);
      const capped = amount > 0 && amount < raw;
      earnedForThisPerson += amount;

      // 'pending' nếu còn trong hạn giữ, 'available' nếu đã qua; amount 0 = 'void'.
      const status = amount === 0 ? 'void' : (now - createdAt < HOLD_DAYS * DAY ? 'pending' : 'available');
      commissions.push({
        id: 'demo-c-' + idx + '-' + k,
        createdAt, refereeEmail: email, baseAmount, percent: PERCENT, amount, capped, status,
      });
    }

    referrals.push({ id: 'demo-r-' + idx, email, referredAt, orders, earned: earnedForThisPerson });
  });

  const sum = (arr, f) => arr.reduce((a, x) => a + (f(x) || 0), 0);
  const earnedTotal = sum(commissions, (c) => c.amount);
  const pending = sum(commissions.filter((c) => c.status === 'pending'), (c) => c.amount);
  const monthStart = new Date(now); monthStart.setDate(1); monthStart.setHours(0, 0, 0, 0);
  const earnedMonth = sum(commissions.filter((c) => c.createdAt >= monthStart.getTime()), (c) => c.amount);

  // HAI lượt rút đã xong: một đã chi, một bị từ chối (để nhìn được ô "Ghi chú của admin" có chữ
  // thật - "Bị từ chối" mà không kèm lý do là một chữ không giải thích gì).
  //
  // ⛔ CỐ Ý KHÔNG có lượt ĐANG CHỜ, dù đó cũng là một trạng thái UI đáng xem. Lý do: một yêu cầu
  //    chờ duyệt KHOÁ nút "Rút tiền" (server chặn HAS_PENDING, trang bám đúng luật đó) ⇒ mở trang
  //    ra là nút xám, modal "Yêu cầu rút hoa hồng" không vào được, và đó lại chính là phần giao
  //    diện nhiều thứ phải ngắm nhất. Để trống thì nút MỞ, bấm vào xem được modal, gửi thử xong
  //    `affiliate.js` tự mô phỏng một dòng chờ duyệt ngay tại chỗ (KHÔNG gọi server) ⇒ xem được
  //    CẢ HAI trạng thái, theo đúng thứ tự người dùng thật gặp.
  //    Muốn nhìn ngay trạng thái bị khoá thì thêm một dòng `status: 'pending'` vào đây - nhưng
  //    nhớ là `available` sẽ bị trừ thêm đúng số đó (xem công thức dưới), đừng để nó xuống dưới
  //    `minWithdraw`.
  const withdrawals = [
    {
      id: 'demo-w-1', requestedAt: now - 46 * DAY, amount: 600000, status: 'paid',
      bankName: 'Vietcombank', bankAccount: '0071****4512', bankHolder: 'NGUYEN VAN A',
      adminNote: 'Đã chuyển khoản.',
    },
    {
      id: 'demo-w-2', requestedAt: now - 23 * DAY, amount: 800000, status: 'rejected',
      bankName: 'Techcombank', bankAccount: '1903****8871', bankHolder: 'NGUYEN VAN A',
      adminNote: 'Tên chủ tài khoản không khớp với tên trên hồ sơ. Vui lòng gửi lại.',
    },
  ];
  // Tự TÌM trong danh sách chứ đừng ghi tay `null`: thêm một dòng 'pending' ở trên mà quên sửa
  // dòng này là bảng có yêu cầu chờ duyệt trong khi nút "Rút tiền" vẫn mở - trang tự mâu thuẫn.
  const pendingWithdrawal = withdrawals.find((w) => w.status === 'pending') || null;
  const withdrawn = sum(withdrawals.filter((w) => w.status === 'paid'), (w) => w.amount);

  // `available` = đã qua hạn giữ, TRỪ số đã chi và số đang treo trong yêu cầu chờ duyệt.
  // Kẹp sàn 0: nếu chỉnh mấy con số trên mà ra âm thì ô "Có thể rút" hiện "-500.000₫" và đó là
  // thứ sẽ bị báo là lỗi hiển thị.
  const availRaw = earnedTotal - pending - withdrawn - (pendingWithdrawal ? pendingWithdrawal.amount : 0);
  const available = Math.max(0, availRaw);

  return {
    __demo: true,                 // cờ để affiliate.js biết đang vẽ dữ liệu giả (vẽ dải cảnh báo)
    enabled: true,
    refCode: 'K7MQ2XVB',          // 8 ký tự, bộ không có 0/O/1/I/L - y khuôn mã thật
    policy: {
      percent: PERCENT, holdDays: HOLD_DAYS, minWithdraw: 200000, minReferrals: 1,
      maxPerReferee: MAX_PER_REFEREE, maxPerMonth: 0, refereeBonus: 50000,
    },
    balance: { pending, available, locked: 0, withdrawn },
    stats: {
      earnedTotal, earnedMonth,
      referrals: referrals.length,
      payingReferees: referrals.filter((r) => r.orders > 0).length,
    },
    pendingWithdrawal, referrals, commissions, withdrawals,
  };
}
