// Trang "Tạo hàng loạt" - DÙNG NGUYÊN giao diện màn "Tạo hồ sơ" (profile_create.js):
// cùng bố cục 4 mục (Cài đặt chung / Proxy / Dấu vân tay / Nâng cao), cùng tab
// scrollspy + cột "Tổng quan". Chỉ THÊM 2 cấu hình riêng cho việc tạo nhiều hồ sơ:
//   • Số bắt đầu - số thứ tự gắn vào tên hồ sơ đầu tiên.
//   • Số lượng   - số hồ sơ cần tạo.
// Tên hồ sơ = TÊN GỐC + SỐ THỨ TỰ (vd "Acc1", "Acc2", …). MỖI hồ sơ được sinh 1 dấu
// vân tay RIÊNG (GPU/CPU/RAM/tên máy/MAC + seed ngẫu nhiên bám OS) nên dù chung cấu
// hình, mỗi profile vẫn là một "máy" khác nhau - đúng tinh thần antidetect.
import { el, clear, toast, customSelect, alertDialog } from '../ui.js';
import { icon } from '../icons.js';
import { remote } from '../data/remote-ds.js';
import { notifyError } from '../data/errors.js';
import { hasFeature, gateFeature } from '../data/plan-features.js';
import { tf } from '../i18n.js';
import { PROXY_TYPES, PROXY_TYPE_DEFAULT, normalizeProxyType } from '../data/proxy-types.js';
import { uaString, osGpu, osDeviceName, osHardware, randMac, newFingerprint, buildFpConfig, WEBGL_VENDORS, osFonts, setAllPools, hasPools, chromeMajors, firefoxMajors, randomChromeFull, TIMEZONES, LOCALES, RESOLUTIONS } from '../data/fingerprint.js';
// Modal tải nhân + đồng bộ fingerprint theo nhân đang dùng - dùng cho dropdown
// "Trình duyệt", Y HỆT màn tạo-đơn: chỉ nhân ĐÃ CÀI mới chọn được, bản CHƯA CÀI
// bấm vào sẽ mở modal tải.
import { openKernelDownloadModal, syncActiveKernelToFingerprint } from './kernels.js';
// Nhãn engine + nhãn dòng "Browser Kernel": DÙNG CHUNG với màn tạo-đơn (xem chú thích
// trong data/browser-badge.js). Không chép lại ở đây nữa để hai màn KHÔNG THỂ lệch nhau.
import { ENGINE_LABEL, kernelLabel } from '../data/browser-badge.js';

const KERNEL_PLATFORM = 'win-x64';
// Hai nhân: Chromium đã vá (ChromeBrowser, val nội bộ 'Poly') và Firefox đã vá
// (FirefoxBrowser, val 'Firefox'). Cả hai nhận cùng blob --fp-config.
const KERNELS = [
  ['Poly', 'ChromeBrowser', { icon: 'chrome' }],
  ['Firefox', 'FirefoxBrowser', { icon: 'firefox' }],
];
// Nhân UI ('Poly'/'Firefox') → engine kho nhân ('chromium'/'firefox').
function engineOf(kernel) { return kernel === 'Firefox' ? 'firefox' : 'chromium'; }
const OS_GROUPS = [
  { os: 'Windows', icon: 'windows', versions: ['Windows 11', 'Windows 10', 'Windows 8', 'Windows 7'] },
  { os: 'macOS', icon: 'apple', versions: ['macOS 26', 'macOS 15', 'macOS 14', 'macOS 13', 'macOS 12', 'macOS 11', 'macOS 10'] },
  { os: 'Linux', icon: 'linux', versions: ['Linux x86_64'] },
  { os: 'Android', icon: 'android', versions: ['Android 15', 'Android 14', 'Android 13', 'Android 12', 'Android 11', 'Android 10', 'Android 9'] },
  { os: 'iOS', icon: 'ios', versions: ['iOS 26', 'iOS 18', 'iOS 17', 'iOS 16', 'iOS 15', 'iOS 14', 'iOS 13'] },
];

const SECTIONS = [
  ['general', 'Cài đặt chung'],
  ['proxy', 'Proxy'],
  ['fingerprint', 'Dấu vân tay'],
  ['advanced', 'Nâng cao'],
];

// Dòng "Browser Kernel": engine + major đang chọn ở card "Trình duyệt" - Y HỆT màn
// tạo-đơn vì cùng gọi kernelLabel() ở data/browser-badge.js.
function overviewRows(fp, kernel, ua, osVersion, kernelVer) {
  return [
    ['Browser Kernel', kernelLabel(engineOf(kernel), kernelVer)],
    ['Hệ điều hành', osVersion || ''],
    ['User-Agent', ua],
    ['Múi giờ', fp.timezone], ['WebRTC', fp.webRTC], ['Địa chỉ', fp.geo], ['Ngôn ngữ', fp.language],
    ['Ngôn ngữ hiển thị', fp.displayLanguage],
    ['Độ phân giải', fp.resolution], ['Canvas', fp.canvas],
    ['Avatar WebGL', fp.webglImage], ['AudioContext', fp.audioContext],
    ['Thiết bị truyền thông', fp.mediaDevice], ['SpeechVoices', fp.speechVoice],
    ['ClientRects', fp.clientRects],
    ['WebGL metadata', fp.webglMeta], ['WebGPU', fp.webGPU],
    ['CPU', tf('{0} Nhân', fp.cpu)], ['RAM', `${fp.ram} GB`], ['Tên thiết bị', fp.deviceName], ['Địa chỉ MAC', fp.mac],
    ['Do Not Track', fp.doNotTrack], ['Tăng tốc phần cứng', fp.hardwareAccel],
    ['Hiển thị hình ảnh', fp.imageLoad], ['Âm thanh', fp.audioPlay],
  ];
}

// ---- small reusable controls (giống profile_create.js) -----------------
const frow = (label, control, opts = {}) =>
  el('div.pc-frow' + (opts.required ? '.req' : ''), {}, [
    el('div.pc-flabel' + (opts.extra ? '.extra' : ''), {
      [opts.labelHtml ? 'html' : 'text']: opts.labelHtml || label,
      title: opts.extra ? 'Tùy chọn này không có trong fp-config (chỉ ở ứng dụng)' : undefined,
    }),
    el('div.pc-fctl', {}, Array.isArray(control) ? control : [control]),
  ]);

// Notched-outline field: label sits on the input's top border (Material style).
// Used for the batch-only "Số bắt đầu" / "Số lượng" pair so they share one line.
const notch = (label, input, opts = {}) =>
  el('div.pc-notch' + (opts.required ? '.req' : ''), {}, [
    input,
    el('label.pc-notch-lbl', { text: label }),
  ]);

function pills(options, value, onChange) {
  const norm = options.map((o) => (Array.isArray(o) ? o : [o, o]));
  const wrap = el('div.seg.pc-seg');
  function render() {
    clear(wrap);
    norm.forEach(([v, l, ic, tip]) => {
      wrap.appendChild(el('button.seg-opt' + (v === value ? '.active' : ''), {
        type: 'button',
        title: tip || undefined,
        html: (ic ? icon(ic) : '') + `<span>${l}</span>`,
        onclick: () => { value = v; render(); onChange && onChange(v); },
      }));
    });
  }
  render();
  Object.defineProperty(wrap, 'value', { get: () => value });
  return wrap;
}

function switchEl(on, onChange) {
  let state = !!on;
  const btn = el('button.switch' + (state ? '.on' : ''), { type: 'button' }, [el('span.knob')]);
  btn.onclick = () => { state = !state; btn.classList.toggle('on', state); onChange && onChange(state); };
  Object.defineProperty(btn, 'on', { get: () => state });
  return btn;
}

function groupPicker(initialGroups, value, onChange) {
  let groups = (initialGroups || []).slice();
  let val = value || '';
  const wrap = el('div.pc-select.gsel');
  const trigger = el('button.pc-select-trigger', { type: 'button' });
  const panel = el('div.tagsel-panel.gsel-panel');
  const optList = el('div.tagsel-opts');
  const search = el('input.tagsel-add-input', { placeholder: 'Tìm nhóm/ Tạo nhóm' });
  const nameOf = (id) => { if (!id) return 'Chưa chia nhóm'; const g = groups.find((x) => x.id === id); return g ? g.name : 'Chưa chia nhóm'; };
  function renderTrigger() { trigger.innerHTML = `<span class="lbl${val ? '' : ' ph'}">${nameOf(val)}</span><span class="chev">${icon('chevronDown')}</span>`; }
  function setVal(id) { val = id; renderTrigger(); if (onChange) onChange(val); }
  async function createGroup() {
    const name = search.value.trim(); if (!name) return;
    try { const ng = await remote.groups.create({ name }); if (ng && ng.id) { groups.push(ng); setVal(ng.id); } close(); toast('Đã tạo nhóm', 'ok'); }
    catch (e) { toast('Lỗi tạo nhóm: ' + ((e && e.message) || e), 'err'); }
  }
  function renderOpts() {
    clear(optList);
    const q = search.value.trim().toLowerCase();
    const rows = [{ id: '', name: 'Chưa chia nhóm' }, ...groups].filter((g) => !q || g.name.toLowerCase().includes(q));
    rows.forEach((g) => {
      const on = g.id === val;
      optList.appendChild(el('div.tagsel-opt' + (on ? '.sel' : ''), { onclick: () => { setVal(g.id); close(); } },
        [el('span.tagsel-opt-lbl', { text: g.name }), on ? el('span.tagsel-ck', { html: icon('check') }) : null]));
    });
    optList.appendChild(el('div.tagsel-empty.muted', { text: rows.length ? 'Không còn nội dung' : 'Không có dữ liệu' }));
  }
  const onDoc = (e) => { if (!wrap.contains(e.target)) close(); };
  function open() { wrap.classList.add('open'); renderOpts(); setTimeout(() => search.focus(), 0); document.addEventListener('mousedown', onDoc); }
  function close() { wrap.classList.remove('open'); document.removeEventListener('mousedown', onDoc); }
  trigger.onclick = () => { wrap.classList.contains('open') ? close() : open(); };
  search.oninput = renderOpts;
  search.onkeydown = (e) => { if (e.key === 'Enter') { e.preventDefault(); const q = search.value.trim().toLowerCase(); if (q && !groups.some((g) => g.name.toLowerCase() === q)) createGroup(); } };
  const addBtn = el('button.tagsel-addbtn', { type: 'button', html: '<span>Tạo</span>', onclick: createGroup });
  panel.appendChild(el('div.tagsel-add', {}, [el('span.tagsel-add-ico.gsel-add-ico', { html: icon('search') }), search, addBtn]));
  panel.appendChild(el('div.tagsel-div'));
  panel.appendChild(optList);
  wrap.appendChild(trigger); wrap.appendChild(panel);
  Object.defineProperty(wrap, 'value', { get: () => val, set: (v) => { val = v; renderTrigger(); }, configurable: true });
  wrap.setGroups = (list) => { groups = (list || []).slice(); renderTrigger(); };
  renderTrigger();
  return wrap;
}

function tagSelect(initialTags) {
  const current = new Set((initialTags || []).filter(Boolean));
  let allTags = [];
  const wrap = el('div.tagsel.pc-tagsel');
  const trigger = el('div.tagsel-trigger', { tabindex: '0' });
  const panel = el('div.tagsel-panel');
  const optList = el('div.tagsel-opts');
  let addInput;
  function renderTrigger() {
    clear(trigger);
    trigger.appendChild(el('span.tagsel-ico', { html: icon('tag') }));
    const chips = el('div.tagsel-chips');
    if (current.size) {
      [...current].forEach((t) => chips.appendChild(el('span.tagsel-chip', {}, [
        el('span', { text: t }),
        el('button.tagsel-x', { type: 'button', html: icon('close'), onclick: (e) => { e.stopPropagation(); current.delete(t); renderTrigger(); renderOpts(); } }),
      ])));
    } else { chips.appendChild(el('span.tagsel-ph', { text: 'Tags' })); }
    trigger.appendChild(chips);
    trigger.appendChild(el('span.tagsel-chev', { html: icon('chevronDown') }));
  }
  function renderOpts() {
    clear(optList);
    const raw = (addInput && addInput.value.trim()) || '';
    const q = raw.toLowerCase();
    const rows = allTags.filter((t) => !q || t.toLowerCase().includes(q));
    rows.forEach((t) => {
      const on = current.has(t);
      optList.appendChild(el('div.tagsel-opt' + (on ? '.sel' : ''), { onclick: () => { on ? current.delete(t) : current.add(t); renderTrigger(); renderOpts(); } },
        [el('span.tagsel-opt-lbl', { text: t }), on ? el('span.tagsel-ck', { html: icon('check') }) : null]));
    });
    const exact = allTags.some((t) => t.toLowerCase() === q);
    if (raw && !exact) optList.appendChild(el('div.tagsel-opt.gsel-create', { onclick: addNew },
      [el('span.tagsel-opt-lbl', { html: `Tạo "<b>${raw}</b>"` }), el('span.tagsel-ck.ent', { text: '↵' })]));
    else if (!rows.length) optList.appendChild(el('div.tagsel-empty.muted', { text: 'Không có dữ liệu' }));
  }
  function addNew() {
    const v = addInput.value.trim(); if (!v) return;
    if (!allTags.includes(v)) { allTags.push(v); allTags.sort((a, b) => a.localeCompare(b)); remote.tags.create(v); }
    current.add(v); addInput.value = ''; renderTrigger(); renderOpts(); addInput.focus();
  }
  addInput = el('input.tagsel-add-input', { placeholder: 'Tìm tab/ Tạo tab',
    oninput: () => renderOpts(),
    onkeydown: (e) => { if (e.key === 'Enter') { e.preventDefault(); addNew(); } } });
  panel.appendChild(el('div.tagsel-add', {}, [el('span.tagsel-add-ico.gsel-add-ico', { html: icon('search') }), addInput]));
  panel.appendChild(el('div.tagsel-div'));
  panel.appendChild(optList);
  const onDoc = (e) => { if (!wrap.contains(e.target)) close(); };
  function open() { wrap.classList.add('open'); renderOpts(); setTimeout(() => addInput.focus(), 0); document.addEventListener('mousedown', onDoc); }
  function close() { wrap.classList.remove('open'); document.removeEventListener('mousedown', onDoc); }
  trigger.onclick = () => { wrap.classList.contains('open') ? close() : open(); };
  wrap.appendChild(trigger); wrap.appendChild(panel);
  remote.tags.list().then((list) => { allTags = (list || []).slice().sort((a, b) => a.localeCompare(b)); });
  Object.defineProperty(wrap, 'values', { get: () => [...current], configurable: true });
  renderTrigger();
  return wrap;
}

export function render(ctx) {
  const back = () => ctx.navigate('profiles');
  let groups = [];

  // ----- profile state (mặc định; áp cho MỌI hồ sơ tạo ra) -----
  let kernel = 'Poly';
  let os = 'Windows';
  let osVersion = OS_GROUPS[0].versions[0];
  let proxyTab = 'none';
  const proxyData = { type: 'HTTP', host: '', port: '', user: '', pass: '', token: '', rotateUrl: '' };
  let uaAuto = true;
  // ---------------------------------------------------------- trạng thái THEO ENGINE
  // Giống hệt màn tạo-đơn: Poly (Chromium) và Firefox là HAI kho nhân KHÔNG liên quan gì
  // nhau (Chrome 140 chẳng dính dáng Firefox 140), nên danh sách nhân + major hiển thị
  // trên card + cặp ghim User-Agent đều phải TÁCH ĐÔI. Dùng chung rồi xoá sạch mỗi lần
  // đổi nhân gây hai lỗi: card Firefox trưng số của Chrome, và bấm dropdown phải tải lại
  // catalog ⇒ menu "Đang tải…" rồi số phiên bản nhảy (nhấp nháy).
  const engState = {
    chromium: { items: null, loading: false, ver: '153', uaVer: '', uaFull: '' },
    firefox: { items: null, loading: false, ver: '135', uaVer: '', uaFull: '' },
  };
  const ES = (e) => engState[e] || engState.chromium;
  // 4 biến dưới là "ô kính" của engine ĐANG CHỌN - luôn là bản sao của ES(engine hiện tại).
  let chromeVer = '';              // '' = "Tất cả" (theo kernel thật); hoặc major đã ghim
  let chromeFull = '';             // full-version THẬT đã đổ (random trong dải major)
  let kernelVer = '153';           // major nhân HIỂN THỊ trên card "Trình duyệt" - ĐỘC LẬP với UA
                                  // (chọn UA ở combobox User-Agent không được đổi nhãn card này)
  let kernelItems = null;          // catalog server ∪ đã-cài của engine hiện tại; null = chưa tải
  let pendingAutoLatest = '';      // card đang chờ tự-chọn-bản-mới-nhất khi catalog về (bấm lúc chưa tải xong)
  function stashEngine(e) {
    const s = ES(e);
    s.items = kernelItems; s.ver = kernelVer; s.uaVer = chromeVer; s.uaFull = chromeFull;
  }
  function applyEngine(e) {
    const s = ES(e);
    kernelItems = s.items; kernelVer = s.ver; chromeVer = s.uaVer; chromeFull = s.uaFull;
  }
  let fp = newFingerprint();
  let curGroupId = '';

  const host = el('div.page.pc-page');
  ctx.container.appendChild(host);

  function build() {
  clear(host);

  const nameInput = el('input.input', { placeholder: 'Tên gốc, ví dụ: Acc', maxlength: 100, oninput: () => renderOverview() });
  // Batch-only: số bắt đầu + số lượng.
  const startInput = el('input.input', { type: 'number', min: '0', value: '1' });
  const countInput = el('input.input', { type: 'number', min: '1', max: '1000', value: '10' });
  // "Số bắt đầu" + "Số lượng" side by side on one line, notched-outline style.
  const numRow = el('div.pc-notch-row', {}, [
    notch('Số bắt đầu', startInput),
    notch('Số lượng', countInput),
  ]);
  const groupSel = groupPicker(groups, curGroupId);
  const groupHost = el('div.pc-fctl-inner', {}, [groupSel]);
  const cookiesBox = el('textarea.input', { rows: 3, placeholder: 'Nhập Cookie' });
  const noteBox = el('textarea.input', { rows: 3, placeholder: 'Hãy nhập ghi chú', maxlength: 2000 });
  const uaInput = el('input.input.pc-ua', { value: uaString(kernel, os, osVersion) });

  // ----- overview (right column) -----
  const ovList = el('div.pc-ov-list');
  function renderOverview() {
    clear(ovList);
    overviewRows(fp, kernel, uaInput.value, osVersion, kernelVer).forEach(([k, v]) => {
      ovList.appendChild(el('div.pc-ov-row', {}, [el('span.k', { text: k }), el('span.v', { text: v })]));
    });
  }

  // Full-version THẬT của nhân theo major đang chọn ở card "Trình duyệt": lấy từ
  // kernelItems (đã cài) - chính là version bóc tách từ folder nhân (vd 140.0.7339.264).
  // Chromium phát UA full-build 4 số (140.0.7339.264) nên đòi đúng 4 nhóm; Firefox đánh
  // số 3 nhóm (152.0.6) và UA chỉ lấy major, nên chấp nhận dạng nhiều nhóm bất kỳ.
  function kernelFullFor(major) {
    if (!major || !Array.isArray(kernelItems)) return '';
    const it = kernelItems.find((k) => k.installed && String(k.major) === String(major));
    if (!it || !it.version) return '';
    const ok = engineOf(kernel) === 'firefox'
      ? /^\d+(\.\d+)*$/.test(it.version)
      : /^\d+\.\d+\.\d+\.\d+$/.test(it.version);
    return ok ? it.version : '';
  }
  // "Tất cả" (chưa chọn UA cụ thể) → UA đúng FULL-BUILD của nhân đang chọn ở card
  // "Trình duyệt". Đã chọn UA cụ thể → dùng full-build đã đổ. Y HỆT màn tạo-đơn.
  function syncUA() {
    if (uaAuto) {
      // Dự phòng khi chưa biết full-version: Chromium cần đủ 4 số, Firefox chỉ cần major.
      const fallback = kernelVer
        ? (engineOf(kernel) === 'firefox' ? String(kernelVer) : `${kernelVer}.0.0.0`)
        : '';
      const full = chromeFull || kernelFullFor(kernelVer) || fallback;
      uaInput.value = uaString(kernel, os, osVersion, full);
    }
    renderOverview();
  }
  // Firefox KHÔNG có bảng build như CHROME_BUILDS (UA cũng chỉ lộ major) nên không random:
  // ghim major nào thì lấy đúng full-version của nhân đó.
  function rerollUA() {
    if (engineOf(kernel) === 'firefox') {
      chromeFull = chromeVer ? (kernelFullFor(chromeVer) || String(chromeVer)) : '';
    } else {
      chromeFull = chromeVer ? randomChromeFull(chromeVer) : '';
    }
    uaAuto = true; syncUA();
  }

  async function ensurePools(clientOs) {
    if (hasPools(clientOs)) return;
    try { setAllPools(await remote.fingerprintCatalog()); } catch { /* fallback built-in */ }
  }

  function applyFontsFromPool() {
    fp.fontList = osFonts(os);
    fp.fonts = String(fp.fontList.length);
  }

  async function applyOsConsistency() {
    await ensurePools(os);
    const g = osGpu(os);
    fp.webglVendor = g.vendor;
    fp.webglMeta = g.renderer;
    fp.deviceName = osDeviceName(os);
    const hw = osHardware(os, g.renderer);
    fp.cpu = hw.cpu;
    fp.ram = hw.ram;
    applyFontsFromPool();
    if (typeof vendorSel !== 'undefined') vendorSel.value = fp.webglVendor;
    if (typeof rendererInput !== 'undefined') rendererInput.value = fp.webglMeta;
    if (typeof deviceInput !== 'undefined') deviceInput.value = fp.deviceName;
    if (typeof cpuSel !== 'undefined') cpuSel.value = fp.cpu + ' cores';
    if (typeof ramSel !== 'undefined') ramSel.value = fp.ram + ' GB';
    renderOverview();
  }

  // ----- General: "Trình duyệt" - card chọn kernel + dropdown phiên bản (mũi tên) -----
  // GIỐNG HỆT màn tạo-đơn: dropdown liệt kê NHÂN THẬT (catalog server + đã cài), không
  // phải danh sách major UA. Trước đây batch đổ chromeMajors() vào đây nên bấm "150"
  // chỉ đổi UA, còn nhân chạy vẫn là bản mới nhất đã cài - thẻ nói một đằng, hồ sơ
  // chạy một nẻo, đúng loại lỗi vừa sửa ở màn tạo-đơn.
  const kernelSel = el('div.pc-kernels');
  // Nhãn của ĐÚNG card đang render (không phải của nhân đang chọn). Chưa cài nhân
  // engine đó ⇒ để TRỐNG, không mượn số của engine kia.
  function verLabel(val) {
    const e = engineOf(val);
    const v = e === engineOf(kernel) ? kernelVer : ES(e).ver;
    return v ? String(v) : '';
  }
  // Ghi major hiển thị cho MỘT engine CHỈ ĐỊNH. Tách theo engine (KHÔNG theo `kernel` toàn
  // cục) là mấu chốt chống lỗi "chọn phiên bản nhảy sang trình duyệt khác": callback bất
  // đồng bộ - tải nhân xong (onDone), hay đường trễ pendingAutoLatest - có thể chạy SAU khi
  // người dùng đã bấm sang nhân khác; ghi theo `kernel` lúc đó là ghi nhầm engine. Chỉ cập
  // nhật ô kính kernelVer khi engine đó ĐANG được chọn (card kia không bị lây).
  function setKernelVerFor(eng, v) {
    const val = v ? String(v) : '';
    ES(eng).ver = val;
    if (eng === engineOf(kernel)) kernelVer = val;
  }
  function setKernelVer(v) { setKernelVerFor(engineOf(kernel), v); }
  // Áp phiên bản đã chọn cho MỘT engine + đồng bộ UA CHỈ khi engine đó đang được chọn
  // (đổi UA của engine đang KHÔNG hiển thị là sai vân tay), rồi vẽ lại thẻ.
  function applyKernelVer(eng, majStr) {
    setKernelVerFor(eng, majStr);
    if (eng === engineOf(kernel)) { uaAuto = true; syncUA(); }
    renderKernels();
  }

  // Đổi nhân. ĐỔI ENGINE (Poly↔Firefox) = đổi kho: cất trạng thái engine cũ, lấy trạng
  // thái engine mới ra. KHÔNG xoá và KHÔNG tải lại (primeEngines đã nạp sẵn) ⇒ tức thì,
  // dropdown không nhấp nháy, quay lại engine cũ vẫn nguyên major + ghim UA.
  function selectKernel(val) {
    if (kernel === val) return false;
    const from = engineOf(kernel);
    const to = engineOf(val);
    kernel = val;
    if (from !== to) {
      stashEngine(from);
      applyEngine(to);
      // Đổi engine ⇒ UA tính lại (xem chú thích dài cùng chỗ ở profile_create.js). Ở màn
      // hàng loạt uaAuto hiện luôn = true nên đây là bảo hiểm, KHÔNG phải thừa: giữ hai
      // màn đối xứng để sau này có ai thêm chế độ giữ-UA thì batch không âm thầm lệch.
      uaAuto = true;
      refreshUaVerOptions();
      loadKernelList(to);
    }
    return true;
  }

  // Bấm CHỌN một card trình duyệt ⇒ mặc định lấy phiên bản MỚI NHẤT của nhân đó theo
  // catalog (KHÔNG chỉ bản đã cài như loadKernelList). Bản mới nhất CHƯA cài ⇒ TỰ ĐỘNG
  // mở modal tải rồi ghim sau khi tải xong (yêu cầu chủ sở hữu). Catalog chưa về ⇒ hẹn
  // lại qua pendingAutoLatest: loadKernelList().finally sẽ gọi lại hàm này khi có danh sách.
  function chooseLatestKernel(val) {
    // BẢO HIỂM CHỐNG CHỌN NHẦM SANG NHÂN KHÁC: chỉ áp dụng cho nhân ĐANG được chọn.
    // Đường TRỄ (qua pendingAutoLatest ở loadKernelList.finally) có thể chạy SAU khi người
    // dùng đã bấm sang nhân khác - lúc đó kernel !== val; nếu vẫn chạy thì setKernelVer sẽ
    // ghi phiên bản của nhân này vào ENGINE đang chọn (đúng lỗi "chọn nhầm phiên bản sang
    // trình duyệt khác"). Gặp thế thì bỏ qua và xoá cờ chờ.
    if (kernel !== val) { if (pendingAutoLatest === val) pendingAutoLatest = ''; return; }
    const cardEngine = engineOf(val);
    const items = cardEngine === engineOf(kernel) ? kernelItems : ES(cardEngine).items;
    if (items == null) { pendingAutoLatest = val; loadKernelList(cardEngine); return; }
    pendingAutoLatest = '';
    if (!items.length) return;
    const latest = items[0];            // items đã sắp major GIẢM DẦN ⇒ [0] là mới nhất
    const majStr = String(latest.major);
    if (latest.installed) {
      applyKernelVer(cardEngine, majStr);   // ghi ĐÚNG engine card này (không theo kernel toàn cục)
      return;
    }
    if (!latest.url) return;            // không có nguồn tải trên server ⇒ để nguyên
    openKernelDownloadModal({ ...latest, engine: cardEngine }, {
      onDone: () => {
        syncActiveKernelToFingerprint().catch(() => {});
        applyKernelVer(cardEngine, majStr);   // tải xong: ghi cho ĐÚNG engine dù người dùng đã đổi nhân
        loadKernelList(cardEngine, true);
      },
    });
  }

  // Nạp kho nhân của MỘT engine vào ES(e). Kết quả ghi thẳng vào ES(e); chỉ đổ ra ô kính
  // khi engine đó VẪN đang được chọn lúc kết quả về - người dùng có thể đã bấm sang nhân
  // khác trong lúc chờ mạng, ghi bừa là hai engine lẫn nhau.
  function loadKernelList(engine, force) {
    const e = engine || engineOf(kernel);
    const s = ES(e);
    if (s.loading) return;
    if (s.items && !force) return;
    s.loading = true;
    Promise.resolve(window.vt.kernel.list(e, KERNEL_PLATFORM))
      .then((r) => {
        const items = (r && r.ok && r.data && Array.isArray(r.data.items)) ? r.data.items : [];
        // Sắp major GIẢM DẦN (so sánh số để 140 > 99); major bằng nhau thì so version đầy đủ.
        items.sort((a, b) => {
          const am = Number(a.major) || 0, bm = Number(b.major) || 0;
          if (am !== bm) return bm - am;
          return String(b.version || '').localeCompare(String(a.version || ''), undefined, { numeric: true });
        });
        s.items = items;
        // Mặc định card hiển thị nhân MỚI NHẤT đã cài. Nhân đã ghim mà nay KHÔNG còn cài
        // ⇒ coi như chưa ghim: thẻ phải nói ĐÚNG nhân sẽ chạy.
        if (s.ver && !items.some((k) => k.installed && String(k.major) === String(s.ver))) s.ver = '';
        let autoPinned = false;
        if (!s.ver) {
          const newest = items.find((k) => k.installed) || items.find((k) => k.major === 153) || items[0];
          if (newest) { s.ver = String(newest.major); autoPinned = true; }
        }
        if (engineOf(kernel) === e) {
          kernelItems = s.items; kernelVer = s.ver;
          if (autoPinned) syncUA();
        }
      })
      .catch(() => { s.items = []; if (engineOf(kernel) === e) kernelItems = s.items; })
      // Firefox lấy danh sách major cho ô "User-Agent" TỪ kho nhân → nạp lại khi về.
      .finally(() => {
        s.loading = false; refreshUaVerOptions(); renderKernels();
        // Có card đang chờ tự-chọn-bản-mới-nhất (bấm lúc catalog chưa về) và đúng engine
        // vừa nạp xong ⇒ thực hiện việc chọn/tải bây giờ.
        if (pendingAutoLatest && engineOf(pendingAutoLatest) === e) chooseLatestKernel(pendingAutoLatest);
      });
  }

  // Nạp sẵn CẢ HAI engine khi mở trang - chỗ dập tắt nhấp nháy tận gốc:
  //   • kernel.installed(e): sổ cái LOCAL, không qua mạng ⇒ nhãn của cả hai card đúng
  //     gần như tức thì, không phải chờ catalog rồi mới nhảy số.
  //   • kernel.list(e): catalog cho dropdown, nạp NỀN cả engine chưa chọn ⇒ bấm vào là
  //     có sẵn, không còn "Đang tải danh sách nhân…".
  function primeEngines() {
    [...new Set(KERNELS.map(([v]) => engineOf(v)))].forEach((e) => {
      const s = ES(e);
      Promise.resolve(window.vt.kernel.installed(e))
        .then((list) => {
          const arr = Array.isArray(list) ? list : [];
          // GIỮ major đang ghim nếu vẫn còn cài; ô trống / nhân đã gỡ ⇒ lấy bản mới nhất.
          const keep = e === engineOf(kernel) ? kernelVer : s.ver;
          const next = (keep && arr.some((k) => String(k.major) === String(keep)))
            ? String(keep)
            : (arr.length ? String(arr[0].major) : (e === 'firefox' ? '135' : '153'));
          if (s.ver === next && (e !== engineOf(kernel) || kernelVer === next)) return;
          s.ver = next;
          if (e === engineOf(kernel)) { kernelVer = next; syncUA(); }
          renderKernels();
        })
        .catch(() => { /* không đọc được sổ cái ⇒ để trống, không bịa số */ });
      loadKernelList(e);
    });
  }

  // Card nào đang mở dropdown ('' = không có). Phải là STATE chứ không phải class trên
  // DOM: renderKernels() dựng lại toàn bộ card, không nhớ thì mỗi lần catalog về muộn là
  // menu đang mở bị đóng phụt - chính là cái "nhấp nháy" khi bấm vào dropdown.
  let openKernel = '';
  let offOutside = null;
  function armOutsideClose() {
    if (offOutside) { document.removeEventListener('mousedown', offOutside); offOutside = null; }
    if (!openKernel) return;
    offOutside = (ev) => {
      if (kernelSel.contains(ev.target)) return;
      openKernel = '';
      document.removeEventListener('mousedown', offOutside); offOutside = null;
      kernelSel.querySelectorAll('.pc-kernel.open').forEach((r) => r.classList.remove('open'));
    };
    // Hoãn 1 nhịp để chính cú click đang mở menu không tự đóng nó.
    setTimeout(() => { if (offOutside) document.addEventListener('mousedown', offOutside); }, 0);
  }

  function renderKernels() {
    clear(kernelSel);
    KERNELS.forEach(([val, label, opts]) => {
      opts = opts || {};
      const iconHtml = opts.icon === 'chrome'
        ? `<span class="pc-kernel-ico" role="img" aria-label="${label}"></span>`
        : `<span class="pc-kernel-ico pc-kernel-ico-svg" role="img" aria-label="${label}">${icon(opts.icon)}</span>`;

      if (opts.disabled) {
        const dcard = el('div.pc-kernel.disabled', { title: 'Sắp ra mắt' });
        dcard.appendChild(el('span.pc-kernel-main', { html: iconHtml + `<span class="lbl">${label}</span>` }));
        // "|" là con trực tiếp của card (ngoài trig) để đồng bộ với card thường.
        dcard.appendChild(el('span.pc-osint-div'));
        dcard.appendChild(el('span.pc-kernel-trig', {}, [
          el('span.verlbl'),
          el('span.chev', { html: icon('chevronDown') }),
        ]));
        kernelSel.appendChild(dcard);
        return;
      }

      const active = kernel === val;
      const card = el('div.pc-kernel' + (active ? '.sel' : ''));

      // Ghi vào openKernel RỒI render lại một lần duy nhất - không đụng class của card cũ
      // (card sắp bị dựng lại), nhờ vậy menu không bị mở-đóng chớp.
      const toggleMenu = (e) => {
        e.stopPropagation();
        openKernel = openKernel === val ? '' : val;
        if (selectKernel(val)) syncUA();
        renderKernels();
      };

      const main = el('button.pc-kernel-main', {
        type: 'button',
        html: iconHtml + `<span class="lbl">${label}</span>`,
        // Bấm CHỌN card = chọn nhân + mặc định lấy phiên bản MỚI NHẤT (tự tải nếu chưa có).
        // Chỉ auto-chọn-mới-nhất khi card TRƯỚC ĐÓ chưa được chọn (tránh mở lại modal tải
        // mỗi lần bấm lại đúng card đang chọn).
        onclick: () => {
          const wasActive = active;
          if (selectKernel(val)) { renderKernels(); syncUA(); }
          if (!wasActive) chooseLatestKernel(val);
        },
      });

      // Ngăn cách "|" TÁCH RIÊNG (con trực tiếp của card, KHÔNG nằm trong nút trig) ⇒ bấm
      // vào "|" hay bên trái nó không mở dropdown; chỉ nút trig (bên phải "|") mới mở.
      const kdiv = el('span.pc-osint-div');
      const trig = el('button.pc-kernel-trig', { type: 'button', title: 'Phiên bản trình duyệt' }, [
        el('span.verlbl', { text: verLabel(val) }),
        el('span.chev', { html: icon('chevronDown') }),
      ]);
      trig.onclick = toggleMenu;

      // Menu phiên bản = NHÂN THẬT (không phải danh sách UA). Chỉ bản ĐÃ CÀI mới chọn
      // được; bản CHƯA CÀI hiện icon "Tải" và bấm vào sẽ MỞ MODAL TẢI.
      // Mỗi card liệt kê nhân của CHÍNH engine nó: menu Firefox luôn là các bản Firefox
      // kể cả khi đang chọn Poly. Kho tách đôi + nạp sẵn ⇒ mở menu là có ngay.
      const cardEngine = engineOf(val);
      const cardItems = cardEngine === engineOf(kernel) ? kernelItems : ES(cardEngine).items;
      const cardVer = verLabel(val);
      const menu = el('div.pc-osint-menu.pc-kernel-menu');
      if (cardItems == null) {
        loadKernelList(cardEngine);
        menu.appendChild(el('div.pc-kernel-opt-empty', { text: 'Đang tải danh sách nhân…' }));
      } else {
        cardItems.forEach((it) => {
          const majStr = String(it.major);
          const isSel = cardVer === majStr;
          const installed = !!it.installed;
          const badge = installed ? '' : `<span class="pc-kernel-dl">${icon('download')}</span>`;
          const opt = el('button.pc-osint-opt.pc-kernel-opt' + (isSel ? '.sel' : '') + (installed ? '' : '.uninst'), {
            type: 'button',
            html: `<span class="lbl">${majStr}</span>` + badge + (isSel ? `<span class="ck">${icon('check')}</span>` : ''),
          });
          opt.onclick = () => {
            // Chọn phiên bản trong menu card nào thì CHỌN LUÔN nhân đó - menu và nhân đang
            // dùng không được lệch nhau (bấm bản Firefox mà vẫn đang chạy Poly).
            if (selectKernel(val)) syncUA();
            if (installed) {
              openKernel = '';
              applyKernelVer(cardEngine, majStr);   // ghi cho ĐÚNG engine của card này
              return;
            }
            // Chưa cài → mở modal tải; xong thì reload danh sách + tự chọn bản vừa cài.
            openKernel = '';
            card.classList.remove('open');
            if (!it.url) {
              alertDialog({
                title: 'Không tải được nhân',
                message: tf('Nhân {0} {1} hiện không có sẵn trên máy chủ. Vui lòng liên hệ quản trị viên hoặc chọn phiên bản khác.', ENGINE_LABEL[cardEngine], majStr),
              });
              return;
            }
            openKernelDownloadModal({ ...it, engine: cardEngine }, {
              onDone: () => {
                syncActiveKernelToFingerprint().catch(() => {});
                applyKernelVer(cardEngine, majStr);   // tải xong: ghi cho ĐÚNG engine dù đã đổi nhân
                loadKernelList(cardEngine, true);   // chỉ nạp lại kho ĐÚNG engine vừa tải
              },
            });
          };
          menu.appendChild(opt);
        });
        if (!cardItems.length) menu.appendChild(el('div.pc-kernel-opt-empty', { text: 'Không có nhân khả dụng' }));
      }

      if (openKernel === val) card.classList.add('open');
      card.appendChild(main);
      card.appendChild(kdiv);
      card.appendChild(trig);
      card.appendChild(menu);
      kernelSel.appendChild(card);
    });
    armOutsideClose();
  }
  renderKernels();
  primeEngines();   // nạp sẵn kho + nhãn phiên bản của CẢ HAI engine ⇒ không nhấp nháy

  // ----- General: OS pills -----
  const osInt = el('div.pc-osint');
  function renderOsInt() {
    clear(osInt);
    OS_GROUPS.forEach((g) => {
      const active = os === g.os;
      const pill = el('div.pc-osint-row' + (active ? '.sel' : ''));
      const cb = el('input', { type: 'checkbox' });
      cb.checked = active;
      const selectOs = () => { os = g.os; osVersion = g.versions[0]; renderOsInt(); applyOsConsistency(); uaAuto = true; syncUA(); };
      cb.onchange = selectOs;

      const menu = el('div.pc-osint-menu');
      if (g.versions.length > 1) {
        menu.appendChild(el('button.pc-osint-opt', {
          type: 'button',
          html: `<span class="lbl">All ${g.os}</span>`,
          onclick: () => { os = g.os; osVersion = g.versions[Math.floor(Math.random() * g.versions.length)]; renderOsInt(); applyOsConsistency(); uaAuto = true; syncUA(); },
        }));
      }
      g.versions.forEach((v) => {
        const isSel = active && osVersion === v;
        menu.appendChild(el('button.pc-osint-opt' + (isSel ? '.sel' : ''), {
          type: 'button',
          html: `<span class="lbl">${v}</span>` + (isSel ? `<span class="ck">${icon('check')}</span>` : ''),
          onclick: () => { os = g.os; osVersion = v; renderOsInt(); applyOsConsistency(); uaAuto = true; syncUA(); },
        }));
      });

      const trig = el('button.pc-osint-trig', { type: 'button', title: g.os }, [
        el('span.ic.ic-' + g.icon, { html: icon(g.icon) }),
        el('span.pc-osint-div'),
        el('span.chev', { html: icon('chevronDown') }),
      ]);
      trig.onclick = (e) => {
        e.stopPropagation();
        const willOpen = !pill.classList.contains('open');
        osInt.querySelectorAll('.pc-osint-row.open').forEach((r) => r.classList.remove('open'));
        if (willOpen) {
          pill.classList.add('open');
          const off = (ev) => { if (!pill.contains(ev.target)) { pill.classList.remove('open'); document.removeEventListener('mousedown', off); } };
          setTimeout(() => document.addEventListener('mousedown', off), 0);
        }
      };

      pill.appendChild(cb);
      pill.appendChild(trig);
      pill.appendChild(menu);
      osInt.appendChild(pill);
    });
  }
  renderOsInt();

  // Ô "User-Agent": mặc định BỎ TRỐNG = "Tất cả" (theo kernel thật) - hiển thị qua
  // placeholder, KHÔNG có item "Tất cả" trong danh sách. Y HỆT màn tạo-đơn. Chọn UA ở
  // đây KHÔNG đổi nhãn card "Trình duyệt" nữa (hai thứ đã tách hẳn) nên không renderKernels.
  // Danh sách major PHẢI theo ENGINE đang chọn, nếu không hồ sơ Firefox lại ghim major
  // Chrome (88..150). Chromium: bảng CHROME_BUILDS (chromeMajors). Firefox: firefoxMajors()
  // - danh sách ĐẦY ĐỦ ngang Chromium, cùng thời kỳ (85..152). Y HỆT màn tạo-đơn; xem chú
  // thích dài ở profile_create.js và ở firefoxMajors() trong fingerprint.js.
  function uaVerOptions() {
    if (engineOf(kernel) === 'firefox') {
      const fromKernels = Array.isArray(kernelItems)
        ? kernelItems.map((k) => Number(k.major)).filter(Boolean)
        : [];
      const majors = [...new Set([...firefoxMajors(), ...fromKernels])].sort((a, b) => b - a);
      return majors.map((m) => ({ value: String(m), label: 'UA ' + m }));
    }
    return chromeMajors().map((m) => ({ value: String(m), label: 'UA ' + m }));
  }
  const uaVerSel = customSelect(uaVerOptions(), {
    value: chromeVer || '', width: 120, height: 40, placeholder: 'Tất cả',
    onChange: (v) => { chromeVer = v; rerollUA(); },
  });
  // try/catch: gọi từ selectKernel/loadKernelList - cả hai khai báo TRƯỚC `uaVerSel` nên
  // có thể vướng TDZ nếu chạm lúc form chưa dựng xong. Bỏ qua an toàn.
  function refreshUaVerOptions() {
    try {
      if (uaVerSel && typeof uaVerSel.setOptions === 'function') uaVerSel.setOptions(uaVerOptions(), chromeVer || '');
    } catch { /* form chưa dựng xong */ }
  }
  const uaRefresh = el('button.icon-btn.pc-ua-btn', { html: icon('shuffle'), title: 'Tạo lại User-Agent', onclick: () => rerollUA() });
  // Đặt lại về "Tất cả": bỏ item UA đã chọn, đưa combobox về placeholder (gán .value
  // không fire onChange), rồi syncUA() để ô UA quay về UA chuẩn của nhân đang chọn.
  const uaReset = el('button.icon-btn.pc-ua-btn.pc-ua-btn-2nd', {
    html: icon('uaReset'), title: 'Đặt lại User-Agent (Tất cả)',
    onclick: () => { chromeVer = ''; chromeFull = ''; uaVerSel.value = ''; uaAuto = true; syncUA(); },
  });
  const tagsSel = tagSelect([]);

  const secGeneral = el('section.pc-sec', { id: 'pcsec-general' }, [
    frow('Tên gốc', nameInput, { required: true }),
    el('div.pc-frow', {}, [el('div.pc-flabel', { text: 'Số lượng' }), el('div.pc-fctl', {}, [numRow])]),
    frow('Trình duyệt', kernelSel),
    frow('Hệ điều hành', osInt),
    frow('User-Agent', el('div.pc-ua-line', {}, [uaVerSel, uaInput, uaRefresh, uaReset])),
    frow('Nhóm', el('div.pc-group-row', {}, [groupHost, tagsSel]), { required: true }),
    frow('Cookie', cookiesBox),
    frow('Ghi chú', noteBox),
  ]);

  // ----- Proxy (áp CHUNG cho mọi hồ sơ) -----
  // Tab "Proxy thường" là proxy host:port nên combobox BỎ item 'Token' (token có tab RIÊNG
  // ngay bên cạnh) - user chốt 2026-10-03. KHÔNG mutate PROXY_TYPES (nguồn dùng chung): lọc
  // ra một mảng cục bộ. Giá trị khởi tạo cũng kẹp Token về mặc định để combobox không hiện
  // TRỐNG (customSelect vẽ ô trống khi value không khớp option nào).
  const NORMAL_PROXY_TYPES = PROXY_TYPES.filter((v) => v !== 'Token');
  const proxyTypeInit = (() => { const n = normalizeProxyType(proxyData.type); return n === 'Token' ? PROXY_TYPE_DEFAULT : n; })();
  const proxyTypeSel = customSelect(NORMAL_PROXY_TYPES,
    { value: proxyTypeInit, width: '100%', height: 40, onChange: (v) => { proxyData.type = v; } });
  const pHost = el('input.input', { value: proxyData.host, placeholder: 'Host IP', oninput: (e) => { proxyData.host = e.target.value; } });
  const pPort = el('input.input.pc-proxy-port', { value: proxyData.port, placeholder: 'Port', oninput: (e) => { proxyData.port = e.target.value; } });
  const pUser = el('input.input', { value: proxyData.user, placeholder: 'Username', oninput: (e) => { proxyData.user = e.target.value; } });
  const pPass = el('input.input', { type: 'password', value: proxyData.pass, placeholder: 'Password', oninput: (e) => { proxyData.pass = e.target.value; } });
  const pToken = el('input.input', { value: proxyData.token, placeholder: 'Proxy token', oninput: (e) => { proxyData.token = e.target.value; } });
  const pRotate = el('input.input', { value: proxyData.rotateUrl, placeholder: 'Link / API Proxy xoay', oninput: (e) => { proxyData.rotateUrl = e.target.value; } });

  async function copyProxy() {
    const parts = [proxyData.host, proxyData.port, proxyData.user, proxyData.pass].filter((x) => x && String(x).trim());
    if (!parts.length) { toast('Chưa có thông tin proxy để sao chép'); return; }
    const text = parts.join(':');
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) await navigator.clipboard.writeText(text);
      else { const ta = el('textarea', { value: text }); document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove(); }
      toast('Đã sao chép proxy', 'ok');
    } catch { toast('Không sao chép được'); }
  }

  async function checkProxy(btn) {
    if (!proxyData.host || !proxyData.port) { toast('Nhập Host và Port trước khi kiểm tra'); return; }
    btn.classList.add('is-loading'); btn.disabled = true;
    const lbl = btn.querySelector('.pc-shuffle-lbl');
    const old = lbl ? lbl.textContent : '';
    if (lbl) lbl.textContent = 'Đang kiểm tra…';
    try {
      const r = await window.vt.proxy.check({ type: proxyData.type, host: proxyData.host, port: proxyData.port, user: proxyData.user, pass: proxyData.pass });
      if (r && r.ok && r.geo) toast(`Proxy OK · ${r.geo.ip}${r.geo.country ? ' · ' + r.geo.country : ''}`, 'ok');
      else toast(r && r.error ? r.error : 'Không kết nối được proxy');
    } catch { toast('Lỗi khi kiểm tra proxy'); }
    finally { btn.classList.remove('is-loading'); btn.disabled = false; if (lbl) lbl.textContent = old; }
  }

  const copyBtn = () => { const b = el('button.btn.pc-shuffle', { html: `${icon('copy')}<span class="pc-shuffle-lbl">Sao chép</span>` }); b.onclick = () => copyProxy(); return b; };
  const checkBtn = () => { const b = el('button.btn.pc-shuffle', { html: `${icon('sync')}<span class="pc-shuffle-lbl">Kiểm tra</span>` }); b.onclick = () => checkProxy(b); return b; };

  function syncProxyInputs() {
    pHost.value = proxyData.host || '';
    pPort.value = proxyData.port || '';
    pUser.value = proxyData.user || '';
    pPass.value = proxyData.pass || '';
    pToken.value = proxyData.token || '';
    pRotate.value = proxyData.rotateUrl || '';
  }
  function proxyContent() {
    syncProxyInputs();
    if (proxyTab === 'none') return el('div');
    if (proxyTab === 'normal') return el('div.pc-proxy-fields', {}, [
      proxyTypeSel,
      el('div.pc-proxy-hp', {}, [pHost, el('span.pc-proxy-colon', { text: ':' }), pPort]),
      pUser,
      pPass,
      el('div.pc-proxy-actions', {}, [copyBtn(), checkBtn()]),
    ]);
    if (proxyTab === 'token') return el('div.pc-proxy-fields', {}, [
      pToken,
      el('div.pc-proxy-actions.end', {}, [copyBtn()]),
    ]);
    return el('div.pc-proxy-fields', {}, [
      pRotate,
      el('div.pc-proxy-actions.end', {}, [copyBtn()]),
    ]);
  }

  const PROXY_TABS = [['none', 'Không sử dụng'], ['normal', 'Proxy thường'], ['token', 'Proxy token'], ['rotate', 'Proxy xoay']];
  const proxyBody = el('div.pc-proxy-body');
  function renderProxyBody() { clear(proxyBody); proxyBody.appendChild(proxyContent()); }
  const proxyModePills = pills(PROXY_TABS, proxyTab, (v) => { proxyTab = v; renderProxyBody(); });
  renderProxyBody();

  const secProxy = el('section.pc-sec', { id: 'pcsec-proxy' }, [
    el('div.pc-sec-head', { text: 'Proxy' }),
    frow('Proxy', proxyModePills),
    proxyBody,
  ]);

  // ----- Fingerprint -----
  const fpPill = (field, opts) => pills(opts, fp[field], (v) => { fp[field] = v; renderOverview(); });

  const geoRadios = el('div.pc-radios');
  function renderGeoRadios() {
    clear(geoRadios);
    ['Hỏi mỗi lần', 'Luôn cho phép'].forEach((l) => {
      const rb = el('input', { type: 'radio', name: 'geomode' });
      rb.checked = fp.geoMode === l;
      rb.onchange = () => { fp.geoMode = l; };
      geoRadios.appendChild(el('label.pc-radio', {}, [rb, el('span', { text: l })]));
    });
  }
  renderGeoRadios();

  const tzSel = customSelect(TIMEZONES,
    { value: fp.timezoneValue, width: '100%', height: 40, onChange: (v) => { fp.timezoneValue = v; renderOverview(); } });
  const tzWrap = el('div.pc-fctl-stack');
  const tzPill = pills(['Dựa trên IP', 'Thực', 'Tùy chỉnh'], fp.timezone, (v) => { fp.timezone = v; renderOverview(); drawTz(); });
  function drawTz() { clear(tzWrap); tzWrap.appendChild(tzPill); if (fp.timezone === 'Tùy chỉnh') tzWrap.appendChild(tzSel); }
  drawTz();

  const geoLatInput = el('input.input.pc-geo-in', { value: fp.geoLat, placeholder: 'Vĩ độ', oninput: (e) => { fp.geoLat = e.target.value; } });
  const geoLngInput = el('input.input.pc-geo-in', { value: fp.geoLng, placeholder: 'Kinh độ', oninput: (e) => { fp.geoLng = e.target.value; } });
  const geoAccInput = el('input.input', { type: 'number', value: fp.geoAccuracy, oninput: (e) => { fp.geoAccuracy = e.target.value; } });
  const geoPanel = el('div.pc-subpanel', {}, [
    frow('Vĩ độ / Kinh độ', el('div.pc-ua-line', {}, [geoLatInput, geoLngInput])),
    frow('Accuracy (m)', geoAccInput),
  ]);
  const geoWrap = el('div.pc-fctl-stack');
  const geoPill = pills(['Dựa trên IP', 'Tùy chỉnh', 'Block'], fp.geo, (v) => { fp.geo = v; renderOverview(); drawGeo(); });
  function drawGeo() { clear(geoWrap); geoWrap.appendChild(geoPill); geoWrap.appendChild(geoRadios); if (fp.geo === 'Tùy chỉnh') geoWrap.appendChild(geoPanel); }
  drawGeo();

  const langWrap = el('div.pc-fctl-stack');
  const langPanel = el('div.pc-subpanel.pc-langlist');
  function renderLangList() {
    clear(langPanel);
    fp.languageList.forEach((loc, i) => {
      const lbl = (LOCALES.find((o) => o.value === loc) || {}).label || loc;
      langPanel.appendChild(el('div.pc-lang-row', {}, [
        el('span.pc-lang-name', { text: lbl }),
        el('button.pc-lang-del', {
          type: 'button', text: '×', title: 'Xóa',
          onclick: () => { if (fp.languageList.length > 1) { fp.languageList.splice(i, 1); renderLangList(); renderOverview(); } },
        }),
      ]));
    });
    const avail = LOCALES.filter((o) => !fp.languageList.includes(o.value));
    const addSel = customSelect(avail, {
      placeholder: '+ Thêm ngôn ngữ', width: '100%', height: 38,
      onChange: (v) => { if (v) { fp.languageList.push(v); renderLangList(); renderOverview(); } },
    });
    langPanel.appendChild(el('div.pc-lang-add', {}, [addSel]));
  }
  renderLangList();
  const langPill = pills(['Dựa trên IP', 'Tùy chỉnh'], fp.language, (v) => { fp.language = v; renderOverview(); drawLang(); });
  function drawLang() { clear(langWrap); langWrap.appendChild(langPill); if (fp.language === 'Tùy chỉnh') langWrap.appendChild(langPanel); }
  drawLang();

  const dlSel = customSelect(LOCALES.map((o) => ({ ...o, right: o.value })),
    { value: fp.displayLanguageValue, width: '100%', height: 40, onChange: (v) => { fp.displayLanguageValue = v; renderOverview(); } });
  const dlWrap = el('div.pc-fctl-stack');
  const dlPill = pills(['Dựa trên ngôn ngữ', 'Thực', 'Tùy chỉnh'], fp.displayLanguage, (v) => { fp.displayLanguage = v; renderOverview(); drawDl(); });
  function drawDl() { clear(dlWrap); dlWrap.appendChild(dlPill); if (fp.displayLanguage === 'Tùy chỉnh') dlWrap.appendChild(dlSel); }
  drawDl();

  const resSel = customSelect(RESOLUTIONS,
    { value: fp.resolutionSize, width: '100%', height: 40, onChange: (v) => { fp.resolutionSize = v; renderOverview(); } });
  const resMatch = String(fp.resolutionSize || '').match(/(\d+)\s*x\s*(\d+)/i);
  const writeResSize = () => {
    const w = (resWIn.value || '').trim(); const h = (resHIn.value || '').trim();
    fp.resolutionSize = (w && h) ? `${w} x ${h}` : '';
    renderOverview();
  };
  const resWIn = el('input.input.pc-res-in', { type: 'number', min: '1', max: '9999', placeholder: '1~9999', value: resMatch ? resMatch[1] : '1920', oninput: writeResSize });
  const resHIn = el('input.input.pc-res-in', { type: 'number', min: '1', max: '9999', placeholder: '1~9999', value: resMatch ? resMatch[2] : '1080', oninput: writeResSize });
  const resCustom = el('div.pc-res-custom', {}, [resWIn, el('span.pc-res-x', { text: '×' }), resHIn]);
  const resWrap = el('div.pc-fctl-stack');
  const resPill = pills(['Ngẫu nhiên', 'Được xác định trước', 'Tùy chỉnh'], fp.resolution, (v) => { fp.resolution = v; renderOverview(); renderRes(); });
  function renderRes() {
    clear(resWrap); resWrap.appendChild(resPill);
    if (fp.resolution === 'Được xác định trước') resWrap.appendChild(resSel);
    else if (fp.resolution === 'Tùy chỉnh') { resWrap.appendChild(resCustom); writeResSize(); }
  }
  renderRes();

  function noiseItem(label, field, withEdit) {
    const sw = switchEl(fp[field] === 'Nhiễu', (v) => { fp[field] = v ? 'Nhiễu' : 'Thực'; renderOverview(); });
    const kids = [sw, el('span.pc-noise-lbl', { text: label })];
    if (withEdit) kids.push(el('span.pc-noise-edit', { text: 'Chỉnh sửa', onclick: () => toast('Chỉnh sửa thiết bị chưa được hỗ trợ') }));
    return el('div.pc-noise-item', {}, kids);
  }
  const noiseRow = el('div.pc-noise-row', {}, [
    noiseItem('Canvas', 'canvas'),
    noiseItem('Avatar WebGL', 'webglImage'),
    noiseItem('AudioContext', 'audioContext'),
    noiseItem('Thiết bị truyền thông', 'mediaDevice'),
    noiseItem('SpeechVoices', 'speechVoice'),
    noiseItem('ClientRects', 'clientRects'),
  ]);

  const vendorSel = customSelect(WEBGL_VENDORS,
    { value: fp.webglVendor, width: '100%', height: 40, onChange: (v) => { fp.webglVendor = v; renderOverview(); } });
  const rendererInput = el('input.input', { value: fp.webglMeta, oninput: (e) => { fp.webglMeta = e.target.value; renderOverview(); } });
  const rendererRefresh = el('button.icon-btn.pc-ua-btn', { html: icon('shuffle'), title: 'Tạo lại', onclick: () => {
    const g = osGpu(os);
    fp.webglVendor = g.vendor; fp.webglMeta = g.renderer;
    vendorSel.value = g.vendor; rendererInput.value = g.renderer;
    const hw = osHardware(os, g.renderer);
    fp.cpu = hw.cpu; fp.ram = hw.ram;
    if (typeof cpuSel !== 'undefined') cpuSel.value = fp.cpu + ' cores';
    if (typeof ramSel !== 'undefined') ramSel.value = fp.ram + ' GB';
    renderOverview();
  } });
  const webglPanel = el('div.pc-subpanel', {}, [
    frow('Nhà cung cấp', vendorSel),
    frow('Trình kết xuất', el('div.pc-ua-line', {}, [rendererInput, rendererRefresh])),
  ]);
  const webglWrap = el('div.pc-fctl-stack');
  const webglPill = pills(['Thực', 'Tùy chỉnh'], fp.webglMode, (v) => { fp.webglMode = v; renderWebgl(); });
  function renderWebgl() { clear(webglWrap); webglWrap.appendChild(webglPill); if (fp.webglMode === 'Tùy chỉnh') webglWrap.appendChild(webglPanel); }
  renderWebgl();

  const cpuSel = customSelect(['3 cores', '4 cores', '6 cores', '8 cores', '10 cores', '12 cores', '16 cores', '20 cores', '24 cores', '32 cores', '64 cores'],
    { value: fp.cpu + ' cores', width: '100%', height: 40, onChange: (v) => { fp.cpu = parseInt(v, 10); renderOverview(); } });
  const ramSel = customSelect(['2 GB', '4 GB', '6 GB', '8 GB', '16 GB', '32 GB', '64 GB', '128 GB'],
    { value: fp.ram + ' GB', width: '100%', height: 40, onChange: (v) => { fp.ram = parseInt(v, 10); renderOverview(); } });
  const deviceInput = el('input.input', { value: fp.deviceName, oninput: (e) => { fp.deviceName = e.target.value; renderOverview(); } });
  const macInput = el('input.input', { value: fp.mac, oninput: (e) => { fp.mac = e.target.value; renderOverview(); } });
  const deviceRefresh = el('button.icon-btn.pc-ua-btn', { html: icon('shuffle'), title: 'Tạo lại', onclick: () => { fp.deviceName = osDeviceName(os); deviceInput.value = fp.deviceName; renderOverview(); } });
  const macRefresh = el('button.icon-btn.pc-ua-btn', { html: icon('shuffle'), title: 'Tạo lại', onclick: () => { fp.mac = randMac(); macInput.value = fp.mac; renderOverview(); } });

  function customToggle(field, ctl) {
    const wrap = el('div.pc-fctl-stack');
    const pill = pills(['Thực', 'Tùy chỉnh'], fp[field], (v) => { fp[field] = v; draw(); });
    function draw() { clear(wrap); wrap.appendChild(pill); if (fp[field] === 'Tùy chỉnh') wrap.appendChild(ctl); }
    draw();
    return wrap;
  }

  const launchArgs = el('textarea.input', { rows: 3, placeholder: 'example:\n--disable-notifications\n--blink-settings=imagesEnabled=false', oninput: (e) => { fp.launchArgs = e.target.value; } });
  launchArgs.value = fp.launchArgs || '';

  const moreBlock = el('div.pc-more.open', {}, [
    frow('CPU', customToggle('cpuMode', cpuSel)),
    frow('RAM', customToggle('ramMode', ramSel)),
    frow('Tên thiết bị', customToggle('deviceMode', el('div.pc-ua-line', {}, [deviceInput, deviceRefresh]))),
    frow('Địa chỉ MAC', customToggle('macMode', el('div.pc-ua-line', {}, [macInput, macRefresh]))),
  ]);

  const secFingerprint = el('section.pc-sec', { id: 'pcsec-fingerprint' }, [
    el('div.pc-sec-head', { text: 'Dấu vân tay' }),
    frow('WebRTC', fpPill('webRTC', [
      ['Thực', 'Thực', null, 'Sử dụng IP thực của thiết bị hiện tại'],
      ['Vô hiệu hóa', 'Vô hiệu hóa', null, 'Chặn đọc tham số WebRTC'],
      ['Thay thế', 'Thay thế', null, 'Sử dụng IP WebRTC trùng khớp với proxy của bạn'],
      ['UDP qua proxy', 'UDP qua proxy', null, 'Ép mọi kết nối ICE đi qua proxy, chặn hoàn toàn UDP trực tiếp'],
    ])),
    frow('Múi giờ', tzWrap),
    frow('Địa chỉ', geoWrap),
    frow('Ngôn ngữ', langWrap),
    frow('Ngôn ngữ hiển thị', dlWrap),
    frow('Độ phân giải', resWrap),
    frow('Tiếng ồn phần cứng', noiseRow, { labelHtml: 'Tiếng ồn phần<br>cứng' }),
    frow('WebGL metadata', webglWrap),
    frow('WebGPU', fpPill('webGPU', ['Trùng với WebGL', 'Thực', 'Vô hiệu hóa'])),
    moreBlock,
  ]);

  // ----- Advanced -----
  const secAdvanced = el('section.pc-sec', { id: 'pcsec-advanced' }, [
    el('div.pc-sec-head', { text: 'Nâng cao' }),
    frow('Do Not Track', fpPill('doNotTrack', ['Mặc định', 'Mở', 'Đóng'])),
    frow('Tăng tốc phần cứng', fpPill('hardwareAccel', ['Mặc định', 'Mở', 'Đóng'])),
    frow('Hiển thị hình ảnh', fpPill('imageLoad', ['Cho phép', 'Chặn'])),
    frow('Âm thanh', fpPill('audioPlay', ['Cho phép', 'Chặn'])),
    frow('Vô hiệu hóa tính năng TLS', fpPill('tlsDisable', ['Mở', 'Đóng'])),
    frow('Khởi động tham số', launchArgs),
  ]);

  renderOverview();

  // ----- scrollable form + scrollspy -----
  const form = el('div.pc-form', {}, [secGeneral, secProxy, secFingerprint, secAdvanced]);

  const tabBar = el('div.tabs.pc-tabs');
  const tabBtns = {};
  function setActiveTab(key) {
    SECTIONS.forEach(([k]) => tabBtns[k] && tabBtns[k].classList.toggle('active', k === key));
  }
  let suppressSpy = false;
  let spyTimer = null;
  function scrollToSection(key) {
    const sec = form.querySelector('#pcsec-' + key);
    if (!sec) return;
    suppressSpy = true;
    setActiveTab(key);
    const top = sec.getBoundingClientRect().top - form.getBoundingClientRect().top + form.scrollTop;
    form.scrollTo({ top: Math.max(0, top - 4), behavior: 'smooth' });
    clearTimeout(spyTimer);
    spyTimer = setTimeout(() => { suppressSpy = false; }, 450);
  }
  function onFormScroll() {
    if (suppressSpy) return;
    if (form.scrollTop + form.clientHeight >= form.scrollHeight - 4) {
      setActiveTab(SECTIONS[SECTIONS.length - 1][0]);
      return;
    }
    const ft = form.getBoundingClientRect().top;
    let cur = SECTIONS[0][0];
    for (const [key] of SECTIONS) {
      const sec = form.querySelector('#pcsec-' + key);
      if (sec && sec.getBoundingClientRect().top - ft <= 16) cur = key;
    }
    setActiveTab(cur);
  }
  form.addEventListener('scroll', onFormScroll);

  SECTIONS.forEach(([key, label]) => {
    const b = el('button.tab' + (key === 'general' ? '.active' : ''), { text: label, onclick: () => scrollToSection(key) });
    tabBtns[key] = b;
    tabBar.appendChild(b);
  });

  function collectProxy() {
    const out = {
      proxyType: '',
      proxyHost: String(proxyData.host || '').trim(),
      proxyPort: String(proxyData.port || '').trim(),
      proxyUser: String(proxyData.user || '').trim(),
      proxyPass: proxyData.pass || '',
    };
    if (proxyTab === 'normal' && out.proxyHost && out.proxyPort) {
      // Tab "Proxy thường" là proxy host:port nên 'Token' trong combobox không áp được ở đây
      // (token có tab RIÊNG) - rơi về HTTP thay vì lưu proxyType 'Token' mà không có token.
      const pt = normalizeProxyType(proxyData.type);
      out.proxyType = pt === 'Token' ? PROXY_TYPE_DEFAULT : pt;
    } else if (proxyTab === 'token') {
      const tok = String(proxyData.token || '').trim();
      if (tok) { out.proxyType = 'Token'; out.proxyToken = tok; }
    } else if (proxyTab === 'rotate') {
      const url = String(proxyData.rotateUrl || '').trim();
      if (url) { out.proxyType = 'Proxy Xoay'; out.proxyRotateUrl = url; }
    }
    return out;
  }

  // Sinh 1 vân tay RIÊNG cho 1 hồ sơ: lấy cấu hình `fp` người dùng đang chọn làm
  // KHUÔN, nhưng re-random phần "phần cứng" (GPU/CPU/RAM/tên máy/MAC) + UA build +
  // seed noise (buildFpConfig tự genSeed mỗi lần) → mỗi profile là một máy khác nhau.
  function genFingerprint(name) {
    const f = { ...fp, languageList: fp.languageList.slice() };
    const g = osGpu(os);
    f.webglVendor = g.vendor;
    f.webglMeta = g.renderer;
    f.deviceName = osDeviceName(os);
    const hw = osHardware(os, g.renderer);
    f.cpu = hw.cpu; f.ram = hw.ram;
    f.mac = randMac();
    f.fontList = osFonts(os);
    f.fonts = String(f.fontList.length);
    // Ghim major → mỗi hồ sơ một build THẬT khác nhau trong dải đó. "Tất cả" → dùng
    // build THẬT của nhân ĐANG CHỌN trên card "Trình duyệt" (không bịa hằng mặc định,
    // cũng không lấy bừa nhân mới nhất như trước - phải đúng nhân hồ sơ sẽ chạy).
    // Firefox: KHÔNG random theo bảng CHROME_BUILDS. Bảng đó là build của Chrome -
    // ghim FF 140 sẽ nhả ra "140.0.7339.264" (build Chrome) rồi lưu vào uaFull của hồ sơ
    // Firefox, còn ghim FF 152 (không có trong bảng) lại nhả rỗng. UA Firefox chỉ lộ
    // major nên cả lô dùng chung đúng một phiên bản - đúng như Firefox thật.
    const cf = engineOf(kernel) === 'firefox'
      ? (chromeVer ? (kernelFullFor(chromeVer) || String(chromeVer)) : kernelFullFor(kernelVer))
      : (chromeVer ? randomChromeFull(chromeVer) : kernelFullFor(kernelVer));
    const ua = uaString(kernel, os, osVersion, cf);
    // GIỐNG màn tạo-đơn: chỉ phát section user_agent khi (a) đã ghim major, hoặc
    // (b) spoof OS khác Windows (token OS nằm trong UA + Sec-CH-UA-Platform).
    // Windows + "Tất cả" ⇒ '' ⇒ buildFpConfig BỎ HẲN user_agent → trình duyệt dùng UA
    // gốc của nhân, khớp 100% chromium thật. Trước đây batch luôn bơm UA tự dựng -
    // đúng loại bất nhất gây "Masking detected".
    const uaForConfig = (chromeVer || os !== 'Windows') ? ua : '';
    return JSON.stringify({
      // uaPinned/uaFull: để màn Sửa hồ sơ khôi phục đúng combobox User-Agent.
      // kernelMajor: NHÂN mà hồ sơ sẽ CHẠY = ĐÚNG major đã chọn trên card "Trình duyệt"
      // (kernelVer), y hệt màn tạo-đơn. Trước đây batch suy ra từ "nhân mới nhất đã cài"
      // nên chọn 140 trên thẻ vẫn tạo ra cả lô hồ sơ chạy 150.
      meta: { browser: kernel, engine: engineOf(kernel), os, osVersion, userAgent: ua, uaPinned: chromeVer || '', uaFull: cf || '', kernelMajor: kernelVer || '' },
      fpConfig: buildFpConfig(f, os, uaForConfig, name, osVersion),
      ui: f,
      // Cùng một bộ cookie cho mọi hồ sơ trong lô; bơm qua CDP lúc mở (cookie-inject.js).
      cookies: cookiesBox.value.trim(),
    });
  }

  async function doSave() {
    if (doSave._busy) return;
    const base = nameInput.value.trim();
    const startNum = parseInt(startInput.value, 10);
    const count = parseInt(countInput.value, 10);
    if (!Number.isFinite(count) || count < 1) { toast('Nhập số lượng hồ sơ hợp lệ (≥ 1)', 'err'); return; }
    if (count > 1000) { toast('Tối đa 1000 hồ sơ mỗi lần', 'err'); return; }
    const start = Number.isFinite(startNum) ? startNum : 1;
    const note = noteBox.value.trim();
    const tags = tagsSel.values.join(', ');
    const groupId = groupSel.value || null;
    const proxy = collectProxy();

    doSave._busy = true;
    const okBtn = host.querySelector('.pc-footer .btn.primary');
    if (okBtn) { okBtn.disabled = true; okBtn.textContent = 'Đang tạo…'; }
    try {
      await ensurePools(os);
      const items = [];
      for (let i = 0; i < count; i++) {
        const name = base ? `${base} ${start + i}` : `Profile ${start + i}`;
        items.push({ name, groupId, fingerprint: genFingerprint(name), dynamic: { note, tags, ...proxy } });
      }
      const created = await remote.profiles.createBatch(items);
      toast(tf('Đã tạo {0} hồ sơ', (created && created.length) || count), 'ok');
      try { window.__vtApp && window.__vtApp.refreshProfileCount && window.__vtApp.refreshProfileCount(); } catch { /* ignore */ }
      back();
    } catch (e) {
      notifyError(e, 'Tạo hàng loạt thất bại');
    } finally {
      doSave._busy = false;
      if (okBtn) { okBtn.disabled = false; okBtn.textContent = 'Tạo'; }
    }
  }

  const leftCol = el('div.pc-left', {}, [
    el('div.pc-chead', {}, [tabBar]),
    form,
    el('div.pc-footer', {}, [
      el('button.btn.primary', { text: 'Tạo', onclick: doSave }),
      el('button.btn', { text: 'Hủy', onclick: back }),
    ]),
  ]);

  const rightCol = el('div.pc-right', {}, [
    el('div.pc-ov-head', {}, [
      el('div.pc-ov-title', { text: 'Tổng quan' }),
      el('button.btn.subtle.pc-shuffle', { html: `${icon('shuffle')}<span>Dấu vân tay mới</span>`, onclick: () => { if (!hasFeature('new_fingerprint')) { gateFeature('new_fingerprint', { navigate: ctx.navigate }); return; } fp = newFingerprint(); applyOsConsistency(); rerollUA(); } }),
    ]),
    ovList,
  ]);

  host.appendChild(el('div.pc-split', {}, [leftCol, rightCol]));

  remote.groups.list().then((list) => {
    groups = list || [];
    groupSel.setGroups(groups);
  });

  // Kho nhân của CẢ HAI engine đã được primeEngines() nạp ngay sau renderKernels() ở trên
  // - không cần gọi riêng ở đây (và cũng không được, kẻo tải trùng).
  ensurePools(os).then(() => { applyOsConsistency(); });
  } // end build()

  build();
  return null;
}
