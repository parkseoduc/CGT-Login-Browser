// Trang "NẠP TIỀN" của APP - port trang /topup của web landing. Cùng khung Thủ tục thanh toán, BỎ ô "Số dư"; panel phải
// = số tiền muốn nạp. Đơn vị nhập TỰ theo phương thức: VietQR ⇒ VNĐ, PayPal / thẻ ⇒ USD (nhập USD thì gửi server đúng số
// cent - amountUsdCents - khỏi lệch 1 cent). Đổi phương thức thì quy số đã nhập sang đơn vị mới; quay lại mà chưa sửa ⇒
// trả đúng số gốc (lastConv). Ví nhận của cổng USD chỉ là ƯỚC TÍNH: server quy phần gốc theo giá VCB lúc tiền về.
import { el, clear, closeModal } from '../ui.js';
import { icon } from '../icons.js';
import { t, tf } from '../i18n.js';
import { showTopupModal } from '../ui/topup-modal.js';
import {
  fmtVnd, usdC, fx, totalMoney, loadFx, PAY_METHODS, PAY, loadPayConfig, intlQuote, intlLimitWarn,
  methodTiles, methodDetail, payViaGateway, showGatewaySuccess,
} from './pay-common.js';

const TOPUP_KEY = 'polyTopupPref';
const PRESETS = { vnd: [100000, 200000, 500000, 1000000, 2000000, 5000000], usd: [10, 20, 50, 100, 200, 500] };

export function render(ctx) {
  const host = el('div.co-page.co-app');
  ctx.container.appendChild(host);
  const list = PAY_METHODS.filter((p) => p.key !== 'balance');
  let pref = {};
  try { pref = JSON.parse(localStorage.getItem(TOPUP_KEY) || '{}') || {}; } catch { pref = {}; }
  let method = list.some((p) => p.key === pref.method) ? pref.method : 'vietqr';
  const curOf = (m) => (m === 'vietqr' ? 'vnd' : 'usd');
  let cur$ = curOf(method);
  let input = typeof pref.value === 'string' && (!pref.cur || pref.cur === cur$) ? pref.value : '';
  let balance = null, ready = false, busy = false, lastConv = null, inputEl = null;
  const save = () => { try { localStorage.setItem(TOPUP_KEY, JSON.stringify({ method, value: input })); } catch { /* bỏ qua */ } };
  // Đọc lỗi (wallet:get trả error: true) ⇒ null như web, KHÔNG coi là số dư 0.
  const refreshBalance = async () => { try { const w = await vt.wallet.get(); balance = w && !w.error ? Number(w.balance) || 0 : null; } catch { balance = null; } };

  function mountBackLink() {
    const h = document.getElementById('header-title');
    if (!h) return;
    h.classList.add('is-flow');
    h.innerHTML = '';
    h.appendChild(el('button.rpa-back', { html: `${icon('chevron')}<span>Quay lại</span>`, onclick: () => ctx.navigate('upgrade') }));
    h.appendChild(el('div.rpa-top-div'));
    h.appendChild(el('span.header-flow-title', { text: 'Nạp tiền' }));
  }
  function unmountBackLink() { const h = document.getElementById('header-title'); if (h) h.classList.remove('is-flow'); }

  function parsed() {
    const s = String(input).replace(/\s/g, '');
    if (cur$ === 'usd') {
      if (!/^\d+(\.\d{0,2})?$/.test(s)) return null;
      const [a, b = ''] = s.split('.');
      const cents = Number(a) * 100 + Number(b.padEnd(2, '0'));
      if (!Number.isSafeInteger(cents) || cents <= 0) return null;
      return { cents, vnd: fx.state.rate ? fx.toVnd(cents / 100) : 0 };
    }
    const d = s.replace(/[.,]/g, '');
    if (!/^\d+$/.test(d)) return null;
    const vnd = Number(d);
    return Number.isSafeInteger(vnd) && vnd > 0 ? { vnd, cents: null } : null;
  }

  function paint(keepFocus) {
    clear(host);
    // Tiêu đề 'Nạp tiền' đã ở HEADER LỚN của app (mountBackLink) ⇒ khung không lặp lại dòng tiêu đề như bản web.
    if (!ready) { host.appendChild(el('div.co-wrap', {}, [el('div.co-loading', { text: 'Đang tải…' })])); return; }
    const cur = list.find((p) => p.key === method) || list[0];
    const amt = parsed();
    const vnd = amt ? amt.vnd : 0;
    const iq = cur.gateway && cur.ready ? intlQuote(cur.gateway, amt) : null;
    const MIN_QR = 10000;
    const out = !amt ? null
      : cur.gateway ? (vnd < PAY.limits.minVnd || vnd > PAY.limits.maxVnd ? intlLimitWarn(vnd) : null)
      : (vnd < MIN_QR ? tf('Số tiền nạp tối thiểu {0}', fmtVnd(MIN_QR)) : null);

    const left = el('div.co-panel.co-left', {}, [
      el('div.co-panel-title', { text: 'Chọn phương thức thanh toán' }),
      methodTiles(list, method, null, 0, (k) => {
        const next = curOf(k);
        if (next !== cur$) {
          if (lastConv && lastConv.cur === next && lastConv.result === input) { input = lastConv.from; lastConv = null; }
          else {
            const a = parsed();
            const conv = a && fx.state.rate ? (next === 'usd' ? String(fx.toUsd(a.vnd)) : fx.toVnd(a.cents / 100).toLocaleString('vi-VN')) : '';
            lastConv = { cur: cur$, from: input, result: conv };
            input = conv;
          }
          cur$ = next;
        }
        method = k; save(); paint();
      }),
      methodDetail(cur, [out]),
    ]);

    const row = (k, v, cls) => el('div.co-row' + (cls || ''), {}, [el('span.co-row-k', { text: k }), el('span.co-row-v', { text: v })]);
    inputEl = el('input.tp-input', { type: 'text', inputmode: cur$ === 'usd' ? 'decimal' : 'numeric', value: input, placeholder: cur$ === 'usd' ? '0.00' : '0', 'aria-label': t('Số tiền muốn nạp') });
    inputEl.addEventListener('input', () => {
      let v = inputEl.value;
      if (cur$ === 'usd') {
        v = v.replace(/,/g, '.').replace(/[^\d.]/g, '');
        const i = v.indexOf('.');
        if (i >= 0) v = v.slice(0, i + 1) + v.slice(i + 1).replace(/\./g, '').slice(0, 2);
      } else {
        const d = v.replace(/\D/g, '').replace(/^0+(?=\d)/, '').slice(0, 12);
        v = d ? Number(d).toLocaleString('vi-VN') : '';
      }
      input = v; save(); paint(true);
    });
    const chips = el('div.tp-chips', {}, PRESETS[cur$].map((n) => el('button.tp-chip' + (amt && (cur$ === 'usd' ? amt.cents === n * 100 : amt.vnd === n) ? '.active' : ''), {
      type: 'button', text: cur$ === 'usd' ? fx.fmt(n) : fmtVnd(n),
      onclick: () => { input = cur$ === 'usd' ? String(n) : n.toLocaleString('vi-VN'); save(); paint(); },
    })));
    const credit = !amt ? 0 : cur.gateway ? (fx.state.rate ? fx.toVnd((iq ? iq.base : 0) / 100) : 0) : vnd;
    const payText = !cur.ready ? 'Sắp ra mắt' : cur.key === 'vietqr' ? 'Nạp tiền bằng VietQR' : cur.key === 'paypal' ? 'Thanh toán qua PayPal' : 'Thanh toán bằng thẻ';
    const right = el('div.co-panel.co-right', {}, [
      el('div.co-panel-title', { text: 'Số tiền muốn nạp' }),
      el('div.tp-amount', {}, [
        el('label.tp-box' + (out ? '.bad' : ''), {}, [el('i', { text: cur$ === 'usd' ? '$' : '₫' }), inputEl]),
        amt && fx.show() ? el('div.tp-conv', { text: cur$ === 'usd' ? '≈ ' + fmtVnd(vnd) : '≈ ' + fx.fmt(fx.toUsd(vnd)) }) : null,
        chips,
      ]),
      el('div.co-div'),
      balance != null ? row('Số dư hiện tại', fmtVnd(balance)) : null,
      iq ? row('Tạm tính', usdC(iq.base)) : null,
      iq ? row(tf('Phí {0} ({1}%)', cur.key === 'paypal' ? 'PayPal' : t('thẻ'), iq.pct), iq.fee > 0 ? '+' + usdC(iq.fee) : t('Miễn phí'), '.co-row-fee') : null,
      iq && cur.gateway === 'dodo' && PAY.fees.dodo.vatPct > 0 ? row(tf('Thuế VAT (~{0}%)', PAY.fees.dodo.vatPct), t('Cộng khi thanh toán'), '.co-row-vat') : null,
      row(cur.gateway ? 'Ví nhận (ước tính)' : 'Ví nhận', amt ? '+' + fmtVnd(credit) : '-', '.tp-row-credit'),
      el('div.co-div'),
      el('div.co-total', {}, [
        el('div.co-total-k', { text: 'Tổng thanh toán' }),
        iq ? el('div.ap-money.ap-money-total', {}, [
          el('span.ap-total-amt', { text: usdC(iq.total) }),
          el('span.ap-usd', { text: '≈ ' + fmtVnd(vnd) + (iq.fee > 0 ? ' + ' + t('phí') + ' ' + usdC(iq.fee) : '') }),
        ]) : amt ? totalMoney(vnd) : el('div.ap-money.ap-money-total', {}, [el('span.ap-total-amt', { text: '-' })]),
      ]),
      el('button.btn.primary.co-pay', {
        type: 'button', disabled: cur.ready && amt && !out && !busy ? null : 'disabled',
        text: busy ? 'Đang chuyển sang cổng thanh toán…' : payText, onclick: () => onTopup(cur, amt),
      }),
      el('div.co-note', { text: cur.gateway
        ? 'Số tiền thực cộng vào ví tính theo tỷ giá Vietcombank lúc tiền về, phí cổng thanh toán không cộng vào ví.'
        : 'Ví CGTBrowser tính bằng VNĐ: số tiền nạp được quy ra VNĐ, rồi trừ VNĐ để mua gói.' }),
    ]);
    host.appendChild(el('div.co-wrap', {}, [el('div.co-cols', {}, [left, right])]));
    if (keepFocus && inputEl) {
      inputEl.focus();
      try { inputEl.setSelectionRange(inputEl.value.length, inputEl.value.length); } catch { /* bỏ qua */ }
    }
  }

  async function onTopup(cur, amt) {
    if (!amt || busy || !cur.ready) return;
    if (cur.key === 'vietqr') {
      showTopupModal({ amount: amt.vnd, onDone: (b) => { balance = Number(b) || 0; paint(); } });
      return;
    }
    busy = true; paint();
    try {
      const body = { provider: cur.gateway };
      if (amt.cents != null) body.amountUsdCents = amt.cents; else body.amountVnd = amt.vnd;
      await payViaGateway(body, (d) => {
        balance = Number(d.balance) || 0; paint();
        showGatewaySuccess(d, [
          el('button.btn', { text: 'Đóng', onclick: closeModal }),
          el('button.btn.primary', { text: 'Đi tới Gói dịch vụ', onclick: () => { closeModal(); ctx.navigate('upgrade'); } }),
        ]);
      });
    } finally { busy = false; paint(); }
  }

  mountBackLink();
  paint();
  (async () => {
    await Promise.all([refreshBalance(), loadPayConfig(), loadFx()]);
    ready = true;
    if (document.body.contains(host)) paint();
  })();
  return {
    onShow: () => { mountBackLink(); Promise.all([refreshBalance(), loadPayConfig()]).then(() => paint()); },
    onHide: () => unmountBackLink(),
    destroy: () => unmountBackLink(),
  };
}
