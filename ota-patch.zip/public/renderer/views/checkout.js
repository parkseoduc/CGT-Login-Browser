// Trang "THỦ TỤC THANH TOÁN" của APP - port 1:1 trang /checkout của web landing (chủ sở hữu 2026-10-29: app giống web về
// thanh toán và dịch vụ). Bước 2 của mua gói / mua thêm thiết bị: bước 1 (trang Nâng cấp gói) ghi loại đơn vào
// localStorage (pay-common.js ORDER_KEY) rồi chuyển route 'checkout'.
//   • Đơn 'plan': tiền TÍNH LẠI bằng costFor() của upgrade.js + bảng giá thật + gói hiện tại ⇒ khớp từng đồng với bước 1
//     và với server (server lại tính lần nữa khi mua - renderer không quyết số tiền).
//   • Đơn 'devices': đơn giá / số mua tối đa đọc từ snapshot thiết bị; mua = POST /devices/purchase {qty}.
//   • 4 phương thức: Số dư (trừ ví), VietQR (QR điền sẵn tổng tiền), PayPal / thẻ (mở trình duyệt ngoài, server cộng VNĐ
//     theo giá Vietcombank lúc tiền về, phí cổng theo bậc admin đặt).
import { el, clear, toast, openModal, closeModal } from '../ui.js';
import { icon } from '../icons.js';
import { t, tf } from '../i18n.js';
import { showTopupModal } from '../ui/topup-modal.js';
import { costFor, loadPricingTables, loadCurrentSub, TABS, pkgOf, pkgOrLife, lifetimePkg, tierFor, subIsActive, CURRENT_SUB, iso, validityCount, pricingReady } from './upgrade.js';
import {
  fmtVnd, withUsd, usdC, totalMoney, loadFx, PAY_METHODS, PAY, loadPayConfig, intlQuote, intlLimitWarn,
  methodTiles, methodDetail, readOrder, PAY_KEY, payViaGateway, showGatewaySuccess, OK_ANIM, FAIL_ANIM,
} from './pay-common.js';

const UPGRADE_KEY = 'polyUpgradeState';   // lựa chọn gói do trang Nâng cấp gói lưu (upgrade.js save())
const COUPON_KEY = 'polyCheckoutCoupon';   // mã giảm giá { code, sig } ở sessionStorage (đóng app là mất - xem upgrade.js); sig = chữ ký đơn

function loadUpgradeState() {
  let saved = null;
  try { saved = JSON.parse(localStorage.getItem(UPGRADE_KEY) || 'null'); } catch { saved = null; }
  saved = saved && typeof saved === 'object' ? saved : {};
  const st = { tabKey: 'professional', qty: 0, members: 0, validity: 0, ...saved };
  // Gói cố định (2026-11-12): nhớ GÓI; lựa chọn cũ chỉ có qty ⇒ gói nhỏ nhất chứa được số đó (y upgrade.js).
  if (st.tabKey !== 'lifetime' && !TABS.some((tb) => tb.key === st.tabKey)) st.tabKey = tierFor(Number(st.qty) || 0);
  st.qty = pkgOf(st.tabKey).profiles;
  st.members = Math.max(0, Math.floor(Number(st.members) || 0));
  // Kẹp y web (loadUpgradeState): ngoài [-1, số kỳ hạn) ⇒ 30 ngày, và chỉ coi là 'đã lưu' khi hợp lệ.
  // Bảng giá có thể chưa nạp lúc này (validityCount() = 0) ⇒ chưa nạp thì chỉ kiểm khuôn; kẹp lại sau khi nạp.
  const inRange = (v) => Number.isInteger(Number(v)) && Number(v) >= 0 && (validityCount() === 0 || Number(v) < validityCount());   // -1 ("Không gia hạn" cũ) không còn
  if (!inRange(st.validity)) st.validity = 0;
  st._savedValidity = saved.validity != null && inRange(saved.validity);
  return st;
}

export function render(ctx) {
  const host = el('div.co-page.co-app');
  ctx.container.appendChild(host);
  const order = readOrder();
  const isDev = order.kind === 'devices';
  const state = loadUpgradeState();
  const hasSavedValidity = state._savedValidity;
  delete state._savedValidity;
  let method = 'balance';
  try { const m = localStorage.getItem(PAY_KEY); if (PAY_METHODS.some((p) => p.key === m)) method = m; } catch { /* bỏ qua */ }
  const pick = (m) => { method = m; try { localStorage.setItem(PAY_KEY, m); } catch { /* bỏ qua */ } };
  let balance = null, dv = null, ready = false, busy = false;
  // MÃ GIẢM GIÁ (2026-11-07) - Y HỆT web /checkout (dashboard-upgrade.js): "Áp dụng" ⇒ vt.billing.couponPreview (server tự tính giá
  // gốc từ LỰA CHỌN đơn) ⇒ hiện số giảm; thanh toán gửi lại CHUỖI MÃ + số đang thấy (expectAmount), server kiểm lại trong
  // transaction trừ ví. Mã nhớ ở COUPON_KEY theo chữ ký đơn ⇒ đi nạp tiền rồi quay lại vẫn còn; số nạp = tổng SAU giảm.
  let cp = null;        // { code, base, discount, pay } - kết quả server
  let cpDraft = '', cpErr = '', cpBusy = false;
  const devQty = () => Math.max(1, Math.min(dv && dv.maxBuy ? dv.maxBuy : 1, Math.trunc(Number(order.qty)) || 1));
  const orderPayload = () => (isDev ? { kind: 'devices', qty: devQty() }
    : { kind: 'plan', plan: state.tabKey, qty: state.qty, members: state.members, validity: state.validity });
  const orderSig = () => JSON.stringify(orderPayload());
  const saveCp = () => {
    try { if (cp) sessionStorage.setItem(COUPON_KEY, JSON.stringify({ code: cp.code, sig: orderSig() })); else sessionStorage.removeItem(COUPON_KEY); } catch { /* bỏ qua */ }
  };
  const couponMsg = (r) => (r && r.code === 'COUPON_MIN_ORDER' && r.minOrder ? tf('Mã chỉ áp dụng cho đơn từ {0}', fmtVnd(r.minOrder))
    : r && r.code === 'COUPON_MIN_DAYS' && r.minDays ? tf('Mã chỉ áp dụng cho gói từ {0} ngày', r.minDays)
    : t((r && r.message) || 'Mã giảm giá không hợp lệ'));
  async function applyCoupon(code) {
    code = String(code || '').trim();
    if (!code) { cpErr = t('Vui lòng nhập mã giảm giá'); paint(); return; }
    cpBusy = true; cpErr = ''; paint();
    try {
      const env = await vt.billing.couponPreview({ code, order: orderPayload() });
      const r = env && env.ok ? env.data : null;
      if (r && r.ok) { cp = { code: r.code, base: Number(r.base), discount: Number(r.discount), pay: Number(r.pay) }; cpDraft = ''; }
      else { cp = null; cpDraft = code; cpErr = r ? couponMsg(r) : t((env && env.error) || 'Không kiểm tra được mã, vui lòng thử lại'); }
    } catch (e) { cp = null; cpDraft = code; cpErr = t('Không kiểm tra được mã, vui lòng thử lại'); }
    cpBusy = false; saveCp(); paint();
  }
  const removeCoupon = () => { cp = null; cpErr = ''; saveCp(); paint(); };
  // Đơn đang thanh toán = đơn bước 1 + mã (nếu có): amount = số SAU giảm do server báo (mọi đường trả tiền dùng số này).
  const currentOrder = () => { const o = buildOrder(); if (cp) { o.baseAmount = o.amount; o.amount = cp.pay; } return o; };
  const couponFields = () => (cp ? { couponCode: cp.code, expectAmount: cp.pay } : {});

  // Đọc lỗi (wallet:get trả error: true) ⇒ null như web, KHÔNG coi là số dư 0.
  const refreshBalance = async () => { try { const w = await vt.wallet.get(); balance = w && !w.error ? Number(w.balance) || 0 : null; } catch { balance = null; } };
  const loadDevices = async () => { const r = await vt.devices.list().catch(() => null); dv = r && r.ok ? r.data : null; };
  const refreshShell = () => {
    try { window.__vtApp && window.__vtApp.refreshWalletBalance && window.__vtApp.refreshWalletBalance(); } catch { /* bỏ qua */ }
    try { window.__vtApp && window.__vtApp.refreshProfileCount && window.__vtApp.refreshProfileCount(); } catch { /* bỏ qua */ }
  };
  // Đơn thiết bị về trang "Quản lý thiết bị" (route riêng từ 2026-11-12), đơn gói về trang Nâng cấp gói.
  const goBack = () => ctx.navigate(isDev ? 'devices' : 'upgrade');

  // "Quay lại" ở HEADER LỚN - giống trang Nâng cấp gói.
  function mountBackLink() {
    const h = document.getElementById('header-title');
    if (!h) return;
    h.classList.add('is-flow');
    h.innerHTML = '';
    h.appendChild(el('button.rpa-back', { html: `${icon('chevron')}<span>${isDev ? 'Quay lại quản lý thiết bị' : 'Quay lại chọn gói'}</span>`, onclick: goBack }));
    h.appendChild(el('div.rpa-top-div'));
    h.appendChild(el('span.header-flow-title', { text: 'Thủ tục thanh toán' }));
  }
  function unmountBackLink() { const h = document.getElementById('header-title'); if (h) h.classList.remove('is-flow'); }

  // Đơn hiện tại → dữ liệu để vẽ + hàm mua.
  function buildOrder() {
    if (isDev) {
      const unit = dv ? Number(dv.unit) || 0 : 0;
      const qty = devQty();
      const limit = dv ? Number(dv.limit) || 0 : 0;
      return {
        amount: unit * qty, label: 'Mua thiết bị', confirmTitle: 'Xác nhận mua thiết bị',
        title: t('Mua thêm thiết bị'), sub: tf('{0} thiết bị', qty),
        rows: [
          ['Số lượng', String(qty)],
          ['Đơn giá', tf('{0} / thiết bị', fmtVnd(unit))],
          dv ? ['Thiết bị đã dùng', String(Number(dv.used) || 0) + ' / ' + (limit === 0 ? t('không giới hạn') : String(limit))] : null,
          ['Loại phí', t('Một lần, không mất khi gia hạn')],
        ].filter(Boolean),
        totalSub: null, invalid: !(unit > 0),
        doPurchase: async () => { const r = await vt.devices.purchase(qty, couponFields()); if (!r || !r.ok) throw Object.assign(new Error((r && r.error) || 'Mua thiết bị thất bại'), { code: r && r.code }); await loadDevices(); return r.data; },
        successTitle: tf('{0} thành công', t('Mua thiết bị')), successText: tf('Đã mua thêm {0} thiết bị.', qty),
        doneText: 'Về quản lý thiết bị', payNowText: 'Thanh toán ngay',
      };
    }
    const c = costFor(state);
    const tab = pkgOrLife(state.tabKey);
    const totalDays = c.upgrade ? c.prorateDays : c.days;
    // Nâng cấp lúc còn hạn: server GIỮ hạn cũ rồi cộng đúng số ngày mua (billing.repo keepPeriod) ⇒ hạn mới = HẠN CŨ + c.days,
      // không phải hôm nay + số ngày còn lại (làm tròn lên) - lệch tới 1 ngày.
      const expire = c.upgrade && CURRENT_SUB.periodEnd && !isNaN(new Date(CURRENT_SUB.periodEnd).getTime())
        ? new Date(new Date(CURRENT_SUB.periodEnd).getTime() + c.days * 86400000)
        : (() => { const d = new Date(); d.setDate(d.getDate() + totalDays); return d; })();
    const label = c.upgrade ? 'Nâng cấp' : 'Mua gói';
    return {
      amount: c.upgrade ? c.payNow : c.total, label, confirmTitle: c.upgrade ? 'Xác nhận nâng cấp gói' : 'Xác nhận mua gói',
      title: tab.name, sub: c.upgrade ? tf('Nâng cấp từ gói {0}', CURRENT_SUB.planName) : tf('{0} hồ sơ trình duyệt', c.packageProfiles),
      rows: [
        ['Hồ sơ trình duyệt', String(c.packageProfiles)],
        ['Thành viên nhóm', String(state.members)],
        ['Thời hạn', c.lifetime ? t('Vĩnh viễn') : c.days > 0 ? tf('{0} ngày', c.days) : t('Không gia hạn')],
        // Còn hạn + gia hạn: kéo dài CẢ thuê bao (toàn bộ hồ sơ + thành viên) - tiền đã gồm phần này.
        ['Ngày hết hạn', c.lifetime ? t('Không giới hạn') : iso(expire)],
        c.lifetime ? ['Giá trả một lần', fmtVnd(c.monthly)] : ['Giá mỗi tháng', tf('{0}/tháng', fmtVnd(c.upgrade && c.days > 0 ? c.extendMonthly : (c.disc > 0 ? c.discounted : c.monthly)))],
        c.disc > 0 ? ['Giảm giá', '-' + Math.round(c.disc * 100) + '%', '.co-row-save'] : null,
      ].filter(Boolean),
      totalSub: c.upgrade || c.lifetime ? null : tf('({0} tháng)', c.months), invalid: !!c.invalid,
      doPurchase: async () => {
        const r = await vt.billing.purchaseUpgrade({ plan: state.tabKey, qty: state.qty, members: state.members, validity: state.validity, ...couponFields() });
        if (!r || !r.ok) throw Object.assign(new Error((r && r.error) || tf('{0} thất bại', t(label))), { code: r && r.code });
        CURRENT_SUB._loaded = false; await loadCurrentSub(state.qty);
        return r.data;
      },
      successTitle: tf('{0} thành công', t(label)), successText: tf('Bạn đã {0} thành công. Thông tin gói đã được cập nhật.', t(label).toLowerCase()),
      doneText: 'Về trang gói', payNowText: 'Thanh toán gói ngay',
    };
  }

  // Ô mã giảm giá (panel phải, dưới các dòng đơn). Gõ chữ KHÔNG vẽ lại (giữ con trỏ) - chỉ "Áp dụng"/Enter mới vẽ.
  function couponBox(ord) {
    if (ord.invalid) return null;
    if (cp) {
      return el('div.co-coupon.applied', {}, [
        el('div.co-row.co-row-save', {}, [
          el('span.co-row-k', {}, [document.createTextNode(t('Mã giảm giá') + ' '), el('b.co-coupon-code', { text: cp.code })]),
          el('span.co-row-v', { text: '-' + fmtVnd(cp.discount) }),
        ]),
        el('button.co-coupon-x', { type: 'button', text: t('Gỡ mã'), onclick: removeCoupon }),
      ]);
    }
    // Đơn GÓI: mã nhập ở bước 1 (trang Nâng cấp gói, trên nút "Thủ tục thanh toán") - ở đây chỉ báo lý do nếu mã đã nhớ bị bỏ.
    if (!isDev) return cpErr ? el('div.co-coupon', {}, [el('div.co-coupon-err', {}, [cpDraft ? el('b', { text: String(cpDraft).trim().toUpperCase() + ': ' }) : null, document.createTextNode(cpErr)])]) : null;
    const inp = el('input.cpf-inp.co-coupon-inp', { type: 'text', maxlength: '32', autocomplete: 'off', spellcheck: 'false', placeholder: t('Nhập mã giảm giá (nếu có)') });
    inp.value = cpDraft;
    inp.addEventListener('input', () => { cpDraft = inp.value; });
    inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); applyCoupon(inp.value); } });
    return el('div.co-coupon', {}, [
      el('div.cpf', {}, [
        inp,
        el('button.cpf-btn.co-coupon-btn', { type: 'button', disabled: cpBusy ? 'disabled' : null, text: cpBusy ? t('Đang kiểm tra…') : t('Áp dụng'), onclick: () => applyCoupon(inp.value) }),
      ]),
      cpErr ? el('div.co-coupon-err', { text: cpErr }) : null,
    ]);
  }

  function paint() {
    clear(host);
    const steps = el('div.co-steps', {}, [
      el('div.co-step.done', {}, [el('span.co-step-no', { html: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg>' }), el('span', { text: isDev ? 'Chọn thiết bị' : 'Chọn gói' })]),
      el('span.co-step-line'),
      el('div.co-step.active', {}, [el('span.co-step-no', { text: '2' }), el('span', { text: 'Thanh toán' })]),
    ]);
    const head = el('div.co-head', {}, [el('span'), el('h1.co-title', { text: 'Thủ tục thanh toán' }), steps]);
    if (!ready) { host.appendChild(el('div.co-wrap', {}, [head, el('div.co-loading', { text: 'Đang tải…' })])); return; }
    // Bảng giá web admin không nạp được ⇒ không cho trả tiền đơn gói (không có số mặc định để tính).
    if (!isDev && !pricingReady()) { host.appendChild(el('div.co-wrap', {}, [head, el('div.co-loading', { text: 'Không tải được bảng giá. Vui lòng mở lại trang.' })])); return; }

    const ord = currentOrder();
    const amount = ord.amount;
    const cur = PAY_METHODS.find((p) => p.key === method) || PAY_METHODS[0];
    const intlOut = !!cur.gateway && cur.ready && (amount < PAY.limits.minVnd || amount > PAY.limits.maxVnd);
    const short = balance != null && balance < amount ? amount - balance : 0;
    const left = el('div.co-panel.co-left', {}, [
      el('div.co-panel-title', { text: 'Chọn phương thức thanh toán' }),
      methodTiles(PAY_METHODS, method, balance, short, (k) => { pick(k); paint(); }),
      methodDetail(cur, [
        cur.key === 'balance' && short ? tf('Số dư không đủ, còn thiếu {0}', withUsd(short)) : null,
        intlOut ? intlLimitWarn(amount) : null,
      ]),
    ]);

    const row = (k, v, cls) => el('div.co-row' + (cls || ''), {}, [el('span.co-row-k', { text: k }), el('span.co-row-v', { text: v })]);
    const iq = cur.gateway && cur.ready ? intlQuote(cur.gateway, { vnd: amount }) : null;
    const payText = !cur.ready ? 'Sắp ra mắt' : cur.key === 'vietqr' ? 'Nạp tiền bằng VietQR' : cur.key === 'paypal' ? 'Thanh toán qua PayPal' : cur.key === 'card' ? 'Thanh toán bằng thẻ' : 'Thanh toán ngay';
    const right = el('div.co-panel.co-right', {}, [
      el('div.co-panel-title', { text: 'Thông tin đơn hàng' }),
      el('div.co-plan', {}, [el('span.co-plan-name', { text: ord.title }), el('span.co-plan-sub', { text: ord.sub })]),
      ...ord.rows.map(([k, v, cls]) => row(k, v, cls)),
      couponBox(ord),
      el('div.co-div'),
      iq ? row('Tạm tính', usdC(iq.base) + ' (' + fmtVnd(amount) + ')') : null,
      iq ? row(tf('Phí {0} ({1}%)', cur.key === 'paypal' ? 'PayPal' : t('thẻ'), iq.pct), iq.fee > 0 ? '+' + usdC(iq.fee) : t('Miễn phí'), '.co-row-fee') : null,
      iq && cur.gateway === 'dodo' && PAY.fees.dodo.vatPct > 0 ? row(tf('Thuế VAT (~{0}%)', PAY.fees.dodo.vatPct), t('Cộng khi thanh toán'), '.co-row-vat') : null,
      iq ? el('div.co-div') : null,
      el('div.co-total', {}, [
        el('div.co-total-k', {}, [document.createTextNode('Tổng thanh toán'), ord.totalSub ? el('span.ap-total-sub', { text: ord.totalSub }) : null]),
        iq ? el('div.ap-money.ap-money-total', {}, [
          el('span.ap-total-amt', { text: usdC(iq.total) }),
          el('span.ap-usd', { text: iq.fee > 0 ? tf('{0} + phí {1}', fmtVnd(amount), usdC(iq.fee)) : fmtVnd(amount) }),
        ]) : totalMoney(amount),
      ]),
      el('button.btn.primary.co-pay', {
        type: 'button', disabled: cur.ready && !intlOut && !busy && !ord.invalid ? null : 'disabled',
        text: busy ? 'Đang chuyển sang cổng thanh toán…' : payText, onclick: () => onPay(ord),
      }),
      el('div.co-note', { text: 'Ví CGTBrowser tính bằng VNĐ: số tiền nạp được quy ra VNĐ, rồi trừ VNĐ để mua gói.' }),
    ]);
    host.appendChild(el('div.co-wrap', {}, [head, el('div.co-cols', {}, [left, right])]));
  }

  async function onPay(ord) {
    if (ord.invalid) return;
    const amount = ord.amount;
    await refreshBalance();
    if (balance == null) { toast('Không đọc được số dư ví', 'err'); return; }
    const cur = PAY_METHODS.find((p) => p.key === method);
    if (method === 'vietqr') {
      // QR = ĐÚNG tổng thanh toán của đơn, KHÔNG trừ số dư có sẵn ("nạp là nạp").
      showTopupModal({ amount, onDone: (b) => { balance = Number(b) || 0; pick('balance'); paint(); } });
      return;
    }
    if (cur && cur.gateway) {
      if (!cur.ready || busy) return;
      busy = true; paint();
      try {
        await payViaGateway({ provider: cur.gateway, amountVnd: amount }, async (d) => {
          balance = Number(d.balance) || 0; pick('balance'); paint();
          showGatewaySuccess(d, [
            el('button.btn', { text: 'Để sau', onclick: closeModal }),
            el('button.btn.primary', { text: ord.payNowText, onclick: () => { closeModal(); onPay(currentOrder()); } }),
          ]);
        });
      } finally { busy = false; paint(); }
      return;
    }
    if (balance < amount) { insufficient(ord); paint(); return; }
    openModal({
      title: ord.confirmTitle,
      width: 560,
      body: [el('div.ap-fund-note.ap-confirm-note', { text: tf('Thanh toán {0} từ ví CGTBrowser?', fmtVnd(amount)) })],
      footer: [
        el('button.btn', { text: 'Hủy', onclick: closeModal }),
        el('button.btn.primary', { text: 'Đồng ý', onclick: () => { closeModal(); purchase(ord); } }),
      ],
    });
  }

  function insufficient(ord) {
    const shortfall = Math.max(0, ord.amount - (balance || 0));
    openModal({
      title: 'Số dư không đủ',
      width: 560,
      body: [
        el('div.ap-fail-anim', { html: FAIL_ANIM }),
        el('div.ap-fund-note.ap-fail-note', { text: tf('Số dư ví không đủ để {0}. Bạn cần nạp thêm để tiếp tục.', t(ord.label).toLowerCase()) }),
        el('div.dv-short', { text: tf('Còn thiếu {0}', withUsd(shortfall)) }),
      ],
      footer: [
        el('button.btn', { text: 'Để sau', onclick: closeModal }),
        // Sang màn "Nạp tiền" (chọn VietQR / PayPal / thẻ, tự nhập số tiền) - không bật thẳng modal QR (chủ sở hữu 2026-10-29).
        el('button.btn.primary', { text: 'Nạp tiền', onclick: () => { closeModal(); ctx.navigate('topup'); } }),
      ],
    });
  }

  async function purchase(ord) {
    try { await ord.doPurchase(); } catch (e) {
      if (e && e.code === 'INSUFFICIENT_FUNDS') { await refreshBalance(); insufficient(ord); paint(); return; }
      // Mã hết hiệu lực giữa lúc xem và lúc bấm ⇒ server KHÔNG trừ đồng nào; gỡ mã, báo lý do.
      if (e && typeof e.code === 'string' && e.code.indexOf('COUPON_') === 0) {
        cp = null; cpErr = t(e.message || 'Mã giảm giá không hợp lệ'); saveCp(); paint();
        toast(cpErr, 'err'); return;
      }
      // Giá vừa đổi ⇒ không trừ tiền; kiểm lại mã để hiện đúng số mới rồi khách bấm lại.
      if (e && e.code === 'PRICE_CHANGED') {
        if (cp) await applyCoupon(cp.code); else paint();
        toast(t(e.message || 'Giá đơn hàng vừa thay đổi, vui lòng kiểm tra lại trước khi thanh toán'), 'err'); return;
      }
      toast((e && e.message) || tf('{0} thất bại', t(ord.label)), 'err');
      return;
    }
    cp = null; cpErr = ''; saveCp();   // mã đã dùng cho đơn này - đơn sau phải nhập lại
    await refreshBalance();
    refreshShell();
    paint();
    openModal({
      title: ord.successTitle,
      width: 560,
      body: [el('div.ap-success-anim', { html: OK_ANIM }), el('div.ap-fund-note.ap-success-note', { text: ord.successText })],
      footer: [el('button.btn.primary', { text: ord.doneText, onclick: () => { closeModal(); goBack(); } })],
    });
  }

  mountBackLink();
  paint();
  (async () => {
    const [, , sub] = await Promise.all([loadPricingTables(), refreshBalance(), isDev ? null : loadCurrentSub(state.qty), loadPayConfig(), loadFx(), isDev ? loadDevices() : null]);
    // "Không gia hạn" (-1) chỉ có nghĩa khi đang có gói; không thì mặc định 30 ngày - như trang gói.
    if (!isDev) {
      if (state.tabKey === 'lifetime' && !lifetimePkg()) state.tabKey = TABS[0].key;   // admin đã tắt bán vĩnh viễn
      if (state.tabKey !== 'lifetime' && !TABS.some((tb) => tb.key === state.tabKey)) state.tabKey = tierFor(Number(state.qty) || 0);
      state.qty = pkgOrLife(state.tabKey).profiles;   // số hồ sơ gói theo bảng giá thật vừa nạp
      if (!(state.validity >= 0 && state.validity < validityCount())) state.validity = 0;   // bảng giá thật có thể ít kỳ hơn
      const active = !!(sub && sub.active) || subIsActive();
      if (!hasSavedValidity || state.validity < 0) state.validity = 0;
      else if (state.validity < 0 && !active) state.validity = 0;
    }
    ready = true;
    // Mã đã áp trước khi đi nạp tiền ⇒ kiểm lại với server (đúng đơn thì giữ, đơn đã đổi thì bỏ).
    let saved = null;
    try { saved = JSON.parse(sessionStorage.getItem(COUPON_KEY) || 'null'); } catch { saved = null; }
    // Đơn GÓI: mã gõ ở bước 1 luôn được kiểm (server tính theo đơn thật) - khách đã gõ thì phải có phản hồi hợp lệ / lỗi.
    const savedKind = (() => { try { return JSON.parse((saved && saved.sig) || '{}').kind; } catch { return null; } })();
    if (saved && saved.code && (saved.sig === orderSig() || (!isDev && savedKind === 'plan'))) await applyCoupon(saved.code);
    else { try { sessionStorage.removeItem(COUPON_KEY); } catch { /* bỏ qua */ } }
    if (document.body.contains(host)) paint();
  })();

  return {
    onShow: () => { mountBackLink(); loadPayConfig().then(() => paint()); },
    onHide: () => unmountBackLink(),
    destroy: () => unmountBackLink(),
  };
}
