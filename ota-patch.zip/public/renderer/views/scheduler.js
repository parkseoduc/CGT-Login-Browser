// "Lập lịch" (Scheduler) page - lists the schedules created by the Lên lịch
// dialog (window.__rpaSchedules). Each schedule is a self-rescheduling timer that
// fires its task ("Nhiệm vụ") on a chosen cadence (once / interval / daily /
// weekly / monthly). A schedule can be turned on/off (Trạng thái toggle → arms or
// disarms the timer), edited (re-opens the Lên lịch dialog pre-filled) or deleted.
//
// Timers are device-local (matching MKTLogin's note) - they live in the shared
// rpa-store module and survive view re-renders because they hang off window scope.
import { el, clear, toast, confirmDialog, customSelect, pageSizeSelect, gridEmpty, noScheduleSvg, openMenu } from '../ui.js';
import { icon } from '../icons.js';
import { t } from '../i18n.js';
import {
  schedules, getTask, removeSchedule, setEnabled, openScheduleDialog,
  fmtDateTime, freqLabel, onSchedulesChange, ready,
} from '../data/rpa-store.js';
import { notifyError } from '../data/errors.js';

export function render(ctx) {
  let filtered = [];
  let page = 0;
  let pageSize = 10;
  let searchText = '';
  const selected = new Set();

  const tbody = el('tbody');
  const emptyEl = gridEmpty('Chưa có lịch nào. Mở một nhiệm vụ và bấm "Lên lịch" để tạo lịch.', noScheduleSvg);
  const totalText = el('span.muted');
  const pageNumbers = el('div.page-nums');
  const selectAll = el('input', { type: 'checkbox' });

  const taskName = (id) => { const t = getTask(id); return t ? (t.name || '(không tên)') : '- (đã xóa)'; };

  function matches(s) {
    if (!searchText) return true;
    const hay = `${s.name} ${taskName(s.taskId)} ${s.note || ''} ${freqLabel(s.freq)}`.toLowerCase();
    return hay.includes(searchText);
  }
  function applyFilter() { filtered = schedules().filter(matches); page = 0; renderPage(); }
  // Refresh from the current schedule list WITHOUT resetting page/selection - used
  // when a schedule changes elsewhere (Lên lịch dialog from the Nhiệm vụ grid) or
  // when returning to this keep-alive view. renderPage() clamps an out-of-range page.
  function refresh() { filtered = schedules().filter(matches); renderPage(); }

  // Trạng thái cell: nhãn "Bật"/"Tắt" + công tắc (.switch) - cả hai luôn đồng bộ.
  // Bấm công tắc vừa arm/disarm timer, vừa cập nhật nhãn text.
  function statusCell(s) {
    const txt = el('span.sched-status-txt', { text: s.enabled ? 'Bật' : 'Tắt' });
    const sw = el('button.switch' + (s.enabled ? '.on' : ''), { type: 'button', title: s.enabled ? 'Đang bật' : 'Đang tắt' }, [el('span.knob')]);
    sw.addEventListener('click', async () => {
      const next = !sw.classList.contains('on');
      sw.classList.toggle('on', next);
      sw.title = next ? 'Đang bật' : 'Đang tắt';
      txt.textContent = next ? 'Bật' : 'Tắt';
      try {
        await setEnabled(s, next);
        toast(next ? 'Đã bật lịch' : 'Đã tắt lịch', 'ok');
      } catch (e) {
        // setEnabled đã hoàn tác trạng thái + phát sự kiện → hàng tự vẽ lại; chỉ cần
        // đồng bộ nhãn/công tắc tại chỗ phòng khi hàng không được vẽ lại kịp.
        sw.classList.toggle('on', s.enabled);
        sw.title = s.enabled ? 'Đang bật' : 'Đang tắt';
        txt.textContent = s.enabled ? 'Bật' : 'Tắt';
        notifyError(e, next ? 'Bật lịch thất bại' : 'Tắt lịch thất bại');
      }
    });
    return el('td.sched-status-cell', {}, [el('div.sched-status', {}, [txt, sw])]);
  }

  function dateCell(v, emptyText = '-') {
    const d = fmtDateTime(v);
    if (!d) return el('td.muted', { text: emptyText });
    return el('td', {}, [el('div.name-main', { text: d.date }), el('div.name-sub.muted', { text: d.time })]);
  }

  // Nhiệm vụ cell: huy hiệu icon + tên nhiệm vụ. Nhiệm vụ đã bị xóa hiện mờ.
  function taskCell(s) {
    const t = getTask(s.taskId);
    const name = taskName(s.taskId);
    return el('td', {}, [el('div.sched-taskcell' + (t ? '' : '.gone'), { title: name }, [
      el('span.sched-taskcell-ico', { html: icon('automation') }),
      el('span.sched-taskcell-name', { text: name }),
    ])]);
  }

  function renderPage() {
    const pages = Math.max(1, Math.ceil(filtered.length / pageSize));
    if (page >= pages) page = pages - 1;
    const slice = filtered.slice(page * pageSize, page * pageSize + pageSize);
    clear(tbody);
    slice.forEach((s, i) => {
      const cb = el('input', { type: 'checkbox', checked: selected.has(s.id),
        onchange: (e) => { e.target.checked ? selected.add(s.id) : selected.delete(s.id); syncSelAll(); } });
      const last = fmtDateTime(s.lastRun);

      const kebab = el('button.icon-btn.kebab', { html: icon('moreVertical'), title: 'Thêm',
        onclick: (e) => {
          e.stopPropagation();
          const task = getTask(s.taskId);
          openMenu(kebab, [
            { label: 'Chỉnh sửa', icon: 'edit', onClick: () => {
              if (!task) return toast('Nhiệm vụ của lịch này đã bị xóa', 'err');
              openScheduleDialog(task, s, () => applyFilter());
            } },
            { label: 'Xóa', icon: 'trash', danger: true, onClick: () => {
              confirmDialog({ title: 'Xóa lịch', danger: true, confirmLabel: 'Xóa',
                message: `${t('Xóa lịch "')}${s.name}"?`,
                onConfirm: async () => { selected.delete(s.id); try { await removeSchedule(s.id); applyFilter(); toast('Đã xóa lịch', 'ok'); } catch (e) { applyFilter(); notifyError(e, 'Xóa lịch thất bại'); } } });
            } },
          ]);
        } });

      tbody.appendChild(el('tr', {}, [
        el('td.col-check', {}, [cb]),
        el('td', { text: String(page * pageSize + i + 1) }),
        el('td', {}, [el('div.name-main', { text: s.name || '(không tên)' })]),
        taskCell(s),
        statusCell(s),
        dateCell(s.startAt),
        dateCell(s.endAt, '-'),
        el('td.muted', { text: last ? `${last.date} ${last.time}` : 'Chưa chạy' }),
        el('td.col-action', {}, [el('div.row-actions', {}, [kebab])]),
      ]));
    });
    const total = filtered.length;
    const from = total === 0 ? 0 : page * pageSize + 1;
    const to = Math.min((page + 1) * pageSize, total);
    totalText.textContent = total === 0 ? `0 ${t('trên')} 0` : `${from}-${to} ${t('trên')} ${total}`;
    emptyEl.style.display = total === 0 ? 'flex' : 'none';
    renderPager(pages);
    syncSelAll();
  }

  function syncSelAll() {
    const slice = filtered.slice(page * pageSize, page * pageSize + pageSize);
    selectAll.checked = slice.length > 0 && slice.every((s) => selected.has(s.id));
  }

  function renderPager(pages) {
    clear(pageNumbers);
    for (let i = 0; i < pages; i++) {
      if (pages > 7 && i > 1 && i < pages - 2 && Math.abs(i - page) > 1) {
        if (i === 2 || i === pages - 3) pageNumbers.appendChild(el('span.muted', { text: '…' }));
        continue;
      }
      pageNumbers.appendChild(el('button.page-num' + (i === page ? '.active' : ''), { text: String(i + 1), onclick: () => { page = i; renderPage(); } }));
    }
  }

  async function load() {
    // Chờ lịch tải xong từ server (workspace hiện hành) rồi mới lọc/hiển thị.
    try { await ready(); } catch { /* offline → cache rỗng */ }
    selected.clear();
    applyFilter();
  }

  // ---- toolbar
  const searchInput = el('input.search-input', { placeholder: 'Tìm kiếm lịch...',
    oninput: (e) => { searchText = e.target.value.trim().toLowerCase(); applyFilter(); } });
  const searchBar = el('div.searchbar', {}, [el('span.ico', { html: icon('search') }), searchInput]);

  const toolbar = el('div.toolbar.trash-bar', {}, [
    searchBar,
    el('button.icon-btn.tr-del', { html: icon('trash'), title: 'Xóa các lịch đã chọn', onclick: () => {
      if (!selected.size) return toast('Chưa chọn lịch nào');
      confirmDialog({ title: 'Xóa lịch', danger: true, confirmLabel: 'Xóa',
        message: `${t('Xóa')} ${selected.size} ${t('lịch đã chọn?')}`,
        onConfirm: async () => { const ids = [...selected]; selected.clear(); try { for (const id of ids) await removeSchedule(id); applyFilter(); toast('Đã xóa lịch', 'ok'); } catch (e) { applyFilter(); notifyError(e, 'Xóa lịch thất bại'); } } });
    } }),
    el('span.spacer'),
    el('button.icon-btn.reload', { html: icon('sync'), title: 'Làm mới', onclick: load }),
  ]);

  selectAll.onchange = (e) => {
    const slice = filtered.slice(page * pageSize, page * pageSize + pageSize);
    slice.forEach((s) => e.target.checked ? selected.add(s.id) : selected.delete(s.id));
    renderPage();
  };

  const sizeSel = pageSizeSelect([10, 25, 50, 100], { value: pageSize, onChange: (v) => { pageSize = v; page = 0; renderPage(); } });

  const th = (label) => el('th', {}, [el('span', { text: label })]);
  const table = el('table.grid.profiles-grid.sched-grid', {}, [
    el('thead', {}, [el('tr', {}, [
      el('th.col-check', {}, [selectAll]),
      th('STT'), th('Tên lịch'), th('Nhiệm vụ'),
      th('Trạng thái'), th('Bắt đầu'), th('Kết thúc'), th('Lần chạy cuối'),
      el('th.col-action', {}, [el('span', { text: 'Hành động' })]),
    ])]),
    tbody,
  ]);

  const pager = el('div.pager', {}, [
    el('span.muted', { text: 'Số dòng mỗi trang:' }),
    sizeSel,
    totalText,
    el('button.icon-btn', { html: icon('chevron'), style: { transform: 'rotate(180deg)' }, onclick: () => { if (page > 0) { page--; renderPage(); } } }),
    pageNumbers,
    el('button.icon-btn', { html: icon('chevron'), onclick: () => { const pages = Math.ceil(filtered.length / pageSize); if (page < pages - 1) { page++; renderPage(); } } }),
  ]);

  const pageEl = el('div.page', {}, [
    toolbar,
    el('div.grid-area', {}, [el('div.grid-card', {}, [table, emptyEl]), pager]),
  ]);
  ctx.container.appendChild(pageEl);
  load();

  // Live-refresh the grid the moment a schedule is created/edited/deleted from
  // anywhere (e.g. the "Lên lịch" dialog opened on the Nhiệm vụ grid) - no Ctrl+R.
  const offSched = onSchedulesChange(() => refresh());

  return {
    // Keep-alive route: also refresh when navigating back to this page.
    onShow() { refresh(); },
    destroy() { offSched(); },
  };
}
