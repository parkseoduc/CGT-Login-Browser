// Port of TrashView.xaml - soft-deleted profiles with restore / permanent
// delete. The grid mirrors the "Hồ sơ" (Profiles) datagrid look (grid-card +
// profiles-grid + sortable headers + matching pager). The toolbar has a
// deletion-date range picker that opens a dual-month calendar dropdown (quick
// presets + range selection), a group dropdown, a search box (filter icon
// inside - replaces the old "Lọc" button), "Khôi phục" / "Xóa bỏ" actions and a
// right-aligned refresh button. Columns: Số hồ sơ / Profile / ID hồ sơ / Ghi
// chú / Tags / Người thao tác / Thời gian xóa.
import { el, clear, toast, confirmDialog, customSelect, pageSizeSelect, gridEmpty, trashEmptySvg, withSpin } from '../ui.js';
import { icon } from '../icons.js';
import { t, tf } from '../i18n.js';
import { remote } from '../data/remote-ds.js';
import { notifyError } from '../data/errors.js';
import { polyBrowserVersion, polyBrowserName, polyBrowserIcon } from '../data/browser-badge.js';

const OS_ICON = { Windows: 'windows', macOS: 'apple', Linux: 'linux', Android: 'android', iOS: 'ios' };
// Badge trình duyệt (icon + major): dùng CHUNG module với profiles.js - xem
// data/browser-badge.js. Trước đây mỗi lưới chép một bản nên dễ lệch nhau.
const TAG_COLOR_COUNT = 6;
function tagColorClass(name) {
  let h = 0;
  const s = String(name || '');
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return 'tag-c' + (h % TAG_COLOR_COUNT);
}
function parseTags(v) {
  if (Array.isArray(v)) return v.filter(Boolean);
  return String(v || '').split(',').map((t) => t.trim()).filter(Boolean);
}

// ---- date helpers (local, day-granular) ----
const DOW = ['CN', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7'];
const pad = (n) => String(n).padStart(2, '0');
const fmtIso = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const parseIso = (s) => { const [y, m, d] = String(s).split('-').map(Number); return new Date(y, m - 1, d); };
const startOfMonth = (d) => new Date(d.getFullYear(), d.getMonth(), 1);
const addMonths = (d, n) => new Date(d.getFullYear(), d.getMonth() + n, 1);
const addDays = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
const sameDay = (a, b) => !!a && !!b && a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
const isoDay = (v) => String(v || '').slice(0, 10);
// "Tự động xóa": ngày server dọn + số ngày còn lại (làm tròn lên: còn 0.3 ngày vẫn là "còn 1 ngày"; quá mốc ⇒ "sắp xóa").
function purgeText(p) {
  if (!p.purgeAtIso) return p.purgeAt || '-';
  const left = Math.ceil((new Date(p.purgeAtIso).getTime() - Date.now()) / 86400000);
  return `${p.purgeAt} (${left > 0 ? tf('còn {0} ngày', left) : t('sắp xóa')})`;
}

export function render(ctx) {
  let all = [];        // full deleted list
  let filtered = [];
  let groups = [];
  let page = 0;
  let pageSize = 10;
  let dateFrom = '';   // 'YYYY-MM-DD'
  let dateTo = '';
  let groupFilter = null; // null = all groups, '' = ungrouped, else group id
  let searchText = '';
  let advFilter = null; // { field: 'profileId'|'group'|'tags', op: 'any'|'none', values: [] }
  let refreshDateLabel = null; // set by buildDatePicker, lets load() show the default range
  const selected = new Set();

  const tbody = el('tbody');
  const emptyEl = gridEmpty('Thùng rác trống', trashEmptySvg);
  const totalText = el('span.muted');
  const pageNumbers = el('div.page-nums');
  const selectAll = el('input', { type: 'checkbox' });

  function matches(p) {
    const day = isoDay(p.deletedAtIso || p.deletedAt);
    if (dateFrom && day && day < dateFrom) return false;
    if (dateTo && day && day > dateTo) return false;
    if (groupFilter === '') { if (p.groupId) return false; }
    else if (groupFilter != null) { if (p.groupId !== groupFilter) return false; }
    if (searchText) {
      const hay = `${p.name} ${p.profileId} ${p.note} ${p.tags} ${p.group} ${p.operator}`.toLowerCase();
      if (!hay.includes(searchText)) return false;
    }
    if (advFilter && advFilter.values.length) {
      const vals = advFilter.values.map((v) => v.toLowerCase());
      let hay;
      if (advFilter.field === 'group') hay = [String(p.group || '').toLowerCase()];
      else if (advFilter.field === 'tags') hay = parseTags(p.tags).map((t) => t.toLowerCase());
      else hay = [String(p.profileId || '').toLowerCase()];
      const hit = vals.some((v) => hay.some((h) => h === v || h.includes(v)));
      if (advFilter.op === 'any' && !hit) return false;
      if (advFilter.op === 'none' && hit) return false;
    }
    return true;
  }

  function applyFilter() { filtered = all.filter(matches); page = 0; renderPage(); }

  // Latest profile-creation date across the trash list (default range start).
  function latestCreateDate() {
    let max = '';
    for (const p of all) { const s = isoDay(p.createdAtIso || p.createdAt); if (s && s > max) max = s; }
    return max ? parseIso(max) : new Date();
  }

  // Oldest deletion date across the trash list (used by the "clear range" button).
  function oldestDeleteDate() {
    let min = '';
    for (const p of all) { const s = isoDay(p.deletedAtIso || p.deletedAt); if (s && (!min || s < min)) min = s; }
    return min ? parseIso(min) : new Date();
  }

  function renderPage() {
    const pages = Math.max(1, Math.ceil(filtered.length / pageSize));
    if (page >= pages) page = pages - 1;
    const slice = filtered.slice(page * pageSize, page * pageSize + pageSize);
    clear(tbody);
    slice.forEach((p, i) => {
      const cb = el('input', { type: 'checkbox', checked: selected.has(p.id),
        onchange: (e) => { e.target.checked ? selected.add(p.id) : selected.delete(p.id); syncSelAll(); } });
      const tags = parseTags(p.tags);
      // Combined "Profile" cell - same layout as the Hồ sơ datagrid: OS badge +
      // CGTBrowser mark + name above a group sub-line.
      const profileCell = el('td', {}, [el('div.name-cell', {}, [
        el('span.os-mark', { title: p.os || 'Windows', html: icon(OS_ICON[p.os] || 'windows') }),
        el('div.poly-mark', { title: polyBrowserName(p) + ' ' + polyBrowserVersion(p) }, [
          el('span.poly-ver', { text: polyBrowserVersion(p) }),
          el('img.poly-ico', { src: polyBrowserIcon(p), alt: polyBrowserName(p) }),
        ]),
        el('div', {}, [
          el('div.name-main', { text: p.name }),
          // Dòng name-id ẨN: trang "Hồ sơ" có dòng short-ID dưới tên (luôn hiện) nên
          // row của nó cao hơn 1 dòng. Thùng rác đã có cột "ID hồ sơ" riêng nên không
          // cần hiện lại, chỉ CHỪA đúng chiều cao dòng đó để row cao BẰNG trang Hồ sơ.
          el('div.name-id', { text: '\u00A0', style: { visibility: 'hidden' } }),
          el('div.name-sub.muted', { html: `${icon('folder')}<span>${p.group || 'Không có nhóm'}</span>` }),
        ]),
      ])]);
      tbody.appendChild(el('tr', {}, [
        el('td.col-check', {}, [cb]),
        el('td', { text: String(page * pageSize + i + 1) }),
        profileCell,
        el('td.muted', { text: p.profileId }),
        el('td', {}, [el('span.muted', { text: p.note || '' })]),
        el('td', {}, [el('div.cell-tags', {}, tags.map((t) => el('span.chip.tag-chip.' + tagColorClass(t), { text: t })))]),
        el('td', { text: p.operator || '' }),
        el('td.muted', { text: p.deletedAt || '-' }),
        // Server tự xoá vĩnh viễn sau 30 ngày (trash-retention.js, dọn mỗi 6 giờ) - cho người dùng thấy mốc + số ngày còn lại.
        el('td.muted', { text: purgeText(p) }),
      ]));
    });
    const total = filtered.length;
    const from = total === 0 ? 0 : page * pageSize + 1;
    const to = Math.min((page + 1) * pageSize, total);
    totalText.textContent = total === 0 ? `0 ${t('trên')} 0` : `${from}-${to} ${t('trên')} ${total}`;
    emptyEl.style.display = total === 0 ? 'flex' : 'none';
    renderPager(pages);
    syncSelAll();
  }

  function syncSelAll() {
    const slice = filtered.slice(page * pageSize, page * pageSize + pageSize);
    selectAll.checked = slice.length > 0 && slice.every((p) => selected.has(p.id));
  }

  function renderPager(pages) {
    clear(pageNumbers);
    for (let i = 0; i < pages; i++) {
      if (pages > 7 && i > 1 && i < pages - 2 && Math.abs(i - page) > 1) {
        if (i === 2 || i === pages - 3) pageNumbers.appendChild(el('span.muted', { text: '…' }));
        continue;
      }
      pageNumbers.appendChild(el('button.page-num' + (i === page ? '.active' : ''), { text: String(i + 1), onclick: () => { page = i; renderPage(); } }));
    }
  }

  async function load() {
    [all, groups] = await Promise.all([
      remote.trash.list(),
      remote.groups.list().catch(() => []),
    ]);
    selected.clear();
    // Default range shown on the trigger (like the reference): latest profile
    // creation date → today. Committed so the date label reads as a range.
    if (!dateFrom && !dateTo) {
      dateFrom = fmtIso(latestCreateDate());
      dateTo = fmtIso(new Date());
    }
    if (refreshDateLabel) refreshDateLabel();
    renderGroupFilter();
    applyFilter();
  }

  // ---- deletion-date range picker (dual-month calendar dropdown) ----
  function buildDatePicker() {
    let selStart = null;
    let selEnd = null;
    let viewMonth = startOfMonth(new Date());
    let hoverDay = null;
    let pop = null;
    let dayCells = [];

    const label = el('span.dr-label');
    const clearBtn = el('button.dr-clear', { type: 'button', title: 'Xóa khoảng ngày',
      html: icon('close'), onclick: (e) => {
        // "Clear" resets to the full window: oldest deletion date → today.
        e.stopPropagation();
        const lo = oldestDeleteDate(), hi = new Date();
        selStart = lo; selEnd = hi; dateFrom = fmtIso(lo); dateTo = fmtIso(hi);
        refreshLabel(); applyFilter();
      } });
    const trigger = el('button.date-range', { type: 'button' }, [
      el('span.dr-ico', { html: icon('calendar') }), label, clearBtn,
    ]);

    function refreshLabel() {
      if (dateFrom && dateTo) { label.textContent = `${dateFrom} → ${dateTo}`; clearBtn.style.display = 'grid'; }
      else { label.textContent = 'Thời gian xóa'; clearBtn.style.display = 'none'; }
    }

    function commit(a, b) {
      const lo = a <= b ? a : b, hi = a <= b ? b : a;
      selStart = lo; selEnd = hi; dateFrom = fmtIso(lo); dateTo = fmtIso(hi);
      refreshLabel(); applyFilter(); close();
    }
    function onDay(d) {
      if (!selStart || (selStart && selEnd)) { selStart = d; selEnd = null; hoverDay = null; applyDayStates(); }
      else { commit(selStart, d); }
    }
    function preset(fromD, toD) { commit(fromD, toD); }

    function applyDayStates() {
      let lo = selStart, hi = selEnd;
      if (selStart && !selEnd && hoverDay) { lo = selStart <= hoverDay ? selStart : hoverDay; hi = selStart <= hoverDay ? hoverDay : selStart; }
      const today = new Date();
      dayCells.forEach(({ btn, date, inMonth }) => {
        btn.className = 'dr-day';
        if (!inMonth) btn.classList.add('muted');
        if (sameDay(date, today)) btn.classList.add('today');
        if (lo && hi && date > lo && date < hi) btn.classList.add('in-range');
        if (lo && sameDay(date, lo)) btn.classList.add('range-start');
        if (hi && sameDay(date, hi)) btn.classList.add('range-end');
      });
    }

    function monthEl(base, side) {
      const title = tf('{0} Năm Tháng {1}', base.getFullYear(), base.getMonth() + 1);
      const head = el('div.dr-cal-head');
      if (side === 'left') {
        head.appendChild(el('button.dr-nav.n1', { type: 'button', text: '«', title: 'Năm trước', onclick: () => { viewMonth = addMonths(viewMonth, -12); renderCals(); } }));
        head.appendChild(el('button.dr-nav.n2', { type: 'button', text: '‹', title: 'Tháng trước', onclick: () => { viewMonth = addMonths(viewMonth, -1); renderCals(); } }));
      } else {
        head.appendChild(el('button.dr-nav.x1', { type: 'button', text: '›', title: 'Tháng sau', onclick: () => { viewMonth = addMonths(viewMonth, 1); renderCals(); } }));
        head.appendChild(el('button.dr-nav.x2', { type: 'button', text: '»', title: 'Năm sau', onclick: () => { viewMonth = addMonths(viewMonth, 12); renderCals(); } }));
      }
      head.appendChild(el('span.dr-title', { text: title }));

      const grid = el('div.dr-grid');
      DOW.forEach((w) => grid.appendChild(el('span.dr-dow', { text: w })));
      // start from the Sunday on/before the 1st
      const first = startOfMonth(base);
      const start = addDays(first, -first.getDay());
      for (let i = 0; i < 42; i++) {
        const date = addDays(start, i);
        const inMonth = date.getMonth() === base.getMonth();
        const btn = el('button.dr-day', { type: 'button', text: String(date.getDate()) });
        btn.onclick = () => onDay(date);
        btn.onmouseenter = () => { if (selStart && !selEnd) { hoverDay = date; applyDayStates(); } };
        grid.appendChild(btn);
        dayCells.push({ btn, date, inMonth });
      }
      return el('div.dr-cal', {}, [head, grid]);
    }

    const calsWrap = el('div.dr-cals');
    function renderCals() {
      dayCells = [];
      clear(calsWrap);
      calsWrap.appendChild(monthEl(viewMonth, 'left'));
      calsWrap.appendChild(monthEl(addMonths(viewMonth, 1), 'right'));
      applyDayStates();
    }

    const onDoc = (e) => { if (pop && !pop.contains(e.target) && !trigger.contains(e.target)) close(); };
    const onReposition = () => { if (pop) close(); };
    function place() {
      const r = trigger.getBoundingClientRect();
      pop.style.left = Math.min(r.left, window.innerWidth - pop.offsetWidth - 10) + 'px';
      if ((window.innerHeight - r.bottom) < pop.offsetHeight + 10) {
        pop.style.top = 'auto'; pop.style.bottom = (window.innerHeight - r.top + 6) + 'px';
      } else { pop.style.bottom = 'auto'; pop.style.top = (r.bottom + 6) + 'px'; }
    }
    function open() {
      const today = new Date();
      // Default shown range when nothing is chosen yet: latest profile creation
      // date → today (highlighted in the calendar, not yet committed as a filter).
      if (dateFrom && dateTo) { selStart = parseIso(dateFrom); selEnd = parseIso(dateTo); }
      else { selStart = latestCreateDate(); selEnd = today; }
      hoverDay = null;
      viewMonth = startOfMonth(selStart);
      pop = el('div.dr-pop', {}, [
        el('div.dr-presets', {}, [
          el('button.dr-preset', { type: 'button', text: 'Hôm nay', onclick: () => preset(today, today) }),
          el('button.dr-preset', { type: 'button', text: 'Hôm qua', onclick: () => { const y = addDays(today, -1); preset(y, y); } }),
          el('button.dr-preset', { type: 'button', text: '7 ngày trước', onclick: () => preset(addDays(today, -6), today) }),
          el('button.dr-preset', { type: 'button', text: '30 ngày trước', onclick: () => preset(addDays(today, -29), today) }),
        ]),
        calsWrap,
      ]);
      pop.onmouseleave = () => { if (selStart && !selEnd) { hoverDay = null; applyDayStates(); } };
      document.body.appendChild(pop);
      trigger.classList.add('open');
      renderCals();
      place();
      document.addEventListener('mousedown', onDoc);
      window.addEventListener('scroll', onReposition, true);
      window.addEventListener('resize', onReposition);
    }
    function close() {
      if (pop && pop.parentNode) pop.parentNode.removeChild(pop);
      pop = null;
      trigger.classList.remove('open');
      document.removeEventListener('mousedown', onDoc);
      window.removeEventListener('scroll', onReposition, true);
      window.removeEventListener('resize', onReposition);
    }
    trigger.onclick = () => { pop ? close() : open(); };
    refreshDateLabel = refreshLabel;
    refreshLabel();
    return trigger;
  }

  // ---- group dropdown
  const groupFilterWrap = el('div.group-filter');
  function renderGroupFilter() {
    clear(groupFilterWrap);
    const opts = [
      { value: '__all__', label: 'Tất cả các nhóm' },
      { value: '__ungrouped__', label: 'Chưa chia nhóm' },
      ...groups.map((g) => ({ value: g.id, label: g.name })),
    ];
    const cur = groupFilter == null ? '__all__' : groupFilter === '' ? '__ungrouped__' : groupFilter;
    groupFilterWrap.appendChild(customSelect(opts, {
      value: cur, width: 190, height: 41,
      onChange: (v) => { groupFilter = v === '__all__' ? null : v === '__ungrouped__' ? '' : v; },
    }));
  }

  // ---- advanced filter popover (opened by the filter icon) - single condition:
  // field (Profile ID / Group / Tags) · operator (là bất kỳ / không phải) · values.
  // Group/Tags use an editable combobox (type free text AND pick from existing).
  const FILTER_FIELDS = [
    { value: 'profileId', label: 'Profile ID' },
    { value: 'group', label: 'Group' },
    { value: 'tags', label: 'Tags' },
  ];
  const FILTER_OPS = [
    { value: 'any', label: 'là bất kỳ' },
    { value: 'none', label: 'không phải bất kỳ' },
  ];
  const placeholderFor = (f) => f === 'group' ? 'Chọn nhóm'
    : f === 'tags' ? 'Chọn thẻ'
    : 'Các ID cách nhau bởi dấu phẩy, khoảng…';
  const groupOptions = () => ['Không có nhóm', ...groups.map((g) => g.name).filter(Boolean)];
  const tagOptions = () => {
    const set = new Set();
    all.forEach((p) => parseTags(p.tags).forEach((t) => set.add(t)));
    return [...set].sort((a, b) => a.localeCompare(b));
  };

  // Editable combobox: a text input (multi-value, comma-separated) plus a portaled
  // dropdown of existing options. Clicking an option fills the current token.
  function editableCombo(options, opt) {
    const input = el('input.input.tr-combo-input', { value: opt.value || '', placeholder: opt.placeholder || '' });
    const chev = el('span.tr-combo-chev', { html: icon('chevronDown') });
    const wrap = el('div.tr-combo', {}, [input, chev]);
    let menu = null;
    const tokens = () => input.value.split(',').map((s) => s.trim()).filter(Boolean);
    const lastToken = () => { const p = input.value.split(','); return p[p.length - 1].trim().toLowerCase(); };
    function pick(o) {
      const parts = input.value.split(',');
      parts[parts.length - 1] = ' ' + o;
      input.value = parts.map((s) => s.trim()).filter(Boolean).join(', ') + ', ';
      if (opt.onChange) opt.onChange(input.value);
      renderMenu(); input.focus();
    }
    function renderMenu() {
      if (!menu) return;
      clear(menu);
      const q = lastToken();
      const chosen = new Set(tokens().map((t) => t.toLowerCase()));
      const rows = options.filter((o) => !q || o.toLowerCase().includes(q));
      if (!rows.length) { menu.appendChild(el('div.tr-combo-empty.muted', { text: 'Không có lựa chọn' })); return; }
      rows.forEach((o) => {
        const on = chosen.has(o.toLowerCase());
        menu.appendChild(el('div.tr-combo-opt' + (on ? '.sel' : ''), {
          onmousedown: (e) => { e.preventDefault(); pick(o); },
        }, [el('span.lbl', { text: o }), on ? el('span.ck', { html: icon('check') }) : null]));
      });
    }
    function place() {
      const r = wrap.getBoundingClientRect();
      menu.style.left = r.left + 'px';
      menu.style.top = (r.bottom + 6) + 'px';
      menu.style.minWidth = r.width + 'px';
    }
    const onDoc = (e) => { if (menu && !menu.contains(e.target) && !wrap.contains(e.target)) closeMenu(); };
    function openMenuPop() {
      if (menu) return;
      menu = el('div.tr-combo-menu');
      document.body.appendChild(menu);
      renderMenu(); place();
      document.addEventListener('mousedown', onDoc, true);
      window.addEventListener('resize', closeMenu);
    }
    function closeMenu() {
      if (menu && menu.parentNode) menu.parentNode.removeChild(menu);
      menu = null;
      document.removeEventListener('mousedown', onDoc, true);
      window.removeEventListener('resize', closeMenu);
    }
    input.onfocus = openMenuPop;
    input.oninput = () => { if (opt.onChange) opt.onChange(input.value); openMenuPop(); renderMenu(); };
    chev.onclick = () => { if (menu) { closeMenu(); } else { input.focus(); openMenuPop(); } };
    return { el: wrap, getValue: () => input.value, close: closeMenu };
  }

  let filterPop = null;
  const scopeBtn = el('button.icon-btn.scope-btn', { type: 'button', html: icon('filter'), title: 'Tìm kiếm nâng cao' });

  function onFilterDoc(e) {
    if (!filterPop) return;
    if (filterPop.contains(e.target) || scopeBtn.contains(e.target)) return;
    if (e.target.closest && e.target.closest('.pc-select-menu, .tr-combo-menu')) return; // portaled menus
    closeFilterPop();
  }
  function closeFilterPop() {
    if (filterPop && filterPop.parentNode) filterPop.parentNode.removeChild(filterPop);
    filterPop = null;
    document.removeEventListener('mousedown', onFilterDoc, true);
    window.removeEventListener('resize', closeFilterPop);
  }
  function openFilterPop() {
    if (filterPop) { closeFilterPop(); return; }
    const cur = advFilter || { field: 'profileId', op: 'any', values: [] };
    let field = cur.field, op = cur.op;
    let textValue = (cur.values || []).join(', ');
    let activeCombo = null;
    const valueHost = el('div.tr-value-host');
    let getValue = () => textValue;

    function renderValueControl() {
      if (activeCombo) { activeCombo.close(); activeCombo = null; }
      clear(valueHost);
      if (field === 'group' || field === 'tags') {
        const combo = editableCombo(field === 'group' ? groupOptions() : tagOptions(),
          { value: textValue, placeholder: placeholderFor(field), onChange: (v) => { textValue = v; } });
        activeCombo = combo; getValue = () => combo.getValue();
        valueHost.appendChild(combo.el);
      } else {
        const input = el('input.input.tr-filter-value', { value: textValue, placeholder: placeholderFor(field),
          oninput: (e) => { textValue = e.target.value; } });
        getValue = () => input.value;
        valueHost.appendChild(input);
      }
    }
    renderValueControl();

    const fieldSel = customSelect(FILTER_FIELDS, { value: field, width: 150, height: 40, className: 'adv-select',
      onChange: (v) => { textValue = getValue(); field = v; renderValueControl(); } });
    const opSel = customSelect(FILTER_OPS, { value: op, width: 150, height: 40, className: 'adv-select',
      onChange: (v) => { op = v; } });
    filterPop = el('div.tr-filter-pop', {}, [
      el('div.tr-filter-row', {}, [fieldSel, opSel, valueHost]),
      el('div.tr-filter-foot', {}, [
        el('button.btn.subtle.pc-shuffle.tr-go', { type: 'button', html: `${icon('search')}<span>Tìm kiếm</span>`, onclick: () => {
          const values = String(getValue() || '').split(/[,\s]+/).map((s) => s.trim()).filter(Boolean);
          advFilter = values.length ? { field, op, values } : null;
          scopeBtn.classList.toggle('active', !!advFilter);
          closeFilterPop(); applyFilter();
        } }),
        // Bỏ .subtle: "Hủy" là nút phủ định nên phải theo quy ước chung (không nền, không viền,
        // hover ăn màu brand) - xem khối ":is(.modal-foot, ...)" trong app.css.
        el('button.btn.tr-cancel', { type: 'button', text: 'Hủy', onclick: closeFilterPop }),
      ]),
    ]);
    document.body.appendChild(filterPop);
    const r = searchBar.getBoundingClientRect();
    filterPop.style.position = 'fixed';
    filterPop.style.top = (r.bottom + 6) + 'px';
    filterPop.style.left = Math.min(r.left, window.innerWidth - filterPop.offsetWidth - 12) + 'px';
    setTimeout(() => document.addEventListener('mousedown', onFilterDoc, true), 0);
    window.addEventListener('resize', closeFilterPop);
  }
  scopeBtn.onclick = openFilterPop;

  // ---- search box (same look as the Hồ sơ search field: round icon + input,
  // plus a filter icon button on the right that opens the filter popover)
  const searchInput = el('input.search-input', { placeholder: 'Tìm kiếm...',
    oninput: (e) => { searchText = e.target.value.trim().toLowerCase(); applyFilter(); } });
  const searchBar = el('div.searchbar', {}, [
    el('span.ico', { html: icon('search') }),
    searchInput,
    scopeBtn,
  ]);

  // ---- toolbar - single row: search · group · date · restore · delete · refresh
  const toolbar = el('div.toolbar.trash-bar', {}, [
    searchBar,
    groupFilterWrap,
    buildDatePicker(),
    // Restore: brand 3-colour signature gradient (#88C4FF → #6AA9FF → #1D7BD8)
    el('button.btn.primary', { html: `${icon('restore')}<span>Khôi phục</span>`, onclick: (e) => {
      if (!selected.size) return toast('Chưa chọn hồ sơ nào');
      return withSpin(e.currentTarget, async () => {
        try {
          await remote.trash.restore([...selected]); toast('Đã khôi phục', 'ok'); await load();
          window.__vtApp && window.__vtApp.refreshProfileCount();
        } catch (err) { await load(); notifyError(err, 'Khôi phục hồ sơ thất bại'); }
      });
    } }),
    // Delete: bordered icon chip wrapping the trash glyph (same affordance as the
    // "Hồ sơ" bulk-delete sb-trash button) - red glyph, red border on hover.
    el('button.icon-btn.tr-del', { html: icon('trash'), title: 'Xóa bỏ', onclick: () => {
      if (!selected.size) return toast('Chưa chọn hồ sơ nào');
      confirmDialog({ title: 'Xóa vĩnh viễn', danger: true, confirmLabel: 'Xóa',
        message: `${t('Xóa vĩnh viễn')} ${selected.size} ${t('hồ sơ? Không thể khôi phục.')}`,
        onConfirm: async () => { try { await remote.trash.hardDelete([...selected]); toast('Đã xóa vĩnh viễn', 'ok'); await load(); } catch (err) { await load(); notifyError(err, 'Xóa vĩnh viễn thất bại'); } } });
    } }),
    el('span.spacer'),
    el('button.icon-btn.reload', { html: icon('sync'), title: 'Làm mới', onclick: (e) => withSpin(e.currentTarget, load) }),
  ]);

  selectAll.onchange = (e) => {
    const slice = filtered.slice(page * pageSize, page * pageSize + pageSize);
    slice.forEach((p) => e.target.checked ? selected.add(p.id) : selected.delete(p.id));
    renderPage();
  };

  const sizeSel = pageSizeSelect([10, 25, 50, 100], { value: pageSize, onChange: (v) => { pageSize = v; page = 0; renderPage(); } });

  // sortable column header (label + flip arrow) - same affordance as the Profiles grid
  const sortTh = (label) => el('th.sortable', {}, [el('span.th-inner', {}, [
    el('span', { text: label }),
    el('button.sort-arrow', { html: icon('chevronDown'), title: 'Sắp xếp', onclick: (e) => { e.stopPropagation(); e.currentTarget.classList.toggle('up'); } }),
  ])]);

  const table = el('table.grid.profiles-grid', {}, [
    el('thead', {}, [el('tr', {}, [
      el('th.col-check', {}, [selectAll]),
      sortTh('Số hồ sơ'), sortTh('Profile'), sortTh('ID hồ sơ'),
      sortTh('Ghi chú'), sortTh('Tags'),
      sortTh('Người thao tác'), sortTh('Thời gian xóa'), sortTh('Tự động xóa'),
    ])]),
    tbody,
  ]);

  const pager = el('div.pager', {}, [
    el('span.muted', { text: 'Số dòng mỗi trang:' }),
    sizeSel,
    totalText,
    el('button.icon-btn', { html: icon('chevron'), style: { transform: 'rotate(180deg)' }, onclick: () => { if (page > 0) { page--; renderPage(); } } }),
    pageNumbers,
    el('button.icon-btn', { html: icon('chevron'), onclick: () => { const pages = Math.ceil(filtered.length / pageSize); if (page < pages - 1) { page++; renderPage(); } } }),
  ]);

  const pageEl = el('div.page', {}, [
    toolbar,
    el('div.grid-area', {}, [el('div.grid-card', {}, [table, emptyEl]), pager]),
  ]);
  ctx.container.appendChild(pageEl);
  load();
  // Route keep-alive: DOM được giữ lại khi rời trang, nên phải nạp lại danh sách
  // mỗi lần quay vào - nếu không, hồ sơ vừa xóa mềm sẽ không hiện ra cho tới khi
  // người dùng làm mới thủ công.
  return { onShow: () => { load(); } };
}
