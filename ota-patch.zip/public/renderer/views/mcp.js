// ─────────────────────────────────────────────────────────────────────────────
// Trang "MCP" — bảng điều khiển cho máy chủ MCP (Model Context Protocol) ở
// src/main/mcp.js. Trang này CHỈ ĐỌC: nó lấy trạng thái qua vt.mcp.status() rồi
// vẽ ra, không có kênh ghi nào (user bỏ công tắc từng tính năng - xem dưới).
//
// Bố cục theo yêu cầu (user 2026-10-10): "cho boder lớn bọc bên ngoài
// (boderbush làm bóng, boderthink=0)" - tức một KHUNG LỚN bọc toàn bộ nội dung,
// viền DÀY 0 (không có đường kẻ) và phần "viền" đó được vẽ bằng BÓNG ĐỔ. Lớp
// `.mcp-frame` trong app.css làm đúng vậy: `border: 0` + `box-shadow`.
//
// ── Vì sao KHÔNG chặn cả trang với gói Free ──────────────────────────────────
// Tiền lệ trang "Tài liệu API" (user chốt 2026-09-27): trang thì mở cho mọi gói,
// chỉ LỜI GỌI THẬT mới trả 403. Làm y vậy ở đây - chặn ở main (mcp.js gác
// planGate.hasFeature('api') ngay trên đường HTTP), còn trang vẫn vào được để
// khách gói Free biết tính năng này có và cần gói nào. Chặn ở renderer là vô
// nghĩa về an ninh: trợ lý AI nói chuyện TRỰC TIẾP với cổng 51001, không đi qua UI.
// Nhưng vẫn phải NÓI RÕ trạng thái gói: không nói thì người dùng ngồi chờ mãi
// không hiểu vì sao trợ lý báo lỗi. Nên có đúng MỘT dải thông báo (chỉ hiện khi
// gói không hỗ trợ), không phải dải quảng cáo thường trú.
//
// ── "Tính năng cho phép" là CÂY CHỈ ĐỂ XEM ───────────────────────────────────
// User chốt 2026-10-10: "bỏ tolge chọn từng cái, mặc định được áp dụng tất cả.
// sửa lại thành dạng tree (click vào là show ra. bỏ các icon)". Nên khối này chỉ
// liệt kê bốn việc, bấm một dòng thì mở phần mô tả. Không còn `setCaps` ở bất kỳ
// tầng nào (preload/ipc/main đều đã bỏ) - giữ một phép gác mà không còn UI bật
// lại được là cái bẫy IM LẶNG: một giá trị `false` cũ trong settings.json sẽ tắt
// vĩnh viễn một công cụ và không ai hiểu tại sao trợ lý "không thấy" nó.
// Mũi tên mở/đóng vẽ bằng CSS (border tam giác), KHÔNG dùng SVG - "bỏ các icon".
// ─────────────────────────────────────────────────────────────────────────────
import { el, clear, toast } from '../ui.js';
import { icon } from '../icons.js';
import { t } from '../i18n.js';

// Khối JSON cấu hình KHÔNG dựng ở đây nữa - `st.configJson` do main gửi sang
// (xem src/main/mcp.js → configJson). Lý do: khối đó khai một mục stdio trỏ vào
// đường dẫn TỆP CẦU NỐI mà main vừa chép ra userData; chỉ main biết đường dẫn ấy.
// Tự ghép lại chuỗi ở renderer là mở đường cho hai bên lệch nhau mà chẳng có gì
// báo - người dùng dán một khối trỏ vào tệp không tồn tại, rồi trợ lý im lặng
// không thấy công cụ nào.

// `msg` là CÂU TRỌN VẸN đã dịch được ('Đã sao chép địa chỉ'), KHÔNG nối
// 'Đã sao chép' + danh từ: nối chuỗi thì en/ru/zh sai trật tự từ (đã mắc một lần
// ở tab "Quản lý thiết bị", xem i18n notes).
async function copy(text, msg) {
  try {
    await navigator.clipboard.writeText(String(text || ''));
    toast(t(msg), 'ok');
  } catch { toast(t('Không sao chép được'), 'err'); }
}

export function render(ctx) {
  const host = el('div.mcp-view');
  ctx.container.appendChild(host);

  // Khung lớn bọc ngoài: viền 0, "viền" là bóng đổ (xem CSS .mcp-frame).
  const frame = el('div.mcp-frame');
  host.appendChild(frame);

  let st = null;
  let dead = false;

  function paintLoading() {
    clear(frame);
    frame.appendChild(el('div.mcp-loading.muted', { text: 'Đang tải…' }));
  }

  // Tiêu đề: CHỈ chữ. User đã bỏ icon bên trái và hai chip (phiên bản giao thức
  // 2025-06-18 + phiên bản app) bên phải - 2026-10-10. `status()` cũng không còn
  // trả `protocol`/`version` nữa, đừng đọc lại.
  function head() {
    return el('div.mcp-head', {}, [
      el('div.mcp-head-main', {}, [
        el('div.mcp-head-title', { text: 'Model Context Protocol' }),
        el('div.mcp-head-sub', { text: 'Cho trợ lý AI điều khiển CGTBrowser qua một cổng duy nhất trên máy này.' }),
      ]),
    ]);
  }

  // Dải thông báo gói - CHỈ hiện khi gói hiện tại không hỗ trợ. Bấm vào nút là
  // sang trang "Nâng cấp gói" (cùng route mà sidebar dùng).
  function planNote() {
    if (st.paid) return null;
    return el('div.mcp-plan', {}, [
      el('span.mcp-plan-ic', { html: icon('crown') }),
      el('div.mcp-plan-main', {}, [
        el('div.mcp-plan-title', { text: 'MCP chỉ hỗ trợ đối với gói trả phí.' }),
        el('div.mcp-plan-sub', { text: 'Gói miễn phí vẫn xem được trang này, nhưng mọi lệnh trợ lý AI gửi tới sẽ bị từ chối.' }),
      ]),
      el('button.btn.primary.mcp-plan-btn', {
        type: 'button',
        onclick: () => { if (typeof ctx.navigate === 'function') ctx.navigate('upgrade'); },
      }, [el('span', { text: 'Nâng cấp gói' })]),
    ]);
  }

  function sect(title, sub, body) {
    return el('div.mcp-sect', {}, [
      el('div.mcp-sect-head', {}, [
        el('div.mcp-sect-title', { text: title }),
        sub ? el('div.mcp-sect-sub', { text: sub }) : null,
      ]),
      body,
    ]);
  }

  function endpointSect() {
    const row = el('div.mcp-endpoint', {}, [
      el('code.mcp-endpoint-url', { text: st.endpoint || '' }),
      el('button.btn.ghost.mcp-copy', {
        type: 'button',
        title: 'Sao chép địa chỉ',
        onclick: () => copy(st.endpoint, 'Đã sao chép địa chỉ'),
      }, [el('span.mcp-copy-ic', { html: icon('copy') }), el('span', { text: 'Sao chép' })]),
    ]);
    // Tiêu đề "Server" và KHÔNG có câu phụ - user chốt 2026-10-10. Câu
    // "Chỉ nghe trên máy này (127.0.0.1)…" đã bỏ, đừng thêm lại.
    return sect('Server', '', row);
  }

  // ĐÃ BỎ nút "Tích hợp Claude" (tự ghi khối cấu hình vào
  // claude_desktop_config.json) - user bỏ 2026-10-10: "miễn sao cấu hình tôi setup
  // bằng tay mà claude đọc đúng là được". ĐỪNG thêm lại. Việc duy nhất trang này
  // phải làm đúng là HIỂN THỊ khối cấu hình để sao chép.
  //
  // HAI KHỐI = HAI CÚ PHÁP TỆP của CÙNG MỘT mục stdio, không phải hai cách kết nối
  // (user 2026-10-10: "hoạt động cho cả claude và codex và các model ai agent
  // khác, chứ không phải chọn 1 trong 2"). Cả hai chuỗi do main sinh ra từ cùng
  // `clientEntry()` - xem src/main/mcp.js → configJson / configToml. ĐỪNG ghép lại
  // chuỗi nào ở đây: chỉ main biết đường dẫn tệp cầu nối nó vừa chép ra.
  //
  // ⛔ ĐÃ BỎ dải thẻ chọn cú pháp (segmented control) - user bỏ 2026-10-10: "bỏ
  // semendtab, đưa boder của codex xuống bên dưới boder claude (trực quan ra luôn,
  // người dùng đỡ bấm vào tab tìm)". Hai khối nay HIỆN CẢ HAI, Codex nằm DƯỚI.
  // ĐỪNG thêm lại thẻ: cả state `fmt`, hàm `show()` và luật `.mcp-fmt*` trong CSS
  // đều đã gỡ. Hệ quả tốt: không còn chỗ nào đọc "thẻ đang chọn" nên nút Sao chép
  // của mỗi khối gắn cứng vào đúng chuỗi của nó, không thể sao chép lẫn.
  // `apps` là MẢNG, mỗi nền tảng một phần tử - KHÔNG phải một chuỗi nối bằng dấu
  // phẩy. Giữ mảng dù nay chỉ nền tảng ĐẦU TIÊN có vạch đỏ (user 2026-10-10: "chỉ
  // áp dụng cho nền tảng đầu tiên, bỏ phía sau và thêm dấu , giữa các model như
  // cũ"): mảng là thứ cho phép mỗi tên có khoá DICT riêng và cho phép đổi ý về sau
  // mà không phải xé lại chuỗi. Dấu phẩy do `appList()` chèn, KHÔNG viết vào `apps`.
  const FORMATS = [
    // ⚠ VS Code ghi kèm TÊN TỆP là có chủ ý: tệp "portable" `.mcp.json` ở gốc
    // workspace dùng khoá `mcpServers` (dán được y nguyên), còn
    // `.vscode/mcp.json` dùng khoá `servers` - dán khối này vào đó thì VS Code
    // nạp RỖNG, im lặng. Đừng rút gọn thành "VS Code".
    { key: 'json', fmt: 'JSON', apps: ['Claude Desktop', 'Claude Code', 'Cursor', 'Windsurf', 'VS Code (.mcp.json)'] },
    { key: 'toml', fmt: 'TOML', apps: ['Codex (tệp config.toml)'] },
    // Thêm trợ lý mới thì thêm TÊN vào `apps` của khối có cú pháp tương ứng, ĐỪNG
    // thêm khối thứ ba: khối là CÚ PHÁP TỆP, không phải tên sản phẩm. Tên nào có
    // chữ tiếng Việt (như "Codex (tệp config.toml)") thì phải thêm khoá vào DICT;
    // tên thuần sản phẩm thì không cần, `t()` trả về nguyên chuỗi.
  ];

  function codeOf(key) {
    return (key === 'toml' ? st.configToml : st.configJson) || '';
  }

  // Danh sách trợ lý: các tên nối bằng ", " và CHỈ tên đầu có vạch đỏ, do luật
  // `.mcp-cfg-for:first-child` trong CSS lo. Dấu phân cách là TEXT NODE trần (`el`
  // nhận chuỗi làm text node) chứ không phải phần tử - nhờ vậy `:first-child` vẫn
  // trúng `<span>` đầu tiên, nếu bọc dấu phẩy vào thẻ thì phải đổi sang
  // `:first-of-type`. Và ", " không có khoá DICT nên bộ dịch bỏ qua nó.
  function appList(apps) {
    const out = [];
    apps.forEach((a, i) => {
      if (i) out.push(', ');
      out.push(el('span.mcp-cfg-for', { text: t(a) }));
    });
    return el('div.mcp-cfg-apps', {}, out);
  }

  // Một khối = nhãn cú pháp + danh sách trợ lý dùng nó + khung mã có nút sao chép.
  function cfgItem(f) {
    const code = codeOf(f.key);
    return el('div.mcp-cfg-item', {}, [
      el('div.mcp-cfg-head', {}, [
        el('code.mcp-cfg-fmt', { text: f.fmt }),
        appList(f.apps),
      ]),
      el('div.mcp-codebox', {}, [
        el('pre.mcp-code', {}, [el('code', { text: code })]),
        el('button.btn.ghost.mcp-copy.mcp-code-copy', {
          type: 'button',
          title: 'Sao chép cấu hình',
          onclick: () => copy(code, 'Đã sao chép cấu hình'),
        }, [el('span.mcp-copy-ic', { html: icon('copy') }), el('span', { text: 'Sao chép' })]),
      ]),
    ]);
  }

  function configSect() {
    // Câu phụ ĐÃ BỎ (user 2026-10-10: bỏ label "Cùng một cấu hình khai bằng hai cú
    // pháp…"), giống mục "Server" và "Tính năng cho phép". `sect()` nhận `sub` rỗng
    // là không dựng `.mcp-sect-sub` nào - ĐỪNG thêm lại câu nào vào đây.
    return sect('Cấu hình cho trợ lý', '', el('div.mcp-cfg', {}, FORMATS.map(cfgItem)));
  }

  // Một nhánh cây = hàng bấm được (mũi tên + tên việc + tên công cụ) và phần thân
  // mô tả chỉ hiện khi mở. Mở/đóng bằng class `.open` trên nhánh, KHÔNG vẽ lại cả
  // trang: paint() lại thì mọi nhánh đang mở sẽ sập về đóng.
  // Các nhánh ĐỘC LẬP (mở được nhiều cùng lúc) - đây là danh sách để đọc, không
  // phải menu một-lựa-chọn.
  function capNode(f) {
    const row = el('button.mcp-tree-row', { type: 'button' }, [
      el('span.mcp-tree-caret'),
      el('span.mcp-tree-name', { text: f.label }),
      el('code.mcp-tree-tool', { text: f.tool }),
    ]);
    const item = el('div.mcp-tree-item', {}, [
      row,
      el('div.mcp-tree-body', {}, [el('div.mcp-tree-desc', { text: f.desc })]),
    ]);
    row.setAttribute('aria-expanded', 'false');
    row.addEventListener('click', () => {
      row.setAttribute('aria-expanded', item.classList.toggle('open') ? 'true' : 'false');
    });
    return item;
  }

  // CỐ Ý không có câu phụ: user đã bỏ dòng "Cả bốn việc dưới đây luôn được phép…"
  // (2026-10-10). `sect()` nhận `sub` rỗng là không dựng thẻ nào - ĐỪNG thêm lại.
  function capsSect() {
    const list = el('div.mcp-tree');
    (st.features || []).forEach((f) => list.appendChild(capNode(f)));
    return sect('Tính năng cho phép', '', list);
  }

  function paint() {
    clear(frame);
    frame.appendChild(head());
    const note = planNote();
    if (note) frame.appendChild(note);
    frame.appendChild(endpointSect());
    frame.appendChild(configSect());
    frame.appendChild(capsSect());
  }

  paintLoading();
  (async () => {
    try {
      st = await window.vt.mcp.status();
    } catch (e) {
      if (dead) return;
      clear(frame);
      frame.appendChild(el('div.mcp-loading', {}, [
        el('div', { text: 'Không đọc được trạng thái MCP' }),
        el('div.muted', { text: String((e && e.message) || e) }),
      ]));
      return;
    }
    if (dead || !st) return;
    paint();
  })();

  return { destroy() { dead = true; } };
}
