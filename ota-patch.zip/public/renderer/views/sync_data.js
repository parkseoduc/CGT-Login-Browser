// "Dữ liệu đồng bộ" - thiết kế theo mục "Đồng bộ dữ liệu" của Omnilogin.
// Lớp bọc ngoài "boder lớn" giống Proxies (.syncdata-card). Bên trong chia 2 panel:
//  - TRÁI 30% "ĐÍCH SAO LƯU": danh sách đích lưu trữ (icon + tên + trạng thái + checkbox),
//    đích đang chọn nổi bật viền/nền xanh.
//  - PHẢI 70%: cấu hình của đích đang chọn, kết thúc bằng khối "Tệp sao lưu".
// Ngăn 2 panel bằng bóng (boderbush), boderthink=0.
import { el, clear, toast, openModal, closeModal } from '../ui.js';
import { icon } from '../icons.js';
import { notifyError } from '../data/errors.js';
import { tf } from '../i18n.js';

// Các đích lưu trữ. Google Drive ĐẦU danh sách (user 2026-11-07) - quyền drive.file (chỉ tệp do CGTBrowser tạo), xem
// src/main/gdrive.js. Bản cũ dùng quyền đọc metadata cả Drive (bị Google xếp "restricted", không tải lên được) nên từng bị gỡ.
const DESTS = [
  { key: 'local', name: 'Thư mục Cục bộ / LAN / NAS', icon: 'folder', status: 'Sẵn sàng' },
  { key: 'gdrive', name: 'Google Drive', icon: 'googleDrive', status: 'Chưa kết nối' },
  { key: 's3', name: 'S3 (Simple Storage Service)', icon: 'amazonS3', status: '' },
  { key: 'telegram', name: 'Telegram', icon: 'telegram', status: 'Chưa kết nối' },
];

let selected = 'local';   // chưa từng chọn ⇒ mục ĐẦU danh sách
const enabled = new Set(['local']); // đích đang bật (checkbox)

// Trạng thái toggle "Đồng bộ dữ liệu hồ sơ khi mở/đóng" (lưu ở settings.syncEnabled).
const sync = { loaded: false, enabled: false, dest: '' };

async function ensureSyncState() {
  if (sync.loaded) return;
  try {
    const s = (window.vt && window.vt.settings && (await window.vt.settings.all())) || {};
    sync.enabled = !!s.syncEnabled;
    sync.dest = s.syncDest || '';
    // Khôi phục thông tin đã gõ ở phiên trước (tự lưu).
    if (s.s3Draft && typeof s.s3Draft === 'object') s3.draft = { ...s.s3Draft };
  } catch { /* mặc định tắt */ }
  sync.loaded = true;
}

function saveSyncState() {
  try { window.vt && window.vt.settings && window.vt.settings.set({ syncEnabled: sync.enabled, syncDest: sync.dest }); } catch { /* ignore */ }
}

// Đích nào đang kết nối thành công.
function isDestConnected(key) {
  return (key === 'local' && localVault.connected) || (key === 'gdrive' && gd.connected) || (key === 'telegram' && tg.connected) || (key === 's3' && s3.connected);
}
function firstConnectedDest() {
  return DESTS.map((d) => d.key).find(isDestConnected) || '';
}

// Hàm vẽ lại panel phải (được render() gán). Cho phép các pane bất đồng bộ (Google
// Drive) tự làm mới sau khi đăng nhập / tải danh sách tệp xong.
let repaintRight = () => {};

// ---- trạng thái Google Drive (đăng nhập + danh sách tệp sao lưu) ----
const gd = {
  loaded: false,        // đã lấy status() lần đầu chưa
  connected: false,
  configured: false,
  account: null,        // { email, name, picture }
  needsReauth: false,   // có token nhưng cấp với quyền CŨ (không lưu được tệp) ⇒ phải đăng nhập lại một lần
  busy: false,          // đang chạy luồng đăng nhập
  files: null,          // null = chưa tải; [] = tải xong nhưng rỗng
  filesLoading: false,
  filesError: '',
};

const bridge = () => (typeof window !== 'undefined' && window.vt && window.vt.gdrive) || null;

// Bóc envelope { ok, data } / { ok:false, error, code } của IPC remoteCall.
function unwrap(res) {
  if (res && res.ok) return res.data;
  const err = new Error((res && res.error) || 'Lỗi không xác định');
  if (res && res.code) err.code = res.code;
  throw err;
}

async function ensureGdStatus() {
  const g = bridge();
  if (!g) { gd.loaded = true; return; }
  try {
    const st = unwrap(await g.status());
    gd.connected = !!st.connected;
    gd.configured = !!st.configured;
    gd.account = st.account || null;
    gd.needsReauth = !!st.needsReauth;
  } catch { /* để trạng thái mặc định */ }
  gd.loaded = true;
  if (selected === 'gdrive') repaintRight();
  if (gd.connected && gd.files == null) loadGdFiles();
}

// Main đẩy 'gdrive:changed' khi kết nối đổi ⇒ lấy lại status + danh sách tệp và vẽ lại (đăng nhập trên trình duyệt
// xong là pane tự cập nhật, không phụ thuộc lời gọi login trả về). Đăng ký MỘT lần cho cả vòng đời renderer.
let gdSubscribed = false;
function subscribeGdChanges() {
  const g = bridge();
  if (gdSubscribed || !g || typeof g.onChanged !== 'function') return;
  gdSubscribed = true;
  g.onChanged(() => {
    gd.files = null; gd.filesError = '';
    ensureGdStatus().then(() => repaintRight()).catch(() => {});
  });
}

async function loadGdFiles() {
  const g = bridge();
  if (!g || !gd.connected) return;
  gd.filesLoading = true; gd.filesError = '';
  if (selected === 'gdrive') repaintRight();
  try {
    const data = unwrap(await g.files({ pageSize: 100 }));
    gd.files = data.files || [];
  } catch (e) {
    gd.files = [];
    gd.filesError = e.message || 'Không tải được danh sách tệp';
    // Phiên Google bị thu hồi / cần cấp lại quyền ⇒ main đã xoá token: hiện lại nút đăng nhập.
    if (e.code === 'NOT_CONNECTED' || e.code === 'DRIVE_REAUTH') { gd.connected = false; gd.files = null; gd.filesError = ''; toast(e.message, 'error'); }
  }
  gd.filesLoading = false;
  if (selected === 'gdrive') repaintRight();
}

async function gdLogin() {
  const g = bridge();
  if (!g) return;
  gd.busy = true; repaintRight();
  try {
    const st = unwrap(await g.login());
    gd.connected = !!st.connected;
    gd.configured = !!st.configured;
    gd.account = st.account || null;
    gd.needsReauth = !!st.needsReauth;
    gd.files = null;
    toast('Đã kết nối Google Drive');
    if (gd.connected) loadGdFiles();
  } catch (e) {
    if (e.code === 'CANCELLED') { /* người dùng bấm Huỷ - im lặng */ } else if (e.code === 'NOT_CONFIGURED') {
      notifyError(e, 'Chưa cấu hình Google Client cho Drive');
    } else {
      notifyError(e, 'Đăng nhập Google Drive thất bại');
    }
    // Lỗi có thể xảy ra SAU khi token đã lưu (vd. tạo thư mục sao lưu) ⇒ lấy lại trạng thái thật từ main cho khớp.
    gd.busy = false;
    await ensureGdStatus().catch(() => {});
  }
  gd.busy = false; repaintRight();
}

async function gdLogout() {
  const g = bridge();
  if (!g) return;
  try {
    const st = unwrap(await g.logout());
    gd.connected = !!st.connected;
    gd.account = null; gd.files = null; gd.needsReauth = false;
    toast('Đã ngắt kết nối Google Drive');
  } catch (e) {
    notifyError(e, 'Ngắt kết nối thất bại');
  }
  repaintRight();
}

// ---- trạng thái Telegram (đăng nhập bằng QR qua MTProto) ----
const tg = {
  loaded: false,
  connected: false,
  configured: false,
  account: null,   // { id, name, username, phone }
  busy: false,
  chatId: '',      // đích đồng bộ (ID kênh/nhóm/username) - rỗng ⇒ Tin nhắn đã lưu
};

const tgBridge = () => (typeof window !== 'undefined' && window.vt && window.vt.telegram) || null;

async function ensureTgStatus() {
  const t = tgBridge();
  if (!t) { tg.loaded = true; return; }
  try {
    const st = unwrap(await t.status());
    tg.connected = !!st.connected;
    tg.configured = !!st.configured;
    tg.account = st.account || null;
    tg.chatId = st.chatId || '';
  } catch { /* mặc định */ }
  tg.loaded = true;
  if (selected === 'telegram') repaintRight();
  // Phiên đăng nhập cũ chưa có ảnh → lấy ảnh (tên/username) ở nền, tự vẽ lại khi xong.
  if (tg.connected && (!tg.account || !tg.account.picture)) {
    t.refresh().then((r) => {
      const st2 = unwrap(r);
      tg.account = st2.account || tg.account;
      if (selected === 'telegram') repaintRight();
    }).catch(() => { /* im lặng, giữ icon mặc định */ });
  }
}

// Bấm "Đăng nhập bằng Telegram" → mở modal chứa mã QR. Đăng ký nhận từng khung QR,
// gọi login() (resolve khi người dùng quét xong). Đóng modal = huỷ đăng nhập.
function tgLogin() {
  const t = tgBridge();
  if (!t) return;
  if (tg.busy) return;
  tg.busy = true;

  const qrBox = el('div.tg-qr', {}, [
    el('div.tg-qr-spinner'),
    el('div.tg-qr-hint', { text: 'Đang tạo mã QR…' }),
  ]);

  const body = el('div.tg-qrmodal', {}, [
    el('div.tg-qr-steps', {}, [
      el('div.tg-qr-step', {}, [el('span.tg-qr-num', { text: '1' }), el('span', { text: 'Mở Telegram trên điện thoại của bạn.' })]),
      el('div.tg-qr-step', {}, [el('span.tg-qr-num', { text: '2' }), el('span', { text: 'Vào Cài đặt → Thiết bị → Liên kết thiết bị.' })]),
      el('div.tg-qr-step', {}, [el('span.tg-qr-num', { text: '3' }), el('span', { text: 'Hướng máy ảnh vào mã QR này để quét.' })]),
    ]),
    qrBox,
  ]);

  let done = false;      // login đã kết thúc (thành công/lỗi) → đừng gọi cancel khi đóng
  let unsub = () => {};
  let observer = null;

  const finish = () => {
    done = true;
    try { unsub(); } catch { /* ignore */ }
    if (observer) { try { observer.disconnect(); } catch { /* ignore */ } observer = null; }
    tg.busy = false;
  };

  // Nhận khung QR → vẽ ảnh vào modal.
  unsub = t.onQr((dataUrl) => {
    clear(qrBox);
    qrBox.appendChild(el('img.tg-qr-img', { src: dataUrl, alt: 'Mã QR đăng nhập Telegram' }));
    qrBox.appendChild(el('div.tg-qr-hint', { text: 'Quét mã bằng ứng dụng Telegram trên điện thoại.' }));
  });

  const { close } = openModal({
    title: 'Đăng nhập Telegram',
    sub: 'Quét mã QR bằng ứng dụng Telegram để kết nối.',
    body,
    width: 520,
  });

  // Người dùng đóng modal (nút X / nền) khi login còn chạy → huỷ phiên đăng nhập.
  const host = document.getElementById('modal-host');
  observer = new MutationObserver(() => {
    if (!host.classList.contains('open') && !done) {
      finish();
      try { t.cancel(); } catch { /* ignore */ }
    }
  });
  observer.observe(host, { attributes: true, attributeFilter: ['class'] });

  t.login().then((res) => {
    const st = unwrap(res);
    finish();
    tg.connected = !!st.connected;
    tg.configured = !!st.configured;
    tg.account = st.account || null;
    closeModal();
    toast('Đã kết nối Telegram');
    repaintRight();
  }).catch((e) => {
    finish();
    if (e.code === 'CANCELLED') { repaintRight(); return; } // người dùng tự huỷ, im lặng
    closeModal();
    if (e.code === 'NOT_CONFIGURED') notifyError(e, 'Chưa cấu hình Telegram trên máy chủ');
    else if (e.code === 'NEED_PASSWORD') notifyError(e, 'Tài khoản bật 2FA - chưa hỗ trợ QR');
    else notifyError(e, 'Đăng nhập Telegram thất bại');
    repaintRight();
  });
}

async function tgLogout() {
  const t = tgBridge();
  if (!t) return;
  try {
    const st = unwrap(await t.logout());
    tg.connected = !!st.connected;
    tg.account = null;
    toast('Đã ngắt kết nối Telegram');
  } catch (e) {
    notifyError(e, 'Ngắt kết nối Telegram thất bại');
  }
  repaintRight();
}

// ---- trạng thái S3 (dịch vụ lưu trữ tự-host của người dùng) ----
const s3 = {
  loaded: false,
  connected: false,
  config: null,       // { bucket, endpoint, region, accessKeyId, prefix }
  busy: false,
  files: null,
  filesLoading: false,
  filesError: '',
  // Nháp cấu hình đang gõ - TỰ LƯU để không mất khi chuyển pane / mở lại app (kể cả khi
  // CHƯA bấm "Kết nối"). Lưu ở settings.s3Draft (cùng nơi lưu creds cục bộ khi đã kết nối).
  draft: {},
};

// Auto-lưu nháp (chống mất dữ liệu người dùng đã gõ). Gộp ghi trong 300ms để đỡ dội IPC.
let _s3DraftT = null;
function saveS3Draft() {
  if (_s3DraftT) clearTimeout(_s3DraftT);
  _s3DraftT = setTimeout(() => {
    _s3DraftT = null;
    try { window.vt && window.vt.settings && window.vt.settings.set({ s3Draft: s3.draft || {} }); } catch { /* ignore */ }
  }, 300);
}

const s3Bridge = () => (typeof window !== 'undefined' && window.vt && window.vt.s3) || null;

async function ensureS3Status() {
  const b = s3Bridge();
  if (!b) { s3.loaded = true; return; }
  try {
    const st = unwrap(await b.status());
    s3.connected = !!st.connected;
    s3.config = st.config || null;
  } catch { /* mặc định */ }
  s3.loaded = true;
  if (s3.connected && s3.files == null) loadS3Files();
  if (selected === 's3') repaintRight();
}

async function loadS3Files() {
  const b = s3Bridge();
  if (!b || !s3.connected) return;
  s3.filesLoading = true; s3.filesError = '';
  if (selected === 's3') repaintRight();
  try {
    const data = unwrap(await b.files({ maxKeys: 1000 }));
    s3.files = data.files || [];
  } catch (e) {
    s3.files = [];
    s3.filesError = e.message || 'Không tải được danh sách tệp';
  }
  s3.filesLoading = false;
  if (selected === 's3') repaintRight();
}

async function s3Connect(cfg) {
  const b = s3Bridge();
  if (!b) return;
  s3.busy = true; repaintRight();
  try {
    const st = unwrap(await b.connect(cfg));
    s3.connected = !!st.connected;
    s3.config = st.config || null;
    s3.files = null;
    toast('Đã kết nối S3');
    if (s3.connected) loadS3Files();
  } catch (e) {
    if (e.code === 'MISSING_FIELDS') notifyError(e, 'Vui lòng nhập đủ thông tin bắt buộc');
    else notifyError(e, 'Kết nối S3 thất bại - kiểm tra endpoint, bucket và khoá truy cập');
  }
  s3.busy = false; repaintRight();
}

async function s3Disconnect() {
  const b = s3Bridge();
  if (!b) return;
  try {
    const st = unwrap(await b.disconnect());
    s3.connected = !!st.connected;
    s3.config = null; s3.files = null;
    toast('Đã ngắt kết nối S3');
  } catch (e) {
    notifyError(e, 'Ngắt kết nối S3 thất bại');
  }
  repaintRight();
}

// ---- định dạng cho datagrid tệp ----
function fmtSize(bytes) {
  if (bytes == null || isNaN(bytes)) return '-';
  if (bytes === 0) return '0 B';
  const u = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.min(u.length - 1, Math.floor(Math.log(bytes) / Math.log(1024)));
  const v = bytes / Math.pow(1024, i);
  return `${v >= 100 || i === 0 ? Math.round(v) : v.toFixed(1)} ${u[i]}`;
}
function fmtDate(iso) {
  if (!iso) return '-';
  const d = new Date(iso);
  if (isNaN(d)) return '-';
  const p = (n) => String(n).padStart(2, '0');
  return `${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

// ---- helpers dựng field cho panel phải ----
function labelEl(text, required, note) {
  return el('label.syncdata-flabel', {}, [
    required ? el('span.req', { text: '* ' }) : null,
    el('span', { text }),
    note ? el('span.syncdata-fnote', { text: ' ' + note }) : null,
  ]);
}

// Nhãn NHÓM (tiêu đề mục) cho panel bên phải - gom các phần Tài khoản / Nơi lưu / Tệp sao
// lưu thành từng nhóm rõ ràng. `sub` (tuỳ chọn) = mô tả ngắn dưới nhãn.
function sectionLabel(text, sub) {
  return el('div.syncdata-section', {}, [
    el('div.syncdata-section-t', { text }),
    sub ? el('div.syncdata-section-s', { text: sub }) : null,
  ]);
}

function textField(label, { required, placeholder = '', value = '', hint, eye } = {}) {
  const input = el('input.input', { type: eye ? 'password' : 'text', placeholder, value });
  let control = input;
  if (eye) {
    const toggle = el('button.syncdata-eye', {
      type: 'button', html: icon('eyeOff'),
      onclick: () => {
        const show = input.type === 'password';
        input.type = show ? 'text' : 'password';
        toggle.innerHTML = icon(show ? 'eye' : 'eyeOff');
      },
    });
    control = el('div.syncdata-inputwrap', {}, [input, toggle]);
  }
  return el('div.syncdata-field', {}, [
    labelEl(label, required),
    control,
    hint ? el('div.syncdata-fhint', { text: hint }) : null,
  ]);
}

// Ô nhập dùng "nhãn cắt ngang" (floating label): nhãn nằm giữa ô khi rỗng, trượt lên cắt viền
// trên khi focus/có giá trị. `input` là <input.input> tạo sẵn; `suffix` (vd nút con mắt) đặt trong ô.
function floatField(labelText, input, { required, hint, suffix } = {}) {
  if (!input.getAttribute('placeholder')) input.setAttribute('placeholder', ' ');
  const lbl = el('label.syncdata-float-lbl', {}, [
    el('span', { text: labelText }),
    required ? el('span.req', { text: ' *' }) : null,
  ]);
  const kids = suffix ? [input, lbl, suffix] : [input, lbl];
  return el('div.syncdata-field', {}, [
    el('div.syncdata-float' + (suffix ? '.has-suffix' : ''), {}, kids),
    hint ? el('div.syncdata-fhint', { text: hint }) : null,
  ]);
}

// Khối "Tệp sao lưu" (trạng thái rỗng) dùng chung cuối mỗi panel.
function backupFilesBlock() {
  return el('div.syncdata-backup', {}, [
    el('div.syncdata-empty', { text: 'Kết nối đích này để xem danh sách tệp sao lưu.' }),
  ]);
}

// ---- panel phải theo từng đích ----
// Header khi đã đăng nhập: avatar + tên + email + nút Làm mới / Ngắt kết nối.
function gdAccountHeader() {
  const a = gd.account || {};
  const initial = (a.name || a.email || '?').trim().charAt(0).toUpperCase();
  const avatar = a.picture
    ? el('img.syncdata-acc-avatar', { src: a.picture, alt: '' })
    : el('div.syncdata-acc-avatar.fallback', { text: initial });
  return el('div.syncdata-acc', {}, [
    avatar,
    el('div.syncdata-acc-main', {}, [
      el('div.syncdata-acc-name', { text: a.name || 'Tài khoản Google' }),
      el('div.syncdata-acc-email', { text: a.email || '' }),
    ]),
    el('div.syncdata-acc-actions', {}, [
      el('button.icon-btn.syncdata-acc-btn', {
        title: 'Làm mới', html: icon('refresh'),
        onclick: () => { if (!gd.filesLoading) loadGdFiles(); },
      }),
      el('button.btn.syncdata-acc-logout', {
        onclick: gdLogout,
      }, [el('span.syncdata-acc-logout-ic', { html: icon('logout') }), el('span', { text: 'Ngắt kết nối' })]),
    ]),
  ]);
}

// Khối "Tệp sao lưu" khi ĐÃ kết nối: datagrid (Tên / Kích thước / Ngày tạo) + vector rỗng.
function gdFilesBlock() {
  const body = el('div');
  if (gd.filesLoading && gd.files == null) {
    body.appendChild(el('div.syncdata-empty', { text: 'Đang tải danh sách tệp…' }));
  } else if (gd.filesError) {
    body.appendChild(el('div.syncdata-empty', { text: gd.filesError }));
  } else if (!gd.files || gd.files.length === 0) {
    body.appendChild(el('div.syncdata-nofiles', {}, [
      el('div.syncdata-nofiles-ic', { html: icon('emptyDrive') }),
      el('div.syncdata-nofiles-t', { text: 'Chưa có tệp sao lưu' }),
      el('div.syncdata-nofiles-d', { text: 'Các tệp sao lưu trên Google Drive sẽ hiển thị ở đây.' }),
    ]));
  } else {
    const rows = gd.files.map((f) => el('tr', {}, [
      el('td.syncdata-fname', {}, [
        el('span.syncdata-fname-ic', { html: icon('googleDrive') }),
        el('span', { text: f.name }),
      ]),
      el('td', { text: fmtSize(f.size) }),
      el('td', { text: fmtDate(f.createdTime) }),
    ]));
    body.appendChild(el('table.grid.syncdata-ftable', {}, [
      el('thead', {}, [el('tr', {}, [
        el('th', { text: 'Tên' }),
        el('th.syncdata-col-size', { text: 'Kích thước' }),
        el('th.syncdata-col-date', { text: 'Ngày tạo' }),
      ])]),
      el('tbody', {}, rows),
    ]));
  }
  return el('div.syncdata-backup', {}, [
    el('div.syncdata-backup-head', {}, [
      gd.files && gd.files.length
        ? el('span.syncdata-backup-count', { text: tf('{0} tệp', gd.files.length) })
        : null,
    ]),
    body,
  ]);
}

function paneGdrive() {
  // Lần đầu vào tab → lấy trạng thái kết nối (bất đồng bộ, tự vẽ lại khi xong).
  if (!gd.loaded) ensureGdStatus();

  const pane = el('div.syncdata-pane', {}, [
    el('h3', { text: 'Google Drive' }),   // KHÔNG đoạn mô tả (user 2026-11-07: bỏ dòng mô tả dài dòng)
  ]);

  if (!gd.loaded) {
    pane.appendChild(el('div.syncdata-hero', { html: icon('googleDrive') }));
    pane.appendChild(el('div.syncdata-empty', { text: 'Đang kiểm tra kết nối…' }));
    return pane;
  }

  if (gd.connected) {
    // ĐÃ đăng nhập: header thông tin Gmail (căn trái) + datagrid tệp.
    pane.classList.add('is-connected');
    pane.appendChild(sectionLabel('Tài khoản', 'Tài khoản Google nhận các gói sao lưu.'));
    pane.appendChild(gdAccountHeader());
    pane.appendChild(gdFilesBlock());
    return pane;
  }

  // CHƯA đăng nhập: minh hoạ + nút đăng nhập.
  pane.appendChild(el('div.syncdata-hero', { html: icon('googleDrive') }));
  pane.appendChild(el('div.syncdata-actions', {}, [
    el('button.btn.primary.syncdata-btn', {
      disabled: gd.busy || undefined,
      onclick: gdLogin,
    }, [
      el('span.syncdata-btn-ic', { html: icon('googleG') }),
      el('span', { text: gd.busy ? 'Đang chờ đăng nhập trên trình duyệt…' : (gd.needsReauth ? 'Đăng nhập lại với Google' : 'Đăng nhập với Google') }),
    ]),
    // Đang chờ trình duyệt (người dùng đóng tab Google giữa chừng…) ⇒ cho huỷ thay vì đợi hết 5 phút.
    gd.busy ? el('button.btn.syncdata-btn', {
      onclick: () => { const g = bridge(); if (g && g.cancel) g.cancel(); },
    }, [el('span', { text: 'Huỷ' })]) : null,
  ]));

  // (Bỏ nút "Dùng Token" + ô dán Refresh Token - user 2026-11-07: chỉ đăng nhập bằng Google.)

  if (gd.needsReauth) {
    pane.appendChild(el('div.syncdata-notice', { text: 'Kết nối Google Drive cũ chưa có quyền lưu tệp sao lưu. Hãy đăng nhập lại một lần và cho phép CGTBrowser tạo, quản lý tệp trên Drive.' }));
  }
  if (!gd.configured) {
    pane.appendChild(el('div.syncdata-notice', { text: 'Đăng nhập Google chưa được cấu hình trên máy chủ (GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET). Bật Google Drive API cho OAuth Client này để đăng nhập.' }));
  }

  return pane;
}

// Header khi ĐÃ kết nối S3: icon + bucket + endpoint + nút Làm mới / Ngắt kết nối.
function s3AccountHeader() {
  const c = s3.config || {};
  let hostText = c.endpoint || '';
  try { hostText = new URL(c.endpoint).host; } catch { /* giữ nguyên */ }
  return el('div.syncdata-acc', {}, [
    el('div.syncdata-acc-avatar.fallback.s3', { html: icon('amazonS3') }),
    el('div.syncdata-acc-main', {}, [
      el('div.syncdata-acc-name', { text: c.bucket || 'Bucket S3' }),
      el('div.syncdata-acc-email', { text: hostText + (c.region ? ' · ' + c.region : '') }),
    ]),
    el('div.syncdata-acc-actions', {}, [
      el('button.icon-btn.syncdata-acc-btn', {
        title: 'Làm mới', html: icon('refresh'),
        onclick: () => { if (!s3.filesLoading) loadS3Files(); },
      }),
      el('button.btn.syncdata-acc-logout', { onclick: s3Disconnect }, [
        el('span.syncdata-acc-logout-ic', { html: icon('logout') }),
        el('span', { text: 'Ngắt kết nối' }),
      ]),
    ]),
  ]);
}

// Khối "Tệp sao lưu" khi ĐÃ kết nối S3: datagrid (Tên / Kích thước / Ngày sửa đổi).
function s3FilesBlock() {
  const body = el('div');
  if (s3.filesLoading && s3.files == null) {
    body.appendChild(el('div.syncdata-empty', { text: 'Đang tải danh sách tệp…' }));
  } else if (s3.filesError) {
    body.appendChild(el('div.syncdata-empty', { text: s3.filesError }));
  } else if (!s3.files || s3.files.length === 0) {
    body.appendChild(el('div.syncdata-nofiles', {}, [
      el('div.syncdata-nofiles-ic', { html: icon('emptyDrive') }),
      el('div.syncdata-nofiles-t', { text: 'Chưa có tệp sao lưu' }),
      el('div.syncdata-nofiles-d', { text: 'Các tệp trong bucket S3 sẽ hiển thị ở đây.' }),
    ]));
  } else {
    const rows = s3.files.map((f) => el('tr', {}, [
      el('td.syncdata-fname', {}, [
        el('span.syncdata-fname-ic', { html: icon('fileDoc') }),
        el('span', { text: f.name }),
      ]),
      el('td', { text: fmtSize(f.size) }),
      el('td', { text: fmtDate(f.createdTime) }),
    ]));
    body.appendChild(el('table.grid.syncdata-ftable', {}, [
      el('thead', {}, [el('tr', {}, [
        el('th', { text: 'Tên' }),
        el('th.syncdata-col-size', { text: 'Kích thước' }),
        el('th.syncdata-col-date', { text: 'Ngày sửa đổi' }),
      ])]),
      el('tbody', {}, rows),
    ]));
  }
  return el('div.syncdata-backup', {}, [
    el('div.syncdata-backup-head', {}, [
      s3.files && s3.files.length
        ? el('span.syncdata-backup-count', { text: tf('{0} tệp', s3.files.length) })
        : null,
    ]),
    body,
  ]);
}

function paneS3() {
  if (!s3.loaded) ensureS3Status();

  const pane = el('div.syncdata-pane', {}, [
    el('h3', { text: 'S3 (Simple Storage Service)' }),
    el('p.syncdata-desc', {}, [
      el('span', { text: 'Đây là các dịch vụ lưu trữ an toàn, giá rẻ. Không giới hạn dung lượng hay băng thông và có nhiều nhà cung cấp trên toàn thế giới. Bạn có thể tham khảo các nhà cung cấp sau: ' }),
      el('span.syncdata-link', { text: 'Cloudflare R2, Amazon S3, DigitalOcean, Wasabi, BizflyCloud VN, Cloudfly VN, MinIO' }),
    ]),
  ]);

  if (!s3.loaded) {
    pane.appendChild(el('div.syncdata-hero', { html: icon('amazonS3') }));
    pane.appendChild(el('div.syncdata-empty', { text: 'Đang kiểm tra kết nối…' }));
    return pane;
  }

  if (s3.connected) {
    pane.classList.add('is-connected');
    pane.appendChild(s3AccountHeader());
    pane.appendChild(s3FilesBlock());
    return pane;
  }

  // CHƯA kết nối: form nhập cấu hình S3 (nhãn cắt ngang) + nút "Kết nối".
  // Giá trị khởi tạo ưu tiên nháp đang gõ (s3.draft) rồi mới tới cấu hình đã lưu (s3.config),
  // và MỌI ô đều tự lưu nháp (debounce) để không mất khi chuyển pane / khởi động lại app.
  const c = s3.config || {};
  const d = s3.draft || {};
  const draftVal = (key) => (d[key] != null ? d[key] : (c[key] || ''));
  const bindDraft = (inputEl, key) => {
    inputEl.addEventListener('input', () => {
      s3.draft[key] = inputEl.value;
      saveS3Draft();
    });
    return inputEl;
  };
  const inBucket = bindDraft(el('input.input', { type: 'text', value: draftVal('bucket') }), 'bucket');
  const inEndpoint = bindDraft(el('input.input', { type: 'text', value: draftVal('endpoint') }), 'endpoint');
  const inAccessKey = bindDraft(el('input.input', { type: 'text', value: draftVal('accessKeyId') }), 'accessKeyId');
  const inSecret = bindDraft(el('input.input', { type: 'password', value: draftVal('secretAccessKey') }), 'secretAccessKey');
  const secretToggle = el('button.syncdata-eye', {
    type: 'button', html: icon('eyeOff'),
    onclick: () => {
      const show = inSecret.type === 'password';
      inSecret.type = show ? 'text' : 'password';
      secretToggle.innerHTML = icon(show ? 'eye' : 'eyeOff');
    },
  });
  const inRegion = bindDraft(el('input.input', { type: 'text', value: draftVal('region') }), 'region');

  const doConnect = () => s3Connect({
    bucket: inBucket.value,
    endpoint: inEndpoint.value,
    accessKeyId: inAccessKey.value,
    secretAccessKey: inSecret.value,
    region: inRegion.value,
  });

  pane.appendChild(floatField('Bucket', inBucket, { required: true }));
  pane.appendChild(floatField('Endpoint', inEndpoint, {
    required: true,
    hint: 'Địa chỉ dịch vụ S3 (không kèm tên bucket). VD: https://<account>.r2.cloudflarestorage.com',
  }));
  pane.appendChild(floatField('Access Key ID', inAccessKey, { required: true }));
  pane.appendChild(floatField('Secret Access Key', inSecret, { required: true, suffix: secretToggle }));
  pane.appendChild(floatField('Region', inRegion, { hint: 'Để trống sẽ dùng us-east-1. Cloudflare R2 dùng "auto".' }));
  pane.appendChild(el('div.syncdata-actions.is-left', {}, [
    el('button.btn.primary.syncdata-connect', {
      disabled: s3.busy || undefined,
      text: s3.busy ? 'Đang kết nối…' : 'Kết nối',
      onclick: doConnect,
    }),
  ]));

  return pane;
}

// Header khi đã đăng nhập Telegram: avatar (chữ cái đầu) + tên + @username / số ĐT.
function tgAccountHeader() {
  const a = tg.account || {};
  const sub = a.username ? '@' + a.username : (a.phone ? '+' + a.phone : '');
  const avatar = a.picture
    ? el('img.syncdata-acc-avatar', { src: a.picture, alt: '' })
    : el('div.syncdata-acc-avatar.fallback.tg', { html: icon('userSolid') });
  return el('div.syncdata-acc', {}, [
    avatar,
    el('div.syncdata-acc-main', {}, [
      el('div.syncdata-acc-name', { text: a.name || 'Tài khoản Telegram' }),
      el('div.syncdata-acc-email', { text: sub }),
    ]),
    el('div.syncdata-acc-actions', {}, [
      el('button.btn.syncdata-acc-logout', { onclick: tgLogout }, [
        el('span.syncdata-acc-logout-ic', { html: icon('logout') }),
        el('span', { text: 'Ngắt kết nối' }),
      ]),
    ]),
  ]);
}

// Ô "Chat / Channel ID" - nhập ID kênh/nhóm/username để đẩy sao lưu lên đó. Lưu ngay khi
// rời ô (change/blur) qua telegram.setChatId, rồi telegram.validateChat kiểm tra truy cập:
// resolve được ⇒ hint xanh "Sẽ đồng bộ vào: <tên>"; sai/không quyền ⇒ hint cam cảnh báo
// sẽ quay về Tin nhắn đã lưu; để trống ⇒ mặc định Tin nhắn đã lưu.
function tgChatIdField() {
  const DEFAULT_HINT = 'Dán link/ID kênh hoặc NHÓM (t.me/+… , t.me/joinchat/… , @username). Dùng NHÓM để mọi thành viên đều đồng bộ được (kênh chỉ admin đăng được). Để trống sẽ dùng Tin nhắn đã lưu.';
  const hint = el('div.syncdata-fhint', { text: DEFAULT_HINT });
  // placeholder = 1 khoảng trắng → giữ :placeholder-shown hoạt động cho nhãn nổi (floating label).
  const input = el('input.input', {
    type: 'text',
    placeholder: ' ',
    value: tg.chatId || '',
  });

  let lastSaved = tg.chatId || '';
  async function commit() {
    const t = tgBridge();
    if (!t) return;
    const val = input.value.trim();
    if (val === lastSaved) return; // không đổi → khỏi gọi
    lastSaved = val;
    tg.chatId = val;
    hint.className = 'syncdata-fhint';
    hint.textContent = val ? 'Đang kiểm tra ID…' : DEFAULT_HINT;
    try {
      await t.setChatId(val);
      if (!val) { hint.textContent = DEFAULT_HINT; return; }
      const r = unwrap(await t.validateChat(val));
      if (r && r.fallback) {
        hint.className = 'syncdata-fhint is-warn';
        hint.textContent = `Không truy cập được ID này - sẽ đồng bộ vào Tin nhắn đã lưu.`;
      } else {
        hint.className = 'syncdata-fhint is-ok';
        hint.textContent = tf('Sẽ đồng bộ vào: {0}', (r && r.target) || val);
      }
    } catch (e) {
      hint.className = 'syncdata-fhint is-warn';
      hint.textContent = (e && e.message) || 'Không kiểm tra được ID.';
    }
  }
  input.addEventListener('change', commit);
  input.addEventListener('blur', commit);
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); input.blur(); } });

  // Nhãn "cắt ngang" (floating label): nằm giữa ô khi rỗng, nổi lên cắt viền trên khi focus/có giá trị.
  return el('div.syncdata-field', {}, [
    el('div.syncdata-float', {}, [
      input,
      el('label.syncdata-float-lbl', { text: 'Nhập link kênh hoặc nhóm' }),
    ]),
    hint,
  ]);
}

function paneTelegram() {
  if (!tg.loaded) ensureTgStatus();

  const pane = el('div.syncdata-pane', {});

  if (!tg.loaded) {
    pane.appendChild(el('h3', { text: 'Telegram' }));
    pane.appendChild(el('div.syncdata-hero', { html: icon('telegram') }));
    pane.appendChild(el('div.syncdata-empty', { text: 'Đang kiểm tra kết nối…' }));
    return pane;
  }

  if (tg.connected) {
    // Tối giản: chỉ tài khoản + ô nhập link kênh (nhãn nổi). Bỏ hết nhãn nhóm/tiêu đề.
    pane.classList.add('is-connected');
    pane.appendChild(tgAccountHeader());
    pane.appendChild(tgChatIdField());
    return pane;
  }

  // CHƯA đăng nhập: minh hoạ + nút mở modal QR.
  pane.appendChild(el('h3', { text: 'Telegram' }));
  pane.appendChild(el('div.syncdata-hero', { html: icon('telegram') }));
  pane.appendChild(el('div.syncdata-actions', {}, [
    el('button.btn.primary.syncdata-btn', {
      disabled: tg.busy || undefined,
      onclick: tgLogin,
    }, [
      el('span.syncdata-btn-ic', { html: icon('telegram') }),
      el('span', { text: tg.busy ? 'Đang chờ quét QR…' : 'Đăng nhập bằng Telegram' }),
    ]),
  ]));

  if (!tg.configured) {
    pane.appendChild(el('div.syncdata-notice', { text: 'Đăng nhập Telegram chưa được cấu hình trên máy chủ (TELEGRAM_API_ID / TELEGRAM_API_HASH). Lấy api_id + api_hash tại https://my.telegram.org rồi thêm vào server/.env.' }));
  }

  return pane;
}


// ---- trạng thái Kho Cục bộ / LAN / NAS + E2EE (CORE_UI_CONTRACT_V2 §4.6) ----
const localVault = {
  loaded: false,
  connected: true,
  folderPath: 'D:\\CGT-Login\\data\\cloud-vault',
  passphrase: '',
  profiles: [],
  busyId: '',
};

async function ensureLocalVault() {
  try {
    const all = (window.vt && window.vt.settings && await window.vt.settings.all()) || {};
    if (all.localSyncFolder) localVault.folderPath = all.localSyncFolder;
    if (typeof all.vaultPassphrase === 'string') localVault.passphrase = all.vaultPassphrase;
    if (window.vt && window.vt.cloudSync) {
      const cs = await window.vt.cloudSync.status();
      if (cs && cs.ok && cs.data && cs.data.local && cs.data.local.folderPath) {
        localVault.folderPath = cs.data.local.folderPath;
        localVault.connected = cs.data.local.connected !== false;
      }
    }
    if (window.vt && window.vt.profiles) {
      localVault.profiles = (await window.vt.profiles.list(null)) || [];
    }
  } catch { /* keep defaults */ }
  localVault.loaded = true;
}

function buildE2eeCard() {
  const hasPass = !!(localVault.passphrase && localVault.passphrase.trim().length >= 4);
  const badge = el('span.cgt-e2ee-badge' + (hasPass ? '' : '.off'), {
    text: hasPass ? 'AES-256 E2EE Bật' : 'Chưa đặt khóa',
  });
  const inp = el('input.input', {
    type: 'password',
    placeholder: 'Mật khẩu mã hóa E2EE (.tgz)',
    value: localVault.passphrase || '',
  });
  const saveBtn = el('button.btn.sm', {
    type: 'button',
    text: 'Lưu khóa',
    onclick: async () => {
      localVault.passphrase = inp.value.trim();
      if (window.vt && window.vt.cloudSync) {
        await window.vt.cloudSync.saveSettings({ vaultPassphrase: localVault.passphrase });
      }
      toast(localVault.passphrase ? 'Đã bật khóa mã hóa đầu cuối E2EE cho gói sao lưu' : 'Đã tắt mật khẩu mã hóa E2EE', 'ok');
      repaintRight();
    },
  });
  return el('div.cgt-e2ee-box', {}, [
    el('div.cgt-e2ee-head', {}, [el('span', { text: 'Mã hóa đầu cuối (E2EE)' }), badge]),
    el('div.cgt-e2ee-row', {}, [inp, saveBtn]),
  ]);
}

function paneLocal() {
  if (!localVault.loaded) {
    ensureLocalVault().then(() => { if (selected === 'local') repaintRight(); });
  }
  const pane = el('div.syncdata-pane.is-connected');
  const pathInp = el('input.input', {
    value: localVault.folderPath || 'D:\\CGT-Login\\data\\cloud-vault',
    placeholder: 'Đường dẫn thư mục LAN / NAS / OneDrive / Dropbox...',
  });
  const pickBtn = el('button.btn', {
    type: 'button',
    html: icon('folder') + '<span>Chọn thư mục</span>',
    onclick: async () => {
      const dir = await window.vt.dialog.openFolder({ title: 'Chọn thư mục Kho đồng bộ LAN / NAS' });
      if (dir) pathInp.value = dir;
    },
  });
  const saveBtn = el('button.btn.primary', {
    type: 'button',
    text: 'Kết nối kho',
    onclick: async () => {
      const folderPath = pathInp.value.trim();
      if (!folderPath) { toast('Vui lòng nhập đường dẫn thư mục', 'error'); return; }
      const r = await window.vt.cloudSync.connectLocal(folderPath);
      if (r && r.ok) {
        localVault.folderPath = folderPath;
        localVault.connected = true;
        toast('Đã kết nối Kho đồng bộ Cục bộ / NAS', 'ok');
        repaintRight();
      } else {
        toast((r && r.error) || 'Không kết nối được thư mục', 'error');
      }
    },
  });

  const profRows = (localVault.profiles || []).slice(0, 20).map((p) => el('div.cgt-vault-profrow', {}, [
    el('div.cgt-vault-profname', { text: p.name || p.id, title: p.name || p.id }),
    el('div.cgt-vault-profacts', {}, [
      el('button.btn.sm', {
        type: 'button',
        disabled: localVault.busyId === p.id || undefined,
        text: 'Đẩy lên (Push)',
        onclick: async () => {
          localVault.busyId = p.id; repaintRight();
          const r = await window.vt.cloudSync.pushProfile(p.id);
          localVault.busyId = '';
          if (r && r.ok) toast('Đã đóng gói & sao lưu hồ sơ "' + p.name + '"', 'ok');
          else toast((r && r.error) || 'Sao lưu thất bại', 'error');
          repaintRight();
        },
      }),
      el('button.btn.sm', {
        type: 'button',
        disabled: localVault.busyId === p.id || undefined,
        text: 'Kéo về (Pull)',
        onclick: async () => {
          localVault.busyId = p.id; repaintRight();
          const r = await window.vt.cloudSync.pullProfile(p.id);
          localVault.busyId = '';
          if (r && r.ok) toast('Đã khôi phục hồ sơ "' + p.name + '" từ kho sao lưu', 'ok');
          else toast((r && r.error) || 'Khôi phục thất bại', 'error');
          repaintRight();
        },
      }),
    ]),
  ]));

  pane.appendChild(el('div.cgt-local-vault', {}, [
    el('h3', { text: 'Kho lưu trữ Cục bộ / LAN / NAS' }),
    buildE2eeCard(),
    el('div.cgt-vault-card', {}, [
      el('div.muted', { text: 'Đồng bộ tự động dữ liệu Cookie & Phiên đăng nhập của hồ sơ vào thư mục chia sẻ mạng nội bộ (SMB/NAS) hoặc thư mục Cloud Mount (OneDrive, Google Drive Desktop, Dropbox).' }),
      el('div.cgt-vault-pathrow', {}, [pathInp, pickBtn, saveBtn]),
    ]),
    el('div.cgt-vault-card', {}, [
      el('div', { style: { fontWeight: '600', fontSize: '13.5px' }, text: 'Sao lưu & Khôi phục thủ công theo Hồ sơ' }),
      profRows.length
        ? el('div.cgt-vault-proflist', {}, profRows)
        : el('div.muted', { text: 'Chưa có hồ sơ nào — tạo hồ sơ mới để đẩy bản sao lưu đầu tiên.' }),
    ]),
  ]));
  return pane;
}

const PANES = { local: paneLocal, gdrive: paneGdrive, s3: paneS3, telegram: paneTelegram };

export function render(ctx) {
  const left = el('div.syncdata-left');
  const right = el('div.syncdata-right');

  function destStatus(d) {
    // Google Drive: phản ánh trạng thái kết nối thực (email khi đã đăng nhập).
    if (d.key === 'local') return localVault.connected ? 'Đã kết nối' : 'Chưa kết nối';
    if (d.key === 'gdrive') {
      if (gd.connected) return (gd.account && gd.account.email) || 'Đã kết nối';
      return 'Chưa kết nối';
    }
    if (d.key === 'telegram') {
      if (tg.connected) {
        const a = tg.account || {};
        return a.username ? '@' + a.username : (a.name || 'Đã kết nối');
      }
      return 'Chưa kết nối';
    }
    if (d.key === 's3') {
      if (s3.connected) return (s3.config && s3.config.bucket) || 'Đã kết nối';
      return 'Chưa kết nối';
    }
    return d.status;
  }

  // checkbox bật/tắt đích - dùng đúng checkbox chuẩn của app (input type=checkbox).
  function destCheck(d) {
    const cb = el('input.syncdata-check', {
      type: 'checkbox',
      onclick: (e) => {
        e.stopPropagation();
        // Radio 1-trong-3: bấm ô này = chọn đích này làm nơi đồng bộ (và LƯU) - không để trống.
        selectDest(d.key);
      },
    });
    cb.checked = enabled.has(d.key);
    return cb;
  }

  // Chọn nơi đồng bộ = đặt ĐÍCH HIỆU LỰC (settings.syncDest) mà sync-run.activeDest() đọc
  // MỖI lần mở/đóng hồ sơ. BẮT BUỘC lưu ngay: trước đây click chỉ đổi UI (selected/enabled)
  // mà KHÔNG lưu → bật sync ở Telegram rồi bấm sang S3, mở/đóng hồ sơ VẪN đẩy lên Telegram.
  function selectDest(key) {
    selected = key;
    enabled.clear();
    enabled.add(key);
    sync.dest = key;      // đích hiệu lực = lựa chọn hiện tại
    saveSyncState();      // lưu syncDest (kể cả khi tắt sync → nhớ lựa chọn gần nhất)
    paintLeft();
    paintRight();
  }

  function paintLeft() {
    clear(left);
    // Toggle bật/tắt đồng bộ nằm NGAY TRONG panel bên trái (không còn thanh header riêng).
    left.appendChild(el('div.syncdata-ltoggle', {}, [
      el('button.switch' + (sync.enabled ? '.on' : ''), {
        title: sync.enabled ? 'Tắt đồng bộ' : 'Bật đồng bộ',
        onclick: toggleSync,
      }, [el('span.knob')]),
      el('div.syncdata-ltoggle-main', {}, [
        el('div.syncdata-ltoggle-title', { text: 'Đồng bộ dữ liệu' }),
      ]),
    ]));
    // Gạch ngang phân cách nằm BÊN TRONG panel trái (ngăn toggle với danh sách nơi đồng bộ).
    left.appendChild(el('div.syncdata-ldivider'));
    left.appendChild(el('div.syncdata-lhead', { text: 'Chọn nơi đồng bộ' }));
    DESTS.forEach((d) => {
      const isSel = d.key === selected;
      const status = destStatus(d);
      const isConn = isDestConnected(d.key);
      const box = el('div.syncdata-dest' + (isSel ? '.active' : ''), {
        onclick: () => selectDest(d.key),
      }, [
        el('span.syncdata-dest-ic' + (isConn ? '.connected' : ''), { html: icon(d.icon) }),
        el('div.syncdata-dest-main', {}, [
          el('div.syncdata-dest-name', { text: d.name }),
          status ? el('div.syncdata-dest-status' + (isConn ? '.ok' : ''), { text: status }) : null,
        ]),
        destCheck(d),
      ]);
      left.appendChild(box);
    });
  }

  function paintRight() {
    clear(right);
    right.appendChild((PANES[selected] || paneS3)());
  }

  // ---- Toggle bật/tắt đồng bộ (render TRONG panel trái ở paintLeft) ----
  function toggleSync() {
    if (!sync.enabled) {
      // BẬT: bắt buộc đã kết nối 1 trong 3 đích. Ưu tiên: đích đang tick bên trái →
      // đích đã lưu phiên trước (syncDest) → đích đầu tiên đang kết nối.
      const chosen = [...enabled][0];
      const dest = (chosen && isDestConnected(chosen)) ? chosen
        : (sync.dest && isDestConnected(sync.dest)) ? sync.dest
          : firstConnectedDest();
      if (!dest) {
        toast('Chưa kết nối đồng bộ. Hãy kết nối một trong ba nơi sao lưu (Google Drive / S3 / Telegram) trước khi bật.', 'error');
        return;
      }
      sync.enabled = true;
      sync.dest = dest;
    } else {
      sync.enabled = false;
    }
    saveSyncState();
    paintLeft();
  }

  // Cho các pane bất đồng bộ tự vẽ lại (đăng nhập Google Drive xong, tải tệp…).
  // Cập nhật cả trạng thái đích + toggle bên trái theo kết nối.
  repaintRight = () => { paintRight(); paintLeft(); };

  paintLeft();
  paintRight();
  ensureSyncState().then(() => {
    // Khôi phục ĐÍCH đã chọn từ phiên trước (settings.syncDest) - nếu không, mở lại app
    // panel bên trái luôn nhảy về Google Drive dù đã chọn Telegram/S3 ("nơi chọn đồng bộ
    // bị reset"). syncDest được giữ cả khi tắt toggle nên vẫn nhớ lựa chọn gần nhất.
    if (sync.dest && DESTS.some((d) => d.key === sync.dest)) {
      selected = sync.dest;
      enabled.clear();
      enabled.add(sync.dest);
      paintLeft();
      paintRight();
    }
  });

  // Tải trạng thái kết nối của CẢ 3 đích NGAY khi mở trang (không đợi người dùng bấm
  // vào từng pane). Trước đây chỉ pane Google Drive được vẽ lúc mở → ensureTgStatus/
  // ensureS3Status không chạy → tg.connected/s3.connected vẫn false dù đã đăng nhập →
  // bấm nút gạt bị chặn "chưa kết nối" và KHÔNG lưu được (toggle bị reset mỗi lần mở
  // app). Nạp sẵn để danh sách bên trái + nút gạt phản ánh đúng nơi đang kết nối.
  const refreshConn = () => { paintLeft(); };
  subscribeGdChanges();
  if (!gd.loaded) ensureGdStatus().then(refreshConn).catch(() => {});
  if (!tg.loaded) ensureTgStatus().then(refreshConn).catch(() => {});
  if (!s3.loaded) ensureS3Status().then(refreshConn).catch(() => {});
  if (!localVault.loaded) ensureLocalVault().then(refreshConn).catch(() => {});

  const page = el('div.syncdata-root', {}, [
    el('div.syncdata-card', {}, [
      el('div.syncdata-split', {}, [left, right]),
    ]),
  ]);

  ctx.container.appendChild(page);
  return null;
}
