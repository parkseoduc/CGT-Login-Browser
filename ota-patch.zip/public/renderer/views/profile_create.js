// Full-page "Hồ sơ trình duyệt mới" - redesigned to mirror the reference
// create-profile screen: a single scrollable form split into 5 sections
// (Cài đặt chung / Proxy / Vân tay / Siêu dữ liệu / Nâng cao). The top tab bar
// is a scrollspy nav - clicking a tab smooth-scrolls the form to that section,
// and scrolling the form highlights the matching tab. The right column keeps
// the live "Tổng quan" fingerprint overview.
import { el, clear, toast, customSelect, alertDialog, confirmUnsavedDialog, openModal, closeModal } from '../ui.js';
import { icon } from '../icons.js';
import { remote } from '../data/remote-ds.js';
import { notifyError } from '../data/errors.js';
import { hasFeature, gateFeature } from '../data/plan-features.js';
import { t, tf } from '../i18n.js';
import { PROXY_TYPES, PROXY_TYPE_DEFAULT, normalizeProxyType } from '../data/proxy-types.js';
// Bộ sinh ngẫu nhiên vân tay (UA, WebGL metadata, GPU pool, device/MAC, seed,
// fp-config builder) - tách riêng tại data/fingerprint.js.
import { uaString, osGpu, osDeviceName, osHardware, randMac, newFingerprint, buildFpConfig, WEBGL_VENDORS, osFonts, setAllPools, hasPools, chromeMajors, firefoxMajors, randomChromeFull, TIMEZONES, LOCALES, RESOLUTIONS } from '../data/fingerprint.js';
// Modal tải nhân + đồng bộ fingerprint theo nhân đang dùng (dùng cho dropdown
// "Trình duyệt": chỉ nhân ĐÃ CÀI mới chọn được; bản CHƯA CÀI bấm vào sẽ mở modal tải).
import { openKernelDownloadModal, syncActiveKernelToFingerprint } from './kernels.js';
// Nhãn engine + nhãn dòng "Browser Kernel": DÙNG CHUNG với màn tạo-hàng-loạt và với
// các lưới hồ sơ. Trước đây mỗi màn tự chép một bản kernelLabel() hardcode "Chromium"
// nên bấm sang thẻ Firefox mà bảng Tổng quan vẫn trơ ra "(Chromium 140)".
import { ENGINE_LABEL, kernelLabel } from '../data/browser-badge.js';

const KERNEL_PLATFORM = 'win-x64';

// Hai nhân: Chromium đã vá ("ChromeBrowser", val nội bộ 'Poly' để không phá logic
// UA/fp) và Firefox đã vá ("FirefoxBrowser", val 'Firefox'). Cả hai nhận cùng blob
// --fp-config nên fpConfig/UA dựng CHUNG một đường; khác biệt chỉ ở tầng launcher.
// [val, label, opts] - opts.icon: tên icon; opts.disabled: khoá hover/click.
const KERNELS = [
  ['Poly', 'ChromeBrowser', { icon: 'chrome' }],
  ['Firefox', 'FirefoxBrowser', { icon: 'firefox' }],
];
// Nhân UI ('Poly'/'Firefox') → engine kho nhân ('chromium'/'firefox'). Dùng để
// tải đúng danh sách nhân theo engine và ghim engine vào meta hồ sơ.
function engineOf(kernel) { return kernel === 'Firefox' ? 'firefox' : 'chromium'; }
// Danh sách phiên bản ĐẦY ĐỦ theo từng OS, khớp 1:1 với AdsPower (mục "Thao tác
// hệ thống"). Mỗi menu còn có thêm mục "All <OS>" ở đầu (xem renderOsInt) - chọn
// nó sẽ random ra MỘT phiên bản cụ thể (hồ sơ đơn luôn ứng với một phiên bản thật).
//   • Windows/macOS: token OS trong UA bị Chrome ĐÓNG BĂNG (NT 10.0 / 10_15_7) nên
//     phiên bản chỉ là nhãn hiển thị; vẫn liệt kê đủ để khớp AdsPower.
//   • Linux: UA chỉ "X11; Linux x86_64", KHÔNG lộ distro → AdsPower cũng chỉ có một
//     mục ("All Linux") → ta để một mục "Linux x86_64".
//   • Android/iOS: phiên bản OS THỰC SỰ vào UA → bám theo lựa chọn.
// macOS 26 / iOS 26 là cách đặt tên theo năm của Apple (WWDC 2025, nhảy từ 15→26).
const OS_GROUPS = [
  { os: 'Windows', icon: 'windows', versions: ['Windows 11', 'Windows 10', 'Windows 8', 'Windows 7'] },
  { os: 'macOS', icon: 'apple', versions: ['macOS 26', 'macOS 15', 'macOS 14', 'macOS 13', 'macOS 12', 'macOS 11', 'macOS 10'] },
  { os: 'Linux', icon: 'linux', versions: ['Linux x86_64'] },
  { os: 'Android', icon: 'android', versions: ['Android 15', 'Android 14', 'Android 13', 'Android 12', 'Android 11', 'Android 10', 'Android 9'] },
  { os: 'iOS', icon: 'ios', versions: ['iOS 26', 'iOS 18', 'iOS 17', 'iOS 16', 'iOS 15', 'iOS 14', 'iOS 13'] },
];

// Section descriptors drive both the tab bar and the scrollspy.
const SECTIONS = [
  ['general', 'Cài đặt chung'],
  ['proxy', 'Proxy'],
  ['fingerprint', 'Dấu vân tay'],
  ['advanced', 'Nâng cao'],
];

// ---- user-agent + fingerprint model -----------------------------------
// uaString / randMac / randDevice → data/fingerprint.js (import ở đầu file).

// OS_GPU / osGpu / osDeviceName / newFingerprint → data/fingerprint.js.
// Nhãn dòng "Browser Kernel" → kernelLabel(engine, major) ở data/browser-badge.js.
// Nó BÁM ĐÚNG cả engine đang chọn lẫn major đang chọn (kernelVer); chưa chọn/chưa tải
// xong danh sách thì lùi về nhân đang dùng CỦA ĐÚNG ENGINE ĐÓ.

function overviewRows(fp, kernel, ua, osVersion, kernelVer) {
  // "Dựa trên IP" chỉ là tuỳ chọn - giá trị thật (múi giờ/toạ độ/ngôn ngữ) CHỈ được
  // dò từ ipinfo.io/json đúng lúc MỞ profile (xem applyProxyGeo trong ipc.js), nên ở
  // màn tạo/sửa chỉ hiển thị nguyên nhãn tuỳ chọn, không fetch trước.
  return [
    ['Browser Kernel', kernelLabel(engineOf(kernel), kernelVer)],
    ['Hệ điều hành', osVersion || ''],
    ['User-Agent', ua],
    ['Múi giờ', fp.timezone], ['WebRTC', fp.webRTC], ['Địa chỉ', fp.geo], ['Ngôn ngữ', fp.language],
    ['Ngôn ngữ hiển thị', fp.displayLanguage],
    ['Độ phân giải', fp.resolution], ['Canvas', fp.canvas],
    ['Avatar WebGL', fp.webglImage], ['AudioContext', fp.audioContext],
    ['Thiết bị truyền thông', fp.mediaDevice], ['SpeechVoices', fp.speechVoice],
    ['ClientRects', fp.clientRects],
    ['WebGL metadata', fp.webglMeta], ['WebGPU', fp.webGPU],
    ['CPU', tf('{0} Nhân', fp.cpu)], ['RAM', `${fp.ram} GB`], ['Tên thiết bị', fp.deviceName], ['Địa chỉ MAC', fp.mac],
    ['Do Not Track', fp.doNotTrack], ['Tăng tốc phần cứng', fp.hardwareAccel],
    ['Hiển thị hình ảnh', fp.imageLoad], ['Âm thanh', fp.audioPlay],
  ];
}

// ---- fp-config builder -------------------------------------------------
// genSeed / navPlatform / buildFpConfig → data/fingerprint.js (import ở đầu file).

// ---- small reusable controls ------------------------------------------
// Horizontal field row: label on the left, control on the right.
// opts.extra marks a field whose concept has NO counterpart in the CGTBrowser
// fp-config JSON schema (it is display-only / app-level), so its label is shown
// in red to flag that it is not part of the antidetect fingerprint config.
const frow = (label, control, opts = {}) =>
  el('div.pc-frow' + (opts.required ? '.req' : ''), {}, [
    el('div.pc-flabel' + (opts.extra ? '.extra' : ''), {
      // opts.labelHtml: cho phép ngắt dòng tường minh (vd nhãn dài muốn wrap 2 dòng
      // để cân đối chiều cao với control nhiều dòng); mặc định dùng text thuần.
      [opts.labelHtml ? 'html' : 'text']: opts.labelHtml || label,
      title: opts.extra ? 'Tùy chọn này không có trong fp-config (chỉ ở ứng dụng)' : undefined,
    }),
    el('div.pc-fctl', {}, Array.isArray(control) ? control : [control]),
  ]);

// Segmented control (same look as the Theme selector in Cài đặt): one rounded
// track holding the options, no per-option border. `options` accepts
// ['Label', ...] | [[value, label], ...] | [[value, label, iconName], ...].
function pills(options, value, onChange) {
  const norm = options.map((o) => (Array.isArray(o) ? o : [o, o]));
  const wrap = el('div.seg.pc-seg');
  function render() {
    clear(wrap);
    norm.forEach(([v, l, ic, tip]) => {
      wrap.appendChild(el('button.seg-opt' + (v === value ? '.active' : ''), {
        type: 'button',
        title: tip || undefined,
        html: (ic ? icon(ic) : '') + `<span>${l}</span>`,
        onclick: () => { value = v; render(); onChange && onChange(v); },
      }));
    });
  }
  render();
  Object.defineProperty(wrap, 'value', { get: () => value });
  return wrap;
}

function switchEl(on, onChange) {
  let state = !!on;
  const btn = el('button.switch' + (state ? '.on' : ''), { type: 'button' }, [el('span.knob')]);
  btn.onclick = () => { state = !state; btn.classList.toggle('on', state); onChange && onChange(state); };
  Object.defineProperty(btn, 'on', { get: () => state });
  return btn;
}

function checkRow(label, checked) {
  const cb = el('input', { type: 'checkbox' });
  cb.checked = !!checked;
  return { row: el('label.pc-check', {}, [cb, el('span', { text: label })]), cb };
}

// Bộ chọn "Nhóm": combobox TÌM-KIẾM + TẠO NHANH (giống AdsPower). Trigger dùng
// .pc-select-trigger để ĐỒNG NHẤT với mọi combobox khác ("Nhà cung cấp"); panel
// mở ra có ô tìm, danh sách nhóm (tick nhóm đang chọn), dòng "Tạo …" khi gõ tên
// mới, và "Không có dữ liệu" khi rỗng. Tạo nhóm gọi remote.groups.create.
function groupPicker(initialGroups, value, onChange) {
  let groups = (initialGroups || []).slice();
  let val = value || '';
  const wrap = el('div.pc-select.gsel');
  const trigger = el('button.pc-select-trigger', { type: 'button' });
  const panel = el('div.tagsel-panel.gsel-panel');
  const optList = el('div.tagsel-opts');
  const search = el('input.tagsel-add-input', { placeholder: 'Tìm nhóm/ Tạo nhóm' });
  const nameOf = (id) => { if (!id) return 'Chưa chia nhóm'; const g = groups.find((x) => x.id === id); return g ? g.name : 'Chưa chia nhóm'; };
  function renderTrigger() { trigger.innerHTML = `<span class="lbl${val ? '' : ' ph'}">${nameOf(val)}</span><span class="chev">${icon('chevronDown')}</span>`; }
  function setVal(id) { val = id; renderTrigger(); if (onChange) onChange(val); }
  async function createGroup() {
    const name = search.value.trim(); if (!name) return;
    try { const ng = await remote.groups.create({ name }); if (ng && ng.id) { groups.push(ng); setVal(ng.id); } close(); toast('Đã tạo nhóm', 'ok'); }
    catch (e) { toast('Lỗi tạo nhóm: ' + ((e && e.message) || e), 'err'); }
  }
  function renderOpts() {
    clear(optList);
    const q = search.value.trim().toLowerCase();
    const rows = [{ id: '', name: 'Chưa chia nhóm' }, ...groups].filter((g) => !q || g.name.toLowerCase().includes(q));
    rows.forEach((g) => {
      const on = g.id === val;
      optList.appendChild(el('div.tagsel-opt' + (on ? '.sel' : ''), { onclick: () => { setVal(g.id); close(); } },
        [el('span.tagsel-opt-lbl', { text: g.name }), on ? el('span.tagsel-ck', { html: icon('check') }) : null]));
    });
    optList.appendChild(el('div.tagsel-empty.muted', { text: rows.length ? 'Không còn nội dung' : 'Không có dữ liệu' }));
  }
  const onDoc = (e) => { if (!wrap.contains(e.target)) close(); };
  function open() { wrap.classList.add('open'); renderOpts(); setTimeout(() => search.focus(), 0); document.addEventListener('mousedown', onDoc); }
  function close() { wrap.classList.remove('open'); document.removeEventListener('mousedown', onDoc); }
  trigger.onclick = () => { wrap.classList.contains('open') ? close() : open(); };
  search.oninput = renderOpts;
  search.onkeydown = (e) => { if (e.key === 'Enter') { e.preventDefault(); const q = search.value.trim().toLowerCase(); if (q && !groups.some((g) => g.name.toLowerCase() === q)) createGroup(); } };
  const addBtn = el('button.tagsel-addbtn', { type: 'button', html: '<span>Tạo</span>', onclick: createGroup });
  panel.appendChild(el('div.tagsel-add', {}, [el('span.tagsel-add-ico.gsel-add-ico', { html: icon('search') }), search, addBtn]));
  panel.appendChild(el('div.tagsel-div'));
  panel.appendChild(optList);
  wrap.appendChild(trigger); wrap.appendChild(panel);
  Object.defineProperty(wrap, 'value', { get: () => val, set: (v) => { val = v; renderTrigger(); }, configurable: true });
  wrap.setGroups = (list) => { groups = (list || []).slice(); renderTrigger(); };
  renderTrigger();
  return wrap;
}

// Bộ chọn "Tags": multi-select có ô tìm + tạo thẻ nhanh, hiển thị chip (giống ô
// "Thêm thẻ" ở danh sách hồ sơ). Empty state = "Không có dữ liệu". Đọc/ghi qua
// remote.tags; giá trị lấy ở .values (mảng tên thẻ) khi lưu hồ sơ.
function tagSelect(initialTags) {
  const current = new Set((initialTags || []).filter(Boolean));
  let allTags = [];
  const wrap = el('div.tagsel.pc-tagsel');
  const trigger = el('div.tagsel-trigger', { tabindex: '0' });
  const panel = el('div.tagsel-panel');
  const optList = el('div.tagsel-opts');
  let addInput;
  function renderTrigger() {
    clear(trigger);
    trigger.appendChild(el('span.tagsel-ico', { html: icon('tag') }));
    const chips = el('div.tagsel-chips');
    if (current.size) {
      [...current].forEach((t) => chips.appendChild(el('span.tagsel-chip', {}, [
        el('span', { text: t }),
        el('button.tagsel-x', { type: 'button', html: icon('close'), onclick: (e) => { e.stopPropagation(); current.delete(t); renderTrigger(); renderOpts(); } }),
      ])));
    } else { chips.appendChild(el('span.tagsel-ph', { text: 'Tags' })); }
    trigger.appendChild(chips);
    trigger.appendChild(el('span.tagsel-chev', { html: icon('chevronDown') }));
  }
  function renderOpts() {
    clear(optList);
    const raw = (addInput && addInput.value.trim()) || '';
    const q = raw.toLowerCase();
    const rows = allTags.filter((t) => !q || t.toLowerCase().includes(q));
    rows.forEach((t) => {
      const on = current.has(t);
      optList.appendChild(el('div.tagsel-opt' + (on ? '.sel' : ''), { onclick: () => { on ? current.delete(t) : current.add(t); renderTrigger(); renderOpts(); } },
        [el('span.tagsel-opt-lbl', { text: t }), on ? el('span.tagsel-ck', { html: icon('check') }) : null]));
    });
    const exact = allTags.some((t) => t.toLowerCase() === q);
    if (raw && !exact) optList.appendChild(el('div.tagsel-opt.gsel-create', { onclick: addNew },
      [el('span.tagsel-opt-lbl', { html: `Tạo "<b>${raw}</b>"` }), el('span.tagsel-ck.ent', { text: '↵' })]));
    else if (!rows.length) optList.appendChild(el('div.tagsel-empty.muted', { text: 'Không có dữ liệu' }));
  }
  function addNew() {
    const v = addInput.value.trim(); if (!v) return;
    if (!allTags.includes(v)) { allTags.push(v); allTags.sort((a, b) => a.localeCompare(b)); remote.tags.create(v); }
    current.add(v); addInput.value = ''; renderTrigger(); renderOpts(); addInput.focus();
  }
  addInput = el('input.tagsel-add-input', { placeholder: 'Tìm tab/ Tạo tab',
    oninput: () => renderOpts(),
    onkeydown: (e) => { if (e.key === 'Enter') { e.preventDefault(); addNew(); } } });
  panel.appendChild(el('div.tagsel-add', {}, [el('span.tagsel-add-ico.gsel-add-ico', { html: icon('search') }), addInput]));
  panel.appendChild(el('div.tagsel-div'));
  panel.appendChild(optList);
  const onDoc = (e) => { if (!wrap.contains(e.target)) close(); };
  function open() { wrap.classList.add('open'); renderOpts(); setTimeout(() => addInput.focus(), 0); document.addEventListener('mousedown', onDoc); }
  function close() { wrap.classList.remove('open'); document.removeEventListener('mousedown', onDoc); }
  trigger.onclick = () => { wrap.classList.contains('open') ? close() : open(); };
  wrap.appendChild(trigger); wrap.appendChild(panel);
  remote.tags.list().then((list) => { allTags = (list || []).slice().sort((a, b) => a.localeCompare(b)); });
  Object.defineProperty(wrap, 'values', { get: () => [...current], configurable: true });
  renderTrigger();
  return wrap;
}

export function render(ctx) {
  // When ctx.param is a profile id we are EDITING that profile in this same tab
  // (the grid's kebab/pencil "Chỉnh sửa" routes here). Otherwise it is a create.
  const editId = ctx && ctx.param ? ctx.param : null;
  let groups = [];
  // "Hủy" và "Lưu" đều rời trang có CHỦ Ý → không hỏi lại. Chỉ điều hướng từ bên
  // ngoài (thanh bên, header) mới phải xác nhận.
  let leaving = false;
  const back = () => { leaving = true; ctx.navigate('profiles'); };
  // build() đăng ký {isDirty, save} ra đây để router hỏi được (form nằm trong scope
  // riêng của build). Chỉ đặt ở chế độ SỬA.
  let formGuard = null;

  // ----- profile state (defaults; overridden by the loaded profile in edit mode) -----
  let kernel = 'Poly';
  let os = 'Windows';
  let osVersion = OS_GROUPS[0].versions[0];
  // Proxy: 4 tab giống thiết kế tham chiếu. Hiện CHỈ là UI (chưa nối vào doSave/
  // fp-config) - giữ state để sau wiring theo proxy-auth contract nếu cần.
  let proxyTab = 'none';
  const proxyData = { type: 'HTTP', host: '', port: '', user: '', pass: '', token: '', rotateUrl: '' };
  let uaAuto = !editId;            // edit mode preserves the stored User-Agent
                                  // (until the user explicitly changes OS - see OS handlers below,
                                  //  which re-enable uaAuto so the UA follows the new OS for consistency)
  // ---------------------------------------------------------- trạng thái THEO ENGINE
  // Poly (Chromium) và Firefox là HAI kho nhân KHÔNG liên quan gì nhau: Chrome 140 chẳng
  // dính dáng gì Firefox 140. Mọi thứ bám theo nhân vì thế phải TÁCH ĐÔI - danh sách nhân,
  // major hiển thị trên card, và cặp ghim User-Agent. Trước đây cả hai engine xài CHUNG
  // một bộ biến rồi xoá sạch mỗi lần đổi nhân, gây hai lỗi hiển thị:
  //   1) card Firefox trưng số phiên bản của Chrome (cùng đọc một biến),
  //   2) bấm dropdown là phải gọi mạng tải lại catalog ⇒ menu hiện "Đang tải…" rồi số
  //      phiên bản nhảy - đúng cái nhấp nháy người dùng thấy.
  // Nay mỗi engine giữ kho RIÊNG, nạp sẵn CẢ HAI ngay khi mở trang ⇒ đổi qua lại là tức
  // thì, không gọi mạng lại, không nhấp nháy, và không engine nào đọc trúng số của engine kia.
  const engState = {
    chromium: { items: null, loading: false, ver: '153', uaVer: '', uaFull: '' },
    firefox: { items: null, loading: false, ver: '135', uaVer: '', uaFull: '' },
  };
  const ES = (e) => engState[e] || engState.chromium;
  // 4 biến dưới đây là "ô kính" của engine ĐANG CHỌN - luôn là bản sao của ES(engine hiện
  // tại). stashEngine/applyEngine giữ hai bên khớp nhau mỗi khi đổi nhân; code phía dưới
  // cứ đọc/ghi bình thường như trước, không phải nhớ engine nào.
  let chromeVer = '';              // '' = "Tất cả" (theo kernel thật); hoặc major đã ghim
  let chromeFull = '';             // full-version THẬT đã đổ (random trong dải major); '' = mặc định kernel
  let kernelVer = '153';           // major nhân HIỂN THỊ trên card "Trình duyệt" - ĐỘC LẬP với UA
                                  // (chọn UA ở combobox User-Agent không được đổi nhãn card này)
  let kernelItems = null;          // catalog server ∪ đã-cài của engine hiện tại; null = chưa tải
  let pendingAutoLatest = '';      // card đang chờ tự-chọn-bản-mới-nhất khi catalog về (bấm lúc chưa tải xong)
  // Cất trạng thái đang hiển thị vào kho của engine `e` (gọi TRƯỚC khi rời engine đó).
  function stashEngine(e) {
    const s = ES(e);
    s.items = kernelItems; s.ver = kernelVer; s.uaVer = chromeVer; s.uaFull = chromeFull;
  }
  // Kéo trạng thái đã lưu của engine `e` ra ô kính (gọi SAU khi đã đổi sang engine đó).
  function applyEngine(e) {
    const s = ES(e);
    kernelItems = s.items; kernelVer = s.ver; chromeVer = s.uaVer; chromeFull = s.uaFull;
  }
  let fp = newFingerprint();
  // seed values applied to controls when build() runs (filled in edit mode)
  let seedName = '', seedNote = '', seedUA = '', curGroupId = '', seedTags = '', seedCookies = '';

  // The form is built by build(). In edit mode we first load the profile and
  // seed the state above, then build with everything pre-filled; create mode
  // builds immediately.
  const host = el('div.page.pc-page');
  ctx.container.appendChild(host);

  function build() {
  clear(host);

  const nameInput = el('input.input', { placeholder: 'Nhập tên hồ sơ', maxlength: 100, value: seedName, oninput: () => renderOverview() });
  const groupSel = groupPicker(groups, curGroupId);
  const groupHost = el('div.pc-fctl-inner', {}, [groupSel]);
  const cookiesBox = el('textarea.input', { rows: 3, placeholder: 'Nhập Cookie' });
  cookiesBox.value = seedCookies;
  // Khi CHỈNH SỬA: kéo cookie THẬT đã tích luỹ của hồ sơ (giải mã từ file trên
  // máy) vào ô - chỉ ghi đè khi người dùng chưa chỉnh tay (giá trị == seed).
  if (editId) {
    // Ưu tiên cookie THẬT đã tích luỹ (đọc từ file trên máy). Nếu hồ sơ chưa từng mở
    // (chưa có cookie thật) thì nạp lại cookie SEED người dùng đã dán - cũng lưu LOCAL
    // (không còn nằm trong fingerprint server). Chỉ ghi đè khi người dùng chưa sửa tay.
    (async () => {
      try {
        const r = await remote.profiles.readCookies(editId);
        if (r && r.ok && r.count > 0) {
          if (cookiesBox.value === seedCookies) cookiesBox.value = r.text;
          return;
        }
      } catch { /* ignore */ }
      try {
        const seedText = await remote.profiles.readCookieSeed(editId);
        if (seedText && cookiesBox.value === seedCookies) cookiesBox.value = seedText;
      } catch { /* ignore */ }
    })();
  }
  const noteBox = el('textarea.input', { rows: 3, placeholder: 'Hãy nhập ghi chú', maxlength: 2000 });
  noteBox.value = seedNote;
  const uaInput = el('input.input.pc-ua', { value: seedUA || uaString(kernel, os, osVersion) });

  // ----- overview (right column) -----
  const ovList = el('div.pc-ov-list');
  function renderOverview() {
    clear(ovList);
    overviewRows(fp, kernel, uaInput.value, osVersion, kernelVer).forEach(([k, v]) => {
      ovList.appendChild(el('div.pc-ov-row', {}, [el('span.k', { text: k }), el('span.v', { text: v })]));
    });
  }

  // Full-version THẬT của nhân theo major đang chọn ở card "Trình duyệt": lấy từ
  // kernelItems (đã cài) - chính là version bóc tách từ folder nhân (vd 140.0.7339.264).
  // Không có (chưa tải xong / chưa cài) → rỗng.
  // Chromium phát UA full-build 4 số (140.0.7339.264) nên đòi đúng 4 nhóm; Firefox đánh
  // số 3 nhóm (152.0.6) và UA chỉ lấy major, nên chấp nhận dạng nhiều nhóm bất kỳ.
  function kernelFullFor(major) {
    if (!major || !Array.isArray(kernelItems)) return '';
    const it = kernelItems.find((k) => k.installed && String(k.major) === String(major));
    if (!it || !it.version) return '';
    const ok = engineOf(kernel) === 'firefox'
      ? /^\d+(\.\d+)*$/.test(it.version)
      : /^\d+\.\d+\.\d+\.\d+$/.test(it.version);
    return ok ? it.version : '';
  }
  // "Tất cả" (chưa chọn UA cụ thể) → UA đúng FULL-BUILD của nhân chromium đã tải/đang
  // chọn ở card "Trình duyệt" (kernelVer), vd Chrome/140.0.7339.264. Đã chọn UA cụ thể
  // (chromeFull) → dùng full-build đó. Dự phòng (chưa có version): major.0.0.0.
  function syncUA() {
    if (uaAuto) {
      // Dự phòng khi chưa biết full-version: Chromium cần đủ 4 số, Firefox chỉ cần major.
      const fallback = kernelVer
        ? (engineOf(kernel) === 'firefox' ? String(kernelVer) : `${kernelVer}.0.0.0`)
        : '';
      const full = chromeFull || kernelFullFor(kernelVer) || fallback;
      uaInput.value = uaString(kernel, os, osVersion, full);
    }
    renderOverview();
  }
  // Đổ lại UA: random MỘT build THẬT trong dải major đã chọn (rỗng = "Tất cả" → kernel
  // thật). Gọi khi chọn major, bấm "Tạo lại" (shuffle), hoặc "Sửa vân tay mới".
  // Firefox KHÔNG có bảng build như CHROME_BUILDS (và UA cũng chỉ lộ major) nên không
  // random gì cả: ghim major nào thì lấy đúng full-version của nhân đó.
  function rerollUA() {
    if (engineOf(kernel) === 'firefox') {
      chromeFull = chromeVer ? (kernelFullFor(chromeVer) || String(chromeVer)) : '';
    } else {
      chromeFull = chromeVer ? randomChromeFull(chromeVer) : '';
    }
    uaAuto = true; syncUA();
  }

  // GPU/WebGL + Fonts lấy POOL TỪ SERVER (fp_gpus/fp_fonts). Fetch TOÀN BỘ catalog
  // (5 OS) đúng 1 lần rồi cache trong fingerprint.js → đổi OS sau đó tức thì, không
  // gọi mạng. Thiếu (offline) → dùng fallback built-in.
  async function ensurePools(clientOs) {
    if (hasPools(clientOs)) return;
    try { setAllPools(await remote.fingerprintCatalog()); } catch { /* fallback built-in */ }
  }

  // Đổ GPU + Fonts (từ pool server) vào state + cập nhật ô hiển thị.
  function applyFontsFromPool() {
    fp.fontList = osFonts(os);
    fp.fonts = String(fp.fontList.length);
    if (typeof fontsInput !== 'undefined') fontsInput.value = fp.fonts;
  }

  // Keep OS-bound fingerprint facets (GPU vendor/renderer, fonts, machine name) in
  // lock-step with the selected OS so the profile never advertises e.g. a Mac GPU
  // under a Windows UA. Fetch pool server trước rồi reroll + cập nhật controls.
  async function applyOsConsistency() {
    await ensurePools(os);
    const g = osGpu(os);
    fp.webglVendor = g.vendor;
    fp.webglMeta = g.renderer;
    fp.deviceName = osDeviceName(os);
    // CPU/RAM bám OS + HẠNG GPU vừa chọn: không để iPhone/Android mang cấu hình
    // desktop, cũng không ghép card tích hợp với 32 nhân/128 GB. Truyền renderer
    // để osHardware phân hạng GPU.
    const hw = osHardware(os, g.renderer);
    fp.cpu = hw.cpu;
    fp.ram = hw.ram;
    applyFontsFromPool();
    if (typeof vendorSel !== 'undefined') vendorSel.value = fp.webglVendor;
    if (typeof rendererInput !== 'undefined') rendererInput.value = fp.webglMeta;
    if (typeof deviceInput !== 'undefined') deviceInput.value = fp.deviceName;
    if (typeof cpuSel !== 'undefined') cpuSel.value = fp.cpu + ' cores';
    if (typeof ramSel !== 'undefined') ramSel.value = fp.ram + ' GB';
    renderOverview();
  }

  // ----- General: "Trình duyệt" - card chọn kernel + dropdown phiên bản (mũi tên) -----
  // Card gồm: icon + tên kernel | ngăn cách dọc | nhãn phiên bản + chevron. Bấm phần
  // chevron mở menu các phiên bản Chrome (Tất cả / major 88..150) → đặt chromeVer +
  // rerollUA (đồng bộ luôn ô "User-Agent"). Bấm phần icon/tên = chọn kernel.
  const kernelSel = el('div.pc-kernels');
  // Nhãn phiên bản của ĐÚNG card đang render (không phải của nhân đang chọn): card
  // Firefox phải nói số Firefox kể cả khi đang chọn Poly. Chưa cài nhân engine đó ⇒
  // để TRỐNG, không mượn số của engine kia (card không được trưng phiên bản không có
  // trên máy này - cùng quy tắc với loadKernelList bên dưới).
  // Nhãn của ĐÚNG card đang render, không phải của nhân đang chọn: card Firefox phải nói
  // số Firefox kể cả khi đang chọn Poly. Chưa cài nhân engine đó ⇒ để TRỐNG, KHÔNG mượn số
  // của engine kia (card không được trưng phiên bản không tồn tại trên máy này).
  function verLabel(val) {
    const e = engineOf(val);
    const v = e === engineOf(kernel) ? kernelVer : ES(e).ver;
    return v ? String(v) : '';
  }
  // Ghi major hiển thị cho MỘT engine CHỈ ĐỊNH. Tách theo engine (KHÔNG theo `kernel` toàn
  // cục) là mấu chốt chống lỗi "chọn phiên bản nhảy sang trình duyệt khác": callback bất
  // đồng bộ - tải nhân xong (onDone), hay đường trễ pendingAutoLatest - có thể chạy SAU khi
  // người dùng đã bấm sang nhân khác; ghi theo `kernel` lúc đó là ghi nhầm engine. Chỉ cập
  // nhật ô kính kernelVer khi engine đó ĐANG được chọn (card kia không bị lây).
  function setKernelVerFor(eng, v) {
    const val = v ? String(v) : '';
    ES(eng).ver = val;
    if (eng === engineOf(kernel)) kernelVer = val;
  }
  function setKernelVer(v) { setKernelVerFor(engineOf(kernel), v); }
  // Áp phiên bản đã chọn cho MỘT engine + đồng bộ UA CHỈ khi engine đó đang được chọn
  // (đổi UA của engine đang KHÔNG hiển thị là sai vân tay), rồi vẽ lại thẻ.
  function applyKernelVer(eng, majStr) {
    setKernelVerFor(eng, majStr);
    if (eng === engineOf(kernel)) { uaAuto = true; syncUA(); }
    renderKernels();
  }

  // Đổi nhân trên thẻ "Trình duyệt". ĐỔI ENGINE (Poly↔Firefox) = đổi kho: cất trạng thái
  // engine cũ, lấy trạng thái engine mới ra. KHÔNG xoá gì và KHÔNG tải lại - kho đã được
  // primeEngines() nạp sẵn nên thao tác này tức thì; nhờ vậy dropdown không nhấp nháy và
  // quay lại engine cũ vẫn nguyên major + ghim UA đã chọn. Trả về true nếu có đổi.
  function selectKernel(val) {
    if (kernel === val) return false;
    const from = engineOf(kernel);
    const to = engineOf(val);
    kernel = val;
    if (from !== to) {
      stashEngine(from);
      applyEngine(to);
      // ĐỔI ENGINE thì UA BẮT BUỘC phải tính lại. Ở chế độ SỬA, uaAuto = false để giữ
      // nguyên UA đã lưu, nên trước đây bấm Poly→Firefox mà ô User-Agent (và dòng
      // User-Agent ở Tổng quan) vẫn trơ ra "Chrome/140…" - hồ sơ Firefox lưu kèm UA
      // Chrome là mâu thuẫn vân tay lộ ngay. Cùng lý do các handler đổi OS bật lại
      // uaAuto: đổi nhân là thay đổi CHỦ ĐỘNG, UA phải theo nhân mới.
      uaAuto = true;
      refreshUaVerOptions();   // danh sách major + giá trị ghim đổi sang engine mới
      loadKernelList(to);      // chỉ thực sự gọi mạng nếu kho engine đó còn trống
    }
    return true;
  }

  // Bấm CHỌN một card trình duyệt ⇒ mặc định lấy phiên bản MỚI NHẤT của nhân đó theo
  // catalog (KHÔNG chỉ bản đã cài như loadKernelList). Bản mới nhất CHƯA cài ⇒ TỰ ĐỘNG
  // mở modal tải rồi ghim sau khi tải xong (yêu cầu chủ sở hữu). Catalog chưa về ⇒ hẹn
  // lại qua pendingAutoLatest: loadKernelList().finally sẽ gọi lại hàm này khi có danh sách.
  function chooseLatestKernel(val) {
    // BẢO HIỂM CHỐNG CHỌN NHẦM SANG NHÂN KHÁC: chỉ áp dụng cho nhân ĐANG được chọn.
    // Đường TRỄ (qua pendingAutoLatest ở loadKernelList.finally) có thể chạy SAU khi người
    // dùng đã bấm sang nhân khác - lúc đó kernel !== val; nếu vẫn chạy thì setKernelVer sẽ
    // ghi phiên bản của nhân này vào ENGINE đang chọn (đúng lỗi "chọn nhầm phiên bản sang
    // trình duyệt khác"). Gặp thế thì bỏ qua và xoá cờ chờ.
    if (kernel !== val) { if (pendingAutoLatest === val) pendingAutoLatest = ''; return; }
    const cardEngine = engineOf(val);
    const items = cardEngine === engineOf(kernel) ? kernelItems : ES(cardEngine).items;
    if (items == null) { pendingAutoLatest = val; loadKernelList(cardEngine); return; }
    pendingAutoLatest = '';
    if (!items.length) return;
    const latest = items[0];            // items đã sắp major GIẢM DẦN ⇒ [0] là mới nhất
    const majStr = String(latest.major);
    if (latest.installed) {
      applyKernelVer(cardEngine, majStr);   // ghi ĐÚNG engine card này (không theo kernel toàn cục)
      return;
    }
    if (!latest.url) return;            // không có nguồn tải trên server ⇒ để nguyên
    openKernelDownloadModal({ ...latest, engine: cardEngine }, {
      onDone: () => {
        syncActiveKernelToFingerprint().catch(() => {});
        applyKernelVer(cardEngine, majStr);   // tải xong: ghi cho ĐÚNG engine dù người dùng đã đổi nhân
        loadKernelList(cardEngine, true);
      },
    });
  }

  // Nạp kho nhân (catalog server ∪ đã cài) của MỘT engine vào ES(e). Đã có kho thì thôi
  // (force = true khi vừa tải/gỡ nhân xong, cần cập nhật badge). Kết quả ghi thẳng vào
  // ES(e); chỉ đổ ra ô kính khi engine đó VẪN đang được chọn lúc kết quả về - người dùng
  // có thể đã bấm sang nhân khác trong lúc chờ mạng, ghi bừa là hai engine lẫn nhau.
  function loadKernelList(engine, force) {
    const e = engine || engineOf(kernel);
    const s = ES(e);
    if (s.loading) return;
    if (s.items && !force) return;
    s.loading = true;
    Promise.resolve(window.vt.kernel.list(e, KERNEL_PLATFORM))
      .then((r) => {
        const items = (r && r.ok && r.data && Array.isArray(r.data.items)) ? r.data.items : [];
        // Sắp phiên bản GIẢM DẦN theo major (không phụ thuộc thứ tự ở web admin/datagrid).
        // So sánh số để 140 > 99; major bằng nhau thì so version đầy đủ cho ổn định.
        items.sort((a, b) => {
          const am = Number(a.major) || 0, bm = Number(b.major) || 0;
          if (am !== bm) return bm - am;
          return String(b.version || '').localeCompare(String(a.version || ''), undefined, { numeric: true });
        });
        s.items = items;
        // Mặc định card "Trình duyệt" hiển thị nhân MỚI NHẤT đã cài (danh sách đã sắp
        // major giảm dần). Combobox User-Agent GIỮ mặc định "Tất cả" (không ghim major)
        // → UA theo kernel thật. Áp dụng cho CẢ tạo mới và sửa (khi chưa ghim nhân): thẻ
        // trình duyệt luôn theo nhân đã tải, không dính phiên bản UA của hồ sơ.
        // Nhân đã ghim mà nay KHÔNG còn cài (người dùng gỡ, hoặc mở hồ sơ trên máy khác)
        // ⇒ coi như chưa ghim: thẻ phải nói ĐÚNG nhân sẽ chạy, không được trưng một số
        // phiên bản không tồn tại trên máy này.
        if (s.ver && !items.some((k) => k.installed && String(k.major) === String(s.ver))) s.ver = '';
        let autoPinned = false;
        if (!s.ver) {
          const newest = items.find((k) => k.installed) || items.find((k) => k.major === 153) || items[0];
          if (newest) { s.ver = String(newest.major); autoPinned = true; }
        }
        if (engineOf(kernel) === e) {
          kernelItems = s.items; kernelVer = s.ver;
          if (autoPinned) syncUA();
        }
      })
      .catch(() => { s.items = []; if (engineOf(kernel) === e) kernelItems = s.items; })
      // Firefox lấy danh sách major cho ô "User-Agent" TỪ kho nhân, nên phải nạp lại ngay
      // khi catalog về (lúc dựng form nó còn null ⇒ danh sách rỗng).
      .finally(() => {
        s.loading = false; refreshUaVerOptions(); renderKernels();
        // Có card đang chờ tự-chọn-bản-mới-nhất (người dùng bấm lúc catalog chưa về) và
        // đúng engine vừa nạp xong ⇒ thực hiện việc chọn/tải bây giờ.
        if (pendingAutoLatest && engineOf(pendingAutoLatest) === e) chooseLatestKernel(pendingAutoLatest);
      });
  }

  // Nạp sẵn CẢ HAI engine ngay khi mở trang - đây là chỗ dập tắt nhấp nháy tận gốc:
  //   • kernel.installed(e): sổ cái nhân LOCAL, không qua mạng ⇒ nhãn phiên bản của cả hai
  //     card đúng gần như tức thì, không phải chờ catalog rồi mới nhảy số.
  //   • kernel.list(e): catalog server ∪ đã-cài cho dropdown; nạp NỀN cho cả engine chưa
  //     chọn để lúc bấm vào là menu có sẵn, không còn cảnh "Đang tải danh sách nhân…".
  function primeEngines() {
    [...new Set(KERNELS.map(([v]) => engineOf(v)))].forEach((e) => {
      const s = ES(e);
      Promise.resolve(window.vt.kernel.installed(e))
        .then((list) => {
          const arr = Array.isArray(list) ? list : [];
          // listInstalled đã sắp major giảm dần và tự loại nhân đã biến mất khỏi ổ đĩa.
          // GIỮ major đang ghim nếu vẫn còn cài; ô trống / nhân đã gỡ ⇒ lấy bản mới nhất.
          const keep = e === engineOf(kernel) ? kernelVer : s.ver;
          const next = (keep && arr.some((k) => String(k.major) === String(keep)))
            ? String(keep)
            : (arr.length ? String(arr[0].major) : (e === 'firefox' ? '135' : '153'));
          if (s.ver === next && (e !== engineOf(kernel) || kernelVer === next)) return;
          s.ver = next;
          if (e === engineOf(kernel)) { kernelVer = next; syncUA(); }
          renderKernels();
        })
        .catch(() => { /* không đọc được sổ cái ⇒ để trống, không bịa số */ });
      loadKernelList(e);
    });
  }

  // Card nào đang mở dropdown ('' = không có). Phải là STATE chứ không phải class trên
  // DOM: renderKernels() dựng lại toàn bộ card, nếu không nhớ thì mỗi lần catalog về
  // muộn (hoặc nhãn phiên bản cập nhật) là menu đang mở bị đóng phụt - chính là cái
  // "nhấp nháy" khi bấm vào dropdown.
  let openKernel = '';
  let offOutside = null;
  // Đăng ký/huỷ handler đóng-khi-bấm-ra-ngoài theo openKernel. Dùng MỘT handler ở cấp
  // document thay vì mỗi card một cái, để render lại không rải rác listener chồng nhau.
  function armOutsideClose() {
    if (offOutside) { document.removeEventListener('mousedown', offOutside); offOutside = null; }
    if (!openKernel) return;
    offOutside = (ev) => {
      if (kernelSel.contains(ev.target)) return;
      openKernel = '';
      document.removeEventListener('mousedown', offOutside); offOutside = null;
      kernelSel.querySelectorAll('.pc-kernel.open').forEach((r) => r.classList.remove('open'));
    };
    // Hoãn 1 nhịp để chính cú click đang mở menu không tự đóng nó.
    setTimeout(() => { if (offOutside) document.addEventListener('mousedown', offOutside); }, 0);
  }

  function renderKernels() {
    clear(kernelSel);
    KERNELS.forEach(([val, label, opts]) => {
      opts = opts || {};
      // Icon: 'chrome' = logo Poly (mask PNG); còn lại render SVG (vd firefox).
      const iconHtml = opts.icon === 'chrome'
        ? `<span class="pc-kernel-ico" role="img" aria-label="${label}"></span>`
        : `<span class="pc-kernel-ico pc-kernel-ico-svg" role="img" aria-label="${label}">${icon(opts.icon)}</span>`;

      // Kernel chưa hoàn thiện (FirefoxBrowser): hiện nhưng KHOÁ - không hover/click,
      // không dropdown phiên bản. (CSS .pc-kernel.disabled: pointer-events:none.)
      if (opts.disabled) {
        const dcard = el('div.pc-kernel.disabled', { title: 'Sắp ra mắt' });
        dcard.appendChild(el('span.pc-kernel-main', { html: iconHtml + `<span class="lbl">${label}</span>` }));
        // Vẫn hiện "|" + mũi tên cho giống Chrome (chỉ để nhìn, không bấm được). "|" là con
        // trực tiếp của card (ngoài trig) để đồng bộ với card thường.
        dcard.appendChild(el('span.pc-osint-div'));
        dcard.appendChild(el('span.pc-kernel-trig', {}, [
          el('span.verlbl'),
          el('span.chev', { html: icon('chevronDown') }),
        ]));
        kernelSel.appendChild(dcard);
        return;
      }

      const active = kernel === val;
      const card = el('div.pc-kernel' + (active ? '.sel' : ''));

      // Bấm chevron = chọn luôn nhân đó + mở/đóng menu. Ghi vào openKernel RỒI render lại
      // một lần duy nhất - không đụng tay vào class của card cũ (card sắp bị dựng lại).
      const toggleMenu = (e) => {
        e.stopPropagation();
        openKernel = openKernel === val ? '' : val;
        if (selectKernel(val)) syncUA();
        renderKernels();
      };

      const main = el('button.pc-kernel-main', {
        type: 'button',
        html: iconHtml + `<span class="lbl">${label}</span>`,
        // Bấm CHỌN card = chọn nhân + mặc định lấy phiên bản MỚI NHẤT (tự tải nếu chưa có).
        // Chỉ auto-chọn-mới-nhất khi card TRƯỚC ĐÓ chưa được chọn (tránh mở lại modal tải
        // mỗi lần bấm lại đúng card đang chọn).
        onclick: () => {
          const wasActive = active;
          if (selectKernel(val)) { renderKernels(); syncUA(); }
          if (!wasActive) chooseLatestKernel(val);
        },
      });

      // Ngăn cách "|" TÁCH RIÊNG (con trực tiếp của card, KHÔNG nằm trong nút trig) ⇒ bấm
      // vào "|" hay bên trái nó không mở dropdown; chỉ nút trig (bên phải "|") mới mở.
      const kdiv = el('span.pc-osint-div');
      const trig = el('button.pc-kernel-trig', { type: 'button', title: 'Phiên bản trình duyệt' }, [
        el('span.verlbl', { text: verLabel(val) }),
        el('span.chev', { html: icon('chevronDown') }),
      ]);
      trig.onclick = toggleMenu;

      // Menu phiên bản = NHÂN THẬT (không phải danh sách UA). Chỉ bản ĐÃ CÀI mới
      // chọn được; bản CHƯA CÀI hiện nhãn "Tải" và bấm vào sẽ MỞ MODAL TẢI (không
      // âm thầm chọn như trước). "Tất cả" = theo nhân đang dùng (UA tự động).
      // Mỗi card liệt kê nhân của CHÍNH engine nó (ES(engineOf(val))), không phải của nhân
      // đang chọn: menu Firefox luôn là các bản Firefox kể cả khi đang chọn Poly. Nhờ kho
      // tách đôi + nạp sẵn, mở menu là có ngay, không phải chờ tải rồi số nhảy.
      const cardEngine = engineOf(val);
      const cardItems = cardEngine === engineOf(kernel) ? kernelItems : ES(cardEngine).items;
      const cardVer = verLabel(val);
      const menu = el('div.pc-osint-menu.pc-kernel-menu');
      if (cardItems == null) {
        loadKernelList(cardEngine);
        menu.appendChild(el('div.pc-kernel-opt-empty', { text: 'Đang tải danh sách nhân…' }));
      } else {
        // Chỉ liệt kê nhân có trong catalog/đã cài (không phải toàn bộ 60+ major UA).
        cardItems.forEach((it) => {
          const majStr = String(it.major);
          const isSel = cardVer === majStr;
          const installed = !!it.installed;
          // Đã cài: KHÔNG hiện icon tải (chỉ nhãn + dấu check nếu đang chọn). Chưa cài:
          // ICON download (không nền, hover mới hiện nền tròn) - bấm vào mở modal tải.
          // Nhãn phiên bản CHỈ hiện số major (vd 140).
          const badge = installed ? '' : `<span class="pc-kernel-dl">${icon('download')}</span>`;
          const opt = el('button.pc-osint-opt.pc-kernel-opt' + (isSel ? '.sel' : '') + (installed ? '' : '.uninst'), {
            type: 'button',
            html: `<span class="lbl">${majStr}</span>` + badge + (isSel ? `<span class="ck">${icon('check')}</span>` : ''),
          });
          opt.onclick = () => {
            // Chọn phiên bản trong menu của card nào thì cũng CHỌN LUÔN nhân đó - menu và
            // nhân đang dùng không được lệch nhau (bấm bản Firefox mà vẫn đang chạy Poly).
            if (selectKernel(val)) syncUA();
            if (installed) {
              openKernel = '';
              applyKernelVer(cardEngine, majStr);   // ghi cho ĐÚNG engine của card này
              return;
            }
            // Chưa cài → mở modal tải; xong thì reload danh sách + tự chọn bản vừa cài.
            openKernel = '';
            card.classList.remove('open');
            // Nhân không còn nguồn tải trên server (admin đã gỡ / thiếu URL) → báo modal
            // rõ ràng thay vì mở modal tải rồi mới lỗi.
            if (!it.url) {
              alertDialog({
                title: 'Không tải được nhân',
                message: tf('Nhân {0} {1} hiện không có sẵn trên máy chủ. Vui lòng liên hệ quản trị viên hoặc chọn phiên bản khác.', ENGINE_LABEL[cardEngine], majStr),
              });
              return;
            }
            openKernelDownloadModal({ ...it, engine: cardEngine }, {
              onDone: () => {
                syncActiveKernelToFingerprint().catch(() => {});
                applyKernelVer(cardEngine, majStr);   // tải xong: ghi cho ĐÚNG engine dù đã đổi nhân
                loadKernelList(cardEngine, true);   // chỉ nạp lại kho ĐÚNG engine vừa tải
              },
            });
          };
          menu.appendChild(opt);
        });
        if (!cardItems.length) menu.appendChild(el('div.pc-kernel-opt-empty', { text: 'Không có nhân khả dụng' }));
      }

      if (openKernel === val) card.classList.add('open');
      card.appendChild(main);
      card.appendChild(kdiv);
      card.appendChild(trig);
      card.appendChild(menu);
      kernelSel.appendChild(card);
    });
    armOutsideClose();
  }
  renderKernels();
  primeEngines();   // nạp sẵn kho + nhãn phiên bản của CẢ HAI engine ⇒ không nhấp nháy

  const onGlobalKernelInstalled = (ev) => {
    const e = (ev && ev.detail && ev.detail.engine) || 'chromium';
    const maj = String((ev && ev.detail && ev.detail.major) || '153');
    ES(e).ver = maj;
    if (e === engineOf(kernel)) {
      kernelVer = maj;
    }
    loadKernelList(e, true);
    syncUA();
    renderKernels();
  };
  window.addEventListener('cgt:kernel-installed', onGlobalKernelInstalled);

  // ----- General: compact OS pills on one row: [checkbox] [icon] [chevron] -----
  // Each pill's chevron opens a dropdown of that OS's versions (with a check on
  // the active one). The checkbox / icon selects the OS itself.
  const osInt = el('div.pc-osint');
  function renderOsInt() {
    clear(osInt);
    OS_GROUPS.forEach((g) => {
      const active = os === g.os;
      const pill = el('div.pc-osint-row' + (active ? '.sel' : ''));
      const cb = el('input', { type: 'checkbox' });
      cb.checked = active;
      // Đổi OS qua checkbox: kéo osVersion về phiên bản đầu của OS mới để
      // "Hệ điều hành" (Tổng quan) + menu phiên bản không còn dính OS cũ.
      const selectOs = () => { os = g.os; osVersion = g.versions[0]; renderOsInt(); applyOsConsistency(); uaAuto = true; syncUA(); };
      cb.onchange = selectOs;

      const menu = el('div.pc-osint-menu');
      // "All <OS>" ở đầu menu (khớp AdsPower). Hồ sơ đơn luôn ứng với MỘT phiên bản
      // thật, nên chọn "All" = random một phiên bản cụ thể của OS đó. Bỏ qua khi OS
      // chỉ có 1 phiên bản (vd Linux) vì "All" không thêm ý nghĩa gì.
      if (g.versions.length > 1) {
        menu.appendChild(el('button.pc-osint-opt', {
          type: 'button',
          html: `<span class="lbl">All ${g.os}</span>`,
          onclick: () => { os = g.os; osVersion = g.versions[Math.floor(Math.random() * g.versions.length)]; renderOsInt(); applyOsConsistency(); uaAuto = true; syncUA(); },
        }));
      }
      g.versions.forEach((v) => {
        const isSel = active && osVersion === v;
        menu.appendChild(el('button.pc-osint-opt' + (isSel ? '.sel' : ''), {
          type: 'button',
          html: `<span class="lbl">${v}</span>` + (isSel ? `<span class="ck">${icon('check')}</span>` : ''),
          onclick: () => { os = g.os; osVersion = v; renderOsInt(); applyOsConsistency(); uaAuto = true; syncUA(); },
        }));
      });

      const trig = el('button.pc-osint-trig', { type: 'button', title: g.os }, [
        el('span.ic.ic-' + g.icon, { html: icon(g.icon) }),
        el('span.pc-osint-div'),
        el('span.chev', { html: icon('chevronDown') }),
      ]);
      trig.onclick = (e) => {
        e.stopPropagation();
        const willOpen = !pill.classList.contains('open');
        osInt.querySelectorAll('.pc-osint-row.open').forEach((r) => r.classList.remove('open'));
        if (willOpen) {
          pill.classList.add('open');
          const off = (ev) => { if (!pill.contains(ev.target)) { pill.classList.remove('open'); document.removeEventListener('mousedown', off); } };
          setTimeout(() => document.addEventListener('mousedown', off), 0);
        }
      };

      pill.appendChild(cb);
      pill.appendChild(trig);
      pill.appendChild(menu);
      osInt.appendChild(pill);
    });
  }
  renderOsInt();

  // Ô "User-Agent" (giống AdsPower): mặc định BỎ TRỐNG = "Tất cả" (theo kernel thật) -
  // hiển thị qua placeholder, KHÔNG còn item "Tất cả" trong danh sách. Danh sách chỉ gồm
  // các major Chrome đã biết → UA phát full-version thật của bản đó (CHROME_BUILDS).
  // chromeMajors() gọi LÚC DỰNG FORM (không phải lúc import) nên đã gồm cả major của
  // nhân mới tải về từ server - xem registerKernelBuild() trong fingerprint.js.
  // Danh sách major PHẢI theo ENGINE đang chọn, nếu không thì hồ sơ Firefox lại đi ghim
  // major Chrome (88..150) - đúng kiểu "phiên bản Chrome với Firefox lẫn nhau".
  // Chromium: bảng CHROME_BUILDS (chromeMajors). Firefox: firefoxMajors() - danh sách
  // ĐẦY ĐỦ ngang Chromium, cùng thời kỳ (85..152 vs 88..150).
  //
  // TRƯỚC ĐÂY Firefox chỉ lấy major của các nhân trong kho (kernelItems) nên dropdown
  // thường chỉ có ĐÚNG 1 mục (mỗi bản nhân đã build) - người dùng gần như không chọn
  // được phiên bản UA nào, trong khi Chromium có 63 mục. Nguyên nhân là hiểu nhầm "không
  // có bảng build ⇒ không có danh sách": UA Firefox chỉ lộ MAJOR nên không cần bảng build,
  // chỉ cần dải major (xem firefoxMajors trong fingerprint.js).
  //
  // Vẫn HỢP thêm major có trong kho nhân: server đẩy bản mới hơn ảnh chụp thì hiện ngay,
  // không phải chờ cài xong mới thấy.
  function uaVerOptions() {
    if (engineOf(kernel) === 'firefox') {
      const fromKernels = Array.isArray(kernelItems)
        ? kernelItems.map((k) => Number(k.major)).filter(Boolean)
        : [];
      const majors = [...new Set([...firefoxMajors(), ...fromKernels])].sort((a, b) => b - a);
      return majors.map((m) => ({ value: String(m), label: 'UA ' + m }));
    }
    return chromeMajors().map((m) => ({ value: String(m), label: 'UA ' + m }));
  }
  const uaVerSel = customSelect(uaVerOptions(), {
    value: chromeVer || '', width: 120, height: 40, placeholder: 'Tất cả',
    onChange: (v) => { chromeVer = v; rerollUA(); },
  });
  // Nạp lại danh sách major cho đúng engine (gọi khi đổi nhân và khi kernelItems về).
  // try/catch vì hàm này được gọi từ selectKernel/loadKernelList - cả hai khai báo TRƯỚC
  // `uaVerSel`, nên nếu có đường chạy nào chạm vào lúc form chưa dựng xong thì sẽ vướng
  // TDZ. Bỏ qua an toàn: lần render kế tiếp sẽ nạp lại danh sách.
  function refreshUaVerOptions() {
    try {
      if (uaVerSel && typeof uaVerSel.setOptions === 'function') uaVerSel.setOptions(uaVerOptions(), chromeVer || '');
    } catch { /* form chưa dựng xong */ }
  }
  const uaRefresh = el('button.icon-btn.pc-ua-btn', { html: icon('shuffle'), title: 'Tạo lại User-Agent', onclick: () => rerollUA() });
  // Đặt lại User-Agent về trạng thái "Tất cả": bỏ item UA đã chọn (chromeVer/chromeFull
  // rỗng), đưa combobox về placeholder "Tất cả" (gán .value không fire onChange), rồi
  // syncUA() để ô UA quay về UA chuẩn của nhân đang chọn.
  const uaReset = el('button.icon-btn.pc-ua-btn.pc-ua-btn-2nd', {
    html: icon('uaReset'), title: 'Đặt lại User-Agent (Tất cả)',
    onclick: () => { chromeVer = ''; chromeFull = ''; uaVerSel.value = ''; uaAuto = true; syncUA(); },
  });
  const tagsSel = tagSelect(seedTags ? seedTags.split(',').map((s) => s.trim()).filter(Boolean) : []);

  const secGeneral = el('section.pc-sec', { id: 'pcsec-general' }, [
    frow('Tên', nameInput, { required: true }),
    frow('Trình duyệt', kernelSel),
    frow('Hệ điều hành', osInt),
    frow('User-Agent', el('div.pc-ua-line', {}, [uaVerSel, uaInput, uaRefresh, uaReset])),
    frow('Nhóm', el('div.pc-group-row', {}, [groupHost, tagsSel]), { required: true }),
    frow('Cookie', cookiesBox),
    frow('Ghi chú', noteBox),
  ]);

  // ----- Proxy (tab-strip giống thiết kế tham chiếu) -----
  // 4 tab: Không sử dụng / Proxy thường / Proxy token / Proxy xoay. Mỗi tab đổi nội
  // dung bên dưới. Input ghi vào proxyData; doSave() gọi collectProxy() để lưu vào
  // dynamic → server metadata (lưới hiển thị qua proxyType/proxyHost/proxyPort).
  // Tab "Proxy thường" là proxy host:port nên combobox BỎ item 'Token' (token có tab RIÊNG
  // ngay bên cạnh) - user chốt 2026-10-03. KHÔNG mutate PROXY_TYPES (nguồn dùng chung): lọc
  // ra một mảng cục bộ. Giá trị khởi tạo cũng kẹp Token về mặc định để combobox không hiện
  // TRỐNG (customSelect vẽ ô trống khi value không khớp option nào).
  const NORMAL_PROXY_TYPES = PROXY_TYPES.filter((v) => v !== 'Token');
  const proxyTypeInit = (() => { const n = normalizeProxyType(proxyData.type); return n === 'Token' ? PROXY_TYPE_DEFAULT : n; })();
  const proxyTypeSel = customSelect(NORMAL_PROXY_TYPES,
    { value: proxyTypeInit, width: '100%', height: 40, onChange: (v) => { proxyData.type = v; } });
  const pHost = el('input.input', { value: proxyData.host, placeholder: 'Host IP', oninput: (e) => { proxyData.host = e.target.value; } });
  const pPort = el('input.input.pc-proxy-port', { value: proxyData.port, placeholder: 'Port', oninput: (e) => { proxyData.port = e.target.value; } });
  const pUser = el('input.input', { value: proxyData.user, placeholder: 'Username', oninput: (e) => { proxyData.user = e.target.value; } });
  const pPass = el('input.input', { type: 'password', value: proxyData.pass, placeholder: 'Password', oninput: (e) => { proxyData.pass = e.target.value; } });
  const pToken = el('input.input', { value: proxyData.token, placeholder: 'Proxy token', oninput: (e) => { proxyData.token = e.target.value; } });
  const pRotate = el('input.input', { value: proxyData.rotateUrl, placeholder: 'Link / API Proxy xoay', oninput: (e) => { proxyData.rotateUrl = e.target.value; } });

  // Sao chép proxy ra clipboard ở dạng host:port:user:pass (bỏ field trống).
  async function copyProxy(btn) {
    const parts = [proxyData.host, proxyData.port, proxyData.user, proxyData.pass].filter((x) => x && String(x).trim());
    if (!parts.length) { toast('Chưa có thông tin proxy để sao chép'); return; }
    const text = parts.join(':');
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) await navigator.clipboard.writeText(text);
      else { const ta = el('textarea', { value: text }); document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove(); }
      toast('Đã sao chép proxy', 'ok');
    } catch { toast('Không sao chép được'); }
  }

  // Kiểm tra proxy thật qua IPC proxy:check (geo.lookup chạy ipinfo QUA proxy) - THỦ CÔNG
  // (người dùng bấm nút), chỉ toast IP/quốc gia. Việc dò geoIP để áp múi giờ/ngôn ngữ/geo
  // chỉ diễn ra khi MỞ profile (applyProxyGeo trong ipc.js), không fetch trước ở màn này.
  async function checkProxy(btn) {
    if (!proxyData.host || !proxyData.port) { toast('Nhập Host và Port trước khi kiểm tra'); return; }
    btn.classList.add('is-loading'); btn.disabled = true;
    const lbl = btn.querySelector('.pc-shuffle-lbl');
    const old = lbl ? lbl.textContent : '';
    if (lbl) lbl.textContent = 'Đang kiểm tra…';
    try {
      const r = await window.vt.proxy.check({ type: proxyData.type, host: proxyData.host, port: proxyData.port, user: proxyData.user, pass: proxyData.pass });
      if (r && r.ok && r.geo) toast(`Proxy OK · ${r.geo.ip}${r.geo.country ? ' · ' + r.geo.country : ''}`, 'ok');
      else toast(r && r.error ? r.error : 'Không kết nối được proxy');
    } catch { toast('Lỗi khi kiểm tra proxy'); }
    finally { btn.classList.remove('is-loading'); btn.disabled = false; if (lbl) lbl.textContent = old; }
  }

  const copyBtn = () => { const b = el('button.btn.pc-shuffle', { html: `${icon('copy')}<span class="pc-shuffle-lbl">Sao chép</span>` }); b.onclick = () => copyProxy(b); return b; };
  const checkBtn = () => { const b = el('button.btn.pc-shuffle', { html: `${icon('sync')}<span class="pc-shuffle-lbl">Kiểm tra</span>` }); b.onclick = () => checkProxy(b); return b; };

  // Đồng bộ ô nhập TỪ proxyData - proxyData là nguồn sự thật duy nhất và không bao giờ
  // bị xoá khi đổi tab, nên dù chuyển "Không sử dụng" rồi quay lại "Proxy thường" thì
  // mọi thông số đã nhập đều được khôi phục nguyên vẹn (không mất).
  function syncProxyInputs() {
    pHost.value = proxyData.host || '';
    pPort.value = proxyData.port || '';
    pUser.value = proxyData.user || '';
    pPass.value = proxyData.pass || '';
    pToken.value = proxyData.token || '';
    pRotate.value = proxyData.rotateUrl || '';
  }
  function proxyContent() {
    syncProxyInputs();
    if (proxyTab === 'none') return el('div');
    if (proxyTab === 'normal') return el('div.pc-proxy-fields', {}, [
      proxyTypeSel,
      el('div.pc-proxy-hp', {}, [pHost, el('span.pc-proxy-colon', { text: ':' }), pPort]),
      pUser,
      pPass,
      el('div.pc-proxy-actions', {}, [copyBtn(), checkBtn()]),
    ]);
    if (proxyTab === 'token') return el('div.pc-proxy-fields', {}, [
      pToken,
      el('div.pc-proxy-actions.end', {}, [copyBtn()]),
    ]);
    return el('div.pc-proxy-fields', {}, [
      pRotate,
      el('div.pc-proxy-actions.end', {}, [copyBtn()]),
    ]);
  }

  // Tab menu giữ NGUYÊN kiểu cũ (segmented pills), chỉ đổi tên 4 tab + nội dung dưới.
  const PROXY_TABS = [['none', 'Không sử dụng'], ['normal', 'Proxy thường'], ['token', 'Proxy token'], ['rotate', 'Proxy xoay']];
  const proxyBody = el('div.pc-proxy-body');
  function renderProxyBody() { clear(proxyBody); proxyBody.appendChild(proxyContent()); }
  const proxyModePills = pills(PROXY_TABS, proxyTab, (v) => {
    proxyTab = v; renderProxyBody();
  });
  renderProxyBody();

  const secProxy = el('section.pc-sec', { id: 'pcsec-proxy' }, [
    el('div.pc-sec-head', { text: 'Proxy' }),
    frow('Proxy', proxyModePills),
    proxyBody,
  ]);

  // ----- Fingerprint (mirrors the reference 'Dấu vân tay' panel) -----
  const fpPill = (field, opts) => pills(opts, fp[field], (v) => { fp[field] = v; renderOverview(); });

  // Địa chỉ: a 3-way pill plus a radio sub-choice (Hỏi mỗi lần / Luôn cho phép)
  const geoRadios = el('div.pc-radios');
  function renderGeoRadios() {
    clear(geoRadios);
    ['Hỏi mỗi lần', 'Luôn cho phép'].forEach((l) => {
      const rb = el('input', { type: 'radio', name: 'geomode' });
      rb.checked = fp.geoMode === l;
      rb.onchange = () => { fp.geoMode = l; };
      geoRadios.appendChild(el('label.pc-radio', {}, [rb, el('span', { text: l })]));
    });
  }
  renderGeoRadios();

  // Múi giờ: pill; 'Tùy chỉnh' lộ ra dropdown chọn múi giờ IANA (giống AdsPower).
  const tzSel = customSelect(TIMEZONES,
    { value: fp.timezoneValue, width: '100%', height: 40, onChange: (v) => { fp.timezoneValue = v; renderOverview(); } });
  const tzWrap = el('div.pc-fctl-stack');
  const tzPill = pills(['Dựa trên IP', 'Thực', 'Tùy chỉnh'], fp.timezone, (v) => { fp.timezone = v; renderOverview(); drawTz(); });
  function drawTz() { clear(tzWrap); tzWrap.appendChild(tzPill); if (fp.timezone === 'Tùy chỉnh') tzWrap.appendChild(tzSel); }
  drawTz();

  // Địa chỉ: pill + radio (luôn hiện); 'Tùy chỉnh' lộ ô Vĩ độ/Kinh độ + Accuracy.
  const geoLatInput = el('input.input.pc-geo-in', { value: fp.geoLat, placeholder: 'Vĩ độ', oninput: (e) => { fp.geoLat = e.target.value; } });
  const geoLngInput = el('input.input.pc-geo-in', { value: fp.geoLng, placeholder: 'Kinh độ', oninput: (e) => { fp.geoLng = e.target.value; } });
  const geoAccInput = el('input.input', { type: 'number', value: fp.geoAccuracy, oninput: (e) => { fp.geoAccuracy = e.target.value; } });
  const geoPanel = el('div.pc-subpanel', {}, [
    frow('Vĩ độ / Kinh độ', el('div.pc-ua-line', {}, [geoLatInput, geoLngInput])),
    frow('Accuracy (m)', geoAccInput),
  ]);
  const geoWrap = el('div.pc-fctl-stack');
  const geoPill = pills(['Dựa trên IP', 'Tùy chỉnh', 'Block'], fp.geo, (v) => { fp.geo = v; renderOverview(); drawGeo(); });
  function drawGeo() { clear(geoWrap); geoWrap.appendChild(geoPill); geoWrap.appendChild(geoRadios); if (fp.geo === 'Tùy chỉnh') geoWrap.appendChild(geoPanel); }
  drawGeo();

  // Ngôn ngữ: pill; 'Tùy chỉnh' lộ DANH SÁCH locale (Accept-Language) thêm/xóa được.
  const langWrap = el('div.pc-fctl-stack');
  const langPanel = el('div.pc-subpanel.pc-langlist');
  function renderLangList() {
    clear(langPanel);
    fp.languageList.forEach((loc, i) => {
      const lbl = (LOCALES.find((o) => o.value === loc) || {}).label || loc;
      langPanel.appendChild(el('div.pc-lang-row', {}, [
        el('span.pc-lang-name', { text: lbl }),
        el('button.pc-lang-del', {
          type: 'button', text: '×', title: 'Xóa',
          onclick: () => { if (fp.languageList.length > 1) { fp.languageList.splice(i, 1); renderLangList(); renderOverview(); } },
        }),
      ]));
    });
    const avail = LOCALES.filter((o) => !fp.languageList.includes(o.value));
    const addSel = customSelect(avail, {
      placeholder: '+ Thêm ngôn ngữ', width: '100%', height: 38,
      onChange: (v) => { if (v) { fp.languageList.push(v); renderLangList(); renderOverview(); } },
    });
    langPanel.appendChild(el('div.pc-lang-add', {}, [addSel]));
  }
  renderLangList();
  const langPill = pills(['Dựa trên IP', 'Tùy chỉnh'], fp.language, (v) => { fp.language = v; renderOverview(); drawLang(); });
  function drawLang() { clear(langWrap); langWrap.appendChild(langPill); if (fp.language === 'Tùy chỉnh') langWrap.appendChild(langPanel); }
  drawLang();

  // Ngôn ngữ hiển thị: pill; 'Tùy chỉnh' lộ dropdown chọn 1 ngôn ngữ hiển thị.
  // Mỗi item: tên ngôn ngữ bên trái, mã viết tắt (vd 'vi') bên phải - giống AdsPower.
  const dlSel = customSelect(LOCALES.map((o) => ({ ...o, right: o.value })),
    { value: fp.displayLanguageValue, width: '100%', height: 40, onChange: (v) => { fp.displayLanguageValue = v; renderOverview(); } });
  const dlWrap = el('div.pc-fctl-stack');
  const dlPill = pills(['Dựa trên ngôn ngữ', 'Thực', 'Tùy chỉnh'], fp.displayLanguage, (v) => { fp.displayLanguage = v; renderOverview(); drawDl(); });
  function drawDl() { clear(dlWrap); dlWrap.appendChild(dlPill); if (fp.displayLanguage === 'Tùy chỉnh') dlWrap.appendChild(dlSel); }
  drawDl();

  // Độ phân giải: pill. 'Được xác định trước' lộ dropdown preset; 'Tùy chỉnh' nhập tay (rộng × cao).
  const resSel = customSelect(RESOLUTIONS,
    { value: fp.resolutionSize, width: '100%', height: 40, onChange: (v) => { fp.resolutionSize = v; renderOverview(); } });
  const resMatch = String(fp.resolutionSize || '').match(/(\d+)\s*x\s*(\d+)/i);
  const writeResSize = () => {
    const w = (resWIn.value || '').trim(); const h = (resHIn.value || '').trim();
    fp.resolutionSize = (w && h) ? `${w} x ${h}` : '';
    renderOverview();
  };
  // Điền số mẫu (1920 × 1080) thay vì để trống khi resolutionSize chưa phải dạng "W x H".
  const resWIn = el('input.input.pc-res-in', { type: 'number', min: '1', max: '9999', placeholder: '1~9999', value: resMatch ? resMatch[1] : '1920', oninput: writeResSize });
  const resHIn = el('input.input.pc-res-in', { type: 'number', min: '1', max: '9999', placeholder: '1~9999', value: resMatch ? resMatch[2] : '1080', oninput: writeResSize });
  const resCustom = el('div.pc-res-custom', {}, [resWIn, el('span.pc-res-x', { text: '×' }), resHIn]);
  const resWrap = el('div.pc-fctl-stack');
  const resPill = pills(['Ngẫu nhiên', 'Được xác định trước', 'Tùy chỉnh'], fp.resolution, (v) => { fp.resolution = v; renderOverview(); renderRes(); });
  function renderRes() {
    clear(resWrap); resWrap.appendChild(resPill);
    if (fp.resolution === 'Được xác định trước') resWrap.appendChild(resSel);
    // Khi chọn 'Tùy chỉnh', đồng bộ ngay số mẫu đang hiển thị vào fp.resolutionSize.
    else if (fp.resolution === 'Tùy chỉnh') { resWrap.appendChild(resCustom); writeResSize(); }
  }
  renderRes();

  // "Font chữ" ĐÃ BỎ khỏi UI: bộ font giờ được hook cứng trong CGTBrowser.exe nên
  // không cần điều khiển ở giao diện. fp.fontList/fp.fonts vẫn được applyFontsFromPool
  // đổ vào state để buildFpConfig dựng whitelist như cũ (không đổi hành vi JSON ở đây).

  // Tiếng ồn phần cứng: a wrapping row of on/off toggles (on = 'Nhiễu')
  function noiseItem(label, field, withEdit) {
    const sw = switchEl(fp[field] === 'Nhiễu', (v) => { fp[field] = v ? 'Nhiễu' : 'Thực'; renderOverview(); });
    const kids = [sw, el('span.pc-noise-lbl', { text: label })];
    if (withEdit) kids.push(el('span.pc-noise-edit', { text: 'Chỉnh sửa', onclick: () => toast('Chỉnh sửa thiết bị chưa được hỗ trợ') }));
    return el('div.pc-noise-item', {}, kids);
  }
  // "Thiết bị truyền thông" và "SpeechVoices" là 2 toggle ĐƯỢC PHÁT vào fp-config:
  //  - BẬT mediaDevice → media_devices.mode='spoof' + label camera/mic đúng OS.
  //  - BẬT speechVoice → speechVoices.whitelist = bộ giọng đúng OS.
  // (xem buildFpConfig + osMediaLabels/osVoices trong fingerprint.js). TẮT = giữ thật.
  const noiseRow = el('div.pc-noise-row', {}, [
    noiseItem('Canvas', 'canvas'),
    noiseItem('Avatar WebGL', 'webglImage'),
    noiseItem('AudioContext', 'audioContext'),
    noiseItem('Thiết bị truyền thông', 'mediaDevice'),
    noiseItem('SpeechVoices', 'speechVoice'),
    noiseItem('ClientRects', 'clientRects'),
  ]);

  // Siêu dữ liệu WebGL: Real / Tùy chỉnh; 'Tùy chỉnh' reveals a vendor+renderer panel.
  // "Tạo lại" re-rolls a vendor+renderer PAIR drawn from the current OS's pool so the
  // two never drift apart (e.g. a NVIDIA renderer under an Apple vendor).
  const vendorSel = customSelect(WEBGL_VENDORS,
    { value: fp.webglVendor, width: '100%', height: 40, onChange: (v) => { fp.webglVendor = v; renderOverview(); } });
  const rendererInput = el('input.input', { value: fp.webglMeta, oninput: (e) => { fp.webglMeta = e.target.value; renderOverview(); } });
  const rendererRefresh = el('button.icon-btn.pc-ua-btn', { html: icon('shuffle'), title: 'Tạo lại', onclick: () => {
    const g = osGpu(os);
    fp.webglVendor = g.vendor; fp.webglMeta = g.renderer;
    vendorSel.value = g.vendor; rendererInput.value = g.renderer;
    // Đổi card → CPU/RAM cũng phải đổi cho khớp hạng GPU mới.
    const hw = osHardware(os, g.renderer);
    fp.cpu = hw.cpu; fp.ram = hw.ram;
    if (typeof cpuSel !== 'undefined') cpuSel.value = fp.cpu + ' cores';
    if (typeof ramSel !== 'undefined') ramSel.value = fp.ram + ' GB';
    renderOverview();
  } });
  const webglPanel = el('div.pc-subpanel', {}, [
    frow('Nhà cung cấp', vendorSel),
    frow('Trình kết xuất', el('div.pc-ua-line', {}, [rendererInput, rendererRefresh])),
  ]);
  const webglWrap = el('div.pc-fctl-stack');
  const webglPill = pills(['Thực', 'Tùy chỉnh'], fp.webglMode, (v) => { fp.webglMode = v; renderWebgl(); });
  function renderWebgl() { clear(webglWrap); webglWrap.appendChild(webglPill); if (fp.webglMode === 'Tùy chỉnh') webglWrap.appendChild(webglPanel); }
  renderWebgl();

  // Mở rộng: collapsible block - CPU / RAM / device / MAC each toggle Real|Tùy chỉnh
  const cpuSel = customSelect(['3 cores', '4 cores', '6 cores', '8 cores', '10 cores', '12 cores', '16 cores', '20 cores', '24 cores', '32 cores', '64 cores'],
    { value: fp.cpu + ' cores', width: '100%', height: 40, onChange: (v) => { fp.cpu = parseInt(v, 10); renderOverview(); } });
  const ramSel = customSelect(['2 GB', '4 GB', '6 GB', '8 GB', '16 GB', '32 GB', '64 GB', '128 GB'],
    { value: fp.ram + ' GB', width: '100%', height: 40, onChange: (v) => { fp.ram = parseInt(v, 10); renderOverview(); } });
  const deviceInput = el('input.input', { value: fp.deviceName, oninput: (e) => { fp.deviceName = e.target.value; renderOverview(); } });
  const macInput = el('input.input', { value: fp.mac, oninput: (e) => { fp.mac = e.target.value; renderOverview(); } });
  const deviceRefresh = el('button.icon-btn.pc-ua-btn', { html: icon('shuffle'), title: 'Tạo lại', onclick: () => { fp.deviceName = osDeviceName(os); deviceInput.value = fp.deviceName; renderOverview(); } });
  const macRefresh = el('button.icon-btn.pc-ua-btn', { html: icon('shuffle'), title: 'Tạo lại', onclick: () => { fp.mac = randMac(); macInput.value = fp.mac; renderOverview(); } });

  // Real|Tùy chỉnh toggle that reveals `ctl` only when 'Tùy chỉnh' is chosen
  function customToggle(field, ctl) {
    const wrap = el('div.pc-fctl-stack');
    const pill = pills(['Thực', 'Tùy chỉnh'], fp[field], (v) => { fp[field] = v; draw(); });
    function draw() { clear(wrap); wrap.appendChild(pill); if (fp[field] === 'Tùy chỉnh') wrap.appendChild(ctl); }
    draw();
    return wrap;
  }

  // "Bảo vệ Port scan" ĐÃ BỎ khỏi UI (không được phát vào fp-config nên không đổi
  // hành vi launch). fp.portScan/portScanPorts giữ trong state mặc định, vô hại.
  const launchArgs = el('textarea.input', { rows: 3, placeholder: 'example:\n--disable-notifications\n--blink-settings=imagesEnabled=false', oninput: (e) => { fp.launchArgs = e.target.value; } });
  // <textarea> hiển thị nội dung qua .value (không phải attribute), nên phải gán tay -
  // nếu không, mở sửa hồ sơ ô sẽ trống dù fp.launchArgs đã lưu (giống noteBox). Gán lại
  // để giá trị thấy trên màn KHỚP đúng tham số được áp khi mở profile (buildLaunchOptionArgs).
  launchArgs.value = fp.launchArgs || '';

  const moreBlock = el('div.pc-more.open', {}, [
    frow('CPU', customToggle('cpuMode', cpuSel)),
    frow('RAM', customToggle('ramMode', ramSel)),
    frow('Tên thiết bị', customToggle('deviceMode', el('div.pc-ua-line', {}, [deviceInput, deviceRefresh]))),
    frow('Địa chỉ MAC', customToggle('macMode', el('div.pc-ua-line', {}, [macInput, macRefresh]))),
  ]);

  const secFingerprint = el('section.pc-sec', { id: 'pcsec-fingerprint' }, [
    el('div.pc-sec-head', { text: 'Dấu vân tay' }),
    frow('WebRTC', fpPill('webRTC', [
      ['Thực', 'Thực', null, 'Sử dụng IP thực của thiết bị hiện tại'],
      ['Vô hiệu hóa', 'Vô hiệu hóa', null, 'Chặn đọc tham số WebRTC'],
      ['Thay thế', 'Thay thế', null, 'Sử dụng IP WebRTC trùng khớp với proxy của bạn'],
      ['UDP qua proxy', 'UDP qua proxy', null, 'Ép mọi kết nối ICE đi qua proxy, chặn hoàn toàn UDP trực tiếp'],
    ])),
    frow('Múi giờ', tzWrap),
    frow('Địa chỉ', geoWrap),
    frow('Ngôn ngữ', langWrap),
    frow('Ngôn ngữ hiển thị', dlWrap),
    frow('Độ phân giải', resWrap),
    frow('Tiếng ồn phần cứng', noiseRow, { labelHtml: 'Tiếng ồn phần<br>cứng' }),
    frow('WebGL metadata', webglWrap),
    frow('WebGPU', fpPill('webGPU', ['Trùng với WebGL', 'Thực', 'Vô hiệu hóa'])),
    moreBlock,
  ]);

  // ----- Advanced -----
  const secAdvanced = el('section.pc-sec', { id: 'pcsec-advanced' }, [
    el('div.pc-sec-head', { text: 'Nâng cao' }),
    frow('Do Not Track', fpPill('doNotTrack', ['Mặc định', 'Mở', 'Đóng'])),
    frow('Tăng tốc phần cứng', fpPill('hardwareAccel', ['Mặc định', 'Mở', 'Đóng'])),
    frow('Hiển thị hình ảnh', fpPill('imageLoad', ['Cho phép', 'Chặn'])),
    frow('Âm thanh', fpPill('audioPlay', ['Cho phép', 'Chặn'])),
    frow('Vô hiệu hóa tính năng TLS', fpPill('tlsDisable', ['Mở', 'Đóng'])),
    frow('Khởi động tham số', launchArgs),
  ]);

  renderOverview();

  // ----- scrollable form + scrollspy -----
  const form = el('div.pc-form', {}, [secGeneral, secProxy, secFingerprint, secAdvanced]);

  const tabBar = el('div.tabs.pc-tabs');
  const tabBtns = {};
  function setActiveTab(key) {
    SECTIONS.forEach(([k]) => tabBtns[k] && tabBtns[k].classList.toggle('active', k === key));
  }
  let suppressSpy = false;
  let spyTimer = null;
  function scrollToSection(key) {
    const sec = form.querySelector('#pcsec-' + key);
    if (!sec) return;
    suppressSpy = true;
    setActiveTab(key);
    const top = sec.getBoundingClientRect().top - form.getBoundingClientRect().top + form.scrollTop;
    form.scrollTo({ top: Math.max(0, top - 4), behavior: 'smooth' });
    clearTimeout(spyTimer);
    spyTimer = setTimeout(() => { suppressSpy = false; }, 450);
  }
  function onFormScroll() {
    if (suppressSpy) return;
    // Đã cuộn chạm đáy → section CUỐI luôn active. Section cuối ("Nâng cao") thường
    // ngắn nên không thể đẩy đỉnh của nó lên sát đầu form → ngưỡng top<=16 không bao
    // giờ đạt được, làm tab kẹt ở section trước. Kiểm tra đáy để nhảy tab đúng.
    if (form.scrollTop + form.clientHeight >= form.scrollHeight - 4) {
      setActiveTab(SECTIONS[SECTIONS.length - 1][0]);
      return;
    }
    const ft = form.getBoundingClientRect().top;
    let cur = SECTIONS[0][0];
    for (const [key] of SECTIONS) {
      const sec = form.querySelector('#pcsec-' + key);
      if (sec && sec.getBoundingClientRect().top - ft <= 16) cur = key;
    }
    setActiveTab(cur);
  }
  form.addEventListener('scroll', onFormScroll);

  SECTIONS.forEach(([key, label]) => {
    const b = el('button.tab' + (key === 'general' ? '.active' : ''), { text: label, onclick: () => scrollToSection(key) });
    tabBtns[key] = b;
    tabBar.appendChild(b);
  });

  // Thu thập proxy theo tab đang chọn → các khóa "dynamic" mà server map vào
  // metadata jsonb (lưới đọc lại qua proxyType/proxyHost/...). proxyType rỗng = tắt
  // proxy (giữ host/port để bật lại) - khớp hợp đồng getProfileProxyConfig/getLaunchData.
  function collectProxy() {
    // LUÔN lưu lại mọi thông số proxy đã nhập (host/port/user/pass) - kể cả khi chọn
    // "Không sử dụng" - để bật lại không phải nhập lại. proxyType là CÔNG TẮC bật/tắt:
    // rỗng = tắt (getProfileProxyConfig trả null → launcher bỏ qua) nhưng dữ liệu vẫn còn.
    const out = {
      proxyType: '',
      proxyHost: String(proxyData.host || '').trim(),
      proxyPort: String(proxyData.port || '').trim(),
      proxyUser: String(proxyData.user || '').trim(),
      proxyPass: proxyData.pass || '',
    };
    if (proxyTab === 'normal' && out.proxyHost && out.proxyPort) {
      // Tab "Proxy thường" là proxy host:port, nên 'Token' trong combobox không áp được ở
      // đây (token có tab RIÊNG ngay bên cạnh) - rơi về HTTP thay vì lưu một proxyType
      // 'Token' mà lại không có proxyToken nào.
      const pt = normalizeProxyType(proxyData.type);
      out.proxyType = pt === 'Token' ? PROXY_TYPE_DEFAULT : pt;
    } else if (proxyTab === 'token') {
      const tok = String(proxyData.token || '').trim();
      if (tok) { out.proxyType = 'Token'; out.proxyToken = tok; }
    } else if (proxyTab === 'rotate') {
      const url = String(proxyData.rotateUrl || '').trim();
      if (url) { out.proxyType = 'Proxy Xoay'; out.proxyRotateUrl = url; }
    }
    return out;
  }

  // Gom TOÀN BỘ form thành đúng payload sẽ gửi lên server. Tách khỏi doSave() để
  // dùng lại cho việc phát hiện "có thay đổi chưa lưu" - vì vậy hàm này PHẢI thuần,
  // không tác dụng phụ (việc tự đặt tên khi bỏ trống nằm ở doSave).
  function collectPayload() {
    const n = nameInput.value.trim();
    const ua = uaInput.value.trim();
    // Khi nào PHÁT user_agent (UA string + client-hints) vào fp-config:
    //  1) Chọn 1 item UA cụ thể (chromeVer có giá trị) → hook đúng phiên bản đã chọn.
    //  2) Spoof OS khác máy thật (os !== 'Windows' - nhân CGTBrowser chạy trên Windows):
    //     token OS nằm TRONG UA string + Sec-CH-UA-Platform, nên KHÔNG phát user_agent thì
    //     đổi OS vô nghĩa (web vẫn đọc Windows từ UA gốc của nhân). Ở "Tất cả", syncUA đã
    //     dựng UA theo FULL-BUILD THẬT của nhân (kernelFullFor, vd 140.0.7339.264) → chỉ đổi
    //     token OS, KHỚP TUYỆT ĐỐI version chromium gốc, KHÔNG bịa.
    // Windows + "Tất cả" ⇒ ua='' ⇒ fpConfig KHÔNG có section user_agent → trình duyệt dùng
    // UA gốc của nhân (vốn đã là Windows) → khớp 100% chromium gốc, không hook gì.
    const uaForConfig = (chromeVer || os !== 'Windows') ? ua : '';
    // fingerprint_data = { meta, fpConfig, ui } - the launcher encrypts fpConfig
    // and passes it to the patched CGTBrowser inline via --fp-config.
    const fingerprint = JSON.stringify({
      // uaPinned/uaFull: LƯU TƯỜNG MINH lựa chọn ở combobox User-Agent (rỗng = "Tất cả").
      // Dùng để khôi phục combobox lúc mở sửa hồ sơ, KHÔNG phụ thuộc sự-hiện-diện của
      // fpConfig.user_agent (chỉ có khi chọn item cụ thể; "Tất cả" thì buildFpConfig bỏ hẳn).
      // kernelMajor: NHÂN mà hồ sơ này sẽ CHẠY (major của thẻ "Trình duyệt"). Trước đây
      // lựa chọn trên thẻ KHÔNG được lưu ⇒ launcher luôn mở nhân "đang dùng" toàn cục
      // (activeExe) nên chọn 150 vẫn chạy 140. Lưu tường minh ⇒ mỗi hồ sơ ghim nhân
      // riêng (mô hình AdsPower), không phụ thuộc nhân active toàn cục.
      meta: { browser: kernel, engine: engineOf(kernel), os, osVersion, userAgent: ua, uaPinned: chromeVer || '', uaFull: chromeFull || '', kernelMajor: kernelVer || '' },
      fpConfig: buildFpConfig(fp, os, uaForConfig, n, osVersion),
      ui: fp,
      // Cookie người dùng dán (JSON MKTLogin/Chrome hoặc name=value) - lưu nguyên văn;
      // được bơm vào trình duyệt qua CDP lúc mở hồ sơ (main/cookie-inject.js).
      cookies: cookiesBox.value.trim(),
    });
    return { name: n, groupId: groupSel.value || null, fingerprint, dynamic: { note: noteBox.value.trim(), tags: tagsSel.values.join(', '), ...collectProxy() } };
  }

  // `stay: true` = lưu nhưng KHÔNG tự rời trang; dùng khi hộp thoại "Lưu và thoát"
  // gọi tới, vì lúc đó router đang chờ và tự điều hướng tiếp về đúng trang người
  // dùng bấm. Trả về true/false = lưu thành công hay không.
  async function doSave(opts) {
    // Tên bỏ trống → tự đặt "Profile " + số ngẫu nhiên 100000–999999 (có dấu cách).
    if (!nameInput.value.trim()) nameInput.value = 'Profile ' + (Math.floor(Math.random() * 900000) + 100000);
    const payload = collectPayload();

    // Nút OK có thể bị double-click; khoá trong lúc gửi.
    if (doSave._busy) return false;
    doSave._busy = true;
    try {
      if (editId) {
        await remote.profiles.update(editId, payload);
        toast('Đã lưu hồ sơ', 'ok');
        try { window.__vtApp && window.__vtApp.refreshProfileCount && window.__vtApp.refreshProfileCount(); } catch { /* ignore */ }
        if (!(opts && opts.stay)) back();
        return true;
      }

      await remote.profiles.create(payload);
      toast('Đã tạo hồ sơ', 'ok');
      try { window.__vtApp && window.__vtApp.refreshProfileCount && window.__vtApp.refreshProfileCount(); } catch { /* ignore */ }
      // Tạo xong KHÔNG tự mở CGTBrowser nữa; người dùng tự mở khi cần.
      if (!(opts && opts.stay)) back();
      return true;
    } catch (e) {
      // KHÔNG được đứng im: báo rõ lý do (hết hạn mức gói → modal; thiếu quyền/mạng → toast).
      notifyError(e, editId ? 'Lưu hồ sơ thất bại' : 'Tạo hồ sơ thất bại');
      return false;
    } finally {
      doSave._busy = false;
    }
  }

  // Bấm "Lưu" ở chế độ SỬA là GHI ĐÈ hồ sơ đang có → hỏi lại một lần. Tạo mới thì
  // không hỏi (chưa có gì để mất). Trả về Promise<boolean> = có được lưu hay không.
  //
  // Dùng lại nguyên bộ CSS của modal "Xóa nhóm" (.grp-del / .grp-del-q / .grp-del-row /
  // .grp-del-chip / .grp-del-badge) nên KHÔNG thêm CSS mới nào.
  function confirmSave() {
    return new Promise((resolve) => {
      let done = false;
      const finish = (ok) => { if (done) return; done = true; closeModal(); resolve(ok); };
      const nm = nameInput.value.trim();
      const { modal } = openModal({
        title: t('Chỉnh sửa hồ sơ trình duyệt'),
        width: 528,
        body: [el('div.grp-del', {}, [
          el('p.grp-del-q', { text: t('Bạn có chắc chắn muốn thay đổi thông tin của profile này?') }),
          // Tên còn trống thì doSave() sẽ tự đặt khi lưu - bỏ luôn dòng này chứ đừng
          // hiện một cái chip rỗng.
          nm ? el('div.grp-del-row', {}, [
            el('span.grp-del-label', { text: t('Tên hồ sơ') }),
            el('div.grp-del-chips', {}, [el('span.grp-del-chip', { text: nm })]),
          ]) : null,
        ].filter(Boolean))],
        footer: [
          el('button.grp-cancel', { text: t('Hủy'), onclick: () => finish(false) }),
          el('button.btn.primary', { text: t('OK'), onclick: () => finish(true) }),
        ],
      });
      const head = modal.querySelector('.modal-head > div');
      if (head) head.insertBefore(el('span.grp-del-badge', { html: icon('warning') }), head.firstChild);
      // Nút X và nền mờ phải resolve(false), nếu không Promise treo mãi và nút "Lưu"
      // không bao giờ nhận lại được. openModal gắn closeModal bằng addEventListener và
      // không giữ tham chiếu để gỡ → nhân bản node để bỏ listener cũ rồi gắn lại.
      const mh = document.getElementById('modal-host');
      [mh && mh.querySelector('.scrim'), modal.querySelector('.icon-btn.x')].forEach((node) => {
        if (!node || !node.parentNode) return;
        const fresh = node.cloneNode(true);
        node.parentNode.replaceChild(fresh, node);
        fresh.addEventListener('click', () => finish(false));
      });
    });
  }

  // Người dùng bấm "Lưu"/"OK" ở chân trang. Chế độ SỬA đi qua hộp xác nhận trước.
  async function onSaveClick() {
    if (editId && !(await confirmSave())) return;
    await doSave();
  }

  const leftCol = el('div.pc-left', {}, [
    el('div.pc-chead', {}, [tabBar]),
    form,
    el('div.pc-footer', {}, [
      // Bọc trong hàm mũi: `onclick: onSaveClick` sẽ truyền MouseEvent vào tham số.
      el('button.btn.primary', { text: editId ? 'Lưu' : 'OK', onclick: () => onSaveClick() }),
      el('button.btn', { text: 'Hủy', onclick: back }),
    ]),
  ]);

  const rightCol = el('div.pc-right', {}, [
    el('div.pc-ov-head', {}, [
      el('div.pc-ov-title', { text: 'Tổng quan' }),
      el('button.btn.subtle.pc-shuffle', { html: `${icon('shuffle')}<span>Dấu vân tay mới</span>`, onclick: () => { if (!hasFeature('new_fingerprint')) { gateFeature('new_fingerprint', { navigate: ctx.navigate }); return; } fp = newFingerprint(); applyOsConsistency(); rerollUA(); } }),
    ]),
    ovList,
  ]);

  host.appendChild(el('div.pc-split', {}, [leftCol, rightCol]));

  remote.groups.list().then((list) => {
    groups = list || [];
    groupSel.setGroups(groups);
  });

  // Nạp pool GPU/Fonts từ server cho OS hiện tại.
  //  - Tạo mới: reroll GPU + fonts theo pool server làm giá trị khởi tạo.
  //  - Sửa: chỉ fetch (để nút "Tạo lại"/dropdown có data), KHÔNG ghi đè vân tay đã lưu;
  //    chỉ điền fontList nếu hồ sơ cũ chưa có (để buildFpConfig có whitelist).
  ensurePools(os).then(() => {
    if (!editId) {
      applyOsConsistency();
    } else {
      if (!Array.isArray(fp.fontList) || !fp.fontList.length) applyFontsFromPool();
      vendorSel.value = fp.webglVendor;
      rendererInput.value = fp.webglMeta;
      renderOverview();
    }
  });

  // ---- Chặn rời trang khi CHƯA LƯU (chỉ chế độ SỬA) ----
  // Mốc so sánh được chốt ngay TRƯỚC tương tác đầu tiên của người dùng: pointerdown
  // và keydown chạy ở pha capture, tức là trước khi giá trị ô nhập kịp đổi.
  //
  // Vì sao không chốt ngay sau build(): form này còn ĐANG được ghi bởi bốn tác vụ
  // nạp bất đồng bộ (cookie thật đọc từ máy, danh sách nhóm, pool GPU/font, danh
  // sách nhân → tự ghim nhân mới nhất rồi dựng lại UA). Chốt sớm thì hồ sơ nào mở
  // ra cũng bị coi là "đã sửa". Chốt theo tương tác đầu tiên thì chúng đã lắng
  // xuống hết mà không phải vá từng chỗ nạp - và thêm chỗ nạp mới sau này vẫn đúng.
  if (editId) {
    let baseline = null;
    // fpConfig.seed do buildFpConfig sinh NGẪU NHIÊN mỗi lần gọi (genSeed dùng crypto
    // RNG) - phải bỏ ra khỏi phép so, nếu không hai lần gọi liền nhau đã khác nhau và
    // modal hỏi lưu hiện lên dù người dùng không sửa gì. Đã rà toàn bộ buildFpConfig:
    // seed là nguồn ngẫu nhiên DUY NHẤT trong đó, phần còn lại thuần theo form.
    const snap = () => {
      try {
        const p = collectPayload();
        const fpo = JSON.parse(p.fingerprint);
        if (fpo && fpo.fpConfig) delete fpo.fpConfig.seed;
        return JSON.stringify({ ...p, fingerprint: fpo });
      } catch { return null; }
    };
    const mark = () => { if (baseline === null) baseline = snap(); };
    // Trên `host`: clear(host) chỉ xoá CON nên listener ở đây sống sót qua mọi lần
    // dựng lại form bên trong.
    host.addEventListener('pointerdown', mark, true);
    host.addEventListener('keydown', mark, true);
    formGuard = {
      isDirty: () => baseline !== null && snap() !== baseline,
      // CỐ Ý gọi thẳng doSave, KHÔNG qua confirmSave(): nút "Lưu và thoát" của hộp
      // thoại chưa-lưu đã là một lần xác nhận rồi, hỏi tiếp là hai modal liền nhau.
      // Chỉ nút "Lưu" ở chân trang mới đi qua confirmSave().
      save: () => doSave({ stay: true }),
    };
  }
  } // end build()

  if (editId) {
    remote.profiles.get(editId).then((prof) => {
      if (prof) {
        const meta = (prof.fingerprint && prof.fingerprint.meta) || {};
        // Nhân đã ghim ('Poly'/'Firefox'). Hồ sơ CŨ không có meta.browser → mặc định 'Poly'.
        // Suy từ meta.engine nếu thiếu browser (an toàn cho dữ liệu chuyển tiếp).
        kernel = meta.browser || (meta.engine === 'firefox' ? 'Firefox' : 'Poly');
        os = meta.os || os;
        // osVersion PHẢI thuộc đúng OS đang dùng. Dữ liệu cũ có thể lưu lệch (vd hồ
        // sơ macOS nhưng osVersion='Windows 11') → kéo userAgentData.platformVersion
        // sai. Nếu lệch, đưa về phiên bản đầu của OS để client-hints nhất quán.
        const _grp = OS_GROUPS.find((g) => g.os === os);
        osVersion = (_grp && _grp.versions.includes(meta.osVersion))
          ? meta.osVersion
          : (_grp ? _grp.versions[0] : (meta.osVersion || osVersion));
        seedUA = meta.userAgent || '';
        // Thẻ "Trình duyệt" khôi phục từ meta.kernelMajor - NHÂN mà hồ sơ đã ghim, cũng
        // chính là nhân launcher sẽ mở. KHÔNG suy từ UA đã lưu: thẻ trình duyệt và combobox
        // User-Agent là HAI phạm trù khác nhau (thẻ = nhân đã tải, combobox = phiên bản UA).
        // Hồ sơ CŨ chưa có kernelMajor → để trống → auto-pin (loadKernelList) ghim nhân MỚI
        // NHẤT đã cài, đúng như hành vi trước đây.
        kernelVer = String(meta.kernelMajor || '');
        // Trạng thái "đã chọn item UA cụ thể" được LƯU dưới dạng fpConfig.user_agent (chỉ
        // tồn tại khi người dùng chọn item; "Tất cả" thì buildFpConfig bỏ hẳn section này).
        // → Có user_agent = khôi phục ĐÚNG item đã chọn vào combobox UA (chromeVer +
        // chromeFull). Không có = giữ "Tất cả" (chromeVer rỗng).
        {
          // Hồ sơ MỚI lưu tường minh uaPinned/uaFull (rỗng = "Tất cả") → khôi phục thẳng,
          // KHÔNG suy từ user_agent (vốn nay luôn hiện diện để spoof OS). Hồ sơ CŨ chưa có
          // uaPinned → giữ suy-luận cũ: có user_agent = item cụ thể; không có = "Tất cả".
          if ('uaPinned' in meta) {
            chromeVer = meta.uaPinned || '';
            chromeFull = meta.uaFull || '';
          } else {
            const _uaCfg = (prof.fingerprint && prof.fingerprint.fpConfig && prof.fingerprint.fpConfig.user_agent) || null;
            const _uaStr = _uaCfg && _uaCfg.ua ? _uaCfg.ua : '';
            const _m = String(_uaStr).match(/(?:Chrome|CriOS)\/(\d+)\.(\d+)\.(\d+)\.(\d+)/);
            if (_m) { chromeVer = String(parseInt(_m[1], 10)); chromeFull = `${_m[1]}.${_m[2]}.${_m[3]}.${_m[4]}`; }
          }
        }
        seedName = prof.name || '';
        seedNote = prof.note || '';
        seedTags = prof.tags || '';
        seedCookies = (prof.fingerprint && prof.fingerprint.cookies) || '';
        curGroupId = prof.groupId || '';
        if (prof.fingerprint && prof.fingerprint.ui) fp = { ...newFingerprint(), ...prof.fingerprint.ui };
        // LUÔN khôi phục mọi thông số proxy đã lưu vào proxyData - kể cả khi proxy đang
        // TẮT (proxyType rỗng) - để người dùng bật lại không phải nhập lại. proxyType chỉ
        // quyết định tab đang chọn (bật/tắt), không quyết định việc giữ dữ liệu.
        proxyData.host = prof.proxyHost || '';
        proxyData.port = prof.proxyPort || '';
        proxyData.user = prof.proxyUser || '';
        proxyData.pass = prof.proxyPass || '';
        proxyData.token = prof.proxyToken || '';
        proxyData.rotateUrl = prof.proxyRotateUrl || '';
        const ptype = String(prof.proxyType || '').trim();
        const ptl = ptype.toLowerCase();
        if (ptl === 'token') proxyTab = 'token';
        else if (ptl === 'proxy xoay') proxyTab = 'rotate';
        else if (ptype && prof.proxyHost && prof.proxyPort) {
          proxyTab = 'normal';
          proxyData.type = normalizeProxyType(ptype);
        }
        // else: proxyTab giữ 'none' nhưng proxyData vẫn còn nguyên thông số đã lưu.
        // Chốt major + ghim UA vừa khôi phục vào kho của ĐÚNG engine hồ sơ đang dùng.
        // Kho của engine KIA để trống - primeEngines() sẽ tự đi lấy số của nó, tuyệt đối
        // không thừa hưởng major này (Chrome 140 không phải Firefox 140).
        stashEngine(engineOf(kernel));
      }
      build();
    });
  } else {
    build();
  }

  // Router gọi TRƯỚC khi điều hướng (xem navigate() ở app.js). Phải là trước, vì
  // route này volatile - destroyHost() xoá sạch DOM lẫn state, hỏi sau thì trả lời
  // "ở lại" cũng không còn form để ở lại.
  return {
    destroy() {
      if (typeof onGlobalKernelInstalled === 'function') {
        window.removeEventListener('cgt:kernel-installed', onGlobalKernelInstalled);
      }
    },
    async confirmLeave() {
      if (leaving || !formGuard || !formGuard.isDirty()) return true;
      const act = await confirmUnsavedDialog({
        message: t('Hồ sơ hiện tại chưa được lưu, bạn có chắc chắn thoát không?'),
        sub: t('Thoát sẽ không được lưu lại'),
      });
      if (act === 'stay') return false;
      if (act === 'discard') return true;
      // Lưu LỖI thì ở lại - thoát tiếp là mất trắng công của người dùng.
      try { return (await formGuard.save()) !== false; } catch { return false; }
    },
  };
}
