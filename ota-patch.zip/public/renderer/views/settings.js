// Trang "Cài đặt" - bố cục 2 CỘT (20 / 80): CỘT TRÁI là menu điều hướng (2 mục:
// "Cài đặt chung" và "Trình duyệt"), CỘT PHẢI (80%) là nội dung. Mỗi cài đặt = 1 hàng:
// NHÃN bên trái (1 dòng), SEGMENTED CONTROL chỉ-icon bên phải; áp dụng NGAY. Giữa các
// cấu hình có gạch ngang mờ ngăn cách.
//   • Giao diện - Ngôn ngữ / Chế độ hiển thị / Độ tương phản.
//   • Ứng dụng  - đường dẫn lưu trữ dữ liệu hồ sơ + nút mở thư mục.
// Giao diện tự lưu + áp dụng live qua window.__appPrefs (đúng logic nút header).
import { el, withSpin, toast } from '../ui.js';
import { icon } from '../icons.js';
import { renderKernelCard } from './kernels.js';
import { checkForUpdates, openUpdateModal, getInfo, hasPendingUpdate, subscribe as subscribeUpdates } from '../ui/update-modal.js';

const LANG_OPTS = [
  ['vi', 'flagVi', 'Tiếng Việt'],
  ['en', 'flagEn', 'English'],
  ['ru', 'flagRu', 'Русский'],
  ['zh', 'flagZh', '中文'],
];
const THEME_OPTS = [
  ['light', 'themeSun', 'Sáng'],
  ['dark', 'themeMoon', 'Tối'],
];
const CONTRAST_OPTS = [
  ['default', 'contrastStd', 'Mặc định'],
  ['f9', 'contrastLight', 'Nền F9 (dịu)'],
];

const NAV_ITEMS = [
  ['general', 'tune', 'Cài đặt chung'],
  ['kernels', 'chrome', 'Nhân trình duyệt'],
  ['app', 'appUpdate', 'Ứng dụng'],
];

export function render(ctx) {
  const prefs = (typeof window !== 'undefined' && window.__appPrefs) || null;
  const cur = prefs ? prefs.get() : { theme: 'light', language: 'vi', contrast: 'default' };

  // Segmented control CHỈ ICON, kiểu .pc-seg giống trang "Tạo hồ sơ" (viền liền, chọn =
  // nền trắng + viền brand + glow). opts = [ [val, iconName, title] ]; title = tooltip.
  function segmented(opts, value, onPick) {
    const seg = el('div.seg.pc-seg');
    opts.forEach(([val, ic, title]) => {
      const b = el('button.seg-opt' + (val === value ? '.active' : ''), {
        type: 'button',
        title,
        'data-val': val,
        onclick: () => {
          seg.querySelectorAll('.seg-opt').forEach((x) => x.classList.toggle('active', x === b));
          onPick(val);
        },
      }, [el('span.seg-ic', { html: icon(ic) })]);
      seg.append(b);
    });
    return seg;
  }

  // hàng: nhãn 1 dòng bên trái + segmented bên phải
  function segRow(title, seg) {
    return el('div.set-row', {}, [
      el('div.set-row-text', {}, [el('div.set-row-title', { text: title })]),
      el('div.set-row-ctl', {}, [seg]),
    ]);
  }

  const langSeg = segmented(LANG_OPTS, cur.language, (v) => { if (prefs) prefs.setLanguage(v); });
  const themeSeg = segmented(THEME_OPTS, cur.theme === 'dark' ? 'dark' : 'light', (v) => { if (prefs) prefs.setTheme(v); });
  const contrastSeg = segmented(CONTRAST_OPTS, cur.contrast === 'f9' ? 'f9' : 'default', (v) => { if (prefs) prefs.setContrast(v); });

  // Segmented dạng CHỮ (không icon) - dùng cho tùy chọn admin "Nguồn nhân trình duyệt".
  function segmentedText(opts, value, onPick) {
    const seg = el('div.seg.pc-seg');
    opts.forEach(([val, label]) => {
      const b = el('button.seg-opt' + (val === value ? '.active' : ''), {
        type: 'button', 'data-val': val, text: label,
        onclick: () => {
          seg.querySelectorAll('.seg-opt').forEach((x) => x.classList.toggle('active', x === b));
          onPick(val);
        },
      });
      seg.append(b);
    });
    return seg;
  }

  // ---- CHỈ ADMIN: "Nguồn nhân trình duyệt" - Storage (mặc định) vs Vendor (test cục bộ) ----
  // Cho admin chạy thẳng bản Chromium trong vendor/ để TEST trước khi đóng gói thành nhân
  // & up lên web admin. Tài khoản thường KHÔNG thấy hàng này và luôn chạy Storage (phương
  // án B). Hàng khởi tạo ẩn, chỉ hiện sau khi xác nhận là admin (loadPermissions).
  const SRC_OPTS = [['storage', 'Storage'], ['vendor', 'Vendor (test)']];
  const srcSeg = segmentedText(SRC_OPTS, 'storage', (v) => {
    Promise.resolve(vt.settings.set({ browserSource: v }))
      .then(() => toast(v === 'vendor' ? 'Đang test bằng nhân Vendor cục bộ' : 'Dùng nhân tải từ Storage', 'ok'))
      .catch(() => toast('Không lưu được lựa chọn', 'error'));
  });
  const srcRow = el('div.set-row', { style: { display: 'none' } }, [
    el('div.set-row-text', {}, [
      el('div.set-row-title', { text: 'Nguồn nhân trình duyệt' }),
      el('div.set-row-sub', { text: 'Vendor: chạy Chromium cục bộ để test trước khi up nhân lên web admin. Storage: chạy nhân tải về (mặc định).' }),
    ]),
    el('div.set-row-ctl', {}, [srcSeg]),
  ]);
  // Hiện hàng chỉ cho ADMIN NỀN TẢNG (accounts.is_publisher) + tô nút theo giá trị đang lưu.
  // Dùng vt.market.canPublish().isAdmin - KHÔNG dùng canManageMembers() (cờ đó còn true cho
  // chủ workspace / quản lý nhóm là tài khoản thường → sẽ lộ tính năng test nhân cho họ).
  (async () => {
    try {
      let isAdmin = false;
      try { const p = await vt.market.canPublish(); isAdmin = !!(p && p.isAdmin); } catch { /* giữ ẩn */ }
      if (!isAdmin) return; // tài khoản thường → ẩn hoàn toàn
      let curSrc = 'storage';
      try { const s = await vt.settings.all(); curSrc = (s && s.browserSource) || 'storage'; } catch { /* default storage */ }
      srcSeg.querySelectorAll('.seg-opt').forEach((x) => x.classList.toggle('active', x.getAttribute('data-val') === curSrc));
      srcRow.style.display = '';
    } catch { /* không xác định được quyền → giữ ẩn */ }
  })();

  // ---- Đường dẫn dữ liệu hồ sơ: textbox full-width + nút CHỌN thư mục NẰM TRONG (phải) ----
  // Nút mở hộp thoại chọn thư mục → lưu làm nơi lưu trữ mới (áp dụng sau khi khởi động lại).
  const pathInput = el('input.set-pathinput', { readonly: true, placeholder: '-' });
  const pathField = el('div.set-apppath', {}, [
    el('div.set-apppath-lbl', { text: 'Đường dẫn lưu trữ dữ liệu hồ sơ' }),
    el('div.set-pathbox', {}, [
      pathInput,
      el('button.set-pathbtn', {
        type: 'button',
        html: icon('folder'),
        title: 'Chọn thư mục lưu trữ',
        onclick: (e) => withSpin(e.currentTarget, async () => {
          const dir = await vt.dialog.openFolder();
          if (!dir) return;
          const r = await vt.paths.setRoot(dir);
          if (r && r.ok) {
            pathInput.value = r.dataRoot || dir;
            toast('Đã đổi nơi lưu trữ - khởi động lại app để áp dụng', 'ok');
          } else {
            toast((r && r.error) || 'Không đổi được nơi lưu trữ', 'error');
          }
        }),
      }),
    ]),
  ]);

  // Nội dung "Cài đặt chung": các hàng có gạch ngang mờ ngăn cách (class .set-list).
  const generalCard = el('div.set-list', {}, [
    segRow('Ngôn ngữ', langSeg),
    segRow('Chế độ hiển thị', themeSeg),
    segRow('Độ tương phản', contrastSeg),
    pathField,
    srcRow,
  ]);

  // ---- Nội dung "Ứng dụng": phiên bản + kiểm tra cập nhật ----
  // Hàng phiên bản (giá trị cập nhật sau khi kiểm tra) + hàng nút kiểm tra có badge đỏ
  // khi đang có bản mới chờ. Bấm kiểm tra → check không im lặng (toast kết quả); có bản
  // mới → nút "Cập nhật ngay" mở modal luồng cập nhật.
  const verValue = el('div.set-row-val', { text: '-' });
  const checkBtn = el('button.btn', { type: 'button', text: 'Kiểm tra cập nhật' });
  const checkBadge = el('span.notif-badge', { style: { display: 'none' } });
  const updateNowBtn = el('button.btn.primary', { type: 'button', text: 'Cập nhật ngay', style: { display: 'none' } });

  function refreshAppCard() {
    const info = getInfo();
    if (info && info.current) verValue.textContent = info.current + (info.latest && info.hasUpdate ? ` → ${info.latest}` : '');
    const pending = hasPendingUpdate();
    checkBadge.style.display = pending ? 'inline-block' : 'none';
    updateNowBtn.style.display = pending ? 'inline-flex' : 'none';
  }

  checkBtn.addEventListener('click', (e) => withSpin(e.currentTarget, async () => {
    await checkForUpdates({ silent: false });
    refreshAppCard();
  }));
  updateNowBtn.addEventListener('click', () => {
    const info = getInfo();
    openUpdateModal(!!(info && info.force));
  });

  const appCard = el('div.set-list', {}, [
    el('div.set-row', {}, [
      el('div.set-row-text', {}, [el('div.set-row-title', { text: 'Phiên bản hiện tại' })]),
      el('div.set-row-ctl', {}, [verValue]),
    ]),
    el('div.set-row', {}, [
      el('div.set-row-text', {}, [el('div.set-row-title', { text: 'Cập nhật phần mềm' })]),
      el('div.set-row-ctl.set-upd-ctl', {}, [
        el('div.set-upd-btnwrap', {}, [checkBtn, checkBadge]),
        updateNowBtn,
      ]),
    ]),
  ]);

  // Lấy trạng thái hiện có (nếu đã kiểm tra ở nơi khác) rồi lắng nghe cập nhật.
  refreshAppCard();
  const offUpd = subscribeUpdates(refreshAppCard);
  // Kiểm tra im lặng khi mở trang để có sẵn số phiên bản.
  checkForUpdates({ silent: true }).then(refreshAppCard).catch(() => {});
  // Dọn đăng ký khi rời trang (ctx.container bị gỡ). Best-effort qua MutationObserver.
  try {
    const mo = new MutationObserver(() => {
      if (!document.body.contains(appCard)) { offUpd(); mo.disconnect(); }
    });
    mo.observe(document.body, { childList: true, subtree: true });
  } catch { /* ignore */ }

  const kernelsCard = renderKernelCard();
  const CARDS = { general: generalCard, kernels: kernelsCard, app: appCard };
  const content = el('div.set-body-scroll', {}, [generalCard]);

  // ---- CỘT TRÁI: menu điều hướng 2 mục ----
  const nav = el('div.set-nav');
  let curNav = 'general';
  NAV_ITEMS.forEach(([key, ic, label]) => {
    const item = el('button.set-navitem' + (key === curNav ? '.active' : ''), {
      type: 'button',
      onclick: () => {
        if (curNav === key) return;
        curNav = key;
        nav.querySelectorAll('.set-navitem').forEach((x) => x.classList.toggle('active', x === item));
        content.innerHTML = '';
        content.append(CARDS[key]);
      },
    }, [
      el('span.set-navlbl', { text: label }),
    ]);
    nav.append(item);
  });

  // Bố cục 2 cột: trái 20% menu, phải 80% nội dung.
  const page = el('div.set-root', {}, [
    el('div.set-shell', {}, [
      el('div.set-split', {}, [nav, el('div.set-mid', {}, [content])]),
    ]),
  ]);
  ctx.container.appendChild(page);

  // hiển thị đường dẫn thư mục dữ liệu hồ sơ
  vt.paths.info().then((info) => { if (info) pathInput.value = info.dataRoot || ''; });

  return null;
}
