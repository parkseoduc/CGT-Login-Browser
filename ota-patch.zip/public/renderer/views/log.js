// "Nhật ký hoạt động" (Activity log) page - lists device-local operation records
// (create / update / delete a profile, proxy, tag, …) collected by
// data/activity-log.js. Cloned 1:1 from MKTLogin's "Nhật Ký Chung": a filter bar
// (Hành động dropdown · ID/tên hồ sơ search · tài khoản/email search · khoảng ngày)
// over a 5-column grid (Hành động · ID hồ sơ · Tên hồ sơ · Người thực hiện · Thời
// gian thực hiện) with a pager. Read-only - the log is written elsewhere and this
// view only displays + filters it, live-refreshing via onActivityChange.
import { el, clear, customSelect, pageSizeSelect, gridEmpty, noLogSvg } from '../ui.js';
import { icon } from '../icons.js';
import { t, tf } from '../i18n.js';
import { activities, actionLabel, ACTION_LIST, onActivityChange, ready as activityReady } from '../data/activity-log.js';

const MONTHS = ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12'];
// "01 tháng 07 2026" + "16:03" - matches MKTLogin's two-line time cell.
function fmtWhen(ts) {
  if (!ts) return null;
  const d = new Date(ts);
  if (isNaN(d)) return null;
  const day = String(d.getDate()).padStart(2, '0');
  const date = tf('{0} tháng {1} {2}', day, MONTHS[d.getMonth()], d.getFullYear());
  const time = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  return { date, time };
}
// ---- date helpers for the dual-month range picker (local, day-granular) ----
const DOW = ['CN', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7'];
const pad = (n) => String(n).padStart(2, '0');
const fmtIso = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const parseIso = (s) => { const [y, m, d] = String(s).split('-').map(Number); return new Date(y, m - 1, d); };
const startOfMonth = (d) => new Date(d.getFullYear(), d.getMonth(), 1);
const addMonths = (d, n) => new Date(d.getFullYear(), d.getMonth() + n, 1);
const addDays = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
const sameDay = (a, b) => !!a && !!b && a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
// Date (day) → epoch ms at local day start/end.
const dayStartMs = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate(), 0, 0, 0, 0).getTime();
const dayEndMs = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate(), 23, 59, 59, 999).getTime();

export function render(ctx) {
  let filtered = [];
  let page = 0;
  let pageSize = 10;
  let actionFilter = '';       // '' = tất cả
  let profileText = '';        // ID hoặc tên hồ sơ
  let accountText = '';        // tên tài khoản hoặc email
  let fromTs = null, toTs = null;

  const tbody = el('tbody');
  const emptyEl = gridEmpty('Chưa có hoạt động nào được ghi lại.', noLogSvg);
  const totalText = el('span.muted');
  const pageNumbers = el('div.page-nums');

  // First 8 hex of the md5 "Profile ID", uppercase - matches the profiles/proxies grid.
  const shortId = (pid) => (pid ? String(pid).slice(0, 8).toUpperCase() : '');

  // Active-filter summary bar shown above the grid the moment an action is picked
  // in the "Hành động" combobox (result count + a removable chip + "Loại bỏ").
  const filterBar = el('div.log-filterbar', { style: { display: 'none' } });
  function clearAction() {
    actionFilter = '';
    actionSel.value = '';   // reset the combobox label (setter doesn't re-fire onChange)
    applyFilter();
  }
  function renderFilterBar(total) {
    if (!actionFilter) { filterBar.style.display = 'none'; return; }
    filterBar.style.display = 'flex';
    clear(filterBar);
    filterBar.appendChild(el('div.log-filter-count', {}, [
      el('b', { text: String(total) }), document.createTextNode(' Kết quả tìm kiếm'),
    ]));
    filterBar.appendChild(el('div.log-filter-active', {}, [
      el('span.lff-label', { text: 'Hành động:' }),
      el('span.lff-chip', {}, [
        document.createTextNode(actionLabel(actionFilter)),
        el('button.lff-x', { type: 'button', html: icon('close'), title: 'Bỏ lọc', onclick: clearAction }),
      ]),
      el('button.lff-clear', { type: 'button', onclick: clearAction },
        [el('span.lff-ico', { html: icon('trash') }), document.createTextNode('Loại bỏ')]),
    ]));
  }

  function matches(e) {
    if (actionFilter && e.action !== actionFilter) return false;
    if (profileText) {
      const hay = `${e.profileId} ${e.profileName || ''}`.toLowerCase();
      if (!hay.includes(profileText)) return false;
    }
    if (accountText) {
      const hay = `${e.actorName || ''} ${e.actorEmail || ''}`.toLowerCase();
      if (!hay.includes(accountText)) return false;
    }
    if (fromTs != null && e.ts < fromTs) return false;
    if (toTs != null && e.ts > toTs) return false;
    return true;
  }
  function applyFilter() { filtered = activities().filter(matches); page = 0; renderPage(); }
  // Refresh from the store WITHOUT resetting page - used on live change / re-show.
  function refresh() { filtered = activities().filter(matches); renderPage(); }

  function renderPage() {
    const pages = Math.max(1, Math.ceil(filtered.length / pageSize));
    if (page >= pages) page = pages - 1;
    const slice = filtered.slice(page * pageSize, page * pageSize + pageSize);
    clear(tbody);
    slice.forEach((e) => {
      const when = fmtWhen(e.ts);
      tbody.appendChild(el('tr', {}, [
        el('td.log-action-cell', {}, [el('span.log-action', { text: actionLabel(e.action) })]),
        el('td', {}, [el('div.name-main', { text: shortId(e.profileId) || '-' })]),
        el('td', {}, [el('div.name-main', { text: e.profileName || '-' })]),
        el('td', {}, [el('div.log-actor', {}, [
          el('div.name-main', { text: e.actorName || '-' }),
          el('div.name-sub.muted', { text: e.actorEmail || '' }),
        ])]),
        el('td.log-when', {}, when
          ? [el('div.name-main', { text: when.date }), el('div.name-sub.muted', { text: when.time })]
          : [el('span.muted', { text: '-' })]),
      ]));
    });
    const total = filtered.length;
    const from = total === 0 ? 0 : page * pageSize + 1;
    const to = Math.min((page + 1) * pageSize, total);
    totalText.textContent = total === 0 ? `0 ${t('trên')} 0` : `${from}-${to} ${t('trên')} ${total}`;
    emptyEl.style.display = total === 0 ? 'flex' : 'none';
    renderFilterBar(total);
    renderPager(pages);
  }

  function renderPager(pages) {
    clear(pageNumbers);
    for (let i = 0; i < pages; i++) {
      if (pages > 7 && i > 1 && i < pages - 2 && Math.abs(i - page) > 1) {
        if (i === 2 || i === pages - 3) pageNumbers.appendChild(el('span.muted', { text: '…' }));
        continue;
      }
      pageNumbers.appendChild(el('button.page-num' + (i === page ? '.active' : ''), { text: String(i + 1), onclick: () => { page = i; renderPage(); } }));
    }
  }

  // ---- toolbar (filters) ----------------------------------------------------
  const actionSel = customSelect(
    [{ value: '', label: 'Tất cả' }, ...ACTION_LIST.map((a) => ({ value: a.key, label: a.label }))],
    { value: '', width: 240, height: 41, placeholder: 'Hành động',
      onChange: (v) => { actionFilter = v; applyFilter(); } });

  const profInput = el('input.search-input', { placeholder: 'ID hoặc tên hồ sơ',
    oninput: (e) => { profileText = e.target.value.trim().toLowerCase(); applyFilter(); } });
  const profBar = el('div.searchbar', {}, [el('span.ico', { html: icon('search') }), profInput]);

  const acctInput = el('input.search-input', { placeholder: 'Tên tài khoản hoặc email',
    oninput: (e) => { accountText = e.target.value.trim().toLowerCase(); applyFilter(); } });
  const acctBar = el('div.searchbar', {}, [el('span.ico', { html: icon('search') }), acctInput]);

  // Date-range picker - dual-month calendar dropdown with quick presets, cloned
  // from the Trash view (reuses its .date-range/.dr-* styling). Replaces the two
  // bare native date inputs that looked poor. Sets fromTs/toTs (epoch ms).
  let dateFrom = '';   // iso yyyy-mm-dd (inclusive day start)
  let dateTo = '';     // iso yyyy-mm-dd (inclusive day end)
  function buildDatePicker() {
    let selStart = null, selEnd = null;
    let viewMonth = startOfMonth(new Date());
    let hoverDay = null, pop = null, dayCells = [];

    // Two boxed date fields ("2026-06-27" → "2026-07-03") like the reference:
    // calendar icon · [from] · arrow · [to] · clear.
    const fromField = el('span.dr-field');
    const toField = el('span.dr-field');
    const arrow = el('span.dr-arrow', { text: '→' });
    // Default range = [oldest logged day → today]: always shows real dates AND
    // never hides an entry (every log falls inside it). Clear (×) resets to this.
    function defaultRange() {
      const arr = activities();
      const today = new Date();
      const lo = arr.length ? new Date(arr[arr.length - 1].ts) : today;
      return [lo, today];
    }
    const clearBtn = el('button.dr-clear', { type: 'button', title: 'Đặt lại khoảng ngày',
      html: icon('close'), onclick: (e) => { e.stopPropagation(); const [lo, hi] = defaultRange(); commit(lo, hi); } });
    const trigger = el('button.date-range.dr-split', { type: 'button' }, [
      el('span.dr-ico', { html: icon('calendar') }), fromField, arrow, toField, clearBtn,
    ]);

    function refreshLabel() {
      fromField.textContent = dateFrom || '-';
      toField.textContent = dateTo || '-';
      clearBtn.style.display = 'grid';
    }
    function commit(a, b) {
      const lo = a <= b ? a : b, hi = a <= b ? b : a;
      selStart = lo; selEnd = hi; dateFrom = fmtIso(lo); dateTo = fmtIso(hi);
      fromTs = dayStartMs(lo); toTs = dayEndMs(hi);
      refreshLabel(); applyFilter(); close();
    }
    function onDay(d) {
      if (!selStart || (selStart && selEnd)) { selStart = d; selEnd = null; hoverDay = null; applyDayStates(); }
      else { commit(selStart, d); }
    }
    function preset(fromD, toD) { commit(fromD, toD); }

    function applyDayStates() {
      let lo = selStart, hi = selEnd;
      if (selStart && !selEnd && hoverDay) { lo = selStart <= hoverDay ? selStart : hoverDay; hi = selStart <= hoverDay ? hoverDay : selStart; }
      const today = new Date();
      dayCells.forEach(({ btn, date, inMonth }) => {
        btn.className = 'dr-day';
        if (!inMonth) btn.classList.add('muted');
        if (sameDay(date, today)) btn.classList.add('today');
        if (lo && hi && date > lo && date < hi) btn.classList.add('in-range');
        if (lo && sameDay(date, lo)) btn.classList.add('range-start');
        if (hi && sameDay(date, hi)) btn.classList.add('range-end');
      });
    }

    function monthEl(base, side) {
      const title = tf('{0} Năm Tháng {1}', base.getFullYear(), base.getMonth() + 1);
      const head = el('div.dr-cal-head');
      if (side === 'left') {
        head.appendChild(el('button.dr-nav.n1', { type: 'button', text: '«', title: 'Năm trước', onclick: () => { viewMonth = addMonths(viewMonth, -12); renderCals(); } }));
        head.appendChild(el('button.dr-nav.n2', { type: 'button', text: '‹', title: 'Tháng trước', onclick: () => { viewMonth = addMonths(viewMonth, -1); renderCals(); } }));
      } else {
        head.appendChild(el('button.dr-nav.x1', { type: 'button', text: '›', title: 'Tháng sau', onclick: () => { viewMonth = addMonths(viewMonth, 1); renderCals(); } }));
        head.appendChild(el('button.dr-nav.x2', { type: 'button', text: '»', title: 'Năm sau', onclick: () => { viewMonth = addMonths(viewMonth, 12); renderCals(); } }));
      }
      head.appendChild(el('span.dr-title', { text: title }));

      const grid = el('div.dr-grid');
      DOW.forEach((w) => grid.appendChild(el('span.dr-dow', { text: w })));
      const first = startOfMonth(base);
      const start = addDays(first, -first.getDay());
      for (let i = 0; i < 42; i++) {
        const date = addDays(start, i);
        const inMonth = date.getMonth() === base.getMonth();
        const btn = el('button.dr-day', { type: 'button', text: String(date.getDate()) });
        btn.onclick = () => onDay(date);
        btn.onmouseenter = () => { if (selStart && !selEnd) { hoverDay = date; applyDayStates(); } };
        grid.appendChild(btn);
        dayCells.push({ btn, date, inMonth });
      }
      return el('div.dr-cal', {}, [head, grid]);
    }

    const calsWrap = el('div.dr-cals');
    function renderCals() {
      dayCells = [];
      clear(calsWrap);
      calsWrap.appendChild(monthEl(viewMonth, 'left'));
      calsWrap.appendChild(monthEl(addMonths(viewMonth, 1), 'right'));
      applyDayStates();
    }

    const onDoc = (e) => { if (pop && !pop.contains(e.target) && !trigger.contains(e.target)) close(); };
    const onReposition = () => { if (pop) close(); };
    function place() {
      const r = trigger.getBoundingClientRect();
      pop.style.left = Math.min(r.left, window.innerWidth - pop.offsetWidth - 10) + 'px';
      if ((window.innerHeight - r.bottom) < pop.offsetHeight + 10) {
        pop.style.top = 'auto'; pop.style.bottom = (window.innerHeight - r.top + 6) + 'px';
      } else { pop.style.bottom = 'auto'; pop.style.top = (r.bottom + 6) + 'px'; }
    }
    function open() {
      const today = new Date();
      if (dateFrom && dateTo) { selStart = parseIso(dateFrom); selEnd = parseIso(dateTo); }
      else { selStart = today; selEnd = null; }
      hoverDay = null;
      viewMonth = startOfMonth(selStart || today);
      pop = el('div.dr-pop', {}, [
        el('div.dr-presets', {}, [
          el('button.dr-preset', { type: 'button', text: 'Hôm nay', onclick: () => preset(today, today) }),
          el('button.dr-preset', { type: 'button', text: 'Hôm qua', onclick: () => { const y = addDays(today, -1); preset(y, y); } }),
          el('button.dr-preset', { type: 'button', text: '7 ngày trước', onclick: () => preset(addDays(today, -6), today) }),
          el('button.dr-preset', { type: 'button', text: '30 ngày trước', onclick: () => preset(addDays(today, -29), today) }),
        ]),
        calsWrap,
      ]);
      pop.onmouseleave = () => { if (selStart && !selEnd) { hoverDay = null; applyDayStates(); } };
      document.body.appendChild(pop);
      trigger.classList.add('open');
      renderCals();
      place();
      document.addEventListener('mousedown', onDoc);
      window.addEventListener('scroll', onReposition, true);
      window.addEventListener('resize', onReposition);
    }
    function close() {
      if (pop && pop.parentNode) pop.parentNode.removeChild(pop);
      pop = null;
      trigger.classList.remove('open');
      document.removeEventListener('mousedown', onDoc);
      window.removeEventListener('scroll', onReposition, true);
      window.removeEventListener('resize', onReposition);
    }
    trigger.onclick = () => { pop ? close() : open(); };
    // Seed the default range so dates always show (without closing/opening a popup).
    (() => { const [lo, hi] = defaultRange();
      selStart = lo; selEnd = hi; dateFrom = fmtIso(lo); dateTo = fmtIso(hi);
      fromTs = dayStartMs(lo); toTs = dayEndMs(hi); })();
    refreshLabel();
    return trigger;
  }
  const dateBar = buildDatePicker();

  const toolbar = el('div.toolbar.trash-bar.log-bar', {}, [actionSel, profBar, acctBar, dateBar]);

  // Nói RA hạn lưu trữ. Server tự dọn mục quá 3 ngày (activity-retention.js) và `list` cũng lọc
  // theo cùng mốc đó, nên không có dòng này thì người dùng lọc "30 ngày trước" ra bảng rỗng và
  // tưởng nhật ký bị mất/lỗi. Con số phải KHỚP RETENTION_DAYS ở server - sửa một bên thì sửa cả hai.
  const retentionNote = el('div.log-retention', { text: t('Nhật ký chỉ lưu 3 ngày gần nhất, các mục cũ hơn sẽ được tự động xóa.') });

  // ---- grid -----------------------------------------------------------------
  const th = (label, cls) => el('th' + (cls || ''), {}, [el('span', { text: label })]);
  const table = el('table.grid.profiles-grid.log-grid', {}, [
    el('thead', {}, [el('tr', {}, [
      th('Hành động'), th('ID hồ sơ'), th('Tên hồ sơ'), th('Người thực hiện'),
      th('Thời gian thực hiện', '.log-when'),
    ])]),
    tbody,
  ]);

  const sizeSel = pageSizeSelect([10, 25, 50, 100], { value: pageSize, onChange: (v) => { pageSize = v; page = 0; renderPage(); } });

  const pager = el('div.pager', {}, [
    el('span.muted', { text: 'Số dòng mỗi trang:' }),
    sizeSel,
    totalText,
    el('button.icon-btn', { html: icon('chevron'), style: { transform: 'rotate(180deg)' }, onclick: () => { if (page > 0) { page--; renderPage(); } } }),
    pageNumbers,
    el('button.icon-btn', { html: icon('chevron'), onclick: () => { const pages = Math.ceil(filtered.length / pageSize); if (page < pages - 1) { page++; renderPage(); } } }),
  ]);

  const pageEl = el('div.page', {}, [
    toolbar,
    retentionNote,
    filterBar,
    el('div.grid-area', {}, [el('div.grid-card', {}, [table, emptyEl]), pager]),
  ]);
  ctx.container.appendChild(pageEl);
  applyFilter();
  // Chờ nhật ký tải xong từ server (workspace hiện hành) rồi hiển thị lại.
  activityReady().then(() => applyFilter()).catch(() => {});

  // Live-refresh the moment any action is logged from anywhere in the app.
  const offLog = onActivityChange(() => refresh());

  return {
    onShow() { refresh(); },      // keep-alive route: refresh on return too
    destroy() { offLog(); },
  };
}
