// "Proxies" - UI ONLY, drawn fresh to clone AdsPower's Proxies section 1:1.
//
// Two top tabs: "Danh sách Proxy" and "Proxy xoay".
//
// There is NO proxy backend yet. Since the list has no data, the "Danh sách
// Proxy" tab renders AdsPower's inline "Thêm proxy" form AS its main content
// (notes panel + parse form + live preview table); "Proxy xoay" shows the empty
// "no traffic" state.
import { el, clear, toast, customSelect, pageSizeSelect, hoverMenu, openModal, closeModal, noProfileSvg } from '../ui.js';
import { icon } from '../icons.js';
import { t, tf } from '../i18n.js';
import { remote } from '../data/remote-ds.js';
import { logActivity } from '../data/activity-log.js';
import { loadPermissions, can } from '../data/team-permissions.js';
import { notifyError } from '../data/errors.js';
import { PROXY_TYPES, PROXY_TYPE_DEFAULT, normalizeProxyType } from '../data/proxy-types.js';

const SOON = (label) => () => toast(tf('Tính năng {0} đang phát triển', label));

// Proxy là tài nguyên dùng chung: mọi thành viên XEM được, nhưng thêm/sửa/xóa cần
// quyền sửa proxy (profile:edit_proxy) - nhân viên chỉ-xem-chạy bị khóa mềm nút.
// Server VẪN enforce thật (403); đây chỉ để UX rõ ràng (mờ + not-allowed + tooltip).
const PROXY_LOCK_MSG = 'Bạn chỉ có quyền xem & chạy - không thể thêm/sửa/xóa proxy. Liên hệ quản trị để nâng quyền.';
const canEditProxy = () => can('profile:edit_proxy');
function gateProxyBtn(btn, allowed) {
  if (!btn) return btn;
  if (allowed) {
    btn.classList.remove('is-locked');
    if (btn._realClick) { btn.onclick = btn._realClick; btn._realClick = null; }
    if (btn.getAttribute('title') === PROXY_LOCK_MSG) btn.removeAttribute('title');
  } else {
    if (!btn._realClick) btn._realClick = btn.onclick;
    btn.classList.add('is-locked');
    btn.title = PROXY_LOCK_MSG;
    btn.onclick = (e) => { e.stopPropagation(); toast(PROXY_LOCK_MSG, 'warn'); };
  }
  return btn;
}

// Short, stable display ID for a profile - first 8 hex chars of its "Profile ID"
// (md5 of the GUID), matching the profiles grid / Automation modal. Shown instead
// of the (long) profile name in the "Hồ sơ áp dụng" tags.
function shortId(p) {
  const pid = p && (p.profileId || p.id) ? String(p.profileId || p.id) : '';
  return pid ? pid.slice(0, 8).toUpperCase() : '';
}

// "Loại proxy" ở trang này dùng CHUNG PROXY_TYPES với mọi combobox proxy khác
// (data/proxy-types.js). Trước đây nó là bộ riêng [Socks5 | HTTPS | HTTP] - thiếu SOCKS4,
// thiếu Token, và nhãn viết khác hẳn modal "Cập nhật proxy" bên trang Hồ sơ.
// `r.type` của các dòng ĐÃ LƯU vì vậy có thể vẫn là 'socks5'/'https'/'http'/'ssh' kiểu cũ;
// luôn đi qua normalizeProxyType() trước khi hiển thị hay quy sang proxyType của hồ sơ.
// MKTLogin's "Chế độ chèn proxy" (proxy insertion mode).
const INSERT_MODES = [
  { value: 'no_repeat', label: 'Không lặp lại' },
  { value: 'repeat', label: 'Lặp lại' },
  { value: 'one_for_all', label: 'Một cho tất cả' },
];

// 2-letter ISO country code → a flag-emoji span (same as the Hồ sơ IP cell).
// Returns null on invalid codes.
function flagImg(cc) {
  const c = (cc || '').toUpperCase();
  if (!/^[A-Z]{2}$/.test(c)) return null;
  const emoji = String.fromCodePoint(
    0x1f1e6 + (c.charCodeAt(0) - 65),
    0x1f1e6 + (c.charCodeAt(1) - 65),
  );
  return el('span.ip-flag', { text: emoji, title: c });
}

// Split "host:port" honouring bracketed IPv6 (e.g. "[2001:db8::e13]:8000").
function splitHostPort(s) {
  s = (s || '').trim();
  if (s.startsWith('[')) {
    const i = s.indexOf(']');
    const host = s.slice(0, i + 1);
    const rest = s.slice(i + 1);
    return [host, rest.startsWith(':') ? rest.slice(1) : ''];
  }
  const i = s.lastIndexOf(':');
  return i < 0 ? [s, ''] : [s.slice(0, i), s.slice(i + 1)];
}

// Best-effort parse of one AdsPower proxy line into the preview columns.
// Handles the documented formats:
//   host:port{note}
//   host:port:user:pass{note}
//   scheme://host:port[changeUrl]{note}
//   scheme://user:pass@host:port[changeUrl]{note}
function parseProxyLine(raw, defType) {
  let s = (raw || '').trim();
  if (!s) return null;
  let note = '';
  const nm = s.match(/\{([^}]*)\}\s*$/);
  if (nm) { note = nm[1]; s = s.slice(0, nm.index).trim(); }
  let changeUrl = '';
  const cm = s.match(/\[([^\]]*)\]\s*$/);
  if (cm) { changeUrl = cm[1]; s = s.slice(0, cm.index).trim(); }
  let type = '';
  const sm = s.match(/^([a-z0-9]+):\/\//i);
  if (sm) { type = sm[1].toLowerCase(); s = s.slice(sm[0].length).trim(); }
  let host = '', port = '', user = '', pass = '';
  const at = s.lastIndexOf('@');
  if (at >= 0) {
    const cred = s.slice(0, at);
    const ci = cred.indexOf(':');
    if (ci >= 0) { user = cred.slice(0, ci); pass = cred.slice(ci + 1); } else { user = cred; }
    [host, port] = splitHostPort(s.slice(at + 1));
  } else if (!s.startsWith('[') && s.split(':').length >= 4) {
    const parts = s.split(':');
    host = parts[0]; port = parts[1]; user = parts[2]; pass = parts.slice(3).join(':');
  } else {
    [host, port] = splitHostPort(s);
  }
  if (!host) return null;
  return { type: type || defType, host, port, user, pass, changeUrl, note };
}

// Add-page config persists across nav away/back within a session (so switching
// pages doesn't lose the configured type / mode / group / tags / textarea and the
// staged rows waiting to be added). Module-scope = survives render() re-mount.
const ADD_STATE = {
  tab: 'list',
  proxyType: PROXY_TYPE_DEFAULT,
  insertMode: 'no_repeat',
  group: '__all__',
  tags: '',
  textarea: '',
  excluded: new Set(),   // profile ids removed from the target list (current group)
  staged: [],            // rows imported from the textarea, awaiting "Thêm Proxy"
};
let STAGED_UID = 1;      // stable uid for staged rows (selection keys)

export function render(ctx) {
  let tab = ADD_STATE.tab; // list | rotating

  const body = el('div.px-body');

  const tabsRow = el('div.px-tabs');
  function renderTabs() {
    clear(tabsRow);
    [['list', 'Danh sách Proxy'], ['rotating', 'Proxy xoay']].forEach(([k, label]) => {
      tabsRow.appendChild(el('button.px-tab' + (tab === k ? '.is-active' : ''), {
        text: label, onclick: () => { if (tab !== k) { tab = k; ADD_STATE.tab = k; renderTabs(); renderBody(); } },
      }));
    });
  }

  // -------------------------------------------------------- "Proxy xoay" tab
  function renderRotating() {
    return el('div.px-page', {}, [
      el('div.px-empty.px-empty-tall', {}, [
        el('div.px-empty-art', { html: NO_PROXY_SVG }),
        el('div.px-empty-title', { text: 'Không có lưu lượng khả dụng' }),
        el('div.px-empty-sub', { text: 'Nhấn "Mua gói lưu lượng" để bắt đầu.' }),
        el('div.px-empty-acts', {}, [
          el('button.btn.primary', { html: `${icon('wallet')}<span>Mua gói lưu lượng</span>`, onclick: SOON('mua gói lưu lượng') }),
        ]),
      ]),
    ]);
  }

  // ------------------------------ "Thêm proxy" inline page (clones AdsPower)
  function renderAddProxy() {
    // normalizeProxyType: ADD_STATE còn sống qua các lần render nên có thể giữ giá trị cũ
    // kiểu 'http'/'https' từ phiên trước khi đổi sang danh sách 4 item.
    let proxyType = normalizeProxyType(ADD_STATE.proxyType);
    let insertMode = ADD_STATE.insertMode;

    // Run `worker` over `items` with at most `size` in flight - keeps bulk proxy
    // checks fast without firing hundreds of simultaneous network requests.
    async function pool(items, size, worker) {
      let i = 0;
      const runners = new Array(Math.min(size, items.length)).fill(0).map(async () => {
        while (i < items.length) { const idx = i++; await worker(items[idx], idx); }
      });
      await Promise.all(runners);
    }

    // ------------------------------------------------------- left: profile tags
    // The left column lists the profiles of the currently-selected "Nhóm" as
    // removable tags. Removing a tag drops that profile from the import target
    // list (UI-only; there is no profile↔proxy assignment backend yet).
    let group = ADD_STATE.group;
    let groupProfiles = [];           // [{ id, name }] of the selected group
    const excluded = ADD_STATE.excluded;   // profile ids removed from the import list (persists across nav)
    const profileTagsWrap = el('div.px-profiletags');
    const profilesCountEl = el('span.px-profiles-count', { text: '' });
    const profilesHead = el('div.px-profiles-head', {}, [
      el('span.px-profiles-h', { text: 'Hồ sơ áp dụng' }),
      profilesCountEl,
    ]);
    // PHÂN TRANG cho panel "Hồ sơ áp dụng": chọn "Tất cả các nhóm" có thể ra HÀNG TRĂM
    // hồ sơ, vẽ hết thì khung dài vô tận và đẩy cả form nhập proxy xuống dưới màn hình.
    // Dùng ĐÚNG mẫu .pager của toàn app (Hồ sơ / Nhật ký / Thùng rác / Thành viên và
    // lưới proxy ngay dưới trang này): "Số dòng mỗi trang:" + ô NHẬP SỐ gõ tay được
    // (pageSizeSelect, kèm dropdown 10/25/50/100) + "x - y trên z" + ◀ + số trang + ▶.
    // Cùng bộ tùy chọn 10/25/50/100 và mặc định 25 y như lưới proxy để hai thanh phân
    // trang trên CÙNG một trang không lệch nhau.
    // LUÔN HIỆN, kể cả khi chỉ có 1 trang hoặc chưa có hồ sơ nào - các lưới khác trong
    // app đều vậy (hiện "0 - 0 trên 0"), ẩn đi mới là chỗ lạc điệu.
    // Lưu ý: đây CHỈ là chuyện hiển thị - mọi nơi cần danh sách hồ sơ đích vẫn gọi
    // targetProfiles() (toàn bộ, không theo trang), nên chia trang không ảnh hưởng
    // việc gán proxy.
    let ptagPage = 0;
    let ptagPageSize = 25;
    const ptagNums = el('div.page-nums');
    const ptagTotal = el('span.muted');
    const ptagSizeSel = pageSizeSelect([10, 25, 50, 100], {
      value: ptagPageSize,
      onChange: (v) => { ptagPageSize = v; ptagPage = 0; renderProfileTags(); },
    });
    const ptagPager = el('div.pager.px-profiles-pager', {}, [
      el('span.muted', { text: 'Số dòng mỗi trang:' }),
      ptagSizeSel,
      ptagTotal,
      el('button.icon-btn', {
        html: icon('chevron'), title: 'Trang trước', style: { transform: 'rotate(180deg)' },
        onclick: () => { if (ptagPage > 0) { ptagPage--; renderProfileTags(); } },
      }),
      ptagNums,
      el('button.icon-btn', {
        html: icon('chevron'), title: 'Trang sau',
        onclick: () => {
          const pages = Math.ceil(targetProfiles().length / ptagPageSize);
          if (ptagPage < pages - 1) { ptagPage++; renderProfileTags(); }
        },
      }),
    ]);
    const profilesPanel = el('div.px-profiles', {}, [
      profilesHead,
      profileTagsWrap,
      ptagPager,
    ]);
    function targetProfiles() { return groupProfiles.filter((p) => !excluded.has(p.id)); }
    function renderProfileTags(loading) {
      clear(profileTagsWrap);
      if (loading) {
        profilesHead.style.display = '';
        profileTagsWrap.appendChild(el('span.px-profiles-empty', { text: 'Đang tải…' }));
        profilesCountEl.textContent = '';
        ptagTotal.textContent = `0 - 0 ${t('trên')} 0`;
        renderPtagPager(1);
        return;
      }
      const shown = targetProfiles();
      profilesCountEl.textContent = shown.length ? `${shown.length} ${t('hồ sơ')}` : '';
      if (!shown.length) {
        // No profiles → hide the "Hồ sơ áp dụng" heading; show a taller empty
        // bordered box with the vector centered + "Không có hồ sơ" caption below.
        profilesHead.style.display = 'none';
        profileTagsWrap.appendChild(el('div.px-profiles-empty', {}, [
          el('div.px-profiles-empty-art', { html: noProfileSvg }),
          el('div.px-profiles-empty-text', { text: 'Không có hồ sơ' }),
        ]));
        ptagTotal.textContent = `0 - 0 ${t('trên')} 0`;
        renderPtagPager(1);
        return;
      }
      profilesHead.style.display = '';
      // Kẹp lại số trang: bỏ chip cuối của trang cuối (hoặc đổi cỡ trang / đổi nhóm) làm
      // danh sách co lại, trang đang xem có thể vượt quá số trang mới → panel trắng trơn.
      const pages = Math.max(1, Math.ceil(shown.length / ptagPageSize));
      if (ptagPage > pages - 1) ptagPage = pages - 1;
      const from = ptagPage * ptagPageSize;
      shown.slice(from, from + ptagPageSize).forEach((p) => {
        profileTagsWrap.appendChild(el('span.px-ptag', {}, [
          el('span.px-ptag-name', { text: shortId(p), title: p.name }),
          el('button.px-ptag-x', { html: icon('close'), onclick: () => { excluded.add(p.id); renderProfileTags(); } }),
        ]));
      });
      // Y hệt các lưới khác: "1 - 25 trên 137" (vế đầu là vị trí chip đầu/cuối của trang).
      ptagTotal.textContent = `${from + 1} - ${Math.min(from + ptagPageSize, shown.length)} ${t('trên')} ${shown.length}`;
      renderPtagPager(pages);
    }
    // Nút số trang - cùng luật rút gọn "…" với lưới proxy / Hồ sơ / Nhật ký.
    function renderPtagPager(pages) {
      clear(ptagNums);
      for (let i = 0; i < pages; i++) {
        if (pages > 7 && i > 1 && i < pages - 2 && Math.abs(i - ptagPage) > 1) {
          if (i === 2 || i === pages - 3) ptagNums.appendChild(el('span.muted', { text: '…' }));
          continue;
        }
        ptagNums.appendChild(el('button.page-num' + (i === ptagPage ? '.active' : ''), {
          text: String(i + 1), onclick: () => { ptagPage = i; renderProfileTags(); },
        }));
      }
    }
    async function loadGroupProfiles() {
      ptagPage = 0;   // đổi nhóm = danh sách khác hẳn → luôn về trang 1
      renderProfileTags(true);
      try {
        let list;
        if (group === '__all__') list = await remote.profiles.list();
        else if (group === '__ungrouped__') { const all = await remote.profiles.list(); list = (all || []).filter((p) => !p.groupId); }
        else list = await remote.profiles.list(group);
        groupProfiles = (list || []).map((p) => ({ id: p.id, name: p.name, profileId: p.profileId }));
      } catch (_) { groupProfiles = []; }
      renderProfileTags();
    }

    // ------------------------------------------------------------- right: form
    const typeSel = customSelect(PROXY_TYPES, { value: proxyType, width: '100%', onChange: (v) => { proxyType = v; ADD_STATE.proxyType = v; reparse(); } });
    // "Chế độ chèn proxy" ALSO drives filtering: "Không lặp lại" dedups by
    // type|host|port; "Lặp lại" keeps duplicates; "Một cho tất cả" dedups too.
    const modeSel = customSelect(INSERT_MODES, { value: insertMode, width: '100%', onChange: (v) => { insertMode = v; ADD_STATE.insertMode = v; reparse(); } });
    const tagsSel = customSelect([], { value: ADD_STATE.tags, placeholder: 'Tìm tab/Tạo tab', width: '100%', creatable: true, createPlaceholder: 'Tạo tab', onChange: (v) => { ADD_STATE.tags = v || ''; }, onCreate: (v) => { ADD_STATE.tags = v || ''; } });
    // Nhóm - plain group picker (same style/options as "Hồ sơ"): "Tất cả các
    // nhóm" + "Chưa chia nhóm" sentinels then the real groups. Picks the group
    // whose profiles the proxy is added to. Not creatable.
    const groupField = el('div.field', {}, [el('label', { text: 'Nhóm' })]);
    function buildGroupSel(list) {
      const opts = [
        { value: '__all__', label: 'Tất cả các nhóm' },
        { value: '__ungrouped__', label: 'Chưa chia nhóm' },
        ...(list || []).map((g) => ({ value: String(g.id), label: g.name })),
      ];
      const sel = customSelect(opts, {
        value: group, width: '100%',
        onChange: (v) => { group = v; ADD_STATE.group = v; excluded.clear(); loadGroupProfiles(); },
      });
      while (groupField.children.length > 1) groupField.removeChild(groupField.lastChild);
      groupField.appendChild(sel);
    }
    buildGroupSel([]);
    remote.groups.list().then(buildGroupSel).catch(() => {});
    loadGroupProfiles();
    // load persisted proxies into the grid (so a refresh doesn't lose them)
    loadSaved();
    const listBox = el('textarea.input.px-addlist', {
      placeholder: [
        `host:port:user:pass ${t('hoặc')} host:port  (${t('mỗi dòng 1 proxy')})`,
        `${t('Ví dụ')}:`,
        '45.76.120.33:8080:username:password',
        '45.76.120.33:8080:username:password',
        '45.76.120.33:8080',
        '45.76.120.33:8080',
      ].join('\n'),
    });
    listBox.value = ADD_STATE.textarea || '';
    // The textarea is the import source. Persist its content so nav away/back keeps
    // what was typed, and AUTO-IMPORT into the grid when focus leaves it (the
    // explicit "Nhập vào danh sách" button was redundant - 1 dòng = 1 proxy).
    listBox.addEventListener('input', () => { ADD_STATE.textarea = listBox.value; });
    listBox.addEventListener('blur', () => { if ((listBox.value || '').trim()) importFromTextarea(); });

    const form = el('div.px-form', {}, [
      el('div.field-row', {}, [
        el('div.field', {}, [el('label', { text: 'Loại proxy' }), typeSel]),
        el('div.field', {}, [el('label', { text: 'Chế độ chèn proxy' }), modeSel]),
      ]),
      el('div.field-row', {}, [
        groupField,
        el('div.field', {}, [el('label', { text: 'Tags' }), tagsSel]),
      ]),
      listBox,
    ]);

    const cols = el('div.px-addcols', {}, [profilesPanel, form]);

    // check bar - bulk "Kiểm tra Proxy" (checks the selected rows) + the
    // "Kiểm tra proxy trước khi thêm" toggle + running count.
    const countEl = el('span.px-addcount', { text: `${t('Đã thêm Proxy')}:0` });
    const precheckCb = el('input', { type: 'checkbox', checked: true });
    const bulkCheckBtn = el('button.btn.primary.px-addcheckbtn', {
      html: `${icon('searchCheck')}<span>Kiểm tra Proxy</span>`,
      onclick: () => checkSelected(),
    });
    // Bordered "xóa" icon next to "Kiểm tra Proxy" - bulk-deletes the selected rows
    // (staged rows leave the grid; saved rows are removed from proxies.db).
    const bulkDelBtn = el('button.icon-btn.px-adddel', { html: icon('trash'), title: 'Xóa proxy đã chọn' });
    bulkDelBtn.onclick = async () => {
      const chosen = lastRows.filter((r) => selected.has(rowUid(r)));
      if (!chosen.length) { toast('Chưa chọn proxy để xóa', 'warn'); return; }
      const ids = chosen.filter((r) => r._saved && r._id).map((r) => r._id);
      for (let i = stagedRows.length - 1; i >= 0; i--) { if (selected.has(rowUid(stagedRows[i]))) stagedRows.splice(i, 1); }
      try {
        if (ids.length) await window.vt?.proxies?.remove(ids);
        selected.clear();
        await loadSaved();
        toast(tf('Đã xóa {0} proxy', chosen.length), 'ok');
      } catch (e) {
        await loadSaved();
        notifyError(e, 'Xóa proxy thất bại');
      }
    };
    // Các nút ghi proxy cần quyền edit_proxy → khóa mềm. Áp ngay + áp lại sau khi
    // loadPermissions() xong (tránh chớp-khóa với chủ/quản trị lúc chờ nạp quyền).
    const gatedProxyBtns = [bulkDelBtn];
    const applyProxyGate = () => { const ce = canEditProxy(); gatedProxyBtns.forEach((b) => gateProxyBtn(b, ce)); };
    const checkBar = el('div.px-addcheck', {}, [
      bulkCheckBtn,
      bulkDelBtn,
      countEl,
      // pushed to the far right (margin-left:auto in CSS)
      el('label.px-dedup', {}, [precheckCb, el('span', { text: 'Kiểm tra proxy trước khi thêm' })]),
    ]);

    // grid = the source of truth for adding. Rows come from the persisted pool
    // (saved) + the staged rows imported from the textarea; row actions act on
    // whichever list a row belongs to.
    const th = (t) => el('th', {}, [el('span', { text: t })]);
    const tbody = el('tbody');
    const selectAll = el('input', { type: 'checkbox' });
    const table = el('table.grid.profiles-grid.px-addtable', {}, [
      el('thead', {}, [el('tr', {}, [
        el('th.col-check', {}, [selectAll]),
        th('#'),
        th('Loại proxy'), th('Proxy Host'), th('Port Proxy'), th('Proxy username'),
        th('Proxy Password'), th('Liên kết thay đổi IP'), th('Ghi chú'), th('Xuất IP'),
        el('th.col-action', {}, [el('span', { text: 'Hành động' })]),
      ])]),
      tbody,
    ]);

    // Check results survive re-parsing (keyed by type|host|port) so a checked
    // proxy keeps its status / exit IP while the user keeps typing.
    const checkResults = new Map();
    const rowKey = (r) => `${r.type}|${r.host}|${r.port}`;
    // Row uid unifies selection across SAVED proxies (persisted in proxies.db) and
    // STAGED grid rows (imported from the textarea, awaiting "Thêm Proxy"):
    // saved → 's:<id>', staged → 'g:<uid>'.
    const rowUid = (r) => (r._saved ? `s:${r._id}` : `g:${r._uid}`);
    const selected = new Set();      // selected row uids
    let lastRows = [];               // saved rows ++ staged rows (what the grid shows)
    let pxPage = 0;                  // current page (0-based) for the proxy grid
    let pxPageSize = 25;             // rows per page
    const pageNumbers = el('div.page-nums');
    const pagerText = el('span.muted');
    let savedRows = [];              // persisted proxies (vt.proxies.list())
    const stagedRows = ADD_STATE.staged;   // imported-but-not-added rows (persists across nav)
    // `r.type` → enum proxyType của hồ sơ: nay dùng normalizeProxyType (data/proxy-types.js)
    // thay cho bảng map riêng, nên dòng mới ('HTTP'/'SOCKS4'/'SOCKS5'/'Token') và dòng cũ
    // ('socks5'/'https'/'http'/'ssh') đều quy về đúng một trong bốn enum.

    // Show the exit-IP location (like the Hồ sơ "Vị trí IP" action).
    function showExitLocation(data) {
      const parts = [data.exitIp, data.city, data.region, data.country].filter(Boolean);
      toast(parts.join(' · ') || 'Không có dữ liệu', 'ok');
    }
    // Draw the "Xuất IP" cell. While checking it shows a loading spinner; a
    // failed check shows "Lỗi Proxy"; a good check mirrors the Hồ sơ "IP" cell
    // (IP on top, flag + region below) plus the "Vị trí IP" location action.
    // Status lives entirely in this cell - no toast.
    function renderExitCell(cell, data) {
      clear(cell);
      if (data && data.loading) {
        cell.appendChild(el('span.px-exitloading', {}, [el('span.btn-spin'), el('span', { text: 'Đang kiểm tra' })]));
        return;
      }
      if (data && data.status === 'fail') {
        cell.appendChild(el('span.px-exiterr', { text: 'Lỗi Proxy' }));
        return;
      }
      const ip = data && data.exitIp ? data.exitIp : '';
      if (!ip) { cell.appendChild(el('span', { text: '-' })); return; }
      const botParts = [
        flagImg((data && data.country) || ''),
        data && data.region ? el('span.ip-region', { text: data.region }) : null,
      ].filter(Boolean);
      cell.appendChild(el('div.ip-cell.px-exitcell', {}, [
        el('div.ip-actions', {}, [
          el('button.ip-act.loc', { html: icon('location'), title: 'Vị trí IP', onclick: () => showExitLocation(data) }),
        ]),
        el('div.ip-info', {}, [
          el('div.ip-top', { text: ip }),
          botParts.length ? el('div.ip-bot', {}, botParts) : null,
        ]),
      ]));
    }

    // Perform the actual proxy check for one row; store + return the result.
    // Status is written into the cell only (no toast).
    // Persist a check result onto a SAVED proxy so its exit IP / status survives
    // a refresh (preview rows aren't persisted until "Thêm Proxy").
    async function persistSaved(r, data) {
      if (!r._saved || !r._id) return;
      try {
        await window.vt?.proxies?.update(r._id, {
          status: data.status || '', exitIp: data.exitIp || '',
          exitCountry: data.country || '', exitRegion: data.region || '', exitCity: data.city || '',
        });
      } catch (_) { /* ignore */ }
    }
    async function runCheck(r) {
      try {
        const res = await window.vt?.proxy?.check({ type: r.type, host: r.host, port: r.port, user: r.user, pass: r.pass });
        const ok = !!(res && res.ok);
        const g = ok && res.geo ? res.geo : {};
        const data = { status: ok ? 'ok' : 'fail', exitIp: g.ip || '', country: g.country || '', region: g.region || '', city: g.city || '' };
        checkResults.set(rowKey(r), data);
        await persistSaved(r, data);
        return data;
      } catch (_) {
        const data = { status: 'fail', exitIp: '' };
        checkResults.set(rowKey(r), data);
        await persistSaved(r, data);
        return data;
      }
    }

    // Per-row "Kiểm tra" button.
    async function checkRow(r, exitCell, btn) {
      renderExitCell(exitCell, { loading: true });
      if (btn) { btn.disabled = true; btn.classList.add('is-loading'); }
      const data = await runCheck(r);
      renderExitCell(exitCell, data);
      if (btn) { btn.disabled = false; btn.classList.remove('is-loading'); }
    }

    // Bulk "Kiểm tra Proxy" - checks the SELECTED rows (or all rows if none are
    // selected). Each row's exit cell shows the loading spinner then the result.
    let checking = false;
    async function checkSelected() {
      if (checking) return;
      const chosen = lastRows.filter((r) => selected.has(rowUid(r)));
      const target = chosen.length ? chosen : lastRows;
      if (!target.length) { toast('Chưa có proxy để kiểm tra', 'warn'); return; }
      checking = true;
      bulkCheckBtn.disabled = true;
      bulkCheckBtn.innerHTML = '<span class="btn-spin"></span><span>Đang kiểm tra…</span>';
      target.forEach((r) => { if (r._exitCell) renderExitCell(r._exitCell, { loading: true }); });
      await pool(target, 8, async (r) => { const data = await runCheck(r); if (r._exitCell) renderExitCell(r._exitCell, data); });
      bulkCheckBtn.disabled = false;
      bulkCheckBtn.innerHTML = `${icon('searchCheck')}<span>Kiểm tra Proxy</span>`;
      checking = false;
    }

    // "Chỉnh sửa" - edit one proxy's fields in a modal. Saved rows persist via
    // vt.proxies.update (+ reload); staged rows just mutate the in-memory row (+
    // reparse). Fields mirror the add-form columns.
    function openEditProxyModal(r) {
      const typeSel = customSelect(PROXY_TYPES, { value: normalizeProxyType(r.type), width: '100%' });
      const inp = (val) => el('input.input', { type: 'text', value: val || '' });
      const hostI = inp(r.host); const portI = inp(r.port);
      const userI = inp(r.user); const passI = inp(r.pass);
      const curlI = inp(r.changeUrl); const noteI = inp(r.note);
      const field = (label, ctrl) => el('div.field', {}, [el('label', { text: label }), ctrl]);
      const saveBtn = el('button.btn.primary', { text: 'Lưu' });
      saveBtn.onclick = async () => {
        const next = {
          type: typeSel.value || PROXY_TYPE_DEFAULT,
          host: (hostI.value || '').trim(), port: (portI.value || '').trim(),
          user: userI.value || '', pass: passI.value || '',
          changeUrl: (curlI.value || '').trim(), note: noteI.value || '',
        };
        if (!next.host) { toast('Thiếu Proxy Host', 'warn'); return; }
        saveBtn.disabled = true;
        if (r._saved && r._id) {
          try {
            await window.vt?.proxies?.update(r._id, {
              type: next.type, host: next.host, port: next.port,
              username: next.user, password: next.pass, changeUrl: next.changeUrl, note: next.note,
            });
            logActivity('update_proxy', { profileName: `${next.host}:${next.port}` });
            closeModal();
            await loadSaved();
            toast('Đã lưu proxy', 'ok');
          } catch (e) {
            saveBtn.disabled = false;
            notifyError(e, 'Lưu proxy thất bại');
          }
        } else {
          Object.assign(r, next);
          closeModal();
          reparse();
          toast('Đã lưu proxy', 'ok');
        }
      };
      openModal({
        title: 'Chỉnh sửa Proxy', width: 520,
        body: [el('div.px-editform', {}, [
          el('div.field-row', {}, [field('Loại proxy', typeSel), field('Port Proxy', portI)]),
          field('Proxy Host', hostI),
          el('div.field-row', {}, [field('Proxy username', userI), field('Proxy Password', passI)]),
          field('Liên kết thay đổi IP', curlI),
          field('Ghi chú', noteI),
        ])],
        footer: [el('button.btn', { text: 'Hủy', onclick: closeModal }), saveBtn],
      });
    }

    // Build one <tr> for a SAVED (persisted) or PREVIEW (textarea) row.
    function renderRow(r, idx) {
      const td = (t) => el('td', {}, [el('span', { text: t || '-' })]);
      const cached = checkResults.get(rowKey(r)) || (r._saved ? r._savedExit : {});
      const exitCell = el('td.col-exit', {});
      renderExitCell(exitCell, cached);
      r._exitCell = exitCell;   // let bulk-check target this row's cell
      const uid = rowUid(r);
      const cb = el('input', { type: 'checkbox', checked: selected.has(uid) });
      cb.onchange = () => { if (cb.checked) selected.add(uid); else selected.delete(uid); syncSelectAll(); };
      const checkBtn = el('button.px-rowcheck', { text: 'Kiểm tra', onclick: () => checkRow(r, exitCell, checkBtn) });
      const moreBtn = el('button.icon-btn.kebab.px-rowmore', { html: icon('moreVertical') });
      // Saved rows act on the DB (duplicate/delete); staged rows act on the grid.
      // Sửa/Sao chép/Xóa proxy → khóa mềm theo quyền (đọc can() mỗi lần mở menu).
      hoverMenu(moreBtn, () => {
       const lockAttrs = canEditProxy() ? {} : { disabled: true, title: PROXY_LOCK_MSG };
       return (r._saved ? [
        { label: 'Chỉnh sửa', icon: 'edit', ...lockAttrs, onClick: () => openEditProxyModal(r) },
        { label: 'Sao chép', icon: 'copy', ...lockAttrs, onClick: async () => { try { await window.vt?.proxies?.duplicate(r._id); await loadSaved(); } catch (e) { notifyError(e, 'Sao chép proxy thất bại'); } } },
        '-',
        { label: 'Xóa', icon: 'trash', danger: true, ...lockAttrs, onClick: async () => { try { await window.vt?.proxies?.remove([r._id]); logActivity('delete_proxy', { profileName: `${r.host}:${r.port}` }); await loadSaved(); } catch (e) { notifyError(e, 'Xóa proxy thất bại'); } } },
      ] : [
        { label: 'Chỉnh sửa', icon: 'edit', ...lockAttrs, onClick: () => openEditProxyModal(r) },
        { label: 'Sao chép', icon: 'copy', ...lockAttrs, onClick: () => { const i = stagedRows.indexOf(r); if (i >= 0) stagedRows.splice(i + 1, 0, { ...r, _uid: STAGED_UID++, _exitCell: null }); reparse(); } },
        '-',
        { label: 'Xóa', icon: 'trash', danger: true, ...lockAttrs, onClick: () => { const i = stagedRows.indexOf(r); if (i >= 0) stagedRows.splice(i, 1); reparse(); } },
      ]);
      });
      // Ticking a row's checkbox must NOT tint the row - selection is tracked in
      // the `selected` Set + checkbox state only (no `.selected` row background).
      return el('tr', {}, [
        el('td.col-check', {}, [cb]),
        el('td', {}, [el('span', { text: String(idx + 1) })]),
        td(normalizeProxyType(r.type)), td(r.host), td(r.port), td(r.user), td(r.pass),
        td(r.changeUrl), td(r.note), exitCell,
        el('td.col-action', {}, [el('div.px-rowacts', {}, [checkBtn, moreBtn])]),
      ]);
    }

    // Rebuild the grid from the two row sources - persisted proxies (survive a
    // refresh) first, then the staged rows imported from the textarea. The
    // textarea is NOT a source of truth here; "Nhập vào danh sách" imports into
    // `stagedRows` and the grid is the source of truth for "Thêm Proxy".
    function reparse() {
      const savedAsRows = savedRows.map((sp) => ({
        type: sp.type, host: sp.host, port: sp.port, user: sp.username, pass: sp.password,
        changeUrl: sp.changeUrl, note: sp.note, _saved: true, _id: sp.id,
        _savedExit: {
          status: sp.status || (sp.exitIp ? 'ok' : ''), exitIp: sp.exitIp || '',
          country: sp.exitCountry || '', region: sp.exitRegion || '', city: sp.exitCity || '',
        },
      }));
      lastRows = savedAsRows.concat(stagedRows);
      // prune selection to rows that still exist
      const uids = new Set(lastRows.map(rowUid));
      [...selected].forEach((u) => { if (!uids.has(u)) selected.delete(u); });
      // Clamp the page in case rows shrank (delete/dedup) below the current window.
      const pages = Math.max(1, Math.ceil(lastRows.length / pxPageSize));
      if (pxPage > pages - 1) pxPage = pages - 1;
      const from = pxPage * pxPageSize;
      const slice = lastRows.slice(from, from + pxPageSize);
      // Build only the current page off-DOM (one reflow). The "#" column keeps a
      // continuous global number (from + i) across pages.
      const frag = document.createDocumentFragment();
      slice.forEach((r, i) => frag.appendChild(renderRow(r, from + i)));
      clear(tbody);
      tbody.appendChild(frag);
      renderPxPager(pages);
      const total = lastRows.length;
      pagerText.textContent = total === 0 ? `0 - 0 ${t('trên')} 0` : `${from + 1} - ${Math.min(from + pxPageSize, total)} ${t('trên')} ${total}`;
      syncSelectAll();
      // counter = staged proxies waiting to be added
      countEl.textContent = `${t('Đã thêm Proxy')}:${stagedRows.length}`;
    }

    // Numbered page buttons (house style - same collapse rule as log/profiles/trash).
    function renderPxPager(pages) {
      clear(pageNumbers);
      for (let i = 0; i < pages; i++) {
        if (pages > 7 && i > 1 && i < pages - 2 && Math.abs(i - pxPage) > 1) {
          if (i === 2 || i === pages - 3) pageNumbers.appendChild(el('span.muted', { text: '…' }));
          continue;
        }
        pageNumbers.appendChild(el('button.page-num' + (i === pxPage ? '.active' : ''), { text: String(i + 1), onclick: () => { pxPage = i; reparse(); } }));
      }
    }

    // Parse the textarea into staged grid rows (1 line = 1 proxy). Dedups per the
    // "Chế độ chèn proxy" option (against both already-staged and saved rows),
    // then clears the textarea. This is the ONLY path from text → grid.
    function importFromTextarea() {
      const lines = (listBox.value || '').split('\n');
      let parsed = [];
      lines.forEach((ln) => { const p = parseProxyLine(ln, proxyType); if (p) parsed.push(p); });
      if (!parsed.length) { toast('Không có proxy hợp lệ để nhập', 'warn'); return; }
      let added = 0;
      if (insertMode === 'repeat') {
        parsed.forEach((p) => { stagedRows.push({ ...p, _uid: STAGED_UID++ }); added++; });
      } else {
        const seen = new Set(stagedRows.map(rowKey));
        savedRows.forEach((sp) => seen.add(`${sp.type}|${sp.host}|${sp.port}`));
        parsed.forEach((p) => { const k = rowKey(p); if (seen.has(k)) return; seen.add(k); stagedRows.push({ ...p, _uid: STAGED_UID++ }); added++; });
      }
      listBox.value = '';
      ADD_STATE.textarea = '';
      reparse();
      toast(added ? `${t('Đã nhập')} ${added} proxy ${t('vào danh sách')}` : 'Không có proxy mới (đã trùng)', added ? 'ok' : 'warn');
    }
    function syncSelectAll() {
      const total = lastRows.length;
      const sel = lastRows.filter((r) => selected.has(rowUid(r))).length;
      selectAll.checked = total > 0 && sel === total;
      selectAll.indeterminate = sel > 0 && sel < total;
    }
    selectAll.onchange = () => {
      if (selectAll.checked) lastRows.forEach((r) => selected.add(rowUid(r)));
      else selected.clear();
      reparse();
    };

    // Load persisted proxies (proxies.db) into the grid so the pool survives a
    // refresh / re-render; also seed the check cache so saved exit IPs show.
    async function loadSaved() {
      try { savedRows = (await window.vt?.proxies?.list()) || []; }
      catch (_) { savedRows = []; }
      savedRows.forEach((sp) => {
        const k = `${sp.type}|${sp.host}|${sp.port}`;
        if (!checkResults.has(k) && (sp.exitIp || sp.status)) {
          checkResults.set(k, {
            status: sp.status || (sp.exitIp ? 'ok' : ''), exitIp: sp.exitIp || '',
            country: sp.exitCountry || '', region: sp.exitRegion || '', city: sp.exitCity || '',
          });
        }
      });
      reparse();
      backfillFlags();
    }

    // Self-heal proxies checked BEFORE the exit-country column existed: they have a
    // saved exit IP but no country → no flag on load. Resolve each one's country by
    // a DIRECT ip lookup (no proxy needed, works even if the proxy is now down),
    // persist it, and repaint the cell - so the flag appears without a re-check.
    let backfilling = false;
    async function backfillFlags() {
      if (backfilling || !window.vt?.proxies?.geoIp) return;
      const stale = savedRows.filter((sp) => sp.exitIp && !sp.exitCountry);
      if (!stale.length) return;
      backfilling = true;
      try {
        await pool(stale, 6, async (sp) => {
          let res;
          try { res = await window.vt.proxies.geoIp(sp.exitIp); } catch (_) { res = null; }
          if (!res || !res.ok || !res.geo || !res.geo.country) return;
          const g = res.geo;
          const k = `${sp.type}|${sp.host}|${sp.port}`;
          const data = {
            status: sp.status || 'ok', exitIp: sp.exitIp,
            country: g.country || '', region: sp.exitRegion || g.region || '', city: sp.exitCity || g.city || '',
          };
          checkResults.set(k, data);
          // reflect in the in-memory row too, so a later reparse keeps the flag
          sp.exitCountry = data.country; if (!sp.exitRegion) sp.exitRegion = data.region; if (!sp.exitCity) sp.exitCity = data.city;
          try { await window.vt.proxies.update(sp.id, { exitCountry: data.country, exitRegion: data.region, exitCity: data.city }); } catch (_) { /* ignore */ }
          // repaint the row's cell if it's still on screen
          const row = lastRows.find((r) => r._saved && r._id === sp.id);
          if (row && row._exitCell) renderExitCell(row._exitCell, data);
        });
      } finally { backfilling = false; }
    }

    // Assign the just-added proxies to the selected profiles → their "IP" cell in
    // the Hồ sơ datagrid now shows this proxy. "Một cho tất cả" gives every profile
    // the first proxy; otherwise proxies are zipped to profiles by index.
    async function assignProxiesToProfiles(rows) {
      const profs = targetProfiles();
      if (!profs.length || !rows || !rows.length) return;
      const toDyn = (r) => ({ proxyType: normalizeProxyType(r.type), proxyHost: r.host || '', proxyPort: String(r.port || ''), proxyUser: r.user || '', proxyPass: r.pass || '' });
      let pairs;
      if (insertMode === 'one_for_all') {
        const dyn = toDyn(rows[0]);
        pairs = profs.map((p) => [p, dyn]);
      } else {
        const nn = Math.min(profs.length, rows.length);
        pairs = [];
        for (let i = 0; i < nn; i++) pairs.push([profs[i], toDyn(rows[i])]);
      }
      await pool(pairs, 6, async ([p, dyn]) => { try { await remote.profiles.updateDynamic(p.id, dyn); } catch (_) { /* ignore */ } });
    }

    // Large success modal shown after proxies are added.
    function showSuccessModal(added, skipped, profileCount) {
      let head;
      if (added > 0) { head = `${t('Đã thêm')} ${added} proxy`; if (profileCount) head += ` ${t('cho')} ${profileCount} ${t('hồ sơ')}`; }
      else if (profileCount) { head = `${t('Đã gán proxy cho')} ${profileCount} ${t('hồ sơ')}`; }
      else { head = t('Hoàn tất'); }
      const sub = skipped ? `${head}. ${t('Bỏ qua')} ${skipped} ${t('proxy lỗi')}.` : `${head}.`;
      openModal({
        title: '', width: 460,
        body: [el('div.px-success', {}, [
          el('div.px-success-icon', { html: icon('check') }),
          el('div.px-success-title', { text: 'Thêm proxy thành công' }),
          el('div.px-success-sub', { text: sub }),
        ])],
        footer: [el('button.btn.primary', { text: 'Hoàn tất', onclick: closeModal })],
      });
    }

    // footer
    const addBtn = el('button.btn.primary', { text: 'Thêm Proxy' });
    addBtn.onclick = async () => {
      // "Thêm Proxy" works off the DATAGRID, never the textarea. Flush any leftover
      // textarea text into the grid first (the textarea only ever feeds the grid).
      if ((listBox.value || '').trim()) importFromTextarea();
      // The datagrid = persisted rows + staged rows. Only the staged (not-yet-saved)
      // rows get inserted into the pool; the persisted ones are already there.
      const gridRows = lastRows.slice();
      if (!gridRows.length) { toast('Danh sách trống - hãy nhập proxy vào danh sách trước', 'warn'); return; }
      let stagedToAdd = gridRows.filter((r) => !r._saved);
      addBtn.disabled = true;
      const restore = () => { addBtn.disabled = false; addBtn.textContent = 'Thêm Proxy'; };
      let skipped = 0;
      // "Kiểm tra proxy trước khi thêm" - validate the new rows and only keep the
      // ones that pass (persisted rows were already checked when added).
      if (precheckCb.checked && stagedToAdd.length) {
        addBtn.innerHTML = '<span class="btn-spin"></span><span>Đang kiểm tra…</span>';
        stagedToAdd.forEach((r) => { if (r._exitCell) renderExitCell(r._exitCell, { loading: true }); });
        await pool(stagedToAdd, 8, async (r) => { const data = await runCheck(r); if (r._exitCell) renderExitCell(r._exitCell, data); });
        const before = stagedToAdd.length;
        stagedToAdd = stagedToAdd.filter((r) => (checkResults.get(rowKey(r)) || {}).status === 'ok');
        skipped = before - stagedToAdd.length;
      }
      // Sentinel group values ("all"/"ungrouped") are not real group ids.
      const gid = (group === '__all__' || group === '__ungrouped__') ? null : group;
      const tags = tagsSel && tagsSel.value ? tagsSel.value : '';
      try {
        // 1) persist the new (staged) rows into the pool
        let insertedCount = 0;
        if (stagedToAdd.length) {
          const items = stagedToAdd.map((r) => {
            const c = checkResults.get(rowKey(r)) || {};
            return {
              type: r.type, host: r.host, port: r.port, username: r.user, password: r.pass,
              changeUrl: r.changeUrl, note: r.note, groupId: gid, tags, insertMode,
              status: c.status || '', exitIp: c.exitIp || '',
              exitCountry: c.country || '', exitRegion: c.region || '', exitCity: c.city || '',
            };
          });
          const saved = await window.vt?.proxies?.addBatch(items);
          insertedCount = Array.isArray(saved) ? saved.length : items.length;
          try { items.forEach((it) => logActivity('update_proxy', { profileName: `${it.host}:${it.port}` })); } catch (_) { /* log best-effort */ }
        }
        // 2) assign every VALID datagrid proxy (persisted + newly-added, in grid
        //    order) to the selected profiles' "IP" cell (Hồ sơ datagrid).
        const passSet = new Set(stagedToAdd);
        const assignRows = gridRows.filter((r) => r._saved || passSet.has(r));
        const profileCount = targetProfiles().length;
        await assignProxiesToProfiles(assignRows);
        // 3) drop the committed staged rows (failed/precheck-skipped ones stay so
        //    the user can retry), then reload the persisted pool so the grid keeps
        //    the proxies (survives a refresh - data lives in proxies.db).
        const addedSet = new Set(stagedToAdd);
        for (let i = stagedRows.length - 1; i >= 0; i--) { if (addedSet.has(stagedRows[i])) stagedRows.splice(i, 1); }
        await loadSaved();
        // Show the success modal on any meaningful add (new proxies inserted OR
        // datagrid proxies assigned to profiles); toast only for no-op / all-failed.
        if (insertedCount > 0 || profileCount > 0) showSuccessModal(insertedCount, skipped, profileCount);
        else if (skipped > 0) toast(`${skipped} ${t('proxy lỗi - không thêm được proxy nào')}`, 'warn');
        else toast('Các proxy trong danh sách đã được thêm rồi', 'ok');
      } catch (e) {
        notifyError(e, 'Lưu proxy thất bại');
      }
      restore();
    };
    const pxSizeSel = pageSizeSelect([10, 25, 50, 100], { value: pxPageSize, onChange: (v) => { pxPageSize = v; pxPage = 0; reparse(); } });
    // Thanh phân trang sống trong FOOTER, dồn về bên phải (spacer flex đẩy 2 nút sang trái).
    const pxPager = el('div.pager', { style: { padding: '0', flex: '0 0 auto' } }, [
      el('span.muted', { text: 'Số dòng mỗi trang' }), pxSizeSel,
      pagerText,
      el('button.icon-btn', { html: icon('chevron'), style: { transform: 'rotate(180deg)' }, onclick: () => { if (pxPage > 0) { pxPage--; reparse(); } } }),
      pageNumbers,
      el('button.icon-btn', { html: icon('chevron'), onclick: () => { if ((pxPage + 1) * pxPageSize < lastRows.length) { pxPage++; reparse(); } } }),
    ]);
    const footer = el('div.px-addfoot', {}, [
      addBtn,
      el('button.btn', { text: 'Hủy', onclick: () => { stagedRows.length = 0; listBox.value = ''; ADD_STATE.textarea = ''; reparse(); } }),
      el('span', { style: { flex: '1' } }),
      pxPager,
    ]);

    // addBtn đã có onclick thật → giờ mới đưa vào danh sách khóa (giữ _realClick).
    gatedProxyBtns.push(addBtn);
    applyProxyGate();
    loadPermissions().then(applyProxyGate).catch(() => {});

    return el('div.px-page.px-addpage', {}, [
      el('div.px-addscroll', {}, [cols, checkBar, el('div.px-addtablewrap', {}, [table])]),
      footer,
    ]);
  }

  function renderBody() {
    clear(body);
    // "Danh sách Proxy" now IS the add-proxy page (there is no proxy backend /
    // list yet, so the AdsPower-style "Thêm proxy" form is the main content).
    body.appendChild(tab === 'list' ? renderAddProxy() : renderRotating());
  }

  renderTabs();
  renderBody();
  // one big shadowed panel wraps EVERYTHING - the tab control + the per-tab body
  ctx.container.appendChild(el('div.px-root', {}, [el('div.px-card', {}, [tabsRow, body])]));
  return null;
}

// Proxy-themed empty illustration: a stylised globe (network/geolocation) with a
// small secure-relay shield badge - reads as "proxy / anonymous network".
const NO_PROXY_SVG = `
<svg width="96" height="80" viewBox="0 0 96 80" fill="none" xmlns="http://www.w3.org/2000/svg">
  <circle cx="40" cy="40" r="26" fill="currentColor" opacity=".08"/>
  <circle cx="40" cy="40" r="26" class="vec-paper" stroke="currentColor" stroke-opacity=".35" stroke-width="2"/>
  <ellipse cx="40" cy="40" rx="11" ry="26" stroke="currentColor" stroke-opacity=".28" stroke-width="2"/>
  <path d="M15 32h50M14 40h52M15 48h50" stroke="currentColor" stroke-opacity=".22" stroke-width="2" stroke-linecap="round"/>
  <circle cx="71" cy="58" r="15" class="vec-paper" stroke="currentColor" stroke-width="2"/>
  <path d="M71 50l6 2.4v3.4c0 3.3-2.4 5.5-6 6.6c-3.6-1.1-6-3.3-6-6.6v-3.4z" fill="currentColor" fill-opacity=".16" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
  <path d="M68.4 57.8l1.9 1.9 3.4-3.6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`;
