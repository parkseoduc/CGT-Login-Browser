// Banner quảng cáo ở HEADER - dải ảnh ngang (leaderboard) giữa thanh header, giống
// GenLogin. Nội dung do WEB ADMIN quản lý (bảng promos, type='banner'): app chỉ lấy
// các banner ĐANG HIỆU LỰC qua API rồi hiển thị - KHÔNG hardcode.
//
// Dạng CAROUSEL: bao nhiêu banner admin tạo + bật (status='active', trong khoảng
// start_at/end_at, đúng audience, có ảnh) thì bấy nhiêu ảnh trượt. Thứ tự trượt =
// priority ↓ rồi mới nhất (do server sắp trong /promo/active-list).
//   • 0 banner  → host rỗng (thanh header thu gọn như thường)
//   • 1 banner  → ảnh tĩnh, KHÔNG chạy timer
//   • ≥2 banner → tự trượt sang trái mỗi 5s, hết vòng quay lại ảnh đầu
//
// Tạm dừng khi: rê chuột lên banner, hoặc cửa sổ app bị ẩn/xuống nền - vừa đỡ tốn
// tài nguyên vừa không thổi phồng lượt xem khi người dùng không hề nhìn.
import { el, clear } from '../ui.js';

const SLIDE_MS = 5000;  // thời gian đứng yên của mỗi ảnh
const MAX_SLIDES = 20;  // trần an toàn, khớp MAX_LIST bên server

// Dọn dẹp của lần mount trước (timer + listener). Mount lại phải gọi, nếu không
// timer cũ vẫn chạy trên DOM đã bị xoá.
let disposePrev = null;

// Gắn carousel banner vào host (ô giữa header #header-promo).
// Bấm vào ảnh đang hiện → mở link đích của ĐÚNG ảnh đó + đếm click.
export async function mountPromoBanner(host) {
  if (disposePrev) { try { disposePrev(); } catch { /* ignore */ } disposePrev = null; }
  if (!host) return;
  clear(host);

  let promos = [];
  try {
    const res = await window.vt.promos.activeList({ type: 'banner', audience: 'all', limit: MAX_SLIDES });
    const list = res && res.ok ? res.data : null;
    promos = Array.isArray(list) ? list.filter((p) => p && p.image) : [];
  } catch { promos = []; }
  if (!promos.length) return; // không có banner nào bật → host rỗng

  const viewport = el('div.promo-banner');
  const track = el('div.promo-track');
  viewport.appendChild(track);

  // Mỗi promo = 1 slide rộng đúng bằng viewport ⇒ trượt = dịch track đi i×100%.
  const slides = promos.map((promo) => {
    const img = el('img.promo-banner-img', {
      src: promo.image,
      alt: promo.title || 'Quảng cáo',
      onerror: () => dropSlide(promo.id), // ảnh hỏng → bỏ riêng ảnh đó, giữ các ảnh còn lại
    });
    const slide = el('div.promo-slide', {}, [img]);
    if (promo.target) {
      slide.classList.add('promo-banner-clickable');
      slide.addEventListener('click', () => {
        try { window.vt.promos.click(promo.id); } catch { /* ignore */ }
        try { window.vt.shell.openExternal(promo.target); } catch { /* ignore */ }
      });
    }
    track.appendChild(slide);
    return { promo, slide };
  });

  host.appendChild(viewport);

  let items = slides;
  let index = 0;
  let timer = null;

  // Đếm lượt xem 1 LẦN cho mỗi banner trong 1 phiên mount. Nếu đếm mỗi vòng quay thì
  // để app mở cả ngày sẽ ra hàng nghìn view ảo, thống kê bên admin mất ý nghĩa.
  const counted = new Set();
  const countView = (id) => {
    if (!id || counted.has(id)) return;
    counted.add(id);
    try { window.vt.promos.view(id); } catch { /* ignore */ }
  };

  function render() {
    track.style.transform = `translateX(-${index * 100}%)`;
    const cur = items[index];
    if (cur) countView(cur.promo.id);
  }

  function next() {
    if (items.length < 2) return;
    index = (index + 1) % items.length;
    render();
  }

  // Ảnh lỗi (404, link admin nhập sai…) → gỡ khỏi vòng quay. Hết sạch ảnh → xoá banner.
  function dropSlide(id) {
    const at = items.findIndex((s) => s.promo.id === id);
    if (at < 0) return;
    items[at].slide.remove();
    items = items.filter((_, i) => i !== at);
    if (!items.length) { stop(); clear(host); return; }
    if (index >= items.length) index = 0;
    else if (at < index) index -= 1;
    if (items.length < 2) stop(); // còn 1 ảnh → thành ảnh tĩnh
    render();
  }

  function start() {
    if (timer || items.length < 2) return;
    timer = setInterval(next, SLIDE_MS);
  }
  function stop() {
    if (timer) { clearInterval(timer); timer = null; }
  }

  // Rê chuột lên banner → dừng để người dùng kịp đọc / kịp bấm đúng ảnh đang xem.
  viewport.addEventListener('mouseenter', stop);
  viewport.addEventListener('mouseleave', start);

  // Cửa sổ bị ẩn / thu nhỏ → dừng hẳn, hiện lại thì chạy tiếp.
  const onVisibility = () => { if (document.hidden) stop(); else start(); };
  document.addEventListener('visibilitychange', onVisibility);

  render();
  start();

  disposePrev = () => {
    stop();
    document.removeEventListener('visibilitychange', onVisibility);
  };
}
