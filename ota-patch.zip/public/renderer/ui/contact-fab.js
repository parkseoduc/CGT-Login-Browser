// BONG BÓNG LIÊN HỆ (góc dưới bên phải) - bản trong app của khối .contact-fab ở web
// landing (`web landing anti-browser/public/index.html`, CSS ở styles.css §"Bong bóng
// liên hệ"). Dùng ở màn ĐĂNG NHẬP/ĐĂNG KÝ: đây là lúc khách chưa vào được app nên cần
// đường liên hệ hỗ trợ rõ ràng nhất.
//
// KHÁC web landing ở hai điểm, đều cố ý:
//  1. KHÔNG dùng <a target="_blank">. Trong Electron, thẻ neo mở cửa sổ BrowserWindow
//     trần (không có chrome, không tắt được) - link ngoài phải đẩy sang trình duyệt hệ
//     thống qua vt.shell.openExternal.
//  2. Nhãn khi rê chuột dùng THUỘC TÍNH `title`, để bộ tooltip dùng chung của app
//     (installTooltips trong ui.js) vẽ - thay vì ::after{content:attr(data-tip)} như
//     landing. Nếu tự vẽ ::after thì sẽ ra HAI tooltip, vì bộ tooltip của app tự chuyển
//     `title` → `data-tip` ngay lần rê chuột đầu.
import { el } from '../ui.js';

// Kênh liên hệ. Link LẤY TỪ web admin (bảng contact_links) qua window.vt.contacts.list()
// để "đổi ở admin là app nhận ngay" - KHÔNG phải sửa code. Các url dưới đây chỉ là
// FALLBACK khi chưa fetch xong / lỗi mạng / admin chưa nhập, để nút không bao giờ chết.
//   • src/main/app-menu.js  → menu Trợ giúp (cũng tự fetch từ admin)
//   • web landing anti-browser/public/*.html → khối .contact-fab (fetch qua contacts-sync.js)
const CONTACTS = [
  { key: 'zalo', label: 'Zalo CGT Media', url: 'https://cgtdev.space' },
  { key: 'telegram', label: 'Telegram CGT Support', url: 'https://t.me/cgtmediagroup' },
  { key: 'messenger', label: 'Hỗ trợ CGT Media', url: 'https://cgtdev.space' },
];

// SVG lấy nguyên từ web landing để hai bên giống hệt nhau.
const ICONS = {
  zalo: `<svg viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <path fill-rule="evenodd" clip-rule="evenodd" d="M22.782 0.166016H27.199C33.2653 0.166016 36.8103 1.05701 39.9572 2.74421C43.1041 4.4314 45.5875 6.89585 47.2557 10.0428C48.9429 13.1897 49.8339 16.7347 49.8339 22.801V27.1991C49.8339 33.2654 48.9429 36.8104 47.2557 39.9573C45.5685 43.1042 43.1041 45.5877 39.9572 47.2559C36.8103 48.9431 33.2653 49.8341 27.199 49.8341H22.8009C16.7346 49.8341 13.1896 48.9431 10.0427 47.2559C6.89583 45.5687 4.41243 43.1042 2.7442 39.9573C1.057 36.8104 0.166016 33.2654 0.166016 27.1991V22.801C0.166016 16.7347 1.057 13.1897 2.7442 10.0428C4.43139 6.89585 6.89583 4.41245 10.0427 2.74421C13.1707 1.05701 16.7346 0.166016 22.782 0.166016Z" fill="#0068FF"/>
    <path opacity="0.12" fill-rule="evenodd" clip-rule="evenodd" d="M49.8336 26.4736V27.1994C49.8336 33.2657 48.9427 36.8107 47.2555 39.9576C45.5683 43.1045 43.1038 45.5879 39.9569 47.2562C36.81 48.9434 33.265 49.8344 27.1987 49.8344H22.8007C17.8369 49.8344 14.5612 49.2378 11.8104 48.0966L7.27539 43.4267L49.8336 26.4736Z" fill="#001A33"/>
    <path fill-rule="evenodd" clip-rule="evenodd" d="M7.779 43.5892C10.1019 43.846 13.0061 43.1836 15.0682 42.1825C24.0225 47.1318 38.0197 46.8954 46.4923 41.4732C46.8209 40.9803 47.1279 40.4677 47.4128 39.9363C49.1062 36.7779 50.0004 33.22 50.0004 27.1316V22.7175C50.0004 16.629 49.1062 13.0711 47.4128 9.91273C45.7385 6.75436 43.2461 4.28093 40.0877 2.58758C36.9293 0.894239 33.3714 0 27.283 0H22.8499C17.6644 0 14.2982 0.652754 11.4699 1.89893C11.3153 2.03737 11.1636 2.17818 11.0151 2.32135C2.71734 10.3203 2.08658 27.6593 9.12279 37.0782C9.13064 37.0921 9.13933 37.1061 9.14889 37.1203C10.2334 38.7185 9.18694 41.5154 7.55068 43.1516C7.28431 43.399 7.37944 43.5512 7.779 43.5892Z" fill="white"/>
    <path d="M20.5632 17H10.8382V19.0853H17.5869L10.9329 27.3317C10.7244 27.635 10.5728 27.9194 10.5728 28.5639V29.0947H19.748C20.203 29.0947 20.5822 28.7156 20.5822 28.2606V27.1421H13.4922L19.748 19.2938C19.8428 19.1801 20.0134 18.9716 20.0893 18.8768L20.1272 18.8199C20.4874 18.2891 20.5632 17.8341 20.5632 17.2844V17Z" fill="#0068FF"/>
    <path d="M32.9416 29.0947H34.3255V17H32.2402V28.3933C32.2402 28.7725 32.5435 29.0947 32.9416 29.0947Z" fill="#0068FF"/>
    <path d="M25.814 19.6924C23.1979 19.6924 21.0747 21.8156 21.0747 24.4317C21.0747 27.0478 23.1979 29.171 25.814 29.171C28.4301 29.171 30.5533 27.0478 30.5533 24.4317C30.5723 21.8156 28.4491 19.6924 25.814 19.6924ZM25.814 27.2184C24.2785 27.2184 23.0273 25.9672 23.0273 24.4317C23.0273 22.8962 24.2785 21.645 25.814 21.645C27.3495 21.645 28.6007 22.8962 28.6007 24.4317C28.6007 25.9672 27.3685 27.2184 25.814 27.2184Z" fill="#0068FF"/>
    <path d="M40.4867 19.6162C37.8516 19.6162 35.7095 21.7584 35.7095 24.3934C35.7095 27.0285 37.8516 29.1707 40.4867 29.1707C43.1217 29.1707 45.2639 27.0285 45.2639 24.3934C45.2639 21.7584 43.1217 19.6162 40.4867 19.6162ZM40.4867 27.2181C38.9322 27.2181 37.681 25.9669 37.681 24.4124C37.681 22.8579 38.9322 21.6067 40.4867 21.6067C42.0412 21.6067 43.2924 22.8579 43.2924 24.4124C43.2924 25.9669 42.0412 27.2181 40.4867 27.2181Z" fill="#0068FF"/>
    <path d="M29.4562 29.0944H30.5747V19.957H28.6221V28.2793C28.6221 28.7153 29.0012 29.0944 29.4562 29.0944Z" fill="#0068FF"/>
  </svg>`,
  telegram: `<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M9.78 18.65l.28-4.23 7.68-6.92c.34-.31-.07-.46-.52-.19L7.74 13.3 3.64 12c-.88-.25-.89-.86.2-1.3l15.97-6.16c.73-.33 1.43.18 1.15 1.3l-2.72 12.81c-.19.91-.74 1.13-1.5.71l-4.14-3.05-1.99 1.93c-.23.23-.42.42-.83.42z"/></svg>`,
  messenger: `<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2C6.36 2 2 6.13 2 11.7c0 2.91 1.19 5.44 3.14 7.17.16.14.26.35.27.57l.05 1.78c.02.57.6.94 1.12.71l1.98-.87c.17-.08.36-.09.54-.04.91.25 1.88.38 2.9.38 5.64 0 10-4.13 10-9.7C22 6.13 17.64 2 12 2zm6.02 7.46l-2.93 4.65c-.47.74-1.47.93-2.18.4l-2.33-1.75a.6.6 0 0 0-.72 0l-3.15 2.39c-.42.32-.97-.18-.68-.62l2.93-4.65c.47-.74 1.47-.93 2.18-.4l2.33 1.75c.21.16.51.16.72 0l3.15-2.39c.42-.32.97.18.68.62z"/></svg>`,
};

// Trả về khối bong bóng (position:fixed) để nơi gọi tự gắn vào cây DOM của mình.
//
// KHÔNG đặt aria-label tiếng Việt ("Liên hệ") lên khối bọc như bên web landing: bộ dịch
// của app chỉ đụng tới `title` / `placeholder` / `data-tip`, nên aria-label sẽ nằm chết
// bằng tiếng Việt trong giao diện EN/RU/ZH (test/_diag-i18n-coverage.js bắt đúng chỗ này).
// Mỗi nút đã tự mang tên riêng (Zalo/Telegram/Messenger) - vốn không dịch ở mọi ngôn ngữ
// - nên trình đọc màn hình vẫn đọc đủ nghĩa mà không cần nhãn nhóm.
// Chỉ trả về MẢNG nút liên hệ (không kèm khối bọc .contact-fab). Tách ra để dùng lại ở
// bong bóng info trong app (ui/info-bubble.js) mà không kéo theo position:fixed của .contact-fab.
export function contactButtons() {
  return CONTACTS.map((c) => {
    // url động: onclick đọc `ref.url` tại thời điểm bấm, nên khi fetch xong ta chỉ cần
    // cập nhật ref là nút mở link mới (không cần dựng lại DOM).
    const ref = { url: c.url };
    const btn = el(`button.cfab.cfab-${c.key}`, {
      type: 'button',
      title: c.label,          // tooltip dùng chung của app vẽ nhãn này
      'aria-label': c.label,
      html: ICONS[c.key] || '',
      onclick: () => { try { window.vt.shell.openExternal(ref.url); } catch { /* ignore */ } },
    });
    btn._contactRef = ref; // để syncContacts() tìm & cập nhật
    return btn;
  });
}

// Fetch liên hệ từ web admin rồi ghi đè url cho các nút .cfab đang có trên trang.
// Best-effort: lỗi/không có dữ liệu thì giữ nguyên link fallback. Gọi sau khi render.
export async function syncContacts(root = document) {
  let data;
  try {
    const res = await window.vt.contacts.list();
    data = res && res.ok ? res.data : null;
  } catch { data = null; }
  if (!data) return;

  for (const c of CONTACTS) {
    const list = data[c.key];
    const url = Array.isArray(list) && list.length && list[0] && list[0].value
      ? String(list[0].value).trim()
      : '';
    if (!url) continue; // admin chưa nhập nhóm này → giữ fallback
    root.querySelectorAll(`.cfab-${c.key}`).forEach((btn) => {
      if (btn._contactRef) btn._contactRef.url = url;
    });
  }
}

export function contactFab() {
  const node = el('div.contact-fab', { role: 'group' }, contactButtons());
  // Sau khi mount (tick kế), fetch link từ web admin ghi đè fallback.
  setTimeout(() => { syncContacts(node); }, 0);
  return node;
}
