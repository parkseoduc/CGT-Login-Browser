// Luồng cập nhật ứng dụng phía renderer:
//   - checkForUpdates(): gọi main (vt.updates.check), lưu trạng thái, cập nhật badge,
//     và bật modal khi có bản mới (force = chặn, không "Để sau"; thường = có "Để sau").
//   - openUpdateModal(): mở modal cho bản mới hiện có (dùng cho nút ở header/Cài đặt).
//   - subscribe(): cho header/Cài đặt lắng nghe để bật/tắt badge "có cập nhật".
//
// An toàn: mọi hành động (tải/verify/cài) chạy ở main; renderer chỉ ra lệnh + hiển thị.
// Lỗi bất kỳ bước nào → thông báo rõ + nút "Thử lại", KHÔNG phá bản đang chạy.
import { el, iconBtn, toast, clear } from '../ui.js';
import { icon } from '../icons.js';
import { tf } from '../i18n.js';

// Trạng thái dùng chung (header dropdown + Cài đặt đọc qua getInfo()).
const stateUpd = {
  info: null,        // payload check gần nhất: { current, latest, hasUpdate, force, url, sha256, size, notes }
  checking: false,
  downloading: false,
};

const listeners = new Set();
export function subscribe(cb) { listeners.add(cb); return () => listeners.delete(cb); }
function emit() { for (const cb of listeners) { try { cb(stateUpd); } catch { /* ignore */ } } }

export function getInfo() { return stateUpd.info; }
export function isChecking() { return stateUpd.checking; }
// "Có cập nhật đang chờ" để hiện badge: có bản mới VÀ chưa hoãn đúng bản đó.
export function hasPendingUpdate() {
  const i = stateUpd.info;
  return !!(i && i.hasUpdate);
}

// ── Kiểm tra cập nhật ────────────────────────────────────────────────────────
// opts.silent=true (khởi động/định kỳ): không toast khi không có bản mới / lỗi mạng.
// opts.silent=false (bấm tay ở Cài đặt): toast kết quả để người dùng biết đã chạy.
export async function checkForUpdates(opts = {}) {
  const silent = opts.silent !== false ? true : false;
  // noModal=true: chỉ làm mới trạng thái (badge/dropdown), TUYỆT ĐỐI không tự bật modal.
  // Dùng khi người dùng bấm icon cập nhật - modal chỉ hiện lúc mở app.
  const noModal = opts.noModal === true;
  if (stateUpd.checking) return stateUpd.info;
  stateUpd.checking = true;
  emit();
  let res;
  try {
    res = await window.vt.updates.check();
  } catch (e) {
    stateUpd.checking = false;
    emit();
    if (!silent) toast('Không kiểm tra được cập nhật', 'error');
    return null;
  }
  stateUpd.checking = false;
  if (!res || !res.ok) {
    emit();
    if (!silent) toast((res && res.error) || 'Không kiểm tra được cập nhật', 'error');
    return null;
  }
  stateUpd.info = res.data || null;
  emit();

  const info = stateUpd.info;
  if (!info || !info.hasUpdate) {
    if (!silent) toast('Bạn đang dùng bản mới nhất', 'ok');
    return info;
  }

  // Chỉ làm mới trạng thái (badge/dropdown), không tự bật modal.
  if (noModal) return info;

  // Có bản mới → LUÔN hiện modal MỖI LẦN mở app (không còn chặn theo "Để sau"):
  // force → modal chặn (không "Để sau"); thường → modal có "Để sau" (đóng cho phiên
  // này, lần mở app sau vẫn nhắc lại).
  openUpdateModal(!!info.force);
  return info;
}

// ── Modal 1: THÔNG BÁO có bản mới ────────────────────────────────────────────
// Chỉ giới thiệu bản mới + mô tả. force=true: chặn (không đóng bằng scrim/X, không
// "Để sau"). force=false: có "Để sau". Bấm "Cập nhật ngay" → RỜI modal này và mở
// MODAL TẢI RIÊNG (openDownloadModal) - tiến độ/kết quả không còn nằm chung ở đây.
export function openUpdateModal(force) {
  const info = stateUpd.info;
  if (!info || !info.hasUpdate) return;
  const host = document.getElementById('modal-host');
  if (!host) return;
  clear(host);

  const scrim = el('div.scrim');
  if (!force) scrim.addEventListener('click', close);
  const modal = el('div.modal.upd-modal', { style: { width: '600px' } });

  const head = el('div.modal-head', {}, [
    el('div', {}, [
      el('h3', { text: force ? 'Bắt buộc cập nhật' : 'Phiên bản mới đã sẵn sàng' }),
    ]),
  ]);
  if (!force) head.appendChild(iconBtn('close', { class: 'icon-btn x', onclick: close }));

  const body = el('div.modal-body.upd-modal-body');
  // Tiêu đề lớn (đậm) + đoạn mô tả khuyến nghị (xám) - theo thiết kế.
  body.appendChild(el('div.upd-modal-title', { text: tf('Phiên bản {0} đã sẵn sàng!', info.latest) }));
  body.appendChild(el('div.upd-notes', {
    text: force
      ? 'Phiên bản bạn đang dùng không còn được hỗ trợ. Vui lòng cập nhật để tiếp tục sử dụng.'
      : 'Chúng tôi khuyến nghị cập nhật lên phiên bản mới nhất để có trải nghiệm tốt nhất và các tính năng mới nhất.',
  }));

  const foot = el('div.modal-foot.upd-modal-foot');
  const primary = el('button.btn.primary', { text: 'Cập nhật ngay' });
  const later = force ? null : el('button.btn', { text: 'Để sau' });

  function close() {
    host.classList.remove('open', 'upd-open');
    clear(host);
  }
  async function doDeferLater() {
    try { await window.vt.updates.setDeferred(info.latest); } catch { /* ignore */ }
    close();
  }

  // Bấm "Cập nhật ngay": chuyển sang modal tải riêng (thay nội dung trong host).
  primary.addEventListener('click', () => openDownloadModal(force));
  if (later) later.addEventListener('click', doDeferLater);

  foot.appendChild(primary);
  if (later) foot.appendChild(later);

  modal.appendChild(head);
  modal.appendChild(body);
  modal.appendChild(foot);
  host.appendChild(scrim);
  host.appendChild(modal);
  // upd-open → căn GIỮA màn hình (mặc định modal neo trên); thêm cùng 'open'.
  host.classList.add('open', 'upd-open');
}

// ── Modal 2: TẢI + CÀI bản cập nhật (RIÊNG, tách khỏi modal thông báo) ────────
// Mở khi bấm "Cập nhật ngay". Tự bắt đầu tải ngay khi mở. Trong lúc tải KHÔNG cho
// đóng (không scrim-click, không nút Đóng). Lỗi → hiện lỗi + "Thử lại" (và "Đóng"
// nếu không phải bắt buộc). Thành công → main tự thoát app để trình cài tiếp quản.
export function openDownloadModal(force) {
  const info = stateUpd.info;
  if (!info || !info.hasUpdate) return;
  const host = document.getElementById('modal-host');
  if (!host) return;
  clear(host);

  const scrim = el('div.scrim'); // không gắn click-đóng: chỉ đóng qua nút khi có lỗi
  const modal = el('div.modal.upd-modal.upd-dl-modal', { style: { width: '600px' } });

  const head = el('div.modal-head', {}, [
    el('div', {}, [el('h3', { text: 'Đang cập nhật' })]),
  ]);

  const body = el('div.modal-body.upd-modal-body');
  body.appendChild(el('div.upd-modal-title', { text: tf('Phiên bản {0}', info.latest) }));
  const status = el('div.upd-notes', { text: 'Đang chuẩn bị tải…' });
  body.appendChild(status);
  const progWrap = el('div.upd-progress', {}, [
    el('div.upd-progress-bar', {}, [el('div.upd-progress-fill#upd-fill')]),
    el('div.upd-progress-text#upd-ptext', { text: '0%' }),
  ]);
  body.appendChild(progWrap);

  const foot = el('div.modal-foot.upd-modal-foot');
  const primary = el('button.btn.primary', { text: 'Đang tải…' });
  primary.disabled = true;
  const closeBtn = force ? null : el('button.btn', { text: 'Đóng' });
  if (closeBtn) closeBtn.disabled = true;

  let offProgress = null;
  function cleanup() {
    if (offProgress) { try { offProgress(); } catch { /* ignore */ } offProgress = null; }
  }
  function close() {
    if (stateUpd.downloading) return; // đang tải → không cho đóng nửa chừng
    cleanup();
    host.classList.remove('open', 'upd-open');
    clear(host);
  }
  if (closeBtn) closeBtn.addEventListener('click', close);

  function showError(msg) {
    progWrap.style.display = 'none';
    status.classList.add('upd-error');
    status.textContent = msg;
    primary.disabled = false;
    primary.textContent = 'Thử lại';
    if (closeBtn) closeBtn.disabled = false;
    toast(msg, 'error');
  }

  async function startDownload() {
    stateUpd.downloading = true;
    emit();
    primary.disabled = true;
    primary.textContent = 'Đang tải…';
    if (closeBtn) closeBtn.disabled = true;
    status.classList.remove('upd-error');
    status.textContent = 'Đang tải bản cập nhật…';
    progWrap.style.display = '';
    const fill = document.getElementById('upd-fill');
    const ptext = document.getElementById('upd-ptext');
    if (fill) fill.style.width = '0%';
    if (ptext) ptext.textContent = '0%';

    offProgress = window.vt.updates.onProgress((p) => {
      const pct = Math.max(0, Math.min(100, p.percent || 0));
      if (fill) fill.style.width = pct + '%';
      if (ptext) {
        const mb = p.total ? ` · ${(p.received / 1048576).toFixed(1)}/${(p.total / 1048576).toFixed(1)} MB` : '';
        ptext.textContent = pct + '%' + mb;
      }
    });

    let dl;
    try {
      dl = await window.vt.updates.download(info);
    } catch (e) {
      dl = { ok: false, error: e && e.message };
    }
    cleanup();
    stateUpd.downloading = false;
    emit();

    if (!dl || !dl.ok) {
      // Lỗi tải/verify → giữ bản cũ, cho "Thử lại".
      showError((dl && dl.error) || 'Tải bản cập nhật thất bại');
      return;
    }

    // Tải + verify xong → chạy cài đặt (app sẽ thoát để trình cài tiếp quản).
    primary.textContent = 'Đang mở trình cài đặt…';
    status.textContent = 'Hoàn tất tải · đang cài đặt';
    const ptext2 = document.getElementById('upd-ptext');
    if (ptext2) ptext2.textContent = '100%';
    let ins;
    try {
      ins = await window.vt.updates.install(dl.data ? dl.data.path : dl.path);
    } catch (e) {
      ins = { ok: false, error: e && e.message };
    }
    if (!ins || !ins.ok) {
      showError((ins && ins.error) || 'Không mở được trình cài đặt');
    }
    // Thành công: main gọi app.quit() sau vài trăm ms; không cần làm gì thêm.
  }

  // Nút primary chỉ có tác dụng "Thử lại" sau khi lỗi (lúc đang tải nó bị disable).
  primary.addEventListener('click', () => {
    if (stateUpd.downloading) return;
    startDownload();
  });

  foot.appendChild(primary);
  if (closeBtn) foot.appendChild(closeBtn);

  modal.appendChild(head);
  modal.appendChild(body);
  modal.appendChild(foot);
  host.appendChild(scrim);
  host.appendChild(modal);
  host.classList.add('open', 'upd-open');

  // Tự bắt đầu tải ngay khi modal mở.
  startDownload();
}

// Vẽ trạng thái vào dropdown "Cập nhật phiên bản" ở header (khung .upd-body có sẵn).
export function renderDropdownBody(body) {
  clear(body);
  const info = stateUpd.info;
  if (info && info.hasUpdate) {
    body.appendChild(el('div.upd-avail', {}, [
      el('div.upd-avail-head', {}, [
        el('span.upd-avail-title', { text: tf('Phiên bản {0} đã sẵn sàng', info.latest) }),
        info.size ? el('span.upd-avail-size', { text: `${info.size} MB` }) : null,
      ]),
      info.notes ? el('div.upd-avail-notes', { text: info.notes }) : null,
      el('button.btn.primary.upd-avail-btn', {
        text: 'Cập nhật ngay',
        onclick: () => openDownloadModal(!!info.force),
      }),
    ]));
    return;
  }
  // Không có cập nhật → trạng thái rỗng kèm vector minh hoạ.
  body.appendChild(el('div.upd-empty', {}, [
    el('div.upd-empty-ic', { html: icon('updateEmpty') }),
    el('div.upd-empty-title', { text: stateUpd.checking ? 'Đang kiểm tra…' : 'Không có cập nhật mới' }),
  ]));
}
