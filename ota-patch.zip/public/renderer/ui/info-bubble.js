// BONG BÓNG INFO TRONG APP - phiên bản dùng SAU khi đăng nhập (mọi view), khác với
// contactFab() (chỉ ở màn đăng nhập/đăng ký, ghim cứng góc dưới phải).
//
// Hai trạng thái:
//  1. MỞ (panel): một CỘT bong bóng trong suốt (không khung bọc) gồm 3 nút liên hệ
//     (Zalo/Telegram/Messenger, dùng lại contactButtons()) + một bong bóng "X" ĐỎ
//     (icon trắng) ở dưới cùng để THU GỌN. Chỉ bấm bong bóng "X" mới thu gọn.
//  2. THU GỌN (robot): một bong bóng tròn mang icon robot, nền gradient brand (đúng
//     gradient của nút chính .btn.primary), KHÔNG hiệu ứng lan tỏa/nhấp nháy - nó là
//     nút phụ, không nên hút mắt liên tục ở góc màn hình. Bấm robot -> mở lại panel.
//
// KÉO THẢ: kéo được cả hai trạng thái tới BẤT KỲ đâu trong app. Bấm-giữ bất kỳ chỗ nào
// trên cột bong bóng (hoặc trên robot) rồi rê để kéo cả khối. Phân biệt "kéo" và "bấm"
// bằng ngưỡng ~4px: dưới ngưỡng coi là bấm (nút con nổ như thường: mở link / thu gọn /
// mở panel), trên ngưỡng là kéo (di chuyển khối và NUỐT cú click kèm theo).
//
// LƯU VỊ TRÍ + TRẠNG THÁI vào localStorage để giữ nguyên chỗ user đã kéo và mở/gọn qua
// các lần điều hướng / mở lại app. Vị trí luôn được ghim lại trong khung nhìn khi khôi
// phục và khi cửa sổ đổi kích thước (tránh lọt ra ngoài màn hình).
import { el } from '../ui.js';
import { contactButtons, syncContacts } from './contact-fab.js';

const POS_KEY = 'appInfoBubblePos';       // { left, top } px
const STATE_KEY = 'appInfoBubbleCollapsed'; // '1' = thu gọn
const MARGIN = 8;                           // lề tối thiểu với mép cửa sổ
const DRAG_THRESHOLD = 4;                   // px: quá ngưỡng này coi là kéo, không phải bấm

// (Không còn thanh tiêu đề/khung bọc: panel chỉ là một CỘT bong bóng trong suốt gồm
//  3 nút liên hệ + 1 bong bóng "X" đỏ ở dưới cùng để thu gọn.)
//
// Icon robot cho bong bóng thu gọn (tô đặc theo currentColor).
const ROBOT_SVG = `<svg viewBox="0 0 24 24" aria-hidden="true">
  <path d="M0 0h24v24H0z" fill="none"/>
  <path fill="currentColor" d="M12 2C6.486 2 2 6.486 2 12v4.143C2 17.167 2.897 18 4 18h1a1 1 0 0 0 1-1v-5.143a1 1 0 0 0-1-1h-.908C4.648 6.987 7.978 4 12 4s7.352 2.987 7.908 6.857H19a1 1 0 0 0-1 1V18c0 1.103-.897 2-2 2h-2v-1h-4v3h6c2.206 0 4-1.794 4-4c1.103 0 2-.833 2-1.857V12c0-5.514-4.486-10-10-10"/>
</svg>`;

const X_SVG = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>`;

// Ghim theo cạnh DƯỚI (bottom) thay vì trên (top): nhờ vậy khi bấm mở, cột bong bóng cao
// lên sẽ MỌC NGƯỢC LÊN TRÊN (dropup) vì mép dưới đứng yên ở chỗ robot.
function clampToViewport(root, left, bottom) {
  const w = root.offsetWidth || 60;
  const h = root.offsetHeight || 60;
  const maxL = Math.max(MARGIN, window.innerWidth - w - MARGIN);
  const maxB = Math.max(MARGIN, window.innerHeight - h - MARGIN);
  return {
    left: Math.min(Math.max(MARGIN, left), maxL),
    bottom: Math.min(Math.max(MARGIN, bottom), maxB),
  };
}

// Đặt vị trí theo left + bottom (huỷ right/top mặc định).
function applyPos(root, left, bottom) {
  root.style.left = `${left}px`;
  root.style.bottom = `${bottom}px`;
  root.style.right = 'auto';
  root.style.top = 'auto';
}

// Đọc bottom hiện tại của root (khoảng cách từ mép dưới cửa sổ tới đáy khối).
function bottomOf(root) {
  return window.innerHeight - root.getBoundingClientRect().bottom;
}

// Vị trí lưu vào sessionStorage (KHÔNG localStorage): giữ chỗ user đã kéo qua các lần
// điều hướng trong CÙNG một phiên, nhưng RESET khi mở lại app -> mỗi lần mở app bong bóng
// mặc định nằm góc dưới phải (theo CSS .app-bubble: right/bottom).
function savePos(left, bottom) {
  try { sessionStorage.setItem(POS_KEY, JSON.stringify({ left, bottom })); } catch { /* ignore */ }
}

function loadPos() {
  try {
    const raw = sessionStorage.getItem(POS_KEY);
    if (!raw) return null;
    const p = JSON.parse(raw);
    if (p && Number.isFinite(p.left) && Number.isFinite(p.bottom)) return p;
  } catch { /* ignore */ }
  return null;
}

// Nuốt ĐÚNG MỘT cú "click" kế tiếp trên `root` (pha capture) - dùng sau khi vừa kéo, để
// cú click do trình duyệt phát ra lúc thả KHÔNG kích hoạt nút con (mở link / thu gọn).
function suppressNextClick(root) {
  const h = (e) => { e.stopPropagation(); e.preventDefault(); };
  root.addEventListener('click', h, true);
  setTimeout(() => root.removeEventListener('click', h, true), 0);
}

// Kéo-thả CẢ KHỐI `root` bằng cách bấm-giữ trên `handle`. Không bắt pointer capture và
// không preventDefault ở pointerdown, nên cú CLICK gốc của các nút con (liên hệ / "X")
// vẫn nổ bình thường khi chỉ bấm (không kéo). Chỉ khi di quá ngưỡng mới coi là kéo: di
// chuyển khối, lưu vị trí, và nuốt cú click kèm theo để nút con không bị kích nhầm.
function attachDrag(root, handle, onDragStart) {
  let startX = 0;
  let startY = 0;
  let origL = 0;
  let origB = 0;
  let active = false;
  let dragging = false;

  const onMove = (e) => {
    if (!active) return;
    const dx = e.clientX - startX;
    const dy = e.clientY - startY;
    if (!dragging && (Math.abs(dx) > DRAG_THRESHOLD || Math.abs(dy) > DRAG_THRESHOLD)) {
      dragging = true;
      root.classList.add('is-dragging');
      // Chỉ CHUYỂN sang định vị left/bottom khi THỰC SỰ kéo (không phải chỉ bấm). Nhờ vậy
      // khi chưa kéo, bong bóng vẫn ghim góc phải-dưới bằng CSS (right/bottom) và tự bám
      // góc khi thu nhỏ/phóng to cửa sổ.
      applyPos(root, origL, origB);
      if (typeof onDragStart === 'function') onDragStart();
    }
    if (dragging) {
      // Kéo xuống (dy>0) -> bottom giảm; kéo lên -> bottom tăng.
      const { left, bottom } = clampToViewport(root, origL + dx, origB - dy);
      applyPos(root, left, bottom);
      e.preventDefault(); // chặn bôi đen văn bản khi kéo
    }
  };

  const onUp = () => {
    if (!active) return;
    active = false;
    window.removeEventListener('pointermove', onMove);
    window.removeEventListener('pointerup', onUp);
    window.removeEventListener('pointercancel', onUp);
    if (dragging) {
      dragging = false;
      root.classList.remove('is-dragging');
      savePos(root.getBoundingClientRect().left, bottomOf(root));
      suppressNextClick(root); // đừng để cú click sau khi thả kích nút con
    }
  };

  handle.addEventListener('pointerdown', (e) => {
    if (e.button !== 0) return;
    active = true;
    dragging = false;
    startX = e.clientX;
    startY = e.clientY;
    const r = root.getBoundingClientRect();
    origL = r.left;
    origB = window.innerHeight - r.bottom;
    // KHÔNG đổi anchoring ở pointerdown: chỉ bấm (không kéo) thì giữ nguyên ghim góc phải.
    // Việc chuyển sang left/bottom để onMove xử lý khi vượt ngưỡng kéo.
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
    window.addEventListener('pointercancel', onUp);
  });
}

// Dựng và trả về khối bong bóng info (position:fixed). Nơi gọi tự gắn vào #app.
export function inAppInfoBubble() {
  const collapsedStart = (() => {
    try {
      const raw = localStorage.getItem(STATE_KEY);
      return raw == null ? true : raw === '1';
    } catch { return true; }
  })();

  // Bong bóng "X" đỏ (icon trắng) - nằm DƯỚI nút "Messenger" trong cột. Bấm để thu gọn.
  const closeBtn = el('button.abub-close', {
    type: 'button',
    title: 'Thu gọn',
    'aria-label': 'Thu gọn',
    html: X_SVG,
  });
  // Panel = cột bong bóng trong suốt (không khung bọc): 3 nút liên hệ + "X" ở dưới cùng.
  const panel = el('div.abub-panel', { role: 'group' }, [
    ...contactButtons(),
    closeBtn,
  ]);

  const robot = el('button.abub-robot', {
    type: 'button',
    title: 'Liên hệ hỗ trợ',
    'aria-label': 'Mở liên hệ hỗ trợ',
    html: ROBOT_SVG,
  });

  // data-tip-place="top": mọi tooltip của bong bóng (liên hệ / X / robot) luôn hiện BÊN TRÊN.
  const root = el('div.app-bubble', { 'data-tip-place': 'top' }, [panel, robot]);

  // Sau khi mount, fetch link liên hệ từ web admin ghi đè fallback (best-effort).
  setTimeout(() => { syncContacts(root); }, 0);

  // Người dùng đã TỰ KÉO bong bóng đi chỗ khác chưa? Nếu CHƯA, giữ ghim góc phải-dưới bằng
  // CSS và KHÔNG can thiệp khi đổi cỡ cửa sổ (để nó tự bám góc lúc thu nhỏ/phóng to). Chỉ khi
  // đã kéo (hoặc khôi phục vị trí đã lưu trong phiên) mới ghim-lại-trong-khung-nhìn khi resize.
  let moved = false;

  function setCollapsed(v) {
    root.classList.toggle('is-collapsed', v);
    try { localStorage.setItem(STATE_KEY, v ? '1' : '0'); } catch { /* ignore */ }
  }
  setCollapsed(collapsedStart);

  // CHỈ bong bóng "X" mới thu gọn (các nút liên hệ vẫn mở link như thường).
  closeBtn.addEventListener('click', () => setCollapsed(true));
  // Robot: bấm (không kéo) -> mở panel. Kéo -> di chuyển.
  robot.addEventListener('click', () => setCollapsed(false));
  const markMoved = () => { moved = true; };
  attachDrag(root, robot, markMoved);
  // Panel kéo tự do bằng cách bấm-giữ bất kỳ chỗ nào trên cột bong bóng; chỉ bấm (không
  // kéo) thì cú click gốc của nút con vẫn nổ (mở link / thu gọn).
  attachDrag(root, panel, markMoved);

  // Khôi phục vị trí đã lưu (ghim trong khung nhìn). Chờ 1 nhịp để offsetWidth có thật.
  requestAnimationFrame(() => {
    const p = loadPos();
    if (p) {
      moved = true; // đã có vị trí tự-kéo trong phiên -> tôn trọng, ghim lại khi resize
      const { left, bottom } = clampToViewport(root, p.left, p.bottom);
      applyPos(root, left, bottom);
    }
  });

  // Cửa sổ đổi cỡ: NẾU người dùng chưa tự kéo, không đụng gì (CSS right/bottom tự bám góc
  // phải-dưới khi thu nhỏ/phóng to). Chỉ khi đã kéo mới ghim lại trong khung nhìn.
  const onResize = () => {
    if (!moved) return;
    const curL = root.getBoundingClientRect().left;
    const curB = bottomOf(root);
    const { left, bottom } = clampToViewport(root, curL, curB);
    if (left !== curL || bottom !== curB) {
      applyPos(root, left, bottom);
      savePos(left, bottom);
    }
  };
  window.addEventListener('resize', onResize);

  return root;
}
