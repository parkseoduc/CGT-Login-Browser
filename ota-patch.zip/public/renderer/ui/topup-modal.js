// Modal nạp tiền dạng VietQR - DÙNG CHUNG cho trang "Nâng cấp gói" và icon "Nạp
// tiền" ở header. Quét QR / chuyển khoản theo cú pháp; SERVER tự đối soát biến động số
// dư (Pay2S) rồi cộng ví. Modal POLL số dư trong lúc mở → tiền vào là hiện "đã nhận" ngay.
//
// Thông tin ngân hàng + ẢNH QR do SERVER dựng (đọc từ .env). Ảnh QR lấy TRỰC TIẾP từ
// dịch vụ chính thức img.vietqr.io (template compact2 - mã QR kèm khung STK/tên/số tiền),
// main fetch về data URL để né CSP. Không tự vẽ bằng lib qrcode. Không hardcode số tài
// khoản ở client (đã hiển thị dạng text bên dưới ảnh).
import { el, openModal, closeModal, toast } from '../ui.js';
import { icon } from '../icons.js';
import { notifyError } from '../data/errors.js';
import { t, tf, fmtDate, punct } from '../i18n.js';

const fmtVnd = (n) => (Number(n) || 0).toLocaleString('vi-VN') + '\u20ab';

// opts.amount > 0 (trang Thủ tục thanh toán / Nạp tiền) ⇒ QR ĐỘNG điền sẵn đúng số tiền (khách khỏi gõ; app ngân hàng
// vẫn cho sửa). Không truyền ⇒ QR TĨNH như cũ. opts.onDone(số dư mới) chạy sau khi tiền vào (trước modal thành công).
export function showTopupModal(opts) {
  opts = opts || {};
  const amount = Math.max(0, Math.round(Number(opts.amount) || 0));

  const copyBtn = (getValue) => el('button.ap-qr-copy', {
    html: icon('copy') || '⧉', title: 'Sao chép',
    onclick: async () => { try { await navigator.clipboard.writeText(String(getValue())); toast('Đã sao chép', 'ok'); } catch { toast('Không sao chép được', 'err'); } },
  });
  // Ô key–value có thể cập nhật giá trị sau khi server trả thông tin.
  const kv = (label, withCopy) => {
    const vEl = el('span.ap-qr-kv-v', { text: '…' });
    const node = el('div.ap-qr-kv', {}, [
      el('span.ap-qr-kv-k', { text: label }),
      vEl,
      withCopy ? copyBtn(() => vEl.textContent) : null,
    ]);
    return { node, set: (t) => { vEl.textContent = t; } };
  };

  const qrImg = el('img.ap-qr-img', { alt: 'Mã QR chuyển khoản' });
  const qrHolder = el('div.ap-qr-holder', {}, [qrImg]);
  const kvAcc = kv('Số tài khoản:', true);
  const kvHolder = kv('Họ tên chủ tài khoản:', false);
  const kvInfo = kv('Nội dung chuyển khoản:', true);
  const bankNameEl = el('div.ap-qr-bankname', { text: '' });
  // Dải KHUYẾN MÃI NẠP - ẩn sẵn, chỉ hiện khi server báo đang có đợt chạy.
  const promoEl = el('div.ap-qr-promo', { style: 'display:none' });
  // Dòng TRẠNG THÁI đối soát: đang chờ ↔ đã nhận tiền.
  const statusEl = el('div.ap-qr-status', {}, [
    el('span.ap-qr-spinner'),
    el('span.ap-qr-status-txt', { text: 'Đang chờ chuyển khoản…' }),
  ]);
  const statusTxt = statusEl.querySelector('.ap-qr-status-txt');

  const body = [
    el('div.ap-qr-banner', {}, [
      el('span.ap-qr-banner-ico', { html: icon('infoCircle') || 'ⓘ' }),
      el('span', { text: 'Hệ thống sẽ tự động nạp tiền trong vòng 30 giây - 1 phút sau khi bạn chuyển khoản thành công. Vui lòng giữ nguyên nội dung chuyển khoản.' }),
    ]),
    promoEl,
    qrHolder,
    el('div.ap-qr-info', {}, [
      kvAcc.node,
      kvHolder.node,
      kvInfo.node,
      bankNameEl,
    ]),
    statusEl,
  ];
  const footer = [el('button.btn', { text: 'Đóng', onclick: closeModal })];
  openModal({ title: 'Quét mã QR hoặc chuyển khoản theo cú pháp', body, footer, width: 960 });

  // ── DẢI KHUYẾN MÃI NẠP ────────────────────────────────────────────────────────
  // Cho khách biết TRƯỚC khi chuyển khoản: đang có đợt +X%, cần nạp tối thiểu bao nhiêu,
  // thưởng có trần không, đợt chạy tới ngày nào. Không có đợt ⇒ dải này không xuất hiện,
  // giao diện y hệt như trước khi có tính năng.
  const renderPromo = (promo) => {
    if (!promo || !(Number(promo.percent) > 0)) { promoEl.style.display = 'none'; return; }
    // DỊCH: các chuỗi này có chèn số/tiền/ngày nên PHẢI dựng qua tf('… {0} …') - nếu ghép
    // sẵn rồi để bộ dịch DOM tra từ điển thì không bao giờ khớp khoá (khoá không chứa số),
    // khách dùng tiếng Anh/Nga/Trung sẽ thấy nguyên câu tiếng Việt. Ngày theo fmtDate()
    // để đúng định dạng của ngôn ngữ đang chọn; dấu liệt kê/dấu chấm theo punct().
    const p = punct();
    const dk = [];
    if (Number(promo.minAmount) > 0) dk.push(tf('nạp từ {0}', fmtVnd(promo.minAmount)));
    if (promo.maxBonus != null) dk.push(tf('thưởng tối đa {0}/lần', fmtVnd(promo.maxBonus)));
    if (promo.endAt) dk.push(tf('đến hết {0}', fmtDate(promo.endAt)));
    promoEl.innerHTML = '';
    promoEl.append(
      el('span.ap-qr-promo-ico', { html: icon('gift') || '🎁' }),
      el('span.ap-qr-promo-txt', {}, [
        el('b', { text: tf('Đang khuyến mãi +{0}% khi nạp tiền', Number(promo.percent)) }),
        el('span.ap-qr-promo-sub', { text: dk.length ? `${p.dash}${dk.join(p.list)}${p.dot}` : '' }),
      ]),
    );
    promoEl.style.display = '';
  };

  // Lấy thông tin chuyển khoản + URL ảnh QR từ server (đọc .env) → hiển thị ảnh + điền ô.
  // Nội dung CK (addInfo) do SERVER dựng theo mã định danh tài khoản → không truyền ref.
  vt.wallet.bank({ amount }).then((info) => {
    // Chưa cấu hình ngân hàng ⇒ ĐÓNG modal (y web: báo lỗi, không để modal trống "…").
    if (!info || !info.bank) { closeModal(); notifyError(new Error('VIETQR_NOT_CONFIGURED'), 'Chưa cấu hình tài khoản nhận tiền'); return; }
    const b = info.bank;
    kvAcc.set(b.accountNo || '');
    kvHolder.set(b.accountName || '');
    kvInfo.set(info.addInfo || '');
    bankNameEl.textContent = b.name || b.shortName || '';
    renderPromo(info.promo);
    // Ảnh QR CHÍNH THỨC từ img.vietqr.io (compact) - main fetch về data URL để né CSP.
    if (info.imageUrl) vt.wallet.qrImage(info.imageUrl).then((d) => { if (d) qrImg.src = d; });
  }).catch((e) => { closeModal(); notifyError(e, 'Không lấy được thông tin nạp tiền'); });

  // ── TỰ ĐỘNG PHÁT HIỆN TIỀN VÀO ────────────────────────────────────────────────
  // Đọc số dư gốc, rồi POLL: mỗi nhịp gọi wallet.reconcile (server đối soát Pay2S NGAY rồi
  // trả số dư mới). Số dư TĂNG ⇒ đã nhận tiền → báo "đã nhận +X", làm mới số dư ở header.
  // Dừng khi modal đóng (không còn trong DOM) hoặc quá thời gian tối đa.
  let baseline = null;
  let stopped = false;
  const POLL_MS = 5000;
  const MAX_MS = 10 * 60 * 1000; // ngừng poll sau 10 phút để không chạy vô hạn nếu để mở lâu
  const startedAt = Date.now();

  // lastTopup = lần nạp ngân hàng gần nhất server ghi nhận ({amount, bonus, promoName}).
  // Dùng để TÁCH "gốc + thưởng" ở modal thành công - số dư chỉ cho biết tổng đã tăng.
  let lastTopup = null;
  const readBalance = async () => {
    // reconcile: đối soát NGAY + trả số dư. Lỗi/không bật → fallback wallet.get.
    const r = await vt.wallet.reconcile().catch(() => null);
    if (r && typeof r.balance === 'number') { lastTopup = r.lastTopup || null; return r.balance; }
    const w = await vt.wallet.get().catch(() => null);
    return w && typeof w.balance === 'number' ? w.balance : null;
  };

  const refreshHeaderBalance = () => {
    try { window.__vtApp && window.__vtApp.refreshWalletBalance && window.__vtApp.refreshWalletBalance(); } catch { /* ignore */ }
  };

  const tick = async () => {
    if (stopped || !document.body.contains(qrHolder)) { stopped = true; return; }
    if (Date.now() - startedAt > MAX_MS) {
      stopped = true;
      if (statusTxt) statusTxt.textContent = 'Đã dừng kiểm tra tự động. Mở lại nếu bạn vừa chuyển khoản.';
      statusEl.classList.add('timeout');
      return;
    }
    const bal = await readBalance();
    if (stopped || !document.body.contains(qrHolder)) { stopped = true; return; }
    if (bal == null) { schedule(); return; }
    if (baseline == null) { baseline = bal; schedule(); return; }
    if (bal > baseline) {
      const added = bal - baseline;
      baseline = bal;
      // Phát hiện tiền vào → DỪNG poll, ĐÓNG modal nạp tiền, MỞ modal "Nạp tiền thành công".
      stopped = true;
      if (timer) clearTimeout(timer);
      refreshHeaderBalance();
      closeModal();
      if (typeof opts.onDone === 'function') { try { opts.onDone(bal); } catch { /* bỏ qua - vẫn phải báo nạp thành công */ } }
      // Chỉ tin lastTopup khi gốc + thưởng KHỚP ĐÚNG mức số dư vừa tăng. Lệch (vd vừa bị
      // trừ tiền mua hàng xen vào, hoặc gộp 2 lần chuyển khoản trong 1 nhịp poll) ⇒ báo
      // tổng cho an toàn, thà nói ít hơn là nói sai về tiền.
      const split = lastTopup && (Number(lastTopup.amount) + Number(lastTopup.bonus || 0)) === added
        ? lastTopup : null;
      showTopupSuccessModal(added, split);
      return;
    }
    schedule();
  };
  let timer = null;
  const schedule = () => { if (!stopped) timer = setTimeout(tick, POLL_MS); };
  // Khởi động: đọc số dư gốc ngay rồi bắt đầu nhịp poll.
  tick();

  // Dọn dẹp khi modal đóng: theo dõi DOM, khi qrHolder biến mất thì dừng + xoá timer.
  const cleanup = () => {
    if (!document.body.contains(qrHolder)) {
      stopped = true;
      if (timer) clearTimeout(timer);
      obs.disconnect();
    }
  };
  const obs = new MutationObserver(cleanup);
  obs.observe(document.body, { childList: true, subtree: true });
}

// Modal "Nạp tiền thành công": icon dấu tích ĐỘNG (vẽ vòng tròn rồi vẽ tích) + số tiền vừa
// nạp. Dùng lại animation .ap-success-anim/.ap-success-svg cho đồng bộ với modal nâng cấp gói.
//
// added  = số dư ĐÃ TĂNG (gốc + thưởng gộp lại).
// split  = {amount, bonus, promoName, promoPercent} nếu tách được - có thưởng khuyến mãi thì
//          BÓC RA cho khách thấy: "chuyển 100.000₫, thưởng +10.000₫, vào ví 110.000₫". Không
//          bóc thì khách chuyển 100k lại thấy báo 110k, tưởng hệ thống tính sai.
export function showTopupSuccessModal(added, split) {
  const bonus = split ? Number(split.bonus || 0) : 0;
  const body = [
    el('div.ap-success-anim', { html: '<svg class="ap-success-svg" viewBox="0 0 52 52"><circle class="ap-success-circle" cx="26" cy="26" r="24"/><path class="ap-success-check" d="M14 27l7 7 16-16"/></svg>' }),
  ];
  if (bonus > 0) {
    const km = split.promoPercent ? ` (+${split.promoPercent}%)` : '';
    body.push(
      el('div.ap-fund-note.ap-success-note', { text: tf('Nạp tiền thành công! Ví của bạn đã được cộng {0}.', fmtVnd(added)) }),
      el('div.ap-topup-breakdown', {}, [
        el('div.ap-topup-line', {}, [
          el('span', { text: 'Số tiền chuyển khoản' }),
          el('b', { text: fmtVnd(split.amount) }),
        ]),
        el('div.ap-topup-line.bonus', {}, [
          // promoName do admin tự đặt (tiếng Việt, lưu trong DB) → là DỮ LIỆU, không dịch
          // được; chỉ dịch phần nhãn quanh nó. km = " (+20%)" vốn không phụ thuộc ngôn ngữ.
          el('span', { text: split.promoName ? tf('Khuyến mãi: {0}', split.promoName + km) : t('Khuyến mãi nạp tiền') + km }),
          el('b', { text: '+' + fmtVnd(bonus) }),
        ]),
        el('div.ap-topup-line.total', {}, [
          el('span', { text: 'Cộng vào ví' }),
          el('b', { text: fmtVnd(added) }),
        ]),
      ]),
    );
  } else {
    body.push(el('div.ap-fund-note.ap-success-note', { text: tf('Bạn đã nạp thành công {0} vào ví. Số dư đã được cập nhật.', fmtVnd(added)) }));
  }
  const footer = [el('button.btn.primary', { text: 'Đóng', onclick: closeModal })];
  openModal({ title: 'Nạp tiền thành công', body, footer, width: 560 });
}
