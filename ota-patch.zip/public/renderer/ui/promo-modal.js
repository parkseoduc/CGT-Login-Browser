// Popup quảng cáo (promo) - ảnh marketing hiển thị GIỮA màn hình khi mở app,
// giống các bên như GenLogin. Nội dung do WEB ADMIN quản lý (bảng promos): app chỉ
// lấy promo đang hiệu lực qua API rồi hiển thị - KHÔNG hardcode nội dung.
//
// Độc lập với #modal-host (modal cập nhật) - dùng overlay riêng #promo-overlay gắn
// thẳng vào <body>, nên hai luồng không tranh chấp nhau.
//
// Tần suất (freq) do admin đặt, renderer tôn trọng qua localStorage:
//   - everyopen: hiện mỗi lần mở app.
//   - daily:     tối đa 1 lần/ngày.
//   - once:      chỉ 1 lần duy nhất (theo id promo).
import { el } from '../ui.js';

const SEEN_KEY = 'promoSeen'; // { [id]: 'YYYY-MM-DD' | 'once' }

function readSeen() {
  try { return JSON.parse(localStorage.getItem(SEEN_KEY) || '{}') || {}; } catch { return {}; }
}
function writeSeen(map) {
  try { localStorage.setItem(SEEN_KEY, JSON.stringify(map)); } catch { /* ignore */ }
}
function today() { return new Date().toISOString().slice(0, 10); }

// Có nên hiện promo này không (theo freq đã xem trước đó)?
function shouldShow(promo) {
  const freq = promo.freq || 'everyopen';
  if (freq === 'everyopen') return true;
  const seen = readSeen()[promo.id];
  if (freq === 'once') return seen !== 'once';
  if (freq === 'daily') return seen !== today();
  return true;
}
// Ghi lại đã xem để tôn trọng freq lần sau.
function markSeen(promo) {
  const freq = promo.freq || 'everyopen';
  if (freq === 'everyopen') return;
  const map = readSeen();
  map[promo.id] = freq === 'once' ? 'once' : today();
  writeSeen(map);
}

// showPromoModal(opts): lấy promo 'popup' đang hiệu lực từ server rồi hiện.
// opts.audience: 'all' | 'free' | 'expired' (mặc định 'all').
// opts.force=true: bỏ qua kiểm tra freq (dùng khi bấm "Xem thử" ở đâu đó).
export async function showPromoModal(opts = {}) {
  let promo = null;
  try {
    const res = await window.vt.promos.active({ type: 'popup', audience: opts.audience || 'all' });
    promo = res && res.ok ? res.data : null;
  } catch { promo = null; }
  if (!promo || !promo.image) return;              // không có promo hiệu lực → không hiện
  if (!opts.force && !shouldShow(promo)) return;   // đã xem đủ theo freq → bỏ qua

  render(promo);
}

function render(promo) {
  // Chỉ 1 popup tại một thời điểm.
  const old = document.getElementById('promo-overlay');
  if (old) old.remove();

  const overlay = el('div.promo-overlay#promo-overlay');
  // Đóng có hiệu ứng: thêm class .closing (ảnh thu nhỏ + mờ dần) rồi mới gỡ khỏi DOM
  // khi animation kết thúc. Có timeout dự phòng phòng khi animationend không bắn.
  let closing = false;
  function close() {
    if (closing) return;
    closing = true;
    document.removeEventListener('keydown', onKey);
    overlay.classList.add('closing');
    const done = () => { try { overlay.remove(); } catch { /* ignore */ } };
    // Chờ animation của .promo-box (ảnh thu nhỏ) kết thúc mới gỡ - dài hơn nền một chút.
    const box = overlay.querySelector('.promo-box');
    (box || overlay).addEventListener('animationend', done, { once: true });
    setTimeout(done, 650);
  }
  function onKey(e) { if (e.key === 'Escape') close(); }

  // KHÔNG có nút X - bấm vào BẤT KỲ đâu (kể cả ảnh) đều tự đóng popup.
  // Nếu promo có link đích: bấm vào ẢNH sẽ mở link (đếm click) rồi mới đóng.
  overlay.addEventListener('click', (e) => {
    if (e.target.classList && e.target.classList.contains('promo-img') && promo.target) {
      try { window.vt.promos.click(promo.id); } catch { /* ignore */ }
      try { window.vt.shell.openExternal(promo.target); } catch { /* ignore */ }
    }
    close();
  });

  const img = el('img.promo-img', {
    src: promo.image,
    alt: promo.title || 'Quảng cáo',
    // Ảnh hỏng/không tải được → bỏ popup luôn (không hiện khung rỗng).
    onerror: close,
  });
  if (promo.target) img.classList.add('promo-clickable');

  const box = el('div.promo-box', {}, [img]);
  overlay.appendChild(box);
  document.body.appendChild(overlay);
  document.addEventListener('keydown', onKey);

  // Đã hiển thị: ghi nhận theo freq + đếm lượt xem (best-effort).
  markSeen(promo);
  try { window.vt.promos.view(promo.id); } catch { /* ignore */ }
}
