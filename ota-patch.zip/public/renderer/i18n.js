// Live UI internationalization.
//
// The whole app is authored in Vietnamese (hard-coded strings across every view).
// Rather than rewrite each view with lookup keys, this module translates the DOM
// IN PLACE: it walks text nodes (plus `title`/`placeholder` attributes) and swaps
// each string for its translation, keyed on the exact Vietnamese source text.
//
// - `vi` is the default and the source of truth; picking it restores the originals.
// - Originals are remembered per-node in a WeakMap, so switching back and forth is
//   lossless (we never translate an already-translated string).
// - Strings with no dictionary entry are left as-is (graceful fallback), so partial
//   coverage degrades to "some Vietnamese remains" rather than blanks.
//
// Apply it after every navigate (covers freshly-rendered views + the shell) and on
// each language change (re-walks the whole body, incl. kept-alive hidden views).
// Language autonyms (Tiếng Việt / English / Русский / 中文) are intentionally NOT in
// the dictionary - a language's own name must read the same in every language.

export const LANGS = ['vi', 'en', 'ru', 'zh'];
const SUPPORTED = new Set(LANGS);

// key = exact trimmed Vietnamese source string; value = { en, ru, zh }
const DICT = {
  // ── Google Drive ở trang Dữ liệu đồng bộ (views/sync_data.js + câu lỗi main/gdrive.js, 2026-11-07) ──
  'Gói sao lưu nằm trong thư mục "CGTBrowser Backup" trên Drive của bạn. CGTBrowser chỉ xem và quản lý các tệp do chính nó tạo, không đọc được tệp khác trên Drive.': { en: 'Backups are stored in the "CGTBrowser Backup" folder on your Drive. CGTBrowser can only see and manage files it creates; it cannot read any other files on your Drive.', ru: 'Резервные копии хранятся в папке «CGTBrowser Backup» на вашем Диске. CGTBrowser видит и управляет только созданными им файлами и не может читать другие файлы на Диске.', zh: '备份存放在您 Drive 中的“CGTBrowser Backup”文件夹。CGTBrowser 只能查看和管理它自己创建的文件，无法读取 Drive 上的其他文件。' },
  'Đang chờ đăng nhập trên trình duyệt…': { en: 'Waiting for sign-in in your browser…', ru: 'Ожидание входа в браузере…', zh: '正在等待浏览器中完成登录…' },
  'Đăng nhập lại với Google': { en: 'Sign in again with Google', ru: 'Войти снова через Google', zh: '重新使用 Google 登录' },
  'Kết nối Google Drive cũ chưa có quyền lưu tệp sao lưu. Hãy đăng nhập lại một lần và cho phép CGTBrowser tạo, quản lý tệp trên Drive.': { en: 'Your previous Google Drive connection cannot save backup files. Sign in again once and allow CGTBrowser to create and manage files on Drive.', ru: 'Прежнее подключение к Google Диску не может сохранять резервные копии. Войдите снова и разрешите CGTBrowser создавать и управлять файлами на Диске.', zh: '旧的 Google Drive 连接没有保存备份文件的权限。请重新登录一次，并允许 CGTBrowser 在 Drive 上创建和管理文件。' },
  'Chưa kết nối đồng bộ. Hãy kết nối một trong ba nơi sao lưu (Google Drive / S3 / Telegram) trước khi bật.': { en: 'Sync is not connected. Connect one of the three backup destinations (Google Drive / S3 / Telegram) before turning it on.', ru: 'Синхронизация не подключена. Подключите одно из трёх мест хранения (Google Drive / S3 / Telegram), прежде чем включать.', zh: '尚未连接同步。请先连接三个备份位置之一（Google Drive / S3 / Telegram）再开启。' },
  'Phiên Google Drive đã hết hạn hoặc bị thu hồi. Vui lòng đăng nhập lại.': { en: 'Your Google Drive session has expired or was revoked. Please sign in again.', ru: 'Сеанс Google Диска истёк или был отозван. Войдите снова.', zh: 'Google Drive 会话已过期或被撤销，请重新登录。' },
  'Cần đăng nhập lại Google Drive để cấp quyền lưu tệp sao lưu.': { en: 'Sign in to Google Drive again to grant permission to save backups.', ru: 'Войдите в Google Диск снова, чтобы разрешить сохранение резервных копий.', zh: '需要重新登录 Google Drive 以授予保存备份的权限。' },
  'Chưa cấp quyền Google Drive. Hãy đăng nhập lại và tick ô cho phép CGTBrowser tạo và quản lý tệp sao lưu trên Drive.': { en: 'Google Drive permission was not granted. Sign in again and tick the box that lets CGTBrowser create and manage backup files on Drive.', ru: 'Доступ к Google Диску не предоставлен. Войдите снова и отметьте пункт, разрешающий CGTBrowser создавать и управлять резервными копиями на Диске.', zh: '未授予 Google Drive 权限。请重新登录并勾选允许 CGTBrowser 在 Drive 上创建和管理备份文件的选项。' },
  'Google Drive đã hết dung lượng lưu trữ': { en: 'Your Google Drive storage is full', ru: 'Хранилище Google Диска заполнено', zh: 'Google Drive 存储空间已满' },
  'Bạn đã huỷ đăng nhập Google': { en: 'You cancelled the Google sign-in', ru: 'Вы отменили вход через Google', zh: '您已取消 Google 登录' },
  'Chưa kết nối Google Drive': { en: 'Google Drive is not connected', ru: 'Google Диск не подключён', zh: '尚未连接 Google Drive' },
  'Phiên đăng nhập đã kết thúc. Vui lòng đăng nhập lại.': { en: 'Your session has ended. Please sign in again.', ru: 'Сеанс завершён. Войдите снова.', zh: '登录会话已结束，请重新登录。' },
  // ── Mã giảm giá (views/checkout.js + câu lỗi server coupon.js, 2026-11-07) - cùng bộ chữ với web landing i18n.js ──
  'Mã hợp lệ, giảm {0}': { en: 'Code applied: {0} off', ru: 'Промокод применён, скидка {0}', zh: '优惠码有效，立减{0}' },
  'Nhập mã giảm giá (nếu có)': { en: 'Discount code (optional)', ru: 'Промокод (если есть)', zh: '优惠码（如有）' },
  'đã áp dụng': { en: 'applied', ru: 'применён', zh: '已使用' },
  'Mã giảm giá': { en: 'Discount code', ru: 'Промокод', zh: '优惠码' },
  'Nhập mã giảm giá': { en: 'Discount code', ru: 'Промокод', zh: '输入优惠码' },
  'Gỡ mã': { en: 'Remove', ru: 'Убрать', zh: '移除' },
  'Vui lòng nhập mã giảm giá': { en: 'Please enter a discount code', ru: 'Введите промокод', zh: '请输入优惠码' },
  'Không kiểm tra được mã, vui lòng thử lại': { en: 'Could not check the code, please try again', ru: 'Не удалось проверить код, попробуйте ещё раз', zh: '无法检查优惠码，请重试' },
  'Mã chỉ áp dụng cho đơn từ {0}': { en: 'This code applies to orders from {0}', ru: 'Код действует для заказов от {0}', zh: '此优惠码适用于{0}及以上的订单' },
  'Mã chỉ áp dụng cho gói từ {0} ngày': { en: 'This code applies to plans of {0} days or longer', ru: 'Код действует для тарифов сроком от {0} дн.', zh: '此优惠码仅适用于{0}天及以上的套餐' },
  'Mã giảm giá không hợp lệ': { en: 'Invalid discount code', ru: 'Недействительный промокод', zh: '优惠码无效' },
  'Mã giảm giá chưa đến thời gian sử dụng': { en: 'This discount code is not active yet', ru: 'Срок действия промокода ещё не начался', zh: '优惠码尚未到使用时间' },
  'Mã giảm giá đã hết hạn': { en: 'This discount code has expired', ru: 'Срок действия промокода истёк', zh: '优惠码已过期' },
  'Mã giảm giá đã hết lượt sử dụng': { en: 'This discount code has been fully used', ru: 'Лимит использований промокода исчерпан', zh: '优惠码使用次数已用完' },
  'Bạn đã dùng hết số lần cho phép của mã này': { en: 'You have used this code the maximum number of times', ru: 'Вы уже использовали этот код максимальное число раз', zh: '您已达到此优惠码的使用次数上限' },
  'Tài khoản của bạn không thuộc đối tượng được dùng mã này': { en: 'Your account is not eligible for this code', ru: 'Ваш аккаунт не подходит для этого кода', zh: '您的账户不符合使用此优惠码的条件' },
  'Mã giảm giá không áp dụng cho đơn hàng này': { en: 'This discount code does not apply to this order', ru: 'Промокод не действует для этого заказа', zh: '此优惠码不适用于该订单' },
  'Đơn hàng chưa đạt giá trị tối thiểu để dùng mã này': { en: 'The order does not reach the minimum value for this code', ru: 'Сумма заказа ниже минимальной для этого кода', zh: '订单金额未达到使用此优惠码的最低要求' },
  'Mã này chỉ áp dụng khi mua gói đủ thời hạn tối thiểu': { en: 'This code only applies to plans with the minimum duration', ru: 'Код действует только для тарифов минимального срока', zh: '此优惠码仅适用于达到最短期限的套餐' },
  'Mã này không dùng chung với ưu đãi theo thời hạn gói': { en: 'This code cannot be combined with the plan duration discount', ru: 'Код не суммируется со скидкой за срок тарифа', zh: '此优惠码不可与套餐期限优惠同时使用' },
  'Bạn đã thử mã quá nhiều lần, vui lòng thử lại sau ít phút': { en: 'Too many code attempts, please try again in a few minutes', ru: 'Слишком много попыток, повторите через несколько минут', zh: '尝试次数过多，请几分钟后再试' },
  'Giá đơn hàng vừa thay đổi, vui lòng kiểm tra lại trước khi thanh toán': { en: 'The order price has just changed, please review it before paying', ru: 'Цена заказа только что изменилась, проверьте её перед оплатой', zh: '订单价格刚刚发生变化，请在付款前重新确认' },
  // ── Gia hạn khi gói còn hạn (views/upgrade.js costFor, checkout.js) ──
  'Hệ thống sẽ tự động nạp tiền trong vòng 30 giây - 1 phút sau khi bạn chuyển khoản thành công. Vui lòng giữ nguyên nội dung chuyển khoản.': { en: 'Funds will be added automatically within 30 seconds - 1 minute after your transfer succeeds. Please keep the transfer note unchanged.', ru: 'Средства будут зачислены автоматически в течение 30 секунд - 1 минуты после успешного перевода. Пожалуйста, не изменяйте назначение платежа.', zh: '转账成功后，系统将在 30 秒至 1 分钟内自动充值。请勿修改转账备注。' },
  '{0} (đã hết hạn)': { en: '{0} (expired)', ru: '{0} (истёк)', zh: '{0}（已过期）' },
  'Gia hạn toàn bộ hồ sơ': { en: 'Renewal of all profiles', ru: 'Продление всех профилей', zh: '全部配置文件续期' },
  '({0} hồ sơ × {1} ngày)': { en: '({0} profiles × {1} days)', ru: '(профилей: {0} × {1} дн.)', zh: '（{0} 个配置文件 × {1} 天）' },
  '(mua thêm {0}, gia hạn {1})': { en: '(buy {0} more, renew {1})', ru: '(докупить {0}, продлить {1})', zh: '（加购 {0}，续期 {1}）' },
  'Gia hạn toàn bộ': { en: 'Renew everything', ru: 'Продление всего', zh: '全部续期' },
  '{0} hồ sơ, {1} thành viên': { en: '{0} profiles, {1} members', ru: 'профилей: {0}, участников: {1}', zh: '{0} 个配置文件，{1} 位成员' },
  // ── Thanh toán / Nạp tiền / USD quy đổi (views/pay-common.js, checkout.js, topup.js) - lấy từ từ điển web landing ──
  'Trừ thẳng vào số dư ví CGTBrowser bạn đang có.': { en: 'Charged directly to your current CGTBrowser wallet balance.', ru: 'Списывается напрямую с текущего баланса кошелька CGTBrowser.', zh: '直接从您现有的 CGTBrowser 钱包余额中扣款。' },
  'Chuyển khoản ngân hàng Việt Nam bằng mã QR. Tiền vào ví xong, bấm thanh toán để trừ ví.': { en: 'Vietnamese bank transfer via QR code. Once the funds reach your wallet, press pay to charge it.', ru: 'Банковский перевод во Вьетнаме по QR-коду. Когда деньги поступят на кошелёк, нажмите «Оплатить».', zh: '通过二维码进行越南银行转账。款项到达钱包后，点击付款即可从钱包扣款。' },
  'Trả bằng USD qua tài khoản PayPal. Tiền về thành công được quy ra VNĐ theo tỷ giá Vietcombank lúc đó và cộng vào ví.': { en: 'Pay in USD with your PayPal account. Once received, the payment is converted to VND at the Vietcombank rate at that moment and added to your wallet.', ru: 'Оплата в USD через PayPal. После поступления сумма пересчитывается в VND по курсу Vietcombank на этот момент и зачисляется на кошелёк.', zh: '通过 PayPal 账户以美元付款。到账后按当时的 Vietcombank 汇率换算为越南盾并存入钱包。' },
  'Thẻ ngân hàng': { en: 'Bank card', ru: 'Банковская карта', zh: '银行卡' },
  'Trả bằng USD qua thẻ quốc tế Visa, Mastercard, JCB, American Express (cổng Dodo Payments). Tiền về thành công được quy ra VNĐ theo tỷ giá Vietcombank lúc đó và cộng vào ví.': { en: 'Pay in USD with an international Visa, Mastercard, JCB or American Express card (via Dodo Payments). Once received, the payment is converted to VND at the Vietcombank rate at that moment and added to your wallet.', ru: 'Оплата в USD международной картой Visa, Mastercard, JCB, American Express (через Dodo Payments). После поступления сумма пересчитывается в VND по курсу Vietcombank на этот момент и зачисляется на кошелёк.', zh: '使用 Visa、Mastercard、JCB、American Express 国际卡以美元付款（Dodo Payments 通道）。到账后按当时的 Vietcombank 汇率换算为越南盾并存入钱包。' },
  'Thanh toán quốc tế tối thiểu {0}': { en: 'International payments start from {0}', ru: 'Минимальная международная оплата {0}', zh: '国际支付最低 {0}' },
  'Thanh toán quốc tế tối đa {0}': { en: 'International payments are limited to {0}', ru: 'Максимальная международная оплата {0}', zh: '国际支付最高 {0}' },
  'mọi mức giá tính phí {0}%': { en: 'all amounts carry a {0}% fee', ru: 'для любой суммы комиссия {0}%', zh: '所有金额收取 {0}% 手续费' },
  'mọi mức giá không tính thêm phí': { en: 'no extra fee applies', ru: 'дополнительная комиссия не взимается', zh: '不收取额外手续费' },
  'giá dưới ${0} tính phí {1}%': { en: 'amounts under ${0} carry a {1}% fee', ru: 'для сумм до ${0} комиссия {1}%', zh: '低于 ${0} 收取 {1}% 手续费' },
  'giá dưới ${0} không tính thêm phí': { en: 'amounts under ${0} have no extra fee', ru: 'для сумм до ${0} без комиссии', zh: '低于 ${0} 不收取额外手续费' },
  'từ ${0} đến dưới ${1} tính phí {2}%': { en: 'from ${0} to under ${1} carry a {2}% fee', ru: 'от ${0} до ${1} комиссия {2}%', zh: '${0} 至低于 ${1} 收取 {2}% 手续费' },
  'từ ${0} đến dưới ${1} không tính thêm phí': { en: 'from ${0} to under ${1} have no extra fee', ru: 'от ${0} до ${1} без комиссии', zh: '${0} 至低于 ${1} 不收取额外手续费' },
  'từ ${0} trở lên tính phí {1}%': { en: '${0} and above carry a {1}% fee', ru: 'от ${0} и выше комиссия {1}%', zh: '${0} 及以上收取 {1}% 手续费' },
  'từ ${0} trở lên không tính thêm phí': { en: '${0} and above have no extra fee', ru: 'от ${0} и выше без комиссии', zh: '${0} 及以上不收取额外手续费' },
  'Với phương thức {0}, {1}.': { en: 'With {0}, {1}.', ru: 'Для способа {0}: {1}.', zh: '使用 {0} 时，{1}。' },
  'Thanh toán bằng thẻ sẽ chịu thêm {0}% thuế VAT, được tính trên số tiền thanh toán ban đầu và tự động cộng vào tổng số tiền khi thanh toán.': { en: 'Card payments are subject to an additional {0}% VAT, calculated on the original payment amount and added to the total automatically at checkout.', ru: 'К оплате картой добавляется НДС {0}%: он рассчитывается от исходной суммы и автоматически прибавляется к итогу при оплате.', zh: '银行卡付款需另加 {0}% 增值税，按原始付款金额计算，并在付款时自动计入总额。' },
  'Cổng thanh toán đang lỗi, vui lòng thử lại': { en: 'The payment gateway is unavailable, please try again', ru: 'Платёжный шлюз недоступен, попробуйте ещё раз', zh: '支付通道暂不可用，请重试' },
  'Không mở được trang thanh toán': { en: 'Could not open the payment page', ru: 'Не удалось открыть страницу оплаты', zh: '无法打开付款页面' },
  'Đang chờ thanh toán…': { en: 'Waiting for payment…', ru: 'Ожидание оплаты…', zh: '等待付款…' },
  'Hoàn tất thanh toán trong trình duyệt': { en: 'Complete the payment in your browser', ru: 'Завершите оплату в браузере', zh: '请在浏览器中完成付款' },
  'Trang thanh toán đã mở trong trình duyệt. Sau khi bạn thanh toán xong, ứng dụng tự cập nhật ví - không cần thao tác thêm.': { en: 'The payment page has opened in your browser. Once you have paid, the app updates your wallet automatically - nothing else to do.', ru: 'Страница оплаты открыта в браузере. После оплаты приложение само обновит кошелёк - больше ничего делать не нужно.', zh: '付款页面已在浏览器中打开。付款完成后，应用会自动更新钱包，无需其他操作。' },
  'Mở lại trang thanh toán': { en: 'Reopen payment page', ru: 'Открыть страницу оплаты снова', zh: '重新打开付款页面' },
  'Đã dừng kiểm tra tự động. Nếu đã trả tiền, ví sẽ tự được cộng trong ít phút.': { en: 'Automatic checking stopped. If you have paid, your wallet will be credited within a few minutes.', ru: 'Автопроверка остановлена. Если вы оплатили, кошелёк пополнится в течение нескольких минут.', zh: '已停止自动检查。如已付款，钱包将在几分钟内自动入账。' },
  'Thanh toán chưa hoàn tất': { en: 'Payment not completed', ru: 'Оплата не завершена', zh: '付款未完成' },
  'Giao dịch chưa được ghi nhận. Nếu bạn đã bị trừ tiền, hãy liên hệ hỗ trợ kèm mã {0}.': { en: 'The transaction was not recorded. If you were charged, please contact support with code {0}.', ru: 'Транзакция не зарегистрирована. Если деньги списаны, свяжитесь с поддержкой и укажите код {0}.', zh: '交易未被记录。如已扣款，请联系客服并提供代码 {0}。' },
  'Đã nhận thanh toán. Ví sẽ được cộng ngay khi có tỷ giá Vietcombank.': { en: 'Payment received. Your wallet will be credited as soon as the Vietcombank rate is available.', ru: 'Оплата получена. Кошелёк пополнится, как только будет доступен курс Vietcombank.', zh: '已收到付款。一旦获取到 Vietcombank 汇率，钱包将立即入账。' },
  'Đã nhận {0}. Ví của bạn được cộng {1}.': { en: 'Received {0}. {1} has been added to your wallet.', ru: 'Получено {0}. На кошелёк зачислено {1}.', zh: '已收到 {0}。钱包已入账 {1}。' },
  'Tỷ giá Vietcombank': { en: 'Vietcombank rate', ru: 'Курс Vietcombank', zh: 'Vietcombank 汇率' },
  'Quay lại quản lý thiết bị': { en: 'Back to device management', ru: 'Назад к управлению устройствами', zh: '返回设备管理' },
  'Quay lại chọn gói': { en: 'Back to plans', ru: 'Назад к тарифам', zh: '返回选择套餐' },
  'Thủ tục thanh toán': { en: 'Checkout', ru: 'Оформление оплаты', zh: '结算' },
  '{0} thiết bị': { en: '{0} devices', ru: 'Устройств: {0}', zh: '{0} 台设备' },
  'Loại phí': { en: 'Charge type', ru: 'Тип платежа', zh: '收费方式' },
  'Một lần, không mất khi gia hạn': { en: 'One-time, kept when you renew', ru: 'Разово, сохраняется при продлении', zh: '一次性，续费时保留' },
  'Về quản lý thiết bị': { en: 'Back to device management', ru: 'К управлению устройствами', zh: '返回设备管理' },
  'Thanh toán ngay': { en: 'Pay now', ru: 'Оплатить', zh: '立即付款' },
  'Nâng cấp từ gói {0}': { en: 'Upgrade from {0}', ru: 'Повышение с тарифа {0}', zh: '从 {0} 升级' },
  '{0} hồ sơ trình duyệt': { en: '{0} browser profiles', ru: '{0} профилей браузера', zh: '{0} 个浏览器配置文件' },
  '+{0} hồ sơ': { en: '+{0} profiles', ru: '+{0} профилей', zh: '+{0} 个配置文件' },
  '{0} ngày': { en: '{0} days', ru: '{0} дн.', zh: '{0} 天' },
  'Ngày hết hạn': { en: 'Expiry date', ru: 'Дата окончания', zh: '到期日期' },
  'Giá mỗi tháng': { en: 'Price per month', ru: 'Цена в месяц', zh: '每月价格' },
  'Giảm giá': { en: 'Discount', ru: 'Скидка', zh: '折扣' },
  'Về trang gói': { en: 'Go to plans', ru: 'К тарифам', zh: '返回套餐页' },
  'Thanh toán gói ngay': { en: 'Pay for the plan now', ru: 'Оплатить тариф сейчас', zh: '立即支付套餐' },
  'Chọn thiết bị': { en: 'Choose devices', ru: 'Выбор устройств', zh: '选择设备' },
  'Chọn gói': { en: 'Choose plan', ru: 'Выбор тарифа', zh: '选择套餐' },
  'Thanh toán': { en: 'Payment', ru: 'Оплата', zh: '付款' },
  'Chọn phương thức thanh toán': { en: 'Choose a payment method', ru: 'Выберите способ оплаты', zh: '选择付款方式' },
  'Số dư không đủ, còn thiếu {0}': { en: 'Insufficient balance, short by {0}', ru: 'Недостаточно средств, не хватает {0}', zh: '余额不足，还差 {0}' },
  'Nạp tiền bằng VietQR': { en: 'Top up with VietQR', ru: 'Пополнить через VietQR', zh: '通过 VietQR 充值' },
  'Thanh toán qua PayPal': { en: 'Pay with PayPal', ru: 'Оплатить через PayPal', zh: '通过 PayPal 支付' },
  'Thanh toán bằng thẻ': { en: 'Pay by card', ru: 'Оплатить картой', zh: '用银行卡支付' },
  'Thông tin đơn hàng': { en: 'Order summary', ru: 'Сводка заказа', zh: '订单信息' },
  'Tạm tính': { en: 'Subtotal', ru: 'Промежуточный итог', zh: '小计' },
  'Phí {0} ({1}%)': { en: '{0} fee ({1}%)', ru: 'Комиссия {0} ({1}%)', zh: '{0} 手续费（{1}%）' },
  'thẻ': { en: 'card', ru: 'карты', zh: '银行卡' },
  'Thuế VAT (~{0}%)': { en: 'VAT (~{0}%)', ru: 'НДС (~{0}%)', zh: '增值税（约 {0}%）' },
  'Cộng khi thanh toán': { en: 'Added at checkout', ru: 'Добавляется при оплате', zh: '付款时计入' },
  '{0} + phí {1}': { en: '{0} + {1} fee', ru: '{0} + комиссия {1}', zh: '{0} + 手续费 {1}' },
  'Đang chuyển sang cổng thanh toán…': { en: 'Redirecting to the payment page…', ru: 'Переход на страницу оплаты…', zh: '正在跳转至支付页面…' },
  'Ví CGTBrowser tính bằng VNĐ: số tiền nạp được quy ra VNĐ, rồi trừ VNĐ để mua gói.': { en: 'Your CGTBrowser wallet is in VND: top-ups are converted to VND, and plans are paid in VND.', ru: 'Кошелёк CGTBrowser ведётся в VND: пополнения пересчитываются в VND, тарифы оплачиваются в VND.', zh: 'CGTBrowser 钱包以越南盾计价：充值换算为越南盾，套餐以越南盾支付。' },
  'Thanh toán {0} từ ví CGTBrowser?': { en: 'Pay {0} from your CGTBrowser wallet?', ru: 'Оплатить {0} с кошелька CGTBrowser?', zh: '从 CGTBrowser 钱包支付 {0}？' },
  'Số tiền nạp tối thiểu {0}': { en: 'The minimum top-up is {0}', ru: 'Минимальное пополнение {0}', zh: '最低充值 {0}' },
  'Số tiền muốn nạp': { en: 'Top-up amount', ru: 'Сумма пополнения', zh: '充值金额' },
  'Số dư hiện tại': { en: 'Current balance', ru: 'Текущий баланс', zh: '当前余额' },
  'Ví nhận (ước tính)': { en: 'Wallet receives (estimate)', ru: 'На кошелёк (примерно)', zh: '钱包到账（预估）' },
  'Ví nhận': { en: 'Wallet receives', ru: 'На кошелёк', zh: '钱包到账' },
  'phí': { en: 'fee', ru: 'комиссия', zh: '手续费' },
  'Số tiền thực cộng vào ví tính theo tỷ giá Vietcombank lúc tiền về, phí cổng thanh toán không cộng vào ví.': { en: 'The amount actually credited uses the Vietcombank rate at the moment the payment arrives; the gateway fee is not added to your wallet.', ru: 'Фактическая сумма зачисления рассчитывается по курсу Vietcombank на момент поступления платежа; комиссия шлюза на кошелёк не зачисляется.', zh: '实际入账金额按到账时的 Vietcombank 汇率计算，支付通道手续费不计入钱包。' },
  'Đi tới Gói dịch vụ': { en: 'Go to Plans', ru: 'К тарифам', zh: '前往套餐' },
  'Tổng {0} hồ sơ = {1}.': { en: 'Total for {0} profiles = {1}.', ru: 'Итого (профилей: {0}) = {1}.', zh: '{0} 个配置文件合计 = {1}。' },
  // ── App shell: sidebar nav ────────────────────────────────────────────────
  'Hồ sơ': { en: 'Profiles', ru: 'Профили', zh: '配置文件' },
  'Nhóm': { en: 'Groups', ru: 'Группы', zh: '分组' },
  'Proxies': { en: 'Proxies', ru: 'Прокси', zh: '代理' },
  'Tiện ích': { en: 'Extensions', ru: 'Расширения', zh: '扩展' },
  'Thùng rác': { en: 'Trash', ru: 'Корзина', zh: '回收站' },
  'Tự động hóa': { en: 'Automation', ru: 'Автоматизация', zh: '自动化' },
  'Đồng bộ thao tác': { en: 'Sync Actions', ru: 'Синхронизация действий', zh: '同步操作' },
  'Quy trình': { en: 'Workflows', ru: 'Процессы', zh: '流程' },
  'Nhiệm vụ': { en: 'Tasks', ru: 'Задачи', zh: '任务' },
  'Lập lịch': { en: 'Scheduler', ru: 'Планировщик', zh: '计划任务' },
  'Chợ': { en: 'Store', ru: 'Магазин', zh: '商店' },
  'Tài liệu API': { en: 'API Docs', ru: 'Документация API', zh: 'API 文档' },
  'Thành viên': { en: 'Members', ru: 'Участники', zh: '成员' },
  'Nhật ký hoạt động': { en: 'Activity Log', ru: 'Журнал активности', zh: '活动日志' },
  'Cài đặt': { en: 'Settings', ru: 'Настройки', zh: '设置' },
  // Nhãn badge trên mục "Dữ liệu đồng bộ". Dạng nhãn ngắn, KHÔNG phải câu: tiếng Nga
  // dùng dạng ngắn trung tính "Важно" (chuẩn cho nhãn/cảnh báo), không dùng "Важное".
  'Quan trọng': { en: 'Important', ru: 'Важно', zh: '重要' },

  // ── Trang "Hồ sơ đăng ký" (account.js) ────────────────────────────────────
  'Hồ sơ đăng ký': { en: 'Account', ru: 'Аккаунт', zh: '账户' },
  'Thông tin tài khoản và bảo mật': { en: 'Account information and security', ru: 'Информация об аккаунте и безопасность', zh: '账户信息与安全' },
  'Thông tin tài khoản': { en: 'Account information', ru: 'Информация об аккаунте', zh: '账户信息' },
  'Xác thực email': { en: 'Email verification', ru: 'Подтверждение email', zh: '邮箱验证' },
  'ID tài khoản': { en: 'Account ID', ru: 'ID аккаунта', zh: '账户 ID' },
  'Đang hoạt động': { en: 'Active', ru: 'Активен', zh: '正常' },
  'Đã xác thực': { en: 'Verified', ru: 'Подтверждён', zh: '已验证' },
  'Chưa xác thực': { en: 'Not verified', ru: 'Не подтверждён', zh: '未验证' },
  'Tài khoản CGTBrowser': { en: 'CGTBrowser account', ru: 'Аккаунт CGTBrowser', zh: 'CGTBrowser 账户' },
  'Đổi mật khẩu': { en: 'Change password', ru: 'Сменить пароль', zh: '修改密码' },
  'Thay đổi mật khẩu': { en: 'Change password', ru: 'Смена пароля', zh: '修改密码' },
  'Mật khẩu cũ': { en: 'Old password', ru: 'Старый пароль', zh: '旧密码' },
  'Xác nhận mật khẩu mới': { en: 'Confirm new password', ru: 'Подтвердите новый пароль', zh: '确认新密码' },
  'Vui lòng nhập mật khẩu đúng định dạng': { en: 'Please enter a password in the correct format', ru: 'Пожалуйста, введите пароль в правильном формате', zh: '请输入格式正确的密码' },
  'Lưu mật khẩu mới': { en: 'Save new password', ru: 'Сохранить новый пароль', zh: '保存新密码' },
  'Hiện/ẩn mật khẩu': { en: 'Show/hide password', ru: 'Показать/скрыть пароль', zh: '显示/隐藏密码' },
  'Đổi mật khẩu ngay tại đây, không cần xác thực qua email. Bạn chỉ cần nhập đúng mật khẩu hiện tại.': { en: 'Change your password right here - no email verification needed. Just enter your current password.', ru: 'Смените пароль прямо здесь - без подтверждения по email. Достаточно ввести текущий пароль.', zh: '在此直接修改密码，无需邮箱验证。只需输入当前密码即可。' },
  'Mật khẩu hiện tại': { en: 'Current password', ru: 'Текущий пароль', zh: '当前密码' },
  'Mật khẩu mới': { en: 'New password', ru: 'Новый пароль', zh: '新密码' },
  'Nhập lại mật khẩu mới': { en: 'Confirm new password', ru: 'Повторите новый пароль', zh: '确认新密码' },
  'Mật khẩu mới (tối thiểu 6 ký tự)': { en: 'New password (at least 6 characters)', ru: 'Новый пароль (не менее 6 символов)', zh: '新密码（至少 6 个字符）' },
  'Vui lòng nhập mật khẩu hiện tại': { en: 'Please enter your current password', ru: 'Пожалуйста, введите текущий пароль', zh: '请输入当前密码' },
  'Mật khẩu mới tối thiểu 6 ký tự': { en: 'New password must be at least 6 characters', ru: 'Новый пароль должен содержать не менее 6 символов', zh: '新密码至少 6 个字符' },
  'Mật khẩu mới tối thiểu 6 ký tự, gồm cả chữ và số': { en: 'New password must be at least 6 characters, with letters and numbers', ru: 'Новый пароль: не менее 6 символов, буквы и цифры', zh: '新密码至少 6 个字符，且包含字母和数字' },
  'Mật khẩu nhập lại không khớp': { en: 'Passwords do not match', ru: 'Пароли не совпадают', zh: '两次输入的密码不一致' },
  'Mật khẩu mới trùng mật khẩu hiện tại': { en: 'New password matches the current one', ru: 'Новый пароль совпадает с текущим', zh: '新密码与当前密码相同' },
  'Mật khẩu mới không được trùng mật khẩu cũ': { en: 'New password must not match the old one', ru: 'Новый пароль не должен совпадать со старым', zh: '新密码不能与旧密码相同' },
  'Vui lòng nhập lại mật khẩu mới': { en: 'Please re-enter the new password', ru: 'Пожалуйста, повторите новый пароль', zh: '请再次输入新密码' },
  'Mật khẩu hiện tại không đúng': { en: 'Current password is incorrect', ru: 'Текущий пароль неверный', zh: '当前密码不正确' },
  'Đã đổi mật khẩu thành công': { en: 'Password changed successfully', ru: 'Пароль успешно изменён', zh: '密码修改成功' },
  'Đổi mật khẩu thất bại': { en: 'Failed to change password', ru: 'Не удалось сменить пароль', zh: '修改密码失败' },
  'Không tải được thông tin tài khoản': { en: 'Failed to load account information', ru: 'Не удалось загрузить информацию об аккаунте', zh: '无法加载账户信息' },

  // ── Màn đăng nhập / đăng ký / quên mật khẩu / OTP (login.js) ───────────────
  'Đăng ký': { en: 'Sign up', ru: 'Регистрация', zh: '注册' },
  'Email': { en: 'Email', ru: 'Email', zh: '邮箱' },
  'Ghi nhớ mật khẩu': { en: 'Remember password', ru: 'Запомнить пароль', zh: '记住密码' },
  'Quên mật khẩu?': { en: 'Forgot password?', ru: 'Забыли пароль?', zh: '忘记密码？' },
  'Quên mật khẩu': { en: 'Forgot password', ru: 'Восстановление пароля', zh: '忘记密码' },
  'Nhập email': { en: 'Enter your email', ru: 'Введите email', zh: '请输入邮箱' },
  'Nhập mật khẩu': { en: 'Enter your password', ru: 'Введите пароль', zh: '请输入密码' },
  'Đăng nhập với Google': { en: 'Sign in with Google', ru: 'Войти через Google', zh: '使用 Google 登录' },
  'Hiện mật khẩu': { en: 'Show password', ru: 'Показать пароль', zh: '显示密码' },
  'Ẩn mật khẩu': { en: 'Hide password', ru: 'Скрыть пароль', zh: '隐藏密码' },
  'Người dùng mới sẽ tự động đăng ký tài khoản': { en: 'New users will be registered automatically', ru: 'Новые пользователи регистрируются автоматически', zh: '新用户将自动注册账号' },
  'và': { en: 'and', ru: 'и', zh: '和' },
  'Tôi đã đọc và đồng ý với': { en: 'I have read and agree to', ru: 'Я прочитал(а) и согласен(на) с', zh: '我已阅读并同意' },
  'Đăng nhập đồng nghĩa với việc bạn đồng ý với': { en: 'By signing in you agree to', ru: 'Выполняя вход, вы соглашаетесь с', zh: '登录即表示您同意' },
  'Terms of Use': { en: 'Terms of Use', ru: 'Условия использования', zh: '使用条款' },
  'Privacy Policy': { en: 'Privacy Policy', ru: 'Политика конфиденциальности', zh: '隐私政策' },
  'Không có tài khoản CGTBrowser ?': { en: 'No CGTBrowser account?', ru: 'Нет аккаунта CGTBrowser?', zh: '还没有 CGTBrowser 账号？' },
  '← Quay lại đăng nhập': { en: '← Back to sign in', ru: '← Назад ко входу', zh: '← 返回登录' },

  // Nút / trạng thái động
  'Gửi yêu cầu': { en: 'Send request', ru: 'Отправить запрос', zh: '提交请求' },
  'Đang đăng ký…': { en: 'Signing up…', ru: 'Регистрация…', zh: '正在注册…' },
  'Đang gửi…': { en: 'Sending…', ru: 'Отправка…', zh: '正在发送…' },
  'Đang mở Google…': { en: 'Opening Google…', ru: 'Открываем Google…', zh: '正在打开 Google…' },
  'Nhận mã xác minh': { en: 'Get code', ru: 'Получить код', zh: '获取验证码' },
  'Gửi mã': { en: 'Send code', ru: 'Отправить код', zh: '发送验证码' },
  'Gửi lại': { en: 'Resend', ru: 'Отправить снова', zh: '重新发送' },
  'Mã xác nhận': { en: 'Verification code', ru: 'Код подтверждения', zh: '验证码' },
  'Nhập mã xác nhận': { en: 'Enter the code', ru: 'Введите код', zh: '请输入验证码' },

  // Ô "Mã giới thiệu" (TUỲ CHỌN) ở màn đăng ký - chương trình hoa hồng.
  // ⛔ KHÔNG còn khoá 'Mã giới thiệu (không bắt buộc)': user bỏ chữ "(không bắt buộc)" khỏi
  // nhãn 2026-10-20, nhãn nay là 'Mã giới thiệu' trần. Khoá đó đã mất chỗ dùng cuối cùng.
  // ⛔ Và ĐỪNG thêm khoá 'Mã giới thiệu' ở đây: nó ĐÃ CÓ ở khối trang "Hoa hồng" phía dưới
  // (tìm `'Mã giới thiệu':`). DICT này là một object literal - khai trùng khoá thì bản DƯỚI
  // lặng lẽ ghi đè bản trên, không lỗi, không cảnh báo. Trong tệp đã có 5 cặp trùng cũ như
  // vậy rồi, đừng thêm cặp thứ sáu.
  // ⛔ KHÔNG còn khoá 'Nhập mã nếu bạn được giới thiệu' (placeholder cũ của ô): placeholder nay
  // là 'Không bắt buộc' cho ĐỒNG NHẤT với web landing, và khoá đó ĐÃ CÓ ở khối khác trong tệp
  // (tìm `'Không bắt buộc':`) nên KHÔNG khai lại ở đây - xem lý do khoá trùng ngay trên.
  'Mã giới thiệu không tồn tại': { en: 'This referral code does not exist', ru: 'Такой код приглашения не существует', zh: '该推荐码不存在' },

  // Màn "Quên mật khẩu" (đặt lại mật khẩu qua mã OTP email)
  'Đặt lại mật khẩu': { en: 'Reset password', ru: 'Сбросить пароль', zh: '重置密码' },
  'Đang đặt lại…': { en: 'Resetting…', ru: 'Сброс…', zh: '正在重置…' },
  'Nhập email tài khoản, bấm "Nhận mã xác minh" để nhận mã qua email, rồi nhập mã và mật khẩu mới để đặt lại.': { en: 'Enter your account email, click "Get code" to receive a code by email, then enter the code and a new password to reset.', ru: 'Введите email аккаунта, нажмите «Получить код», чтобы получить код на почту, затем введите код и новый пароль для сброса.', zh: '请输入账户邮箱，点击"获取验证码"以通过邮件接收验证码，然后输入验证码和新密码进行重置。' },
  'Vui lòng nhập mật khẩu mới': { en: 'Please enter a new password', ru: 'Пожалуйста, введите новый пароль', zh: '请输入新密码' },
  'Đặt lại mật khẩu thành công. Vui lòng đăng nhập lại.': { en: 'Password reset successfully. Please sign in again.', ru: 'Пароль успешно сброшен. Пожалуйста, войдите снова.', zh: '密码重置成功。请重新登录。' },
  'Đặt lại mật khẩu thất bại': { en: 'Password reset failed', ru: 'Не удалось сбросить пароль', zh: '密码重置失败' },
  'Email này chưa được đăng ký': { en: 'This email is not registered', ru: 'Этот email не зарегистрирован', zh: '该邮箱尚未注册' },
  'Email bạn nhập không tồn tại': { en: 'The email you entered does not exist', ru: 'Введённый email не существует', zh: '您输入的邮箱不存在' },
  'Tài khoản đã bị khóa': { en: 'This account is locked', ru: 'Этот аккаунт заблокирован', zh: '该账户已被锁定' },

  // Lỗi kiểm tra ô nhập
  'Vui lòng nhập email': { en: 'Please enter your email', ru: 'Пожалуйста, введите email', zh: '请输入邮箱' },
  'Email không đúng định dạng': { en: 'Invalid email format', ru: 'Неверный формат email', zh: '邮箱格式不正确' },
  'Vui lòng nhập mã xác nhận': { en: 'Please enter the verification code', ru: 'Пожалуйста, введите код подтверждения', zh: '请输入验证码' },
  'Mã xác nhận gồm 6 số': { en: 'The code is 6 digits', ru: 'Код состоит из 6 цифр', zh: '验证码为 6 位数字' },
  'Vui lòng nhập mật khẩu': { en: 'Please enter your password', ru: 'Пожалуйста, введите пароль', zh: '请输入密码' },
  'Vui lòng đọc và đồng ý với điều khoản trước khi đăng ký': { en: 'Please read and accept the terms before signing up', ru: 'Пожалуйста, прочитайте и примите условия перед регистрацией', zh: '请先阅读并同意条款后再注册' },

  // Thông báo lỗi / trạng thái đăng ký & OTP
  'Mã xác thực không đúng': { en: 'Incorrect verification code', ru: 'Неверный код подтверждения', zh: '验证码不正确' },
  'Mã xác thực đã hết hạn, hãy bấm "Gửi lại" để lấy mã mới': { en: 'The verification code has expired. Tap "Resend" to get a new one.', ru: 'Код подтверждения истёк. Нажмите «Отправить снова», чтобы получить новый.', zh: '验证码已过期，请点击“重新发送”获取新验证码。' },
  'Nhập sai quá nhiều lần, hãy bấm "Gửi lại" để lấy mã mới': { en: 'Too many incorrect attempts. Tap "Resend" to get a new code.', ru: 'Слишком много неверных попыток. Нажмите «Отправить снова», чтобы получить новый код.', zh: '输入错误次数过多，请点击“重新发送”获取新验证码。' },
  'Bạn chưa lấy mã hoặc mã đã hết hạn, hãy bấm "Gửi mã"': { en: 'You haven\'t requested a code or it has expired. Tap "Send code".', ru: 'Вы не запрашивали код или он истёк. Нажмите «Отправить код».', zh: '您尚未获取验证码或验证码已过期，请点击“发送验证码”。' },
  'Đăng ký thất bại': { en: 'Sign-up failed', ru: 'Не удалось зарегистрироваться', zh: '注册失败' },
  'Không gửi được mã xác thực': { en: 'Failed to send the verification code', ru: 'Не удалось отправить код подтверждения', zh: '验证码发送失败' },
  'Đã gửi mã xác thực tới email': { en: 'Verification code sent to your email', ru: 'Код подтверждения отправлен на email', zh: '验证码已发送至您的邮箱' },
  'Đăng nhập Google chưa được cấu hình trên máy chủ.': { en: 'Google sign-in is not configured on the server.', ru: 'Вход через Google не настроен на сервере.', zh: '服务器尚未配置 Google 登录。' },
  'Đăng nhập Google thất bại. Vui lòng thử lại.': { en: 'Google sign-in failed. Please try again.', ru: 'Не удалось войти через Google. Попробуйте снова.', zh: 'Google 登录失败，请重试。' },

  // Modal Điều khoản sử dụng
  'Điều khoản sử dụng': { en: 'Terms of Use', ru: 'Условия использования', zh: '使用条款' },
  '1. Chấp nhận điều khoản': { en: '1. Acceptance of terms', ru: '1. Принятие условий', zh: '1. 接受条款' },
  'Khi tạo tài khoản và sử dụng CGTBrowser, bạn xác nhận đã đọc, hiểu và đồng ý bị ràng buộc bởi các Điều khoản sử dụng này. Nếu không đồng ý, vui lòng ngừng sử dụng dịch vụ.': { en: 'By creating an account and using CGTBrowser, you confirm that you have read, understood and agree to be bound by these Terms of Use. If you do not agree, please stop using the service.', ru: 'Создавая аккаунт и используя CGTBrowser, вы подтверждаете, что прочитали, поняли и согласны соблюдать настоящие Условия использования. Если вы не согласны, прекратите использование сервиса.', zh: '创建账户并使用 CGTBrowser，即表示您确认已阅读、理解并同意受本使用条款约束。如不同意，请停止使用本服务。' },
  '2. Tài khoản của bạn': { en: '2. Your account', ru: '2. Ваш аккаунт', zh: '2. 您的账户' },
  'Bạn chịu trách nhiệm giữ bí mật thông tin đăng nhập và mọi hoạt động diễn ra dưới tài khoản của mình.': { en: 'You are responsible for keeping your login credentials confidential and for all activity that occurs under your account.', ru: 'Вы несёте ответственность за сохранение конфиденциальности данных для входа и за все действия, совершаемые под вашим аккаунтом.', zh: '您有责任对登录信息保密，并对您账户下发生的所有活动负责。' },
  'Bạn cam kết cung cấp thông tin đăng ký chính xác và cập nhật khi có thay đổi.': { en: 'You agree to provide accurate registration information and to keep it up to date when it changes.', ru: 'Вы обязуетесь предоставлять точные регистрационные данные и обновлять их при изменении.', zh: '您承诺提供准确的注册信息，并在信息变更时及时更新。' },
  '3. Sử dụng hợp pháp': { en: '3. Lawful use', ru: '3. Законное использование', zh: '3. 合法使用' },
  'Bạn đồng ý chỉ sử dụng CGTBrowser cho các mục đích hợp pháp và không vi phạm quyền lợi của bên thứ ba.': { en: 'You agree to use CGTBrowser only for lawful purposes and not to infringe the rights of any third party.', ru: 'Вы соглашаетесь использовать CGTBrowser только в законных целях и не нарушать права третьих лиц.', zh: '您同意仅将 CGTBrowser 用于合法目的，且不侵犯任何第三方的权益。' },
  'Nghiêm cấm dùng dịch vụ để phát tán mã độc, gian lận, truy cập trái phép hoặc bất kỳ hành vi vi phạm pháp luật nào.': { en: 'Using the service to distribute malware, commit fraud, gain unauthorized access, or engage in any unlawful activity is strictly prohibited.', ru: 'Строго запрещается использовать сервис для распространения вредоносного ПО, мошенничества, несанкционированного доступа или любых противоправных действий.', zh: '严禁利用本服务传播恶意软件、进行欺诈、未经授权的访问或任何违法行为。' },
  '4. Sở hữu trí tuệ': { en: '4. Intellectual property', ru: '4. Интеллектуальная собственность', zh: '4. 知识产权' },
  'Toàn bộ phần mềm, giao diện, thương hiệu và nội dung của CGTBrowser thuộc quyền sở hữu của chúng tôi và được pháp luật bảo hộ. Bạn không được sao chép, phân phối hay chỉnh sửa khi chưa được cho phép.': { en: 'All software, interfaces, branding and content of CGTBrowser are owned by us and protected by law. You may not copy, distribute or modify them without permission.', ru: 'Всё программное обеспечение, интерфейсы, бренд и контент CGTBrowser принадлежат нам и охраняются законом. Вы не вправе копировать, распространять или изменять их без разрешения.', zh: 'CGTBrowser 的全部软件、界面、品牌及内容均归我们所有并受法律保护。未经许可，您不得复制、分发或修改。' },
  '5. Giới hạn trách nhiệm': { en: '5. Limitation of liability', ru: '5. Ограничение ответственности', zh: '5. 责任限制' },
  'Dịch vụ được cung cấp "nguyên trạng". Trong phạm vi pháp luật cho phép, chúng tôi không chịu trách nhiệm cho các thiệt hại gián tiếp phát sinh từ việc sử dụng hoặc không thể sử dụng dịch vụ.': { en: 'The service is provided "as is". To the extent permitted by law, we are not liable for any indirect damages arising from the use of, or inability to use, the service.', ru: 'Сервис предоставляется «как есть». В пределах, допускаемых законом, мы не несём ответственности за косвенный ущерб, возникший в результате использования или невозможности использования сервиса.', zh: '本服务按“现状”提供。在法律允许的范围内，对于因使用或无法使用本服务而产生的间接损失，我们概不负责。' },
  '6. Thay đổi & chấm dứt': { en: '6. Changes & termination', ru: '6. Изменения и прекращение', zh: '6. 变更与终止' },
  'Chúng tôi có thể cập nhật điều khoản hoặc tạm ngừng, chấm dứt dịch vụ vào từng thời điểm. Việc tiếp tục sử dụng sau khi thay đổi đồng nghĩa với việc bạn chấp nhận điều khoản mới.': { en: 'We may update these terms or suspend or terminate the service from time to time. Continuing to use it after changes means you accept the new terms.', ru: 'Мы можем время от времени обновлять условия либо приостанавливать или прекращать работу сервиса. Продолжение использования после изменений означает принятие новых условий.', zh: '我们可能会不时更新条款或暂停、终止服务。变更后继续使用即表示您接受新的条款。' },

  // Modal Chính sách bảo mật
  'Chính sách bảo mật': { en: 'Privacy Policy', ru: 'Политика конфиденциальности', zh: '隐私政策' },
  '1. Thông tin chúng tôi thu thập': { en: '1. Information we collect', ru: '1. Собираемая информация', zh: '1. 我们收集的信息' },
  'Thông tin bạn cung cấp khi đăng ký: địa chỉ email và mật khẩu (được lưu dưới dạng đã băm, chúng tôi không lưu mật khẩu gốc).': { en: 'Information you provide at registration: your email address and password (stored in hashed form; we do not store the original password).', ru: 'Информация, которую вы предоставляете при регистрации: адрес email и пароль (хранится в виде хеша; исходный пароль мы не храним).', zh: '您在注册时提供的信息：电子邮箱地址和密码（以哈希形式存储，我们不保存原始密码）。' },
  'Dữ liệu vận hành cần thiết để đồng bộ workspace: hồ sơ, nhóm, proxy, quy trình tự động hóa và nhật ký hoạt động.': { en: 'Operational data needed to sync your workspace: profiles, groups, proxies, automation workflows and activity logs.', ru: 'Операционные данные, необходимые для синхронизации рабочего пространства: профили, группы, прокси, процессы автоматизации и журналы активности.', zh: '同步工作空间所需的运行数据：配置文件、分组、代理、自动化流程及活动日志。' },
  '2. Mục đích sử dụng': { en: '2. How we use it', ru: '2. Цели использования', zh: '2. 使用目的' },
  'Xác thực đăng nhập, tạo và bảo vệ tài khoản của bạn.': { en: 'To authenticate sign-in and to create and protect your account.', ru: 'Аутентификация входа, создание и защита вашего аккаунта.', zh: '用于登录验证、创建和保护您的账户。' },
  'Cung cấp, đồng bộ và cải thiện các tính năng của CGTBrowser theo từng workspace.': { en: 'To provide, sync and improve CGTBrowser features for each workspace.', ru: 'Предоставление, синхронизация и улучшение функций CGTBrowser для каждого рабочего пространства.', zh: '按各工作空间提供、同步并改进 CGTBrowser 的功能。' },
  '3. Lưu trữ & bảo mật': { en: '3. Storage & security', ru: '3. Хранение и безопасность', zh: '3. 存储与安全' },
  'Mật khẩu được băm; thông tin nhạy cảm trên thiết bị (email, mật khẩu ghi nhớ) được mã hóa bằng cơ chế bảo mật của hệ điều hành.': { en: 'Passwords are hashed; sensitive data on your device (saved email and password) is encrypted using your operating system\'s security mechanisms.', ru: 'Пароли хешируются; конфиденциальные данные на устройстве (сохранённые email и пароль) шифруются средствами безопасности операционной системы.', zh: '密码经过哈希处理；设备上的敏感信息（记住的邮箱和密码）通过操作系统的安全机制加密。' },
  'Chúng tôi áp dụng các biện pháp hợp lý để bảo vệ dữ liệu khỏi truy cập trái phép.': { en: 'We apply reasonable measures to protect data from unauthorized access.', ru: 'Мы применяем разумные меры для защиты данных от несанкционированного доступа.', zh: '我们采取合理措施保护数据免遭未经授权的访问。' },
  '4. Chia sẻ với bên thứ ba': { en: '4. Sharing with third parties', ru: '4. Передача третьим лицам', zh: '4. 第三方共享' },
  'Chúng tôi không bán dữ liệu của bạn. Dữ liệu chỉ được chia sẻ khi bạn yêu cầu, khi cần cho vận hành dịch vụ (ví dụ máy chủ email OTP) hoặc khi pháp luật yêu cầu.': { en: 'We do not sell your data. Data is shared only at your request, when needed to operate the service (for example, the OTP email server), or when required by law.', ru: 'Мы не продаём ваши данные. Данные передаются только по вашему запросу, при необходимости для работы сервиса (например, почтовый сервер OTP) или по требованию закона.', zh: '我们不出售您的数据。仅在您请求时、为运营服务所必需时（例如 OTP 邮件服务器）或法律要求时才会共享数据。' },
  '5. Cookie & dữ liệu cục bộ': { en: '5. Cookies & local data', ru: '5. Cookie и локальные данные', zh: '5. Cookie 与本地数据' },
  'Ứng dụng lưu một số tùy chọn cục bộ (ngôn ngữ, ghi nhớ đăng nhập, phiên làm việc) trên thiết bị của bạn để duy trì trải nghiệm.': { en: 'The app stores some local preferences (language, saved login, session) on your device to maintain your experience.', ru: 'Приложение хранит некоторые локальные настройки (язык, сохранённый вход, сессию) на вашем устройстве для сохранения удобства работы.', zh: '应用会在您的设备上保存部分本地设置（语言、登录记忆、会话）以维持使用体验。' },
  '6. Quyền của bạn & liên hệ': { en: '6. Your rights & contact', ru: '6. Ваши права и контакты', zh: '6. 您的权利与联系方式' },
  'Bạn có thể yêu cầu truy cập, chỉnh sửa hoặc xóa dữ liệu cá nhân của mình trong phạm vi pháp luật cho phép.': { en: 'You may request to access, edit or delete your personal data to the extent permitted by law.', ru: 'Вы можете запросить доступ, изменение или удаление своих персональных данных в пределах, допускаемых законом.', zh: '在法律允许的范围内，您可以请求访问、修改或删除您的个人数据。' },
  'Mọi thắc mắc về quyền riêng tư, vui lòng liên hệ quản trị viên hệ thống.': { en: 'For any privacy questions, please contact your system administrator.', ru: 'По всем вопросам конфиденциальности обращайтесь к системному администратору.', zh: '如有任何隐私相关问题，请联系系统管理员。' },

  // ── App shell: CTA + plan card + header ───────────────────────────────────
  'Hồ sơ mới': { en: 'New Profile', ru: 'Новый профиль', zh: '新建配置文件' },
  'Tạo hồ sơ mới': { en: 'Create new profile', ru: 'Создать новый профиль', zh: '创建新配置文件' },
  'Tạo hàng loạt': { en: 'Bulk Create', ru: 'Массовое создание', zh: '批量创建' },
  'Số dư chính': { en: 'Main Balance', ru: 'Основной баланс', zh: '主余额' },
  'Số dư hồ sơ': { en: 'Profile Balance', ru: 'Баланс профилей', zh: '配置文件余额' },
  'Gói đang dùng': { en: 'Current Plan', ru: 'Текущий план', zh: '当前套餐' },
  'Hồ sơ hiện có': { en: 'Existing Profiles', ru: 'Текущие профили', zh: '现有配置文件' },
  // Dải mép trên thẻ gói (plan-deco) - MỘT text node duy nhất, click sang trang "Hoa hồng".
  // ⛔ ĐÃ XOÁ cùng lượt đổi tên dải (2026-10-19): 'Nhận ưu đãi lớn' + 'xem ngay'. Câu cũ
  // "Nhận ưu đãi lớn xem ngay" bị xé thành 2 text node nên phải là 2 khoá; câu mới gọn một
  // cụm. Hai khoá đó KHÔNG còn chỗ nào dùng (đã grep cả src/) nên để lại là khoá chết.
  'Nhận hoa hồng': { en: 'Get commission', ru: 'Получить комиссию', zh: '领取佣金' },
  'Số dư': { en: 'Balance', ru: 'Баланс', zh: '余额' },
  'Làm mới': { en: 'Refresh', ru: 'Обновить', zh: '刷新' },
  'Đổi giao diện': { en: 'Toggle theme', ru: 'Сменить тему', zh: '切换主题' },
  'Thông báo': { en: 'Notifications', ru: 'Уведомления', zh: '通知' },
  'Nạp tiền': { en: 'Top up', ru: 'Пополнить', zh: '充值' },
  'Tài khoản': { en: 'Account', ru: 'Аккаунт', zh: '账户' },

  // ── App shell: account menu ───────────────────────────────────────────────
  'Hoa Hồng': { en: 'Commission', ru: 'Комиссия', zh: '佣金' },
  'Ngôn ngữ': { en: 'Language', ru: 'Язык', zh: '语言' },
  'Chủ đề': { en: 'Theme', ru: 'Тема', zh: '主题' },
  'Sáng': { en: 'Light', ru: 'Светлая', zh: '浅色' },
  'Tối': { en: 'Dark', ru: 'Тёмная', zh: '深色' },
  'Độ tương phản': { en: 'Contrast', ru: 'Контраст', zh: '对比度' },
  'Tiêu chuẩn': { en: 'Standard', ru: 'Стандартный', zh: '标准' },
  'Chẩn đoán mạng': { en: 'Network Diagnostics', ru: 'Диагностика сети', zh: '网络诊断' },
  'Đăng xuất': { en: 'Log out', ru: 'Выйти', zh: '退出登录' },
  // ⛔ ĐÃ XOÁ (2026-10-19): 'Chương trình hoa hồng sắp ra mắt' - toast tạm khi mục "Hoa Hồng"
  // trong menu tài khoản chưa có trang. Nay mục đó navigate('affiliate') nên toast không còn
  // được gọi ở đâu. Đừng thêm lại khoá mà không có chỗ dùng.
  'Chẩn đoán mạng đang được phát triển': { en: 'Network diagnostics under development', ru: 'Диагностика сети в разработке', zh: '网络诊断功能开发中' },

  // ── Route titles not covered by nav ───────────────────────────────────────
  'Tạo hồ sơ': { en: 'Create Profile', ru: 'Создать профиль', zh: '创建配置文件' },
  'Chỉnh sửa nhiệm vụ': { en: 'Edit Task', ru: 'Редактировать задачу', zh: '编辑任务' },
  'Giới thiệu': { en: 'About', ru: 'О программе', zh: '关于' },

  // ── Settings page: section headings ───────────────────────────────────────
  'Chung': { en: 'General', ru: 'Общие', zh: '常规' },
  'Giao diện': { en: 'Appearance', ru: 'Внешний вид', zh: '外观' },
  'Trình duyệt & hồ sơ': { en: 'Browser & Profiles', ru: 'Браузер и профили', zh: '浏览器与配置文件' },
  'Lưu trữ & dữ liệu': { en: 'Storage & Data', ru: 'Хранилище и данные', zh: '存储与数据' },
  'Cập nhật': { en: 'Updates', ru: 'Обновления', zh: '更新' },

  // ── Settings page: rows (titles + subtitles) ──────────────────────────────
  'Đường dẫn trình duyệt': { en: 'Browser Path', ru: 'Путь к браузеру', zh: '浏览器路径' },
  'Chrome/Chromium dùng để mở hồ sơ': { en: 'Chrome/Chromium used to open profiles', ru: 'Chrome/Chromium для открытия профилей', zh: '用于打开配置文件的 Chrome/Chromium' },
  'Múi giờ': { en: 'Timezone', ru: 'Часовой пояс', zh: '时区' },
  'Dùng khi lên lịch tự động hóa': { en: 'Used when scheduling automation', ru: 'Используется при планировании автоматизации', zh: '用于自动化计划' },
  'Chế độ sáng hoặc tối': { en: 'Light or dark mode', ru: 'Светлый или тёмный режим', zh: '浅色或深色模式' },
  'Thu gọn thanh bên khi khởi động': { en: 'Collapse sidebar on startup', ru: 'Сворачивать боковую панель при запуске', zh: '启动时折叠侧边栏' },
  'Mở ứng dụng với thanh điều hướng thu gọn': { en: 'Open the app with the navigation bar collapsed', ru: 'Открывать приложение со свёрнутой панелью навигации', zh: '以折叠导航栏方式打开应用' },
  'Tự đóng hồ sơ khi thoát': { en: 'Auto-close profiles on exit', ru: 'Автоматически закрывать профили при выходе', zh: '退出时自动关闭配置文件' },
  'Tắt mọi cửa sổ Chrome khi đóng ứng dụng': { en: 'Close all Chrome windows when quitting the app', ru: 'Закрывать все окна Chrome при выходе из приложения', zh: '退出应用时关闭所有 Chrome 窗口' },
  'Xác nhận trước khi xóa hồ sơ': { en: 'Confirm before deleting a profile', ru: 'Подтверждать перед удалением профиля', zh: '删除配置文件前确认' },
  'Hiển thị hộp thoại xác nhận khi xóa': { en: 'Show a confirmation dialog when deleting', ru: 'Показывать диалог подтверждения при удалении', zh: '删除时显示确认对话框' },
  'Mở hồ sơ ở chế độ ẩn danh': { en: 'Open profiles in incognito mode', ru: 'Открывать профили в режиме инкогнито', zh: '以隐身模式打开配置文件' },
  'Không lưu lịch sử giữa các phiên': { en: "Don't save history between sessions", ru: 'Не сохранять историю между сеансами', zh: '不在会话之间保存历史记录' },
  'Thư mục dữ liệu hồ sơ': { en: 'Profile Data Folder', ru: 'Папка данных профилей', zh: '配置文件数据目录' },
  'Nơi lưu user-data-dir của từng hồ sơ': { en: "Where each profile's user-data-dir is stored", ru: 'Где хранится user-data-dir каждого профиля', zh: '每个配置文件的 user-data-dir 存储位置' },
  'Mở thư mục': { en: 'Open Folder', ru: 'Открыть папку', zh: '打开目录' },
  'Xóa cache': { en: 'Clear Cache', ru: 'Очистить кэш', zh: '清除缓存' },
  'Ảnh chụp màn hình, cache trình duyệt và tệp tạm': { en: 'Screenshots, browser cache and temporary files', ru: 'Скриншоты, кэш браузера и временные файлы', zh: '截图、浏览器缓存和临时文件' },
  'Kênh cập nhật': { en: 'Update Channel', ru: 'Канал обновлений', zh: '更新渠道' },
  'Bản ổn định, beta hoặc nightly': { en: 'Stable, beta or nightly build', ru: 'Стабильная, бета или nightly сборка', zh: '稳定版、Beta 或 Nightly' },
  'Tự động cập nhật nhân trình duyệt': { en: 'Auto-update browser core', ru: 'Автоматически обновлять ядро браузера', zh: '自动更新浏览器内核' },
  'Tải bản Chromium mới ở chế độ nền': { en: 'Download new Chromium in the background', ru: 'Загружать новую версию Chromium в фоне', zh: '后台下载新版 Chromium' },

  // ── Settings page: controls, buttons, header, toasts, placeholder ─────────
  'Ổn định (Stable)': { en: 'Stable', ru: 'Стабильная (Stable)', zh: '稳定版 (Stable)' },
  'Chọn…': { en: 'Choose…', ru: 'Выбрать…', zh: '选择…' },
  'Lưu thay đổi': { en: 'Save Changes', ru: 'Сохранить изменения', zh: '保存更改' },
  'Tùy chỉnh chung, giao diện, trình duyệt và lưu trữ': { en: 'Customize general, appearance, browser and storage', ru: 'Настройка общих параметров, внешнего вида, браузера и хранилища', zh: '自定义常规、外观、浏览器与存储' },
  'Đã lưu cài đặt': { en: 'Settings saved', ru: 'Настройки сохранены', zh: '设置已保存' },
  'Tự động dò tìm (Chrome / Edge)': { en: 'Auto-detect (Chrome / Edge)', ru: 'Автоопределение (Chrome / Edge)', zh: '自动检测 (Chrome / Edge)' },

  // ── Common cross-view terms (full-node matches only, so safe) ─────────────
  'Lưu': { en: 'Save', ru: 'Сохранить', zh: '保存' },
  'Hủy': { en: 'Cancel', ru: 'Отмена', zh: '取消' },
  'Huỷ': { en: 'Cancel', ru: 'Отмена', zh: '取消' },
  'Xóa': { en: 'Delete', ru: 'Удалить', zh: '删除' },
  'Xoá': { en: 'Delete', ru: 'Удалить', zh: '删除' },
  'Thêm': { en: 'Add', ru: 'Добавить', zh: '添加' },
  'Đóng': { en: 'Close', ru: 'Закрыть', zh: '关闭' },
  'Mở': { en: 'Open', ru: 'Открыть', zh: '打开' },
  'Đồng ý': { en: 'OK', ru: 'ОК', zh: '确定' },
  'Xác nhận': { en: 'Confirm', ru: 'Подтвердить', zh: '确认' },
  'Chỉnh sửa': { en: 'Edit', ru: 'Редактировать', zh: '编辑' },
  'Sao chép': { en: 'Copy', ru: 'Копировать', zh: '复制' },
  'Nhân bản': { en: 'Duplicate', ru: 'Дублировать', zh: '复制副本' },
  'Di chuyển': { en: 'Move', ru: 'Переместить', zh: '移动' },
  'Đổi tên': { en: 'Rename', ru: 'Переименовать', zh: '重命名' },
  'Tất cả': { en: 'All', ru: 'Все', zh: '全部' },
  'Trạng thái': { en: 'Status', ru: 'Статус', zh: '状态' },
  'Tên': { en: 'Name', ru: 'Имя', zh: '名称' },
  'Ghi chú': { en: 'Note', ru: 'Заметка', zh: '备注' },
  'Thao tác': { en: 'Actions', ru: 'Действия', zh: '操作' },
  'Mở hồ sơ': { en: 'Open profile', ru: 'Открыть профиль', zh: '打开配置文件' },
  'Đóng hồ sơ': { en: 'Close profile', ru: 'Закрыть профиль', zh: '关闭配置文件' },
  'Tìm kiếm': { en: 'Search', ru: 'Поиск', zh: '搜索' },

  // ── Profiles view: toolbar, grid, dialogs, toasts ─────────────────────────
  'Làm mới danh sách hồ sơ': { en: 'Refresh profile list', ru: 'Обновить список профилей', zh: '刷新配置文件列表' },
  'Tên hồ sơ': { en: 'Profile Name', ru: 'Имя профиля', zh: '配置文件名称' },
  'Hồ sơ trình duyệt mới': { en: 'New browser profile', ru: 'Новый профиль браузера', zh: '新建浏览器配置文件' },
  'Sao chép ID': { en: 'Copy ID', ru: 'Копировать ID', zh: '复制 ID' },
  'Sao chép tên': { en: 'Copy name', ru: 'Копировать имя', zh: '复制名称' },
  'Sao chép ghi chú': { en: 'Copy note', ru: 'Копировать заметку', zh: '复制备注' },
  // Menu "Thêm" (ba chấm) ở thanh thao tác hàng loạt VÀ menu ba chấm của từng hàng: chọn bộ
  // tiện ích RIÊNG cho hồ sơ. Mở từ menu hàng thì modal gọi thẳng tên hồ sơ (mẫu {0}).
  'Chỉnh sửa tiện ích': { en: 'Edit extensions', ru: 'Редактировать расширения', zh: '编辑扩展' },
  'Chọn tiện ích áp dụng cho': { en: 'Choose extensions to apply to', ru: 'Выберите расширения для', zh: '选择要应用的扩展，共' },
  'Chọn tiện ích cho hồ sơ "{0}"': { en: 'Choose extensions for the profile "{0}"', ru: 'Выберите расширения для профиля «{0}»', zh: '为配置文件“{0}”选择扩展' },
  'Đã đặt tiện ích cho': { en: 'Extensions set for', ru: 'Расширения заданы для', zh: '已设置扩展：' },
  'Đang áp dụng tiện ích…': { en: 'Applying extensions…', ru: 'Применение расширений…', zh: '正在应用扩展…' },
  'Chưa có tiện ích nào trong kho. Hãy vào trang Tiện ích để tải lên trước.': { en: 'There are no extensions yet. Go to the Extensions page to upload one first.', ru: 'Расширений пока нет. Сначала загрузите их на странице «Расширения».', zh: '尚无任何扩展。请先前往"扩展"页面上传。' },
  'Chỉ các tiện ích đang bật mới nạp cho những hồ sơ này. Hồ sơ khác và kho tiện ích chung không bị ảnh hưởng.': { en: 'Only the extensions switched on load for these profiles. Other profiles and the shared extension library are unaffected.', ru: 'Для этих профилей загружаются только включённые расширения. Другие профили и общая библиотека расширений не затрагиваются.', zh: '仅已开启的扩展会为这些配置文件加载。其他配置文件和共享扩展库不受影响。' },
  'Nhập ghi chú…': { en: 'Enter a note…', ru: 'Введите заметку…', zh: '输入备注…' },
  'Cập nhật ghi chú': { en: 'Update note', ru: 'Обновить заметку', zh: '更新备注' },
  'Xóa ghi chú': { en: 'Delete note', ru: 'Удалить заметку', zh: '删除备注' },
  'Nhân bản hồ sơ': { en: 'Duplicate profile', ru: 'Дублировать профиль', zh: '复制配置文件' },
  'Chuyển nhóm hồ sơ': { en: 'Move profile group', ru: 'Переместить группу профиля', zh: '移动配置文件分组' },
  'Chuyển nhóm': { en: 'Move to group', ru: 'Переместить в группу', zh: '移动到分组' },
  'Chuyển hồ sơ': { en: 'Move profile', ru: 'Переместить профиль', zh: '移动配置文件' },
  'Xóa hồ sơ': { en: 'Delete profile', ru: 'Удалить профиль', zh: '删除配置文件' },
  'Khôi phục hồ sơ': { en: 'Restore profile', ru: 'Восстановить профиль', zh: '恢复配置文件' },
  'Chia sẻ hồ sơ': { en: 'Share profile', ru: 'Поделиться профилем', zh: '共享配置文件' },
  'Gia hạn hồ sơ': { en: 'Renew profile', ru: 'Продлить профиль', zh: '续期配置文件' },
  'Đổi tên hàng loạt': { en: 'Bulk rename', ru: 'Массовое переименование', zh: '批量重命名' },
  'Cập nhật hồ sơ': { en: 'Update profile', ru: 'Обновить профиль', zh: '更新配置文件' },
  'Kiểm tra Proxy': { en: 'Check Proxy', ru: 'Проверить прокси', zh: '检测代理' },
  'Kiểm tra proxy': { en: 'Check proxy', ru: 'Проверить прокси', zh: '检测代理' },
  'Xóa proxy ra khỏi hồ sơ': { en: 'Remove proxy from profile', ru: 'Убрать прокси из профиля', zh: '从配置文件移除代理' },
  'Vị trí IP': { en: 'IP Location', ru: 'Местоположение IP', zh: 'IP 位置' },
  'Xuất IP': { en: 'Export IP', ru: 'Экспорт IP', zh: '导出 IP' },
  'Hệ điều hành': { en: 'Operating System', ru: 'Операционная система', zh: '操作系统' },
  'Ngày tạo': { en: 'Created Date', ru: 'Дата создания', zh: '创建日期' },
  'Cập nhật cuối': { en: 'Last Updated', ru: 'Последнее обновление', zh: '最后更新' },
  'Chạy lần cuối': { en: 'Last Run', ru: 'Последний запуск', zh: '最近运行' },
  'ID hồ sơ': { en: 'Profile ID', ru: 'ID профиля', zh: '配置文件 ID' },
  'Đã tạo hồ sơ': { en: 'Profile created', ru: 'Профиль создан', zh: '配置文件已创建' },
  'Đã lưu hồ sơ': { en: 'Profile saved', ru: 'Профиль сохранён', zh: '配置文件已保存' },
  'Đã nhân bản': { en: 'Duplicated', ru: 'Продублировано', zh: '已复制' },
  'Đã chuyển vào thùng rác': { en: 'Moved to trash', ru: 'Перемещено в корзину', zh: '已移入回收站' },
  'Đã khôi phục': { en: 'Restored', ru: 'Восстановлено', zh: '已恢复' },
  'Đã xóa vĩnh viễn': { en: 'Permanently deleted', ru: 'Удалено навсегда', zh: '已永久删除' },
  'Chưa chọn hồ sơ nào': { en: 'No profile selected', ru: 'Профиль не выбран', zh: '未选择配置文件' },
  'Không có hồ sơ': { en: 'No profiles', ru: 'Нет профилей', zh: '暂无配置文件' },
  'Không có hồ sơ nào đang mở!': { en: 'No profiles are open!', ru: 'Нет открытых профилей!', zh: '没有已打开的配置文件！' },
  'Không mở được trình duyệt': { en: 'Could not open the browser', ru: 'Не удалось открыть браузер', zh: '无法打开浏览器' },
  'Số hồ sơ': { en: 'Number of Profiles', ru: 'Количество профилей', zh: '配置文件数量' },
  'Hồ sơ áp dụng': { en: 'Applied Profiles', ru: 'Применённые профили', zh: '应用的配置文件' },
  'Hồ sơ được gắn': { en: 'Attached Profiles', ru: 'Привязанные профили', zh: '关联的配置文件' },
  'Đang mở': { en: 'Opening', ru: 'Открытие', zh: '打开中' },
  'Đang bật': { en: 'On', ru: 'Включено', zh: '已开启' },
  'Đang tắt': { en: 'Off', ru: 'Выключено', zh: '已关闭' },

  // ── Common statuses / verbs / small labels ────────────────────────────────
  'Sẵn sàng': { en: 'Ready', ru: 'Готово', zh: '就绪' },
  'Hoàn tất': { en: 'Completed', ru: 'Завершено', zh: '已完成' },
  'Hoàn Thành': { en: 'Complete', ru: 'Завершено', zh: '完成' },
  'Thất bại': { en: 'Failed', ru: 'Ошибка', zh: '失败' },
  'Đã dừng': { en: 'Stopped', ru: 'Остановлено', zh: '已停止' },
  'Gián đoạn': { en: 'Interrupted', ru: 'Прервано', zh: '已中断' },
  'Bắt đầu': { en: 'Start', ru: 'Начать', zh: '开始' },
  'Bắt đầu dùng': { en: 'Get started', ru: 'Начать', zh: '开始使用' },
  'Sắp ra mắt': { en: 'Coming soon', ru: 'Скоро', zh: '即将推出' },
  'Tính năng đang phát triển': { en: 'Feature under development', ru: 'Функция в разработке', zh: '功能开发中' },
  'Lưu lại': { en: 'Save', ru: 'Сохранить', zh: '保存' },
  'Tạo mới': { en: 'Create new', ru: 'Создать', zh: '新建' },
  'Tạo': { en: 'Create', ru: 'Создать', zh: '创建' },
  'Nhập': { en: 'Import', ru: 'Импорт', zh: '导入' },
  'Xuất': { en: 'Export', ru: 'Экспорт', zh: '导出' },
  'Tải lên': { en: 'Upload', ru: 'Загрузить', zh: '上传' },
  'Tải xuống': { en: 'Download', ru: 'Скачать', zh: '下载' },
  'Bỏ qua': { en: 'Skip', ru: 'Пропустить', zh: '跳过' },
  'Bỏ': { en: 'Remove', ru: 'Убрать', zh: '移除' },
  'Loại bỏ': { en: 'Remove', ru: 'Удалить', zh: '移除' },
  'Chọn lại': { en: 'Reselect', ru: 'Выбрать заново', zh: '重新选择' },
  'Chọn tệp': { en: 'Choose file', ru: 'Выбрать файл', zh: '选择文件' },
  'Chọn thư mục': { en: 'Choose folder', ru: 'Выбрать папку', zh: '选择目录' },
  'Chọn nhóm': { en: 'Choose group', ru: 'Выбрать группу', zh: '选择分组' },
  'Chọn tùy chọn': { en: 'Choose an option', ru: 'Выберите вариант', zh: '选择选项' },
  'Chọn giờ': { en: 'Choose time', ru: 'Выбрать время', zh: '选择时间' },
  'Chọn thời gian': { en: 'Choose time', ru: 'Выбрать время', zh: '选择时间' },
  'Chọn hồ sơ để chạy': { en: 'Choose a profile to run', ru: 'Выберите профиль для запуска', zh: '选择要运行的配置文件' },
  'Khởi động lại': { en: 'Restart', ru: 'Перезапустить', zh: '重启' },
  'Đã hiểu': { en: 'Got it', ru: 'Понятно', zh: '知道了' },
  'Chú ý:': { en: 'Note:', ru: 'Внимание:', zh: '注意：' },
  'Ví dụ:': { en: 'Example:', ru: 'Пример:', zh: '示例：' },
  'Thông tin': { en: 'Info', ru: 'Информация', zh: '信息' },
  'Tổng quan': { en: 'Overview', ru: 'Обзор', zh: '概览' },
  'Nâng cao': { en: 'Advanced', ru: 'Дополнительно', zh: '高级' },
  'Tùy chọn': { en: 'Options', ru: 'Параметры', zh: '选项' },
  'Tùy chỉnh': { en: 'Custom', ru: 'Пользовательский', zh: '自定义' },
  'Mặc định': { en: 'Default', ru: 'По умолчанию', zh: '默认' },
  'Nhóm mới': { en: 'New Group', ru: 'Новая группа', zh: '新建分组' },
  'Chưa chia nhóm': { en: 'Ungrouped', ru: 'Без группы', zh: '未分组' },
  'Tất cả nhóm': { en: 'All groups', ru: 'Все группы', zh: '全部分组' },
  'Tất cả các nhóm': { en: 'All groups', ru: 'Все группы', zh: '所有分组' },
  'Nhóm đã chọn': { en: 'Selected group', ru: 'Выбранная группа', zh: '已选分组' },
  'Nhóm đích': { en: 'Target group', ru: 'Целевая группа', zh: '目标分组' },
  'Nhóm công khai': { en: 'Public group', ru: 'Публичная группа', zh: '公开分组' },
  'Đã tạo nhóm': { en: 'Group created', ru: 'Группа создана', zh: '分组已创建' },
  'Đã thêm nhóm': { en: 'Group added', ru: 'Группа добавлена', zh: '已添加分组' },
  'Không có nhóm': { en: 'No groups', ru: 'Нет групп', zh: '暂无分组' },
  'Không có kết quả': { en: 'No results', ru: 'Нет результатов', zh: '无结果' },
  'Không có dữ liệu': { en: 'No data', ru: 'Нет данных', zh: '暂无数据' },
  'Không có lựa chọn': { en: 'No options', ru: 'Нет вариантов', zh: '无可选项' },
  'Không tồn tại': { en: 'Does not exist', ru: 'Не существует', zh: '不存在' },
  'Tồn tại': { en: 'Exists', ru: 'Существует', zh: '存在' },
  'Trống': { en: 'Empty', ru: 'Пусто', zh: '空' },

  // ── Proxies view ──────────────────────────────────────────────────────────
  'Thêm proxy': { en: 'Add Proxy', ru: 'Добавить прокси', zh: '添加代理' },
  'Thêm Proxy': { en: 'Add Proxy', ru: 'Добавить прокси', zh: '添加代理' },
  'Thêm proxy thành công': { en: 'Proxy added successfully', ru: 'Прокси успешно добавлен', zh: '代理添加成功' },
  'Loại proxy': { en: 'Proxy Type', ru: 'Тип прокси', zh: '代理类型' },
  'Sao chép proxy': { en: 'Copy proxy', ru: 'Копировать прокси', zh: '复制代理' },
  'Xóa proxy': { en: 'Delete proxy', ru: 'Удалить прокси', zh: '删除代理' },
  'Xóa proxy đã chọn': { en: 'Delete selected proxies', ru: 'Удалить выбранные прокси', zh: '删除所选代理' },
  'Cập nhật proxy': { en: 'Update proxy', ru: 'Обновить прокси', zh: '更新代理' },
  'Reset proxy': { en: 'Reset proxy', ru: 'Сбросить прокси', zh: '重置代理' },
  'Reset': { en: 'Reset', ru: 'Сбросить', zh: '重置' },
  'Đã xóa proxy': { en: 'Proxy deleted', ru: 'Прокси удалён', zh: '代理已删除' },
  'Chưa chọn proxy để xóa': { en: 'No proxy selected to delete', ru: 'Не выбран прокси для удаления', zh: '未选择要删除的代理' },
  'Chưa có proxy để kiểm tra': { en: 'No proxy to check', ru: 'Нет прокси для проверки', zh: '没有可检测的代理' },
  'Kiểm tra proxy trước khi thêm': { en: 'Check proxy before adding', ru: 'Проверить прокси перед добавлением', zh: '添加前检测代理' },
  'Không dùng proxy': { en: 'No proxy', ru: 'Без прокси', zh: '不使用代理' },
  // Mục "Dùng proxy" trong dropdown Reset proxy - bật lại proxy đã giữ ở hồ sơ.
  'Dùng proxy': { en: 'Use proxy', ru: 'Использовать прокси', zh: '使用代理' },
  'Bạn có chắc chắn muốn dùng lại proxy cho': { en: 'Are you sure you want to use the proxy again for', ru: 'Вы уверены, что хотите снова использовать прокси для', zh: '确定要为以下项重新启用代理吗' },
  'Các hồ sơ sẽ dùng lại proxy đã lưu (host, cổng, tài khoản, mật khẩu). Hãy chọn đúng loại proxy để kết nối hoạt động.': { en: 'The profiles will reuse the saved proxy (host, port, username, password). Choose the correct proxy type so the connection works.', ru: 'Профили снова будут использовать сохранённый прокси (хост, порт, логин, пароль). Выберите правильный тип прокси, чтобы соединение работало.', zh: '这些配置文件将重新使用已保存的代理（主机、端口、账号、密码）。请选择正确的代理类型以确保连接可用。' },
  'hồ sơ không còn thông tin proxy nên sẽ được bỏ qua': { en: 'profiles no longer have proxy details and will be skipped', ru: 'профилей больше не содержат данных прокси и будут пропущены', zh: '个配置文件已无代理信息，将被跳过' },
  'Các hồ sơ đã chọn không còn thông tin proxy để bật lại': { en: 'The selected profiles no longer have proxy details to re-enable', ru: 'У выбранных профилей больше нет данных прокси для повторного включения', zh: '所选配置文件已无可重新启用的代理信息' },
  'Các hồ sơ đã chọn đang dùng proxy': { en: 'The selected profiles are already using a proxy', ru: 'Выбранные профили уже используют прокси', zh: '所选配置文件已在使用代理' },
  'Đã bật lại proxy': { en: 'Proxy re-enabled', ru: 'Прокси снова включён', zh: '已重新启用代理' },
  'Bật lại proxy thất bại': { en: 'Failed to re-enable proxy', ru: 'Не удалось снова включить прокси', zh: '重新启用代理失败' },
  // Hai nút "Web RTC" / "Trình duyệt" trên thanh chọn hồ sơ: sửa MỘT thiết lập trong vân
  // tay cho nhiều hồ sơ, giữ nguyên phần vân tay còn lại. ("Web RTC" là tên riêng của
  // công nghệ nên KHÔNG dịch - bản đồ dưới chỉ để chuẩn hoá chữ hoa ở từng ngôn ngữ.)
  'Web RTC': { en: 'Web RTC', ru: 'Web RTC', zh: 'Web RTC' },
  'Áp dụng': { en: 'Apply', ru: 'Применить', zh: '应用' },
  'Áp dụng chế độ WebRTC cho': { en: 'Apply the WebRTC mode to', ru: 'Применить режим WebRTC к', zh: '将 WebRTC 模式应用于' },
  'Chỉ thiết lập WebRTC được thay đổi. Toàn bộ phần còn lại của dấu vân tay được giữ nguyên.': { en: 'Only the WebRTC setting changes. Everything else in the fingerprint is kept as is.', ru: 'Изменяется только настройка WebRTC. Всё остальное в отпечатке остаётся без изменений.', zh: '仅修改 WebRTC 设置。指纹的其余部分保持不变。' },
  'Đang áp dụng thiết lập WebRTC…': { en: 'Applying the WebRTC setting…', ru: 'Применение настройки WebRTC…', zh: '正在应用 WebRTC 设置…' },
  'Đã đặt WebRTC cho': { en: 'WebRTC set for', ru: 'WebRTC задан для', zh: '已为以下项设置 WebRTC' },
  'Áp dụng trình duyệt cho': { en: 'Apply the browser to', ru: 'Применить браузер к', zh: '将浏览器应用于' },
  'Phiên bản trình duyệt': { en: 'Browser version', ru: 'Версия браузера', zh: '浏览器版本' },
  'Đang tải danh sách nhân…': { en: 'Loading the kernel list…', ru: 'Загрузка списка ядер…', zh: '正在加载内核列表…' },
  'Chưa cài nhân nào cho trình duyệt này. Hãy tải nhân ở trang Nhân trình duyệt trước.': { en: 'No kernel is installed for this browser yet. Please download one on the Browser kernels page first.', ru: 'Для этого браузера ещё не установлено ни одного ядра. Сначала скачайте ядро на странице «Ядра браузера».', zh: '尚未为此浏览器安装内核。请先在“浏览器内核”页面下载。' },
  'Chỉ những mục bạn chọn ở hộp thoại này được thay đổi. Phần còn lại của dấu vân tay được giữ nguyên.': { en: 'Only what you pick in this dialog changes. The rest of the fingerprint is kept as is.', ru: 'Изменяется только то, что вы выбрали в этом окне. Остальная часть отпечатка остаётся без изменений.', zh: '仅修改你在此对话框中选择的项目。指纹的其余部分保持不变。' },
  // Ô "User-Agent" của modal "Trình duyệt" hàng loạt: "Không đổi" = không chạm UA của hồ sơ,
  // "Theo phiên bản nhân" = dựng UA theo full-version thật của nhân đang chọn.
  'Không đổi': { en: 'Unchanged', ru: 'Без изменений', zh: '不更改' },
  'Theo phiên bản nhân': { en: 'Match the kernel version', ru: 'По версии ядра', zh: '跟随内核版本' },
  'Giữ nguyên User-Agent hiện có của từng hồ sơ.': { en: 'Each profile keeps its current User-Agent.', ru: 'Каждый профиль сохраняет свой текущий User-Agent.', zh: '每个配置文件都保留其当前的 User-Agent。' },
  'Xem trước theo hồ sơ đầu tiên. Mỗi hồ sơ tự dựng User-Agent theo hệ điều hành của nó.': { en: 'Preview for the first profile. Each profile builds its own User-Agent from its own operating system.', ru: 'Предпросмотр для первого профиля. Каждый профиль формирует свой User-Agent по своей операционной системе.', zh: '这是第一个配置文件的预览。每个配置文件都会根据自身的操作系统生成 User-Agent。' },
  'Đang áp dụng thiết lập trình duyệt…': { en: 'Applying the browser setting…', ru: 'Применение настройки браузера…', zh: '正在应用浏览器设置…' },
  'Đã đặt trình duyệt cho': { en: 'Browser set for', ru: 'Браузер задан для', zh: '已为以下项设置浏览器' },

  // ── Menu "Thêm" → "Tạo shortcut cho hồ sơ" (lối tắt .lnk mở thẳng một hồ sơ) ──
  // Nhãn trong menu giữ đúng chữ người dùng đặt (tiếng Việt lẫn "shortcut"); bản dịch thì
  // dùng thuật ngữ đúng của từng hệ: Windows tiếng Anh gọi là "shortcut", tiếng Nga
  // "ярлык", tiếng Trung "快捷方式".
  'Tạo shortcut cho hồ sơ': { en: 'Create profile shortcut', ru: 'Создать ярлык профиля', zh: '创建配置文件快捷方式' },
  'Tạo lối tắt hồ sơ': { en: 'Create profile shortcut', ru: 'Создание ярлыка профиля', zh: '创建配置文件快捷方式' },
  'Tạo lối tắt trên máy cho': { en: 'Create desktop shortcuts for', ru: 'Создать ярлыки на компьютере для', zh: '为以下项创建本机快捷方式' },
  'Vị trí lưu': { en: 'Save location', ru: 'Место сохранения', zh: '保存位置' },
  'Đang lấy màn hình nền…': { en: 'Reading the desktop path…', ru: 'Получение пути к рабочему столу…', zh: '正在获取桌面路径…' },
  'Hãy chọn thư mục lưu': { en: 'Please pick a folder', ru: 'Выберите папку для сохранения', zh: '请选择保存文件夹' },
  'Chọn thư mục lưu lối tắt': { en: 'Pick the folder for the shortcuts', ru: 'Выберите папку для ярлыков', zh: '选择存放快捷方式的文件夹' },
  'Tên lối tắt': { en: 'Shortcut name', ru: 'Имя ярлыка', zh: '快捷方式名称' },
  // Ba token {name}/{index}/{id} là CÚ PHÁP - giữ nguyên trong mọi bản dịch.
  'Dùng được {name}, {index}, {id}': { en: 'You can use {name}, {index}, {id}', ru: 'Можно использовать {name}, {index}, {id}', zh: '可使用 {name}、{index}、{id}' },
  'Tạo lối tắt': { en: 'Create shortcuts', ru: 'Создать ярлыки', zh: '创建快捷方式' },
  'Đang tạo lối tắt…': { en: 'Creating the shortcuts…', ru: 'Создание ярлыков…', zh: '正在创建快捷方式…' },
  'Không tạo được lối tắt': { en: 'Could not create the shortcuts', ru: 'Не удалось создать ярлыки', zh: '无法创建快捷方式' },
  'Tạo nhiều lối tắt thì tên phải chứa {name}, {index} hoặc {id}': { en: 'To create several shortcuts the name must contain {name}, {index} or {id}', ru: 'Чтобы создать несколько ярлыков, имя должно содержать {name}, {index} или {id}', zh: '要创建多个快捷方式，名称必须包含 {name}、{index} 或 {id}' },
  'Đã tạo lối tắt cho': { en: 'Created shortcuts for', ru: 'Ярлыки созданы для', zh: '已为以下项创建快捷方式' },
  'Không tìm thấy hồ sơ của lối tắt (đã xóa, hoặc thuộc workspace khác)': { en: "The shortcut's profile was not found (deleted, or it belongs to another workspace)", ru: 'Профиль этого ярлыка не найден (удалён или принадлежит другому рабочему пространству)', zh: '未找到该快捷方式对应的配置文件（已删除，或属于其他工作区）' },

  // "Ghim đầu trang" / "Bỏ ghim đầu trang" / "Đã ghim lên đầu trang" / "Đã bỏ ghim" /
  // "Đã ghim" ĐÃ CÓ SẴN ở dưới (trang Nhóm + trang Tự động hóa ghim y hệt) - hồ sơ dùng
  // lại đúng những khoá đó, KHÔNG thêm bản trùng.

  'Không sử dụng': { en: 'Not used', ru: 'Не используется', zh: '不使用' },
  'Không Sử Dụng Proxy': { en: 'No Proxy', ru: 'Без прокси', zh: '不使用代理' },
  'Đã ngừng dùng proxy': { en: 'Proxy disabled', ru: 'Прокси отключён', zh: '已停用代理' },
  'Lỗi Proxy': { en: 'Proxy Error', ru: 'Ошибка прокси', zh: '代理错误' },
  'Liên kết thay đổi IP': { en: 'IP change link', ru: 'Ссылка смены IP', zh: 'IP 更换链接' },
  'Sử dụng IP thực của thiết bị hiện tại': { en: "Use the current device's real IP", ru: 'Использовать реальный IP текущего устройства', zh: '使用当前设备的真实 IP' },
  'Chặn đọc tham số WebRTC': { en: 'Block reading of WebRTC parameters', ru: 'Блокировать чтение параметров WebRTC', zh: '阻止读取 WebRTC 参数' },
  'Sử dụng IP WebRTC trùng khớp với proxy của bạn': { en: 'Use a WebRTC IP that matches your proxy', ru: 'Использовать IP WebRTC, совпадающий с вашим прокси', zh: '使用与您的代理匹配的 WebRTC IP' },
  // Nhãn + chú thích của lựa chọn WebRTC thứ 4 (mode proxy_only). "UDP" giữ nguyên ở mọi
  // ngôn ngữ vì là tên giao thức; tiếng Nga dùng "через прокси" (через + вин. cách).
  'UDP qua proxy': { en: 'UDP through proxy', ru: 'UDP через прокси', zh: 'UDP 经由代理' },
  'Ép mọi kết nối ICE đi qua proxy, chặn hoàn toàn UDP trực tiếp': { en: 'Force all ICE connections through the proxy, fully blocking direct UDP', ru: 'Направлять все ICE-соединения через прокси, полностью блокируя прямой UDP', zh: '强制所有 ICE 连接经由代理，完全阻止直连 UDP' },
  'Chế độ chèn proxy': { en: 'Proxy insertion mode', ru: 'Режим вставки прокси', zh: '代理插入模式' },
  'Danh sách trống - hãy nhập proxy vào danh sách trước': { en: 'Empty list - enter proxies into the list first', ru: 'Список пуст - сначала введите прокси в список', zh: '列表为空 - 请先输入代理' },
  'Vui lòng nhập ít nhất 1 proxy hợp lệ': { en: 'Please enter at least 1 valid proxy', ru: 'Введите хотя бы 1 действительный прокси', zh: '请输入至少 1 个有效代理' },

  // ── Extensions view ───────────────────────────────────────────────────────
  'Tải lên tiện ích': { en: 'Upload extension', ru: 'Загрузить расширение', zh: '上传扩展' },
  'Đã thêm tiện ích': { en: 'Extension added', ru: 'Расширение добавлено', zh: '已添加扩展' },
  'Đã cập nhật tiện ích': { en: 'Extension updated', ru: 'Расширение обновлено', zh: '扩展已更新' },
  'Đã tải và thêm tiện ích': { en: 'Extension downloaded and added', ru: 'Расширение загружено и добавлено', zh: '扩展已下载并添加' },
  'Đã chọn tiện ích': { en: 'Extension selected', ru: 'Расширение выбрано', zh: '已选择扩展' },
  'Đang cập nhật tiện ích…': { en: 'Updating extension…', ru: 'Обновление расширения…', zh: '正在更新扩展…' },
  'Tải tiện ích thất bại': { en: 'Failed to download extension', ru: 'Не удалось загрузить расширение', zh: '扩展下载失败' },
  'Tải tiện ích thất bại (kiểm tra mạng/URL)': { en: 'Failed to download extension (check network/URL)', ru: 'Не удалось загрузить расширение (проверьте сеть/URL)', zh: '扩展下载失败（请检查网络/URL）' },
  'Không giải nén được tiện ích': { en: 'Could not unpack the extension', ru: 'Не удалось распаковать расширение', zh: '无法解压扩展' },
  'Tiện ích không hợp lệ (thiếu tên)': { en: 'Invalid extension (missing name)', ru: 'Недопустимое расширение (нет имени)', zh: '无效扩展（缺少名称）' },
  'Tiện ích chưa có thư mục': { en: 'Extension has no folder', ru: 'У расширения нет папки', zh: '扩展没有目录' },
  'Tiện ích nhóm': { en: 'Group extension', ru: 'Групповое расширение', zh: '分组扩展' },
  'Không tìm thấy tiện ích phù hợp.': { en: 'No matching extension found.', ru: 'Подходящее расширение не найдено.', zh: '未找到匹配的扩展。' },
  'Chưa có tiện ích nào. Bấm "Tải lên tiện ích" để thêm.': { en: 'No extensions yet. Click "Upload extension" to add one.', ru: 'Пока нет расширений. Нажмите «Загрузить расширение», чтобы добавить.', zh: '暂无扩展。点击"上传扩展"以添加。' },
  'Kéo & thả tiện ích mở rộng vào đây': { en: 'Drag & drop an extension here', ru: 'Перетащите расширение сюда', zh: '将扩展拖放到此处' },
  'Hãy thả thư mục tiện ích đã giải nén': { en: 'Drop the unpacked extension folder', ru: 'Перетащите распакованную папку расширения', zh: '拖入已解压的扩展目录' },
  'Thư mục không chứa manifest.json': { en: 'Folder does not contain manifest.json', ru: 'В папке нет manifest.json', zh: '目录中没有 manifest.json' },
  'Gói tải về không hợp lệ (thiếu manifest.json)': { en: 'Invalid downloaded package (missing manifest.json)', ru: 'Недопустимый загруженный пакет (нет manifest.json)', zh: '下载的包无效（缺少 manifest.json）' },
  'Không nhận diện được ID tiện ích từ URL': { en: 'Could not detect extension ID from the URL', ru: 'Не удалось определить ID расширения из URL', zh: '无法从 URL 识别扩展 ID' },
  'Vui lòng nhập URL Chrome Web Store hợp lệ': { en: 'Please enter a valid Chrome Web Store URL', ru: 'Введите действительный URL Chrome Web Store', zh: '请输入有效的 Chrome 应用商店 URL' },
  'URL Chrome Web Store của tiện ích': { en: "Extension's Chrome Web Store URL", ru: 'URL расширения в Chrome Web Store', zh: '扩展的 Chrome 应用商店 URL' },
  'Cửa hàng Chrome': { en: 'Chrome Store', ru: 'Магазин Chrome', zh: 'Chrome 商店' },
  'Xác nhận xóa các ứng dụng này?': { en: 'Confirm deleting these apps?', ru: 'Подтвердить удаление этих приложений?', zh: '确认删除这些应用？' },
  'Xóa ứng dụng': { en: 'Delete app', ru: 'Удалить приложение', zh: '删除应用' },
  'Tên ứng dụng': { en: 'App Name', ru: 'Имя приложения', zh: '应用名称' },
  'Ứng dụng': { en: 'App', ru: 'Приложение', zh: '应用' },

  // ── Trash view ────────────────────────────────────────────────────────────
  'Thùng rác trống': { en: 'Trash is empty', ru: 'Корзина пуста', zh: '回收站为空' },
  'Xóa vĩnh viễn': { en: 'Delete permanently', ru: 'Удалить навсегда', zh: '永久删除' },
  'Khôi phục': { en: 'Restore', ru: 'Восстановить', zh: '恢复' },
  'Tự động xóa': { en: 'Auto-delete', ru: 'Автоудаление', zh: '自动删除' },
  'còn {0} ngày': { en: '{0} days left', ru: 'осталось {0} дн.', zh: '剩 {0} 天' },
  'sắp xóa': { en: 'deleting soon', ru: 'скоро удалится', zh: '即将删除' },
  'Thời gian xóa': { en: 'Deleted Time', ru: 'Время удаления', zh: '删除时间' },
  'Hệ thống tự động xóa': { en: 'Auto-deleted by the system', ru: 'Автоматически удаляется системой', zh: '系统自动删除' },

  // ── Tasks / scheduler / task editor ───────────────────────────────────────
  'Tên nhiệm vụ': { en: 'Task Name', ru: 'Имя задачи', zh: '任务名称' },
  'ID nhiệm vụ': { en: 'Task ID', ru: 'ID задачи', zh: '任务 ID' },
  'Loại nhiệm vụ': { en: 'Task Type', ru: 'Тип задачи', zh: '任务类型' },
  'Xóa nhiệm vụ': { en: 'Delete task', ru: 'Удалить задачу', zh: '删除任务' },
  'Xóa các nhiệm vụ đã chọn': { en: 'Delete selected tasks', ru: 'Удалить выбранные задачи', zh: '删除所选任务' },
  'Đã lưu nhiệm vụ': { en: 'Task saved', ru: 'Задача сохранена', zh: '任务已保存' },
  'Đã xóa nhiệm vụ': { en: 'Task deleted', ru: 'Задача удалена', zh: '任务已删除' },
  'Chưa chọn nhiệm vụ nào': { en: 'No task selected', ru: 'Задача не выбрана', zh: '未选择任务' },
  'Nhiệm vụ cần ít nhất một hồ sơ': { en: 'The task needs at least one profile', ru: 'Задаче нужен хотя бы один профиль', zh: '任务至少需要一个配置文件' },
  'Nhiệm vụ chưa có hồ sơ nào.': { en: 'The task has no profiles yet.', ru: 'В задаче ещё нет профилей.', zh: '任务尚无配置文件。' },
  'Nhiệm vụ này chưa có lần chạy nào.': { en: 'This task has not run yet.', ru: 'Эта задача ещё не запускалась.', zh: '该任务尚未运行。' },
  'Vui lòng nhập tên nhiệm vụ': { en: 'Please enter a task name', ru: 'Введите имя задачи', zh: '请输入任务名称' },
  'Tìm kiếm nhiệm vụ...': { en: 'Search tasks...', ru: 'Поиск задач...', zh: '搜索任务…' },
  'Đang dừng nhiệm vụ…': { en: 'Stopping task…', ru: 'Остановка задачи…', zh: '正在停止任务…' },
  'Tên lịch': { en: 'Schedule Name', ru: 'Название расписания', zh: '计划名称' },
  'Lên lịch': { en: 'Schedule', ru: 'Расписание', zh: '计划' },
  'Lên lịch thực': { en: 'Real schedule', ru: 'Реальное расписание', zh: '实际计划' },
  'Tần suất thực hiện': { en: 'Frequency', ru: 'Частота выполнения', zh: '执行频率' },
  'Một lần': { en: 'Once', ru: 'Один раз', zh: '一次' },
  'Hàng ngày': { en: 'Daily', ru: 'Ежедневно', zh: '每天' },
  'Hàng tuần': { en: 'Weekly', ru: 'Еженедельно', zh: '每周' },
  'Hàng tháng': { en: 'Monthly', ru: 'Ежемесячно', zh: '每月' },
  'Không lặp lại': { en: 'Do not repeat', ru: 'Не повторять', zh: '不重复' },
  'Thời gian bắt đầu': { en: 'Start Time', ru: 'Время начала', zh: '开始时间' },
  'Thời gian kết thúc': { en: 'End Time', ru: 'Время окончания', zh: '结束时间' },
  'Thời gian chạy': { en: 'Run Time', ru: 'Время выполнения', zh: '运行时间' },
  'Thời gian thực hiện': { en: 'Execution Time', ru: 'Время выполнения', zh: '执行时间' },
  'Bắt đầu lúc': { en: 'Starts at', ru: 'Начинается в', zh: '开始于' },
  'Hồ sơ kết thúc lúc': { en: 'Profile ends at', ru: 'Профиль завершается в', zh: '配置文件结束于' },
  'Thực hiện ngay': { en: 'Run now', ru: 'Выполнить сейчас', zh: '立即执行' },
  'Số luồng đồng thời': { en: 'Concurrent threads', ru: 'Одновременные потоки', zh: '并发线程数' },

  // ── Automation / RPA editor - categories, toolbar, common ─────────────────
  'Quy trình này không có tham số đầu vào.': { en: 'This workflow has no input parameters.', ru: 'У этого процесса нет входных параметров.', zh: '此流程没有输入参数。' },
  'Chưa tạo biến đầu vào.': { en: 'No input variables created yet.', ru: 'Входные переменные ещё не созданы.', zh: '尚未创建输入变量。' },
  'Chỉnh sửa quy trình': { en: 'Edit Workflow', ru: 'Редактировать процесс', zh: '编辑流程' },
  'Nhập quy trình': { en: 'Import Workflow', ru: 'Импорт процесса', zh: '导入流程' },
  'Xuất quy trình': { en: 'Export Workflow', ru: 'Экспорт процесса', zh: '导出流程' },
  'Chạy quy trình': { en: 'Run Workflow', ru: 'Запустить процесс', zh: '运行流程' },
  'Bắt đầu quy trình': { en: 'Start of Workflow', ru: 'Начало процесса', zh: '流程开始' },
  'Vui lòng chọn quy trình': { en: 'Please choose a workflow', ru: 'Выберите процесс', zh: '请选择流程' },
  'Sử dụng các quy trình khác': { en: 'Use other workflows', ru: 'Использовать другие процессы', zh: '使用其他流程' },
  'Quá trình': { en: 'Workflows', ru: 'Процессы', zh: '流程' },
  'Quy Trình RPA': { en: 'RPA Workflow', ru: 'RPA-процесс', zh: 'RPA 流程' },
  'Do tôi tạo': { en: 'Created by me', ru: 'Созданные мной', zh: '我创建的' },
  'Đã nhận': { en: 'Received', ru: 'Полученные', zh: '已接收' },
  'Ghim đầu trang': { en: 'Pin to top', ru: 'Закрепить сверху', zh: '置顶' },
  'Gộp nhóm nhanh': { en: 'Quick group', ru: 'Быстрая группировка', zh: '快速分组' },
  'Sơ đồ': { en: 'Diagram', ru: 'Схема', zh: '流程图' },
  'Gỡ lỗi': { en: 'Debug', ru: 'Отладка', zh: '调试' },
  'Nhật ký debug': { en: 'Debug log', ru: 'Журнал отладки', zh: '调试日志' },
  'Cấu hình chạy': { en: 'Run Config', ru: 'Конфигурация запуска', zh: '运行配置' },
  'Đầu vào': { en: 'Input', ru: 'Ввод', zh: '输入' },
  'Đầu ra': { en: 'Output', ru: 'Вывод', zh: '输出' },
  'Chèn biến': { en: 'Insert variable', ru: 'Вставить переменную', zh: '插入变量' },
  'Biến': { en: 'Variable', ru: 'Переменная', zh: '变量' },
  'Biến quy trình': { en: 'Workflow variables', ru: 'Переменные процесса', zh: '流程变量' },
  'Biến hệ thống': { en: 'System variables', ru: 'Системные переменные', zh: '系统变量' },
  'Biến dữ liệu': { en: 'Data variable', ru: 'Переменная данных', zh: '数据变量' },
  'Tên biến': { en: 'Variable name', ru: 'Имя переменной', zh: '变量名' },
  'Kiểu biến': { en: 'Variable type', ru: 'Тип переменной', zh: '变量类型' },
  'Giá trị mặc định': { en: 'Default value', ru: 'Значение по умолчанию', zh: '默认值' },
  'Thêm biến': { en: 'Add variable', ru: 'Добавить переменную', zh: '添加变量' },
  'Tạo biến mới': { en: 'Create new variable', ru: 'Создать переменную', zh: '新建变量' },
  'Chưa có biến': { en: 'No variables yet', ru: 'Переменных пока нет', zh: '暂无变量' },
  'Hãy chọn biến': { en: 'Please choose a variable', ru: 'Выберите переменную', zh: '请选择变量' },
  'Xử lý biến': { en: 'Process variable', ru: 'Обработка переменной', zh: '处理变量' },

  // ── RPA node categories ───────────────────────────────────────────────────
  'Luồng điều khiển': { en: 'Control Flow', ru: 'Поток управления', zh: '流程控制' },
  'Xử lý tệp & thư mục': { en: 'File & Folder Handling', ru: 'Работа с файлами и папками', zh: '文件与目录处理' },
  'Tương tác Web': { en: 'Web Interaction', ru: 'Веб-взаимодействие', zh: '网页交互' },
  'Trình duyệt': { en: 'Browser', ru: 'Браузер', zh: '浏览器' },
  'Dữ liệu': { en: 'Data', ru: 'Данные', zh: '数据' },
  'Toán học': { en: 'Math', ru: 'Математика', zh: '数学' },
  'Khác': { en: 'Other', ru: 'Другое', zh: '其他' },

  // ── RPA node names + descriptions (browser / web / interaction) ───────────
  'Mở URL': { en: 'Open URL', ru: 'Открыть URL', zh: '打开 URL' },
  'Mở URL được chỉ định trên tab hiện tại': { en: 'Open the specified URL in the current tab', ru: 'Открыть указанный URL в текущей вкладке', zh: '在当前标签页打开指定 URL' },
  'Mở tab mới': { en: 'Open new tab', ru: 'Открыть новую вкладку', zh: '打开新标签页' },
  'Mở tab mới với URL được chỉ định': { en: 'Open a new tab with the specified URL', ru: 'Открыть новую вкладку с указанным URL', zh: '以指定 URL 打开新标签页' },
  'Mở link trong tab mới': { en: 'Open link in new tab', ru: 'Открыть ссылку в новой вкладке', zh: '在新标签页打开链接' },
  'Đóng tab': { en: 'Close tab', ru: 'Закрыть вкладку', zh: '关闭标签页' },
  'Đóng tab được chỉ định': { en: 'Close the specified tab', ru: 'Закрыть указанную вкладку', zh: '关闭指定标签页' },
  'Chuyển tab': { en: 'Switch tab', ru: 'Переключить вкладку', zh: '切换标签页' },
  'Chuyển sang tab được chỉ định': { en: 'Switch to the specified tab', ru: 'Перейти на указанную вкладку', zh: '切换到指定标签页' },
  'Thêm tab': { en: 'Add tab', ru: 'Добавить вкладку', zh: '添加标签页' },
  'Đặt làm tab hoạt động': { en: 'Set as active tab', ru: 'Сделать активной вкладкой', zh: '设为活动标签页' },
  'Tab đang hoạt động': { en: 'Active tab', ru: 'Активная вкладка', zh: '活动标签页' },
  'Đóng trình duyệt': { en: 'Close browser', ru: 'Закрыть браузер', zh: '关闭浏览器' },
  'Đóng cửa sổ trình duyệt': { en: 'Close the browser window', ru: 'Закрыть окно браузера', zh: '关闭浏览器窗口' },
  'Tải lại trang': { en: 'Reload page', ru: 'Перезагрузить страницу', zh: '重新加载页面' },
  'Quay lại trang trước đó': { en: 'Go back to the previous page', ru: 'Вернуться на предыдущую страницу', zh: '返回上一页' },
  'Tiến lên trang sau đó': { en: 'Go forward to the next page', ru: 'Перейти на следующую страницу', zh: '前进到下一页' },
  'Quay lại': { en: 'Back', ru: 'Назад', zh: '返回' },
  'Tiến lên': { en: 'Forward', ru: 'Вперёд', zh: '前进' },
  'Truy cập trang web': { en: 'Visit website', ru: 'Перейти на сайт', zh: '访问网站' },
  'Chờ tải trang': { en: 'Wait for page load', ru: 'Ждать загрузки страницы', zh: '等待页面加载' },
  'Chờ phần tử': { en: 'Wait for element', ru: 'Ждать элемент', zh: '等待元素' },
  'Chờ đợi một khoản thời gian trước khi tiếp tục': { en: 'Wait for a while before continuing', ru: 'Подождать некоторое время перед продолжением', zh: '等待一段时间后再继续' },
  'Click chuột vào phần tử được chỉ định': { en: 'Click the specified element', ru: 'Нажать на указанный элемент', zh: '点击指定元素' },
  'Nhấp chuột': { en: 'Click', ru: 'Клик', zh: '点击' },
  'Nhấn chuột': { en: 'Mouse click', ru: 'Нажатие мыши', zh: '鼠标点击' },
  'Nhấn trên phần tử': { en: 'Click on element', ru: 'Нажать на элемент', zh: '点击元素' },
  'Nhấn giữ': { en: 'Press and hold', ru: 'Нажать и удерживать', zh: '按住' },
  'Nhấn phím': { en: 'Press key', ru: 'Нажать клавишу', zh: '按键' },
  'Di chuyển chuột': { en: 'Move mouse', ru: 'Переместить мышь', zh: '移动鼠标' },
  'Di chuyển chuột đến phần tử hoặc tọa độ chỉ định': { en: 'Move the mouse to the specified element or coordinates', ru: 'Переместить мышь к указанному элементу или координатам', zh: '将鼠标移动到指定元素或坐标' },
  'Cuộn chuột': { en: 'Scroll', ru: 'Прокрутка', zh: '滚动' },
  'Cuộn chuột theo tọa độ hoặc phần tử được chọn': { en: 'Scroll to coordinates or the selected element', ru: 'Прокрутить к координатам или выбранному элементу', zh: '滚动到坐标或所选元素' },
  'Cuộn lên': { en: 'Scroll up', ru: 'Прокрутить вверх', zh: '向上滚动' },
  'Cuộn xuống': { en: 'Scroll down', ru: 'Прокрутить вниз', zh: '向下滚动' },
  'Nhập văn bản': { en: 'Enter text', ru: 'Ввести текст', zh: '输入文本' },
  'Gõ văn bản': { en: 'Type text', ru: 'Печатать текст', zh: '键入文本' },
  'Chụp màn hình': { en: 'Screenshot', ru: 'Скриншот', zh: '截图' },
  'Chụp ảnh màn hình của tab đang hoạt động': { en: 'Capture a screenshot of the active tab', ru: 'Сделать скриншот активной вкладки', zh: '截取活动标签页的屏幕截图' },
  'Chờ tải trang đến sự kiện được chỉ định phát ra': { en: 'Wait for the page to load until the specified event fires', ru: 'Ждать загрузки страницы до наступления указанного события', zh: '等待页面加载直到触发指定事件' },
  'Chuyển Frame': { en: 'Switch Frame', ru: 'Переключить фрейм', zh: '切换框架' },
  'Chuyển Frame được chỉ định': { en: 'Switch to the specified frame', ru: 'Перейти к указанному фрейму', zh: '切换到指定框架' },
  'Frame chính': { en: 'Main frame', ru: 'Главный фрейм', zh: '主框架' },
  'Loại Frame': { en: 'Frame type', ru: 'Тип фрейма', zh: '框架类型' },
  'Chạy mã Javascript': { en: 'Run JavaScript', ru: 'Выполнить JavaScript', zh: '运行 JavaScript' },
  'Chèn mã Javascript tùy chỉnh': { en: 'Insert custom JavaScript', ru: 'Вставить свой JavaScript', zh: '插入自定义 JavaScript' },
  'Thực thi mã Javascript trên trang đang hoạt động': { en: 'Execute JavaScript on the active page', ru: 'Выполнить JavaScript на активной странице', zh: '在活动页面执行 JavaScript' },

  // ── RPA data / string / value handling ────────────────────────────────────
  'Lấy dữ liệu': { en: 'Get data', ru: 'Получить данные', zh: '获取数据' },
  'Lấy văn bản': { en: 'Get text', ru: 'Получить текст', zh: '获取文本' },
  'Lấy URL': { en: 'Get URL', ru: 'Получить URL', zh: '获取 URL' },
  'Lấy URL của tab đang hoạt động': { en: 'Get the URL of the active tab', ru: 'Получить URL активной вкладки', zh: '获取活动标签页的 URL' },
  'Lấy thuộc tính': { en: 'Get attribute', ru: 'Получить атрибут', zh: '获取属性' },
  'Lấy nội dung HTML': { en: 'Get HTML content', ru: 'Получить HTML-содержимое', zh: '获取 HTML 内容' },
  'Lấy đầy đủ nội dung HTML của trang web': { en: 'Get the full HTML content of the page', ru: 'Получить полный HTML-код страницы', zh: '获取网页完整 HTML 内容' },
  'Lấy nội dung văn bản của một phần tử trong trang web': { en: 'Get the text content of an element on the page', ru: 'Получить текст элемента на странице', zh: '获取网页中某元素的文本内容' },
  'Lấy độ dài': { en: 'Get length', ru: 'Получить длину', zh: '获取长度' },
  'Lấy số lượng phần tử': { en: 'Get element count', ru: 'Получить количество элементов', zh: '获取元素数量' },
  'Lấy số thứ tự': { en: 'Get index', ru: 'Получить индекс', zh: '获取序号' },
  'Lấy phần tử theo thứ tự': { en: 'Get element by index', ru: 'Получить элемент по индексу', zh: '按序号获取元素' },
  'Lấy phần tử ngẫu nhiên': { en: 'Get random element', ru: 'Получить случайный элемент', zh: '获取随机元素' },
  'Lấy một phần của chuỗi': { en: 'Get a substring', ru: 'Получить подстроку', zh: '获取字符串的一部分' },
  'Lấy một phần của danh sách': { en: 'Get a slice of the list', ru: 'Получить часть списка', zh: '获取列表的一部分' },
  'Lấy Thời Gian': { en: 'Get Time', ru: 'Получить время', zh: '获取时间' },
  'Lấy thông tin thời gian ở thời điểm hiện tại': { en: 'Get the current time', ru: 'Получить текущее время', zh: '获取当前时间信息' },
  'Nối chuỗi': { en: 'Concatenate strings', ru: 'Объединить строки', zh: '拼接字符串' },
  'Tách chuỗi': { en: 'Split string', ru: 'Разделить строку', zh: '拆分字符串' },
  'Thay thế chuỗi': { en: 'Replace string', ru: 'Заменить строку', zh: '替换字符串' },
  'Thay thế': { en: 'Replace', ru: 'Заменить', zh: '替换' },
  'Thay thế tất cả': { en: 'Replace all', ru: 'Заменить всё', zh: '全部替换' },
  'Chuỗi cần thay thế': { en: 'String to replace', ru: 'Строка для замены', zh: '要替换的字符串' },
  'Chuỗi được thay thế': { en: 'Replacement string', ru: 'Строка замены', zh: '替换后的字符串' },
  'Chuỗi ký tự': { en: 'Character string', ru: 'Строка символов', zh: '字符串' },
  'Chuỗi URL': { en: 'URL string', ru: 'Строка URL', zh: 'URL 字符串' },
  'Danh sách chuỗi': { en: 'String list', ru: 'Список строк', zh: '字符串列表' },
  'Gán biến': { en: 'Assign variable', ru: 'Присвоить переменную', zh: '赋值变量' },
  'Gán biến với nhiều toán tử': { en: 'Assign a variable with multiple operators', ru: 'Присвоить переменную с несколькими операторами', zh: '使用多个运算符赋值变量' },
  'Xử lý giá trị của biến': { en: 'Process a variable value', ru: 'Обработать значение переменной', zh: '处理变量的值' },
  'Toán tử': { en: 'Operator', ru: 'Оператор', zh: '运算符' },
  'Thực hiện các phép toán học': { en: 'Perform math operations', ru: 'Выполнить математические операции', zh: '执行数学运算' },
  'Thực hiện một HTTP Request': { en: 'Perform an HTTP request', ru: 'Выполнить HTTP-запрос', zh: '执行一个 HTTP 请求' },
  'Kiểu dữ liệu': { en: 'Data type', ru: 'Тип данных', zh: '数据类型' },
  'Loại dữ liệu': { en: 'Data type', ru: 'Тип данных', zh: '数据类型' },
  'Định dạng trả về': { en: 'Return format', ru: 'Формат ответа', zh: '返回格式' },
  'Phương thức': { en: 'Method', ru: 'Метод', zh: '方法' },

  // ── RPA control flow ──────────────────────────────────────────────────────
  'Điều kiện': { en: 'Condition', ru: 'Условие', zh: '条件' },
  'Lặp lại': { en: 'Repeat', ru: 'Повторить', zh: '重复' },
  'Lặp dữ liệu': { en: 'Loop over data', ru: 'Цикл по данным', zh: '遍历数据' },
  'Lặp có điều kiện': { en: 'Conditional loop', ru: 'Условный цикл', zh: '条件循环' },
  'Dừng vòng lặp': { en: 'Break loop', ru: 'Прервать цикл', zh: '结束循环' },
  'Tiếp tục vòng lặp': { en: 'Continue loop', ru: 'Продолжить цикл', zh: '继续循环' },
  'Điểm cuối vòng lặp': { en: 'Loop end', ru: 'Конец цикла', zh: '循环结束点' },
  'Dữ liệu lặp': { en: 'Loop data', ru: 'Данные цикла', zh: '循环数据' },
  'Bỏ qua các bước tiếp theo và tiếp tục vòng lặp mới': { en: 'Skip the following steps and continue the next loop', ru: 'Пропустить следующие шаги и продолжить новый цикл', zh: '跳过后续步骤并进入下一轮循环' },
  'Bằng': { en: 'Equals', ru: 'Равно', zh: '等于' },
  'Không bằng': { en: 'Not equal', ru: 'Не равно', zh: '不等于' },
  'Lớn hơn': { en: 'Greater than', ru: 'Больше', zh: '大于' },
  'Lớn hơn hoặc bằng': { en: 'Greater than or equal', ru: 'Больше или равно', zh: '大于或等于' },
  'Nhỏ hơn': { en: 'Less than', ru: 'Меньше', zh: '小于' },
  'Nhỏ hơn hoặc bằng': { en: 'Less than or equal', ru: 'Меньше или равно', zh: '小于或等于' },
  'Bao gồm': { en: 'Contains', ru: 'Содержит', zh: '包含' },
  'Không bao gồm': { en: 'Does not contain', ru: 'Не содержит', zh: '不包含' },
  'Bắt đầu bằng': { en: 'Starts with', ru: 'Начинается с', zh: '以…开头' },
  'Nằm trong': { en: 'In', ru: 'Входит в', zh: '在…中' },
  'Không nằm trong': { en: 'Not in', ru: 'Не входит в', zh: '不在…中' },
  'Khớp với mẫu': { en: 'Matches pattern', ru: 'Соответствует шаблону', zh: '匹配模式' },
  'Thỏa mãn': { en: 'Satisfies', ru: 'Удовлетворяет', zh: '满足' },

  // ── RPA file & folder ─────────────────────────────────────────────────────
  'Đọc tệp txt': { en: 'Read TXT file', ru: 'Читать TXT-файл', zh: '读取 TXT 文件' },
  'Đọc tệp có định dạng txt': { en: 'Read a txt-format file', ru: 'Читать файл формата txt', zh: '读取 txt 格式文件' },
  'Đọc một dòng': { en: 'Read one line', ru: 'Читать одну строку', zh: '读取一行' },
  'Đọc tất cả': { en: 'Read all', ru: 'Читать всё', zh: '全部读取' },
  'Đọc thư mục': { en: 'Read folder', ru: 'Читать папку', zh: '读取目录' },
  'Ghi tệp': { en: 'Write file', ru: 'Записать файл', zh: '写入文件' },
  'Ghi dữ liệu vào tệp': { en: 'Write data to a file', ru: 'Записать данные в файл', zh: '将数据写入文件' },
  'Ghi đè': { en: 'Overwrite', ru: 'Перезаписать', zh: '覆盖' },
  'Ghi thêm': { en: 'Append', ru: 'Дописать', zh: '追加' },
  'Xóa tệp': { en: 'Delete file', ru: 'Удалить файл', zh: '删除文件' },
  'Xóa tệp được chỉ định': { en: 'Delete the specified file', ru: 'Удалить указанный файл', zh: '删除指定文件' },
  'Tải tệp lên': { en: 'Upload file', ru: 'Загрузить файл', zh: '上传文件' },
  'Tải tệp lên trang web': { en: 'Upload a file to the page', ru: 'Загрузить файл на страницу', zh: '将文件上传到网页' },
  'Tải tệp trong thư mục': { en: 'Upload files from a folder', ru: 'Загрузить файлы из папки', zh: '上传目录中的文件' },
  'Đường dẫn tệp': { en: 'File path', ru: 'Путь к файлу', zh: '文件路径' },
  'Đường dẫn thư mục': { en: 'Folder path', ru: 'Путь к папке', zh: '目录路径' },
  'Đường dẫn lưu trữ': { en: 'Save path', ru: 'Путь сохранения', zh: '存储路径' },
  'Đường dẫn tới tệp local': { en: 'Path to local file', ru: 'Путь к локальному файлу', zh: '本地文件路径' },
  'Đọc ghi file excel hoặc google sheet': { en: 'Read/write Excel or Google Sheet', ru: 'Чтение/запись Excel или Google Sheet', zh: '读写 Excel 或 Google 表格' },
  'Bảng tính': { en: 'Spreadsheet', ru: 'Таблица', zh: '电子表格' },
  'Loại bảng tính': { en: 'Spreadsheet type', ru: 'Тип таблицы', zh: '表格类型' },

  // ── Fingerprint / profile create tabs ─────────────────────────────────────
  'Dấu vân tay': { en: 'Fingerprint', ru: 'Отпечаток', zh: '指纹' },
  'Dấu vân tay mới': { en: 'New fingerprint', ru: 'Новый отпечаток', zh: '新指纹' },
  'Tạo dấu vân tay ngẫu nhiên': { en: 'Generate random fingerprint', ru: 'Создать случайный отпечаток', zh: '生成随机指纹' },
  'Tạo vân tay mới': { en: 'Generate new fingerprint', ru: 'Создать новый отпечаток', zh: '生成新指纹' },
  'Đang tạo dấu vân tay mới…': { en: 'Generating a new fingerprint…', ru: 'Создание нового отпечатка…', zh: '正在生成新指纹…' },
  'Độ phân giải': { en: 'Resolution', ru: 'Разрешение', zh: '分辨率' },
  'Ngôn ngữ hiển thị': { en: 'Display language', ru: 'Язык интерфейса', zh: '显示语言' },
  'Địa chỉ': { en: 'Address', ru: 'Адрес', zh: '地址' },
  'Địa chỉ MAC': { en: 'MAC Address', ru: 'MAC-адрес', zh: 'MAC 地址' },
  'Địa chỉ URL': { en: 'URL Address', ru: 'URL-адрес', zh: 'URL 地址' },
  'Vị trí': { en: 'Location', ru: 'Местоположение', zh: '位置' },
  'Tọa độ': { en: 'Coordinates', ru: 'Координаты', zh: '坐标' },
  'Tọa độ vị trí': { en: 'Position coordinates', ru: 'Координаты позиции', zh: '位置坐标' },
  'Tọa độ X': { en: 'X coordinate', ru: 'Координата X', zh: 'X 坐标' },
  'Tọa độ Y': { en: 'Y coordinate', ru: 'Координата Y', zh: 'Y 坐标' },
  'Nhà cung cấp': { en: 'Vendor', ru: 'Поставщик', zh: '供应商' },
  'Trình kết xuất': { en: 'Renderer', ru: 'Рендерер', zh: '渲染器' },
  'Trình quản lý cookie mạnh mẽ, sao lưu và phục hồi nhanh.': { en: 'Powerful cookie manager with fast backup and restore.', ru: 'Мощный менеджер cookie с быстрым резервным копированием и восстановлением.', zh: '强大的 Cookie 管理器，快速备份与恢复。' },
  'Tăng tốc phần cứng': { en: 'Hardware acceleration', ru: 'Аппаратное ускорение', zh: '硬件加速' },
  'Âm thanh': { en: 'Audio', ru: 'Звук', zh: '音频' },
  'Nhiễu': { en: 'Noise', ru: 'Шум', zh: '噪声' },
  'Thực': { en: 'Real', ru: 'Реальный', zh: '真实' },
  'Bảo vệ Port scan': { en: 'Port scan protection', ru: 'Защита от сканирования портов', zh: '端口扫描保护' },
  'Vô hiệu hóa': { en: 'Disable', ru: 'Отключить', zh: '禁用' },
  'Vô hiệu hóa tính năng TLS': { en: 'Disable TLS feature', ru: 'Отключить функцию TLS', zh: '禁用 TLS 功能' },
  'Đổi User-Agent để giả lập trình duyệt hoặc thiết bị khác.': { en: 'Change the User-Agent to emulate a different browser or device.', ru: 'Изменить User-Agent для эмуляции другого браузера или устройства.', zh: '更改 User-Agent 以模拟其他浏览器或设备。' },

  // ── Sync / console ────────────────────────────────────────────────────────
  'Bắt đầu đồng bộ': { en: 'Start sync', ru: 'Начать синхронизацию', zh: '开始同步' },
  'Dừng đồng bộ': { en: 'Stop sync', ru: 'Остановить синхронизацию', zh: '停止同步' },
  'Đồng bộ hóa': { en: 'Synchronize', ru: 'Синхронизировать', zh: '同步' },
  'Đồng bộ dữ liệu': { en: 'Sync data', ru: 'Синхронизировать данные', zh: '同步数据' },
  'Sắp xếp cửa sổ': { en: 'Arrange windows', ru: 'Расположить окна', zh: '排列窗口' },
  'Sắp xếp cửa sổ các hồ sơ đang mở': { en: 'Arrange the windows of open profiles', ru: 'Расположить окна открытых профилей', zh: '排列已打开配置文件的窗口' },
  'Hiển thị cửa sổ': { en: 'Show window', ru: 'Показать окно', zh: '显示窗口' },
  'Xem cửa sổ': { en: 'View window', ru: 'Просмотреть окно', zh: '查看窗口' },
  'Số cửa sổ mỗi hàng': { en: 'Windows per row', ru: 'Окон в ряд', zh: '每行窗口数' },
  'Chiều cao cửa sổ': { en: 'Window height', ru: 'Высота окна', zh: '窗口高度' },
  'Chiều rộng cửa sổ': { en: 'Window width', ru: 'Ширина окна', zh: '窗口宽度' },
  'Khoảng cách cửa sổ': { en: 'Window spacing', ru: 'Расстояние между окнами', zh: '窗口间距' },
  'Gõ như con người': { en: 'Type like a human', ru: 'Печатать как человек', zh: '像真人一样输入' },
  'Gõ văn bản vào từng cửa sổ': { en: 'Type text into each window', ru: 'Печатать текст в каждое окно', zh: '向每个窗口输入文本' },
  'Văn bản giống nhau': { en: 'Same text', ru: 'Одинаковый текст', zh: '相同文本' },
  'Văn bản chỉ định': { en: 'Assigned text', ru: 'Заданный текст', zh: '指定文本' },
  'Thêm nhóm văn bản': { en: 'Add text group', ru: 'Добавить группу текста', zh: '添加文本组' },
  'Xóa văn bản': { en: 'Clear text', ru: 'Очистить текст', zh: '清除文本' },
  'Xóa/Dán văn bản': { en: 'Clear/Paste text', ru: 'Очистить/вставить текст', zh: '清除/粘贴文本' },
  'Mô phỏng hành động': { en: 'Simulate actions', ru: 'Имитация действий', zh: '模拟操作' },
  'Mô phỏng chuột': { en: 'Simulate mouse', ru: 'Имитация мыши', zh: '模拟鼠标' },
  'Độ trễ (ms)': { en: 'Delay (ms)', ru: 'Задержка (мс)', zh: '延迟 (ms)' },
  'Độ trễ gõ phím': { en: 'Keystroke delay', ru: 'Задержка нажатия клавиш', zh: '按键延迟' },
  'Độ trễ nhấp chuột': { en: 'Click delay', ru: 'Задержка клика', zh: '点击延迟' },
  'Độ trễ mở (ms)': { en: 'Open delay (ms)', ru: 'Задержка открытия (мс)', zh: '打开延迟 (ms)' },
  'Tốc độ (ms)': { en: 'Speed (ms)', ru: 'Скорость (мс)', zh: '速度 (ms)' },
  'Tốc độ cuộn': { en: 'Scroll speed', ru: 'Скорость прокрутки', zh: '滚动速度' },
  'Không có cửa sổ nào đang mở.': { en: 'No windows are open.', ru: 'Нет открытых окон.', zh: '没有已打开的窗口。' },
  'Không có cửa sổ nào.': { en: 'No windows.', ru: 'Нет окон.', zh: '没有窗口。' },
  'Cần ít nhất 2 cửa sổ đang mở (1 master + 1 slave).': { en: 'Need at least 2 open windows (1 master + 1 slave).', ru: 'Нужно минимум 2 открытых окна (1 главное + 1 подчинённое).', zh: '至少需要 2 个打开的窗口（1 个主 + 1 个从）。' },
  'Không bật được đồng bộ.': { en: 'Could not start sync.', ru: 'Не удалось включить синхронизацию.', zh: '无法开启同步。' },
  'Vui lòng chọn hoặc mở từ 2 profile trở lên': { en: 'Please select or open at least 2 profiles', ru: 'Выберите или откройте не менее 2 профилей', zh: '请选择或打开至少 2 个配置文件' },

  // ── Activity log ──────────────────────────────────────────────────────────
  'Hành động': { en: 'Action', ru: 'Действие', zh: '操作' },
  'Người thực hiện': { en: 'Performed by', ru: 'Исполнитель', zh: '执行人' },
  'Người thao tác': { en: 'Operator', ru: 'Оператор', zh: '操作者' },
  'Nhật ký': { en: 'Log', ru: 'Журнал', zh: '日志' },
  'Xóa nhật ký': { en: 'Clear log', ru: 'Очистить журнал', zh: '清除日志' },
  'Đã xóa nhật ký': { en: 'Log cleared', ru: 'Журнал очищен', zh: '日志已清除' },
  'Chưa có hoạt động nào được ghi lại.': { en: 'No activity has been recorded yet.', ru: 'Активность ещё не записана.', zh: '暂无活动记录。' },
  'Nhật ký chỉ lưu 3 ngày gần nhất, các mục cũ hơn sẽ được tự động xóa.': { en: 'The log keeps only the last 3 days, older entries are deleted automatically.', ru: 'Журнал хранит только последние 3 дня, более старые записи удаляются автоматически.', zh: '日志仅保留最近 3 天，更早的记录将被自动删除。' },
  'Xóa khoảng ngày': { en: 'Clear date range', ru: 'Очистить диапазон дат', zh: '清除日期范围' },
  'Hôm nay': { en: 'Today', ru: 'Сегодня', zh: '今天' },
  'Hôm qua': { en: 'Yesterday', ru: 'Вчера', zh: '昨天' },
  'Bây giờ': { en: 'Now', ru: 'Сейчас', zh: '现在' },
  'Tháng trước': { en: 'Last month', ru: 'Прошлый месяц', zh: '上个月' },
  'Tháng sau': { en: 'Next month', ru: 'Следующий месяц', zh: '下个月' },
  'Năm trước': { en: 'Last year', ru: 'Прошлый год', zh: '去年' },
  'Năm sau': { en: 'Next year', ru: 'Следующий год', zh: '明年' },

  // ── Weekdays ──────────────────────────────────────────────────────────────
  'Thứ hai': { en: 'Monday', ru: 'Понедельник', zh: '星期一' },
  'Thứ ba': { en: 'Tuesday', ru: 'Вторник', zh: '星期二' },
  'Thứ tư': { en: 'Wednesday', ru: 'Среда', zh: '星期三' },
  'Thứ năm': { en: 'Thursday', ru: 'Четверг', zh: '星期四' },
  'Thứ sáu': { en: 'Friday', ru: 'Пятница', zh: '星期五' },
  'Thứ bảy': { en: 'Saturday', ru: 'Суббота', zh: '星期六' },
  'Chủ nhật': { en: 'Sunday', ru: 'Воскресенье', zh: '星期日' },

  // ── Common field labels / small words used widely ─────────────────────────
  'Loại': { en: 'Type', ru: 'Тип', zh: '类型' },
  'Giá trị': { en: 'Value', ru: 'Значение', zh: '值' },
  'Nội dung': { en: 'Content', ru: 'Содержимое', zh: '内容' },
  'Nội dung hiển thị': { en: 'Displayed content', ru: 'Отображаемое содержимое', zh: '显示内容' },
  'Tiêu đề': { en: 'Title', ru: 'Заголовок', zh: '标题' },
  'Tiêu đề tab': { en: 'Tab title', ru: 'Заголовок вкладки', zh: '标签页标题' },
  'Mô tả trang': { en: 'Page description', ru: 'Описание страницы', zh: '页面描述' },
  'Danh mục trang': { en: 'Page category', ru: 'Категория страницы', zh: '页面分类' },
  'Từ khóa': { en: 'Keyword', ru: 'Ключевое слово', zh: '关键词' },
  'Từ tệp': { en: 'From file', ru: 'Из файла', zh: '从文件' },
  'Bộ chọn': { en: 'Selector', ru: 'Селектор', zh: '选择器' },
  'Bộ chọn phần tử': { en: 'Element selector', ru: 'Селектор элемента', zh: '元素选择器' },
  'Bộ chọn của phần tử': { en: 'Selector of the element', ru: 'Селектор элемента', zh: '元素的选择器' },
  'Loại bộ chọn': { en: 'Selector type', ru: 'Тип селектора', zh: '选择器类型' },
  'Loại bộ chọn (tùy chọn)': { en: 'Selector type (optional)', ru: 'Тип селектора (необязательно)', zh: '选择器类型（可选）' },
  'Kiểu chọn': { en: 'Selection type', ru: 'Тип выбора', zh: '选择方式' },
  'Kiểu thêm': { en: 'Add type', ru: 'Тип добавления', zh: '添加方式' },
  'Phần tử': { en: 'Element', ru: 'Элемент', zh: '元素' },
  'Phần tử đã lưu': { en: 'Saved element', ru: 'Сохранённый элемент', zh: '已保存的元素' },
  'Thuộc tính': { en: 'Attribute', ru: 'Атрибут', zh: '属性' },
  'Thuộc tính tìm kiếm': { en: 'Search attribute', ru: 'Атрибут поиска', zh: '搜索属性' },
  'Đường dẫn đến thuộc tính': { en: 'Path to attribute', ru: 'Путь к атрибуту', zh: '属性路径' },
  'Thời gian chờ': { en: 'Timeout', ru: 'Тайм-аут', zh: '等待时间' },
  'Thời gian chờ (số giây)': { en: 'Timeout (seconds)', ru: 'Тайм-аут (секунды)', zh: '等待时间（秒）' },
  'Số lần lặp tối đa, mặc định 0 (không sử dụng)': { en: 'Max iterations, default 0 (unused)', ru: 'Макс. число итераций, по умолчанию 0 (не используется)', zh: '最大循环次数，默认 0（不使用）' },
  'Khoảng thời gian': { en: 'Interval', ru: 'Интервал', zh: '时间间隔' },
  'Khoảng thời gian (phút)': { en: 'Interval (minutes)', ru: 'Интервал (минуты)', zh: '时间间隔（分钟）' },
  'Phạm vi': { en: 'Range', ru: 'Диапазон', zh: '范围' },
  'Số thứ tự': { en: 'Index', ru: 'Индекс', zh: '序号' },
  'Thứ tự': { en: 'Order', ru: 'Порядок', zh: '顺序' },
  'Thứ tự thực hiện': { en: 'Execution order', ru: 'Порядок выполнения', zh: '执行顺序' },
  'Độ dài': { en: 'Length', ru: 'Длина', zh: '长度' },
  'Kích thước': { en: 'Size', ru: 'Размер', zh: '大小' },
  'Số': { en: 'Number', ru: 'Число', zh: '数字' },
  'Số ngẫu nhiên': { en: 'Random number', ru: 'Случайное число', zh: '随机数' },
  'Số tối đa': { en: 'Maximum', ru: 'Максимум', zh: '最大值' },
  'Số tối thiểu': { en: 'Minimum', ru: 'Минимум', zh: '最小值' },
  'Ngẫu nhiên': { en: 'Random', ru: 'Случайно', zh: '随机' },
  'Cố định': { en: 'Fixed', ru: 'Фиксированный', zh: '固定' },
  'Xáo trộn': { en: 'Shuffle', ru: 'Перемешать', zh: '打乱' },
  'Trái': { en: 'Left', ru: 'Слева', zh: '左' },
  'Phải': { en: 'Right', ru: 'Справа', zh: '右' },
  'Giữa': { en: 'Center', ru: 'По центру', zh: '中间' },
  'Dọc': { en: 'Vertical', ru: 'Вертикально', zh: '垂直' },
  'Hướng cuộn': { en: 'Scroll direction', ru: 'Направление прокрутки', zh: '滚动方向' },
  'Nút nhấn': { en: 'Button', ru: 'Кнопка', zh: '按钮' },
  'Phím nhấn': { en: 'Key', ru: 'Клавиша', zh: '按键' },
  'Có': { en: 'Yes', ru: 'Да', zh: '是' },
  'Không': { en: 'No', ru: 'Нет', zh: '否' },
  'Cho phép': { en: 'Allow', ru: 'Разрешить', zh: '允许' },
  'Chặn': { en: 'Block', ru: 'Блокировать', zh: '拦截' },
  'Bật tự động gia hạn': { en: 'Enable auto-renewal', ru: 'Включить автопродление', zh: '开启自动续期' },
  'Tắt tự động gia hạn': { en: 'Disable auto-renewal', ru: 'Отключить автопродление', zh: '关闭自动续期' },
  'Cột': { en: 'Column', ru: 'Столбец', zh: '列' },
  'Hàng': { en: 'Row', ru: 'Строка', zh: '行' },
  'Xóa hàng': { en: 'Delete row', ru: 'Удалить строку', zh: '删除行' },
  'Mật khẩu': { en: 'Password', ru: 'Пароль', zh: '密码' },
  'Họ': { en: 'Last name', ru: 'Фамилия', zh: '姓' },
  'Cửa sổ': { en: 'Window', ru: 'Окно', zh: '窗口' },
  'Thu gọn': { en: 'Collapse', ru: 'Свернуть', zh: '折叠' },
  // Bong bóng hỗ trợ góc màn hình (ui/info-bubble.js): tooltip nút robot + nhãn cho trình đọc
  // màn hình. Nga dùng "Связаться с поддержкой" (связаться + с + tặng cách) cho đúng ngữ pháp.
  'Liên hệ hỗ trợ': { en: 'Contact support', ru: 'Связаться с поддержкой', zh: '联系客服' },
  'Mở liên hệ hỗ trợ': { en: 'Open contact support', ru: 'Открыть связь с поддержкой', zh: '打开联系客服' },
  'Thu nhỏ': { en: 'Minimize', ru: 'Свернуть', zh: '最小化' },
  'Xem hướng dẫn': { en: 'View guide', ru: 'Смотреть руководство', zh: '查看指南' },
  'Hướng dẫn sử dụng': { en: 'User guide', ru: 'Руководство пользователя', zh: '使用指南' },
  'Mua gói lưu lượng': { en: 'Buy a traffic plan', ru: 'Купить тариф трафика', zh: '购买流量套餐' },
  'Gói API': { en: 'API Plan', ru: 'Тариф API', zh: 'API 套餐' },
  'Gia hạn': { en: 'Renew', ru: 'Продлить', zh: '续期' },
  'Chuyển workspace': { en: 'Switch workspace', ru: 'Сменить рабочее пространство', zh: '切换工作区' },
  'Xóa workspace': { en: 'Delete workspace', ru: 'Удалить рабочее пространство', zh: '删除工作区' },

  // ── Placeholder-view descriptions (nav routes without a real page yet) ─────
  'Quản lý danh sách proxy dùng cho hồ sơ.': { en: 'Manage the list of proxies used for profiles.', ru: 'Управление списком прокси для профилей.', zh: '管理用于配置文件的代理列表。' },
  'Quản lý và theo dõi các nhiệm vụ tự động hóa.': { en: 'Manage and monitor automation tasks.', ru: 'Управление и мониторинг задач автоматизации.', zh: '管理并跟踪自动化任务。' },
  'Lên lịch chạy kịch bản theo thời gian.': { en: 'Schedule scripts to run over time.', ru: 'Планирование запуска скриптов по времени.', zh: '按时间计划运行脚本。' },
  'Khám phá và cài đặt các kịch bản tự động hóa có sẵn.': { en: 'Discover and install ready-made automation scripts.', ru: 'Открывайте и устанавливайте готовые скрипты автоматизации.', zh: '发现并安装现成的自动化脚本。' },
  'Quản lý thành viên và phân quyền trong workspace.': { en: 'Manage members and permissions in the workspace.', ru: 'Управление участниками и правами в рабочем пространстве.', zh: '管理工作区中的成员与权限。' },
  'Quản lý khóa API và tích hợp dịch vụ bên ngoài.': { en: 'Manage API keys and third-party integrations.', ru: 'Управление ключами API и внешними интеграциями.', zh: '管理 API 密钥与外部服务集成。' },
  'Lịch sử hoạt động và nhật ký hệ thống.': { en: 'Activity history and system logs.', ru: 'История активности и системные журналы.', zh: '活动历史与系统日志。' },
  'Tạo nhiều hồ sơ cùng lúc - giao diện đang được thiết kế.': { en: 'Create many profiles at once - the interface is being designed.', ru: 'Создание множества профилей сразу - интерфейс в разработке.', zh: '一次创建多个配置文件 - 界面正在设计中。' },
  'Không tải được màn hình: ': { en: 'Could not load screen: ', ru: 'Не удалось загрузить экран: ', zh: '无法加载页面：' },
  '- (đã xóa)': { en: '- (deleted)', ru: '- (удалено)', zh: '-（已删除）' },
  '‹ Quay lại | Chỉnh sửa nhiệm vụ': { en: '‹ Back | Edit task', ru: '‹ Назад | Изменить задачу', zh: '‹ 返回 | 编辑任务' },
  '(không tên)': { en: '(untitled)', ru: '(без имени)', zh: '（未命名）' },
  '* Nếu không chọn "Loại bộ chọn", ứng dụng sẽ nhập văn bản vào vị trí con trỏ hiện tại trên trình duyệt.': { en: '* If "Selector type" is not chosen, the app will type text at the current cursor position in the browser.', ru: '* Если «Тип селектора» не выбран, приложение введёт текст в текущей позиции курсора в браузере.', zh: '* 若未选择“选择器类型”，应用将在浏览器当前光标位置输入文本。' },
  '* Thời gian chờ mặc định 0 là chờ đến khi trang được tải.': { en: '* Default wait time 0 means wait until the page is loaded.', ru: '* Значение ожидания по умолчанию 0 - ждать, пока страница загрузится.', zh: '* 默认等待时间 0 表示等待页面加载完成。' },
  '/hàng': { en: '/row', ru: '/строка', zh: '/行' },
  '^ù': { en: '^ù', ru: '^ù', zh: '^ù' },
  '+ Chọn thẻ': { en: '+ Select tab', ru: '+ Выбрать вкладку', zh: '+ 选择标签' },
  '+ Thêm ngôn ngữ': { en: '+ Add language', ru: '+ Добавить язык', zh: '+ 添加语言' },
  '0 - 0 trên 0': { en: '0 - 0 of 0', ru: '0 - 0 из 0', zh: '0 - 0 / 0' },
  '0 Hồ sơ': { en: '0 Profiles', ru: '0 профилей', zh: '0 个配置文件' },
  '0 trên 0': { en: '0 of 0', ru: '0 из 0', zh: '0 / 0' },
  '01 tháng 07 2026': { en: '01 July 2026', ru: '01 июля 2026', zh: '2026年07月01日' },
  '1 giây = 1000 mili giây': { en: '1 second = 1000 milliseconds', ru: '1 секунда = 1000 миллисекунд', zh: '1 秒 = 1000 毫秒' },
  '1. Yêu cầu mạng ngoài đại lục Trung Quốc.': { en: '1. Requires a network outside mainland China.', ru: '1. Требуется сеть за пределами материкового Китая.', zh: '1. 需要中国大陆以外的网络。' },
  '2. Tiện ích mở rộng được cung cấp bởi bên thứ ba, tất cả quyền được bảo lưu.': { en: '2. Extensions are provided by third parties, all rights reserved.', ru: '2. Расширения предоставляются третьими сторонами, все права защищены.', zh: '2. 扩展程序由第三方提供，保留所有权利。' },
  '26 ngày trước': { en: '26 days ago', ru: '26 дней назад', zh: '26 天前' },
  '3. Truy cập Chrome Web Store và sao chép liên kết của tiện ích mở rộng.': { en: '3. Visit the Chrome Web Store and copy the extension link.', ru: '3. Откройте Chrome Web Store и скопируйте ссылку на расширение.', zh: '3. 访问 Chrome 网上应用店并复制扩展程序链接。' },
  '30 ngày trước': { en: '30 days ago', ru: '30 дней назад', zh: '30 天前' },
  '7 ngày trước': { en: '7 days ago', ru: '7 дней назад', zh: '7 天前' },
  'Bạn có chắc chắn muốn xoá nhóm bên dưới không?': { en: 'Are you sure you want to delete the group below?', ru: 'Вы уверены, что хотите удалить группу ниже?', zh: '确定要删除下面的分组吗？' },
  'Bạn có chắc chắn muốn xóa tất cả nhóm đã chọn không?': { en: 'Are you sure you want to delete all selected groups?', ru: 'Вы уверены, что хотите удалить все выбранные группы?', zh: '确定要删除所有已选分组吗？' },
  'Bảng tạm trống hoặc không đọc được.': { en: 'Clipboard is empty or unreadable.', ru: 'Буфер обмена пуст или недоступен для чтения.', zh: '剪贴板为空或无法读取。' },
  'Bao gồm thư mục con': { en: 'Include subfolders', ru: 'Включая вложенные папки', zh: '包含子文件夹' },
  'Bắt đầu / Dừng đồng bộ': { en: 'Start / Stop sync', ru: 'Начать / Остановить синхронизацию', zh: '开始 / 停止同步' },
  'Bắt đầu đồng bộ hóa': { en: 'Start synchronization', ru: 'Начать синхронизацию', zh: '开始同步' },
  'Bắt đầu/Dừng': { en: 'Start/Stop', ru: 'Старт/Стоп', zh: '开始/停止' },
  'Bậc thang': { en: 'Staircase', ru: 'Лесенка', zh: '阶梯' },
  'Bật': { en: 'On', ru: 'Вкл', zh: '开' },
  'Bật để sử dụng trình duyệt không có giao diện đồ họa (headless)': { en: 'Enable to use a headless browser (no GUI)', ru: 'Включите для использования браузера без графического интерфейса (headless)', zh: '启用以使用无界面浏览器（headless）' },
  'bật lại': { en: 're-enable', ru: 'снова включить', zh: '重新启用' },
  'Bất thường': { en: 'Abnormal', ru: 'Аномально', zh: '异常' },
  'Biến chứa danh sách UID bạn bè': { en: 'Variable holding the friend UID list', ru: 'Переменная со списком UID друзей', zh: '存放好友 UID 列表的变量' },
  'Biến chứa dữ liệu': { en: 'Variable holding data', ru: 'Переменная с данными', zh: '存放数据的变量' },
  'Biến nhận dữ liệu': { en: 'Variable to receive data', ru: 'Переменная для приёма данных', zh: '接收数据的变量' },
  'Biến nhận giá trị': { en: 'Variable to receive value', ru: 'Переменная для приёма значения', zh: '接收值的变量' },
  'Biến khai báo ở đây là THAM SỐ ĐẦU VÀO: người chạy quy trình phải điền giá trị trước khi chạy.': { en: 'Variables declared here are INPUT PARAMETERS: whoever runs the workflow must fill them in before running.', ru: 'Объявленные здесь переменные - ВХОДНЫЕ ПАРАМЕТРЫ: перед запуском их должен заполнить тот, кто запускает процесс.', zh: '此处声明的变量为输入参数：运行流程的人必须先填写这些值。' },
  'Biểu thức chính quy': { en: 'Regular expression', ru: 'Регулярное выражение', zh: '正则表达式' },
  'Bỏ ghim đầu trang': { en: 'Unpin from top', ru: 'Открепить сверху', zh: '取消置顶' },
  'Bỏ lọc': { en: 'Clear filter', ru: 'Сбросить фильтр', zh: '清除筛选' },
  'Bỏ phần thập phân, giữ nguyên dấu': { en: 'Drop the decimal part, keep the sign', ru: 'Отбросить дробную часть, сохранить знак', zh: '去掉小数部分，保留符号' },
  'Bộ chọn / Element được lưu trữ': { en: 'Selector / Stored element', ru: 'Селектор / Сохранённый элемент', zh: '选择器 / 已存储元素' },
  'Bố cục': { en: 'Layout', ru: 'Макет', zh: '布局' },
  'Bố cục cửa sổ': { en: 'Window layout', ru: 'Расположение окон', zh: '窗口布局' },
  'bộ font': { en: 'font set', ru: 'набор шрифтов', zh: '字体集' },
  'Bộ lọc': { en: 'Filter', ru: 'Фильтр', zh: '筛选器' },
  'Bộ nhớ tạm': { en: 'Clipboard', ru: 'Буфер обмена', zh: '剪贴板' },
  'Các hồ sơ đã chọn chưa cấu hình proxy': { en: 'The selected profiles have no proxy configured', ru: 'У выбранных профилей не настроен прокси', zh: '所选配置文件尚未配置代理' },
  'Các hồ sơ sẽ ngừng dùng proxy nhưng vẫn giữ lại thông tin proxy để bật lại sau này.': { en: 'The profiles will stop using the proxy but keep the proxy info to re-enable later.', ru: 'Профили перестанут использовать прокси, но сохранят данные прокси для повторного включения.', zh: '配置文件将停止使用代理，但保留代理信息以便日后重新启用。' },
  'Các ID cách nhau bởi dấu phẩy, khoảng…': { en: 'IDs separated by commas, spaces…', ru: 'ID, разделённые запятыми, пробелами…', zh: '用逗号、空格分隔的 ID…' },
  'Các proxy trong danh sách đã được thêm rồi': { en: 'The proxies in the list have already been added', ru: 'Прокси из списка уже добавлены', zh: '列表中的代理已被添加' },
  'Các ứng dụng đã mở từ [Ứng dụng - Ứng dụng nhóm] sẽ được cài đặt vào trình duyệt.': { en: 'Apps opened from [Apps - Group apps] will be installed into the browser.', ru: 'Приложения, открытые из [Приложения - Групповые приложения], будут установлены в браузер.', zh: '从[应用 - 分组应用]打开的应用将安装到浏览器中。' },
  'Cài đặt chung': { en: 'General settings', ru: 'Общие настройки', zh: '通用设置' },
  'Cài đặt quy trình': { en: 'Workflow settings', ru: 'Настройки процесса', zh: '流程设置' },
  'Cài đặt trình duyệt': { en: 'Browser settings', ru: 'Настройки браузера', zh: '浏览器设置' },
  'Cài đặt ứng dụng:': { en: 'App settings:', ru: 'Настройки приложения:', zh: '应用设置：' },
  'Català': { en: 'Català', ru: 'Català', zh: 'Català' },
  'Căn chỉnh tự động': { en: 'Auto align', ru: 'Автовыравнивание', zh: '自动对齐' },
  'Cần đăng nhập tài khoản dịch vụ': { en: 'Service account login required', ru: 'Требуется вход в сервисный аккаунт', zh: '需要登录服务账号' },
  'Cập nhật browser kernel': { en: 'Update browser kernel', ru: 'Обновить ядро браузера', zh: '更新浏览器内核' },
  'Cập nhật tag': { en: 'Update tag', ru: 'Обновить тег', zh: '更新标签' },
  'Cập nhật tài nguyên': { en: 'Update resource', ru: 'Обновить ресурс', zh: '更新资源' },
  'Cập nhật thất bại (kiểm tra mạng/URL)': { en: 'Update failed (check network/URL)', ru: 'Не удалось обновить (проверьте сеть/URL)', zh: '更新失败（请检查网络/URL）' },
  'Cập nhật thẻ': { en: 'Update tab', ru: 'Обновить вкладку', zh: '更新标签' },
  'Cập nhật thông tin của tài nguyên': { en: 'Update the resource information', ru: 'Обновить информацию о ресурсе', zh: '更新资源信息' },
  'Cấu hình': { en: 'Configuration', ru: 'Конфигурация', zh: '配置' },
  'Chạy': { en: 'Run', ru: 'Запустить', zh: '运行' },
  'chạy thì không theo thiết lập ở console đã cài sẵn': { en: 'runs but does not follow the pre-set console settings', ru: 'запускается, но не следует заранее заданным настройкам консоли', zh: '运行时不遵循控制台中预设的设置' },
  'Chặn quảng cáo, pop-up và banner trên mọi trang web.': { en: 'Block ads, pop-ups and banners on every website.', ru: 'Блокируйте рекламу, всплывающие окна и баннеры на любом сайте.', zh: '拦截所有网站上的广告、弹窗和横幅。' },
  'Chế độ': { en: 'Mode', ru: 'Режим', zh: '模式' },
  'Chế độ đọc': { en: 'Read mode', ru: 'Режим чтения', zh: '读取模式' },
  'Chế độ ghi': { en: 'Write mode', ru: 'Режим записи', zh: '写入模式' },
  'Chia sẻ': { en: 'Share', ru: 'Поделиться', zh: '分享' },
  'Chỉnh sửa nhóm': { en: 'Edit group', ru: 'Изменить группу', zh: '编辑分组' },
  'Chỉnh sửa Proxy': { en: 'Edit proxy', ru: 'Изменить прокси', zh: '编辑代理' },
  'Chỉnh sửa thẻ': { en: 'Edit tab', ru: 'Изменить вкладку', zh: '编辑标签' },
  'Chỉnh sửa thiết bị chưa được hỗ trợ': { en: 'Editing this device is not supported', ru: 'Редактирование этого устройства не поддерживается', zh: '暂不支持编辑此设备' },
  'Chỉnh sửa thông tin': { en: 'Edit information', ru: 'Изменить информацию', zh: '编辑信息' },
  'Chọn': { en: 'Select', ru: 'Выбрать', zh: '选择' },
  'Chọn hàng đầu tiên làm khóa': { en: 'Use the first row as keys', ru: 'Использовать первую строку как ключи', zh: '将第一行作为键' },
  'Chọn hồ sơ chạy tự động hóa': { en: 'Select profiles to run automation', ru: 'Выберите профили для запуска автоматизации', zh: '选择运行自动化的配置文件' },
  'Chọn ít nhất một thông tin': { en: 'Select at least one item', ru: 'Выберите хотя бы один пункт', zh: '至少选择一项信息' },
  'Chọn một tùy chọn từ menu dropdown': { en: 'Choose an option from the dropdown menu', ru: 'Выберите вариант из выпадающего меню', zh: '从下拉菜单中选择一个选项' },
  'Chọn nguồn dữ liệu': { en: 'Select data source', ru: 'Выберите источник данных', zh: '选择数据源' },
  'Chọn tất cả': { en: 'Select all', ru: 'Выбрать всё', zh: '全选' },
  'Chọn tệp excel': { en: 'Choose an Excel file', ru: 'Выберите файл Excel', zh: '选择 Excel 文件' },
  'Chọn tệp hình ảnh': { en: 'Choose an image file', ru: 'Выберите файл изображения', zh: '选择图片文件' },
  'Chọn tệp json': { en: 'Choose a JSON file', ru: 'Выберите файл JSON', zh: '选择 JSON 文件' },
  'Chọn tệp hoặc nhập đường dẫn': { en: 'Choose a file or enter a path', ru: 'Выберите файл или введите путь', zh: '选择文件或输入路径' },
  'Chọn thư mục hoặc nhập đường dẫn': { en: 'Choose a folder or enter a path', ru: 'Выберите папку или введите путь', zh: '选择文件夹或输入路径' },
  'Đường dẫn tệp mặc định': { en: 'Default file path', ru: 'Путь к файлу по умолчанию', zh: '默认文件路径' },
  'Đường dẫn thư mục mặc định': { en: 'Default folder path', ru: 'Путь к папке по умолчанию', zh: '默认文件夹路径' },
  'Nhập tên cấu hình': { en: 'Enter a config name', ru: 'Введите название конфигурации', zh: '输入配置名称' },
  'Tên cấu hình': { en: 'Config name', ru: 'Название конфигурации', zh: '配置名称' },
  'Chọn tệp quy trình (.json) đã xuất từ chức năng "Xuất quy trình".': { en: 'Choose a workflow file (.json) exported via "Export workflow".', ru: 'Выберите файл процесса (.json), экспортированный через «Экспорт процесса».', zh: '选择通过“导出流程”导出的流程文件（.json）。' },
  'Chọn tệp văn bản': { en: 'Choose a text file', ru: 'Выберите текстовый файл', zh: '选择文本文件' },
  'Chọn thẻ': { en: 'Select tab', ru: 'Выбрать вкладку', zh: '选择标签' },
  'chỗ gán': { en: 'assignment slot', ru: 'место присвоения', zh: '赋值处' },
  'Chồng lên': { en: 'Overlap', ru: 'Наложить', zh: '重叠' },
  'Chuỗi cookie': { en: 'Cookie string', ru: 'Строка cookie', zh: 'Cookie 字符串' },
  'Chuyển': { en: 'Move', ru: 'Переместить', zh: '转移' },
  'Chuyển chữ cái đầu của mỗi từ thành chữ in hoa': { en: 'Capitalize the first letter of each word', ru: 'Сделать первую букву каждого слова заглавной', zh: '将每个单词的首字母大写' },
  'Chuyển đi': { en: 'Move out', ru: 'Переместить', zh: '移出' },
  'Chuyển JSON String sang Javascript Object': { en: 'Convert a JSON string to a JavaScript object', ru: 'Преобразовать строку JSON в объект JavaScript', zh: '将 JSON 字符串转换为 JavaScript 对象' },
  'Chuyển sang Trang hoặc Trang cá nhân': { en: 'Switch to a Page or Profile', ru: 'Переключиться на Страницу или Профиль', zh: '切换到主页或个人主页' },
  'Chuyển tất cả thành chữ in hoa': { en: 'Convert everything to uppercase', ru: 'Преобразовать всё в верхний регистр', zh: '全部转换为大写' },
  'Chuyển thành chữ thường': { en: 'Convert to lowercase', ru: 'Преобразовать в нижний регистр', zh: '转换为小写' },
  'Chuyển theo': { en: 'Move by', ru: 'Переместить по', zh: '按…转移' },
  'Chưa': { en: 'Not yet', ru: 'Ещё нет', zh: '尚未' },
  'Chưa chạy': { en: 'Not run yet', ru: 'Ещё не запущено', zh: '未运行' },
  'chưa chia nhóm': { en: 'ungrouped', ru: 'без группы', zh: '未分组' },
  'Chưa chọn lịch nào': { en: 'No schedule selected', ru: 'Расписание не выбрано', zh: '未选择任何计划' },
  'Chưa chọn tệp': { en: 'No file selected', ru: 'Файл не выбран', zh: '未选择文件' },
  'Chưa có dữ liệu IP, hãy bấm "Kiểm tra proxy" trước': { en: 'No IP data yet, please click "Check proxy" first', ru: 'Данных об IP ещё нет, сначала нажмите «Проверить прокси»', zh: '暂无 IP 数据，请先点击“检测代理”' },
  'Chưa có hồ sơ': { en: 'No profiles yet', ru: 'Профилей пока нет', zh: '暂无配置文件' },
  'Chưa có hồ sơ nào': { en: 'No profiles yet', ru: 'Профилей пока нет', zh: '还没有配置文件' },
  // Lưới rỗng khi đang lọc "Đã ghim đầu trang" mà chưa ghim gì.
  'Chưa ghim hồ sơ nào lên đầu trang': { en: 'No profiles pinned to top yet', ru: 'Пока ни один профиль не закреплён сверху', zh: '还没有置顶任何配置文件' },
  'Chưa có lịch nào. Mở một nhiệm vụ và bấm "Lên lịch" để tạo lịch.': { en: 'No schedules yet. Open a task and click "Schedule" to create one.', ru: 'Расписаний пока нет. Откройте задачу и нажмите «Запланировать», чтобы создать.', zh: '还没有任何计划。打开一个任务并点击“计划”来创建。' },
  'Chưa có nhật ký. Nhật ký debug sẽ hiển thị khi bạn chạy gỡ lỗi quy trình.': { en: 'No logs yet. Debug logs appear when you run the workflow in debug mode.', ru: 'Логов пока нет. Отладочные логи появятся при запуске процесса в режиме отладки.', zh: '暂无日志。调试流程时将显示调试日志。' },
  'Chưa có nhiệm vụ nào. Tạo nhiệm vụ từ trang "Hồ sơ" → nút "Tự động hóa".': { en: 'No tasks yet. Create a task from the "Profiles" page → "Automation" button.', ru: 'Задач пока нет. Создайте задачу на странице «Профили» → кнопка «Автоматизация».', zh: '还没有任务。请从“配置文件”页面 → “自动化”按钮创建任务。' },
  'Chưa có tài khoản?': { en: 'No account yet?', ru: 'Ещё нет аккаунта?', zh: '还没有账号？' },
  'Chưa có thẻ nào': { en: 'No tags yet', ru: 'Тегов пока нет', zh: '还没有标签' },
  'Chưa có thông tin proxy để sao chép': { en: 'No proxy info to copy', ru: 'Нет данных прокси для копирования', zh: '没有可复制的代理信息' },
  'Có thể thiết lập': { en: 'Configurable', ru: 'Можно настроить', zh: '可设置' },
  'Copy mẫu': { en: 'Copy template', ru: 'Копировать шаблон', zh: '复制模板' },
  'Cùng một dòng': { en: 'Same line', ru: 'На той же строке', zh: '同一行' },
  'Cuối cùng': { en: 'Last', ru: 'Последний', zh: '最后' },
  'Cuộn chuột theo': { en: 'Scroll by', ru: 'Прокрутка по', zh: '按…滚动' },
  'Cực rộng': { en: 'Extra wide', ru: 'Очень широкий', zh: '超宽' },
  'cứng': { en: 'noise', ru: 'шум', zh: '噪声' },
  'Dán JSON': { en: 'Paste JSON', ru: 'Вставить JSON', zh: '粘贴 JSON' },
  'Dán nội dung JSON của quy trình vào đây…': { en: 'Paste the workflow JSON content here…', ru: 'Вставьте JSON-содержимое процесса сюда…', zh: '在此粘贴流程的 JSON 内容…' },
  'Dán văn bản': { en: 'Paste text', ru: 'Вставить текст', zh: '粘贴文本' },
  'Danh sách phần tử HTML': { en: 'HTML element list', ru: 'Список HTML-элементов', zh: 'HTML 元素列表' },
  'Danh sách Proxy': { en: 'Proxy list', ru: 'Список прокси', zh: '代理列表' },
  'Danh sách thẻ': { en: 'Tag list', ru: 'Список тегов', zh: '标签列表' },
  'Dấu phân cách': { en: 'Separator', ru: 'Разделитель', zh: '分隔符' },
  'Dấu phẩy': { en: 'Comma', ru: 'Запятая', zh: '逗号' },
  'Dịch nhanh trang web và đoạn văn bản được chọn.': { en: 'Quickly translate a web page and selected text.', ru: 'Быстро переводите веб-страницу и выделенный текст.', zh: '快速翻译网页和选中的文本。' },
  'Dòng mới': { en: 'New line', ru: 'Новая строка', zh: '换行' },
  'Dùng biểu thức này để lấy dữ liệu của vòng lặp hiện tại': { en: 'Use this expression to get the data of the current loop', ru: 'Используйте это выражение, чтобы получить данные текущего цикла', zh: '使用此表达式获取当前循环的数据' },
  'Dùng biểu thức này để lấy số thứ tự của vòng lặp hiện tại': { en: 'Use this expression to get the index of the current loop', ru: 'Используйте это выражение, чтобы получить номер текущего цикла', zh: '使用此表达式获取当前循环的序号' },
  'Dữ liệu cần lấy': { en: 'Data to get', ru: 'Данные для получения', zh: '要获取的数据' },
  'Dữ liệu cập nhật': { en: 'Data to update', ru: 'Данные для обновления', zh: '更新的数据' },
  'Dữ liệu nhiệm vụ có thể được xem và quản lý trên nhiều thiết bị; việc thực thi nhiệm vụ và bật nhiệm vụ theo lịch chỉ có hiệu lực trên thiết bị hiện tại.': { en: 'Task data can be viewed and managed on multiple devices; task execution and scheduled tasks only take effect on the current device.', ru: 'Данные задач можно просматривать и управлять ими на нескольких устройствах; выполнение задач и запуск по расписанию действуют только на текущем устройстве.', zh: '任务数据可在多个设备上查看和管理；任务执行和定时任务仅在当前设备上生效。' },
  'Dữ liệu phần tử': { en: 'Element data', ru: 'Данные элемента', zh: '元素数据' },
  'Dữ liệu tài nguyên': { en: 'Resource data', ru: 'Данные ресурса', zh: '资源数据' },
  'Dữ liệu trả về': { en: 'Returned data', ru: 'Возвращаемые данные', zh: '返回的数据' },
  'Dựa trên IP': { en: 'Based on IP', ru: 'На основе IP', zh: '基于 IP' },
  'Dựa trên ngôn ngữ': { en: 'Based on language', ru: 'На основе языка', zh: '基于语言' },
  'Dựa trên User-Agent': { en: 'Based on User-Agent', ru: 'На основе User-Agent', zh: '基于 User-Agent' },
  'Đã bật lịch': { en: 'Schedule enabled', ru: 'Расписание включено', zh: '已启用计划' },
  'Đã bỏ ghim': { en: 'Unpinned', ru: 'Откреплено', zh: '已取消置顶' },
  'Đã cập nhật': { en: 'Updated', ru: 'Обновлено', zh: '已更新' },
  'Đã cập nhật IP': { en: 'IP updated', ru: 'IP обновлён', zh: 'IP 已更新' },
  'Đã cập nhật lịch': { en: 'Schedule updated', ru: 'Расписание обновлено', zh: '计划已更新' },
  'Đã cập nhật thẻ': { en: 'Tag updated', ru: 'Тег обновлён', zh: '标签已更新' },
  'Đã chọn n/total': { en: 'Selected n/total', ru: 'Выбрано n/total', zh: '已选 n/total' },
  'Đã có tài khoản?': { en: 'Already have an account?', ru: 'Уже есть аккаунт?', zh: '已有账号？' },
  'Đã dừng đồng bộ.': { en: 'Sync stopped.', ru: 'Синхронизация остановлена.', zh: '已停止同步。' },
  'Đã dừng quy trình': { en: 'Workflow stopped', ru: 'Процесс остановлен', zh: '已停止流程' },
  'Đã đặt hàng': { en: 'Ordered', ru: 'Заказано', zh: '已下单' },
  'Đã đóng': { en: 'Closed', ru: 'Закрыто', zh: '已关闭' },
  'Đã ghim': { en: 'Pinned', ru: 'Закреплено', zh: '已置顶' },
  // Mục trong combobox sắp xếp của trang Hồ sơ: LỌC ra riêng các hồ sơ đã ghim (nên tiếng
  // Anh là "Pinned to top" ở dạng nhãn bộ lọc, khác 'Đã ghim lên đầu trang' ở dưới - khoá
  // đó là câu thông báo toast sau khi ghim).
  'Đã ghim đầu trang': { en: 'Pinned to top', ru: 'Закреплённые сверху', zh: '已置顶的' },
  'Đã ghim lên đầu trang': { en: 'Pinned to top', ru: 'Закреплено сверху', zh: '已置顶' },
  'Đã lưu nhóm': { en: 'Group saved', ru: 'Группа сохранена', zh: '分组已保存' },
  'Đã lưu proxy': { en: 'Proxy saved', ru: 'Прокси сохранён', zh: '代理已保存' },
  'Đã lưu quy trình': { en: 'Workflow saved', ru: 'Процесс сохранён', zh: '流程已保存' },
  'Đã lưu thông tin luồng': { en: 'Flow info saved', ru: 'Данные потока сохранены', zh: '流程信息已保存' },
  'Đã nhập quy trình': { en: 'Workflow imported', ru: 'Процесс импортирован', zh: '流程已导入' },
  'Đã sao chép biểu thức': { en: 'Expression copied', ru: 'Выражение скопировано', zh: '已复制表达式' },
  'Đã sao chép Profile ID': { en: 'Profile ID copied', ru: 'ID профиля скопирован', zh: '已复制配置文件 ID' },
  'Đã sao chép proxy': { en: 'Proxy copied', ru: 'Прокси скопирован', zh: '已复制代理' },
  'Đã sắp xếp node': { en: 'Nodes arranged', ru: 'Узлы упорядочены', zh: '已排列节点' },
  'Đã tạo bản sao quy trình': { en: 'Workflow duplicated', ru: 'Копия процесса создана', zh: '已创建流程副本' },
  'Đã tắt bước này': { en: 'This step is disabled', ru: 'Этот шаг отключён', zh: '此步骤已禁用' },
  'Đã tắt lịch': { en: 'Schedule disabled', ru: 'Расписание отключено', zh: '已禁用计划' },
  'Đã thêm Proxy:0': { en: 'Proxies added: 0', ru: 'Добавлено прокси: 0', zh: '已添加代理：0' },
  'Đã xóa lịch': { en: 'Schedule deleted', ru: 'Расписание удалено', zh: '已删除计划' },
  'Đã xóa nhóm': { en: 'Group deleted', ru: 'Группа удалена', zh: '已删除分组' },
  'Đã xóa thẻ': { en: 'Tag deleted', ru: 'Тег удалён', zh: '已删除标签' },
  'Đã xuất quy trình': { en: 'Workflow exported', ru: 'Процесс экспортирован', zh: '已导出流程' },
  'Đang bật đồng bộ…': { en: 'Starting sync…', ru: 'Запуск синхронизации…', zh: '正在开启同步…' },
  'Đang cập nhật proxy…': { en: 'Updating proxy…', ru: 'Обновление прокси…', zh: '正在更新代理…' },
  'Đang dừng…': { en: 'Stopping…', ru: 'Остановка…', zh: '正在停止…' },
  'Đang đăng nhập…': { en: 'Signing in…', ru: 'Вход…', zh: '正在登录…' },
  'Đang kiểm tra': { en: 'Checking', ru: 'Проверка', zh: '检测中' },
  'Đang kiểm tra IP…': { en: 'Checking IP…', ru: 'Проверка IP…', zh: '正在检测 IP…' },
  'Đang kiểm tra proxy…': { en: 'Checking proxy…', ru: 'Проверка прокси…', zh: '正在检测代理…' },
  'Đang kiểm tra…': { en: 'Checking…', ru: 'Проверка…', zh: '检测中…' },
  'đang mở': { en: 'open', ru: 'открыт', zh: '打开中' },
  'Đang mở cửa sổ…': { en: 'Opening window…', ru: 'Открытие окна…', zh: '正在打开窗口…' },
  'đang nối': { en: 'connecting', ru: 'подключение', zh: '连接中' },
  'Đang tải…': { en: 'Loading…', ru: 'Загрузка…', zh: '加载中…' },
  'Đang tạo…': { en: 'Creating…', ru: 'Создание…', zh: '创建中…' },
  'Đăng nhập': { en: 'Sign in', ru: 'Войти', zh: '登录' },
  'Đăng nhập thành công': { en: 'Signed in successfully', ru: 'Вход выполнен успешно', zh: '登录成功' },
  'Đăng nhập thất bại': { en: 'Sign-in failed', ru: 'Не удалось войти', zh: '登录失败' },
  'Đăng nhập vào tài khoản CGTBrowser của bạn': { en: 'Sign in to your CGTBrowser account', ru: 'Войдите в свой аккаунт CGTBrowser', zh: '登录您的 CGTBrowser 账号' },
  'Đăng xuất tài khoản trên các thiết bị khác, trừ thiết bị hiện tại ra': { en: 'Sign out of the account on other devices, except the current one', ru: 'Выйти из аккаунта на других устройствах, кроме текущего', zh: '在其他设备上登出账号，当前设备除外' },
  'Đặt lại': { en: 'Reset', ru: 'Сбросить', zh: '重置' },
  'Đặt lại khoảng ngày': { en: 'Reset date range', ru: 'Сбросить диапазон дат', zh: '重置日期范围' },
  'Đầu tiên': { en: 'First', ru: 'Первый', zh: '第一个' },
  'Để trống sẽ tự đặt tên khi lưu': { en: 'Leave blank to auto-name on save', ru: 'Оставьте пустым - имя задастся автоматически при сохранении', zh: '留空则保存时自动命名' },
  'Đề xuất cho bạn': { en: 'Recommended for you', ru: 'Рекомендуем вам', zh: '为你推荐' },
  'Đích di chuyển': { en: 'Move destination', ru: 'Место назначения', zh: '移动目标' },
  'Định dạng được hỗ trợ: FOLDER, ZIP': { en: 'Supported formats: FOLDER, ZIP', ru: 'Поддерживаемые форматы: FOLDER, ZIP', zh: '支持的格式：FOLDER、ZIP' },
  'Định dạng: JSON, Netscape, Name=Value': { en: 'Format: JSON, Netscape, Name=Value', ru: 'Формат: JSON, Netscape, Name=Value', zh: '格式：JSON、Netscape、Name=Value' },
  'Đỏ': { en: 'Red', ru: 'Красный', zh: '红色' },
  'Đọc': { en: 'Read', ru: 'Чтение', zh: '读取' },
  'Đóng theo': { en: 'Close by', ru: 'Закрыть по', zh: '按…关闭' },
  'Độ phân giải → Được xác định trước': { en: 'Resolution → Predefined', ru: 'Разрешение → Предопределённое', zh: '分辨率 → 预定义' },
  'Đổi ngôn ngữ': { en: 'Change language', ru: 'Сменить язык', zh: '更改语言' },
  'Đổi tên tài khoản': { en: 'Rename account', ru: 'Переименовать аккаунт', zh: '重命名账号' },
  'Đợi': { en: 'Wait', ru: 'Ожидание', zh: '等待' },
  'Đợi đến khi sự kiện được kích hoạt': { en: 'Wait until the event is triggered', ru: 'Ждать, пока событие не сработает', zh: '等待直到事件被触发' },
  'Đợi kết quả': { en: 'Wait for result', ru: 'Ждать результат', zh: '等待结果' },
  'Đợi theo thời gian': { en: 'Wait by time', ru: 'Ждать по времени', zh: '按时间等待' },
  'Đưa biến vào': { en: 'Pass variable in', ru: 'Передать переменную', zh: '传入变量' },
  'Được chỉ định': { en: 'Specified', ru: 'Указано', zh: '指定' },
  'Được xác định trước': { en: 'Predefined', ru: 'Предопределённый', zh: '预定义' },
  'Đường dẫn file json xác thực': { en: 'Path to the authentication JSON file', ru: 'Путь к JSON-файлу аутентификации', zh: '认证 JSON 文件的路径' },
  'Email chia sẻ': { en: 'Sharing email', ru: 'Email для доступа', zh: '分享邮箱' },
  'Email hoặc mật khẩu không đúng': { en: 'Incorrect email or password', ru: 'Неверный email или пароль', zh: '邮箱或密码不正确' },
  'Email này đã được đăng ký': { en: 'This email is already registered', ru: 'Этот email уже зарегистрирован', zh: '该邮箱已被注册' },
  'Enter Văn bản tiếp theo / Enter Xuống dòng': { en: 'Enter Next text / Enter New line', ru: 'Enter - следующий текст / Enter - новая строка', zh: 'Enter 下一段文本 / Enter 换行' },
  'Español (Latinoamérica)': { en: 'Español (Latinoamérica)', ru: 'Español (Latinoamérica)', zh: 'Español (Latinoamérica)' },
  'Español (México)': { en: 'Español (México)', ru: 'Español (México)', zh: 'Español (México)' },
  'Font chữ': { en: 'Font', ru: 'Шрифт', zh: '字体' },
  'Gạch đứng |': { en: 'Vertical bar |', ru: 'Вертикальная черта |', zh: '竖线 |' },
  'Gần tôi': { en: 'Near me', ru: 'Рядом со мной', zh: '附近' },
  'Ghi chú...': { en: 'Note...', ru: 'Заметка...', zh: '备注…' },
  'giá trị': { en: 'value', ru: 'значение', zh: '值' },
  'Giá trị tìm kiếm': { en: 'Search value', ru: 'Искомое значение', zh: '搜索值' },
  'Giây': { en: 'Second', ru: 'Секунда', zh: '秒' },
  'Giữ nội dung tag': { en: 'Keep tag content', ru: 'Сохранить содержимое тега', zh: '保留标签内容' },
  'Giữ trình duyệt': { en: 'Keep the browser', ru: 'Оставить браузер', zh: '保留浏览器' },
  'Gõ văn bản này vào tất cả cửa sổ như con người': { en: 'Type this text into all windows like a human', ru: 'Печатать этот текст во всех окнах как человек', zh: '像真人一样在所有窗口中输入此文本' },
  'Hàng ngang': { en: 'Horizontal row', ru: 'Горизонтальный ряд', zh: '横排' },
  'Hành động:': { en: 'Action:', ru: 'Действие:', zh: '操作：' },
  'Hãy bắt đầu đồng bộ trước khi gõ.': { en: 'Please start sync before typing.', ru: 'Пожалуйста, начните синхронизацию перед вводом.', zh: '请先开始同步再输入。' },
  'Hãy bắt đầu đồng bộ trước.': { en: 'Please start sync first.', ru: 'Сначала начните синхронизацию.', zh: '请先开始同步。' },
  'Hãy chọn': { en: 'Please choose', ru: 'Пожалуйста, выберите', zh: '请选择' },
  'Hãy chọn ít nhất một quy trình': { en: 'Please select at least one workflow', ru: 'Выберите хотя бы один процесс', zh: '请至少选择一个流程' },
  'Hãy chọn nhóm.': { en: 'Please choose a group.', ru: 'Пожалуйста, выберите группу.', zh: '请选择分组。' },
  'Hãy chọn tệp quy trình': { en: 'Please choose a workflow file', ru: 'Пожалуйста, выберите файл процесса', zh: '请选择流程文件' },
  'Hãy copy email dưới và share bảng tính của bạn cho email đã copy. Xem hướng dẫn': { en: 'Copy the email below and share your spreadsheet with it. See the guide', ru: 'Скопируйте email ниже и предоставьте доступ к таблице этому адресу. См. руководство', zh: '复制下方邮箱，并将你的电子表格分享给该邮箱。查看指南' },
  'Hãy dán nội dung quy trình': { en: 'Please paste the workflow content', ru: 'Пожалуйста, вставьте содержимое процесса', zh: '请粘贴流程内容' },
  'Hãy nhập biến để lưu kết quả': { en: 'Please enter a variable to store the result', ru: 'Введите переменную для сохранения результата', zh: '请输入用于保存结果的变量' },
  'Hãy nhập bộ chọn phần tử, ví dụ #...': { en: 'Enter an element selector, e.g. #...', ru: 'Введите селектор элемента, например #...', zh: '请输入元素选择器，例如 #…' },
  'Hãy nhập mô tả tóm tắt': { en: 'Please enter a short description', ru: 'Введите краткое описание', zh: '请输入简要描述' },
  'Hãy nhập notes': { en: 'Please enter notes', ru: 'Введите заметки', zh: '请输入备注' },
  'Hãy nhập nội dung': { en: 'Please enter content', ru: 'Введите содержимое', zh: '请输入内容' },
  'Hãy nhập tên nhóm': { en: 'Please enter a group name', ru: 'Введите название группы', zh: '请输入分组名称' },
  'Hãy nhập tên nhóm mới': { en: 'Please enter a new group name', ru: 'Введите новое название группы', zh: '请输入新的分组名称' },
  'Hằng số PROFILE_ID, PROFILE_NAME, GROUP_NAME, PROXY_INFO': { en: 'Constants PROFILE_ID, PROFILE_NAME, GROUP_NAME, PROXY_INFO', ru: 'Константы PROFILE_ID, PROFILE_NAME, GROUP_NAME, PROXY_INFO', zh: '常量 PROFILE_ID、PROFILE_NAME、GROUP_NAME、PROXY_INFO' },
  'Hệ thống tạo mặc định': { en: 'Created by the system by default', ru: 'Создано системой по умолчанию', zh: '系统默认创建' },
  'Hệ thống tự thêm số thứ tự vào sau tên.': { en: 'The system automatically appends a sequence number to the name.', ru: 'Система автоматически добавляет порядковый номер после имени.', zh: '系统会自动在名称后附加序号。' },
  'Hết giờ': { en: 'Timed out', ru: 'Время истекло', zh: '超时' },
  'Hiển thị dữ liệu JSON đẹp, dễ đọc và gấp gọn.': { en: 'Display JSON data neatly, readable and collapsible.', ru: 'Отображение данных JSON аккуратно, удобно для чтения и со сворачиванием.', zh: '以美观、易读且可折叠的方式显示 JSON 数据。' },
  'Hiển thị hình ảnh': { en: 'Show images', ru: 'Показывать изображения', zh: '显示图片' },
  'Hình ảnh': { en: 'Image', ru: 'Изображение', zh: '图片' },
  'Hoàn tác (Ctrl+Z)': { en: 'Undo (Ctrl+Z)', ru: 'Отменить (Ctrl+Z)', zh: '撤销 (Ctrl+Z)' },
  'Hoàn thành nhiệm vụ': { en: 'Complete the task', ru: 'Завершить задачу', zh: '完成任务' },
  'Hỏi mỗi lần': { en: 'Ask every time', ru: 'Спрашивать каждый раз', zh: '每次询问' },
  'host:port:user:pass hoặc host:port  (mỗi dòng 1 proxy)': { en: 'host:port:user:pass or host:port  (one proxy per line)', ru: 'host:port:user:pass или host:port  (по одному прокси в строке)', zh: 'host:port:user:pass 或 host:port（每行一个代理）' },
  'Hồ sơ chưa cấu hình proxy': { en: 'Profile has no proxy configured', ru: 'У профиля не настроен прокси', zh: '配置文件未配置代理' },
  'Hồ sơ đã chọn:': { en: 'Selected profiles:', ru: 'Выбранные профили:', zh: '已选配置文件：' },
  'Hợp nhất': { en: 'Merge', ru: 'Объединить', zh: '合并' },
  'Hợp nhất cookie': { en: 'Merge cookies', ru: 'Объединить cookie', zh: '合并 Cookie' },
  'ID Bài viết': { en: 'Post ID', ru: 'ID публикации', zh: '帖子 ID' },
  'ID Bảng tính': { en: 'Spreadsheet ID', ru: 'ID таблицы', zh: '电子表格 ID' },
  'ID hoặc tên hồ sơ': { en: 'Profile ID or name', ru: 'ID или имя профиля', zh: '配置文件 ID 或名称' },
  'ID Nhóm': { en: 'Group ID', ru: 'ID группы', zh: '分组 ID' },
  'ID Trang hoặc Trang Cá Nhân': { en: 'Page or Profile ID', ru: 'ID Страницы или Профиля', zh: '主页或个人主页 ID' },
  'In ra cửa sổ nhật ký các giá trị ở dạng string, number hay object': { en: 'Print values to the log window as string, number or object', ru: 'Выводить значения в окно журнала как строку, число или объект', zh: '将字符串、数字或对象类型的值打印到日志窗口' },
  'Íslenska': { en: 'Íslenska', ru: 'Íslenska', zh: 'Íslenska' },
  'Kéo tùy chọn thao tác vào đây': { en: 'Drag an action option here', ru: 'Перетащите сюда вариант действия', zh: '将操作选项拖到这里' },
  'Kéo vào nhóm': { en: 'Drag into group', ru: 'Перетащить в группу', zh: '拖入分组' },
  'Kết bạn theo UID': { en: 'Add friends by UID', ru: 'Добавить друзей по UID', zh: '按 UID 加好友' },
  'Kết quả tìm kiếm': { en: 'Search results', ru: 'Результаты поиска', zh: '搜索结果' },
  'Kết thúc': { en: 'End', ru: 'Конец', zh: '结束' },
  'Khi bật tính năng này, mỗi lần khởi động sẽ bỏ qua một số cài đặt hiện có và tạo dấu vân tay mới ngẫu nhiên': { en: 'When enabled, each launch skips some existing settings and generates a new random fingerprint', ru: 'Когда включено, каждый запуск пропускает некоторые текущие настройки и создаёт новый случайный отпечаток', zh: '启用后，每次启动都会跳过部分现有设置并随机生成新的指纹' },
  'Khi xảy ra lỗi, dừng quy trình': { en: 'On error, stop the workflow', ru: 'При ошибке остановить процесс', zh: '发生错误时，停止流程' },
  'Khi xảy ra lỗi, tiếp tục thực thi': { en: 'On error, continue execution', ru: 'При ошибке продолжить выполнение', zh: '发生错误时，继续执行' },
  'Khoảng cách nhẫu nhiên giữa các lần chấp nhận': { en: 'Random interval between accepts', ru: 'Случайный интервал между принятиями', zh: '每次接受之间的随机间隔' },
  'Khoảng cách nhẫu nhiên giữa các lần mời': { en: 'Random interval between invites', ru: 'Случайный интервал между приглашениями', zh: '每次邀请之间的随机间隔' },
  'Khoảng cách nhẫu nhiên giữa các lần quét': { en: 'Random interval between scans', ru: 'Случайный интервал между сканированиями', zh: '每次扫描之间的随机间隔' },
  'Khoảng thời gian giữa các lần gõ (số giây)': { en: 'Interval between keystrokes (seconds)', ru: 'Интервал между нажатиями (в секундах)', zh: '每次输入之间的间隔（秒）' },
  'Khoảng thời gian phải lớn hơn 0 phút': { en: 'The interval must be greater than 0 minutes', ru: 'Интервал должен быть больше 0 минут', zh: '间隔必须大于 0 分钟' },
  'Khoảng trắng': { en: 'Whitespace', ru: 'Пробел', zh: '空白' },
  'Không cần cấu hình': { en: 'No configuration needed', ru: 'Настройка не требуется', zh: '无需配置' },
  'Không chỉnh được kích cỡ.': { en: 'Could not resize.', ru: 'Не удалось изменить размер.', zh: '无法调整大小。' },
  'không có': { en: 'none', ru: 'нет', zh: '无' },
  'Không có cửa sổ nào để chỉnh kích cỡ.': { en: 'No windows to resize.', ru: 'Нет окон для изменения размера.', zh: '没有可调整大小的窗口。' },
  'Không có cửa sổ nào để sắp xếp.': { en: 'No windows to arrange.', ru: 'Нет окон для упорядочивания.', zh: '没有可排列的窗口。' },
  'Không có dữ liệu để sao chép': { en: 'No data to copy', ru: 'Нет данных для копирования', zh: '没有可复制的数据' },
  'Không có loại nhóm': { en: 'No group type', ru: 'Нет типа группы', zh: '无分组类型' },
  'Không có lưu lượng khả dụng': { en: 'No available traffic', ru: 'Нет доступного трафика', zh: '没有可用流量' },
  'Không có proxy hợp lệ để nhập': { en: 'No valid proxy to import', ru: 'Нет корректного прокси для импорта', zh: '没有可导入的有效代理' },
  'Không có proxy mới (đã trùng)': { en: 'No new proxies (duplicates)', ru: 'Нет новых прокси (дубликаты)', zh: '没有新代理（重复）' },
  'Không có thẻ khớp': { en: 'No matching tags', ru: 'Нет подходящих тегов', zh: '没有匹配的标签' },
  'Không còn nội dung': { en: 'No more content', ru: 'Больше нет содержимого', zh: '没有更多内容' },
  'Không dán được văn bản.': { en: 'Could not paste text.', ru: 'Не удалось вставить текст.', zh: '无法粘贴文本。' },
  'Không đọc được tệp': { en: 'Could not read the file', ru: 'Не удалось прочитать файл', zh: '无法读取文件' },
  'Không được để trống': { en: 'Cannot be empty', ru: 'Не может быть пустым', zh: '不能为空' },
  'Không gian': { en: 'Space', ru: 'Пробел', zh: '空格' },
  'Không gõ được văn bản.': { en: 'Could not type text.', ru: 'Не удалось ввести текст.', zh: '无法输入文本。' },
  'Không kết nối được máy chủ. Kiểm tra server đã chạy chưa.': { en: 'Could not connect to the server. Check whether the server is running.', ru: 'Не удалось подключиться к серверу. Проверьте, запущен ли сервер.', zh: '无法连接服务器。请检查服务器是否已运行。' },
  'Không kết nối được proxy': { en: 'Could not connect to the proxy', ru: 'Не удалось подключиться к прокси', zh: '无法连接代理' },
  'Không lấy được IP (kiểm tra proxy/mạng)': { en: 'Could not get IP (check proxy/network)', ru: 'Не удалось получить IP (проверьте прокси/сеть)', zh: '无法获取 IP（请检查代理/网络）' },
  'Không mở đủ cửa sổ để đồng bộ. Vui lòng thử lại.': { en: 'Not enough windows opened to sync. Please try again.', ru: 'Открыто недостаточно окон для синхронизации. Повторите попытку.', zh: '打开的窗口不足以同步。请重试。' },
  'Không mở trình duyệt': { en: 'Do not open the browser', ru: 'Не открывать браузер', zh: '不打开浏览器' },
  'không phải bất kỳ': { en: 'not any', ru: 'ни один', zh: '非任意' },
  'Không sao chép được': { en: 'Could not copy', ru: 'Не удалось скопировать', zh: '无法复制' },
  'Không sắp xếp được cửa sổ.': { en: 'Could not arrange windows.', ru: 'Не удалось упорядочить окна.', zh: '无法排列窗口。' },
  'Không tải được danh sách hồ sơ (lỗi cơ sở dữ liệu).': { en: 'Could not load the profile list (database error).', ru: 'Не удалось загрузить список профилей (ошибка базы данных).', zh: '无法加载配置文件列表（数据库错误）。' },
  'Không tải được màn hình:': { en: 'Could not load screen:', ru: 'Не удалось загрузить экран:', zh: '无法加载页面：' },
  'Không tải được nhóm:': { en: 'Could not load groups:', ru: 'Не удалось загрузить группы:', zh: '无法加载分组：' },
  'Không tải được quy trình của nhiệm vụ': { en: 'Could not load the task workflow', ru: 'Не удалось загрузить процесс задачи', zh: '无法加载任务流程' },
  'Không tải được Swagger UI': { en: 'Could not load Swagger UI', ru: 'Не удалось загрузить Swagger UI', zh: '无法加载 Swagger UI' },
  // ── Tài liệu API: nội dung /v3/api-docs (main/local-api.js) - views/api.js dịch TỪNG ĐOẠN (tách theo dòng trống,
  //    đoạn có xuống dòng thì tách từng dòng) bằng t() lúc nạp tài liệu. Sửa câu trong local-api.js thì sửa khoá ở đây.
  //    Phần thay đổi theo máy (danh sách nhân đã cài, chú thích ví dụ JSON) dịch bằng cụm từ ở views/api.js (API_PHRASES).
  "Hệ thống": { en: "System", ru: "Система", zh: "系统" },
  "Kiểm tra API có đang chạy không": { en: "Check whether the API is running", ru: "Проверить, работает ли API", zh: "检查 API 是否正在运行" },
  "Quản lý & điều khiển hồ sơ": { en: "Manage & control profiles", ru: "Управление профилями", zh: "管理和控制配置文件" },
  "Chạy quy trình tự động hóa (RPA)": { en: "Run automation workflows (RPA)", ru: "Запуск процессов автоматизации (RPA)", zh: "运行自动化流程（RPA）" },
  "Trạng thái API": { en: "API status", ru: "Состояние API", zh: "API 状态" },
  "Tool nên gọi endpoint này TRƯỚC TIÊN để biết ứng dụng có đang mở và đã đăng nhập chưa.": { en: "Tools should call this endpoint FIRST to find out whether the app is open and signed in.", ru: "Инструментам следует вызывать этот endpoint ПЕРВЫМ, чтобы узнать, открыто ли приложение и выполнен ли вход.", zh: "工具应当首先调用此 endpoint，以确认应用是否已打开并已登录。" },
  "API đang chạy.": { en: "The API is running.", ru: "API работает.", zh: "API 正在运行。" },
  "Danh sách hồ sơ": { en: "List profiles", ru: "Список профилей", zh: "配置文件列表" },
  "Danh sách hồ sơ.": { en: "List of profiles.", ru: "Список профилей.", zh: "配置文件列表。" },
  "Hồ sơ vừa tạo.": { en: "The newly created profile.", ru: "Только что созданный профиль.", zh: "新创建的配置文件。" },
  "Thiếu/sai tham số.": { en: "Missing or invalid parameters.", ru: "Параметры отсутствуют или неверны.", zh: "参数缺失或无效。" },
  "Máy chủ từ chối: `QUOTA_EXCEEDED` (hết chỗ hồ sơ của gói), `CREATE_RATE_EXCEEDED` (hết lượt tạo hôm nay), `SUBSCRIPTION_EXPIRED`, `NO_ACTIVE_PLAN`, `NO_PERMISSION`. Mã cụ thể nằm ở trường `code`.": { en: "Rejected by the server: `QUOTA_EXCEEDED` (no profile slots left on your plan), `CREATE_RATE_EXCEEDED` (daily creation limit reached), `SUBSCRIPTION_EXPIRED`, `NO_ACTIVE_PLAN`, `NO_PERMISSION`. The exact code is in the `code` field.", ru: "Сервер отклонил запрос: `QUOTA_EXCEEDED` (в тарифе закончились места для профилей), `CREATE_RATE_EXCEEDED` (исчерпан лимит создания на сегодня), `SUBSCRIPTION_EXPIRED`, `NO_ACTIVE_PLAN`, `NO_PERMISSION`. Точный код находится в поле `code`.", zh: "服务器拒绝：`QUOTA_EXCEEDED`（套餐的配置文件名额已用完）、`CREATE_RATE_EXCEEDED`（今日创建次数已用完）、`SUBSCRIPTION_EXPIRED`、`NO_ACTIVE_PLAN`、`NO_PERMISSION`。具体代码见 `code` 字段。" },
  "`SERVER_UNREACHABLE` - chưa đăng nhập hoặc không gọi tới được máy chủ.": { en: "`SERVER_UNREACHABLE` - not signed in, or the server could not be reached.", ru: "`SERVER_UNREACHABLE` - вход не выполнен или сервер недоступен.", zh: "`SERVER_UNREACHABLE` - 未登录，或无法连接到服务器。" },
  "Lấy 1 hồ sơ": { en: "Get one profile", ru: "Получить профиль", zh: "获取单个配置文件" },
  "Thông tin hồ sơ.": { en: "Profile details.", ru: "Сведения о профиле.", zh: "配置文件信息。" },
  "Không tìm thấy.": { en: "Not found.", ru: "Не найдено.", zh: "未找到。" },
  "Hồ sơ sau cập nhật.": { en: "The profile after the update.", ru: "Профиль после обновления.", zh: "更新后的配置文件。" },
  "Xoá hồ sơ (vào thùng rác)": { en: "Delete a profile (move to trash)", ru: "Удалить профиль (в корзину)", zh: "删除配置文件（移入回收站）" },
  "Chuyển hồ sơ vào thùng rác. Dữ liệu và thư mục hồ sơ vẫn còn nguyên nên KHÔI PHỤC lại được trong ứng dụng. Muốn xoá hẳn và thu hồi dung lượng đĩa thì dùng `DELETE /api/v1/profiles/{id}/permanent`.": { en: "Moves the profile to the trash. Its data and folder stay intact, so it can be RESTORED in the app. To delete it for good and free the disk space, use `DELETE /api/v1/profiles/{id}/permanent`.", ru: "Перемещает профиль в корзину. Данные и папка профиля сохраняются, поэтому его можно ВОССТАНОВИТЬ в приложении. Чтобы удалить окончательно и освободить место на диске, используйте `DELETE /api/v1/profiles/{id}/permanent`.", zh: "将配置文件移入回收站。其数据和文件夹保持不变，因此可以在应用中恢复。若要彻底删除并释放磁盘空间，请使用 `DELETE /api/v1/profiles/{id}/permanent`。" },
  "Đã xoá.": { en: "Deleted.", ru: "Удалено.", zh: "已删除。" },
  "Xoá hồ sơ (vĩnh viễn)": { en: "Delete a profile (permanently)", ru: "Удалить профиль (навсегда)", zh: "删除配置文件（永久）" },
  "Xoá hồ sơ VĨNH VIỄN và thu hồi dung lượng đĩa: KHÔNG qua thùng rác, KHÔNG khôi phục được bằng bất kỳ cách nào. Khác với `DELETE /api/v1/profiles/{id}` - đường đó chỉ chuyển vào thùng rác và vẫn khôi phục lại được.": { en: "Deletes the profile PERMANENTLY and frees the disk space: it does NOT go to the trash and CANNOT be restored in any way. Unlike `DELETE /api/v1/profiles/{id}`, which only moves it to the trash so it can still be restored.", ru: "Удаляет профиль НАВСЕГДА и освобождает место на диске: БЕЗ корзины, восстановить его НЕВОЗМОЖНО никаким способом. В отличие от `DELETE /api/v1/profiles/{id}`, который лишь перемещает профиль в корзину, откуда его можно восстановить.", zh: "永久删除配置文件并释放磁盘空间：不经过回收站，无法以任何方式恢复。与 `DELETE /api/v1/profiles/{id}` 不同，后者只是移入回收站，仍可恢复。" },
  "Nhận CẢ hồ sơ đang dùng LẪN hồ sơ đã nằm trong thùng rác, nên gọi thẳng một lần là xong.": { en: "Accepts BOTH active profiles AND profiles already in the trash, so a single call is enough.", ru: "Принимает КАК активные профили, ТАК И профили, уже находящиеся в корзине, поэтому достаточно одного вызова.", zh: "同时接受正在使用的配置文件和已在回收站中的配置文件，因此调用一次即可。" },
  "Hồ sơ đang mở sẽ bị ĐÓNG (buộc tắt trình duyệt) trước khi xoá, vì Windows khoá tệp trong thư mục hồ sơ khi trình duyệt còn chạy. Toàn bộ cookie, dữ liệu đăng nhập, tiện ích và thư mục hồ sơ đều bị xoá theo.": { en: "A profile that is open will be CLOSED (its browser is force-quit) before deletion, because Windows locks the files in the profile folder while the browser is running. All cookies, sign-in data, extensions and the profile folder are deleted along with it.", ru: "Открытый профиль будет ЗАКРЫТ (браузер принудительно завершается) перед удалением, так как Windows блокирует файлы в папке профиля, пока браузер работает. Все cookie, данные входа, расширения и папка профиля удаляются вместе с ним.", zh: "正在打开的配置文件会在删除前被关闭（强制退出浏览器），因为浏览器运行时 Windows 会锁定配置文件夹中的文件。所有 Cookie、登录数据、扩展程序及配置文件夹都会一并删除。" },
  "`storageRemoved` = false KHÔNG phải lỗi: bản ghi hồ sơ đã xoá xong, chỉ thư mục còn bị hệ điều hành khoá - nó đã được ghi vào sổ chờ và sẽ được dọn ở lần mở ứng dụng sau.": { en: "`storageRemoved` = false is NOT an error: the profile record is already deleted, only the folder is still locked by the operating system - it has been queued and will be cleaned up the next time the app starts.", ru: "`storageRemoved` = false НЕ является ошибкой: запись профиля уже удалена, только папка ещё заблокирована операционной системой - она поставлена в очередь и будет очищена при следующем запуске приложения.", zh: "`storageRemoved` = false 并不是错误：配置文件记录已删除，只是文件夹仍被操作系统锁定 - 它已加入待清理队列，会在下次启动应用时清理。" },
  "Đã xoá vĩnh viễn.": { en: "Permanently deleted.", ru: "Удалено навсегда.", zh: "已永久删除。" },
  "Xoá vĩnh viễn thất bại.": { en: "Permanent deletion failed.", ru: "Не удалось удалить навсегда.", zh: "永久删除失败。" },
  "Không tìm thấy hồ sơ (đã tra cả thùng rác).": { en: "Profile not found (the trash was checked too).", ru: "Профиль не найден (корзина тоже проверена).", zh: "未找到配置文件（已同时查找回收站）。" },
  "Thêm proxy cho hồ sơ": { en: "Add a proxy to a profile", ru: "Добавить прокси в профиль", zh: "为配置文件添加代理" },
  "Gán proxy cho hồ sơ (hoặc tạm ngừng / xoá hẳn proxy khỏi hồ sơ).": { en: "Assigns a proxy to the profile (or pauses / fully removes the proxy from the profile).", ru: "Назначает профилю прокси (или приостанавливает / полностью удаляет прокси из профиля).", zh: "为配置文件分配代理（或暂停 / 彻底移除配置文件的代理）。" },
  "`type` là CÔNG TẮC: `http` / `socks4` / `socks5` = proxy hoạt động; `none` = tạm ngừng nhưng GIỮ lại host/port/user/pass để bật lại sau; `remove` = xoá sạch thông tin proxy.": { en: "`type` is a SWITCH: `http` / `socks4` / `socks5` = proxy active; `none` = paused but host/port/user/pass are KEPT so it can be turned back on later; `remove` = wipe the proxy details.", ru: "`type` работает как ПЕРЕКЛЮЧАТЕЛЬ: `http` / `socks4` / `socks5` = прокси включён; `none` = приостановлен, но host/port/user/pass СОХРАНЯЮТСЯ, чтобы включить позже; `remove` = полностью стереть данные прокси.", zh: "`type` 是一个开关：`http` / `socks4` / `socks5` = 启用代理；`none` = 暂停，但保留 host/port/user/pass 以便以后重新启用；`remove` = 清除全部代理信息。" },
  "Mỗi lần đổi proxy, phần địa lý đã dò được của proxy cũ (IP thoát / quốc gia / vùng / thành phố) đều bị xoá để lần mở sau dò lại theo proxy mới. Proxy mới chỉ có hiệu lực từ LẦN MỞ TIẾP THEO - hồ sơ đang mở phải đóng rồi mở lại.": { en: "Each time the proxy changes, the location detected for the old proxy (exit IP / country / region / city) is cleared so the next launch detects it again for the new proxy. The new proxy only takes effect from the NEXT LAUNCH - a profile that is open must be closed and reopened.", ru: "При каждой смене прокси определённое для старого прокси местоположение (выходной IP / страна / регион / город) сбрасывается, чтобы при следующем запуске оно определилось заново для нового прокси. Новый прокси действует только со СЛЕДУЮЩЕГО ЗАПУСКА - открытый профиль нужно закрыть и открыть снова.", zh: "每次更换代理，旧代理已检测到的地理信息（出口 IP / 国家 / 地区 / 城市）都会被清除，以便下次打开时按新代理重新检测。新代理仅从下一次打开起生效 - 正在打开的配置文件需关闭后重新打开。" },
  "Proxy sau khi gán.": { en: "The proxy after assignment.", ru: "Прокси после назначения.", zh: "分配后的代理。" },
  "Thiếu host/port, hoặc `type` không hợp lệ.": { en: "Missing host/port, or invalid `type`.", ru: "Не указан host/port или неверный `type`.", zh: "缺少 host/port，或 `type` 无效。" },
  "Không tìm thấy hồ sơ.": { en: "Profile not found.", ru: "Профиль не найден.", zh: "未找到配置文件。" },
  "Tạo dấu vân tay mới": { en: "Generate a new fingerprint", ru: "Создать новый отпечаток", zh: "生成新指纹" },
  "Sinh LẠI toàn bộ dấu vân tay của hồ sơ - tương đương nút \"Dấu vân tay mới\" trong ứng dụng: seed nhiễu mới, GPU/CPU/RAM/tên máy/MAC/font mới nhưng vẫn nhất quán với hệ điều hành của hồ sơ.": { en: "REGENERATES the whole fingerprint of the profile - same as the \"New fingerprint\" button in the app: a new noise seed, new GPU/CPU/RAM/computer name/MAC/fonts, all still consistent with the profile's operating system.", ru: "ЗАНОВО генерирует весь отпечаток профиля - то же, что кнопка \"Новый отпечаток\" в приложении: новый шумовой seed, новые GPU/CPU/RAM/имя компьютера/MAC/шрифты, при этом всё согласовано с операционной системой профиля.", zh: "重新生成配置文件的全部指纹 - 等同于应用中的\"新指纹\"按钮：新的噪声种子，新的 GPU/CPU/RAM/计算机名/MAC/字体，且仍与配置文件的操作系统保持一致。" },
  "KHÔNG đụng tới cookie, dữ liệu đăng nhập hay bất kỳ tệp nào trong thư mục hồ sơ. Mặc định GIỮ NGUYÊN hệ điều hành đã chọn; truyền `os` nếu muốn đổi luôn.": { en: "Does NOT touch cookies, sign-in data or any file in the profile folder. By default the selected operating system is KEPT; pass `os` if you want to change it too.", ru: "НЕ затрагивает cookie, данные входа и файлы в папке профиля. По умолчанию выбранная операционная система СОХРАНЯЕТСЯ; передайте `os`, если хотите сменить и её.", zh: "不会改动 Cookie、登录数据或配置文件夹中的任何文件。默认保留已选的操作系统；如需一并更改，请传入 `os`。" },
  "Vân tay mới chỉ có hiệu lực từ LẦN MỞ TIẾP THEO - hồ sơ đang mở phải đóng rồi mở lại.": { en: "The new fingerprint only takes effect from the NEXT LAUNCH - a profile that is open must be closed and reopened.", ru: "Новый отпечаток действует только со СЛЕДУЮЩЕГО ЗАПУСКА - открытый профиль нужно закрыть и открыть снова.", zh: "新指纹仅从下一次打开起生效 - 正在打开的配置文件需关闭后重新打开。" },
  "Tóm tắt vân tay mới.": { en: "Summary of the new fingerprint.", ru: "Сводка нового отпечатка.", zh: "新指纹摘要。" },
  "`os` không hợp lệ, hoặc lưu vân tay thất bại.": { en: "Invalid `os`, or saving the fingerprint failed.", ru: "Неверный `os` или не удалось сохранить отпечаток.", zh: "`os` 无效，或保存指纹失败。" },
  "Mở trình duyệt hồ sơ": { en: "Open the profile browser", ru: "Открыть браузер профиля", zh: "打开配置文件浏览器" },
  "Khởi chạy trình duyệt của hồ sơ (nếu chưa chạy) và trả về điểm cuối CDP (debugPort + WebSocket) để tool ngoài điều khiển qua puppeteer / selenium.": { en: "Launches the profile's browser (if it is not running yet) and returns the CDP endpoint (debugPort + WebSocket) so an external tool can control it through puppeteer / selenium.", ru: "Запускает браузер профиля (если он ещё не запущен) и возвращает конечную точку CDP (debugPort + WebSocket), чтобы внешний инструмент мог управлять им через puppeteer / selenium.", zh: "启动配置文件的浏览器（若尚未运行），并返回 CDP 端点（debugPort + WebSocket），以便外部工具通过 puppeteer / selenium 控制。" },
  "Áp dụng đúng giới hạn như khi bấm \"Mở\" trong ứng dụng: giới hạn số lượt mở mỗi ngày (`OPEN_RATE_EXCEEDED`, dùng chung cho cả nhóm) và khoá chống mở cùng lúc trên 2 máy (`PROFILE_LOCKED`).": { en: "The same limits apply as when you click \"Open\" in the app: a daily open limit (`OPEN_RATE_EXCEEDED`, shared by the whole team) and a lock that prevents opening on 2 computers at once (`PROFILE_LOCKED`).", ru: "Действуют те же ограничения, что и при нажатии \"Открыть\" в приложении: дневной лимит открытий (`OPEN_RATE_EXCEEDED`, общий для всей команды) и блокировка одновременного открытия на 2 компьютерах (`PROFILE_LOCKED`).", zh: "与在应用中点击\"打开\"时的限制相同：每日打开次数上限（`OPEN_RATE_EXCEEDED`，整个团队共用），以及防止在 2 台电脑上同时打开的锁（`PROFILE_LOCKED`）。" },
  "Điểm cuối CDP.": { en: "CDP endpoint.", ru: "Конечная точка CDP.", zh: "CDP 端点。" },
  "`OPEN_RATE_EXCEEDED` (hết lượt mở hôm nay, làm mới vào 00:00 giờ Việt Nam) hoặc `PROFILE_LOCKED` (hồ sơ đang mở ở máy khác).": { en: "`OPEN_RATE_EXCEEDED` (no opens left today, resets at 00:00 Vietnam time) or `PROFILE_LOCKED` (the profile is open on another computer).", ru: "`OPEN_RATE_EXCEEDED` (открытия на сегодня исчерпаны, сброс в 00:00 по времени Вьетнама) или `PROFILE_LOCKED` (профиль открыт на другом компьютере).", zh: "`OPEN_RATE_EXCEEDED`（今日打开次数已用完，于越南时间 00:00 重置）或 `PROFILE_LOCKED`（配置文件已在另一台电脑上打开）。" },
  "Đóng trình duyệt hồ sơ": { en: "Close the profile browser", ru: "Закрыть браузер профиля", zh: "关闭配置文件浏览器" },
  "Đã đóng.": { en: "Closed.", ru: "Закрыто.", zh: "已关闭。" },
  "Danh sách quy trình": { en: "List workflows", ru: "Список процессов", zh: "流程列表" },
  "Lấy id + tên của các quy trình đã lưu, để truyền vào `workflowId` khi chạy.": { en: "Gets the id + name of saved workflows, to pass as `workflowId` when running.", ru: "Возвращает id и название сохранённых процессов для передачи в `workflowId` при запуске.", zh: "获取已保存流程的 id 和名称，以便运行时传入 `workflowId`。" },
  "Danh sách quy trình.": { en: "List of workflows.", ru: "Список процессов.", zh: "流程列表。" },
  "Chạy một quy trình đã lưu trên một hoặc nhiều hồ sơ.": { en: "Runs a saved workflow on one or more profiles.", ru: "Запускает сохранённый процесс на одном или нескольких профилях.", zh: "在一个或多个配置文件上运行已保存的流程。" },
  "Kết quả chạy theo từng hồ sơ.": { en: "Run result for each profile.", ru: "Результат запуска по каждому профилю.", zh: "每个配置文件的运行结果。" },
  "Phiên bản ứng dụng.": { en: "App version.", ru: "Версия приложения.", zh: "应用版本。" },
  "Chưa đăng nhập thì danh sách hồ sơ/quy trình sẽ rỗng.": { en: "When not signed in, the profile/workflow lists are empty.", ru: "Если вход не выполнен, списки профилей и процессов будут пустыми.", zh: "未登录时，配置文件/流程列表为空。" },
  "Số hồ sơ đang mở trình duyệt.": { en: "Number of profiles with an open browser.", ru: "Количество профилей с открытым браузером.", zh: "已打开浏览器的配置文件数量。" },
  "Gói thuê bao hiện tại có kèm \"Sử dụng API cục bộ\" không. false (gói Free / gói đã hết hạn) thì MỌI endpoint khác trả 403 FEATURE_NOT_IN_PLAN - hãy nâng cấp gói, đừng thử lại trong vòng lặp.": { en: "Whether the current subscription includes \"Use the local API\". false (Free plan / expired plan) means EVERY other endpoint returns 403 FEATURE_NOT_IN_PLAN - upgrade the plan, do not retry in a loop.", ru: "Включает ли текущая подписка \"Использование локального API\". false (тариф Free / истёкший тариф) означает, что ВСЕ остальные endpoint возвращают 403 FEATURE_NOT_IN_PLAN - повысьте тариф, не повторяйте запросы в цикле.", zh: "当前订阅是否包含\"使用本地 API\"。为 false（Free 套餐 / 已过期套餐）时，其他所有 endpoint 都返回 403 FEATURE_NOT_IN_PLAN - 请升级套餐，不要循环重试。" },
  "Trình duyệt có đang mở không.": { en: "Whether the browser is open.", ru: "Открыт ли браузер.", zh: "浏览器是否已打开。" },
  "Chỉ gửi các trường muốn đổi.": { en: "Send only the fields you want to change.", ru: "Отправляйте только поля, которые нужно изменить.", zh: "只需发送要修改的字段。" },
  "CHỈ `name` là bắt buộc - mọi tham số còn lại có mặc định hợp lý, gửi `{\"name\":\"Hồ sơ API 01\"}` là tạo được hồ sơ dùng ngay.": { en: "ONLY `name` is required - every other parameter has a sensible default, so sending `{\"name\":\"API Profile 01\"}` creates a profile that is ready to use.", ru: "Обязательно ТОЛЬКО `name` - у всех остальных параметров есть разумные значения по умолчанию, поэтому `{\"name\":\"Профиль API 01\"}` уже создаёт готовый к работе профиль.", zh: "只有 `name` 是必填项 - 其余参数都有合理的默认值，发送 `{\"name\":\"API 配置文件 01\"}` 即可创建一个可直接使用的配置文件。" },
  "Vân tay (GPU, CPU, RAM, font, canvas seed, User-Agent…) KHÔNG nhận từ ngoài - ứng dụng tự sinh bằng đúng bộ sinh của màn \"Tạo hồ sơ\". Lý do: một vân tay ghép tay rất dễ tự-mâu-thuẫn (vd UA nói macOS nhưng GPU là card Windows) và chính sự mâu thuẫn đó là dấu hiệu bị phát hiện. Bạn chỉ chọn KHUNG (hệ điều hành + nhân trình duyệt), phần bên trong được sinh sao cho nhất quán với khung đó.": { en: "The fingerprint (GPU, CPU, RAM, fonts, canvas seed, User-Agent…) is NOT accepted from outside - the app generates it with the same generator as the \"Create Profile\" screen. Reason: a hand-assembled fingerprint easily contradicts itself (e.g. the UA says macOS but the GPU is a Windows card), and that inconsistency is exactly what gives it away. You only choose the FRAME (operating system + browser kernel); everything inside is generated to stay consistent with that frame.", ru: "Отпечаток (GPU, CPU, RAM, шрифты, canvas seed, User-Agent…) НЕ принимается извне - приложение генерирует его тем же генератором, что и экран \"Создать профиль\". Причина: собранный вручную отпечаток легко противоречит сам себе (например, UA говорит macOS, а GPU - видеокарта Windows), и именно это противоречие его выдаёт. Вы выбираете только РАМКУ (операционная система + ядро браузера), а всё внутри генерируется согласованно с ней.", zh: "指纹（GPU、CPU、RAM、字体、canvas seed、User-Agent…）不接受外部传入 - 应用使用与\"创建配置文件\"界面相同的生成器自动生成。原因：手动拼凑的指纹很容易自相矛盾（例如 UA 显示 macOS，而 GPU 却是 Windows 显卡），而这种矛盾恰恰会暴露它。您只需选择框架（操作系统 + 浏览器内核），其中的内容会自动生成并与该框架保持一致。" },
  "TÊN hồ sơ, hiện ở cột đầu của lưới hồ sơ. Khoảng trắng hai đầu bị cắt; rỗng ⇒ lỗi 400 \"Thiếu name\". Tên KHÔNG cần duy nhất (hai hồ sơ trùng tên vẫn khác `id`), nhưng đặt trùng thì bạn tự khó tìm.": { en: "The profile NAME, shown in the first column of the profile grid. Leading and trailing spaces are trimmed; empty ⇒ error 400 \"Thiếu name\". The name does NOT have to be unique (two profiles with the same name still have different `id`s), but duplicates make them harder for you to find.", ru: "ИМЯ профиля, отображается в первом столбце таблицы профилей. Пробелы по краям обрезаются; пустое ⇒ ошибка 400 \"Thiếu name\". Имя НЕ обязано быть уникальным (у двух профилей с одинаковым именем всё равно разные `id`), но дубликаты сложнее найти.", zh: "配置文件名称，显示在配置文件列表的第一列。首尾空格会被去除；为空 ⇒ 返回错误 400 \"Thiếu name\"。名称不必唯一（同名的两个配置文件 `id` 仍然不同），但重名会让您自己难以查找。" },
  "Hồ sơ API 01": { en: "API Profile 01", ru: "Профиль API 01", zh: "API 配置文件 01" },
  "ID NHÓM để xếp hồ sơ vào. Bỏ trống / null = không thuộc nhóm nào (mục \"Chưa chia nhóm\"). Phải là `id` của nhóm ĐÃ CÓ - lấy từ trường `groupId` của một hồ sơ đang ở nhóm đó (`GET /api/v1/profiles`); API này KHÔNG tạo nhóm mới. Gửi ID không tồn tại thì máy chủ TỪ CHỐI cả lệnh tạo (nhóm là khoá ngoại), chứ không lặng lẽ bỏ nhóm - nên đừng điền ID bịa để thử. Ví dụ ở trên để `\"groupId\": null` = không xếp nhóm.": { en: "GROUP ID to place the profile in. Empty / null = no group (the \"Ungrouped\" section). Must be the `id` of an EXISTING group - take it from the `groupId` field of a profile already in that group (`GET /api/v1/profiles`); this API does NOT create new groups. Sending a non-existent ID makes the server REJECT the whole create request (the group is a foreign key) rather than silently dropping the group - so do not fill in a made-up ID to test. The example above uses `\"groupId\": null` = no group.", ru: "ID ГРУППЫ, в которую поместить профиль. Пусто / null = без группы (раздел \"Без группы\"). Должен быть `id` СУЩЕСТВУЮЩЕЙ группы - возьмите его из поля `groupId` профиля, который уже в этой группе (`GET /api/v1/profiles`); этот API НЕ создаёт новые группы. Если отправить несуществующий ID, сервер ОТКЛОНИТ весь запрос на создание (группа - внешний ключ), а не просто проигнорирует группу, поэтому не подставляйте выдуманный ID для проверки. В примере выше `\"groupId\": null` = без группы.", zh: "要放入的分组 ID。留空 / null = 不属于任何分组（\"未分组\"）。必须是已存在分组的 `id` - 可从该分组中某个配置文件的 `groupId` 字段获取（`GET /api/v1/profiles`）；此 API 不会创建新分组。发送不存在的 ID 时，服务器会拒绝整个创建请求（分组是外键），而不是悄悄忽略分组 - 因此不要填写编造的 ID 来测试。上面的示例使用 `\"groupId\": null` = 不分组。" },
  "HỆ ĐIỀU HÀNH mà hồ sơ giả lập. Đây là tham số ẢNH HƯỞNG RỘNG NHẤT: nó khoá luôn GPU/WebGL, số lõi CPU, RAM, tên máy và danh sách font theo đúng hệ điều hành đó, và quyết định token OS trong User-Agent. Nhận cả chữ thường và tên gọi khác (`windows`, `win`, `mac`, `osx`, `ios`…). Bỏ trống = `Windows`.": { en: "The OPERATING SYSTEM the profile emulates. This is the parameter with the WIDEST IMPACT: it also fixes the GPU/WebGL, CPU core count, RAM, computer name and font list to match that operating system, and decides the OS token in the User-Agent. Lowercase and alternative names are accepted too (`windows`, `win`, `mac`, `osx`, `ios`…). Empty = `Windows`.", ru: "ОПЕРАЦИОННАЯ СИСТЕМА, которую эмулирует профиль. Это параметр с САМЫМ ШИРОКИМ ВЛИЯНИЕМ: он заодно определяет GPU/WebGL, число ядер CPU, RAM, имя компьютера и список шрифтов под эту систему, а также токен ОС в User-Agent. Принимаются строчные буквы и другие названия (`windows`, `win`, `mac`, `osx`, `ios`…). Пусто = `Windows`.", zh: "配置文件模拟的操作系统。这是影响范围最广的参数：它会同时按该操作系统确定 GPU/WebGL、CPU 核心数、RAM、计算机名和字体列表，并决定 User-Agent 中的 OS 标识。也接受小写和其他名称（`windows`、`win`、`mac`、`osx`、`ios`…）。留空 = `Windows`。" },
  "Lưu ý: nhân trình duyệt chạy trên Windows thật, nên chọn OS khác Windows là chế độ GIẢ LẬP (ứng dụng phát UA + client-hints tương ứng); chọn `Windows` thì trình duyệt dùng luôn UA gốc của nhân - khớp 100%, không hook gì.": { en: "Note: the browser kernel runs on real Windows, so choosing an OS other than Windows is an EMULATION mode (the app sends the matching UA + client hints); choosing `Windows` makes the browser use the kernel's own UA - a 100% match, nothing hooked.", ru: "Примечание: ядро браузера работает на настоящей Windows, поэтому выбор ОС, отличной от Windows, - это режим ЭМУЛЯЦИИ (приложение отдаёт соответствующие UA и client hints); при выборе `Windows` браузер использует родной UA ядра - совпадение 100%, без подмен.", zh: "注意：浏览器内核运行在真实的 Windows 上，因此选择 Windows 以外的系统属于模拟模式（应用发送对应的 UA + client hints）；选择 `Windows` 时浏览器直接使用内核原生的 UA - 100% 一致，无任何挂钩。" },
  "PHIÊN BẢN của hệ điều hành đã chọn, đúng như menu \"Thao tác hệ thống\" trong ứng dụng: `Windows 11` / `Windows 10`, `macOS 26`, `Linux x86_64`, `Android 15`, `iOS 26`… Bỏ trống = bản mới nhất của OS đó (Windows ⇒ \"Windows 11\", macOS ⇒ \"macOS 26\", Linux ⇒ \"Linux x86_64\", Android ⇒ \"Android 15\", iOS ⇒ \"iOS 26\").": { en: "VERSION of the selected operating system, exactly as in the \"System operation\" menu in the app: `Windows 11` / `Windows 10`, `macOS 26`, `Linux x86_64`, `Android 15`, `iOS 26`… Empty = the latest version of that OS (Windows ⇒ \"Windows 11\", macOS ⇒ \"macOS 26\", Linux ⇒ \"Linux x86_64\", Android ⇒ \"Android 15\", iOS ⇒ \"iOS 26\").", ru: "ВЕРСИЯ выбранной операционной системы, как в меню \"Системная операция\" в приложении: `Windows 11` / `Windows 10`, `macOS 26`, `Linux x86_64`, `Android 15`, `iOS 26`… Пусто = последняя версия этой ОС (Windows ⇒ \"Windows 11\", macOS ⇒ \"macOS 26\", Linux ⇒ \"Linux x86_64\", Android ⇒ \"Android 15\", iOS ⇒ \"iOS 26\").", zh: "所选操作系统的版本，与应用中\"系统操作\"菜单一致：`Windows 11` / `Windows 10`、`macOS 26`、`Linux x86_64`、`Android 15`、`iOS 26`… 留空 = 该系统的最新版本（Windows ⇒ \"Windows 11\"，macOS ⇒ \"macOS 26\"，Linux ⇒ \"Linux x86_64\"，Android ⇒ \"Android 15\"，iOS ⇒ \"iOS 26\"）。" },
  "Với Android/iOS thì phiên bản này ĐI THẲNG vào User-Agent. Với Windows/macOS thì Chrome đã đóng băng token phiên bản OS trong UA từ lâu, nên nó chỉ là nhãn hiển thị.": { en: "For Android/iOS this version GOES STRAIGHT into the User-Agent. For Windows/macOS, Chrome froze the OS version token in the UA long ago, so it is only a display label.", ru: "Для Android/iOS эта версия ПОПАДАЕТ ПРЯМО в User-Agent. Для Windows/macOS Chrome давно заморозил токен версии ОС в UA, поэтому это лишь отображаемая метка.", zh: "对于 Android/iOS，此版本会直接写入 User-Agent。对于 Windows/macOS，Chrome 早已冻结 UA 中的系统版本标识，因此它只是一个显示标签。" },
  "NHÂN TRÌNH DUYỆT mà hồ sơ sẽ chạy - tương đương thẻ \"Trình duyệt\" ở màn \"Tạo hồ sơ\":": { en: "The BROWSER KERNEL the profile will run - same as the \"Browser\" card on the \"Create Profile\" screen:", ru: "ЯДРО БРАУЗЕРА, на котором будет работать профиль, - то же, что карточка \"Браузер\" на экране \"Создать профиль\":", zh: "配置文件将使用的浏览器内核 - 等同于\"创建配置文件\"界面上的\"浏览器\"卡片：" },
  "- `chromium` = CGTBrowser (Chromium đã vá). Mặc định. Điều khiển được bằng puppeteer / playwright / selenium qua CDP (`GET /profiles/{id}/open` trả về `puppeteer` + `selenium`).": { en: "- `chromium` = CGTBrowser (patched Chromium). Default. Can be controlled with puppeteer / playwright / selenium over CDP (`GET /profiles/{id}/open` returns `puppeteer` + `selenium`).", ru: "- `chromium` = CGTBrowser (доработанный Chromium). По умолчанию. Управляется через puppeteer / playwright / selenium по CDP (`GET /profiles/{id}/open` возвращает `puppeteer` + `selenium`).", zh: "- `chromium` = CGTBrowser（修补版 Chromium）。默认值。可通过 CDP 使用 puppeteer / playwright / selenium 控制（`GET /profiles/{id}/open` 返回 `puppeteer` + `selenium`）。" },
  "- `firefox` = CGTBrowser Firefox (Gecko đã vá). Firefox đã BỎ CDP, chỉ còn WebDriver BiDi - tự động hoá được nhưng phải nối bằng BiDi, và tính năng \"Đồng bộ thao tác\" chỉ có trên Chromium.": { en: "- `firefox` = CGTBrowser Firefox (patched Gecko). Firefox has DROPPED CDP and only has WebDriver BiDi - it can be automated but you must connect over BiDi, and the \"Sync Actions\" feature is only available on Chromium.", ru: "- `firefox` = CGTBrowser Firefox (доработанный Gecko). Firefox ОТКАЗАЛСЯ от CDP и поддерживает только WebDriver BiDi - автоматизация возможна, но подключаться нужно по BiDi, а функция \"Синхронизация действий\" есть только в Chromium.", zh: "- `firefox` = CGTBrowser Firefox（修补版 Gecko）。Firefox 已放弃 CDP，只保留 WebDriver BiDi - 可以自动化，但必须通过 BiDi 连接，且\"同步操作\"功能仅在 Chromium 上可用。" },
  "Nhận cả `chrome` / `poly` / `ChromeBrowser` (⇒ chromium) và `gecko` / `ff` / `FirefoxBrowser` (⇒ firefox), không phân biệt hoa thường. Gửi giá trị lạ ⇒ 400.": { en: "`chrome` / `poly` / `ChromeBrowser` (⇒ chromium) and `gecko` / `ff` / `FirefoxBrowser` (⇒ firefox) are accepted too, case-insensitive. An unknown value ⇒ 400.", ru: "Также принимаются `chrome` / `poly` / `ChromeBrowser` (⇒ chromium) и `gecko` / `ff` / `FirefoxBrowser` (⇒ firefox), без учёта регистра. Неизвестное значение ⇒ 400.", zh: "也接受 `chrome` / `poly` / `ChromeBrowser`（⇒ chromium）和 `gecko` / `ff` / `FirefoxBrowser`（⇒ firefox），不区分大小写。未知值 ⇒ 400。" },
  "Hồ sơ chỉ ghim nhân, KHÔNG sao chép nhân, nên đổi nhân về sau không mất dữ liệu.": { en: "A profile only pins the kernel, it does NOT copy it, so switching kernels later loses no data.", ru: "Профиль лишь закрепляет ядро, а НЕ копирует его, поэтому смена ядра позже не приводит к потере данных.", zh: "配置文件只固定内核，不会复制内核，因此以后更换内核不会丢失数据。" },
  "PHIÊN BẢN NHÂN sẽ ghim cho hồ sơ này - đúng số hiện trên thẻ \"Trình duyệt\". Gửi major (`\"150\"`) hoặc full-version (`\"150.0.7258.128\"`) đều được, ứng dụng chỉ lấy phần major vì nhân được cài theo major.": { en: "KERNEL VERSION to pin for this profile - the same number shown on the \"Browser\" card. Either the major (`\"150\"`) or the full version (`\"150.0.7258.128\"`) works; the app only uses the major because kernels are installed per major.", ru: "ВЕРСИЯ ЯДРА, которую нужно закрепить за профилем, - то же число, что на карточке \"Браузер\". Подходит и major (`\"150\"`), и полная версия (`\"150.0.7258.128\"`); приложение берёт только major, так как ядра устанавливаются по major.", zh: "为该配置文件固定的内核版本 - 与\"浏览器\"卡片上显示的数字相同。传主版本号（`\"150\"`）或完整版本（`\"150.0.7258.128\"`）均可，应用只取主版本号，因为内核按主版本安装。" },
  "Phiên bản này PHẢI đã được tải về máy (mục Trình duyệt → tải nhân trong ứng dụng); gửi một bản chưa cài sẽ nhận 400 kèm danh sách bản đã cài. Bỏ trống = bản MỚI NHẤT đã cài của nhân đã chọn (giống hành vi mặc định của màn \"Tạo hồ sơ\"); máy chưa cài nhân nào thì hồ sơ vẫn tạo được nhưng không ghim bản nào và sẽ mở bằng nhân đang dùng.": { en: "This version MUST already be downloaded to the computer (Browser section → download kernel in the app); sending a version that is not installed returns 400 with the list of installed versions. Empty = the LATEST installed version of the selected kernel (same as the default on the \"Create Profile\" screen); if no kernel is installed, the profile is still created but pins no version and opens with the kernel currently in use.", ru: "Эта версия ДОЛЖНА быть уже загружена на компьютер (раздел Браузер → загрузка ядра в приложении); при отправке неустановленной версии вернётся 400 со списком установленных. Пусто = ПОСЛЕДНЯЯ установленная версия выбранного ядра (как по умолчанию на экране \"Создать профиль\"); если ни одно ядро не установлено, профиль всё равно создаётся, но без закреплённой версии и открывается текущим ядром.", zh: "此版本必须已下载到本机（应用中的 浏览器 → 下载内核）；发送未安装的版本会返回 400 及已安装版本列表。留空 = 所选内核已安装的最新版本（与\"创建配置文件\"界面的默认行为相同）；若本机未安装任何内核，配置文件仍可创建，但不固定版本，将使用当前内核打开。" },
  "Ghim là ghim theo TỪNG hồ sơ: mỗi hồ sơ mở đúng bản mình ghim, không bị nhân \"đang dùng\" toàn cục kéo theo. User-Agent của hồ sơ cũng được dựng theo full-version thật của bản nhân này để UA không lệch phiên bản trình duyệt đang chạy.": { en: "Pinning is PER profile: each profile opens exactly the version it pins and is not dragged along by the global \"current\" kernel. The profile's User-Agent is also built from the real full version of this kernel so the UA never mismatches the running browser version.", ru: "Закрепление действует ДЛЯ КАЖДОГО профиля отдельно: каждый профиль открывается именно своей версией и не зависит от глобального \"текущего\" ядра. User-Agent профиля тоже строится по реальной полной версии этого ядра, чтобы UA не расходился с версией запущенного браузера.", zh: "固定是按每个配置文件进行的：每个配置文件都使用自己固定的版本打开，不受全局\"当前\"内核影响。配置文件的 User-Agent 也按该内核的真实完整版本生成，使 UA 与正在运行的浏览器版本一致。" },
  "GHI CHÚ tự do, hiện ở cột \"Ghi chú\" của lưới hồ sơ. Chỉ để bạn đọc, không ảnh hưởng gì tới trình duyệt. Sửa sau bằng `PUT /api/v1/profiles/{id}`.": { en: "A free-form NOTE, shown in the \"Note\" column of the profile grid. Only for you to read, it has no effect on the browser. Edit it later with `PUT /api/v1/profiles/{id}`.", ru: "Произвольная ЗАМЕТКА, отображается в столбце \"Заметка\" таблицы профилей. Только для вас, на браузер не влияет. Изменить позже можно через `PUT /api/v1/profiles/{id}`.", zh: "自由填写的备注，显示在配置文件列表的\"备注\"列中。仅供您阅读，对浏览器没有任何影响。之后可通过 `PUT /api/v1/profiles/{id}` 修改。" },
  "Tạo bằng API cục bộ": { en: "Created via the local API", ru: "Создан через локальный API", zh: "通过本地 API 创建" },
  "THẺ để lọc/tìm hồ sơ. Gửi mảng chuỗi (`[\"api\",\"automation\"]`); cũng nhận một chuỗi ngăn bởi dấu phẩy (\"api, automation\") cho tiện. Thẻ rỗng bị bỏ, khoảng trắng hai đầu bị cắt; đọc ra thì LUÔN là mảng. Thẻ không cần khai báo trước - gõ tên mới là dùng được ngay.": { en: "TAGS to filter/find profiles. Send an array of strings (`[\"api\",\"automation\"]`); a comma-separated string (\"api, automation\") is accepted too for convenience. Empty tags are dropped and spaces are trimmed; when read back it is ALWAYS an array. Tags need no prior declaration - type a new name and it works right away.", ru: "ТЕГИ для фильтрации и поиска профилей. Отправьте массив строк (`[\"api\",\"automation\"]`); для удобства принимается и строка через запятую (\"api, automation\"). Пустые теги отбрасываются, пробелы по краям обрезаются; при чтении это ВСЕГДА массив. Теги не нужно объявлять заранее - введите новое имя, и он сразу работает.", zh: "用于筛选/查找配置文件的标签。发送字符串数组（`[\"api\",\"automation\"]`）；为方便起见也接受以逗号分隔的字符串（\"api, automation\"）。空标签会被丢弃，首尾空格会被去除；读取时始终是数组。标签无需预先声明 - 输入新名称即可直接使用。" },
  "URL mở sẵn MỖI LẦN bật hồ sơ (khi bấm \"Mở\" hoặc gọi `GET /profiles/{id}/open`). Ghi cả giao thức (`https://...`). Bỏ trống = mở tab trắng.": { en: "URL opened EVERY TIME the profile starts (when you click \"Open\" or call `GET /profiles/{id}/open`). Include the protocol (`https://...`). Empty = open a blank tab.", ru: "URL, открываемый ПРИ КАЖДОМ запуске профиля (по кнопке \"Открыть\" или вызову `GET /profiles/{id}/open`). Указывайте протокол (`https://...`). Пусто = открыть пустую вкладку.", zh: "每次启动配置文件时自动打开的 URL（点击\"打开\"或调用 `GET /profiles/{id}/open` 时）。需包含协议（`https://...`）。留空 = 打开空白标签页。" },
  "Chạy quy trình RPA thì tham số này bị BỎ QUA: lượt chạy RPA luôn mở trắng và chỉ giữ đúng một tab URL của quy trình.": { en: "When an RPA workflow runs, this parameter is IGNORED: an RPA run always starts blank and keeps only the workflow's own URL tab.", ru: "При запуске RPA-процесса этот параметр ИГНОРИРУЕТСЯ: запуск RPA всегда начинается с пустой страницы и оставляет только вкладку с URL процесса.", zh: "运行 RPA 流程时会忽略此参数：RPA 运行总是从空白页开始，只保留流程自身的那个 URL 标签页。" },
  "Gán proxy NGAY LÚC TẠO (tuỳ chọn) - cùng định dạng và cùng đường xử lý với `PUT /api/v1/profiles/{id}/proxy`, nên luật không thể lệch giữa hai đường.": { en: "Assign a proxy AT CREATION TIME (optional) - same format and same processing path as `PUT /api/v1/profiles/{id}/proxy`, so the rules cannot differ between the two.", ru: "Назначить прокси СРАЗУ ПРИ СОЗДАНИИ (необязательно) - тот же формат и та же обработка, что и у `PUT /api/v1/profiles/{id}/proxy`, поэтому правила у двух путей не могут расходиться.", zh: "在创建时直接分配代理（可选）- 格式和处理流程与 `PUT /api/v1/profiles/{id}/proxy` 完全相同，因此两条路径的规则不会出现差异。" },
  "`null` (hoặc bỏ hẳn khoá) = hồ sơ KHÔNG dùng proxy, đi bằng mạng của máy. Đó chính là giá trị trong ví dụ ở trên, để copy-dán là chạy được mà không phải đi tìm proxy.": { en: "`null` (or omitting the key) = the profile does NOT use a proxy and goes through the computer's own network. That is exactly the value in the example above, so it runs as-is when copy-pasted without hunting for a proxy.", ru: "`null` (или отсутствие ключа) = профиль НЕ использует прокси и работает через сеть компьютера. Именно это значение стоит в примере выше, чтобы его можно было скопировать и запустить без поиска прокси.", zh: "`null`（或完全省略该键）= 配置文件不使用代理，直接使用本机网络。上面示例中正是这个值，复制粘贴即可运行，无需另找代理。" },
  "Muốn cắm proxy thì thay `null` bằng đối tượng: cần `type` + `host` + `port`, thêm `username`/`password` nếu proxy có xác thực. Ví dụ `{\"type\":\"http\",\"host\":\"45.76.120.33\",\"port\":8080}`. Proxy KHÔNG được kiểm tra sống/chết lúc tạo - gửi proxy bịa thì hồ sơ vẫn tạo xong nhưng mở ra không vào được mạng, nên đừng lấy host trong ví dụ này dùng thật.": { en: "To plug in a proxy, replace `null` with an object: `type` + `host` + `port` are required, add `username`/`password` if the proxy needs authentication. Example `{\"type\":\"http\",\"host\":\"45.76.120.33\",\"port\":8080}`. The proxy is NOT checked for being alive at creation time - a made-up proxy still creates the profile, but it will have no network when opened, so do not use the host from this example for real.", ru: "Чтобы подключить прокси, замените `null` объектом: обязательны `type` + `host` + `port`, добавьте `username`/`password`, если прокси требует авторизации. Пример `{\"type\":\"http\",\"host\":\"45.76.120.33\",\"port\":8080}`. Работоспособность прокси при создании НЕ проверяется - с выдуманным прокси профиль всё равно создастся, но при открытии не будет сети, поэтому не используйте host из этого примера всерьёз.", zh: "若要接入代理，请将 `null` 替换为对象：必须包含 `type` + `host` + `port`，代理需要认证时再加上 `username`/`password`。示例 `{\"type\":\"http\",\"host\":\"45.76.120.33\",\"port\":8080}`。创建时不会检测代理是否可用 - 填写编造的代理仍能创建配置文件，但打开后无法联网，所以不要真的使用此示例中的 host。" },
  "http | https | socks4 | socks5 = bật proxy (cần host + port). none = tạm ngừng dùng proxy nhưng GIỮ thông tin. remove = xoá sạch proxy khỏi hồ sơ. (https được lưu thành HTTP, giống ứng dụng.)": { en: "http | https | socks4 | socks5 = enable the proxy (host + port required). none = stop using the proxy but KEEP its details. remove = wipe the proxy from the profile. (https is saved as HTTP, same as in the app.)", ru: "http | https | socks4 | socks5 = включить прокси (нужны host + port). none = перестать использовать прокси, но СОХРАНИТЬ его данные. remove = полностью удалить прокси из профиля. (https сохраняется как HTTP, как и в приложении.)", zh: "http | https | socks4 | socks5 = 启用代理（需要 host + port）。none = 暂停使用代理但保留其信息。remove = 从配置文件中彻底清除代理。（https 会保存为 HTTP，与应用一致。）" },
  "Bỏ trống nếu proxy không cần xác thực.": { en: "Leave empty if the proxy needs no authentication.", ru: "Оставьте пустым, если прокси не требует авторизации.", zh: "代理无需认证时留空。" },
  "Enum đã lưu: '' (không dùng) | HTTP | SOCKS4 | SOCKS5.": { en: "Stored enum: '' (not used) | HTTP | SOCKS4 | SOCKS5.", ru: "Сохранённое значение enum: '' (не используется) | HTTP | SOCKS4 | SOCKS5.", zh: "已保存的枚举值：''（不使用）| HTTP | SOCKS4 | SOCKS5。" },
  "Lần mở tiếp theo có đi qua proxy không.": { en: "Whether the next launch goes through the proxy.", ru: "Пойдёт ли следующий запуск через прокси.", zh: "下次打开时是否通过代理。" },
  "Body tuỳ chọn - gửi `{}` (hoặc bỏ hẳn) là giữ nguyên hệ điều hành hiện tại của hồ sơ.": { en: "Optional body - sending `{}` (or omitting it) keeps the profile's current operating system.", ru: "Необязательное тело запроса - отправка `{}` (или его отсутствие) сохраняет текущую операционную систему профиля.", zh: "可选的请求体 - 发送 `{}`（或完全省略）即保留配置文件当前的操作系统。" },
  "Đổi luôn hệ điều hành của hồ sơ. Bỏ trống = giữ nguyên.": { en: "Also change the profile's operating system. Empty = keep it.", ru: "Заодно сменить операционную систему профиля. Пусто = оставить как есть.", zh: "同时更改配置文件的操作系统。留空 = 保持不变。" },
  "Phiên bản OS. Bỏ trống = giữ nguyên (hoặc bản mới nhất nếu đổi OS).": { en: "OS version. Empty = keep it (or the latest version if the OS changes).", ru: "Версия ОС. Пусто = оставить как есть (или последняя версия при смене ОС).", zh: "系统版本。留空 = 保持不变（若更换系统则为最新版本）。" },
  "Số lõi CPU (navigator.hardwareConcurrency).": { en: "Number of CPU cores (navigator.hardwareConcurrency).", ru: "Количество ядер CPU (navigator.hardwareConcurrency).", zh: "CPU 核心数（navigator.hardwareConcurrency）。" },
  "Số font trong danh sách font của hồ sơ.": { en: "Number of fonts in the profile's font list.", ru: "Количество шрифтов в списке шрифтов профиля.", zh: "配置文件字体列表中的字体数量。" },
  "Seed nhiễu canvas/WebGL/audio - đổi seed là đổi vân tay.": { en: "Canvas/WebGL/audio noise seed - a new seed means a new fingerprint.", ru: "Шумовой seed для canvas/WebGL/audio - новый seed означает новый отпечаток.", zh: "canvas/WebGL/audio 噪声种子 - 更换种子即更换指纹。" },
  "Đã xoá xong thư mục hồ sơ trên đĩa chưa (false = còn trong sổ chờ dọn).": { en: "Whether the profile folder has been removed from the disk (false = still in the cleanup queue).", ru: "Удалена ли папка профиля с диска (false = ещё в очереди на очистку).", zh: "配置文件夹是否已从磁盘删除（false = 仍在待清理队列中）。" },
  "Cổng CDP trên 127.0.0.1.": { en: "CDP port on 127.0.0.1.", ru: "Порт CDP на 127.0.0.1.", zh: "127.0.0.1 上的 CDP 端口。" },
  "Phiên bản nhân trình duyệt — chromedriver phải cùng dòng phiên bản này.": { en: "Browser kernel version - chromedriver must match this version line.", ru: "Версия ядра браузера - chromedriver должен быть той же линейки версий.", zh: "浏览器内核版本 - chromedriver 必须与此版本系列一致。" },
  "Đường dẫn tệp thực thi trình duyệt (chỉ để tham khảo — đừng tự chạy, hãy luôn mở qua /open).": { en: "Path to the browser executable (for reference only - do not launch it yourself, always open through /open).", ru: "Путь к исполняемому файлу браузера (только для справки - не запускайте его сами, всегда открывайте через /open).", zh: "浏览器可执行文件路径（仅供参考 - 不要自行运行，请始终通过 /open 打开）。" },
  "ID (hoặc tên) quy trình đã lưu.": { en: "ID (or name) of the saved workflow.", ru: "ID (или название) сохранённого процесса.", zh: "已保存流程的 ID（或名称）。" },
  "Danh sách ID hồ sơ cần chạy.": { en: "List of profile IDs to run.", ru: "Список ID профилей для запуска.", zh: "要运行的配置文件 ID 列表。" },
  "RAM theo GiB (navigator.deviceMemory).": { en: "RAM in GiB (navigator.deviceMemory).", ru: "RAM в ГиБ (navigator.deviceMemory).", zh: "RAM，单位 GiB（navigator.deviceMemory）。" },
  "ws:// endpoint cho puppeteer.connect() / playwright.chromium.connectOverCDP().": { en: "ws:// endpoint for puppeteer.connect() / playwright.chromium.connectOverCDP().", ru: "ws:// endpoint для puppeteer.connect() / playwright.chromium.connectOverCDP().", zh: "用于 puppeteer.connect() / playwright.chromium.connectOverCDP() 的 ws:// 端点。" },
  "debuggerAddress cho chromedriver (host:port).": { en: "debuggerAddress for chromedriver (host:port).", ru: "debuggerAddress для chromedriver (host:port).", zh: "chromedriver 使用的 debuggerAddress（host:port）。" },
  // ── Sidebar: ghim mục menu (app.js navPinHtml) ──
  'Ghim lên đầu': { en: 'Pin to top', ru: 'Закрепить вверху', zh: '置顶' },
  'Bỏ ghim': { en: 'Unpin', ru: 'Открепить', zh: '取消置顶' },
  'không tải được swagger-ui-bundle.js': { en: 'could not load swagger-ui-bundle.js', ru: 'не удалось загрузить swagger-ui-bundle.js', zh: '无法加载 swagger-ui-bundle.js' },
  'Không thấy ứng dụng bạn cần?': { en: "Can't find the app you need?", ru: 'Не нашли нужное приложение?', zh: '找不到你需要的应用？' },
  'Không tìm thấy cửa sổ trình duyệt nào đang mở.': { en: 'No open browser window found.', ru: 'Не найдено открытых окон браузера.', zh: '未找到已打开的浏览器窗口。' },
  'Không tìm thấy nhiệm vụ.': { en: 'Task not found.', ru: 'Задача не найдена.', zh: '未找到任务。' },
  'Không tìm thấy phần tử': { en: 'Element not found', ru: 'Элемент не найден', zh: '未找到元素' },
  'Không xóa được văn bản.': { en: 'Could not delete text.', ru: 'Не удалось удалить текст.', zh: '无法删除文本。' },
  'Khởi động tham số': { en: 'Launch parameters', ru: 'Параметры запуска', zh: '启动参数' },
  'Khu vực chỉnh sửa nút': { en: 'Node editing area', ru: 'Область редактирования узла', zh: '节点编辑区' },
  'Kích cỡ đồng nhất': { en: 'Uniform size', ru: 'Одинаковый размер', zh: '统一大小' },
  'Kích thước hình ảnh': { en: 'Image size', ru: 'Размер изображения', zh: '图片尺寸' },
  'Kiểm tra': { en: 'Check', ru: 'Проверить', zh: '检测' },
  'Kiểm tra Meta (Facebook) Pixel hoạt động trên website.': { en: 'Check whether the Meta (Facebook) Pixel works on the website.', ru: 'Проверьте, работает ли Meta (Facebook) Pixel на сайте.', zh: '检测网站上的 Meta (Facebook) Pixel 是否正常工作。' },
  'Kiểm tra thẻ Google (GA, GTM) đã cài đặt đúng hay chưa.': { en: 'Check whether Google tags (GA, GTM) are installed correctly.', ru: 'Проверьте, правильно ли установлены теги Google (GA, GTM).', zh: '检测 Google 代码（GA、GTM）是否安装正确。' },
  'Kiểu trả về': { en: 'Return type', ru: 'Тип возврата', zh: '返回类型' },
  'Kinh độ': { en: 'Longitude', ru: 'Долгота', zh: '经度' },
  'Ký tự đặc biệt': { en: 'Special characters', ru: 'Специальные символы', zh: '特殊字符' },
  'Ký tự nối': { en: 'Joining character', ru: 'Соединительный символ', zh: '连接符' },
  'Ký tự phân cách': { en: 'Separator character', ru: 'Символ-разделитель', zh: '分隔字符' },
  'Ký tự phân tách': { en: 'Delimiter character', ru: 'Символ-разделитель', zh: '分隔字符' },
  'là bất kỳ': { en: 'is any', ru: 'любой', zh: '是任意' },
  'Làm lại (Ctrl+Y)': { en: 'Redo (Ctrl+Y)', ru: 'Повторить (Ctrl+Y)', zh: '重做 (Ctrl+Y)' },
  'làm mờ': { en: 'blur', ru: 'размытие', zh: '模糊' },
  'làm mới': { en: 'refresh', ru: 'обновить', zh: '刷新' },
  'Làm tròn gần nhất': { en: 'Round to nearest', ru: 'Округлить до ближайшего', zh: '四舍五入' },
  'Làm tròn lên': { en: 'Round up', ru: 'Округлить вверх', zh: '向上取整' },
  'Làm tròn xuống': { en: 'Round down', ru: 'Округлить вниз', zh: '向下取整' },
  'làn': { en: 'lane', ru: 'полоса', zh: '道' },
  'Lần chạy cuối': { en: 'Last run', ru: 'Последний запуск', zh: '最后运行' },
  'Lần chạy gần nhất': { en: 'Most recent run', ru: 'Последний запуск', zh: '最近一次运行' },
  'Lập Lịch': { en: 'Schedule', ru: 'Расписание', zh: '计划' },
  'Lấy các dữ liệu về phần tử': { en: 'Get element data', ru: 'Получить данные об элементе', zh: '获取元素的数据' },
  'Lấy danh mục ngẫu nhiên': { en: 'Get a random category', ru: 'Получить случайную категорию', zh: '获取随机类目' },
  'Lấy dữ liệu người dùng hiện tại': { en: 'Get current user data', ru: 'Получить данные текущего пользователя', zh: '获取当前用户数据' },
  'Lấy dữ liệu tài nguyên': { en: 'Get resource data', ru: 'Получить данные ресурса', zh: '获取资源数据' },
  'Lấy mã màu (eyedropper) và phân tích màu trên trang web.': { en: 'Pick color codes (eyedropper) and analyze colors on the web page.', ru: 'Выбирайте коды цветов (пипетка) и анализируйте цвета на веб-странице.', zh: '在网页上拾取颜色代码（取色器）并分析颜色。' },
  'Lấy mã OTP 2FA': { en: 'Get 2FA OTP code', ru: 'Получить код OTP 2FA', zh: '获取 2FA OTP 验证码' },
  'Lấy mã OTP từ mã 2FA': { en: 'Get the OTP code from the 2FA secret', ru: 'Получить код OTP из секрета 2FA', zh: '从 2FA 密钥获取 OTP 验证码' },
  'Lấy quy trình': { en: 'Get workflow', ru: 'Получить процесс', zh: '获取流程' },
  'Lấy tài nguyên': { en: 'Get resource', ru: 'Получить ресурс', zh: '获取资源' },
  'Lấy tất cả đường dẫn của tệp trong thư mục': { en: 'Get all file paths in the folder', ru: 'Получить все пути к файлам в папке', zh: '获取文件夹中所有文件的路径' },
  'Lên lịch thực hiện': { en: 'Schedule execution', ru: 'Запланировать выполнение', zh: '计划执行' },
  'Lệnh cmd': { en: 'cmd command', ru: 'Команда cmd', zh: 'cmd 命令' },
  'Lịch': { en: 'Schedule', ru: 'Расписание', zh: '计划' },
  'Loại bỏ khoảng trắng ở đầu và cuối chuỗi': { en: 'Trim whitespace from the start and end of the string', ru: 'Убрать пробелы в начале и конце строки', zh: '去除字符串首尾的空白' },
  'Loại tài nguyên': { en: 'Resource type', ru: 'Тип ресурса', zh: '资源类型' },
  'Lọc': { en: 'Filter', ru: 'Фильтр', zh: '筛选' },
  'lộ': { en: 'exposed', ru: 'раскрыт', zh: '暴露' },
  'lỗi': { en: 'error', ru: 'ошибка', zh: '错误' },
  'Lỗi khi kiểm tra proxy': { en: 'Error while checking the proxy', ru: 'Ошибка при проверке прокси', zh: '检测代理时出错' },
  'Lỗi không xác định': { en: 'Unknown error', ru: 'Неизвестная ошибка', zh: '未知错误' },
  'Lỗi tạo nhóm:': { en: 'Error creating group:', ru: 'Ошибка создания группы:', zh: '创建分组出错：' },
  'Lỗi:': { en: 'Error:', ru: 'Ошибка:', zh: '错误：' },
  'Lơ': { en: 'Cyan', ru: 'Голубой', zh: '青色' },
  'Luôn cho phép': { en: 'Always allow', ru: 'Всегда разрешать', zh: '始终允许' },
  'Lưới': { en: 'Grid', ru: 'Сетка', zh: '网格' },
  'Lưu mật khẩu': { en: 'Save password', ru: 'Сохранить пароль', zh: '保存密码' },
  'Lưu media': { en: 'Save media', ru: 'Сохранить медиа', zh: '保存媒体' },
  'Lưu proxy thất bại:': { en: 'Failed to save proxy:', ru: 'Не удалось сохранить прокси:', zh: '保存代理失败：' },
  'Lưu quy trình thất bại': { en: 'Failed to save workflow', ru: 'Не удалось сохранить процесс', zh: '保存流程失败' },
  'Lưu ý: Thao tác này sẽ xóa cả hồ sơ và dữ liệu trong nhóm.': { en: 'Note: this will delete both the profiles and the data in the group.', ru: 'Примечание: это удалит и профили, и данные в группе.', zh: '注意：此操作将同时删除分组内的配置文件和数据。' },
  'Mã 2FA': { en: '2FA code', ru: 'Код 2FA', zh: '2FA 验证码' },
  'Màn hình': { en: 'Screen', ru: 'Экран', zh: '屏幕' },
  'Màu': { en: 'Color', ru: 'Цвет', zh: '颜色' },
  'Mật khẩu tối thiểu 6 ký tự': { en: 'Password must be at least 6 characters', ru: 'Пароль должен содержать не менее 6 символов', zh: '密码至少 6 个字符' },
  'Mẫu': { en: 'Template', ru: 'Шаблон', zh: '模板' },
  'Media lấy từ': { en: 'Media taken from', ru: 'Медиа взято из', zh: '媒体来源' },
  'Mili giây': { en: 'Millisecond', ru: 'Миллисекунда', zh: '毫秒' },
  'Model tùy chỉnh': { en: 'Custom model', ru: 'Пользовательская модель', zh: '自定义模型' },
  'mọi thứ ở Đầu vào đều còn luôn': { en: 'everything in Input is still kept', ru: 'всё во входных данных сохраняется', zh: '输入中的所有内容都保留' },
  'Mô tả': { en: 'Description', ru: 'Описание', zh: '描述' },
  'Mỗi dòng một tham số khởi động trình duyệt (ví dụ: --disable-notifications). Áp dụng khi quy trình mở trình duyệt.': { en: 'One browser launch parameter per line (e.g. --disable-notifications). Applied when the workflow opens the browser.', ru: 'Один параметр запуска браузера в строке (например, --disable-notifications). Применяется, когда процесс открывает браузер.', zh: '每行一个浏览器启动参数（例如 --disable-notifications）。当流程打开浏览器时生效。' },
  'Một cho tất cả': { en: 'One for all', ru: 'Один для всех', zh: '一对全部' },
  'Một phần': { en: 'Partial', ru: 'Частично', zh: '部分' },
  'Mở rộng': { en: 'Expand', ru: 'Развернуть', zh: '展开' },
  'Dọn nhật ký': { en: 'Clear log', ru: 'Очистить журнал', zh: '清空日志' },
  'Mở sơ đồ quy trình': { en: 'Open the workflow diagram', ru: 'Открыть схему процесса', zh: '打开流程图' },
  'Mời bạn bè tham gia nhóm': { en: 'Invite friends to the group', ru: 'Пригласить друзей в группу', zh: '邀请好友加入群组' },
  'mua gói lưu lượng': { en: 'buy a traffic plan', ru: 'купить тариф трафика', zh: '购买流量套餐' },
  'Múi giờ → Tùy chỉnh': { en: 'Timezone → Custom', ru: 'Часовой пояс → Пользовательский', zh: '时区 → 自定义' },
  'Nếu bạn muốn thực hiện một nhiệm vụ trong cùng một ngày, thời gian thực hiện nên là 10 phút sau thời điểm bắt đầu': { en: 'If you want to run a task on the same day, the run time should be 10 minutes after the start time', ru: 'Если вы хотите выполнить задачу в тот же день, время выполнения должно быть на 10 минут позже времени начала', zh: '若想在当天执行任务，执行时间应设为开始时间之后 10 分钟' },
  'Nếu không nhập số lượng tệp thì sẽ tải lên tất cả các tệp trong thư mục, nếu có sẽ tải lên ngẫu theo số lượng tệp': { en: 'If no file count is entered, all files in the folder are uploaded; if provided, files are uploaded randomly by that count', ru: 'Если количество файлов не указано, загружаются все файлы из папки; если указано - файлы загружаются случайно в этом количестве', zh: '若未填写文件数量，则上传文件夹中所有文件；若填写，则按该数量随机上传文件' },
  'Nếu ứng dụng này bị xóa, nó sẽ bị gỡ cài đặt trong tất cả các trình duyệt.': { en: 'If this app is removed, it will be uninstalled from all browsers.', ru: 'Если это приложение удалить, оно будет удалено во всех браузерах.', zh: '如果删除此应用，它将从所有浏览器中被卸载。' },
  'Ngày': { en: 'Day', ru: 'День', zh: '天' },
  'Ngày tạo (cũ nhất)': { en: 'Creation date (oldest)', ru: 'Дата создания (сначала старые)', zh: '创建日期（最早）' },
  'Ngày tạo (mới nhất)': { en: 'Creation date (newest)', ru: 'Дата создания (сначала новые)', zh: '创建日期（最新）' },
  'Ngôn ngữ → Tùy chỉnh': { en: 'Language → Custom', ru: 'Язык → Пользовательский', zh: '语言 → 自定义' },
  'Nhà cung cấp:': { en: 'Provider:', ru: 'Провайдер:', zh: '提供商：' },
  'Nhấn "Mua gói lưu lượng" để bắt đầu.': { en: 'Click "Buy a traffic plan" to get started.', ru: 'Нажмите «Купить тариф трафика», чтобы начать.', zh: '点击“购买流量套餐”即可开始。' },
  'Nhận diện công nghệ đứng sau bất kỳ website nào.': { en: 'Identify the technology behind any website.', ru: 'Определяйте технологии, на которых работает любой сайт.', zh: '识别任何网站背后所用的技术。' },
  'Nhấn để cấu hình': { en: 'Click to configure', ru: 'Нажмите, чтобы настроить', zh: '点击进行配置' },
  'Nhấn và kéo lâu để di chuyển vào một nhóm': { en: 'Press and hold, then drag to move into a group', ru: 'Нажмите и удерживайте, затем перетащите, чтобы переместить в группу', zh: '长按并拖动以移入分组' },
  'Nhập ghi chú': { en: 'Enter a note', ru: 'Введите заметку', zh: '输入备注' },
  'Nhập ghi chú cho node…': { en: 'Enter a note for the node…', ru: 'Введите заметку для узла…', zh: '为节点输入备注…' },
  'Nhập giá trị': { en: 'Enter a value', ru: 'Введите значение', zh: '输入值' },
  'Nhập giá trị để thêm thẻ mới': { en: 'Enter a value to add a new tag', ru: 'Введите значение, чтобы добавить новый тег', zh: '输入值以添加新标签' },
  'Nhập Host và Port trước khi kiểm tra': { en: 'Enter Host and Port before checking', ru: 'Введите Host и Port перед проверкой', zh: '检测前请输入 Host 和 Port' },
  'Nhập ngẫu nhiên': { en: 'Random input', ru: 'Случайный ввод', zh: '随机输入' },
  'nhập tên hành động': { en: 'enter the action name', ru: 'введите название действия', zh: '输入操作名称' },
  'Nhập tên hành động': { en: 'Enter the action name', ru: 'Введите название действия', zh: '输入操作名称' },
  'Nhập tên hồ sơ': { en: 'Enter the profile name', ru: 'Введите имя профиля', zh: '输入配置文件名称' },
  'Nhập tên quy trình': { en: 'Enter the workflow name', ru: 'Введите название процесса', zh: '输入流程名称' },
  'Nhập tên thẻ': { en: 'Enter the tag name', ru: 'Введите название тега', zh: '输入标签名称' },
  'Nhập theo thứ tự': { en: 'Input in order', ru: 'Ввод по порядку', zh: '按顺序输入' },
  'Nhập vào danh sách': { en: 'Import into list', ru: 'Импорт в список', zh: '导入到列表' },
  'Nhấp vào Khôi phục cửa sổ/Đóng cửa sổ để khôi phục thanh hành động về vị trí ban đầu': { en: 'Click Restore window/Close window to return the action bar to its original position', ru: 'Нажмите «Восстановить окно/Закрыть окно», чтобы вернуть панель действий на исходное место', zh: '点击“恢复窗口/关闭窗口”以将操作栏恢复到原始位置' },
  'Nhật Ký Chung': { en: 'Activity Log', ru: 'Общий журнал', zh: '通用日志' },
  'Nhiệm Vụ': { en: 'Tasks', ru: 'Задачи', zh: '任务' },
  'Nhiệm vụ chưa có hồ sơ nào': { en: 'The task has no profiles yet', ru: 'В задаче пока нет профилей', zh: '任务还没有任何配置文件' },
  'Nhiệm vụ của lịch này đã bị xóa': { en: 'The task of this schedule has been deleted', ru: 'Задача этого расписания была удалена', zh: '此计划的任务已被删除' },
  'Nhiệm vụ đang chạy': { en: 'Running tasks', ru: 'Выполняемые задачи', zh: '正在运行的任务' },
  'Nội dung 1: Hãy nhập nội dung': { en: 'Content 1: Please enter content', ru: 'Содержимое 1: введите содержимое', zh: '内容 1：请输入内容' },
  'Nội dung N:': { en: 'Content N:', ru: 'Содержимое N:', zh: '内容 N：' },
  'Nội dung nhập': { en: 'Input content', ru: 'Введённое содержимое', zh: '输入内容' },
  'Nội dung quy trình không hợp lệ': { en: 'Invalid workflow content', ru: 'Недопустимое содержимое процесса', zh: '流程内容无效' },
  'Phải lớn hơn thời điểm hiện tại': { en: 'Must be later than the current time', ru: 'Должно быть позже текущего времени', zh: '必须晚于当前时间' },
  'Phải sau thời gian bắt đầu. Nếu không chọn nghĩa là nhiệm vụ không có thời gian kết thúc cụ thể.': { en: 'Must be after the start time. If not set, the task has no specific end time.', ru: 'Должно быть позже времени начала. Если не задано, у задачи нет конкретного времени окончания.', zh: '必须晚于开始时间。若不设置，则任务没有具体的结束时间。' },
  'phản ứng rất lâu mới chạy': { en: 'reacts very slowly before running', ru: 'реагирует очень долго перед запуском', zh: '反应很久才运行' },
  'phút': { en: 'minutes', ru: 'минут', zh: '分钟' },
  'Português': { en: 'Português', ru: 'Português', zh: 'Português' },
  'Português (Brasil)': { en: 'Português (Brasil)', ru: 'Português (Brasil)', zh: 'Português (Brasil)' },
  'Português (Portugal)': { en: 'Português (Portugal)', ru: 'Português (Portugal)', zh: 'Português (Portugal)' },
  'Proxy thường': { en: 'Regular proxy', ru: 'Обычный прокси', zh: '普通代理' },
  'Quản lý và chuyển đổi nhiều proxy chỉ với một cú nhấp.': { en: 'Manage and switch between multiple proxies with a single click.', ru: 'Управляйте и переключайтесь между несколькими прокси одним кликом.', zh: '一键管理和切换多个代理。' },
  'Quay lại danh sách': { en: 'Back to list', ru: 'Назад к списку', zh: '返回列表' },
  'Quét bài viết mới nhất theo từ khóa': { en: 'Scan the latest posts by keyword', ru: 'Сканировать последние публикации по ключевому слову', zh: '按关键词扫描最新帖子' },
  'Quét bài viết trên tường cá nhân hoặc trang': { en: 'Scan posts on a personal wall or page', ru: 'Сканировать публикации на личной стене или странице', zh: '扫描个人主页或主页上的帖子' },
  'Quét bài viết trong nhóm': { en: 'Scan posts in a group', ru: 'Сканировать публикации в группе', zh: '扫描群组内的帖子' },
  'Quét bạn bè của tài khoản': { en: 'Scan the account\'s friends', ru: 'Сканировать друзей аккаунта', zh: '扫描账号的好友' },
  'Quét danh sách nhóm mà tài khoản đã tham gia': { en: 'Scan the list of groups the account has joined', ru: 'Сканировать список групп, в которые вступил аккаунт', zh: '扫描账号已加入的群组列表' },
  'Quét danh sách tài khoản đang theo dõi của tài khoản': { en: 'Scan the list of accounts the account is following', ru: 'Сканировать список аккаунтов, на которые подписан аккаунт', zh: '扫描账号正在关注的账号列表' },
  'Quét danh sách trang của tài khoản': { en: 'Scan the account\'s list of pages', ru: 'Сканировать список страниц аккаунта', zh: '扫描账号的主页列表' },
  'Quét người tương tác bài viết': { en: 'Scan people who interacted with the post', ru: 'Сканировать людей, взаимодействовавших с публикацией', zh: '扫描与帖子互动的用户' },
  'Quét nhóm theo từ khóa': { en: 'Scan groups by keyword', ru: 'Сканировать группы по ключевому слову', zh: '按关键词扫描群组' },
  'Quét thành viên mới tham gia nhóm': { en: 'Scan members newly joined to the group', ru: 'Сканировать новых участников группы', zh: '扫描新加入群组的成员' },
  'Quét trang theo từ khóa': { en: 'Scan pages by keyword', ru: 'Сканировать страницы по ключевому слову', zh: '按关键词扫描主页' },
  'Quét video xu hướng trên Reels': { en: 'Scan trending videos on Reels', ru: 'Сканировать популярные видео в Reels', zh: '扫描 Reels 上的热门视频' },
  'Quy trình chưa đặt tên': { en: 'Untitled workflow', ru: 'Процесс без названия', zh: '未命名流程' },
  'Quy trình hoàn tất': { en: 'Workflow completed', ru: 'Процесс завершён', zh: '流程完成' },
  'Quy trình RPA': { en: 'RPA workflow', ru: 'Процесс RPA', zh: 'RPA 流程' },
  'Quy trình thất bại': { en: 'Workflow failed', ru: 'Процесс завершился с ошибкой', zh: '流程失败' },
  'Quy trình thất bại:': { en: 'Workflow failed:', ru: 'Процесс завершился с ошибкой:', zh: '流程失败：' },
  'Quy trình trống': { en: 'Empty workflow', ru: 'Пустой процесс', zh: '空流程' },
  'Range (Tùy chọn)': { en: 'Range (Optional)', ru: 'Диапазон (необязательно)', zh: '范围（可选）' },
  'Română': { en: 'Română', ru: 'Română', zh: 'Română' },
  'S SHORT ID (not "Nội dung N") - each window': { en: 'S SHORT ID (not "Nội dung N") - each window', ru: 'S SHORT ID (not "Nội dung N") - each window', zh: 'S SHORT ID (not "Nội dung N") - each window' },
  'Sao chép biểu thức': { en: 'Copy expression', ru: 'Копировать выражение', zh: '复制表达式' },
  'Sau khi bật, trình duyệt được phép lưu mật khẩu đăng nhập': { en: 'When enabled, the browser is allowed to save login passwords', ru: 'Когда включено, браузеру разрешено сохранять пароли для входа', zh: '启用后，浏览器可以保存登录密码' },
  'Sau khi bật, trình duyệt sẽ không tự động điền tài khoản và mật khẩu đã lưu': { en: 'When enabled, the browser will not auto-fill saved accounts and passwords', ru: 'Когда включено, браузер не будет автоматически заполнять сохранённые логины и пароли', zh: '启用后，浏览器不会自动填充已保存的账号和密码' },
  'Sau khi bật, trình duyệt sẽ tự động xóa bộ nhớ đệm khi đóng': { en: 'When enabled, the browser will automatically clear the cache on close', ru: 'Когда включено, браузер автоматически очистит кэш при закрытии', zh: '启用后，浏览器关闭时将自动清除缓存' },
  'Sau khi đóng bảng điều khiển, bạn có thể mở lại thông qua [Synchronizer] > Console': { en: 'After closing the console, you can reopen it via [Synchronizer] > Console', ru: 'После закрытия консоли её можно снова открыть через [Synchronizer] > Console', zh: '关闭控制台后，可通过 [Synchronizer] > Console 重新打开' },
  'Sắp xếp': { en: 'Arrange', ru: 'Упорядочить', zh: '排列' },
  'sắp xếp thông minh': { en: 'smart arrange', ru: 'умное упорядочивание', zh: '智能排列' },
  'Sắp xếp tự động các cửa sổ đã chọn theo độ phân giải màn hình': { en: 'Automatically arrange the selected windows by screen resolution', ru: 'Автоматически упорядочить выбранные окна по разрешению экрана', zh: '按屏幕分辨率自动排列所选窗口' },
  'Sắp xếp/đồng bộ cửa sổ cần API Win32 - không khả dụng trong bản Electron.': { en: 'Arranging/syncing windows requires the Win32 API - not available in the Electron build.', ru: 'Упорядочивание/синхронизация окон требует Win32 API - недоступно в сборке Electron.', zh: '排列/同步窗口需要 Win32 API - Electron 版本不支持。' },
  'sóng': { en: 'wave', ru: 'волна', zh: '波' },
  'Số bắt đầu': { en: 'Start number', ru: 'Начальное число', zh: '起始数' },
  'Số bắt đầu (giây)': { en: 'Start number (seconds)', ru: 'Начальное число (секунды)', zh: '起始数（秒）' },
  'Số dòng mỗi trang': { en: 'Rows per page', ru: 'Строк на странице', zh: '每页行数' },
  // Tooltip 2 nút mũi tên của thanh phân trang panel "Hồ sơ áp dụng" (trang Proxies).
  'Trang trước': { en: 'Previous page', ru: 'Предыдущая страница', zh: '上一页' },
  'Trang sau': { en: 'Next page', ru: 'Следующая страница', zh: '下一页' },
  'Số dòng mỗi trang:': { en: 'Rows per page:', ru: 'Строк на странице:', zh: '每页行数：' },
  'Số giây tối đa': { en: 'Maximum seconds', ru: 'Максимум секунд', zh: '最大秒数' },
  'Số giây tối thiểu': { en: 'Minimum seconds', ru: 'Минимум секунд', zh: '最小秒数' },
  'Số kết thúc': { en: 'End number', ru: 'Конечное число', zh: '结束数' },
  'Số kết thúc (giây)': { en: 'End number (seconds)', ru: 'Конечное число (секунды)', zh: '结束数（秒）' },
  'Số lớn nhất': { en: 'Maximum number', ru: 'Наибольшее число', zh: '最大值' },
  'số luồng đồng thời': { en: 'concurrent threads', ru: 'одновременных потоков', zh: '并发线程数' },
  'Số lượng': { en: 'Quantity', ru: 'Количество', zh: '数量' },
  'Số lượng bài viết quét tối đa': { en: 'Maximum number of posts to scan', ru: 'Максимальное число публикаций для сканирования', zh: '最大扫描帖子数' },
  'Số lượng bạn bè mỗi lần mời': { en: 'Number of friends per invite', ru: 'Число друзей за одно приглашение', zh: '每次邀请的好友数' },
  'Số lượng bạn bè quét tối đa': { en: 'Maximum number of friends to scan', ru: 'Максимальное число друзей для сканирования', zh: '最大扫描好友数' },
  'Số lượng chấp nhận tối đa': { en: 'Maximum number of accepts', ru: 'Максимальное число принятий', zh: '最大接受数量' },
  'Số lượng nhóm quét tối đa': { en: 'Maximum number of groups to scan', ru: 'Максимальное число групп для сканирования', zh: '最大扫描群组数' },
  'Số lượng phần tử': { en: 'Number of elements', ru: 'Число элементов', zh: '元素数量' },
  'Số lượng quét tối đa': { en: 'Maximum scan count', ru: 'Максимальное число сканирований', zh: '最大扫描数量' },
  'Số lượng tệp tải lên': { en: 'Number of files to upload', ru: 'Число загружаемых файлов', zh: '上传文件数量' },
  'Số lượng thành viên quét tối đa': { en: 'Maximum number of members to scan', ru: 'Максимальное число участников для сканирования', zh: '最大扫描成员数' },
  'Số lượng trang quét tối đa': { en: 'Maximum number of pages to scan', ru: 'Максимальное число страниц для сканирования', zh: '最大扫描主页数' },
  'Số nhỏ nhất': { en: 'Minimum number', ru: 'Наименьшее число', zh: '最小值' },
  'Sử dụng các API có sẵn của Facebook': { en: 'Use the available Facebook APIs', ru: 'Использовать доступные API Facebook', zh: '使用 Facebook 提供的 API' },
  'Sử dụng ChatGPT để yêu cầu trả lời câu hỏi, viết nội dung.': { en: 'Use ChatGPT to answer questions and write content.', ru: 'Используйте ChatGPT для ответов на вопросы и написания контента.', zh: '使用 ChatGPT 回答问题、撰写内容。' },
  'Sử dụng Gemini để yêu cầu trả lời câu hỏi, viết nội dung.': { en: 'Use Gemini to answer questions and write content.', ru: 'Используйте Gemini для ответов на вопросы и написания контента.', zh: '使用 Gemini 回答问题、撰写内容。' },
  'Sử dụng văn bản được bôi đen trên trang': { en: 'Use the text selected on the page', ru: 'Использовать текст, выделенный на странице', zh: '使用页面上选中的文本' },
  'Sửa vân tay mới': { en: 'New fingerprint edit', ru: 'Новое изменение отпечатка', zh: '修改为新指纹' },
  'SwaggerUIBundle không khả dụng': { en: 'SwaggerUIBundle is not available', ru: 'SwaggerUIBundle недоступен', zh: 'SwaggerUIBundle 不可用' },
  'Tab bên phải': { en: 'Tab on the right', ru: 'Вкладка справа', zh: '右侧标签页' },
  'Tab bên trái': { en: 'Tab on the left', ru: 'Вкладка слева', zh: '左侧标签页' },
  'Tab có thứ tự': { en: 'Tab by order', ru: 'Вкладка по порядку', zh: '按顺序的标签页' },
  'Tab khớp với mẫu': { en: 'Tab matching the pattern', ru: 'Вкладка, совпадающая с шаблоном', zh: '匹配模式的标签页' },
  'Tab khớp với tiêu đề': { en: 'Tab matching the title', ru: 'Вкладка, совпадающая с заголовком', zh: '匹配标题的标签页' },
  'Tài khoản nền tảng': { en: 'Platform account', ru: 'Аккаунт платформы', zh: '平台账号' },
  'Tại lại trang': { en: 'Reload the page', ru: 'Перезагрузить страницу', zh: '重新加载页面' },
  'Tải lên bằng dialog': { en: 'Upload via dialog', ru: 'Загрузить через диалог', zh: '通过对话框上传' },
  'Tải lên file': { en: 'Upload file', ru: 'Загрузить файл', zh: '上传文件' },
  'Tài Liệu API': { en: 'API Docs', ru: 'Документация API', zh: 'API 文档' },
  'Tải Tệp Lên': { en: 'Upload File', ru: 'Загрузить файл', zh: '上传文件' },
  'Tạo …': { en: 'Create …', ru: 'Создать …', zh: '创建 …' },
  'Tạo ↵': { en: 'Create ↵', ru: 'Создать ↵', zh: '创建 ↵' },
  'Tạo dữ liệu ngẫu nhiên': { en: 'Generate random data', ru: 'Сгенерировать случайные данные', zh: '生成随机数据' },
  'Tạo Hàng Loạt': { en: 'Batch Create', ru: 'Массовое создание', zh: '批量创建' },
  'Tạo lại': { en: 'Regenerate', ru: 'Создать заново', zh: '重新生成' },
  'Tạo lại User-Agent': { en: 'Regenerate User-Agent', ru: 'Создать User-Agent заново', zh: '重新生成 User-Agent' },
  'Tạo mã xác thực 2 bước (2FA / OTP) ngay trên trình duyệt.': { en: 'Generate two-factor authentication codes (2FA / OTP) right in the browser.', ru: 'Генерируйте коды двухфакторной аутентификации (2FA / OTP) прямо в браузере.', zh: '直接在浏览器中生成两步验证码（2FA / OTP）。' },
  'Tạo quy trình': { en: 'Create workflow', ru: 'Создать процесс', zh: '创建流程' },
  'Tạo tab': { en: 'Create tab', ru: 'Создать вкладку', zh: '创建标签页' },
  'Tạo tác vụ': { en: 'Create task', ru: 'Создать задачу', zh: '创建任务' },
  'Tạo tài khoản': { en: 'Create account', ru: 'Создать аккаунт', zh: '创建账号' },
  'Tạo tài khoản CGTBrowser mới': { en: 'Create a new CGTBrowser account', ru: 'Создать новый аккаунт CGTBrowser', zh: '创建新的 CGTBrowser 账号' },
  'Tạo tài khoản thành công': { en: 'Account created successfully', ru: 'Аккаунт успешно создан', zh: '账号创建成功' },
  'Tạo tài nguyên nếu chưa tồn tại': { en: 'Create the resource if it does not exist', ru: 'Создать ресурс, если он не существует', zh: '若资源不存在则创建' },
  'Tạo thành viên/Email': { en: 'Create member/Email', ru: 'Создать участника/Email', zh: '创建成员/邮箱' },
  'Tạo trang': { en: 'Create page', ru: 'Создать страницу', zh: '创建主页' },
  'Tạo, sửa, xóa và xuất/nhập cookie ngay trong trình duyệt.': { en: 'Create, edit, delete and export/import cookies right in the browser.', ru: 'Создавайте, редактируйте, удаляйте и экспортируйте/импортируйте cookie прямо в браузере.', zh: '直接在浏览器中创建、编辑、删除以及导入/导出 Cookie。' },
  'tắt': { en: 'off', ru: 'выкл', zh: '关' },
  'Tắt': { en: 'Off', ru: 'Выкл', zh: '关' },
  'tắt bật lại': { en: 'toggle off then on', ru: 'выключить и снова включить', zh: '关闭再开启' },
  'Tất cả nguồn': { en: 'All sources', ru: 'Все источники', zh: '全部来源' },
  'Tất cả thành viên': { en: 'All members', ru: 'Все участники', zh: '全部成员' },
  'Test thử': { en: 'Test', ru: 'Тест', zh: '测试' },
  'Tên (A → Z)': { en: 'Name (A → Z)', ru: 'Имя (A → Z)', zh: '名称 (A → Z)' },
  'Tên (Z → A)': { en: 'Name (Z → A)', ru: 'Имя (Z → A)', zh: '名称 (Z → A)' },
  'Tên cơ sở': { en: 'Base name', ru: 'Базовое имя', zh: '基础名称' },
  'Tên của bạn': { en: 'Your name', ru: 'Ваше имя', zh: '你的名字' },
  'Tên hiển thị': { en: 'Display name', ru: 'Отображаемое имя', zh: '显示名称' },
  'Tên luồng': { en: 'Flow name', ru: 'Название потока', zh: '流程名称' },
  'Tên nhóm': { en: 'Group name', ru: 'Название группы', zh: '分组名称' },
  'Tên quy trình': { en: 'Workflow name', ru: 'Название процесса', zh: '流程名称' },
  'Tên tài khoản hoặc email': { en: 'Username or email', ru: 'Имя пользователя или email', zh: '用户名或邮箱' },
  'Tên tệp (Tùy chọn)': { en: 'File name (Optional)', ru: 'Имя файла (необязательно)', zh: '文件名（可选）' },
  'Tên tệp ảnh': { en: 'Image file name', ru: 'Имя файла изображения', zh: '图片文件名' },
  'Tên thẻ': { en: 'Tag name', ru: 'Название тега', zh: '标签名称' },
  'Tên thiết bị': { en: 'Device name', ru: 'Имя устройства', zh: '设备名称' },
  'Tên trang': { en: 'Page name', ru: 'Название страницы', zh: '主页名称' },
  'Tên trang tính (Tùy chọn)': { en: 'Sheet name (Optional)', ru: 'Имя листа (необязательно)', zh: '工作表名称（可选）' },
  'Tệp hình ảnh đính kèm (tùy chọn)': { en: 'Attached image file (optional)', ru: 'Прикреплённый файл изображения (необязательно)', zh: '附加的图片文件（可选）' },
  'Tệp quy trình không hợp lệ': { en: 'Invalid workflow file', ru: 'Недопустимый файл процесса', zh: '流程文件无效' },
  'Tệp văn bản': { en: 'Text file', ru: 'Текстовый файл', zh: '文本文件' },
  'Tham số khởi động': { en: 'Launch parameters', ru: 'Параметры запуска', zh: '启动参数' },
  'Thành Viên': { en: 'Members', ru: 'Участники', zh: '成员' },
  'Thao tác hệ thống': { en: 'System operation', ru: 'Системная операция', zh: '系统操作' },
  'Thao tác này không cần cấu hình.': { en: 'This action needs no configuration.', ru: 'Это действие не требует настройки.', zh: '此操作无需配置。' },
  'Thao tác này sẽ xóa proxy ra khỏi các hồ sơ đã chọn. Bạn cần gán lại proxy nếu muốn dùng tiếp.': { en: 'This will remove the proxy from the selected profiles. You will need to reassign a proxy to keep using one.', ru: 'Это удалит прокси из выбранных профилей. Чтобы продолжить, потребуется назначить прокси заново.', zh: '此操作将从所选配置文件中移除代理。若要继续使用，你需要重新分配代理。' },
  'Thao tác nhấn phím': { en: 'Key press action', ru: 'Действие нажатия клавиши', zh: '按键操作' },
  'Thao tác với cookies: nhập cookie, xuất cookie, xóa cookie': { en: 'Cookie operations: import cookies, export cookies, delete cookies', ru: 'Операции с cookie: импорт, экспорт, удаление', zh: 'Cookie 操作：导入 Cookie、导出 Cookie、删除 Cookie' },
  'Thao tác với dữ liệu sao chép được lưu ở bộ nhớ tạm': { en: 'Operate on copied data stored in the clipboard', ru: 'Работа со скопированными данными в буфере обмена', zh: '操作剪贴板中保存的复制数据' },
  'thẳng trục dọc': { en: 'straight vertical axis', ru: 'по вертикальной оси', zh: '沿垂直轴' },
  'Thẻ': { en: 'Tag', ru: 'Тег', zh: '标签' },
  'Thẻ đã tồn tại': { en: 'Tag already exists', ru: 'Тег уже существует', zh: '标签已存在' },
  'Theo dõi cài đặt chung': { en: 'Follow the general settings', ru: 'Следовать общим настройкам', zh: '跟随通用设置' },
  'Theo dõi ứng dụng nhóm': { en: 'Follow group apps', ru: 'Следовать групповым приложениям', zh: '跟随分组应用' },
  'Thêm bookmark': { en: 'Add bookmark', ru: 'Добавить закладку', zh: '添加书签' },
  'Thêm dữ liệu vào': { en: 'Add data to', ru: 'Добавить данные в', zh: '添加数据到' },
  'Thêm tag': { en: 'Add tag', ru: 'Добавить тег', zh: '添加标签' },
  'Thêm thẻ': { en: 'Add tag', ru: 'Добавить тег', zh: '添加标签' },
  'Thêm vào': { en: 'Add to', ru: 'Добавить в', zh: '添加到' },
  'Thiết bị truyền thông': { en: 'Media device', ru: 'Мультимедийное устройство', zh: '媒体设备' },
  'Thiết lập phương thức xử lý lỗi mặc định cho toàn bộ quy trình. Nếu một bước thao tác có thiết lập riêng, thì sẽ không bị ảnh hưởng bởi thiết lập này.': { en: 'Set the default error-handling method for the entire workflow. If a step has its own setting, it is not affected by this.', ru: 'Задайте способ обработки ошибок по умолчанию для всего процесса. Если у шага есть собственная настройка, она не зависит от этой.', zh: '设置整个流程的默认错误处理方式。若某个步骤有自己的设置，则不受此设置影响。' },
  'Thiếu Proxy Host': { en: 'Missing proxy host', ru: 'Отсутствует хост прокси', zh: '缺少代理主机' },
  'Thời gian bắt đầu không hợp lệ': { en: 'Invalid start time', ru: 'Недопустимое время начала', zh: '开始时间无效' },
  'Thời gian bắt đầu phải lớn hơn thời điểm hiện tại': { en: 'The start time must be later than the current time', ru: 'Время начала должно быть позже текущего времени', zh: '开始时间必须晚于当前时间' },
  'Thời gian chờ tìm phần tử (số giây)': { en: 'Element wait timeout (seconds)', ru: 'Тайм-аут ожидания элемента (секунды)', zh: '查找元素的等待时间（秒）' },
  'Thời gian chờ tìm phần tử tối đa (số giây)': { en: 'Maximum element wait timeout (seconds)', ru: 'Максимальный тайм-аут ожидания элемента (секунды)', zh: '查找元素的最大等待时间（秒）' },
  'Thời gian chờ tối đa (giây)': { en: 'Maximum wait time (seconds)', ru: 'Максимальное время ожидания (секунды)', zh: '最大等待时间（秒）' },
  'Thời gian chờ tối đa (số giây)': { en: 'Maximum wait time (seconds)', ru: 'Максимальное время ожидания (секунды)', zh: '最大等待时间（秒）' },
  'Thời gian chờ tối đa cho mỗi bước chờ phần tử. Quá thời gian này, bước sẽ bị coi là lỗi. 0 = mặc định 30 giây.': { en: 'Maximum wait time for each element-wait step. Beyond this, the step is treated as an error. 0 = default 30 seconds.', ru: 'Максимальное время ожидания для каждого шага ожидания элемента. По его истечении шаг считается ошибкой. 0 = по умолчанию 30 секунд.', zh: '每个等待元素步骤的最大等待时间。超过后该步骤将被视为错误。0 = 默认 30 秒。' },
  'Thời gian giữa các lần thực hiện tác vụ, đơn vị là phút': { en: 'Time between task runs, in minutes', ru: 'Время между выполнениями задачи, в минутах', zh: '任务每次执行之间的时间间隔，单位为分钟' },
  'Thời gian kết thúc phải lớn hơn thời điểm hiện tại': { en: 'The end time must be later than the current time', ru: 'Время окончания должно быть позже текущего времени', zh: '结束时间必须晚于当前时间' },
  'Thời gian kết thúc phải sau thời gian bắt đầu': { en: 'The end time must be after the start time', ru: 'Время окончания должно быть позже времени начала', zh: '结束时间必须晚于开始时间' },
  'Thời gian không hợp lệ': { en: 'Invalid time', ru: 'Недопустимое время', zh: '时间无效' },
  'Thời gian nhấn giữ (số giây)': { en: 'Hold duration (seconds)', ru: 'Время удержания (секунды)', zh: '按住时长（秒）' },
  'Thời gian tạo': { en: 'Creation time', ru: 'Время создания', zh: '创建时间' },
  'Thứ tự bắt đầu': { en: 'Start order', ru: 'Начальный порядок', zh: '起始顺序' },
  'Thứ tự phần tử': { en: 'Element order', ru: 'Порядок элемента', zh: '元素顺序' },
  'Thứ tự tab': { en: 'Tab order', ru: 'Порядок вкладок', zh: '标签页顺序' },
  'Thực thi lệnh CMD': { en: 'Execute a CMD command', ru: 'Выполнить команду CMD', zh: '执行 CMD 命令' },
  'Thường': { en: 'Normal', ru: 'Обычный', zh: '普通' },
  'Tỉ lệ thu phóng': { en: 'Zoom ratio', ru: 'Коэффициент масштабирования', zh: '缩放比例' },
  'Tiếng Anh - Mỹ': { en: 'English - US', ru: 'Английский - США', zh: '英语 - 美国' },
  'Tiếng ồn phần': { en: 'Hardware', ru: 'Аппаратный', zh: '硬件' },
  'Tiếng ồn phần cứng': { en: 'Hardware noise', ru: 'Аппаратный шум', zh: '硬件噪声' },
  'Tím': { en: 'Purple', ru: 'Фиолетовый', zh: '紫色' },
  'Tìm hiểu thêm': { en: 'Learn more', ru: 'Узнать больше', zh: '了解更多' },
  'Tìm kiếm lịch...': { en: 'Search schedules...', ru: 'Поиск расписаний...', zh: '搜索计划…' },
  'Tìm kiếm nâng cao': { en: 'Advanced search', ru: 'Расширенный поиск', zh: '高级搜索' },
  'Tìm kiếm quy trình...': { en: 'Search workflows...', ru: 'Поиск процессов...', zh: '搜索流程…' },
  'Tìm kiếm tiện ích...': { en: 'Search extensions...', ru: 'Поиск расширений...', zh: '搜索扩展…' },
  'Tìm kiếm từ khóa...': { en: 'Search keywords...', ru: 'Поиск по ключевым словам...', zh: '搜索关键词…' },
  'Tìm kiếm...': { en: 'Search...', ru: 'Поиск...', zh: '搜索…' },
  'Tìm nhóm/ Tạo nhóm': { en: 'Find group / Create group', ru: 'Найти группу / Создать группу', zh: '查找分组 / 创建分组' },
  'Tìm tab/ Tạo tab': { en: 'Find tab / Create tab', ru: 'Найти вкладку / Создать вкладку', zh: '查找标签 / 创建标签' },
  'Tìm tab/Tạo tab': { en: 'Find tab/Create tab', ru: 'Найти вкладку/Создать вкладку', zh: '查找标签/创建标签' },
  'Tính năng chia sẻ đang phát triển': { en: 'The sharing feature is under development', ru: 'Функция обмена в разработке', zh: '分享功能开发中' },
  'Tính năng di chuyển nhóm đang phát triển': { en: 'The group move feature is under development', ru: 'Функция перемещения групп в разработке', zh: '分组移动功能开发中' },
  'Tính năng đang được phát triển': { en: 'The feature is under development', ru: 'Функция в разработке', zh: '功能开发中' },
  'Tính năng lấy quy trình đang phát triển': { en: 'The get-workflow feature is under development', ru: 'Функция получения процесса в разработке', zh: '获取流程功能开发中' },
  'Tính năng này hiện chỉ có sẵn cho Chrome phiên bản 111 trở lên.': { en: 'This feature is currently available only for Chrome version 111 and above.', ru: 'Эта функция сейчас доступна только для Chrome версии 111 и выше.', zh: '此功能目前仅适用于 Chrome 111 及以上版本。' },
  'Tính năng tạo tác vụ đang phát triển': { en: 'The task creation feature is under development', ru: 'Функция создания задач в разработке', zh: '任务创建功能开发中' },
  'Tính năng thử nghiệm chưa được cài đặt': { en: 'The experimental feature is not installed', ru: 'Экспериментальная функция не установлена', zh: '实验功能尚未安装' },
  'Tính năng xuất quy trình đang phát triển': { en: 'The workflow export feature is under development', ru: 'Функция экспорта процесса в разработке', zh: '流程导出功能开发中' },
  'Tình trạng': { en: 'Status', ru: 'Состояние', zh: '状态' },
  'Tổng số hồ sơ chia nhóm': { en: 'Total profiles by group', ru: 'Всего профилей по группам', zh: '按分组统计的配置文件总数' },
  'Trả về giá trị mặc định nếu không tìm thấy thuộc tính': { en: 'Return the default value if the property is not found', ru: 'Вернуть значение по умолчанию, если свойство не найдено', zh: '若未找到属性则返回默认值' },
  'Trạng thái (đang mở trước)': { en: 'Status (open first)', ru: 'Состояние (сначала открытые)', zh: '状态（打开的优先）' },
  'Trì hoãn thực hiện': { en: 'Delay execution', ru: 'Отложить выполнение', zh: '延迟执行' },
  'Trình duyệt không có giao diện': { en: 'Headless browser', ru: 'Браузер без интерфейса', zh: '无界面浏览器' },
  'Trùng với WebGL': { en: 'Matches WebGL', ru: 'Совпадает с WebGL', zh: '与 WebGL 一致' },
  'Truy cập Chrome Web Store': { en: 'Visit the Chrome Web Store', ru: 'Открыть Chrome Web Store', zh: '访问 Chrome 网上应用店' },
  'Trừ tab đang hoạt động': { en: 'Except the active tab', ru: 'Кроме активной вкладки', zh: '活动标签页除外' },
  'Tùy chọn này không có trong fp-config (chỉ ở ứng dụng)': { en: 'This option is not in fp-config (app only)', ru: 'Этот параметр отсутствует в fp-config (только в приложении)', zh: '此选项不在 fp-config 中（仅应用内）' },
  'Tùy chọn sao chép': { en: 'Copy options', ru: 'Параметры копирования', zh: '复制选项' },
  'Tự động chấp nhận lời mời kết bạn': { en: 'Automatically accept friend requests', ru: 'Автоматически принимать заявки в друзья', zh: '自动接受好友请求' },
  'Tự động ghép kết nối khi thêm nút': { en: 'Automatically connect when adding a node', ru: 'Автоматически соединять при добавлении узла', zh: '添加节点时自动连线' },
  'Tự động gia hạn hồ sơ': { en: 'Automatically renew profiles', ru: 'Автоматически продлевать профили', zh: '自动续期配置文件' },
  'Tự Động Hóa': { en: 'Automation', ru: 'Автоматизация', zh: '自动化' },
  'Tự động kết nối': { en: 'Auto connect', ru: 'Автоподключение', zh: '自动连接' },
  'URL chứa Media': { en: 'URL containing media', ru: 'URL с медиа', zh: '包含媒体的 URL' },
  'URL của tiện ích': { en: 'Extension URL', ru: 'URL расширения', zh: '扩展的 URL' },
  'UTC+07:00 Bangkok / Hà Nội': { en: 'UTC+07:00 Bangkok / Hanoi', ru: 'UTC+07:00 Бангкок / Ханой', zh: 'UTC+07:00 曼谷 / 河内' },
  'Vàng': { en: 'Yellow', ru: 'Жёлтый', zh: '黄色' },
  'Văn bản': { en: 'Text', ru: 'Текст', zh: '文本' },
  'Văn bản lệnh': { en: 'Command text', ru: 'Текст команды', zh: '命令文本' },
  'Vĩ độ': { en: 'Latitude', ru: 'Широта', zh: '纬度' },
  'Vĩ độ / Kinh độ': { en: 'Latitude / Longitude', ru: 'Широта / Долгота', zh: '纬度 / 经度' },
  'Vị trí / Pixel': { en: 'Position / Pixel', ru: 'Позиция / Пиксель', zh: '位置 / 像素' },
  'Vị trí bắt đầu': { en: 'Start position', ru: 'Начальная позиция', zh: '起始位置' },
  'Vị trí đọc dòng': { en: 'Line read position', ru: 'Позиция чтения строки', zh: '行读取位置' },
  'Vị trí kết thúc': { en: 'End position', ru: 'Конечная позиция', zh: '结束位置' },
  'Vô hiệu hóa tự động điền mật khẩu': { en: 'Disable password auto-fill', ru: 'Отключить автозаполнение паролей', zh: '禁用密码自动填充' },
  'Vui lòng chọn gói cài đặt trước': { en: 'Please select a preset package', ru: 'Пожалуйста, выберите готовый набор', zh: '请选择预设套餐' },
  'Vui lòng chọn ít nhất một nhóm': { en: 'Please select at least one group', ru: 'Пожалуйста, выберите хотя бы одну группу', zh: '请至少选择一个分组' },
  'Vui lòng chọn quy trình ở tab "Cấu hình chạy".': { en: 'Please select a workflow on the "Run configuration" tab.', ru: 'Пожалуйста, выберите процесс на вкладке «Конфигурация запуска».', zh: '请在“运行配置”标签页中选择流程。' },
  'Vui lòng click vào đây để xem hướng dẫn tạo file json xác thực.': { en: 'Please click here to see the guide for creating the authentication JSON file.', ru: 'Нажмите здесь, чтобы посмотреть руководство по созданию JSON-файла аутентификации.', zh: '请点击此处查看创建认证 JSON 文件的指南。' },
  'Vui lòng nhập': { en: 'Please enter', ru: 'Пожалуйста, введите', zh: '请输入' },
  'Vui lòng nhập email và mật khẩu': { en: 'Please enter email and password', ru: 'Пожалуйста, введите email и пароль', zh: '请输入邮箱和密码' },
  'Vui lòng nhập tên luồng': { en: 'Please enter the flow name', ru: 'Пожалуйста, введите название потока', zh: '请输入流程名称' },
  'Vui lòng nhập tên quy trình': { en: 'Please enter the workflow name', ru: 'Пожалуйста, введите название процесса', zh: '请输入流程名称' },
  'Vui lòng nhập URL, phân tách bằng dòng': { en: 'Please enter URLs, one per line', ru: 'Пожалуйста, введите URL, по одному в строке', zh: '请输入 URL，每行一个' },
  'Vui lòng nhập văn bản trước.': { en: 'Please enter text first.', ru: 'Сначала введите текст.', zh: '请先输入文本。' },
  'Vừa màn hình': { en: 'Fit to screen', ru: 'По размеру экрана', zh: '适应屏幕' },
  'vừa xong': { en: 'just now', ru: 'только что', zh: '刚刚' },
  'Vừa xong': { en: 'Just now', ru: 'Только что', zh: '刚刚' },
  'Xác nhận xoá': { en: 'Confirm deletion', ru: 'Подтвердить удаление', zh: '确认删除' },
  'Xanh lá': { en: 'Green', ru: 'Зелёный', zh: '绿色' },
  'Xanh lục': { en: 'Green', ru: 'Зелёный', zh: '绿色' },
  'xóa': { en: 'delete', ru: 'удалить', zh: '删除' },
  'Xóa biến': { en: 'Delete variable', ru: 'Удалить переменную', zh: '删除变量' },
  'Xóa bỏ': { en: 'Remove', ru: 'Удалить', zh: '移除' },
  'Xóa bookmark': { en: 'Delete bookmark', ru: 'Удалить закладку', zh: '删除书签' },
  'Xóa bộ nhớ đệm': { en: 'Clear cache', ru: 'Очистить кэш', zh: '清除缓存' },
  'Xóa bộ nhớ đệm khi thoát trình duyệt': { en: 'Clear cache when the browser exits', ru: 'Очищать кэш при выходе из браузера', zh: '退出浏览器时清除缓存' },
  'Xóa cookie': { en: 'Delete cookies', ru: 'Удалить cookie', zh: '删除 Cookie' },
  'Xóa dòng sau khi đọc': { en: 'Delete the line after reading', ru: 'Удалить строку после чтения', zh: '读取后删除该行' },
  'Xóa điều kiện': { en: 'Delete condition', ru: 'Удалить условие', zh: '删除条件' },
  'Xóa giá trị ô': { en: 'Clear cell value', ru: 'Очистить значение ячейки', zh: '清除单元格值' },
  'Xóa lịch': { en: 'Delete schedule', ru: 'Удалить расписание', zh: '删除计划' },
  'xóa luôn': { en: 'delete permanently', ru: 'удалить навсегда', zh: '直接删除' },
  'Xóa nhóm': { en: 'Delete group', ru: 'Удалить группу', zh: '删除分组' },
  'Xóa nhóm văn bản': { en: 'Delete text group', ru: 'Удалить группу текста', zh: '删除文本组' },
  'Xóa nội dung tag': { en: 'Clear tag content', ru: 'Очистить содержимое тега', zh: '清除标签内容' },
  'Xoá quy trình': { en: 'Delete workflow', ru: 'Удалить процесс', zh: '删除流程' },
  'Xóa tab': { en: 'Delete tab', ru: 'Удалить вкладку', zh: '删除标签页' },
  'Xóa tag': { en: 'Delete tag', ru: 'Удалить тег', zh: '删除标签' },
  'Xóa thẻ': { en: 'Delete tag', ru: 'Удалить тег', zh: '删除标签' },
  'Xuất quy trình thất bại': { en: 'Failed to export workflow', ru: 'Не удалось экспортировать процесс', zh: '导出流程失败' },
  'Xử lý lỗi:': { en: 'Error handling:', ru: 'Обработка ошибок:', zh: '错误处理：' },
  'Xóa các lịch đã chọn': { en: 'Delete selected schedules', ru: 'Удалить выбранные расписания', zh: '删除所选计划' },
  'Tiếng Việt': { en: 'Tiếng Việt', ru: 'Tiếng Việt', zh: 'Tiếng Việt' },
  '" - tính năng đang được phát triển': { en: '" - feature under development', ru: '" - функция в разработке', zh: '" - 功能开发中' },
  '" khỏi tất cả hồ sơ?': { en: '" from all profiles?', ru: '" из всех профилей?', zh: '" 从所有配置文件中移除？' },
  '" trên': { en: '" on', ru: '" на', zh: '" 于' },
  '"? Các lịch của nhiệm vụ này cũng sẽ bị xóa.': { en: '"? The schedules of this task will also be deleted.', ru: '"? Расписания этой задачи также будут удалены.', zh: '"？此任务的计划也将被删除。' },
  '(bỏ qua': { en: '(skip', ru: '(пропустить', zh: '（跳过' },
  'Bạn có chắc chắn muốn ngừng dùng proxy cho': { en: 'Are you sure you want to stop using the proxy for', ru: 'Вы уверены, что хотите прекратить использование прокси для', zh: '确定要停止为以下项使用代理吗' },
  'Bạn có chắc chắn muốn xóa proxy của': { en: 'Are you sure you want to delete the proxy of', ru: 'Вы уверены, что хотите удалить прокси у', zh: '确定要删除以下项的代理吗' },
  'Bắt đầu "': { en: 'Start "', ru: 'Запустить "', zh: '开始 "' },
  'Chi tiết': { en: 'Details', ru: 'Подробности', zh: '详情' },
  'Chi tiết lần chạy ·': { en: 'Run details ·', ru: 'Детали запуска ·', zh: '运行详情 ·' },
  'Chọn thông tin cần sao chép (': { en: 'Choose the information to copy (', ru: 'Выберите информацию для копирования (', zh: '选择要复制的信息（' },
  'Chưa cấu hình mục bắt buộc': { en: 'Required fields not configured', ru: 'Обязательные поля не настроены', zh: '必填项未配置' },
  'cửa sổ': { en: 'windows', ru: 'окон', zh: '窗口' },
  'Danh sách nhật ký của': { en: 'Log list of', ru: 'Список журналов для', zh: '以下项的日志列表' },
  'Danh sách proxy (áp cho': { en: 'Proxy list (applies to', ru: 'Список прокси (применяется к', zh: '代理列表（应用于' },
  'Dừng': { en: 'Stop', ru: 'Стоп', zh: '停止' },
  'Dừng đồng bộ (': { en: 'Stop sync (', ru: 'Остановить синхронизацию (', zh: '停止同步（' },
  'Đã bật đồng bộ thao tác: master +': { en: 'Action sync enabled: master +', ru: 'Синхронизация действий включена: мастер +', zh: '已开启操作同步：主控 +' },
  'Đã bật đồng bộ: master +': { en: 'Sync enabled: master +', ru: 'Синхронизация включена: мастер +', zh: '已开启同步：主控 +' },
  'Đã cập nhật ghi chú cho': { en: 'Updated the note for', ru: 'Обновлена заметка для', zh: '已更新以下项的备注' },
  'Đã cập nhật proxy cho': { en: 'Updated the proxy for', ru: 'Обновлён прокси для', zh: '已更新以下项的代理' },
  'Đã cập nhật thẻ cho': { en: 'Updated the tag for', ru: 'Обновлён тег для', zh: '已更新以下项的标签' },
  'Đã chọn': { en: 'Selected', ru: 'Выбрано', zh: '已选' },
  'Đã dán vào': { en: 'Pasted into', ru: 'Вставлено в', zh: '已粘贴到' },
  'Đã dừng nhiệm vụ "': { en: 'Stopped task "', ru: 'Задача остановлена "', zh: '已停止任务 "' },
  'Đã đồng nhất kích cỡ': { en: 'Sizes unified', ru: 'Размеры выровнены', zh: '尺寸已统一' },
  'Đã gán proxy cho': { en: 'Assigned proxy to', ru: 'Прокси назначен для', zh: '已为以下项分配代理' },
  'Đã gõ vào': { en: 'Typed into', ru: 'Введено в', zh: '已输入到' },
  'Đã hiện': { en: 'Shown', ru: 'Показано', zh: '已显示' },
  'Đã lên lịch "': { en: 'Scheduled "', ru: 'Запланировано "', zh: '已计划 "' },
  'Đã lên lịch nhiệm vụ "': { en: 'Scheduled task "', ru: 'Запланирована задача "', zh: '已计划任务 "' },
  'Đã nhập': { en: 'Imported', ru: 'Импортировано', zh: '已导入' },
  'Đã sao chép': { en: 'Copied', ru: 'Скопировано', zh: '已复制' },
  'Đã sắp xếp': { en: 'Arranged', ru: 'Упорядочено', zh: '已排列' },
  'Đã tạo nhiệm vụ "': { en: 'Created task "', ru: 'Создана задача "', zh: '已创建任务 "' },
  'Đã tạo vân tay mới cho': { en: 'Created a new fingerprint for', ru: 'Создан новый отпечаток для', zh: '已为以下项创建新指纹' },
  'Đã thêm': { en: 'Added', ru: 'Добавлено', zh: '已添加' },
  'Đã thêm Proxy:': { en: 'Proxies added:', ru: 'Добавлено прокси:', zh: '已添加代理：' },
  'Đã xóa': { en: 'Deleted', ru: 'Удалено', zh: '已删除' },
  'Đã xóa ghi chú của': { en: 'Deleted the note of', ru: 'Удалена заметка у', zh: '已删除以下项的备注' },
  // Hai khoá dưới là VẾ ĐẦU của câu "… N/M hồ sơ" trong menu "Thêm" → "Xóa bộ nhớ đệm"
  // (bản hàng loạt). Bản 1 hồ sơ dùng 'Đã xóa bộ nhớ đệm' / 'Xóa toàn bộ bộ nhớ đệm của
  // hồ sơ “{0}”?' đã có sẵn ở chỗ khác trong tệp này.
  'Đã xóa bộ nhớ đệm của': { en: 'Cache cleared for', ru: 'Кэш очищен у', zh: '已清除以下项的缓存' },
  'Xóa toàn bộ bộ nhớ đệm của': { en: 'Clear all cache of', ru: 'Очистить весь кэш у', zh: '清除以下项的所有缓存' },
  'Đang xóa bộ nhớ đệm…': { en: 'Clearing the cache…', ru: 'Очистка кэша…', zh: '正在清除缓存…' },
  'Đã xóa thẻ của': { en: 'Deleted the tag of', ru: 'Удалён тег у', zh: '已删除以下项的标签' },
  'Đã xóa văn bản ở': { en: 'Cleared text in', ru: 'Текст удалён в', zh: '已清除以下项的文本' },
  'đang phát triển': { en: 'under development', ru: 'в разработке', zh: '开发中' },
  'Đóng các tab khác': { en: 'Close other tabs', ru: 'Закрыть другие вкладки', zh: '关闭其他标签页' },
  'Đóng tab hiện tại': { en: 'Close current tab', ru: 'Закрыть текущую вкладку', zh: '关闭当前标签页' },
  'Đóng tab trống': { en: 'Close empty tabs', ru: 'Закрыть пустые вкладки', zh: '关闭空白标签页' },
  'Đồng bộ Tab': { en: 'Sync Tab', ru: 'Синхронизация вкладок', zh: '同步标签页' },
  'Đồng bộ thao tác(': { en: 'Action sync(', ru: 'Синхронизация действий(', zh: '操作同步（' },
  'ghi chú (': { en: 'note (', ru: 'заметка (', zh: '备注（' },
  'Ghi chú (áp cho': { en: 'Note (applies to', ru: 'Заметка (применяется к', zh: '备注（应用于' },
  'giây': { en: 'seconds', ru: 'секунд', zh: '秒' },
  'giờ trước': { en: 'hours ago', ru: 'часов назад', zh: '小时前' },
  'Hãy nhập': { en: 'Please enter', ru: 'Пожалуйста, введите', zh: '请输入' },
  'Hoàn tất nhiệm vụ "': { en: 'Completed task "', ru: 'Задача завершена "', zh: '已完成任务 "' },
  'hồ sơ': { en: 'profiles', ru: 'профилей', zh: '个配置文件' },
  'hồ sơ (': { en: 'profiles (', ru: 'профилей (', zh: '个配置文件（' },
  'hồ sơ đã chọn?': { en: 'selected profiles?', ru: 'выбранных профилей?', zh: '个已选配置文件？' },
  'hồ sơ đã chọn? Vân tay hiện tại sẽ được thay thế.': { en: 'selected profiles? The current fingerprint will be replaced.', ru: 'выбранных профилей? Текущий отпечаток будет заменён.', zh: '个已选配置文件？当前指纹将被替换。' },
  'hồ sơ đã chọn)': { en: 'selected profiles)', ru: 'выбранных профилей)', zh: '个已选配置文件）' },
  'hồ sơ không có proxy)': { en: 'profiles without a proxy)', ru: 'профилей без прокси)', zh: '个无代理的配置文件）' },
  'hồ sơ vào thùng rác?': { en: 'profiles to the trash?', ru: 'профилей в корзину?', zh: '个配置文件移到回收站？' },
  'hồ sơ? Không thể khôi phục.': { en: 'profiles? This cannot be undone.', ru: 'профилей? Это нельзя отменить.', zh: '个配置文件？此操作无法撤销。' },
  'hồ sơ)': { en: 'profiles)', ru: 'профилей)', zh: '个配置文件）' },
  'lịch đã chọn?': { en: 'selected schedules?', ru: 'выбранных расписаний?', zh: '个已选计划？' },
  'luồng)': { en: 'threads)', ru: 'потоков)', zh: '个线程）' },
  'Năm Tháng': { en: 'Year Month', ru: 'Год Месяц', zh: '年月' },
  'năm trước': { en: 'years ago', ru: 'лет назад', zh: '年前' },
  'ngày trước': { en: 'days ago', ru: 'дней назад', zh: '天前' },
  'Nhân': { en: 'Multiply', ru: 'Умножить', zh: '乘' },
  'nhiệm vụ đã chọn? Các lịch liên quan cũng sẽ bị xóa.': { en: 'selected tasks? Related schedules will also be deleted.', ru: 'выбранных задач? Связанные расписания также будут удалены.', zh: '个已选任务？相关计划也将被删除。' },
  'nhóm': { en: 'groups', ru: 'групп', zh: '个分组' },
  'Nhóm văn bản': { en: 'Text group', ru: 'Группа текста', zh: '文本组' },
  'phút trước': { en: 'minutes ago', ru: 'минут назад', zh: '分钟前' },
  'proxy lỗi - không thêm được proxy nào': { en: 'proxy errors - no proxy could be added', ru: 'ошибок прокси - не удалось добавить ни одного прокси', zh: '个代理错误 - 没有可添加的代理' },
  'proxy lỗi.': { en: 'proxy errors.', ru: 'ошибок прокси.', zh: '个代理错误。' },
  'proxy vào danh sách': { en: 'proxies to the list', ru: 'прокси в список', zh: '个代理到列表' },
  'quy trình': { en: 'workflows', ru: 'процессов', zh: '个流程' },
  'Tạo "': { en: 'Create "', ru: 'Создать "', zh: '创建 "' },
  'Tạo dấu vân tay mới cho': { en: 'Create a new fingerprint for', ru: 'Создать новый отпечаток для', zh: '为以下项创建新指纹' },
  'Tạo một quy trình': { en: 'Create a workflow', ru: 'Создать процесс', zh: '创建一个流程' },
  'tên (': { en: 'name (', ru: 'имя (', zh: '名称（' },
  'tháng': { en: 'months', ru: 'месяцев', zh: '个月' },
  'Tháng': { en: 'Month', ru: 'Месяц', zh: '月' },
  'tháng trước': { en: 'months ago', ru: 'месяцев назад', zh: '个月前' },
  'thành công': { en: 'succeeded', ru: 'успешно', zh: '成功' },
  'Thêm điều kiện': { en: 'Add condition', ru: 'Добавить условие', zh: '添加条件' },
  'Thêm thẻ mới': { en: 'Add new tag', ru: 'Добавить новый тег', zh: '添加新标签' },
  'Tính năng': { en: 'Feature', ru: 'Функция', zh: '功能' },
  'Toàn bộ:': { en: 'All:', ru: 'Всего:', zh: '全部：' },
  'Tổng thời gian chạy:': { en: 'Total run time:', ru: 'Общее время выполнения:', zh: '总运行时间：' },
  'trên': { en: 'of', ru: 'из', zh: '/' },
  'Toàn bộ': { en: 'Total', ru: 'Всего', zh: '全部' },
  'trang': { en: 'page', ru: 'стр.', zh: '页' },
  'hoặc': { en: 'or', ru: 'или', zh: '或' },
  'mỗi dòng 1 proxy': { en: '1 proxy per line', ru: '1 прокси в строке', zh: '每行 1 个代理' },
  'Ví dụ': { en: 'Example', ru: 'Пример', zh: '示例' },
  'cho': { en: 'to', ru: 'для', zh: '给' },
  'proxy lỗi': { en: 'invalid proxies', ru: 'ошибочных прокси', zh: '个无效代理' },
  'Đã thêm Proxy': { en: 'Added Proxies', ru: 'Добавлено прокси', zh: '已添加代理' },
  'Proxy xoay': { en: 'Rotating proxy', ru: 'Ротационный прокси', zh: '轮换代理' },
  'proxy lỗi - không thêm được proxy nào': { en: 'invalid proxies - no proxy was added', ru: 'ошибочных прокси - ни один прокси не добавлен', zh: '个无效代理 - 未添加任何代理' },
  'hồ sơ đã chọn': { en: 'selected profiles', ru: 'выбранных профилей', zh: '个所选配置文件' },
  'hồ sơ vào thùng rác?': { en: 'profiles to the trash?', ru: 'профилей в корзину?', zh: '个配置文件移到回收站吗？' },
  'Chọn thông tin cần sao chép': { en: 'Select the info to copy', ru: 'Выберите данные для копирования', zh: '选择要复制的信息' },
  'tên': { en: 'name', ru: 'имя', zh: '名称' },
  'ghi chú': { en: 'note', ru: 'заметка', zh: '备注' },
  'bỏ qua': { en: 'skipped', ru: 'пропущено', zh: '已跳过' },
  'hồ sơ không có proxy': { en: 'profiles without a proxy', ru: 'профилей без прокси', zh: '个无代理的配置文件' },
  'Vân tay hiện tại sẽ được thay thế.': { en: 'The current fingerprint will be replaced.', ru: 'Текущий отпечаток будет заменён.', zh: '当前指纹将被替换。' },
  'Tổng thời gian chạy': { en: 'Total run time', ru: 'Общее время выполнения', zh: '总运行时长' },
  'vào danh sách': { en: 'into the list', ru: 'в список', zh: '到列表' },
  'Xóa lịch "': { en: 'Delete schedule "', ru: 'Удалить расписание "', zh: '删除计划 "' },
  'Xóa nhiệm vụ "': { en: 'Delete task "', ru: 'Удалить задачу "', zh: '删除任务 "' },
  'Xóa thẻ "': { en: 'Delete tag "', ru: 'Удалить тег "', zh: '删除标签 "' },
  'Xóa toàn bộ ghi chú của': { en: 'Delete all notes of', ru: 'Удалить все заметки у', zh: '删除以下项的全部备注' },
  'Xóa toàn bộ nhật ký chạy của nhiệm vụ "': { en: 'Delete all run logs of task "', ru: 'Удалить все журналы запусков задачи "', zh: '删除任务的全部运行日志 "' },
  'Xóa toàn bộ thẻ của': { en: 'Delete all tags of', ru: 'Удалить все теги у', zh: '删除以下项的全部标签' },

  // ══ Bổ sung: các chuỗi UI còn thiếu (rà soát coverage 2026-07-11) ══════════
  // ── App shell / workspace / thông báo (app.js) ────────────────────────────
  'Thành viên nhóm': { en: 'Team members', ru: 'Участники команды', zh: '团队成员' },
  'Hồ sơ đã tạo': { en: 'Profiles created', ru: 'Создано профилей', zh: '已创建配置文件' },
  'Không thể chuyển workspace': { en: 'Failed to switch workspace', ru: 'Не удалось сменить рабочее пространство', zh: '无法切换工作区' },
  'Không gian làm việc': { en: 'Workspace', ru: 'Рабочее пространство', zh: '工作区' },
  'Tìm workspace...': { en: 'Search workspaces...', ru: 'Поиск рабочих пространств...', zh: '搜索工作区…' },
  'Không tìm thấy workspace': { en: 'No workspaces found', ru: 'Рабочие пространства не найдены', zh: '未找到工作区' },
  'Chia theo nhóm': { en: 'By group', ru: 'По группам', zh: '按分组' },
  'Chia theo hồ sơ': { en: 'By profile', ru: 'По профилям', zh: '按配置文件' },
  'Vui lòng nhập tên không gian làm việc': { en: 'Please enter a workspace name', ru: 'Пожалуйста, введите название рабочего пространства', zh: '请输入工作区名称' },
  'Đã tạo không gian làm việc': { en: 'Workspace created', ru: 'Рабочее пространство создано', zh: '已创建工作区' },
  'Tạo thất bại': { en: 'Creation failed', ru: 'Не удалось создать', zh: '创建失败' },
  'Tạo không gian làm việc': { en: 'Create workspace', ru: 'Создать рабочее пространство', zh: '创建工作区' },
  'Nhập tên không gian làm việc': { en: 'Enter workspace name', ru: 'Введите название рабочего пространства', zh: '输入工作区名称' },
  'Nhập mô tả': { en: 'Enter a description', ru: 'Введите описание', zh: '输入描述' },
  'Ai đó': { en: 'Someone', ru: 'Кто-то', zh: '某人' },
  'Lời mời tham gia nhóm': { en: 'Group invitation', ru: 'Приглашение в группу', zh: '加入分组的邀请' },
  'Lời mời truy cập hồ sơ': { en: 'Profile access invitation', ru: 'Приглашение к доступу к профилю', zh: '访问配置文件的邀请' },
  'Toàn quyền': { en: 'Full access', ru: 'Полный доступ', zh: '完全权限' },
  'Chấp nhận': { en: 'Accept', ru: 'Принять', zh: '接受' },
  'Từ chối': { en: 'Decline', ru: 'Отклонить', zh: '拒绝' },
  'Không thể chấp nhận lời chia sẻ': { en: 'Failed to accept the share', ru: 'Не удалось принять приглашение к доступу', zh: '无法接受分享邀请' },
  'Đã từ chối lời chia sẻ': { en: 'Share declined', ru: 'Приглашение к доступу отклонено', zh: '已拒绝分享邀请' },
  'Không thể từ chối lời chia sẻ': { en: 'Failed to decline the share', ru: 'Не удалось отклонить приглашение к доступу', zh: '无法拒绝分享邀请' },
  'Đồng ý tất cả': { en: 'Accept all', ru: 'Принять все', zh: '全部接受' },
  'Từ chối tất cả': { en: 'Decline all', ru: 'Отклонить все', zh: '全部拒绝' },
  'Chưa có thông báo nào.': { en: 'No notifications yet.', ru: 'Уведомлений пока нет.', zh: '暂无通知。' },
  'Quản trị viên': { en: 'Administrator', ru: 'Администратор', zh: '管理员' },
  'Quản lý': { en: 'Manager', ru: 'Менеджер', zh: '管理者' },
  'Không thể chấp nhận lời mời': { en: 'Failed to accept the invitation', ru: 'Не удалось принять приглашение', zh: '无法接受邀请' },
  'Đã từ chối lời mời': { en: 'Invitation declined', ru: 'Приглашение отклонено', zh: '已拒绝邀请' },
  'Không thể từ chối lời mời': { en: 'Failed to decline the invitation', ru: 'Не удалось отклонить приглашение', zh: '无法拒绝邀请' },
  'Không giới hạn': { en: 'Unlimited', ru: 'Без ограничений', zh: '无限制' },
  'Tổng hồ sơ': { en: 'Total profiles', ru: 'Всего профилей', zh: '配置文件总数' },

  // ── Thông báo lỗi chung (errors.js) ───────────────────────────────────────
  'Thao tác thất bại': { en: 'Operation failed', ru: 'Не удалось выполнить операцию', zh: '操作失败' },
  'Bạn đã sử dụng hết số dư tạo hồ sơ. Vui lòng nâng cấp gói để tiếp tục.': { en: 'You have used up your profile creation balance. Please upgrade your plan to continue.', ru: 'Вы израсходовали баланс на создание профилей. Пожалуйста, обновите тариф, чтобы продолжить.', zh: '您的配置文件创建额度已用完。请升级套餐以继续。' },
  'Không kết nối được máy chủ. Kiểm tra kết nối rồi thử lại.': { en: 'Cannot connect to the server. Check your connection and try again.', ru: 'Не удалось подключиться к серверу. Проверьте соединение и попробуйте снова.', zh: '无法连接到服务器。请检查网络连接后重试。' },
  'Không thể thực hiện': { en: 'Cannot perform this action', ru: 'Не удалось выполнить действие', zh: '无法执行此操作' },
  'do bạn không có đủ quyền hạn': { en: 'because you lack sufficient permissions', ru: 'так как у вас недостаточно прав', zh: '因为您的权限不足' },

  // ── Quyền & vai trò thành viên (members-store.js, members.js) ─────────────
  'Quản lý hồ sơ': { en: 'Manage profiles', ru: 'Управление профилями', zh: '管理配置文件' },
  'Chỉnh sửa ghi chú': { en: 'Edit notes', ru: 'Редактировать заметки', zh: '编辑备注' },
  'Hiển thị ghi chú': { en: 'View notes', ru: 'Просмотр заметок', zh: '查看备注' },
  'Chỉnh sửa dấu vân tay': { en: 'Edit fingerprint', ru: 'Редактировать отпечаток', zh: '编辑指纹' },
  'Chỉnh sửa proxy': { en: 'Edit proxy', ru: 'Редактировать прокси', zh: '编辑代理' },
  'Bật gia hạn tự động': { en: 'Enable auto-renewal', ru: 'Включить автопродление', zh: '开启自动续期' },
  'Tắt gia hạn tự động': { en: 'Disable auto-renewal', ru: 'Отключить автопродление', zh: '关闭自动续期' },
  'Nhập tài nguyên': { en: 'Import resources', ru: 'Импорт ресурсов', zh: '导入资源' },
  'Quản lý nhóm hồ sơ': { en: 'Manage profile groups', ru: 'Управление группами профилей', zh: '管理配置文件分组' },
  'Quản lý quy trình tự động': { en: 'Manage automation workflows', ru: 'Управление процессами автоматизации', zh: '管理自动化流程' },
  'Đăng chợ': { en: 'Publish to store', ru: 'Опубликовать в магазине', zh: '发布到商店' },
  'Tải về': { en: 'Download', ru: 'Скачать', zh: '下载' },
  'Xem mã nguồn / luồng quy trình': { en: 'View source / workflow', ru: 'Просмотр исходного кода / процесса', zh: '查看源码 / 流程' },
  'Quản trị': { en: 'Admin', ru: 'Администрирование', zh: '管理' },
  'Có đầy đủ các quyền quản lý thành viên, nhóm thành viên trong workspace.': { en: 'Has full permissions to manage members and member groups in the workspace.', ru: 'Имеет полные права на управление участниками и группами участников в рабочем пространстве.', zh: '拥有管理工作区内成员和成员组的全部权限。' },
  'Có thể thêm thành viên và chỉnh sửa quyền truy cập của nhóm thành viên đang tham gia.': { en: 'Can add members and edit the access of the member groups they belong to.', ru: 'Может добавлять участников и изменять доступ групп участников, в которых состоит.', zh: '可以添加成员并编辑其所属成员组的访问权限。' },
  'Không thể thêm thành viên và chỉnh sửa quyền truy cập của nhóm thành viên.': { en: 'Cannot add members or edit member group access.', ru: 'Не может добавлять участников или изменять доступ групп участников.', zh: '无法添加成员或编辑成员组的访问权限。' },

  // ── Node catalog (node-catalog.js) ────────────────────────────────────────
  'Sử dụng ${ITEM} để lấy ra giá trị của item để so sánh. Nếu ITEM là đối tượng bạn có thể truy cập thuộc tính bằng cách sử dụng: ${ITEM.ten_thuoc_tinh}': { en: 'Use ${ITEM} to get the item value for comparison. If ITEM is an object, you can access its properties using: ${ITEM.property_name}', ru: 'Используйте ${ITEM}, чтобы получить значение элемента для сравнения. Если ITEM - объект, доступ к его свойствам осуществляется так: ${ITEM.property_name}', zh: '使用 ${ITEM} 获取该项的值以进行比较。如果 ITEM 是对象，可通过以下方式访问其属性：${ITEM.property_name}' },

  // ── Tự động hóa / quy trình (automation.js) ───────────────────────────────
  'Tạo quy trình thất bại': { en: 'Failed to create workflow', ru: 'Не удалось создать процесс', zh: '创建流程失败' },
  'Tạo bản sao thất bại': { en: 'Failed to create a copy', ru: 'Не удалось создать копию', zh: '创建副本失败' },
  'Cập nhật ghim thất bại': { en: 'Failed to update pin', ru: 'Не удалось обновить закрепление', zh: '更新置顶失败' },
  'Xoá quy trình thất bại': { en: 'Failed to delete workflow', ru: 'Не удалось удалить процесс', zh: '删除流程失败' },
  'Đã xoá quy trình': { en: 'Workflow deleted', ru: 'Процесс удалён', zh: '已删除流程' },
  'Xem sơ đồ': { en: 'View diagram', ru: 'Посмотреть схему', zh: '查看流程图' },
  'Lưu thông tin luồng thất bại': { en: 'Failed to save workflow', ru: 'Не удалось сохранить процесс', zh: '保存流程失败' },

  // ── Tiện ích (extensions.js) ──────────────────────────────────────────────
  'Xóa ứng dụng thất bại': { en: 'Failed to remove the app', ru: 'Не удалось удалить приложение', zh: '删除应用失败' },
  'Nhập tiện ích thất bại': { en: 'Failed to import extension', ru: 'Не удалось импортировать расширение', zh: '导入扩展失败' },

  // ── Nhóm (groups.js) ──────────────────────────────────────────────────────
  'Bỏ tất cả hồ sơ ra khỏi nhóm': { en: 'Remove all profiles from the group', ru: 'Убрать все профили из группы', zh: '从分组中移出所有配置文件' },
  'Nhóm chưa có hồ sơ nào để bỏ ra.': { en: 'The group has no profiles to remove.', ru: 'В группе нет профилей для удаления.', zh: '该分组暂无可移出的配置文件。' },
  'Reset nhóm': { en: 'Reset group', ru: 'Сбросить группу', zh: '重置分组' },
  'Bỏ khỏi nhóm': { en: 'Remove from group', ru: 'Убрать из группы', zh: '移出分组' },
  'Reset nhóm thất bại': { en: 'Failed to reset group', ru: 'Не удалось сбросить группу', zh: '重置分组失败' },

  // ── Đăng nhập / OTP (login.js) ────────────────────────────────────────────
  'Bạn chưa lấy mã hoặc mã đã hết hạn, hãy bấm "Nhận mã xác minh"': { en: 'You have not requested a code, or it has expired - click "Get code".', ru: 'Вы ещё не запросили код или он истёк - нажмите «Получить код».', zh: '您尚未获取验证码或验证码已过期，请点击"获取验证码"。' },

  // ── Thành viên (members.js) ───────────────────────────────────────────────
  'Nhóm hồ sơ chia sẻ': { en: 'Shared profile group', ru: 'Группа общих профилей', zh: '共享配置文件分组' },
  'Không tải được dữ liệu (cần đăng nhập máy chủ)': { en: 'Failed to load data (server sign-in required)', ru: 'Не удалось загрузить данные (требуется вход на сервер)', zh: '无法加载数据（需登录服务器）' },
  'Chưa có nhóm thành viên nào': { en: 'No member groups yet', ru: 'Групп участников пока нет', zh: '暂无成员组' },
  'Đã làm mới': { en: 'Refreshed', ru: 'Обновлено', zh: '已刷新' },
  'Làm mới thất bại': { en: 'Refresh failed', ru: 'Не удалось обновить', zh: '刷新失败' },
  'Đã mời': { en: 'Invited', ru: 'Приглашён', zh: '已邀请' },
  'Quyền truy cập': { en: 'Access', ru: 'Доступ', zh: '访问权限' },
  'Ngày mời': { en: 'Invitation date', ru: 'Дата приглашения', zh: '邀请日期' },
  'Quyền hạn': { en: 'Permissions', ru: 'Права', zh: '权限' },
  'Bạn không đủ quyền thực hiện': { en: 'You do not have permission to do this', ru: 'У вас недостаточно прав для этого действия', zh: '您没有执行此操作的权限' },
  'Thu hồi': { en: 'Revoke', ru: 'Отозвать', zh: '撤销' },
  'Trước': { en: 'Previous', ru: 'Назад', zh: '上一页' },
  'Chọn một nhóm thành viên để xem quyền truy cập': { en: 'Select a member group to view its access', ru: 'Выберите группу участников, чтобы просмотреть её доступ', zh: '选择一个成员组以查看其访问权限' },
  'Đã lưu quyền truy cập': { en: 'Access saved', ru: 'Доступ сохранён', zh: '已保存访问权限' },
  'Lưu quyền truy cập thất bại': { en: 'Failed to save access', ru: 'Не удалось сохранить доступ', zh: '保存访问权限失败' },
  'Đã lưu nhóm thành viên': { en: 'Member group saved', ru: 'Группа участников сохранена', zh: '已保存成员组' },
  'Thêm thành công!': { en: 'Added successfully!', ru: 'Успешно добавлено!', zh: '添加成功！' },
  'Lưu nhóm thành viên thất bại': { en: 'Failed to save member group', ru: 'Не удалось сохранить группу участников', zh: '保存成员组失败' },
  'Tạo nhóm thành viên thất bại': { en: 'Failed to create member group', ru: 'Не удалось создать группу участников', zh: '创建成员组失败' },
  'Chỉnh sửa nhóm thành viên': { en: 'Edit member group', ru: 'Редактировать группу участников', zh: '编辑成员组' },
  'Tạo nhóm thành viên': { en: 'Create member group', ru: 'Создать группу участников', zh: '创建成员组' },
  'Nhập tên nhóm': { en: 'Enter group name', ru: 'Введите название группы', zh: '输入分组名称' },
  'Giới thiệu nhóm': { en: 'Group description', ru: 'Описание группы', zh: '分组介绍' },
  'Cấp phép': { en: 'Permissions', ru: 'Разрешения', zh: '授权' },
  'Vui lòng cấp quyền cho các chức năng cho nhóm thành viên. Thành viên cùng một nhóm có quyền truy cập vào các chức năng giống nhau.': { en: 'Please grant feature permissions to the member group. Members in the same group share the same feature access.', ru: 'Пожалуйста, предоставьте группе участников права на функции. Участники одной группы имеют одинаковый доступ к функциям.', zh: '请为该成员组授予功能权限。同一组的成员拥有相同的功能访问权限。' },
  'Xóa nhóm thành viên': { en: 'Delete member group', ru: 'Удалить группу участников', zh: '删除成员组' },
  'Đã xóa nhóm thành viên': { en: 'Member group deleted', ru: 'Группа участников удалена', zh: '已删除成员组' },
  'Xóa nhóm thành viên thất bại': { en: 'Failed to delete member group', ru: 'Не удалось удалить группу участников', zh: '删除成员组失败' },
  'Xóa thành viên': { en: 'Remove member', ru: 'Удалить участника', zh: '移除成员' },
  'Đã xóa thành viên': { en: 'Member removed', ru: 'Участник удалён', zh: '已移除成员' },
  'Xóa thành viên thất bại': { en: 'Failed to remove member', ru: 'Не удалось удалить участника', zh: '移除成员失败' },
  'Đã thu hồi lời mời': { en: 'Invitation revoked', ru: 'Приглашение отозвано', zh: '已撤销邀请' },
  'Thu hồi lời mời thất bại': { en: 'Failed to revoke invitation', ru: 'Не удалось отозвать приглашение', zh: '撤销邀请失败' },
  'Email này đã được mời và đang chờ chấp nhận': { en: 'This email has already been invited and is awaiting acceptance', ru: 'Этот email уже приглашён и ожидает подтверждения', zh: '该邮箱已被邀请，正在等待接受' },
  'Email này đã là thành viên trong nhóm': { en: 'This email is already a member of the group', ru: 'Этот email уже является участником группы', zh: '该邮箱已是该分组的成员' },
  'Mời thành viên thất bại': { en: 'Failed to invite member', ru: 'Не удалось пригласить участника', zh: '邀请成员失败' },
  'Mời thành viên': { en: 'Invite member', ru: 'Пригласить участника', zh: '邀请成员' },
  'Nhập tên thành viên': { en: 'Enter member name', ru: 'Введите имя участника', zh: '输入成员名称' },
  'Nhập email thành viên': { en: 'Enter member email', ru: 'Введите email участника', zh: '输入成员邮箱' },
  'Vai trò': { en: 'Role', ru: 'Роль', zh: '角色' },
  'Hồ sơ chia sẻ': { en: 'Shared profiles', ru: 'Общие профили', zh: '共享配置文件' },
  'Giới hạn số dư hồ sơ': { en: 'Profile balance limit', ru: 'Лимит баланса профилей', zh: '配置文件余额上限' },
  'Nếu để trống sẽ không giới hạn số dư hồ sơ mà thành viên sử dụng': { en: 'If left blank, there is no limit on the profile balance the member can use', ru: 'Если оставить пустым, лимита на используемый участником баланс профилей не будет', zh: '若留空，则不限制该成员可使用的配置文件余额' },
  'Không bắt buộc': { en: 'Optional', ru: 'Необязательно', zh: '可选' },
  'Mời': { en: 'Invite', ru: 'Пригласить', zh: '邀请' },
  'Chọn nhóm thành viên': { en: 'Select a member group', ru: 'Выберите группу участников', zh: '选择成员组' },
  'Đã cập nhật thành viên': { en: 'Member updated', ru: 'Участник обновлён', zh: '已更新成员' },
  'Cập nhật thành viên thất bại': { en: 'Failed to update member', ru: 'Не удалось обновить участника', zh: '更新成员失败' },
  'Chỉnh sửa thành viên': { en: 'Edit member', ru: 'Редактировать участника', zh: '编辑成员' },
  'Nhóm thành viên': { en: 'Member group', ru: 'Группа участников', zh: '成员组' },
  'Đã gửi lời mời': { en: 'Invitation sent', ru: 'Приглашение отправлено', zh: '已发送邀请' },
  'Đã gửi lời mời tới': { en: 'Invitation sent to', ru: 'Приглашение отправлено на', zh: '已发送邀请至' },
  '. Thành viên sẽ thấy lời mời trong mục Thông báo khi đăng nhập bằng đúng email này.': { en: '. The member will see the invitation under Notifications when they sign in with this exact email.', ru: '. Участник увидит приглашение в разделе «Уведомления» при входе с этого же адреса.', zh: '。该成员使用此邮箱登录后，将在"通知"中看到该邀请。' },
  'Tìm hồ sơ...': { en: 'Search profiles...', ru: 'Поиск профилей...', zh: '搜索配置文件…' },
  '+ hồ sơ': { en: '+ profiles', ru: '+ профили', zh: '+ 配置文件' },
  'Không tìm thấy hồ sơ': { en: 'No profiles found', ru: 'Профили не найдены', zh: '未找到配置文件' },
  'Hãy tạo một “không gian làm việc riêng” để sử dụng tính năng Thành viên nhóm.': { en: 'Create a “private workspace” to use the Team members feature.', ru: 'Создайте «личное рабочее пространство», чтобы использовать функцию «Участники команды».', zh: '请创建一个"专属工作区"以使用团队成员功能。' },
  'Hãy chọn một “không gian làm việc” cụ thể để sử dụng tính năng Thành viên nhóm.': { en: 'Select a specific “workspace” to use the Team members feature.', ru: 'Выберите конкретное «рабочее пространство», чтобы использовать функцию «Участники команды».', zh: '请选择一个具体的"工作区"以使用团队成员功能。' },

  // ── Hồ sơ (profiles.js) ───────────────────────────────────────────────────
  'Bạn chỉ có quyền xem & chạy - không thể chỉnh sửa. Liên hệ quản trị để nâng quyền.': { en: 'You only have view & run access - you cannot edit. Contact an admin to upgrade your permissions.', ru: 'У вас только доступ на просмотр и запуск - редактирование недоступно. Обратитесь к администратору для расширения прав.', zh: '您仅有查看和运行权限，无法编辑。请联系管理员提升权限。' },
  'Bạn không có quyền xóa hồ sơ. Liên hệ quản trị để nâng quyền.': { en: 'You do not have permission to delete profiles. Contact an admin to upgrade your permissions.', ru: 'У вас нет прав на удаление профилей. Обратитесь к администратору для расширения прав.', zh: '您没有删除配置文件的权限。请联系管理员提升权限。' },
  'Bạn không có quyền tạo hồ sơ. Liên hệ quản trị để nâng quyền.': { en: 'You do not have permission to create profiles. Contact an admin to upgrade your permissions.', ru: 'У вас нет прав на создание профилей. Обратитесь к администратору для расширения прав.', zh: '您没有创建配置文件的权限。请联系管理员提升权限。' },
  'Bạn không có quyền chuyển nhóm. Liên hệ quản trị để nâng quyền.': { en: 'You do not have permission to move groups. Contact an admin to upgrade your permissions.', ru: 'У вас нет прав на смену группы. Обратитесь к администратору для расширения прав.', zh: '您没有移动分组的权限。请联系管理员提升权限。' },
  'Bạn không có quyền nhân bản hồ sơ. Liên hệ quản trị để nâng quyền.': { en: 'You do not have permission to duplicate profiles. Contact an admin to upgrade your permissions.', ru: 'У вас нет прав на дублирование профилей. Обратитесь к администратору для расширения прав.', zh: '您没有克隆配置文件的权限。请联系管理员提升权限。' },
  'Bạn không có quyền chia sẻ hồ sơ. Liên hệ quản trị để nâng quyền.': { en: 'You do not have permission to share profiles. Contact an admin to upgrade your permissions.', ru: 'У вас нет прав на предоставление доступа к профилям. Обратитесь к администратору для расширения прав.', zh: '您没有分享配置文件的权限。请联系管理员提升权限。' },
  'Email tạo': { en: 'Creator email', ru: 'Email создателя', zh: '创建者邮箱' },
  'Đang đồng bộ lại không gian làm việc…': { en: 'Re-syncing workspace…', ru: 'Повторная синхронизация рабочего пространства…', zh: '正在重新同步工作区…' },
  'Không tải được danh sách hồ sơ.': { en: 'Failed to load the profile list.', ru: 'Не удалось загрузить список профилей.', zh: '无法加载配置文件列表。' },
  'Tạo bởi:': { en: 'Created by:', ru: 'Создано:', zh: '创建者：' },
  'Nhân bản hồ sơ thất bại': { en: 'Failed to duplicate profile', ru: 'Не удалось продублировать профиль', zh: '克隆配置文件失败' },
  'thất bại': { en: 'failed', ru: 'не удалось', zh: '失败' },
  'Tạo thẻ thất bại': { en: 'Failed to create tag', ru: 'Не удалось создать тег', zh: '创建标签失败' },
  'Cập nhật thẻ thất bại': { en: 'Failed to update tag', ru: 'Не удалось обновить тег', zh: '更新标签失败' },
  'Cập nhật thẻ hàng loạt thất bại': { en: 'Failed to bulk-update tags', ru: 'Не удалось массово обновить теги', zh: '批量更新标签失败' },
  'Cập nhật ghi chú thất bại': { en: 'Failed to update note', ru: 'Не удалось обновить заметку', zh: '更新备注失败' },
  'Xóa thẻ thất bại': { en: 'Failed to delete tag', ru: 'Не удалось удалить тег', zh: '删除标签失败' },
  'Xóa ghi chú thất bại': { en: 'Failed to delete note', ru: 'Не удалось удалить заметку', zh: '删除备注失败' },
  'Cập nhật proxy thất bại': { en: 'Failed to update proxy', ru: 'Не удалось обновить прокси', zh: '更新代理失败' },
  'Đã chuyển nhóm': { en: 'Moved to group', ru: 'Группа изменена', zh: '已移动分组' },
  'Chuyển nhóm thất bại': { en: 'Failed to move group', ru: 'Не удалось сменить группу', zh: '移动分组失败' },
  'Email người nhận': { en: 'Recipient email', ru: 'Email получателя', zh: '收件人邮箱' },
  'Nhập email người nhận': { en: 'Enter recipient email', ru: 'Введите email получателя', zh: '输入收件人邮箱' },
  'Email không hợp lệ': { en: 'Invalid email', ru: 'Неверный email', zh: '邮箱无效' },
  'Hãy chọn ít nhất một quyền': { en: 'Select at least one permission', ru: 'Выберите хотя бы одно право', zh: '请至少选择一项权限' },
  'Đã gửi lời chia sẻ': { en: 'Share invitation sent', ru: 'Приглашение к доступу отправлено', zh: '已发送分享邀请' },
  'Chia sẻ hồ sơ thất bại': { en: 'Failed to share profile', ru: 'Не удалось предоставить доступ к профилю', zh: '分享配置文件失败' },
  'Không thể chia sẻ': { en: 'Cannot share', ru: 'Не удалось поделиться', zh: '无法分享' },
  'Xóa hồ sơ thất bại': { en: 'Failed to delete profile', ru: 'Не удалось удалить профиль', zh: '删除配置文件失败' },
  'Xóa proxy thất bại': { en: 'Failed to delete proxy', ru: 'Не удалось удалить прокси', zh: '删除代理失败' },
  'Ngừng dùng proxy thất bại': { en: 'Failed to stop using proxy', ru: 'Не удалось отключить прокси', zh: '停用代理失败' },
  'Đã đổi tên hồ sơ': { en: 'Profile renamed', ru: 'Профиль переименован', zh: '已重命名配置文件' },
  'Đổi tên hàng loạt thất bại': { en: 'Failed to bulk-rename', ru: 'Не удалось массово переименовать', zh: '批量重命名失败' },
  'Đổi tên thẻ thất bại': { en: 'Failed to rename tag', ru: 'Не удалось переименовать тег', zh: '重命名标签失败' },
  'Không đủ quyền': { en: 'Insufficient permissions', ru: 'Недостаточно прав', zh: '权限不足' },
  'Lên lịch nhiệm vụ thất bại': { en: 'Failed to schedule task', ru: 'Не удалось запланировать задачу', zh: '排定任务失败' },
  'Tạo nhiệm vụ thất bại': { en: 'Failed to create task', ru: 'Не удалось создать задачу', zh: '创建任务失败' },
  'Nhân bản hàng loạt thất bại': { en: 'Failed to bulk-duplicate', ru: 'Не удалось массово продублировать', zh: '批量克隆失败' },

  // ── Proxies (proxies.js) ──────────────────────────────────────────────────
  'Bạn chỉ có quyền xem & chạy - không thể thêm/sửa/xóa proxy. Liên hệ quản trị để nâng quyền.': { en: 'You only have view & run access - you cannot add/edit/delete proxies. Contact an admin to upgrade your permissions.', ru: 'У вас только доступ на просмотр и запуск - добавление, изменение и удаление прокси недоступны. Обратитесь к администратору для расширения прав.', zh: '您仅有查看和运行权限，无法添加/编辑/删除代理。请联系管理员提升权限。' },
  'Lưu proxy thất bại': { en: 'Failed to save proxy', ru: 'Не удалось сохранить прокси', zh: '保存代理失败' },
  'Sao chép proxy thất bại': { en: 'Failed to copy proxy', ru: 'Не удалось скопировать прокси', zh: '复制代理失败' },

  // ── Lập lịch (scheduler.js) ───────────────────────────────────────────────
  'Bật lịch thất bại': { en: 'Failed to enable schedule', ru: 'Не удалось включить расписание', zh: '启用计划失败' },
  'Tắt lịch thất bại': { en: 'Failed to disable schedule', ru: 'Не удалось выключить расписание', zh: '停用计划失败' },
  'Xóa lịch thất bại': { en: 'Failed to delete schedule', ru: 'Не удалось удалить расписание', zh: '删除计划失败' },

  // ── Cài đặt (settings.js) ─────────────────────────────────────────────────
  'Sử dụng giao diện kéo thả của Flowchart': { en: 'Use the Flowchart drag-and-drop interface', ru: 'Использовать интерфейс перетаскивания Flowchart', zh: '使用 Flowchart 拖放界面' },
  'Mã Javascript': { en: 'JavaScript code', ru: 'Код JavaScript', zh: 'JavaScript 代码' },
  'Sử dụng các lệnh lập trình ngôn ngữ Javascript': { en: 'Use JavaScript programming commands', ru: 'Использовать команды языка JavaScript', zh: '使用 JavaScript 编程命令' },
  'Đường dẫn lưu trữ dữ liệu hồ sơ': { en: 'Profile data storage path', ru: 'Путь хранения данных профилей', zh: '配置文件数据存储路径' },
  'Đồng bộ cookie': { en: 'Sync cookies', ru: 'Синхронизировать cookie', zh: '同步 Cookie' },
  'Đồng bộ IndexedDB': { en: 'Sync IndexedDB', ru: 'Синхронизировать IndexedDB', zh: '同步 IndexedDB' },
  'Đồng bộ local storage': { en: 'Sync local storage', ru: 'Синхронизировать local storage', zh: '同步 local storage' },
  'Đồng bộ dấu trang': { en: 'Sync bookmarks', ru: 'Синхронизировать закладки', zh: '同步书签' },
  'Đồng bộ mật khẩu đã lưu': { en: 'Sync saved passwords', ru: 'Синхронизировать сохранённые пароли', zh: '同步已保存的密码' },
  'Tắt thông báo': { en: 'Disable notifications', ru: 'Отключить уведомления', zh: '关闭通知' },
  'Tắt vị trí': { en: 'Disable location', ru: 'Отключить геолокацию', zh: '关闭定位' },
  'Cài đặt nhiệm vụ': { en: 'Task settings', ru: 'Настройки задач', zh: '任务设置' },
  'Lưu log chạy nhiệm vụ': { en: 'Save task run logs', ru: 'Сохранять журналы запусков задач', zh: '保存任务运行日志' },
  'Chế độ tạo quy trình': { en: 'Workflow creation mode', ru: 'Режим создания процессов', zh: '流程创建模式' },
  'Cài đặt ứng dụng': { en: 'App settings', ru: 'Настройки приложения', zh: '应用设置' },

  // ── Đồng bộ thao tác (sync.js) ────────────────────────────────────────────
  'Yêu cầu mở từ 2 hồ sơ trở lên để thực hiện tính năng này': { en: 'Open at least 2 profiles to use this feature', ru: 'Откройте не менее 2 профилей, чтобы использовать эту функцию', zh: '需打开至少 2 个配置文件才能使用此功能' },

  // ── Nhiệm vụ / thùng rác / tạo hồ sơ ──────────────────────────────────────
  'Lưu nhiệm vụ thất bại': { en: 'Failed to save task', ru: 'Не удалось сохранить задачу', zh: '保存任务失败' },
  'Xóa nhiệm vụ thất bại': { en: 'Failed to delete task', ru: 'Не удалось удалить задачу', zh: '删除任务失败' },
  'Khôi phục hồ sơ thất bại': { en: 'Failed to restore profile', ru: 'Не удалось восстановить профиль', zh: '恢复配置文件失败' },
  'Xóa vĩnh viễn thất bại': { en: 'Failed to permanently delete', ru: 'Не удалось удалить безвозвратно', zh: '永久删除失败' },
  'Lưu hồ sơ thất bại': { en: 'Failed to save profile', ru: 'Не удалось сохранить профиль', zh: '保存配置文件失败' },
  'Tạo hồ sơ thất bại': { en: 'Failed to create profile', ru: 'Не удалось создать профиль', zh: '创建配置文件失败' },

  // ── Rà soát phủ ngôn ngữ 2026-07-19 (i18n audit: en/ru/zh) ──────────────────
  "- Chọn quy trình để đăng -": { en: "- Select a workflow to publish -", ru: "- Выберите процесс для публикации -", zh: "- 选择要发布的流程 -" },
  "3 giờ trước": { en: "3 hours ago", ru: "3 часа назад", zh: "3 小时前" },
  "5000-100K Hồ sơ trình duyệt": { en: "5000-100K browser profiles", ru: "5000-100K профилей браузера", zh: "5000-100K 个浏览器配置文件" },
  "Bạn chưa đăng kịch bản nào lên chợ.": { en: "You haven't published any scripts to the marketplace.", ru: "Вы ещё не опубликовали ни одного скрипта в магазине.", zh: "您还没有向市场发布任何脚本。" },
  "Bạn đang dùng bản mới nhất": { en: "You are on the latest version", ru: "У вас установлена последняя версия", zh: "您正在使用最新版本" },
  "Bật đồng bộ": { en: "Enable sync", ru: "Включить синхронизацию", zh: "开启同步" },
  "cách đây …": { en: "… ago", ru: "… назад", zh: "… 前" },
  "Cập nhật thất bại": { en: "Update failed", ru: "Не удалось обновить", zh: "更新失败" },
  "Chạy thử": { en: "Test run", ru: "Пробный запуск", zh: "试运行" },
  "Chạy thử:": { en: "Test run:", ru: "Пробный запуск:", zh: "试运行：" },
  "Chỉnh sửa hồ sơ": { en: "Edit profile", ru: "Редактировать профиль", zh: "编辑配置文件" },
  "Chờ kiểm duyệt": { en: "Pending review", ru: "На модерации", zh: "待审核" },
  "Chọn thư mục lưu trữ": { en: "Select storage folder", ru: "Выберите папку для хранения", zh: "选择存储文件夹" },
  "Chưa cấu hình Telegram trên máy chủ": { en: "Telegram is not configured on the server", ru: "Telegram не настроен на сервере", zh: "服务器上尚未配置 Telegram" },
  "Chưa có kịch bản nào được duyệt.": { en: "No scripts have been approved yet.", ru: "Ещё нет одобренных скриптов.", zh: "还没有已审核通过的脚本。" },
  "Chưa có mô tả.": { en: "No description yet.", ru: "Описание отсутствует.", zh: "暂无描述。" },
  "Chưa có nhiệm vụ": { en: "No tasks yet", ru: "Пока нет задач", zh: "暂无任务" },
  "Chưa có thành viên nào": { en: "No members yet", ru: "Пока нет участников", zh: "暂无成员" },
  "Chúng tôi không hỗ trợ email tạm thời. Vui lòng dùng địa chỉ email người dùng thường xuyên để đăng ký.": { en: "We do not support temporary emails. Please use a regularly used email address to register.", ru: "Мы не поддерживаем временные адреса электронной почты. Пожалуйста, используйте для регистрации свой постоянный адрес электронной почты.", zh: "我们不支持临时邮箱。请使用您常用的电子邮件地址进行注册。" },
  "Cột đã tồn tại": { en: "Column already exists", ru: "Столбец уже существует", zh: "列已存在" },
  "Đã đổi nơi lưu trữ - khởi động lại app để áp dụng": { en: "Storage location changed - restart the app to apply", ru: "Место хранения изменено - перезапустите приложение для применения", zh: "存储位置已更改 - 重启应用以生效" },
  "Đã duyệt kịch bản": { en: "Script approved", ru: "Скрипт одобрен", zh: "脚本已审核通过" },
  "Đã huỷ yêu cầu đăng quy trình": { en: "Workflow publish request cancelled", ru: "Запрос на публикацию процесса отменён", zh: "已取消流程发布请求" },
  "Đã kết nối Telegram": { en: "Telegram connected", ru: "Telegram подключён", zh: "已连接 Telegram" },
  "đã nhận": { en: "received", ru: "получено", zh: "已收到" },
  "Đã từ chối kịch bản": { en: "Script rejected", ru: "Скрипт отклонён", zh: "脚本已拒绝" },
  "Dán Refresh Token của Google": { en: "Paste your Google Refresh Token", ru: "Вставьте Refresh Token от Google", zh: "粘贴您的 Google Refresh Token" },
  "Đăng chợ kịch bản": { en: "Publish to script marketplace", ru: "Опубликовать в магазине скриптов", zh: "发布到脚本市场" },
  "Đang đồng bộ": { en: "Syncing", ru: "Синхронизация", zh: "正在同步" },
  "Đăng kịch bản thất bại": { en: "Failed to publish script", ru: "Не удалось опубликовать скрипт", zh: "发布脚本失败" },
  "Đang mở trình cài đặt…": { en: "Opening the installer…", ru: "Открытие установщика…", zh: "正在打开安装程序…" },
  "Đăng nhập Google Drive thất bại": { en: "Failed to sign in to Google Drive", ru: "Не удалось войти в Google Drive", zh: "登录 Google Drive 失败" },
  "Đăng quy trình lên chợ": { en: "Publish workflow to marketplace", ru: "Опубликовать процесс в магазине", zh: "将流程发布到市场" },
  "Đang tạo mã QR…": { en: "Generating QR code…", ru: "Создание QR-кода…", zh: "正在生成 QR 码…" },
  "Để sau": { en: "Later", ru: "Позже", zh: "稍后" },
  "Dịch vụ chăm sóc khách hàng riêng và hỗ trợ phát triển tính năng tùy chỉnh": { en: "Dedicated customer support and assistance developing custom features", ru: "Персональная поддержка клиентов и помощь в разработке индивидуальных функций", zh: "专属客户服务及定制功能开发支持" },
  "Dữ liệu đồng bộ": { en: "Synced data", ru: "Синхронизируемые данные", zh: "同步数据" },
  "Duyệt đã chọn": { en: "Approve selected", ru: "Одобрить выбранные", zh: "审核通过所选" },
  "giá thanh toán": { en: "payment price", ru: "цена оплаты", zh: "支付价格" },
  "Gỡ": { en: "Remove", ru: "Удалить", zh: "移除" },
  "Gói thuê bao đã hết hạn - hãy gia hạn để tiếp tục sử dụng.": { en: "Your subscription plan has expired - renew to continue using it.", ru: "Срок действия тарифа истёк - продлите его, чтобы продолжить использование.", zh: "订阅套餐已过期 - 请续费以继续使用。" },
  "Gửi báo cáo": { en: "Send report", ru: "Отправить отчёт", zh: "发送报告" },
  "hết hạn": { en: "expired", ru: "истёк", zh: "已过期" },
  "Hình thức": { en: "Type", ru: "Способ", zh: "方式" },
  "Hỗ trợ riêng cho việc di chuyển dữ liệu": { en: "Dedicated support for data migration", ru: "Персональная поддержка при миграции данных", zh: "数据迁移专属支持" },
  "Hướng dẫn sử dụng...": { en: "User guide...", ru: "Руководство пользователя...", zh: "使用指南…" },
  "Kết nối": { en: "Connect", ru: "Подключить", zh: "连接" },
  "Khóa": { en: "Lock", ru: "Заблокировать", zh: "锁定" },
  "Không có kịch bản nào đang chờ duyệt.": { en: "There are no scripts pending review.", ru: "Нет скриптов на модерации.", zh: "没有待审核的脚本。" },
  "Không đọc được số dư ví": { en: "Unable to read wallet balance", ru: "Не удалось прочитать баланс кошелька", zh: "无法读取钱包余额" },
  "Không gia hạn": { en: "Do not renew", ru: "Не продлевать", zh: "不续费" },
  "Không lấy được thông tin nạp tiền": { en: "Unable to retrieve top-up information", ru: "Не удалось получить информацию о пополнении", zh: "无法获取充值信息" },
  "Không tải được trình soạn thảo": { en: "Failed to load the editor", ru: "Не удалось загрузить редактор", zh: "无法加载编辑器" },
  "Không truy cập được ID này - sẽ đồng bộ vào Tin nhắn đã lưu.": { en: "Unable to access this ID - it will sync to Saved Messages.", ru: "Не удалось получить доступ к этому ID - синхронизация будет выполнена в «Избранное».", zh: "无法访问此 ID - 将同步到已保存的消息。" },
  "Kịch bản đang chờ duyệt nên chưa thể tải về. Hãy \"Chạy thử\" để kiểm tra trước khi duyệt.": { en: "The script is pending review and cannot be downloaded yet. Use \"Test run\" to check it before approving.", ru: "Скрипт находится на модерации и пока недоступен для загрузки. Используйте «Пробный запуск», чтобы проверить его перед одобрением.", zh: "脚本正在待审核中，暂时无法下载。请在审核通过前使用“试运行”进行检查。" },
  "Kịch bản này không có tham số đầu vào.": { en: "This script has no input parameters.", ru: "У этого скрипта нет входных параметров.", zh: "此脚本没有输入参数。" },
  "Lượt xem": { en: "Views", ru: "Просмотры", zh: "浏览量" },
  "Mã hóa quy trình": { en: "Encrypt workflow", ru: "Шифровать процесс", zh: "加密流程" },
  "Miễn phí": { en: "Free", ru: "Бесплатно", zh: "免费" },
  "Mở mục Nâng cấp gói ở thanh bên để nâng cấp.": { en: "Open the Upgrade plan section in the sidebar to upgrade.", ru: "Откройте раздел «Повысить тариф» на боковой панели, чтобы улучшить тариф.", zh: "在侧边栏打开“升级套餐”栏目进行升级。" },
  "Mỗi gói bao gồm một Quản trị viên cấp cao miễn phí": { en: "Each plan includes one free senior administrator", ru: "Каждый тариф включает одного старшего администратора бесплатно", zh: "每个套餐均包含一名免费的高级管理员" },
  "Mua kịch bản": { en: "Buy script", ru: "Купить скрипт", zh: "购买脚本" },
  "nâng cấp": { en: "upgrade", ru: "повысить тариф", zh: "升级" },
  "Nâng cấp ngay bây giờ": { en: "Upgrade now", ru: "Повысить тариф сейчас", zh: "立即升级" },
  "Ngắt kết nối": { en: "Disconnect", ru: "Отключить", zh: "断开连接" },
  "ngày": { en: "days", ru: "дней", zh: "天" },
  "Người viết": { en: "Author", ru: "Автор", zh: "作者" },
  "nhân viên": { en: "employee", ru: "сотрудник", zh: "员工" },
  "Nhập số lượng hồ sơ hợp lệ (≥ 1)": { en: "Enter a valid number of profiles (≥ 1)", ru: "Введите допустимое количество профилей (≥ 1)", zh: "请输入有效的配置文件数量（≥ 1）" },
  "phần MUA THÊM": { en: "BUY MORE section", ru: "раздел «КУПИТЬ ЕЩЁ»", zh: "“加购”部分" },
  "Phiên bản hiện tại": { en: "Current version", ru: "Текущая версия", zh: "当前版本" },
  "Phổ biến": { en: "Popular", ru: "Популярное", zh: "热门" },
  "Quay lại chợ": { en: "Back to marketplace", ru: "Назад в магазин", zh: "返回市场" },
  "Quill không khả dụng sau khi tải": { en: "Quill is unavailable after loading", ru: "Quill недоступен после загрузки", zh: "加载后 Quill 不可用" },
  "Quy trình tải về": { en: "Downloaded workflow", ru: "Загруженный процесс", zh: "下载的流程" },
  "Số dư …": { en: "Balance …", ru: "Баланс …", zh: "余额 …" },
  "Số hồ sơ:": { en: "Number of profiles:", ru: "Количество профилей:", zh: "配置文件数量：" },
  "Sửa": { en: "Edit", ru: "Редактировать", zh: "编辑" },
  "Tải hình ảnh": { en: "Download image", ru: "Загрузить изображение", zh: "下载图片" },
  "Tài khoản Telegram": { en: "Telegram account", ru: "Аккаунт Telegram", zh: "Telegram 账户" },
  "Tải lên ảnh đại diện": { en: "Upload avatar", ru: "Загрузить аватар", zh: "上传头像" },
  "Tất Cả": { en: "All", ru: "Все", zh: "全部" },
  "Tên gốc, ví dụ: Acc": { en: "Base name, e.g.: Acc", ru: "Базовое имя, например: Acc", zh: "基础名称，例如：Acc" },
  "Thành viên của nhóm": { en: "Group members", ru: "Участники группы", zh: "群组成员" },
  "Thời gian hết hạn": { en: "Expiration time", ru: "Время истечения срока", zh: "到期时间" },
  "Tính năng này không khả dụng với quy trình được tải về": { en: "This feature is not available for downloaded workflows", ru: "Эта функция недоступна для загруженных процессов", zh: "此功能不适用于下载的流程" },
  "Trả phí": { en: "Paid", ru: "Платно", zh: "付费" },
  "Từ chối đã chọn": { en: "Reject selected", ru: "Отклонить выбранные", zh: "拒绝所选" },
  "ví": { en: "wallet", ru: "кошелёк", zh: "钱包" },
  "Vui lòng chọn danh mục": { en: "Please select a category", ru: "Пожалуйста, выберите категорию", zh: "请选择类别" },
  "Vui lòng nhập đủ thông tin bắt buộc": { en: "Please fill in all required information", ru: "Пожалуйста, заполните все обязательные поля", zh: "请填写所有必填信息" },
  "Vui lòng nhập tiêu đề": { en: "Please enter a title", ru: "Пожалуйста, введите заголовок", zh: "请输入标题" },
  "Xác nhận nâng cấp gói": { en: "Confirm plan upgrade", ru: "Подтвердить повышение тарифа", zh: "确认升级套餐" },
  "Xóa bộ nhớ đệm thất bại": { en: "Failed to clear cache", ru: "Не удалось очистить кэш", zh: "清除缓存失败" },
  "(đã hết hạn)": { en: "(expired)", ru: "(истёк)", zh: "（已过期）" },
  "30 ngày": { en: "30 days", ru: "30 дней", zh: "30 天" },
  "Ẩn danh": { en: "Anonymous", ru: "Анонимно", zh: "匿名" },
  "Bạn có chắc chắn muốn mua gói?": { en: "Are you sure you want to buy this plan?", ru: "Вы уверены, что хотите купить тариф?", zh: "您确定要购买套餐吗？" },
  "Bảng": { en: "Table", ru: "Таблица", zh: "表格" },
  "Bị từ chối": { en: "Rejected", ru: "Отклонено", zh: "已拒绝" },
  "Cập nhật ngay": { en: "Update now", ru: "Обновить сейчас", zh: "立即更新" },
  "Cập nhật thông tin cá nhân": { en: "Update personal information", ru: "Обновить личные данные", zh: "更新个人信息" },
  "Chạy thử hoàn tất": { en: "Test run completed", ru: "Тестовый запуск завершён", zh: "试运行完成" },
  "Chế độ hiển thị": { en: "Display mode", ru: "Режим отображения", zh: "显示模式" },
  "chỉnh sửa quy trình": { en: "edit workflow", ru: "редактировать процесс", zh: "编辑流程" },
  "Chọn danh mục": { en: "Select category", ru: "Выберите категорию", zh: "选择类别" },
  "Chu kỳ đăng ký": { en: "Subscription cycle", ru: "Период подписки", zh: "订阅周期" },
  "Chưa chọn kịch bản nào": { en: "No script selected", ru: "Скрипт не выбран", zh: "尚未选择脚本" },
  "Chưa có kịch bản nào phù hợp.": { en: "No matching script yet.", ru: "Пока нет подходящих скриптов.", zh: "暂无匹配的脚本。" },
  "Chưa có nhật ký thay đổi.": { en: "No changelog yet.", ru: "Журнал изменений пока пуст.", zh: "暂无变更日志。" },
  "Chưa có proxy": { en: "No proxy yet", ru: "Прокси пока нет", zh: "暂无代理" },
  "chưa kết nối": { en: "not connected", ru: "не подключено", zh: "未连接" },
  "Chúng tôi khuyến nghị cập nhật lên phiên bản mới nhất để có trải nghiệm tốt nhất và các tính năng mới nhất.": { en: "We recommend updating to the latest version for the best experience and newest features.", ru: "Мы рекомендуем обновиться до последней версии, чтобы получить наилучший опыт и новейшие функции.", zh: "我们建议更新到最新版本，以获得最佳体验和最新功能。" },
  "Đã cập nhật thông tin cá nhân": { en: "Personal information updated", ru: "Личные данные обновлены", zh: "已更新个人信息" },
  "Đã dừng chạy thử": { en: "Test run stopped", ru: "Тестовый запуск остановлен", zh: "已停止试运行" },
  "Đã gỡ kịch bản": { en: "Script removed", ru: "Скрипт удалён", zh: "已移除脚本" },
  "Đã kết nối": { en: "Connected", ru: "Подключено", zh: "已连接" },
  "Đã ngắt kết nối Google Drive": { en: "Google Drive disconnected", ru: "Google Drive отключён", zh: "已断开 Google Drive 连接" },
  "đã nhận +X": { en: "received +X", ru: "получено +X", zh: "已获得 +X" },
  "Đã xóa bộ nhớ đệm": { en: "Cache cleared", ru: "Кэш очищен", zh: "已清除缓存" },
  "Đăng": { en: "Publish", ru: "Опубликовать", zh: "发布" },
  "Đang chờ quét QR…": { en: "Waiting for QR scan…", ru: "Ожидание сканирования QR…", zh: "等待扫描 QR…" },
  "Đang đóng…": { en: "Closing…", ru: "Закрытие…", zh: "正在关闭…" },
  "Đang kiểm tra ID…": { en: "Checking ID…", ru: "Проверка ID…", zh: "正在检查 ID…" },
  "Đang mở…": { en: "Opening…", ru: "Открытие…", zh: "正在打开…" },
  "Đăng nhập Telegram": { en: "Log in to Telegram", ru: "Вход в Telegram", zh: "登录 Telegram" },
  "Đăng quy trình thất bại": { en: "Failed to publish workflow", ru: "Не удалось опубликовать процесс", zh: "发布流程失败" },
  "Đang xử lý…": { en: "Processing…", ru: "Обработка…", zh: "正在处理…" },
  "Để trống sẽ dùng us-east-1. Cloudflare R2 dùng \"auto\".": { en: "Leave empty to use us-east-1. Cloudflare R2 uses \"auto\".", ru: "Оставьте пустым, чтобы использовать us-east-1. Cloudflare R2 использует \"auto\".", zh: "留空将使用 us-east-1。Cloudflare R2 使用 \"auto\"。" },
  "Dịch vụ lưu trữ trực tuyến của Google, cho phép lưu và truy cập từ bất cứ đâu. Miễn phí 15GB ban đầu. Nhược điểm: tốc độ có thể chậm ở một số khu vực và băng thông bị giới hạn nếu dùng liên tục.": { en: "Google's online storage service, letting you save and access files from anywhere. 15GB free to start. Downside: speed may be slow in some regions and bandwidth is throttled with continuous use.", ru: "Онлайн-хранилище Google, позволяющее сохранять и получать доступ к файлам из любого места. 15 ГБ бесплатно для начала. Недостаток: скорость может быть низкой в некоторых регионах, а пропускная способность ограничивается при постоянном использовании.", zh: "Google 的在线存储服务，可随时随地保存和访问文件。初始免费 15GB。缺点：部分地区速度可能较慢，持续使用时带宽会受到限制。" },
  "Dùng khi bạn đã có sẵn Refresh Token (kết nối không cần mở trình duyệt).": { en: "Use when you already have a Refresh Token (connect without opening a browser).", ru: "Используйте, если у вас уже есть Refresh Token (подключение без открытия браузера).", zh: "当您已拥有 Refresh Token 时使用（无需打开浏览器即可连接）。" },
  "Giá (VND, 0 = miễn phí)": { en: "Price (VND, 0 = free)", ru: "Цена (VND, 0 = бесплатно)", zh: "价格（VND，0 = 免费）" },
  "Giá thành viên": { en: "Member price", ru: "Цена за участника", zh: "成员价格" },
  "Gỡ kịch bản": { en: "Remove script", ru: "Удалить скрипт", zh: "移除脚本" },
  "Gói hiện tại": { en: "Current plan", ru: "Текущий тариф", zh: "当前套餐" },
  "Gói thuê bao đã hết hạn - vui lòng gia hạn để tiếp tục sử dụng": { en: "Your subscription plan has expired - please renew to continue using it", ru: "Срок действия тарифа истёк - пожалуйста, продлите его, чтобы продолжить использование", zh: "订阅套餐已过期 - 请续费以继续使用" },
  "Gửi lại (Ns)": { en: "Resend (Ns)", ru: "Отправить снова (Ns)", zh: "重新发送（Ns）" },
  "Hết hạn lúc": { en: "Expires at", ru: "Истекает в", zh: "过期时间" },
  "Hồ Sơ": { en: "Profiles", ru: "Профили", zh: "配置文件" },
  "Hoàn tất tải · đang cài đặt": { en: "Download complete · installing", ru: "Загрузка завершена · установка", zh: "下载完成 · 正在安装" },
  "Hướng máy ảnh vào mã QR này để quét.": { en: "Point your camera at this QR code to scan.", ru: "Наведите камеру на этот QR-код для сканирования.", zh: "将相机对准此 QR 码进行扫描。" },
  "Kết nối bằng Token thất bại": { en: "Failed to connect with Token", ru: "Не удалось подключиться с помощью Token", zh: "使用 Token 连接失败" },
  "không có cập nhật mới": { en: "no new update", ru: "нет новых обновлений", zh: "没有新更新" },
  "Không có kịch bản nào khớp tìm kiếm.": { en: "No script matches your search.", ru: "Нет скриптов, соответствующих поиску.", zh: "没有与搜索匹配的脚本。" },
  "Không đổi được nơi lưu trữ": { en: "Failed to change storage location", ru: "Не удалось изменить место хранения", zh: "无法更改存储位置" },
  "Không hỗ trợ email này": { en: "This email is not supported", ru: "Этот адрес электронной почты не поддерживается", zh: "不支持此邮箱" },
  "Không mã hóa": { en: "No encryption", ru: "Без шифрования", zh: "不加密" },
  "Không tải được trình soạn thảo hướng dẫn": { en: "Failed to load the guide editor", ru: "Не удалось загрузить редактор инструкций", zh: "无法加载指南编辑器" },
  "Kịch bản chưa được duyệt nên chưa thể tải về. Hãy duyệt hoặc \"Chạy thử\" để kiểm tra.": { en: "The script has not been approved yet, so it cannot be downloaded. Please approve it or use \"Test run\" to check.", ru: "Скрипт ещё не одобрен, поэтому его нельзя скачать. Пожалуйста, одобрите его или используйте \"Тестовый запуск\" для проверки.", zh: "脚本尚未审核通过，因此无法下载。请审核通过或使用\"试运行\"进行检查。" },
  "Kịch bản không có nội dung để chạy": { en: "The script has no content to run", ru: "В скрипте нет содержимого для запуска", zh: "脚本没有可运行的内容" },
  "Kiểm tra cập nhật": { en: "Check for updates", ru: "Проверить обновления", zh: "检查更新" },
  "Lưu cấu hình thất bại": { en: "Failed to save configuration", ru: "Не удалось сохранить конфигурацию", zh: "保存配置失败" },
  "Mã QR chuyển khoản": { en: "Bank transfer QR code", ru: "QR-код для банковского перевода", zh: "转账 QR 码" },
  "Miễn phí (một lần)": { en: "Free (one-time)", ru: "Бесплатно (единоразово)", zh: "免费（一次性）" },
  "mở script đã tải từ chợ về": { en: "open a script downloaded from the marketplace", ru: "открыть скрипт, загруженный из магазина", zh: "打开从市场下载的脚本" },
  "Mỗi gói có đơn giá gốc riêng. Trong cùng một gói, số hồ sơ càng cao càng được giảm giá.": { en: "Each plan has its own base unit price. Within the same plan, the more profiles you have, the bigger the discount.", ru: "Каждый тариф имеет собственную базовую цену за единицу. В рамках одного тарифа, чем больше профилей, тем больше скидка.", zh: "每个套餐都有各自的基础单价。在同一套餐内，配置文件数量越多，折扣越大。" },
  "Mua kịch bản thất bại": { en: "Failed to buy script", ru: "Не удалось купить скрипт", zh: "购买脚本失败" },
  "Nâng cấp": { en: "Upgrade", ru: "Повысить тариф", zh: "升级" },
  "Nạp tiền thành công": { en: "Top-up successful", ru: "Пополнение выполнено успешно", zh: "充值成功" },
  "Ngắt kết nối S3 thất bại": { en: "Failed to disconnect S3", ru: "Не удалось отключить S3", zh: "断开 S3 连接失败" },
  "Ngày hết hạn:": { en: "Expiration date:", ru: "Дата истечения:", zh: "过期日期：" },
  "Nhà phát triển": { en: "Developer", ru: "Разработчик", zh: "开发者" },
  "Nhập Cookie": { en: "Import Cookie", ru: "Импортировать Cookie", zh: "导入 Cookie" },
  "Nhập tên hiển thị": { en: "Enter display name", ru: "Введите отображаемое имя", zh: "输入显示名称" },
  "Phí tải về": { en: "Download fee", ru: "Плата за скачивание", zh: "下载费用" },
  "Phiên bản miễn phí": { en: "Free version", ru: "Бесплатная версия", zh: "免费版本" },
  "Quản lý script": { en: "Manage scripts", ru: "Управление скриптами", zh: "管理脚本" },
  "Quét mã bằng ứng dụng Telegram trên điện thoại.": { en: "Scan the code with the Telegram app on your phone.", ru: "Отсканируйте код с помощью приложения Telegram на телефоне.", zh: "使用手机上的 Telegram 应用扫描二维码。" },
  "Quy trình đã đăng": { en: "Workflow published", ru: "Процесс опубликован", zh: "流程已发布" },
  "Sắp xếp mã": { en: "Arrange code", ru: "Упорядочить код", zh: "整理代码" },
  "Số dư không đủ": { en: "Insufficient balance", ru: "Недостаточно средств", zh: "余额不足" },
  "Số lượng thành viên": { en: "Number of members", ru: "Количество участников", zh: "成员数量" },
  "Sửa kịch bản trên chợ": { en: "Edit script on the marketplace", ru: "Редактировать скрипт в магазине", zh: "在市场上编辑脚本" },
  "Tài khoản bật 2FA - chưa hỗ trợ QR": { en: "Account has 2FA enabled - QR not supported yet", ru: "На аккаунте включена 2FA - QR пока не поддерживается", zh: "账户已启用 2FA - 暂不支持 QR" },
  "Tải kịch bản thất bại": { en: "Failed to download script", ru: "Не удалось загрузить скрипт", zh: "下载脚本失败" },
  "Tài nguyên": { en: "Resources", ru: "Ресурсы", zh: "资源" },
  "Tắt đồng bộ": { en: "Turn off sync", ru: "Отключить синхронизацию", zh: "关闭同步" },
  "Tên kịch bản": { en: "Script name", ru: "Название скрипта", zh: "脚本名称" },
  "Thao tác duyệt thất bại": { en: "Approval action failed", ru: "Не удалось выполнить одобрение", zh: "审核通过操作失败" },
  "Thời gian phê duyệt quy trình trong vòng 24h, nếu bạn chờ lâu hơn có thể liên hệ trực tiếp qua chúng tôi.": { en: "Workflow approval takes up to 24h; if you wait longer, you can contact us directly.", ru: "Одобрение процесса занимает до 24 часов; если ожидание затягивается, вы можете связаться с нами напрямую.", zh: "流程审核时间在 24 小时内，如果您等待更久，可以直接联系我们。" },
  "Tối đa 1000 hồ sơ mỗi lần": { en: "Up to 1000 profiles at a time", ru: "До 1000 профилей за раз", zh: "每次最多 1000 个配置文件" },
  "Trả phí theo năm": { en: "Pay annually", ru: "Оплата за год", zh: "按年付费" },
  "Từ chối kịch bản": { en: "Reject script", ru: "Отклонить скрипт", zh: "拒绝脚本" },
  "Ví dụ, nếu bạn cần 10 thành viên, thì: 10*35000₫ = 350000₫": { en: "For example, if you need 10 members, then: 10*35000₫ = 350000₫", ru: "Например, если вам нужно 10 участников, то: 10*35000₫ = 350000₫", zh: "例如，如果您需要 10 个成员，则：10*35000₫ = 350000₫" },
  "Vui lòng chọn hồ sơ để chạy": { en: "Please select a profile to run", ru: "Пожалуйста, выберите профиль для запуска", zh: "请选择要运行的配置文件" },
  "Vui lòng nhập lý do từ chối": { en: "Please enter a reason for rejection", ru: "Пожалуйста, укажите причину отклонения", zh: "请输入拒绝原因" },
  "Vượt hạn mức thành viên": { en: "Member limit exceeded", ru: "Превышен лимит участников", zh: "超出成员限额" },
  "Xem thử": { en: "Preview", ru: "Предпросмотр", zh: "预览" },
  "Xóa cookie thất bại": { en: "Failed to delete cookie", ru: "Не удалось удалить cookie", zh: "删除 cookie 失败" },
  // Khoá phải là ký tự THẬT "←", không phải "&larr;": login.js render qua `html:` nên DOM giữ
  // text node ĐÃ giải mã entity - khoá ghi "&larr;" thì không bao giờ khớp. Giá trị cũng phải
  // là "←" vì bộ dịch gán vào nodeValue của text node, entity sẽ hiện nguyên chữ "&larr;".
  "← Quay lại đăng nhập": { en: "← Back to login", ru: "← Назад ко входу", zh: "← 返回登录" },
  "300-5000 Hồ sơ trình duyệt": { en: "300-5000 Browser profiles", ru: "300-5000 профилей браузера", zh: "300-5000 个浏览器配置文件" },
  "Ảnh quá lớn (tối đa 2MB)": { en: "Image too large (max 2MB)", ru: "Изображение слишком большое (максимум 2 МБ)", zh: "图片过大（最大 2MB）" },
  "Bạn có chắc chắn muốn nâng cấp gói?": { en: "Are you sure you want to upgrade the plan?", ru: "Вы уверены, что хотите повысить тариф?", zh: "确定要升级套餐吗？" },
  "Báo cáo kịch bản": { en: "Report script", ru: "Пожаловаться на скрипт", zh: "举报脚本" },
  "Các tệp sao lưu trên Google Drive sẽ hiển thị ở đây.": { en: "Backup files on Google Drive will appear here.", ru: "Файлы резервных копий на Google Drive будут отображаться здесь.", zh: "Google Drive 上的备份文件将显示在此处。" },
  "Cập nhật phần mềm": { en: "Software update", ru: "Обновление ПО", zh: "软件更新" },
  "Cập nhật thông tin thất bại": { en: "Failed to update information", ru: "Не удалось обновить данные", zh: "更新信息失败" },
  "Chạy thử thất bại": { en: "Test run failed", ru: "Не удалось выполнить тестовый запуск", zh: "试运行失败" },
  "Chi tiết gói": { en: "Plan details", ru: "Детали тарифа", zh: "套餐详情" },
  "chờ duyệt": { en: "pending review", ru: "на модерации", zh: "待审核" },
  "Chọn nơi đồng bộ": { en: "Choose sync destination", ru: "Выберите место синхронизации", zh: "选择同步位置" },
  "Chưa cấu hình Google Client cho Drive": { en: "Google Client not configured for Drive", ru: "Google Client не настроен для Drive", zh: "尚未为 Drive 配置 Google Client" },
  "Chưa có cấu hình trình duyệt.": { en: "No browser configuration yet.", ru: "Пока нет конфигурации браузера.", zh: "尚无浏览器配置。" },
  "Chưa có lịch": { en: "No schedule yet", ru: "Пока нет расписания", zh: "尚无计划" },
  "Chưa có nhật ký. Nhật ký sẽ hiển thị khi bạn chạy quy trình.": { en: "No logs yet. Logs will appear when you run a workflow.", ru: "Пока нет журналов. Журналы появятся, когда вы запустите процесс.", zh: "尚无日志。运行流程后将显示日志。" },
  "Chưa có tệp sao lưu": { en: "No backup files yet", ru: "Пока нет файлов резервных копий", zh: "尚无备份文件" },
  "Chưa kết nối": { en: "Not connected", ru: "Не подключено", zh: "未连接" },
  "có cập nhật": { en: "update available", ru: "есть обновление", zh: "有更新" },
  "Đã cập nhật, kịch bản chờ duyệt lại": { en: "Updated, script pending re-review", ru: "Обновлено, скрипт ожидает повторной модерации", zh: "已更新，脚本待重新审核" },
  "Đã dừng kiểm tra tự động. Mở lại nếu bạn vừa chuyển khoản.": { en: "Automatic checking stopped. Reopen if you just made a bank transfer.", ru: "Автоматическая проверка остановлена. Откройте снова, если вы только что сделали банковский перевод.", zh: "已停止自动检查。如果您刚刚转账，请重新打开。" },
  "Đã gửi báo cáo. Cảm ơn bạn!": { en: "Report sent. Thank you!", ru: "Жалоба отправлена. Спасибо!", zh: "举报已发送。谢谢您！" },
  "Đã kết nối Google Drive": { en: "Google Drive connected", ru: "Google Drive подключён", zh: "已连接 Google Drive" },
  "Đã ngắt kết nối S3": { en: "S3 disconnected", ru: "S3 отключён", zh: "已断开 S3 连接" },
  "Đã sở hữu": { en: "Owned", ru: "Приобретено", zh: "已拥有" },
  "Đã xóa cookie": { en: "Cookies cleared", ru: "Cookie удалены", zh: "已清除 Cookie" },
  "Đang cập nhật": { en: "Updating", ru: "Обновление", zh: "正在更新" },
  "Đang chuẩn bị tải…": { en: "Preparing download…", ru: "Подготовка загрузки…", zh: "正在准备下载…" },
  "Đang kết nối…": { en: "Connecting…", ru: "Подключение…", zh: "正在连接…" },
  "Đang kiểm tra kết nối…": { en: "Checking connection…", ru: "Проверка соединения…", zh: "正在检查连接…" },
  "Đăng nhập bằng Telegram": { en: "Log in with Telegram", ru: "Войти через Telegram", zh: "使用 Telegram 登录" },
  "Đăng nhập Telegram chưa được cấu hình trên máy chủ (TELEGRAM_API_ID / TELEGRAM_API_HASH). Lấy api_id + api_hash tại https://my.telegram.org rồi thêm vào server/.env.": { en: "Telegram login is not configured on the server (TELEGRAM_API_ID / TELEGRAM_API_HASH). Get api_id + api_hash at https://my.telegram.org then add them to server/.env.", ru: "Вход через Telegram не настроен на сервере (TELEGRAM_API_ID / TELEGRAM_API_HASH). Получите api_id + api_hash на https://my.telegram.org и добавьте их в server/.env.", zh: "服务器上尚未配置 Telegram 登录（TELEGRAM_API_ID / TELEGRAM_API_HASH）。请在 https://my.telegram.org 获取 api_id + api_hash 后添加到 server/.env。" },
  "Đang tải bản cập nhật…": { en: "Downloading update…", ru: "Загрузка обновления…", zh: "正在下载更新…" },
  "Đặt mua": { en: "Order", ru: "Заказать", zh: "订购" },
  "Địa chỉ dịch vụ S3 (không kèm tên bucket). VD: https://": { en: "S3 service address (without bucket name). E.g.: https://", ru: "Адрес сервиса S3 (без имени bucket). Например: https://", zh: "S3 服务地址（不含 bucket 名称）。例如：https://" },
  "Đơn giá": { en: "Unit price", ru: "Цена за единицу", zh: "单价" },
  "Dùng Token": { en: "Use Token", ru: "Использовать Token", zh: "使用 Token" },
  "Gia hạn ngay": { en: "Renew now", ru: "Продлить сейчас", zh: "立即续费" },
  "Giao dịch thất bại": { en: "Transaction failed", ru: "Транзакция не удалась", zh: "交易失败" },
  "Gỡ kịch bản thất bại": { en: "Failed to uninstall script", ru: "Не удалось удалить скрипт", zh: "卸载脚本失败" },
  "Gói thuê bao của không gian làm việc đã hết hạn. Vui lòng liên hệ chủ sở hữu để gia hạn.": { en: "The workspace's subscription plan has expired. Please contact the owner to renew.", ru: "Тариф подписки рабочего пространства истёк. Пожалуйста, свяжитесь с владельцем, чтобы продлить.", zh: "工作区的订阅套餐已过期。请联系所有者续费。" },
  "Gói trả phí": { en: "Paid plan", ru: "Платный тариф", zh: "付费套餐" },
  "Hãy nhập ghi chú": { en: "Please enter a note", ru: "Введите заметку", zh: "请输入备注" },
  "Hiển thị": { en: "Show", ru: "Показать", zh: "显示" },
  "Hồ sơ trình duyệt": { en: "Browser profile", ru: "Профиль браузера", zh: "浏览器配置文件" },
  "hôm nay": { en: "today", ru: "сегодня", zh: "今天" },
  "Huỷ yêu cầu": { en: "Cancel request", ru: "Отменить запрос", zh: "取消请求" },
  "Kết nối đích này để xem danh sách tệp sao lưu.": { en: "Connect this destination to view the list of backup files.", ru: "Подключите это место назначения, чтобы просмотреть список файлов резервных копий.", zh: "连接此目标以查看备份文件列表。" },
  "Không có cập nhật mới": { en: "No new updates", ru: "Нет новых обновлений", zh: "没有新更新" },
  "Không có kịch bản nào khớp.": { en: "No matching scripts.", ru: "Нет подходящих скриптов.", zh: "没有匹配的脚本。" },
  "không đủ tiền": { en: "insufficient funds", ru: "недостаточно средств", zh: "余额不足" },
  "Không kiểm tra được cập nhật": { en: "Could not check for updates", ru: "Не удалось проверить обновления", zh: "无法检查更新" },
  "Không mở được trình cài đặt": { en: "Could not open the installer", ru: "Не удалось открыть установщик", zh: "无法打开安装程序" },
  "Không tìm thấy kịch bản": { en: "Script not found", ru: "Скрипт не найден", zh: "未找到脚本" },
  "Kịch bản của tôi": { en: "My scripts", ru: "Мои скрипты", zh: "我的脚本" },
  "Kịch bản này chưa có hướng dẫn sử dụng.": { en: "This script has no usage guide yet.", ru: "У этого скрипта пока нет руководства по использованию.", zh: "此脚本尚无使用指南。" },
  "lỗi cơ sở dữ liệu": { en: "database error", ru: "ошибка базы данных", zh: "数据库错误" },
  "Lý do từ chối": { en: "Reason for rejection", ru: "Причина отклонения", zh: "拒绝原因" },
  "Mã QR đăng nhập Telegram": { en: "Telegram login QR code", ru: "QR-код для входа в Telegram", zh: "Telegram 登录 QR 码" },
  "Mở khóa tất cả tính năng trả phí": { en: "Unlock all paid features", ru: "Разблокировать все платные функции", zh: "解锁所有付费功能" },
  "Mô tả ngắn": { en: "Short description", ru: "Краткое описание", zh: "简短描述" },
  "Mới nhất": { en: "Latest", ru: "Новейшие", zh: "最新" },
  "Mua thành công! Đang tải về...": { en: "Purchase successful! Downloading...", ru: "Покупка успешна! Загрузка...", zh: "购买成功！正在下载…" },
  "Nâng cấp gói": { en: "Upgrade plan", ru: "Повысить тариф", zh: "升级套餐" },
  "Nền F9 (dịu)": { en: "F9 background (soft)", ru: "Фон F9 (мягкий)", zh: "F9 背景（柔和）" },
  "Ngắt kết nối Telegram thất bại": { en: "Failed to disconnect Telegram", ru: "Не удалось отключить Telegram", zh: "断开 Telegram 连接失败" },
  "Ngày sửa đổi": { en: "Modified date", ru: "Дата изменения", zh: "修改日期" },
  "Nhà phát triển này chưa có kịch bản nào được duyệt.": { en: "This developer has no approved scripts yet.", ru: "У этого разработчика пока нет одобренных скриптов.", zh: "此开发者尚无审核通过的脚本。" },
  "Nhập link kênh hoặc nhóm": { en: "Enter channel or group link", ru: "Введите ссылку на канал или группу", zh: "输入频道或群组链接" },
  "Nhật ký thay đổi (Changelog)...": { en: "Changelog...", ru: "Журнал изменений (Changelog)...", zh: "更新日志（Changelog）…" },
  "Phiên bản": { en: "Version", ru: "Версия", zh: "版本" },
  "Phiên bản mới đã sẵn sàng": { en: "New version is ready", ru: "Новая версия готова", zh: "新版本已就绪" },
  "quản lý thành viên": { en: "manage members", ru: "управление участниками", zh: "管理成员" },
  "Quét mã QR bằng ứng dụng Telegram để kết nối.": { en: "Scan the QR code with the Telegram app to connect.", ru: "Отсканируйте QR-код приложением Telegram, чтобы подключиться.", zh: "使用 Telegram 应用扫描 QR 码以连接。" },
  "QUY TRÌNH ĐANG CHỜ PHÊ DUYỆT": { en: "WORKFLOW PENDING APPROVAL", ru: "ПРОЦЕСС НА МОДЕРАЦИИ", zh: "流程待审核" },
  "Sẽ đồng bộ vào:": { en: "Will sync to:", ru: "Будет синхронизировано в:", zh: "将同步到：" },
  "Số dư ví": { en: "Wallet balance", ru: "Баланс кошелька", zh: "钱包余额" },
  "Số lượng thành viên:": { en: "Number of members:", ru: "Количество участников:", zh: "成员数量：" },
  "Tải ảnh lên": { en: "Upload image", ru: "Загрузить изображение", zh: "上传图片" },
  "Tài khoản Google": { en: "Google account", ru: "Аккаунт Google", zh: "Google 账户" },
  "tải lên ảnh": { en: "upload image", ru: "загрузить изображение", zh: "上传图片" },
  "Tạo bởi: email": { en: "Created by: email", ru: "Создано: email", zh: "创建者：email" },
  "Tên cột": { en: "Column name", ru: "Название столбца", zh: "列名" },
  "Tên người bán / nhóm": { en: "Seller / group name", ru: "Имя продавца / группы", zh: "卖家 / 群组名称" },
  "thiếu quyền": { en: "missing permission", ru: "недостаточно прав", zh: "缺少权限" },
  "Thời hạn": { en: "Duration", ru: "Срок", zh: "期限" },
  "Tôi đã đọc và đồng ý…": { en: "I have read and agree…", ru: "Я прочитал(а) и согласен(на)…", zh: "我已阅读并同意…" },
  "Trình duyệt của hồ sơ sẽ mở và chạy toàn bộ kịch bản với tham số ở trên. Theo dõi nhật ký bên dưới.": { en: "The profile's browser will open and run the entire script with the parameters above. Watch the logs below.", ru: "Браузер профиля откроется и выполнит весь скрипт с указанными выше параметрами. Следите за журналами ниже.", zh: "配置文件的浏览器将打开并使用上述参数运行整个脚本。请查看下方日志。" },
  "tỷ ₫": { en: "billion ₫", ru: "млрд ₫", zh: "十亿 ₫" },
  "VND/tháng": { en: "VND/month", ru: "VND/месяц", zh: "VND/月" },
  "Vui lòng chọn quy trình nguồn để đăng": { en: "Please select a source workflow to publish", ru: "Пожалуйста, выберите исходный процесс для публикации", zh: "请选择要发布的源流程" },
  "Vui lòng nhập tên hiển thị": { en: "Please enter a display name", ru: "Пожалуйста, введите отображаемое имя", zh: "请输入显示名称" },
  "xác nhận": { en: "confirm", ru: "подтвердить", zh: "确认" },
  "Xoá ảnh": { en: "Delete image", ru: "Удалить изображение", zh: "删除图片" },
  "Xuất Excel thất bại": { en: "Failed to export Excel", ru: "Не удалось экспортировать в Excel", zh: "导出 Excel 失败" },
  "1-8 trên 8": { en: "1-8 of 8", ru: "1-8 из 8", zh: "1-8，共 8" },
  "50-300 Hồ sơ trình duyệt": { en: "50-300 Browser profiles", ru: "50-300 профилей браузера", zh: "50-300 个浏览器配置文件" },
  "Bạn cần nâng cấp gói để sử dụng tính năng": { en: "You need to upgrade your plan to use this feature", ru: "Чтобы использовать эту функцию, необходимо повысить тариф", zh: "您需要升级套餐才能使用此功能" },
  "Bạn đã hết số dư thành viên. Vui lòng nâng cấp gói để mời thêm thành viên mới.": { en: "You have no member slots left. Please upgrade your plan to invite more members.", ru: "У вас закончились слоты участников. Повысьте тариф, чтобы пригласить новых участников.", zh: "您的成员名额已用完。请升级套餐以邀请更多新成员。" },
  "Bắt buộc cập nhật": { en: "Update required", ru: "Требуется обновление", zh: "必须更新" },
  "Các tệp trong bucket S3 sẽ hiển thị ở đây.": { en: "Files in the S3 bucket will appear here.", ru: "Файлы в бакете S3 будут отображаться здесь.", zh: "S3 存储桶中的文件将显示在此处。" },
  "Cập nhật phiên bản": { en: "Update version", ru: "Обновить версию", zh: "更新版本" },
  "Cấu hình quy trình": { en: "Workflow configuration", ru: "Настройка процесса", zh: "流程配置" },
  "Chạy thử thất bại:": { en: "Test run failed:", ru: "Пробный запуск не удался:", zh: "试运行失败：" },
  "Chi tiết kịch bản": { en: "Script details", ru: "Сведения о скрипте", zh: "脚本详情" },
  "Chờ duyệt": { en: "Pending review", ru: "На модерации", zh: "待审核" },
  "Chọn phạm vi lọc": { en: "Select filter scope", ru: "Выберите область фильтра", zh: "选择筛选范围" },
  "Chưa cấu hình tài khoản nhận tiền": { en: "Payment receiving account not configured", ru: "Счёт для приёма платежей не настроен", zh: "尚未配置收款账户" },
  "Chưa có hướng dẫn.": { en: "No instructions yet.", ru: "Инструкций пока нет.", zh: "暂无说明。" },
  "Chưa có lời mời nào": { en: "No invitations yet", ru: "Пока нет приглашений", zh: "暂无邀请" },
  "Chưa có nhật ký/hoạt động": { en: "No logs/activity yet", ru: "Пока нет журнала/активности", zh: "暂无日志/活动" },
  "Chưa có thành viên": { en: "No members yet", ru: "Пока нет участников", zh: "暂无成员" },
  "Chưa kết nối đồng bộ. Hãy kết nối một trong hai nơi sao lưu (S3 / Telegram) trước khi bật.": { en: "Sync not connected. Please connect one of the two backup destinations (S3 / Telegram) before enabling.", ru: "Синхронизация не подключена. Подключите одно из двух мест резервного копирования (S3 / Telegram) перед включением.", zh: "尚未连接同步。请先连接两个备份目标之一（S3 / Telegram）再启用。" },
  "Có cập nhật đang chờ": { en: "An update is pending", ru: "Есть ожидающее обновление", zh: "有待处理的更新" },
  "Bạn đã sử dụng hết số dư tạo hồ sơ là N. Vui lòng nâng cấp gói để tiếp tục.": { en: "You have used up your profile creation balance of N. Please upgrade your plan to continue.", ru: "Вы израсходовали баланс на создание профилей: N. Пожалуйста, обновите тариф, чтобы продолжить.", zh: "您的配置文件创建额度 N 已用完。请升级套餐以继续。" },
  "Đã duyệt": { en: "Approved", ru: "Одобрено", zh: "已审核通过" },
  "Đã gửi kịch bản, đang chờ quản trị viên duyệt": { en: "Script submitted, awaiting administrator approval", ru: "Скрипт отправлен, ожидает одобрения администратора", zh: "脚本已提交，正在等待管理员审核通过" },
  "Đã kết nối S3": { en: "S3 connected", ru: "S3 подключён", zh: "已连接 S3" },
  "Đã ngắt kết nối Telegram": { en: "Telegram disconnected", ru: "Telegram отключён", zh: "已断开 Telegram 连接" },
  "Đã tải kịch bản vào \"Quy trình\" của workspace": { en: "Script loaded into the workspace's \"Workflows\"", ru: "Скрипт загружен в «Процессы» рабочего пространства", zh: "脚本已加载到工作区的“流程”中" },
  "Dán link/ID kênh hoặc NHÓM (t.me/+… , t.me/joinchat/… , @username). Dùng NHÓM để mọi thành viên đều đồng bộ được (kênh chỉ admin đăng được). Để trống sẽ dùng Tin nhắn đã lưu.": { en: "Paste the link/ID of a channel or GROUP (t.me/+… , t.me/joinchat/… , @username). Use a GROUP so all members can sync (only admins can post to a channel). Leave empty to use Saved Messages.", ru: "Вставьте ссылку/ID канала или ГРУППЫ (t.me/+… , t.me/joinchat/… , @username). Используйте ГРУППУ, чтобы все участники могли синхронизироваться (в канале публиковать может только админ). Оставьте пустым, чтобы использовать «Избранное».", zh: "粘贴频道或群组的链接/ID（t.me/+… , t.me/joinchat/… , @username）。使用群组可让所有成员都能同步（频道仅管理员可发布）。留空则使用已保存消息。" },
  "Đang chờ chuyển khoản…": { en: "Awaiting bank transfer…", ru: "Ожидание банковского перевода…", zh: "等待转账中…" },
  "Đang đóng": { en: "Closing", ru: "Закрытие", zh: "正在关闭" },
  "Đăng kịch bản lên chợ": { en: "Publish script to the marketplace", ru: "Опубликовать скрипт в магазине", zh: "将脚本发布到市场" },
  "đang mở ở máy khác": { en: "open on another machine", ru: "открыт на другом устройстве", zh: "正在其他设备上打开" },
  "Đăng nhập Google chưa được cấu hình trên máy chủ (GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET). Bật Google Drive API cho OAuth Client này để đăng nhập.": { en: "Google sign-in is not configured on the server (GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET). Enable the Google Drive API for this OAuth Client to sign in.", ru: "Вход через Google не настроен на сервере (GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET). Включите Google Drive API для этого OAuth-клиента, чтобы войти.", zh: "服务器上尚未配置 Google 登录（GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET）。请为此 OAuth 客户端启用 Google Drive API 以进行登录。" },
  "Đăng nhập Telegram thất bại": { en: "Telegram sign-in failed", ru: "Не удалось войти в Telegram", zh: "Telegram 登录失败" },
  "Đang tải danh sách tệp…": { en: "Loading file list…", ru: "Загрузка списка файлов…", zh: "正在加载文件列表…" },
  "Đây là các dịch vụ lưu trữ an toàn, giá rẻ. Không giới hạn dung lượng hay băng thông và có nhiều nhà cung cấp trên toàn thế giới. Bạn có thể tham khảo các nhà cung cấp sau:": { en: "These are safe, low-cost storage services. Unlimited capacity and bandwidth, with many providers worldwide. You can consider the following providers:", ru: "Это безопасные и недорогие сервисы хранения. Без ограничений по объёму и трафику, с множеством провайдеров по всему миру. Вы можете рассмотреть следующих провайдеров:", zh: "这些是安全、低成本的存储服务。容量和带宽不受限制，并且全球有众多提供商。您可以参考以下提供商：" },
  "ĐÍCH SAO LƯU": { en: "BACKUP DESTINATION", ru: "МЕСТО РЕЗЕРВНОГО КОПИРОВАНИЯ", zh: "备份目标" },
  "Đồng bộ dữ liệu hồ sơ khi mở/đóng": { en: "Sync profile data on open/close", ru: "Синхронизировать данные профиля при открытии/закрытии", zh: "打开/关闭时同步配置文件数据" },
  "Duyệt": { en: "Approve", ru: "Одобрить", zh: "审核通过" },
  "Giá hồ sơ": { en: "Profile price", ru: "Цена профиля", zh: "配置文件价格" },
  "Giữ nguyên quy trình gốc đã đăng.": { en: "Keep the published source workflow unchanged.", ru: "Оставить опубликованный исходный процесс без изменений.", zh: "保持已发布的源流程不变。" },
  "gói giá gốc": { en: "plan at original price", ru: "тариф по базовой цене", zh: "原价套餐" },
  "Gói thuê bao đã hết hạn": { en: "Subscription plan has expired", ru: "Срок действия тарифа истёк", zh: "订阅套餐已过期" },
  "Gợi ý": { en: "Suggestion", ru: "Подсказка", zh: "建议" },
  "Hệ thống sẽ tự động nạp tiền trong vòng 30 giây - 1 phút kể từ khi chuyển khoản.": { en: "The system will automatically top up within 30 seconds - 1 minute after the bank transfer.", ru: "Система автоматически пополнит баланс в течение 30 секунд - 1 минуты после банковского перевода.", zh: "系统将在转账后 30 秒 - 1 分钟内自动充值。" },
  "Hiển thị kết quả": { en: "Show results", ru: "Показать результаты", zh: "显示结果" },
  "Họ tên chủ tài khoản:": { en: "Account holder name:", ru: "Имя владельца счёта:", zh: "账户持有人姓名：" },
  "Hướng dẫn sử dụng (Read Me)...": { en: "User guide (Read Me)...", ru: "Руководство пользователя (Read Me)...", zh: "使用指南（Read Me）…" },
  "Huỷ yêu cầu thất bại": { en: "Failed to cancel the request", ru: "Не удалось отменить запрос", zh: "取消请求失败" },
  "Kết nối S3 thất bại - kiểm tra endpoint, bucket và khoá truy cập": { en: "S3 connection failed - check the endpoint, bucket and access key", ru: "Не удалось подключиться к S3 - проверьте endpoint, бакет и ключ доступа", zh: "S3 连接失败 - 请检查端点、存储桶和访问密钥" },
  "không có đủ quyền hạn": { en: "insufficient permissions", ru: "недостаточно прав", zh: "权限不足" },
  "Không đọc được quy trình đã chọn": { en: "Could not read the selected workflow", ru: "Не удалось прочитать выбранный процесс", zh: "无法读取所选流程" },
  "không gia hạn": { en: "do not renew", ru: "не продлевать", zh: "不续费" },
  "Không kiểm tra được ID.": { en: "Could not verify the ID.", ru: "Не удалось проверить ID.", zh: "无法验证 ID。" },
  "Không tải được danh sách tệp": { en: "Could not load the file list", ru: "Не удалось загрузить список файлов", zh: "无法加载文件列表" },
  "Không tìm thấy nhà phát triển": { en: "Developer not found", ru: "Разработчик не найден", zh: "未找到开发者" },
  "Kịch bản đã bị từ chối nên chưa công khai. Hãy \"Chạy thử\" để kiểm tra lại.": { en: "The script was rejected and is not public yet. Please \"Test run\" to check again.", ru: "Скрипт был отклонён и пока не опубликован. Выполните «Пробный запуск», чтобы проверить снова.", zh: "脚本已被拒绝，因此尚未公开。请“试运行”以重新检查。" },
  "Kịch bản này chưa có thông tin nhà phát triển": { en: "This script has no developer information yet", ru: "У этого скрипта пока нет информации о разработчике", zh: "此脚本尚无开发者信息" },
  "Lượt tải": { en: "Downloads", ru: "Загрузки", zh: "下载次数" },
  "Mã hóa": { en: "Encryption", ru: "Шифрование", zh: "加密" },
  "Mã xác thực": { en: "Verification code", ru: "Код подтверждения", zh: "验证码" },
  "Mở mục Nâng cấp gói ở thanh bên để gia hạn.": { en: "Open the Upgrade plan section in the sidebar to renew.", ru: "Откройте раздел «Повысить тариф» на боковой панели, чтобы продлить.", zh: "在侧边栏打开“升级套餐”部分以续费。" },
  "Mở Telegram trên điện thoại của bạn.": { en: "Open Telegram on your phone.", ru: "Откройте Telegram на телефоне.", zh: "在您的手机上打开 Telegram。" },
  "Mua gói": { en: "Buy plan", ru: "Купить тариф", zh: "购买套餐" },
  "Mua thất bại": { en: "Purchase failed", ru: "Не удалось совершить покупку", zh: "购买失败" },
  "Nâng cấp ngay": { en: "Upgrade now", ru: "Повысить тариф сейчас", zh: "立即升级" },
  "Nền tảng": { en: "Platform", ru: "Платформа", zh: "平台" },
  "Ngắt kết nối thất bại": { en: "Disconnection failed", ru: "Не удалось отключить", zh: "断开连接失败" },
  "Người bán": { en: "Seller", ru: "Продавец", zh: "卖家" },
  "Nhà phát triển:": { en: "Developer:", ru: "Разработчик:", zh: "开发者：" },
  "Nhập lý do để nhà phát triển biết cần chỉnh sửa gì…": { en: "Enter a reason so the developer knows what to fix…", ru: "Укажите причину, чтобы разработчик знал, что нужно исправить…", zh: "输入原因，让开发者知道需要修改什么…" },
  "Nội dung chuyển khoản:": { en: "Transfer description:", ru: "Назначение перевода:", zh: "转账备注：" },
  "Phiên bản bạn đang dùng không còn được hỗ trợ. Vui lòng cập nhật để tiếp tục sử dụng.": { en: "The version you are using is no longer supported. Please update to continue using it.", ru: "Используемая вами версия больше не поддерживается. Обновите её, чтобы продолжить работу.", zh: "您正在使用的版本已不再受支持。请更新以继续使用。" },
  "Phiên bản trình duyệt": { en: "Browser version", ru: "Версия браузера", zh: "浏览器版本" },
  "Quảng cáo": { en: "Advertising", ru: "Реклама", zh: "广告" },
  "Quét mã QR hoặc chuyển khoản theo cú pháp": { en: "Scan the QR code or make a bank transfer following the syntax", ru: "Отсканируйте QR-код или сделайте банковский перевод по указанному шаблону", zh: "扫描 QR 码或按语法转账" },
  "Quy trình nguồn": { en: "Source workflow", ru: "Исходный процесс", zh: "源流程" },
  "số dòng mỗi trang": { en: "rows per page", ru: "строк на странице", zh: "每页行数" },
  "Số dư ví workspace không đủ. Vui lòng nạp thêm ở trang Thanh Toán.": { en: "Insufficient workspace wallet balance. Please top up on the Payment page.", ru: "Недостаточно средств на балансе кошелька рабочего пространства. Пополните его на странице «Оплата».", zh: "工作区钱包余额不足。请在“支付”页面充值。" },
  "Số tài khoản:": { en: "Account number:", ru: "Номер счёта:", zh: "账号：" },
  "Tải bản cập nhật thất bại": { en: "Failed to download the update", ru: "Не удалось загрузить обновление", zh: "下载更新失败" },
  "Tài khoản Google nhận các gói sao lưu.": { en: "Google account that receives the backup packages.", ru: "Аккаунт Google, который получает пакеты резервных копий.", zh: "接收备份包的 Google 账户。" },
  "Tải lên ảnh": { en: "Upload image", ru: "Загрузить изображение", zh: "上传图片" },
  "Tạo hàng loạt thất bại": { en: "Bulk creation failed", ru: "Не удалось выполнить массовое создание", zh: "批量创建失败" },
  "Tên gốc": { en: "Original name", ru: "Исходное имя", zh: "原始名称" },
  "Tệp sao lưu": { en: "Backup file", ru: "Файл резервной копии", zh: "备份文件" },
  "thiếu quyền hạn": { en: "missing permissions", ru: "недостаточно прав", zh: "缺少权限" },
  "Thử lại": { en: "Retry", ru: "Повторить", zh: "重试" },
  "Tổng thanh toán": { en: "Total payment", ru: "Итого к оплате", zh: "支付总额" },
  "Trượt để chọn số lượng profile": { en: "Slide to select the number of profiles", ru: "Перетащите, чтобы выбрать количество профилей", zh: "滑动以选择配置文件数量" },
  "Vào Cài đặt → Thiết bị → Liên kết thiết bị.": { en: "Go to Settings → Devices → Link device.", ru: "Перейдите в «Настройки» → «Устройства» → «Привязать устройство».", zh: "进入 设置 → 设备 → 关联设备。" },
  "Vô hạn": { en: "Unlimited", ru: "Без ограничений", zh: "无限" },
  "Vui lòng gia hạn để tiếp tục sử dụng để tránh bị gián đoạn": { en: "Please renew to continue using it and avoid interruption", ru: "Продлите тариф, чтобы продолжить использование и избежать перерыва", zh: "请续费以继续使用，避免中断" },
  "Vui lòng nhập tên kịch bản": { en: "Please enter a script name", ru: "Введите имя скрипта", zh: "请输入脚本名称" },
  "Xác nhận mua gói": { en: "Confirm plan purchase", ru: "Подтвердить покупку тарифа", zh: "确认购买套餐" },
  "Xóa ảnh": { en: "Delete image", ru: "Удалить изображение", zh: "删除图片" },


  // ── Chuỗi động tham số hóa (tf) 2026-07-19 ────────────────────────────────
  " · còn {0} ngày": { en: " · {0} days left", ru: " · осталось дней: {0}", zh: " · 剩余 {0} 天" },
  " (giảm {0}%)": { en: " (-{0}%)", ru: " (-{0}%)", zh: "（减 {0}%）" },
  "- Kết thúc sau {0}s -": { en: "- Ends in {0}s -", ru: "- Завершение через {0} с -", zh: "- {0}s 后结束 -" },
  ", bỏ qua {0}": { en: ", skipped {0}", ru: ", пропущено: {0}", zh: "，跳过 {0}" },
  "({0} tháng)": { en: "({0} months)", ru: "({0} мес.)", zh: "（{0} 个月）" },
  "(mua thêm {0} hồ sơ)": { en: "(buy {0} more profiles)", ru: "(докупить профилей: {0})", zh: "（加购 {0} 个配置文件）" },
  "(mua thêm {0})": { en: "(buy {0} more)", ru: "(докупить: {0})", zh: "（加购 {0}）" },
  "{0} – {1} hồ sơ": { en: "{0} – {1} profiles", ru: "{0} – {1} профилей", zh: "{0} – {1} 个配置文件" },
  "{0} (đã hết hạn)": { en: "{0} (expired)", ru: "{0} (истёк)", zh: "{0}（已过期）" },
  "{0} + {1} ngày": { en: "{0} + {1} days", ru: "{0} + {1} дн.", zh: "{0} + {1} 天" },
  "{0} chia sẻ {1} hồ sơ với bạn": { en: "{0} shared {1} profiles with you", ru: "{0} поделился(-ась) с вами профилями: {1}", zh: "{0} 与您分享了 {1} 个配置文件" },
  "{0} chia sẻ hồ sơ “{1}” với bạn": { en: "{0} shared the profile “{1}” with you", ru: "{0} поделился(-ась) с вами профилем «{1}»", zh: "{0} 与您分享了配置文件“{1}”" },
  "{0} đã chia sẻ hồ sơ này với bạn": { en: "{0} shared this profile with you", ru: "{0} поделился(-ась) с вами этим профилем", zh: "{0} 与您分享了此配置文件" },
  "{0} đã mời bạn tham gia nhóm": { en: "{0} invited you to join the group", ru: "{0} пригласил(-а) вас в группу", zh: "{0} 邀请您加入群组" },
  "{0} giây": { en: "{0} s", ru: "{0} с", zh: "{0} 秒" },
  "{0} hồ sơ không mở được - {1}": { en: "{0} profiles could not be opened - {1}", ru: "Не удалось открыть профилей: {0} - {1}", zh: "{0} 个配置文件无法打开 - {1}" },
  "{0} kịch bản": { en: "{0} scripts", ru: "Скриптов: {0}", zh: "{0} 个脚本" },
  "{0} kịch bản đã chọn": { en: "{0} scripts selected", ru: "Выбрано скриптов: {0}", zh: "已选择 {0} 个脚本" },
  "{0} lượt tải": { en: "{0} downloads", ru: "Загрузок: {0}", zh: "{0} 次下载" },
  "{0} mời bạn vào “{1}”": { en: "{0} invited you to “{1}”", ru: "{0} пригласил(-а) вас в «{1}»", zh: "{0} 邀请您加入“{1}”" },
  "{0} Năm Tháng {1}": { en: "{0} - Month {1}", ru: "{0}, месяц {1}", zh: "{0}年{1}月" },
  "{0} năm trước": { en: "{0} years ago", ru: "{0} г. назад", zh: "{0} 年前" },
  "{0} ngày (không gia hạn)": { en: "{0} days (no renewal)", ru: "{0} дн. (без продления)", zh: "{0} 天（不续期）" },
  "{0} ngày trước": { en: "{0} days ago", ru: "{0} дн. назад", zh: "{0} 天前" },
  "{0} Nhân": { en: "{0} cores", ru: "{0} ядер", zh: "{0} 核" },
  "{0} phút {1} giây": { en: "{0} min {1} s", ru: "{0} мин {1} с", zh: "{0} 分 {1} 秒" },
  "{0} tệp": { en: "{0} files", ru: "Файлов: {0}", zh: "{0} 个文件" },
  "{0} tháng {1} {2}": { en: "{0} {1} {2}", ru: "{0} {1} {2}", zh: "{2}年{1}{0}日" },
  "{0} tháng trước": { en: "{0} months ago", ru: "{0} мес. назад", zh: "{0} 个月前" },
  "{0} thành công": { en: "{0} succeeded", ru: "{0}: успешно", zh: "{0}成功" },
  "{0} thất bại": { en: "{0} failed", ru: "{0}: ошибка", zh: "{0}失败" },
  "{0}-{1} trên {2}": { en: "{0}-{1} of {2}", ru: "{0}-{1} из {2}", zh: "{0}-{1}，共 {2}" },
  "{0}+ hồ sơ": { en: "{0}+ profiles", ru: "{0}+ профилей", zh: "{0}+ 个配置文件" },
  "Bạn có chắc muốn xóa thành viên \"{0}\" khỏi nhóm?": { en: "Are you sure you want to remove the member \"{0}\" from the group?", ru: "Вы точно хотите удалить участника \"{0}\" из группы?", zh: "确定要将成员“{0}”从群组中移除吗？" },
  "Bạn đã {0} thành công. Thông tin gói đã được cập nhật.": { en: "You have {0} successfully. Your plan information has been updated.", ru: "Вы успешно выполнили: {0}. Информация о плане обновлена.", zh: "您已成功{0}。套餐信息已更新。" },
  "Bạn đã nạp thành công {0} vào ví. Số dư đã được cập nhật.": { en: "You have successfully topped up {0} to your wallet. The balance has been updated.", ru: "Вы успешно пополнили кошелёк на {0}. Баланс обновлён.", zh: "您已成功向钱包充值 {0}。余额已更新。" },
  "Báo cáo": { en: "Report", ru: "Пожаловаться", zh: "举报" },
  "Báo cáo \"{0}\" vì nội dung không phù hợp hoặc lỗi? Đội ngũ sẽ xem xét.": { en: "Report \"{0}\" for inappropriate content or a bug? Our team will review it.", ru: "Пожаловаться на \"{0}\" из-за неприемлемого содержания или ошибки? Наша команда рассмотрит обращение.", zh: "举报“{0}”存在不当内容或错误？我们的团队将进行审核。" },
  // NGỮ PHÁP NGA: "на {1} профилях" / "{2} потоков" / "все {0} профилей" SAI khi số = 1
  // (на 1 профилях, 1 потоков, все 1 профилей). Đảo sang dạng "профилей: {N}" - bất biến
  // với mọi giá trị. Đừng viết lại thành "{N} профилей".
  "Bắt đầu \"{0}\" trên {1} hồ sơ ({2} luồng)": { en: "Start \"{0}\" on {1} profiles ({2} threads)", ru: "Запуск \"{0}\" - профилей: {1}, потоков: {2}", zh: "在 {1} 个配置文件上启动“{0}”（{2} 个线程）" },
  "Bỏ toàn bộ {0} hồ sơ ra khỏi nhóm “{1}” về “Chưa chia nhóm”? Hồ sơ KHÔNG bị xoá, nhóm vẫn được giữ lại.": { en: "Remove all {0} profiles from the group “{1}” to “Ungrouped”? The profiles will NOT be deleted, and the group will be kept.", ru: "Убрать все профили ({0}) из группы «{1}» в «Без группы»? Профили НЕ будут удалены, группа сохранится.", zh: "将全部 {0} 个配置文件从群组“{1}”移至“未分组”？配置文件不会被删除，群组仍将保留。" },
  "cập nhật {0}": { en: "update {0}", ru: "обновить {0}", zh: "更新 {0}" },
  "Cập nhật {0}": { en: "Update {0}", ru: "Обновить {0}", zh: "更新 {0}" },
  "Chế độ thử nghiệm (máy chủ chưa cấu hình email): mã của bạn là {0}": { en: "Test mode (email not configured on the server): your code is {0}", ru: "Тестовый режим (email не настроен на сервере): ваш код - {0}", zh: "测试模式（服务器尚未配置邮件）：您的验证码为 {0}" },
  "Chi tiết lần chạy · {0}": { en: "Run details · {0}", ru: "Сведения о запуске · {0}", zh: "运行详情 · {0}" },
  "Chia sẻ {0} hồ sơ đã chọn qua email": { en: "Share {0} selected profiles via email", ru: "Поделиться выбранными профилями ({0}) по email", zh: "通过邮件分享所选的 {0} 个配置文件" },
  "Chia sẻ hồ sơ \"{0}\" qua email": { en: "Share the profile \"{0}\" via email", ru: "Поделиться профилем \"{0}\" по email", zh: "通过邮件分享配置文件“{0}”" },
  "Đã bật đồng bộ thao tác: master + {0} slave": { en: "Action sync enabled: master + {0} slaves", ru: "Синхронизация действий включена: master + {0} slave", zh: "已开启操作同步：master + {0} 个 slave" },
  "Đã bật đồng bộ: master + {0} slave": { en: "Sync enabled: master + {0} slaves", ru: "Синхронизация включена: master + {0} slave", zh: "已开启同步：master + {0} 个 slave" },
  "Đã bỏ {0} hồ sơ ra khỏi nhóm “{1}”": { en: "Removed {0} profiles from the group “{1}”", ru: "Убрано профилей из группы «{1}»: {0}", zh: "已将 {0} 个配置文件从群组“{1}”中移除" },
  "Đã chia sẻ {0} hồ sơ": { en: "Shared {0} profiles", ru: "Профилей передано: {0}", zh: "已分享 {0} 个配置文件" },
  "Đã chọn {0}": { en: "{0} selected", ru: "Выбрано: {0}", zh: "已选择 {0}" },
  "Đã chọn {0}/{1}": { en: "{0}/{1} selected", ru: "Выбрано: {0}/{1}", zh: "已选择 {0}/{1}" },
  "Đã chuyển sang “{0}”": { en: "Switched to “{0}”", ru: "Переключено на «{0}»", zh: "已切换到“{0}”" },
  "Đã dán vào {0} cửa sổ": { en: "Pasted into {0} windows", ru: "Вставлено в окон: {0}", zh: "已粘贴到 {0} 个窗口" },
  "Đã đồng nhất kích cỡ {0} cửa sổ": { en: "Unified the size of {0} windows", ru: "Размер выровнен для окон: {0}", zh: "已统一 {0} 个窗口的大小" },
  "Đã dừng nhiệm vụ \"{0}\"": { en: "Stopped the task \"{0}\"", ru: "Задача \"{0}\" остановлена", zh: "已停止任务“{0}”" },
  "Đã duyệt {0} kịch bản": { en: "Approved {0} scripts", ru: "Одобрено скриптов: {0}", zh: "已批准 {0} 个脚本" },
  "Đã gõ vào {0} cửa sổ": { en: "Typed into {0} windows", ru: "Введено в окон: {0}", zh: "已在 {0} 个窗口中输入" },
  "Đã hiện {0} cửa sổ": { en: "Showed {0} windows", ru: "Показано окон: {0}", zh: "已显示 {0} 个窗口" },
  "Đã lên lịch \"{0}\"": { en: "Scheduled \"{0}\"", ru: "Запланировано: \"{0}\"", zh: "已计划“{0}”" },
  "Đã lên lịch nhiệm vụ \"{0}\"": { en: "Scheduled the task \"{0}\"", ru: "Задача \"{0}\" запланирована", zh: "已计划任务“{0}”" },
  "Đã nhận quyền {0} hồ sơ": { en: "Received access to {0} profiles", ru: "Получен доступ к профилям: {0}", zh: "已获得 {0} 个配置文件的权限" },
  "Đã nhận quyền truy cập hồ sơ “{0}”": { en: "Received access to the profile “{0}”", ru: "Получен доступ к профилю «{0}»", zh: "已获得配置文件“{0}”的访问权限" },
  "Đã sắp xếp {0} cửa sổ": { en: "Arranged {0} windows", ru: "Упорядочено окон: {0}", zh: "已排列 {0} 个窗口" },
  "Đã tạo {0} hồ sơ": { en: "Created {0} profiles", ru: "Создано профилей: {0}", zh: "已创建 {0} 个配置文件" },
  "Đã tạo nhiệm vụ \"{0}\"": { en: "Created the task \"{0}\"", ru: "Задача \"{0}\" создана", zh: "已创建任务“{0}”" },
  "Đã tham gia “{0}”": { en: "Joined “{0}”", ru: "Вы присоединились к «{0}»", zh: "已加入“{0}”" },
  "Đã tham gia {0}": { en: "Joined {0}", ru: "Вы присоединились к {0}", zh: "已加入 {0}" },
  "Tham gia {0}": { en: "Joined {0}", ru: "Присоединился {0}", zh: "加入于 {0}" },
  "không rõ": { en: "unknown", ru: "неизвестно", zh: "未知" },
  "Đã từ chối {0} kịch bản": { en: "Rejected {0} scripts", ru: "Отклонено скриптов: {0}", zh: "已拒绝 {0} 个脚本" },
  "Đã xóa {0} proxy": { en: "Deleted {0} proxy", ru: "Удалено proxy: {0}", zh: "已删除 {0} 个 proxy" },
  "Đã xóa văn bản ở {0} cửa sổ": { en: "Cleared text in {0} windows", ru: "Текст очищен в окнах: {0}", zh: "已清除 {0} 个窗口中的文本" },
  "Đồng bộ thao tác({0})": { en: "Action sync ({0})", ru: "Синхронизация действий ({0})", zh: "操作同步（{0}）" },
  "Dừng đồng bộ ({0}){1}": { en: "Stop sync ({0}){1}", ru: "Остановить синхронизацию ({0}){1}", zh: "停止同步（{0}）{1}" },
  "Gỡ \"{0}\" khỏi chợ? Người dùng sẽ không còn thấy kịch bản này.": { en: "Remove \"{0}\" from the marketplace? Users will no longer see this script.", ru: "Удалить \"{0}\" из маркетплейса? Пользователи больше не увидят этот скрипт.", zh: "从市场中下架“{0}”？用户将不再看到此脚本。" },
  "Gói Free chỉ tạo tối đa {0} quy trình": { en: "The Free plan can create at most {0} workflows", ru: "План Free позволяет создать не более {0} рабочих процессов", zh: "免费套餐最多只能创建 {0} 个工作流" },
  "Gói hiện tại: {0}": { en: "Current plan: {0}", ru: "Текущий план: {0}", zh: "当前套餐：{0}" },
  "gửi {0}": { en: "send {0}", ru: "отправить {0}", zh: "发送 {0}" },
  "Hãy nhập {0}.": { en: "Please enter {0}.", ru: "Введите {0}.", zh: "请输入 {0}。" },
  "Hồ sơ chạy": { en: "Running profiles", ru: "Активные профили", zh: "运行中的配置文件" },
  "Hoàn tất nhiệm vụ \"{0}\"": { en: "Completed the task \"{0}\"", ru: "Задача \"{0}\" завершена", zh: "已完成任务“{0}”" },
  "không tải được {0}": { en: "failed to load {0}", ru: "не удалось загрузить {0}", zh: "无法加载 {0}" },
  "Lý do bị từ chối: {0}": { en: "Reason for rejection: {0}", ru: "Причина отклонения: {0}", zh: "拒绝原因：{0}" },
  "Mua \"{0}\" với giá {1}? Phí sẽ trừ vào ví của workspace.": { en: "Buy \"{0}\" for {1}? The fee will be deducted from the workspace wallet.", ru: "Купить \"{0}\" за {1}? Сумма будет списана с кошелька workspace.", zh: "以 {1} 购买“{0}”？费用将从 workspace 的钱包中扣除。" },
  "Người viết: {0}": { en: "Author: {0}", ru: "Автор: {0}", zh: "作者：{0}" },
  "Nhóm văn bản {0}": { en: "Text group {0}", ru: "Группа текста {0}", zh: "文本组 {0}" },
  "Nội dung {0}:": { en: "Content {0}:", ru: "Содержимое {0}:", zh: "内容 {0}：" },
  "Phiên bản {0}": { en: "Version {0}", ru: "Версия {0}", zh: "版本 {0}" },
  "Phiên bản {0} đã sẵn sàng": { en: "Version {0} is ready", ru: "Версия {0} готова", zh: "版本 {0} 已就绪" },
  "Phiên bản {0} đã sẵn sàng!": { en: "Version {0} is ready!", ru: "Версия {0} готова!", zh: "版本 {0} 已就绪！" },
  "Sẽ đồng bộ vào: {0}": { en: "Will sync into: {0}", ru: "Будет синхронизировано в: {0}", zh: "将同步到：{0}" },
  "Số dư ví không đủ để {0}. Bạn cần nạp thêm để tiếp tục.": { en: "Insufficient wallet balance to {0}. You need to top up to continue.", ru: "Недостаточно средств на кошельке, чтобы {0}. Пополните баланс, чтобы продолжить.", zh: "钱包余额不足以{0}。您需要充值才能继续。" },
  "Tham số đầu vào": { en: "Input parameters", ru: "Входные параметры", zh: "输入参数" },
  "Tháng {0}, {1}": { en: "Month {0}, {1}", ru: "Месяц {0}, {1}", zh: "{1}年{0}月" },
  "Tiết kiệm tới {0}%": { en: "Save up to {0}%", ru: "Экономия до {0}%", zh: "最高节省 {0}%" },
  "Tính năng \"{0}\" đang phát triển": { en: "The feature \"{0}\" is under development", ru: "Функция \"{0}\" в разработке", zh: "功能“{0}”正在开发中" },
  "Tính năng {0} đang phát triển": { en: "The feature {0} is under development", ru: "Функция {0} в разработке", zh: "功能 {0} 正在开发中" },
  "Tổng = số hồ sơ × đơn giá hiện tại ({0}).": { en: "Total = number of profiles × current unit price ({0}).", ru: "Итого = число профилей × текущая цена за единицу ({0}).", zh: "总计 = 配置文件数量 × 当前单价（{0}）。" },
  "Tổng thời gian chạy: {0}": { en: "Total run time: {0}", ru: "Общее время выполнения: {0}", zh: "总运行时长：{0}" },
  "Từ chối {0} kịch bản": { en: "Reject {0} scripts", ru: "Отклонить скриптов: {0}", zh: "拒绝 {0} 个脚本" },
  "Xoá {0}?": { en: "Delete {0}?", ru: "Удалить {0}?", zh: "删除 {0}？" },
  "Xóa {0}?": { en: "Delete {0}?", ru: "Удалить {0}?", zh: "删除 {0}？" },
  "Xóa thẻ \"{0}\" khỏi tất cả hồ sơ?": { en: "Remove the tag \"{0}\" from all profiles?", ru: "Удалить тег \"{0}\" со всех профилей?", zh: "从所有配置文件中移除标签“{0}”？" },
  "Xóa toàn bộ bộ nhớ đệm của hồ sơ “{0}”?": { en: "Clear all cache of the profile “{0}”?", ru: "Очистить весь кэш профиля «{0}»?", zh: "清除配置文件“{0}”的所有缓存？" },
  "Xóa toàn bộ cookie của hồ sơ “{0}”? Bạn sẽ phải đăng nhập lại các trang.": { en: "Clear all cookies of the profile “{0}”? You will have to log in to the sites again.", ru: "Очистить все cookie профиля «{0}»? Придётся заново войти на сайтах.", zh: "清除配置文件“{0}”的所有 cookie？您将需要重新登录各网站。" },

  // ── Nhân trình duyệt (kernels.js, profile_create.js, settings.js) ─────────
  "Tải trình duyệt {0} {1}": { en: "Download the {0} {1} browser", ru: "Загрузка браузера {0} {1}", zh: "下载 {0} {1} 浏览器" },
  "Dung lượng gói ~ {0}": { en: "Package size ~ {0}", ru: "Размер пакета ~ {0}", zh: "安装包大小约 {0}" },
  "Lỗi": { en: "Error", ru: "Ошибка", zh: "错误" },
  "Tải thất bại": { en: "Download failed", ru: "Не удалось загрузить", zh: "下载失败" },
  "Đang kiểm tra toàn vẹn (SHA256)…": { en: "Verifying integrity (SHA256)…", ru: "Проверка целостности (SHA256)…", zh: "正在校验完整性（SHA256）…" },
  "Giải nén": { en: "Extracting", ru: "Распаковка", zh: "解压" },
  "Đang giải nén trình duyệt…": { en: "Extracting the browser…", ru: "Распаковка браузера…", zh: "正在解压浏览器…" },
  "Đã cài trình duyệt {0} {1}": { en: "Installed the {0} {1} browser", ru: "Браузер {0} {1} установлен", zh: "已安装 {0} {1} 浏览器" },
  "Tải lại danh sách từ máy chủ": { en: "Reload the list from the server", ru: "Перезагрузить список с сервера", zh: "从服务器重新加载列表" },
  "bản {0}": { en: "version {0}", ru: "версия {0}", zh: "版本 {0}" },
  "khuyến nghị": { en: "recommended", ru: "рекомендуется", zh: "推荐" },
  "Đang dùng": { en: "In use", ru: "Используется", zh: "使用中" },
  "Đã cài": { en: "Installed", ru: "Установлено", zh: "已安装" },
  "Chưa cài": { en: "Not installed", ru: "Не установлено", zh: "未安装" },
  "Chỉ có ở máy": { en: "Local only", ru: "Только локально", zh: "仅本机" },
  "Tải": { en: "Download", ru: "Загрузить", zh: "下载" },
  "Tải & cài nhân này": { en: "Download & install this kernel", ru: "Загрузить и установить это ядро", zh: "下载并安装该内核" },
  "Không có nguồn tải": { en: "No download source", ru: "Нет источника загрузки", zh: "无下载来源" },
  "Dùng": { en: "Use", ru: "Выбрать", zh: "使用" },
  "Đặt làm nhân đang dùng": { en: "Set as the kernel in use", ru: "Сделать текущим ядром", zh: "设为当前使用的内核" },
  "Đang dùng {0} {1}": { en: "Now using {0} {1}", ru: "Сейчас используется {0} {1}", zh: "正在使用 {0} {1}" },
  "Không đặt được nhân đang dùng": { en: "Could not set the kernel in use", ru: "Не удалось назначить текущее ядро", zh: "无法设置当前使用的内核" },
  "Gỡ nhân (đang dùng)": { en: "Uninstall kernel (in use)", ru: "Удалить ядро (используется)", zh: "卸载内核（使用中）" },
  "Gỡ nhân": { en: "Uninstall kernel", ru: "Удалить ядро", zh: "卸载内核" },
  "Gỡ nhân trình duyệt": { en: "Uninstall browser kernel", ru: "Удаление ядра браузера", zh: "卸载浏览器内核" },
  "Gỡ {0} {1} khỏi máy? Có thể tải lại sau.": { en: "Remove {0} {1} from this machine? You can download it again later.", ru: "Удалить {0} {1} с этого компьютера? Позже его можно загрузить снова.", zh: "从本机移除 {0} {1}？之后仍可重新下载。" },
  "Đã gỡ nhân": { en: "Kernel uninstalled", ru: "Ядро удалено", zh: "已卸载内核" },
  "Không gỡ được nhân": { en: "Could not uninstall the kernel", ru: "Не удалось удалить ядро", zh: "无法卸载内核" },
  "Đang tải danh sách…": { en: "Loading the list…", ru: "Загрузка списка…", zh: "正在加载列表…" },
  "Không lấy được danh sách nhân. Kiểm tra kết nối rồi Làm mới.": { en: "Could not fetch the kernel list. Check your connection, then click Refresh.", ru: "Не удалось получить список ядер. Проверьте подключение и нажмите «Обновить».", zh: "无法获取内核列表。请检查网络连接后点击“刷新”。" },
  "Chưa có nhân {0} nào trên máy chủ.": { en: "There are no {0} kernels on the server yet.", ru: "На сервере пока нет ни одного ядра {0}.", zh: "服务器上暂无任何 {0} 内核。" },
  "Bạn chưa cài nhân {0} nào - bấm \"Tải\" ở bản mới nhất để bắt đầu.": { en: "You have not installed any {0} kernel yet - click \"Download\" on the latest version to get started.", ru: "У вас не установлено ни одного ядра {0} - нажмите «Загрузить» у последней версии, чтобы начать.", zh: "您尚未安装任何 {0} 内核 -- 请在最新版本上点击“下载”开始。" },
  "Chưa có nhân trình duyệt khả dụng để tải. Vui lòng liên hệ quản trị viên.": { en: "No browser kernel is available for download. Please contact the administrator.", ru: "Нет доступных для загрузки ядер браузера. Обратитесь к администратору.", zh: "暂无可下载的浏览器内核。请联系管理员。" },
  "Đang tải danh sách nhân…": { en: "Loading the kernel list…", ru: "Загрузка списка ядер…", zh: "正在加载内核列表…" },
  "Không tải được nhân": { en: "Could not download the kernel", ru: "Не удалось загрузить ядро", zh: "无法下载内核" },
  "Nhân Chromium {0} hiện không có sẵn trên máy chủ. Vui lòng liên hệ quản trị viên hoặc chọn phiên bản khác.": { en: "Chromium kernel {0} is not currently available on the server. Please contact the administrator or choose another version.", ru: "Ядро Chromium {0} сейчас недоступно на сервере. Обратитесь к администратору или выберите другую версию.", zh: "服务器上当前没有 Chromium {0} 内核。请联系管理员或选择其他版本。" },
  "Không có nhân khả dụng": { en: "No kernel available", ru: "Нет доступных ядер", zh: "无可用内核" },
  "Đặt lại User-Agent (Tất cả)": { en: "Reset User-Agent (All)", ru: "Сбросить User-Agent (Все)", zh: "重置 User-Agent（全部）" },
  "Đang test bằng nhân Vendor cục bộ": { en: "Testing with the local Vendor kernel", ru: "Тестирование на локальном ядре Vendor", zh: "正在使用本地 Vendor 内核进行测试" },
  "Dùng nhân tải từ Storage": { en: "Using the kernel downloaded from Storage", ru: "Используется ядро, загруженное из Storage", zh: "使用从 Storage 下载的内核" },
  "Không lưu được lựa chọn": { en: "Could not save the choice", ru: "Не удалось сохранить выбор", zh: "无法保存所选项" },
  "Nguồn nhân trình duyệt": { en: "Browser kernel source", ru: "Источник ядра браузера", zh: "浏览器内核来源" },
  "Vendor: chạy Chromium cục bộ để test trước khi up nhân lên web admin. Storage: chạy nhân tải về (mặc định).": { en: "Vendor: run the local Chromium to test before uploading a kernel to the admin site. Storage: run the downloaded kernel (default).", ru: "Vendor: запуск локального Chromium для тестирования до загрузки ядра в веб-админку. Storage: запуск загруженного ядра (по умолчанию).", zh: "Vendor：运行本地 Chromium，以便在将内核上传到管理后台之前进行测试。Storage：运行已下载的内核（默认）。" },

  // ── Điều kiện trong quy trình (node-catalog.js, automation.js) ────────────
  "A khác rỗng và đã được gán.": { en: "A is not empty and has been assigned a value.", ru: "A не пустое и ему присвоено значение.", zh: "A 不为空且已被赋值。" },
  "A rỗng hoặc chưa được gán.": { en: "A is empty or has not been assigned a value.", ru: "A пустое или ему не присвоено значение.", zh: "A 为空或尚未被赋值。" },
  "A == B. Hai vế đều là số thì so theo số, còn lại so chuỗi (phân biệt HOA/thường).": { en: "A == B. If both sides are numbers they are compared as numbers, otherwise as strings (case-sensitive).", ru: "A == B. Если обе стороны - числа, сравнение числовое, иначе строковое (с учётом регистра).", zh: "A == B。两侧均为数字时按数字比较，否则按字符串比较（区分大小写）。" },
  "A.includes(B) - A CHỨA B. VD A = https://www.facebook.com/, B = face → đúng.": { en: "A.includes(B) - A CONTAINS B. E.g. A = https://www.facebook.com/, B = face → true.", ru: "A.includes(B) - A СОДЕРЖИТ B. Например: A = https://www.facebook.com/, B = face → истина.", zh: "A.includes(B) -- A 包含 B。例如 A = https://www.facebook.com/，B = face → 成立。" },
  "!A.includes(B) - A không chứa B.": { en: "!A.includes(B) - A does not contain B.", ru: "!A.includes(B) - A не содержит B.", zh: "!A.includes(B) -- A 不包含 B。" },
  "A > B. Ép về SỐ; vế nào không phải số thì luôn sai.": { en: "A > B. Both sides are coerced to NUMBERS; if either side is not a number the result is always false.", ru: "A > B. Обе стороны приводятся к ЧИСЛУ; если хотя бы одна не число, результат всегда ложь.", zh: "A > B。两侧均转换为数字；任一侧不是数字时结果恒为否。" },
  "A >= B. Ép về SỐ; vế nào không phải số thì luôn sai.": { en: "A >= B. Both sides are coerced to NUMBERS; if either side is not a number the result is always false.", ru: "A >= B. Обе стороны приводятся к ЧИСЛУ; если хотя бы одна не число, результат всегда ложь.", zh: "A >= B。两侧均转换为数字；任一侧不是数字时结果恒为否。" },
  "A < B. Ép về SỐ; vế nào không phải số thì luôn sai.": { en: "A < B. Both sides are coerced to NUMBERS; if either side is not a number the result is always false.", ru: "A < B. Обе стороны приводятся к ЧИСЛУ; если хотя бы одна не число, результат всегда ложь.", zh: "A < B。两侧均转换为数字；任一侧不是数字时结果恒为否。" },
  "A <= B. Ép về SỐ; vế nào không phải số thì luôn sai.": { en: "A <= B. Both sides are coerced to NUMBERS; if either side is not a number the result is always false.", ru: "A <= B. Обе стороны приводятся к ЧИСЛУ; если хотя бы одна не число, результат всегда ложь.", zh: "A <= B。两侧均转换为数字；任一侧不是数字时结果恒为否。" },
  "[B].includes(A) - B là DANH SÁCH (ngăn bằng dấu phẩy hoặc xuống dòng), A phải khớp NGUYÊN một mục. Muốn \"A chứa B\" thì dùng includes.": { en: "[B].includes(A) - B is a LIST (separated by commas or line breaks) and A must match a WHOLE item. For \"A contains B\", use includes instead.", ru: "[B].includes(A) - B это СПИСОК (через запятую или перенос строки), а A должно совпадать с элементом ЦЕЛИКОМ. Если нужно «A содержит B», используйте includes.", zh: "[B].includes(A) -- B 是列表（用逗号或换行分隔），A 必须与其中某一项完全相同。若需要“A 包含 B”，请改用 includes。" },
  "A không khớp mục nào trong danh sách B.": { en: "A does not match any item in list B.", ru: "A не совпадает ни с одним элементом списка B.", zh: "A 与列表 B 中的任何一项都不匹配。" },
  "Điều kiện lặp": { en: "Loop condition", ru: "Условие цикла", zh: "循环条件" },
  "Còn thỏa mãn thì còn lặp tiếp.": { en: "Keeps looping as long as the condition holds.", ru: "Цикл продолжается, пока условие выполняется.", zh: "条件成立时将持续循环。" },
  "Thỏa mãn → đi nhánh \"if\", không thỏa mãn → đi nhánh \"else\".": { en: "Satisfied → take the \"if\" branch; not satisfied → take the \"else\" branch.", ru: "Условие выполнено → ветка «if», не выполнено → ветка «else».", zh: "条件成立 → 走“if”分支；不成立 → 走“else”分支。" },
  "Thử lại nếu điều kiện chưa thỏa mãn": { en: "Retry while the condition is not satisfied", ru: "Повторять, пока условие не выполнено", zh: "条件不成立时重试" },
  "Số lần thử lại": { en: "Number of retries", ru: "Число повторов", zh: "重试次数" },
  "Giãn cách mỗi lần thử (ms)": { en: "Interval between retries (ms)", ru: "Интервал между попытками (мс)", zh: "每次重试的间隔（毫秒）" },
  "HOẶC": { en: "OR", ru: "ИЛИ", zh: "或" },
  "VÀ": { en: "AND", ru: "И", zh: "且" },
  "Bất kỳ": { en: "Any", ru: "Любое", zh: "任意" },
  "Khớp khi": { en: "Match when", ru: "Совпадение, когда", zh: "匹配条件" },
  "Chỉ cần MỘT điều kiện đúng là qua.": { en: "Passes as soon as ONE condition is true.", ru: "Достаточно, чтобы выполнялось ОДНО условие.", zh: "只要有一个条件成立即可通过。" },
  "MỌI điều kiện đều phải đúng mới qua.": { en: "ALL conditions must be true to pass.", ru: "Должны выполняться ВСЕ условия.", zh: "必须所有条件都成立才能通过。" },
  "Ví dụ ${ten_bien} hoặc chuỗi cố định": { en: "E.g. ${variable_name} or a fixed string", ru: "Например, ${variable_name} или фиксированная строка", zh: "例如 ${variable_name} 或固定字符串" },
  "Đây đang là chuỗi cố định. Muốn lấy giá trị của biến thì bấm nút chèn biến (thành ${…}).": { en: "This is currently a fixed string. To use a variable's value, click the insert-variable button (it becomes ${…}).", ru: "Сейчас это фиксированная строка. Чтобы взять значение переменной, нажмите кнопку вставки переменной (станет ${…}).", zh: "当前是固定字符串。若要取变量的值，请点击插入变量按钮（会变成 ${…}）。" },
  "Danh sách so sánh": { en: "Comparison list", ru: "Список для сравнения", zh: "比较列表" },
  "Giá trị so sánh": { en: "Comparison value", ru: "Значение для сравнения", zh: "比较值" },
  "Nhiều giá trị, cách nhau bằng dấu phẩy. VD: vn, us, jp": { en: "Multiple values separated by commas. E.g. vn, us, jp", ru: "Несколько значений через запятую. Например: vn, us, jp", zh: "多个值用逗号分隔。例如：vn, us, jp" },
  "Bỏ biểu thức": { en: "Remove expression", ru: "Убрать выражение", zh: "移除表达式" },

  // ── Còn lại (errors.js, profiles.js, sync-console.js, upgrade.js, market.js)
  "Dùng thử trên thiết bị của bạn đã hết khả dụng. Vui lòng mua gói để tạo hồ sơ.": { en: "The trial on your device is no longer available. Please buy a plan to create profiles.", ru: "Пробный период на вашем устройстве больше недоступен. Чтобы создавать профили, приобретите тарифный план.", zh: "您设备上的试用已不可用。请购买套餐后再创建配置文件。" },
  "Đã xuất {0} hồ sơ → Excel": { en: "Exported {0} profiles → Excel", ru: "Экспортировано профилей: {0} → Excel", zh: "已导出 {0} 个配置文件 → Excel" },
  "không mở được": { en: "could not be opened", ru: "не удалось открыть", zh: "无法打开" },
  "Thao tác không thành công.": { en: "The action failed.", ru: "Не удалось выполнить действие.", zh: "操作未成功。" },
  "Vui lòng nhập URL trước.": { en: "Please enter a URL first.", ru: "Сначала введите URL.", zh: "请先输入网址。" },
  "Đã mở URL trên {0} cửa sổ": { en: "Opened the URLs in {0} windows", ru: "URL открыты в окнах: {0}", zh: "已在 {0} 个窗口中打开网址" },
  "Đã đồng bộ tab cho {0} cửa sổ": { en: "Synced tabs for {0} windows", ru: "Вкладки синхронизированы для окон: {0}", zh: "已为 {0} 个窗口同步标签页" },
  "Đã đóng tab thừa ở {0} cửa sổ": { en: "Closed the extra tabs in {0} windows", ru: "Лишние вкладки закрыты в окнах: {0}", zh: "已在 {0} 个窗口中关闭多余标签页" },
  "Đã đóng tab hiện tại ở {0} cửa sổ": { en: "Closed the current tab in {0} windows", ru: "Текущая вкладка закрыта в окнах: {0}", zh: "已在 {0} 个窗口中关闭当前标签页" },
  "Đã đóng tab trống ở {0} cửa sổ": { en: "Closed the blank tabs in {0} windows", ru: "Пустые вкладки закрыты в окнах: {0}", zh: "已在 {0} 个窗口中关闭空白标签页" },
  "{0}/tháng": { en: "{0}/month", ru: "{0}/мес.", zh: "{0}/月" },
  "· còn {0} ngày": { en: "· {0} days left", ru: "· осталось дней: {0}", zh: "· 剩余 {0} 天" },
  "(giảm {0}%)": { en: "({0}% off)", ru: "(скидка {0}%)", zh: "（减 {0}%）" },
  "/ Hồ sơ trình duyệt": { en: "/ Browser profile", ru: "/ Профиль браузера", zh: "/ 浏览器配置文件" },
  "{0} VND/năm": { en: "{0} VND/year", ru: "{0} VND/год", zh: "{0} VND/年" },

  // ── Hỏi lưu khi rời trình sửa quy trình (automation.js) ─
  // "OK" là nhãn nút xác nhận ở mọi chỗ trong app (rà lại: không chỗ nào dùng nó làm
  // trạng thái). Tiếng Trung dùng 确定 mới tự nhiên; en/ru giữ "OK".
  "OK": { en: "OK", ru: "OK", zh: "确定" },
  "Xác nhận thoát": { en: "Confirm exit", ru: "Подтвердите выход", zh: "确认退出" },
  "Quy trình hiện tại chưa được lưu, bạn có chắc chắn thoát không?": { en: "The current workflow has not been saved. Are you sure you want to exit?", ru: "Текущий сценарий не сохранён. Вы действительно хотите выйти?", zh: "当前流程尚未保存，确定要退出吗？" },
  "Hồ sơ hiện tại chưa được lưu, bạn có chắc chắn thoát không?": { en: "The current profile has not been saved. Are you sure you want to exit?", ru: "Текущий профиль не сохранён. Вы действительно хотите выйти?", zh: "当前配置文件尚未保存，确定要退出吗？" },
  "Thoát sẽ không được lưu lại": { en: "Your changes will not be saved", ru: "Изменения не будут сохранены", zh: "退出后更改将不会保存" },
  "Lưu và thoát": { en: "Save and exit", ru: "Сохранить и выйти", zh: "保存并退出" },

  // ── Xác nhận khi bấm "Lưu" ở trang Chỉnh sửa hồ sơ (profile_create.js) ─
  "Chỉnh sửa hồ sơ trình duyệt": { en: "Edit browser profile", ru: "Редактировать профиль браузера", zh: "编辑浏览器配置文件" },
  "Bạn có chắc chắn muốn thay đổi thông tin của profile này?": { en: "Are you sure you want to change this profile's information?", ru: "Вы действительно хотите изменить данные этого профиля?", zh: "确定要修改此配置文件的信息吗？" },

  // ── Khuyến mãi nạp tiền (ui/topup-modal.js) ─────────────────────────────
  // Các chuỗi có {0} PHẢI gọi qua tf(): chuỗi đã chèn số/tiền/ngày rồi mới tra từ điển thì
  // không bao giờ khớp khoá. Ba mảnh "nạp từ / thưởng tối đa / đến hết" là ĐIỀU KIỆN rời,
  // ghép bằng dấu liệt kê của từng ngôn ngữ (xem PUNCT) nên viết ở dạng cụm, không viết hoa.
  // zh KHÔNG được kết thúc bằng "：" - phần điều kiện phía sau cũng nối bằng "：" (PUNCT.zh.dash)
  // nên sẽ ra hai dấu hai chấm liền nhau. Dùng dấu phẩy toàn phần "，" ở đây.
  "Đang khuyến mãi +{0}% khi nạp tiền": { en: "Promotion running: +{0}% bonus on top-ups", ru: "Идёт акция: +{0}% при пополнении", zh: "充值优惠进行中，加赠 {0}%" },
  "nạp từ {0}": { en: "minimum top-up {0}", ru: "пополнение от {0}", zh: "单笔充值满 {0}" },
  "thưởng tối đa {0}/lần": { en: "bonus capped at {0} per top-up", ru: "бонус не более {0} за раз", zh: "每笔最高加赠 {0}" },
  "đến hết {0}": { en: "valid through {0}", ru: "до {0} включительно", zh: "截至 {0}" },
  "Nạp tiền thành công! Ví của bạn đã được cộng {0}.": { en: "Top-up successful! {0} has been added to your wallet.", ru: "Пополнение выполнено! На ваш кошелёк зачислено {0}.", zh: "充值成功！已向您的钱包充入 {0}。" },
  "Số tiền chuyển khoản": { en: "Transfer amount", ru: "Сумма перевода", zh: "转账金额" },
  "Khuyến mãi: {0}": { en: "Promotion: {0}", ru: "Акция: {0}", zh: "优惠：{0}" },
  "Khuyến mãi nạp tiền": { en: "Top-up bonus", ru: "Бонус за пополнение", zh: "充值加赠" },
  "Cộng vào ví": { en: "Added to wallet", ru: "Зачислено в кошелёк", zh: "入账金额" },

  // ── Ô tích "Xóa vĩnh viễn" trong modal Xóa hồ sơ (profiles.js) ───────────
  // Chuỗi có {0} PHẢI gọi qua tf() (chèn số trước rồi tra từ điển thì không khớp khoá).
  "Xóa vĩnh viễn (không đưa vào thùng rác)": { en: "Delete permanently (skip the trash)", ru: "Удалить навсегда (минуя корзину)", zh: "永久删除（不放入回收站）" },
  "Gói hiện tại không hoàn lại lượt tạo hồ sơ khi xóa.": { en: "Your current plan does not refund profile-creation slots on deletion.", ru: "Текущий тариф не возвращает слоты на создание профилей при удалении.", zh: "当前套餐删除配置文件时不返还创建名额。" },
  "Gói hiện tại còn hạn và có nhiều hồ sơ hơn gói này. Bạn chỉ đổi sang gói nhỏ hơn khi gói hiện tại hết hạn.": { en: "Your current plan is still active and has more profiles than this plan. You can switch to a smaller plan once the current one expires.", ru: "Текущий тариф ещё действует и включает больше профилей, чем этот. Перейти на меньший тариф можно после окончания текущего.", zh: "当前套餐仍在有效期内，且配置文件数量多于此套餐。当前套餐到期后才能切换到更小的套餐。" },
  "Bạn đang dùng gói này. Hãy chọn thời hạn gia hạn, thêm thành viên hoặc chọn gói lớn hơn.": { en: "You are already on this plan. Choose a renewal period, add members or pick a larger plan.", ru: "Вы уже используете этот тариф. Выберите срок продления, добавьте участников или выберите тариф побольше.", zh: "您正在使用此套餐。请选择续期时长、添加成员或选择更大的套餐。" },
  "Tài khoản đang dùng gói vĩnh viễn nên không cần mua thêm gói tháng.": { en: "Your account is on the lifetime plan, so there is no need to buy a monthly plan.", ru: "У аккаунта пожизненный тариф, поэтому покупать помесячный тариф не нужно.", zh: "您的账户正在使用永久套餐，无需再购买月度套餐。" },
  "/tháng": { en: "/month", ru: "/мес.", zh: "/月" },
  "Đang tải bảng giá…": { en: "Loading prices…", ru: "Загрузка цен…", zh: "正在加载价格…" },
  "Không tải được bảng giá. Vui lòng tải lại trang.": { en: "Could not load prices. Please reload the page.", ru: "Не удалось загрузить цены. Обновите страницу.", zh: "无法加载价格，请刷新页面。" },
  "Không tải được bảng giá. Vui lòng mở lại trang.": { en: "Could not load prices. Please reopen this page.", ru: "Не удалось загрузить цены. Откройте страницу заново.", zh: "无法加载价格，请重新打开此页面。" },
  "Chọn gói": { en: "Choose plan", ru: "Выбрать тариф", zh: "选择套餐" },
  "Đã chọn": { en: "Selected", ru: "Выбрано", zh: "已选择" },
  "Hàng tháng": { en: "Monthly", ru: "Ежемесячно", zh: "按月" },
  "{0} tháng": { en: "{0} months", ru: "{0} мес.", zh: "{0} 个月" },
  "mỗi tháng": { en: "per month", ru: "в месяц", zh: "每月" },
  "mỗi {0} tháng": { en: "every {0} months", ru: "каждые {0} мес.", zh: "每 {0} 个月" },
  "mỗi {0} ngày": { en: "every {0} days", ru: "каждые {0} дн.", zh: "每 {0} 天" },
  "Giới hạn thiết bị": { en: "Device limit", ru: "Лимит устройств", zh: "设备上限" },
  "Không giới hạn": { en: "Unlimited", ru: "Без ограничений", zh: "无限制" },
  "Số hồ sơ": { en: "Profiles", ru: "Профили", zh: "配置文件数" },
  "Miễn phí cho {0} hồ sơ": { en: "Free for {0} profiles", ru: "Бесплатно, профилей: {0}", zh: "免费 {0} 个配置文件" },
  "Dùng thử miễn phí": { en: "Try for free", ru: "Попробовать бесплатно", zh: "免费试用" },
  "Đồng bộ thao tác": { en: "Action sync", ru: "Синхронизация действий", zh: "操作同步" },
  "Automation theo workflow": { en: "Workflow automation", ru: "Автоматизация по сценариям", zh: "工作流自动化" },
  "Đồng bộ dữ liệu đám mây": { en: "Cloud data sync", ru: "Облачная синхронизация данных", zh: "云端数据同步" },
  "Xóa hồ sơ được hoàn lại lượt tạo mới": { en: "Deleting a profile refunds a creation slot", ru: "Удаление профиля возвращает слот на создание", zh: "删除配置文件可返还创建名额" },
  "vĩnh viễn": { en: "forever", ru: "навсегда", zh: "永久" },
  "Thành viên nhóm": { en: "Team members", ru: "Участники команды", zh: "团队成员" },
  "Chọn gói {0}": { en: "Choose the {0} plan", ru: "Выбрать тариф {0}", zh: "选择 {0} 套餐" },
  "Hãy chọn thời hạn gia hạn để chuyển sang gói này.": { en: "Choose a renewal period to switch to this plan.", ru: "Выберите срок продления, чтобы перейти на этот тариф.", zh: "请选择续期时长以切换到此套餐。" },
  "Tạo hồ sơ": { en: "Create profiles", ru: "Создание профилей", zh: "创建配置文件" },
  "Mở hồ sơ": { en: "Open profiles", ru: "Открытие профилей", zh: "打开配置文件" },
  "{0}/ngày": { en: "{0}/day", ru: "{0}/день", zh: "{0}/天" },
  "Tạo tối đa {0} hồ sơ mỗi ngày": { en: "Create up to {0} profiles per day", ru: "До {0} профилей в день", zh: "每天最多创建 {0} 个配置文件" },
  "Mở tối đa {0} lượt mỗi ngày": { en: "Open up to {0} times per day", ru: "До {0} запусков в день", zh: "每天最多打开 {0} 次" },
  "Không giới hạn lượt tạo hồ sơ mỗi ngày": { en: "Unlimited profile creation per day", ru: "Без лимита на создание профилей в день", zh: "每日创建配置文件不限次数" },
  "Không giới hạn lượt mở hồ sơ mỗi ngày": { en: "Unlimited profile opens per day", ru: "Без лимита на запуск профилей в день", zh: "每日打开配置文件不限次数" },
  "Vân tay trình duyệt cấu hình tùy chỉnh": { en: "Custom browser fingerprints", ru: "Пользовательские отпечатки браузера", zh: "自定义浏览器指纹" },
  "Tạo hồ sơ mỗi ngày": { en: "Profiles created per day", ru: "Создание профилей в день", zh: "每日创建配置文件" },
  "Mở hồ sơ mỗi ngày": { en: "Profiles opened per day", ru: "Запуск профилей в день", zh: "每日打开配置文件" },
  "Vân tay trình duyệt thực kéo về": { en: "Real browser fingerprints synced", ru: "Реальные отпечатки браузера", zh: "同步真实浏览器指纹" },
  "Không hỗ trợ": { en: "Not included", ru: "Не входит", zh: "不支持" },
  "Giới hạn số lượng": { en: "Quantity limits", ru: "Лимиты", zh: "数量限制" },
  "Vĩnh viễn": { en: "Lifetime", ru: "Навсегда", zh: "永久" },
  "trả một lần": { en: "one-time payment", ru: "разовый платёж", zh: "一次性付款" },
  "Trả một lần": { en: "One-time payment", ru: "Разовый платёж", zh: "一次性付款" },
  "Giá trả một lần": { en: "One-time price", ru: "Цена разовая", zh: "一次性价格" },
  "Khi chọn xóa vĩnh viễn, bạn sẽ được hoàn lại lượt tạo hồ sơ.": { en: "When you delete permanently, your profile-creation slot is refunded.", ru: "При удалении навсегда вам возвращается слот на создание профиля.", zh: "选择永久删除后，将返还您的配置文件创建名额。" },
  "Chú ý: Sau khi xóa, hồ sơ sẽ được chuyển vào thùng rác và lưu giữ trong vòng 30 ngày.": { en: "Note: after deletion the profiles go to the trash and are kept there for 30 days.", ru: "Внимание: после удаления профили попадают в корзину и хранятся там 30 дней.", zh: "注意：删除后配置文件将移入回收站并保留 30 天。" },
  "Chú ý: Hồ sơ KHÔNG vào thùng rác. Toàn bộ dữ liệu trên máy bị xóa hẳn.": { en: "Note: the profiles do NOT go to the trash. All local data is deleted for good.", ru: "Внимание: профили НЕ попадают в корзину. Все локальные данные стираются безвозвратно.", zh: "注意：配置文件不会进入回收站。本机上的全部数据将被彻底删除。" },
  "{0} hồ sơ đang mở sẽ bị đóng.": { en: "{0} open profiles will be closed.", ru: "Открытых профилей будет закрыто: {0}.", zh: "{0} 个正在打开的配置文件将被关闭。" },
  "Đã xóa vĩnh viễn {0} hồ sơ": { en: "Permanently deleted {0} profiles", ru: "Удалено навсегда профилей: {0}", zh: "已永久删除 {0} 个配置文件" },

  // ── Nhãn tính năng bị cắt theo gói (data/plan-features.js FEATURE_LABELS) ──
  // Các nhãn còn lại ("Chia sẻ hồ sơ", "Tạo không gian làm việc"…) đã có ở trên.
  "Sử dụng API cục bộ": { en: "Use the local API", ru: "Использование локального API", zh: "使用本地 API" },

  /* ══════════════════════════════════════════════════════════════════════════
     Trang "Nâng cấp gói" → tab "Quản lý thiết bị" (views/upgrade.js, dv*)
     ─────────────────────────────────────────────────────────────────────────
     Cả tab này TRƯỚC ĐÓ KHÔNG có một dòng DICT nào: chọn en/ru/zh thì nửa trang
     bên phải vẫn đứng nguyên tiếng Việt. Không vỡ gì, không log gì - nên nó sống
     được lâu mà không ai báo.

     Quy tắc ngữ pháp đã áp ở đây (ĐỪNG "sửa cho gọn" thành dịch từng chữ):

     • TIẾNG NGA - số đếm đổi đuôi danh từ (1 слот / 2 слота / 5 слотов). MỘT mẫu
       `{0} слотов` thì sai với 1 và 2. Không có số nhiều theo CLDR trong tf(), nên
       chỗ nào có số chạy thì ĐẢO thành "Слотов: {0}" / "Удалено устройств: {0}"
       (danh từ đứng trước dấu hai chấm → không chia theo số), hoặc dùng viết tắt
       bất biến (мин. / ч. / дн. / мес. / г.).
     • TIẾNG ANH - `{0} minutes ago` in ra "1 minutes ago". Cột "Lần cuối" đếm từ
       1 phút nên PHẢI viết tắt: min / hr. (Hai khoá {0} ngày/tháng/năm trước đã
       có sẵn từ views/market.js ở trên - dùng chung, không thêm bản thứ hai.)
     • TIẾNG TRUNG - không có dấu cách trước đơn vị trong câu chạy, dấu câu toàn
       chiều rộng (。，？), và theo ĐÚNG lệ của tệp này thì giữ một dấu cách quanh
       chữ số ASCII (xem "{0} 天前", "{0} 个文件" ở trên) cho dễ đọc.
     • Mọi bản dịch phải có ĐỦ và ĐÚNG bộ {0}/{1}/{2} như khoá tiếng Việt: tf()
       tra MẪU rồi mới chèn, thiếu một chỗ giữ là con số bay mất khỏi câu.
     ═════════════════════════════════════════════════════════════════════════ */

  // ── Bộ chuyển tab trong khung .ap-card ──
  "Gói dịch vụ": { en: "Plans", ru: "Тарифы", zh: "服务套餐" },
  "Quản lý thiết bị": { en: "Device management", ru: "Управление устройствами", zh: "设备管理" },

  // ── dvAgo(): cột "Lần cuối" ──
  // Chỉ thêm hai mốc này; {0} ngày/tháng/năm trước đã có ở khối market.js phía trên.
  "{0} phút trước": { en: "{0} min ago", ru: "{0} мин. назад", zh: "{0} 分钟前" },
  "{0} giờ trước": { en: "{0} hr ago", ru: "{0} ч. назад", zh: "{0} 小时前" },

  // ── Panel TRÁI: datagrid máy đã đăng nhập ──
  "Thiết bị đã đăng nhập": { en: "Signed-in devices", ru: "Устройства с выполненным входом", zh: "已登录的设备" },
  "Thiết bị": { en: "Device", ru: "Устройство", zh: "设备" },
  "Lần cuối": { en: "Last seen", ru: "Последняя активность", zh: "最后活动" },
  "Máy không tên": { en: "Unnamed device", ru: "Устройство без имени", zh: "未命名设备" },
  "máy này": { en: "this device", ru: "это устройство", zh: "本设备" },
  "không rõ hệ điều hành": { en: "unknown operating system", ru: "ОС неизвестна", zh: "操作系统未知" },
  // Cặp này nói về PHIÊN ĐĂNG NHẬP, không phải online/offline mạng ⇒ tiếng Nga dùng
  // "выполнен вход/выход" chứ KHÔNG phải "в сети / не в сети".
  "Đã đăng nhập": { en: "Signed in", ru: "Выполнен вход", zh: "已登录" },
  "đã đăng xuất": { en: "signed out", ru: "выполнен выход", zh: "已退出" },
  "Gỡ thiết bị này": { en: "Remove this device", ru: "Удалить это устройство", zh: "移除此设备" },
  "Không thể gỡ máy đang dùng. Hãy gỡ máy này từ trang quản lý trên cgtdev.space.": { en: "You cannot remove the device you are using. Remove this device from the management page on cgtdev.space.", ru: "Нельзя удалить устройство, с которого вы работаете. Удалите его на странице управления на cgtdev.space.", zh: "无法移除您正在使用的设备。请在 cgtdev.space 的管理页面移除此设备。" },
  "Chưa có máy nào đăng nhập tài khoản này.": { en: "No device has signed in to this account yet.", ru: "На этот аккаунт пока не входило ни одно устройство.", zh: "目前还没有设备登录过此账户。" },
  "Đang tải thiết bị…": { en: "Loading devices…", ru: "Загрузка устройств…", zh: "正在加载设备…" },
  "Không tải được danh sách thiết bị": { en: "Could not load the device list", ru: "Не удалось загрузить список устройств", zh: "无法加载设备列表" },

  // ── Panel PHẢI: thẻ số "Thiết bị đã dùng" (đổi tên từ "Chỗ thiết bị đã dùng" 2026-10-03) ──
  "Thiết bị đã dùng": { en: "Devices used", ru: "Использовано устройств", zh: "已用设备" },
  "không giới hạn": { en: "unlimited", ru: "без ограничений", zh: "无限制" },
  "Gói của bạn không giới hạn số thiết bị.": { en: "Your plan has no device limit.", ru: "В вашем тарифе нет ограничения на устройства.", zh: "您的套餐不限设备数量。" },
  // {1} là TÊN GÓI do server trả (không dịch) hoặc chuỗi lùi "gói hiện tại".
  // Tiếng Nga: "Слотов: {0}" để khỏi chia đuôi theo con số (1 слот / 2 слота / 5 слотов).
  "{0} chỗ của {1}": { en: "{0} slots from {1}", ru: "Слотов: {0} ({1})", zh: "{0} 个设备位来自{1}" },
  "{0} chỗ của {1} + {2} chỗ đã mua": { en: "{0} slots from {1} + {2} purchased", ru: "Слотов: {0} ({1}) + куплено: {2}", zh: "{0} 个设备位来自{1}，另已购 {2} 个" },
  "gói hiện tại": { en: "your current plan", ru: "текущий тариф", zh: "当前套餐" },
  "Đã hết chỗ. Gỡ một máy cũ để đăng nhập máy mới.": { en: "No slots left. Remove an old device to sign in on a new machine.", ru: "Свободных слотов нет. Удалите старое устройство, чтобы войти на новом компьютере.", zh: "设备位已用完。请移除旧设备，才能在新电脑上登录。" },
  "(nâng cấp: chênh lệch {0} cho {1} ngày còn lại)": { en: "(upgrade: {0} difference for the remaining {1} days)", ru: "(апгрейд: разница {0} за оставшиеся {1} дн.)", zh: "（升级：剩余 {1} 天的差价 {0}）" },
  "{0} ngày còn lại (giữ nguyên hạn)": { en: "{0} days left (expiry unchanged)", ru: "осталось {0} дн. (срок без изменений)", zh: "剩余 {0} 天（到期日不变）" },
  "Gói vĩnh viễn không hỗ trợ mua thêm thiết bị.": { en: "The lifetime plan does not support buying extra devices.", ru: "Пожизненный тариф не поддерживает покупку дополнительных устройств.", zh: "永久套餐不支持加购设备位。" },
  "Đã hết chỗ. Gỡ một máy cũ hoặc mua thêm thiết bị để đăng nhập máy mới.": { en: "No slots left. Remove an old device or buy more devices to sign in on a new machine.", ru: "Свободных слотов нет. Удалите старое устройство или купите ещё, чтобы войти на новом компьютере.", zh: "设备位已用完。请移除旧设备或加购设备位，才能在新电脑上登录。" },

  // ── Modal gỡ MỘT máy (dvAskRemove) ──
  // Mẫu có <b> vì nó đi vào `html:`. Trọn câu trong một mẫu để mỗi ngôn ngữ tự đặt
  // chỗ của tên máy; chắp từ `Gỡ <b>${nm}</b> khỏi...` thì DICT chỉ dịch được mảnh.
  "Gỡ thiết bị": { en: "Remove device", ru: "Удалить устройство", zh: "移除设备" },
  "Gỡ thiết bị thất bại": { en: "Could not remove the device", ru: "Не удалось удалить устройство", zh: "移除设备失败" },
  "Gỡ <b>{0}</b> khỏi tài khoản? Máy này sẽ bị đăng xuất khỏi ứng dụng ngay, và bạn được lại <b>một chỗ thiết bị</b> để đăng nhập máy khác.": { en: "Remove <b>{0}</b> from your account? It is signed out of the app immediately, and you get <b>one device slot</b> back to sign in on another machine.", ru: "Удалить <b>{0}</b> из аккаунта? Это устройство сразу выйдет из приложения, а вы получите обратно <b>один слот устройства</b> для входа на другом компьютере.", zh: "要把 <b>{0}</b> 从账户中移除吗？该设备会立即退出应用，同时归还 <b>一个设备位</b>，可用于在其他电脑上登录。" },
  "Máy này ĐANG đăng nhập. Nếu đang chạy hồ sơ hoặc quy trình, công việc đó sẽ dừng.": { en: "This device is CURRENTLY signed in. If it is running profiles or flows, that work will stop.", ru: "На этом устройстве СЕЙЧАС выполнен вход. Если на нём запущены профили или сценарии, эта работа остановится.", zh: "该设备当前处于登录状态。如果它正在运行配置文件或流程，这些工作会被中断。" },
  "Lần sau đăng nhập lại trên chính máy này vẫn được, miễn là còn chỗ trống.": { en: "You can sign in on this same machine again later, as long as a slot is free.", ru: "Позже вы сможете снова войти с этого же компьютера, если будет свободный слот.", zh: "以后仍可在这台电脑上重新登录，只要还有空闲的设备位。" },
  "Đã gỡ {0}. Bạn có thêm một chỗ thiết bị.": { en: "Removed {0}. You have one more device slot.", ru: "Устройство {0} удалено. У вас стало на один слот больше.", zh: "已移除 {0}。您多了一个设备位。" },

  // ── Modal reset: gỡ mọi máy KHÁC (dvAskReset) ──
  "Reset thiết bị": { en: "Reset devices", ru: "Сбросить устройства", zh: "重置设备" },
  "Reset thiết bị thất bại": { en: "Could not reset devices", ru: "Не удалось сбросить устройства", zh: "重置设备失败" },
  "Gỡ mọi máy khác và trả lại chỗ của chúng": { en: "Remove every other device and free up their slots", ru: "Удалить все другие устройства и освободить их слоты", zh: "移除所有其他设备并释放它们的设备位" },
  "Không có máy nào khác để reset": { en: "There is no other device to reset", ru: "Нет других устройств для сброса", zh: "没有其他设备可重置" },
  "Gỡ <b>{0} thiết bị khác</b> khỏi tài khoản và trả lại chỗ của chúng?": { en: "Remove <b>{0} other devices</b> from your account and free up their slots?", ru: "Удалить из аккаунта <b>другие устройства ({0})</b> и освободить их слоты?", zh: "要把 <b>其他 {0} 台设备</b> 从账户中移除并释放它们的设备位吗？" },
  "Mọi máy đó sẽ bị đăng xuất khỏi ứng dụng ngay. Công việc đang chạy trên các máy đó sẽ dừng.": { en: "All of those devices are signed out of the app immediately. Work running on them will stop.", ru: "Все эти устройства сразу выйдут из приложения. Запущенная на них работа остановится.", zh: "这些设备都会立即退出应用。在它们上运行的工作会被中断。" },
  "Máy bạn đang dùng được giữ lại - bạn không bị đăng xuất khỏi ứng dụng này.": { en: "The device you are using is kept - you will not be signed out of this app.", ru: "Устройство, с которого вы работаете, останется - из этого приложения вас не выведет.", zh: "您正在使用的设备会被保留，不会退出此应用。" },
  "Đã gỡ {0} thiết bị, trả lại chỗ của chúng.": { en: "Removed {0} devices and freed up their slots.", ru: "Удалено устройств: {0}. Их слоты освобождены.", zh: "已移除 {0} 台设备，并释放了它们的设备位。" },

  // ── Mua thêm chỗ thiết bị (dvOnBuy / dvInsufficientModal) ──
  // "Số dư không đủ", "Hủy", "Đồng ý", "Để sau", "Nạp tiền" đã có ở trên - dùng lại.
  "Mua thêm thiết bị": { en: "Buy more devices", ru: "Купить ещё устройства", zh: "加购设备位" },
  "Mua thiết bị": { en: "Buy devices", ru: "Купить устройства", zh: "购买设备位" },
  "Mua thiết bị thất bại": { en: "Could not buy devices", ru: "Не удалось купить устройства", zh: "购买设备位失败" },
  "Xác nhận mua thiết bị": { en: "Confirm device purchase", ru: "Подтверждение покупки устройств", zh: "确认购买设备位" },
  "{0} / thiết bị": { en: "{0} / device", ru: "{0} / устройство", zh: "{0} / 台设备" },
  "Chưa có giá - vui lòng liên hệ hỗ trợ": { en: "No price set - please contact support", ru: "Цена не задана - обратитесь в поддержку", zh: "尚未设置价格，请联系客服" },
  "Thành tiền": { en: "Total", ru: "Итого", zh: "合计" },
  // {0} = số lượng, {1} = số tiền đã định dạng. Tiếng Nga đảo thành "ещё устройств: {0}"
  // để khỏi chia đuôi (1 устройство / 2 устройства / 5 устройств).
  "Mua thêm <b>{0} thiết bị</b> với giá <b>{1}</b>?": { en: "Buy <b>{0} more devices</b> for <b>{1}</b>?", ru: "Купить <b>ещё устройств: {0}</b> за <b>{1}</b>?", zh: "要以 <b>{1}</b> 加购 <b>{0} 台设备</b> 吗？" },
  "Phí một lần. Chỗ đã mua được cộng thêm vào hạn mức của gói và không mất khi gia hạn hay khi gói hết hạn.": { en: "One-time fee. Purchased slots are added on top of your plan limit and are not lost on renewal or when the plan expires.", ru: "Разовый платёж. Купленные слоты добавляются к лимиту тарифа и не теряются при продлении или истечении тарифа.", zh: "一次性费用。已购设备位会叠加在套餐额度之上，续费或套餐到期后也不会丢失。" },
  "Số dư ví không đủ để mua thêm thiết bị. Bạn cần nạp thêm để tiếp tục.": { en: "Your wallet balance is not enough to buy more devices. Please top up to continue.", ru: "На балансе кошелька недостаточно средств для покупки устройств. Пополните счёт, чтобы продолжить.", zh: "钱包余额不足，无法加购设备位。请充值后继续。" },
  "Đã mua thêm {0} thiết bị.": { en: "Bought {0} more devices.", ru: "Куплено устройств: {0}.", zh: "已加购 {0} 台设备。" },
  "Còn thiếu {0}": { en: "Short by {0}", ru: "Не хватает {0}", zh: "还差 {0}" },

  // ===========================================================================
  // Trang "MCP" (views/mcp.js) + nhãn tính năng do src/main/mcp.js trả về.
  // "Model Context Protocol" và tên công cụ (open_profile, create_workflow…) là
  // ĐỊNH DANH GIAO THỨC - CỐ Ý không có khoá, mọi ngôn ngữ đọc y nguyên.
  // ===========================================================================
  // Tên sản phẩm viết LIỀN: "CGTBrowser", không phải "CGTBrowser" (user 2026-10-10).
  // Khoá CHÍNH LÀ chuỗi tiếng Việt, nên sửa tên trong câu là ĐỔI KHOÁ -> phải sửa
  // cả bên views/mcp.js cùng lúc, kẻo ba thứ tiếng kia lặng lẽ in ra tiếng Việt.
  "Cho trợ lý AI điều khiển CGTBrowser qua một cổng duy nhất trên máy này.": { en: "Let AI assistants drive CGTBrowser through a single endpoint on this machine.", ru: "Позволяет ИИ-ассистентам управлять CGTBrowser через единую точку доступа на этом компьютере.", zh: "让 AI 助手通过本机上的单一接入点来操作 CGTBrowser。" },

  // ── Dải thông báo gói (chỉ hiện khi gói hiện tại không hỗ trợ) ──
  // Câu đầu TRÙNG nguyên văn PAID_MSG trong src/main/mcp.js: trợ lý nhận câu đó
  // qua HTTP, người dùng đọc câu đó trên trang - sửa một bên thì sửa cả hai.
  "MCP chỉ hỗ trợ đối với gói trả phí.": { en: "MCP is available on paid plans only.", ru: "MCP доступен только на платных тарифах.", zh: "MCP 仅支持付费套餐。" },
  "Gói miễn phí vẫn xem được trang này, nhưng mọi lệnh trợ lý AI gửi tới sẽ bị từ chối.": { en: "The Free plan can still view this page, but every command an AI assistant sends will be refused.", ru: "На бесплатном тарифе эту страницу можно открыть, но любая команда от ИИ-ассистента будет отклонена.", zh: "免费套餐仍可查看此页面，但 AI 助手发来的所有指令都会被拒绝。" },

  // ── Server + cấu hình ──
  // Tiêu đề khối là "Server" - user tự đặt bằng tiếng Anh (2026-10-10), thay cho
  // "Điểm kết nối" cũ. CỐ Ý KHÔNG có khoá: từ này đọc như nhau ở cả bốn ngôn ngữ
  // trong ngữ cảnh kỹ thuật, và thêm khoá thì khi xem tiếng Việt lại thành chữ
  // khác đúng cái user vừa bỏ. Câu phụ "Chỉ nghe trên máy này (127.0.0.1)…" đã bỏ
  // khỏi trang nên cũng bỏ khoá - đừng thêm lại cả hai.
  "Sao chép địa chỉ": { en: "Copy the endpoint", ru: "Скопировать адрес", zh: "复制地址" },
  "Đã sao chép địa chỉ": { en: "Endpoint copied", ru: "Адрес скопирован", zh: "已复制地址" },
  "Cấu hình cho trợ lý": { en: "Assistant configuration", ru: "Настройка для ассистента", zh: "助手配置" },
  // ⛔ Mục "Cấu hình cho trợ lý" KHÔNG còn câu phụ - user bỏ label 2026-10-10. Đã gỡ
  // CẢ HAI khoá từng tồn tại cho nó ("Cùng một cấu hình, chọn cú pháp…" của bản có
  // dải thẻ, rồi "Cùng một cấu hình khai bằng hai cú pháp…" của bản xếp dọc). ĐỪNG
  // thêm lại. Nhớ: khoá của DICT CHÍNH LÀ chuỗi tiếng Việt trong view, nên mỗi lần
  // sửa chữ ở views/mcp.js phải sửa kèm ở đây, không thì en/ru/zh lặng lẽ in tiếng
  // Việt - và chuỗi bỏ khỏi view mà để khoá lại thì thành khoá chết, không ai thấy.
  //
  // Nhãn chip cú pháp ("JSON" / "TOML") CỐ Ý không có khoá - tên định dạng tệp, viết
  // y nhau ở cả bốn ngôn ngữ. Dòng gợi ý của khối JSON cũng không có khoá vì nó CHỈ
  // gồm tên sản phẩm; khối TOML thì có chữ "tệp" nên phải dịch.
  "Codex (tệp config.toml)": { en: "Codex (config.toml file)", ru: "Codex (файл config.toml)", zh: "Codex（config.toml 文件）" },
  "Sao chép cấu hình": { en: "Copy the configuration", ru: "Скопировать настройку", zh: "复制配置" },
  "Đã sao chép cấu hình": { en: "Configuration copied", ru: "Настройка скопирована", zh: "已复制配置" },
  // ĐÃ BỎ ba khoá "Tích hợp Claude" / "Tích hợp thành công" / "Tích hợp thất bại":
  // user bỏ nút tự ghi claude_desktop_config.json (2026-10-10), người dùng dán tay.
  // Đừng thêm lại - khoá không còn ai gọi chỉ làm bộ dò phủ i18n báo nhiễu.

  // ── Bốn tính năng, dạng cây chỉ để xem ──
  // Nhãn "Mở hồ sơ" / "Đóng hồ sơ" / "Xóa hồ sơ" / "Tạo quy trình" đã có khoá ở
  // phần trên của DICT (trang Hồ sơ, trình sửa quy trình) - dùng lại, đừng thêm lần hai.
  // Khối này CHỈ có tiêu đề, KHÔNG có câu phụ: user đã bỏ công tắc từng tính năng
  // rồi bỏ luôn dòng mô tả dưới tiêu đề (2026-10-10). Đừng thêm lại khoá nào nói
  // về bật/tắt, cũng đừng thêm lại câu "Cả bốn việc dưới đây…".
  "Tính năng cho phép": { en: "Allowed capabilities", ru: "Разрешённые возможности", zh: "允许的功能" },
  "Khởi động trình duyệt của một hồ sơ và trả về điểm nối CDP.": { en: "Launch a profile's browser and return its CDP endpoint.", ru: "Запускает браузер профиля и возвращает его CDP-адрес.", zh: "启动某个配置文件的浏览器，并返回其 CDP 接入点。" },
  "Đóng trình duyệt của một hồ sơ đang mở.": { en: "Close the browser of a profile that is open.", ru: "Закрывает браузер открытого профиля.", zh: "关闭某个已打开配置文件的浏览器。" },
  "Chuyển hồ sơ vào thùng rác (còn khôi phục được).": { en: "Move a profile to the trash (it can still be restored).", ru: "Перемещает профиль в корзину (его ещё можно восстановить).", zh: "将配置文件移入回收站（仍可恢复）。" },
  "Dựng một quy trình RPA mới từ danh sách bước và lưu lại.": { en: "Build a new RPA flow from a list of steps and save it.", ru: "Собирает новый RPA-сценарий из списка шагов и сохраняет его.", zh: "根据步骤列表构建并保存一个新的 RPA 流程。" },

  // ── Lỗi của trang ──
  "Không đọc được trạng thái MCP": { en: "Could not read the MCP status", ru: "Не удалось получить состояние MCP", zh: "无法读取 MCP 状态" },

  // ═══════════════════ Trang "HOA HỒNG" (views/affiliate.js) ═══════════════════
  //
  // ⚠️ MỌI con số trong các câu dưới đây là CHỖ THAY `{0}` do `tf()` điền từ `snap.policy`
  // (admin sửa bên web admin). Bản dịch PHẢI giữ nguyên `{0}` - dịch mà bỏ mất nó là câu
  // chính sách hiện ra thiếu hẳn con số, không có lỗi nào báo.
  //
  // ⚠️ Các nhãn trạng thái ('Đang giữ', 'Rút được', 'Vượt trần', 'Chờ duyệt', 'Đã chi',
  // 'Bị từ chối') KHÔNG đi qua `t()` trong view - chúng là text node do `el()` đặt và
  // applyI18n dịch tại chỗ. Vì vậy chúng BẮT BUỘC có khoá ở đây, bỏ sót là pill trong bảng
  // in tiếng Việt giữa trang tiếng Anh.

  // ── Đầu trang + thẻ mã giới thiệu ──
  // (Khoá "Giới thiệu bạn bè và nhận hoa hồng trọn đời" đã XOÁ ngày 2026-10-20: nhãn mô tả đầu
  // trang bị gỡ từ lâu, và chữ "trọn đời" nay trái với câu "chu kỳ tối đa 24 tháng" mà cả trang
  // đang dùng. Đừng thêm lại.)
  // ⚠️ GIỮ: khoá này KHÔNG còn là tiêu đề thẻ "Mã giới thiệu của bạn" (tiêu đề đó đã bị gỡ ngày
  // 2026-10-20) nhưng chuỗi vẫn được in ở chỗ khác trong src/ - đừng xoá vì tưởng nó chết.
  "Mã giới thiệu của bạn": { en: "Your referral code", ru: "Ваш реферальный код", zh: "您的推荐码" },
  // Hai mẫu `tf()` dựng câu dẫn ĐẦU thẻ mã (thay cho tiêu đề cũ + dòng "Gửi mã này cho bạn bè..."
  // đã xoá). {0} là `policy.percent` / `policy.holdDays` lấy từ server, KHÔNG ghi cứng số.
  // ⚠️ "chu kỳ kéo dài tối đa 24 tháng" là chữ user chọn 2026-10-20, KHÔNG phải mô tả cơ chế:
  // hệ thống hiện KHÔNG cắt hoa hồng theo mốc tháng nào cả. Bản dịch phải bám đúng chữ tiếng
  // Việt, đừng "sửa lại cho khớp code" thành lifetime/пожизненно/终身.
  "Khi bạn bè đăng ký gói của CGTBrowser bằng mã giới thiệu của bạn, bạn sẽ nhận được {0}% hoa hồng từ mọi giao dịch của họ, với chu kỳ kéo dài tối đa 24 tháng.": { en: "When a friend buys a CGTBrowser plan using your referral code, you earn {0}% commission on every payment they make, for a cycle lasting up to 24 months.", ru: "Когда друг оплачивает тариф CGTBrowser по вашему реферальному коду, вы получаете {0}% комиссии с каждого его платежа в течение цикла продолжительностью до 24 месяцев.", zh: "好友使用您的推荐码购买 CGTBrowser 套餐后，您将获得其每笔付款的 {0}% 佣金，周期最长 24 个月。" },
  "Mỗi khoản hoa hồng được giữ {0} ngày rồi chuyển sang số dư có thể rút.": { en: "Each commission is held for {0} days, then moves to your withdrawable balance.", ru: "Каждая комиссия удерживается {0} дней, затем переходит в баланс, доступный к выводу.", zh: "每笔佣金冻结 {0} 天后转入可提现余额。" },
  "Đã sao chép mã giới thiệu": { en: "Referral code copied", ru: "Реферальный код скопирован", zh: "已复制推荐码" },
  "Không sao chép được, bạn hãy chọn và copy thủ công": { en: "Could not copy - please select the code and copy it manually", ru: "Не удалось скопировать - выделите код и скопируйте вручную", zh: "复制失败，请手动选中并复制" },

  // ── Hàng BỐN ô trên cùng trang "Hoa hồng" ──
  // Hàng này đã được rút gọn theo ảnh mẫu (nhãn nhỏ + số lớn + một dòng phụ). Các khoá của bản
  // cũ ('Phần thưởng giới thiệu', 'Rút được sau {0} ngày', 'Admin đã chi', 'Hoa hồng tháng
  // này', 'Đã phát sinh giao dịch'...) đã bị XOÁ cùng với những dòng chữ đó - đừng thêm lại khi
  // thấy "thiếu", hãy kiểm views/affiliate.js xem chuỗi còn được in ra không.
  "Đang giữ": { en: "On hold", ru: "На удержании", zh: "冻结中" },
  "Có thể rút": { en: "Withdrawable", ru: "Доступно к выводу", zh: "可提现" },
  "Rút tiền": { en: "Withdraw", ru: "Вывести", zh: "提现" },
  // Tiêu đề + nhãn của ô ĐẦU hàng. 'Có thể rút' ở trên nay chỉ còn sống trong modal rút tiền -
  // nhãn trên thẻ đã đổi thành 'Số dư', ĐỪNG xoá khoá kia vì tưởng nó chết.
  // ⚠️ 'Số dư' là chuỗi NGẮN và applyI18n dịch MỌI text node khớp khoá: nó cũng sẽ dịch chữ
  // "Số dư" đứng riêng ở app.js. Ở đó nghĩa cũng là "balance" nên đúng, nhưng phải biết là
  // khoá này KHÔNG chỉ tác động một trang.
  // Tiêu đề ô 1 của thẻ trên cùng. Khoá "Tóm tắt dữ liệu" (bản chép theo AdsPower) ĐÃ XOÁ
  // ngày 2026-10-20 - user đổi chữ thành "Thông tin chi trả" và chuỗi cũ không còn nơi nào
  // trong src/ dùng. ĐỪNG thêm lại khoá cũ khi thấy chú thích "Tóm tắt dữ liệu" trong
  // affiliate.js/app.css: ở đó chỉ còn là lời kể về nguồn gốc bố cục.
  "Thông tin chi trả": { en: "Payout details", ru: "Информация о выплатах", zh: "支付信息" },
  "Số dư": { en: "Balance", ru: "Баланс", zh: "余额" },
  // 'Tải lại' nằm ở thuộc tính `title` của nút icon (tooltip) - applyI18n có dịch `title`, nên
  // vẫn phải khai khoá dù chuỗi không xuất hiện thành text node nào.
  "Tải lại": { en: "Reload", ru: "Обновить", zh: "刷新" },
  // Nhãn xám nằm TRONG ô chứa mã. Khác khoá 'Mã giới thiệu của bạn' ở trên (chuỗi đó nay dùng ở
  // nơi khác, không còn là tiêu đề thẻ này).
  "Mã giới thiệu": { en: "Referral code", ru: "Реферальный код", zh: "推荐码" },
  // Ô THỨ HAI của thẻ mã (thêm 2026-10-20): link https://cgtdev.space/download?ref=MÃ.
  // ⚠️ Hai khoá này cũng có trong web landing (public/i18n.js, khối affiliate) - cùng bản dịch,
  // vì trang Hoa hồng ở app và ở web là CÙNG một chương trình. Đổi một bên thì đổi cả hai.
  // "Link" chứ không "Liên kết": toàn app đã dùng "link" cho URL dán đi chia sẻ.
  "Link mời": { en: "Invite link", ru: "Ссылка-приглашение", zh: "邀请链接" },
  "Đã sao chép link mời": { en: "Invite link copied", ru: "Ссылка-приглашение скопирована", zh: "已复制邀请链接" },
  "Đã tải lại dữ liệu hoa hồng": { en: "Commission data reloaded", ru: "Данные по комиссии обновлены", zh: "佣金数据已刷新" },
  "Đang chờ duyệt": { en: "Awaiting review", ru: "Ожидает проверки", zh: "待审核" },
  // ⚠️ KHOÁ PHẢI LÀ 'Đã rút', đừng "sửa" về 'Đã nhận': khoá 'Đã nhận' đã thuộc bộ lọc của
  // trang Chợ (dòng ~569, dịch "Received"). Khai trùng khoá là bản dưới GHI ĐÈ bản trên và
  // bộ lọc bên đó đổi nghĩa thành "Paid out" - không có lỗi nào báo.
  "Đã rút": { en: "Withdrawn", ru: "Выведено", zh: "已提现" },
  "Tổng đã rút": { en: "Total withdrawn", ru: "Всего выведено", zh: "累计提现" },
  "Cần tối thiểu {0} mới gửi được yêu cầu rút.": { en: "You need at least {0} to request a withdrawal.", ru: "Для запроса вывода нужно минимум {0}.", zh: "至少需要 {0} 才能申请提现。" },

  // ── Ô "Tổng hoa hồng" và ô "Số người đã giới thiệu" ──
  // "Số người đã giới thiệu" mang luôn ĐƠN VỊ trong nhãn. ĐỪNG tách đơn vị ra thành khoá
  // riêng 'người': DICT khoá theo chính chuỗi tiếng Việt và applyI18n dịch MỌI text node khớp
  // khoá, nên một khoá-một-từ-thông-dụng sẽ đổi chữ ở những trang chẳng liên quan gì.
  "Lịch sử giới thiệu": { en: "Referral history", ru: "История приглашений", zh: "推荐记录" },
  "Số người đã giới thiệu": { en: "People referred", ru: "Количество приглашённых", zh: "已推荐人数" },
  "{0} người đã phát sinh giao dịch": { en: "{0} of them made a purchase", ru: "из них {0} совершили покупку", zh: "其中 {0} 人已产生交易" },
  "người đã mua gói hoặc kịch bản": { en: "people bought a plan or a script", ru: "чел. купили тариф или сценарий", zh: "人已购买套餐或脚本" },
  "Tháng này {0}": { en: "This month {0}", ru: "За месяц {0}", zh: "本月 {0}" },
  "Tổng hoa hồng": { en: "Total commission", ru: "Всего комиссии", zh: "累计佣金" },

  // ── Thẻ chính sách ──
  // ⚠️ HAI khoá gần nhau nhưng KHÁC nhau, đừng gộp thành một: khoá thứ nhất là NHÃN liên kết chữ
  // xanh ở thẻ 2, khoá thứ hai là TIÊU ĐỀ của modal mà liên kết đó mở ra (user chọn thêm chữ
  // "chi trả" cho tiêu đề, 2026-10-20). Cùng một luồng bấm nên bản dịch phải cùng lối nói.
  "Cách tính hoa hồng": { en: "How commission works", ru: "Как начисляется комиссия", zh: "佣金计算方式" },
  "Cách tính hoa hồng chi trả": { en: "How commission is calculated and paid", ru: "Как начисляется и выплачивается комиссия", zh: "佣金的计算与支付方式" },
  // Xem cảnh báo "24 tháng" ở khoá câu dẫn phía trên - hai câu này PHẢI nói cùng một chuyện.
  "Bạn nhận {0}% giá trị mỗi giao dịch của người bạn giới thiệu, với chu kỳ kéo dài tối đa 24 tháng.": { en: "You earn {0}% of every transaction made by the people you refer, for a cycle lasting up to 24 months.", ru: "Вы получаете {0}% от каждой покупки приглашённых вами людей в течение цикла продолжительностью до 24 месяцев.", zh: "您可从被推荐人的每笔交易中获得 {0}%，周期最长 24 个月。" },
  "Người được bạn giới thiệu nhận {0} vào ví ở giao dịch đầu tiên của họ.": { en: "The person you refer receives {0} in their wallet on their first transaction.", ru: "Приглашённый получает {0} на кошелёк при первой покупке.", zh: "被推荐人在首笔交易时会获得 {0} 到钱包。" },
  "Hoa hồng tính trên tiền CHI TIÊU (mua gói, mua kịch bản). Tiền nạp vào ví không tính hoa hồng.": { en: "Commission is calculated on money SPENT (buying plans or scripts). Wallet top-ups do not earn commission.", ru: "Комиссия начисляется на ПОТРАЧЕННЫЕ средства (покупка тарифов, сценариев). Пополнение кошелька комиссию не даёт.", zh: "佣金按实际消费计算（购买套餐、脚本）。钱包充值不计佣金。" },
  "Mỗi khoản hoa hồng được giữ {0} ngày trước khi chuyển sang số dư có thể rút.": { en: "Each commission is held for {0} days before it becomes withdrawable.", ru: "Каждая комиссия удерживается {0} дн., прежде чем станет доступной для вывода.", zh: "每笔佣金会冻结 {0} 天后才转为可提现。" },
  "Trần hoa hồng cho mỗi người được giới thiệu: {0}.": { en: "Commission cap per referred person: {0}.", ru: "Лимит комиссии на одного приглашённого: {0}.", zh: "每位被推荐人的佣金上限：{0}。" },
  "Không giới hạn hoa hồng cho mỗi người được giới thiệu.": { en: "No commission cap per referred person.", ru: "Лимита комиссии на приглашённого нет.", zh: "每位被推荐人的佣金无上限。" },
  "Trần hoa hồng mỗi tháng: {0}.": { en: "Monthly commission cap: {0}.", ru: "Месячный лимит комиссии: {0}.", zh: "每月佣金上限：{0}。" },
  "Không giới hạn hoa hồng mỗi tháng.": { en: "No monthly commission cap.", ru: "Месячного лимита комиссии нет.", zh: "每月佣金无上限。" },
  "Mức rút tối thiểu {0}. Mỗi lần chỉ có một yêu cầu rút đang chờ duyệt.": { en: "Minimum withdrawal is {0}. Only one withdrawal request can be pending at a time.", ru: "Минимальная сумма вывода - {0}. Одновременно может рассматриваться только один запрос.", zh: "最低提现金额为 {0}。同一时间仅可有一笔待审申请。" },
  "Mọi yêu cầu rút được admin kiểm duyệt thủ công. Tài khoản có dấu hiệu tự giới thiệu hoặc gian lận sẽ bị từ chối.": { en: "Every withdrawal request is reviewed manually by an admin. Accounts showing signs of self-referral or fraud will be rejected.", ru: "Каждый запрос на вывод проверяется администратором вручную. Аккаунты с признаками самоприглашения или мошенничества будут отклонены.", zh: "所有提现申请均由管理员人工审核。存在自我推荐或欺诈迹象的账户将被拒绝。" },

  // ── Bảng "Người bạn đã giới thiệu" ──
  "Người bạn đã giới thiệu": { en: "People you referred", ru: "Приглашённые вами", zh: "您推荐的人" },
  "Email được che một phần để bảo vệ thông tin của họ.": { en: "Emails are partly masked to protect their privacy.", ru: "Адреса частично скрыты для защиты их данных.", zh: "邮箱已部分隐藏以保护对方隐私。" },
  "Ngày đăng ký": { en: "Signed up", ru: "Дата регистрации", zh: "注册日期" },
  "Số giao dịch": { en: "Transactions", ru: "Покупок", zh: "交易笔数" },
  "Hoa hồng": { en: "Commission", ru: "Комиссия", zh: "佣金" },
  "Chưa có ai đăng ký bằng mã của bạn.": { en: "Nobody has signed up with your code yet.", ru: "По вашему коду пока никто не зарегистрировался.", zh: "还没有人使用您的推荐码注册。" },

  // ── Bảng "Lịch sử hoa hồng" ──
  "Lịch sử hoa hồng": { en: "Commission history", ru: "История комиссии", zh: "佣金记录" },
  "Hiển thị 200 khoản gần nhất.": { en: "Showing the 200 most recent entries.", ru: "Показаны 200 последних начислений.", zh: "显示最近 200 条。" },
  "Từ người": { en: "From", ru: "От кого", zh: "来自" },
  "Giá trị giao dịch": { en: "Transaction value", ru: "Сумма покупки", zh: "交易金额" },
  "Tỷ lệ": { en: "Rate", ru: "Ставка", zh: "比例" },
  "Chưa có khoản hoa hồng nào.": { en: "No commission yet.", ru: "Начислений пока нет.", zh: "暂无佣金记录。" },
  "Rút được": { en: "Withdrawable", ru: "Доступно", zh: "可提现" },
  "Vượt trần": { en: "Over cap", ru: "Сверх лимита", zh: "超出上限" },
  "chạm trần": { en: "capped", ru: "лимит", zh: "已达上限" },

  // ── Bảng "Lịch sử rút tiền" ──
  "Lịch sử rút tiền": { en: "Withdrawal history", ru: "История выводов", zh: "提现记录" },
  "Thời điểm gửi": { en: "Requested at", ru: "Время запроса", zh: "申请时间" },
  "Tài khoản nhận": { en: "Receiving account", ru: "Счёт получателя", zh: "收款账户" },
  "Ghi chú của admin": { en: "Admin note", ru: "Примечание администратора", zh: "管理员备注" },
  "Bạn chưa gửi yêu cầu rút nào.": { en: "You have not requested any withdrawal yet.", ru: "Вы ещё не отправляли запросов на вывод.", zh: "您还没有提交过提现申请。" },
  "Đang chờ admin xử lý": { en: "Waiting for an admin", ru: "Ожидает администратора", zh: "等待管理员处理" },
  // 'Chờ duyệt' và 'Bị từ chối' CỐ Ý KHÔNG khai lại ở đây - hai khoá đó đã có sẵn bên trên
  // (dòng ~2251 và ~2053) với đúng nghĩa này. Khai lần hai là ghi đè lặng lẽ bản của trang
  // khác; applyI18n chỉ cần MỘT khoá là dịch được pill ở bảng này.
  "Đã chi": { en: "Paid", ru: "Выплачено", zh: "已支付" },

  // ── Modal "Yêu cầu rút hoa hồng" ──
  "Yêu cầu rút hoa hồng": { en: "Request a commission withdrawal", ru: "Запрос на вывод комиссии", zh: "申请提现佣金" },
  // ⚠️ KHOÁ CHẾT từ 2026-10-20: user bỏ dòng phụ "Số dư có thể rút: …" dưới tiêu đề modal. GIỮ
  // LẠI chứ không dọn - dòng này đã bị thêm/bỏ một lượt rồi, và khoá i18n ở đây CHÍNH LÀ chuỗi
  // tiếng Việt, nên nếu lượt sau cần lại mà thiếu khoá thì en/ru/zh sẽ IN TIẾNG VIỆT, không lỗi,
  // không log, chỉ sai. `_diag-i18n-coverage.js` có thể liệt nó là khoá chết: ĐÚNG, bỏ qua.
  "Số dư có thể rút: {0}": { en: "Withdrawable balance: {0}", ru: "Доступно к выводу: {0}", zh: "可提现余额：{0}" },
  "Số tiền": { en: "Amount", ru: "Сумма", zh: "金额" },
  "Tối thiểu {0}": { en: "Minimum {0}", ru: "Минимум {0}", zh: "最低 {0}" },
  "Ngân hàng": { en: "Bank", ru: "Банк", zh: "银行" },
  "Ví dụ: Vietcombank": { en: "e.g. Vietcombank", ru: "например, Vietcombank", zh: "例如：Vietcombank" },
  "Số tài khoản": { en: "Account number", ru: "Номер счёта", zh: "账号" },
  "Số tài khoản nhận tiền": { en: "Account number to receive the money", ru: "Номер счёта для получения денег", zh: "收款账号" },
  "Chủ tài khoản": { en: "Account holder", ru: "Владелец счёта", zh: "账户持有人" },
  // 2026-10-20: ĐỔI khoá, bỏ "(không dấu)" (user chốt). Khác ca "Số dư có thể rút: {0}" ngay
  // trên: ở đây chuỗi cũ không còn tồn tại trong mã nguồn nào nên xoá hẳn, giữ lại là một bản
  // dịch của câu sẽ không bao giờ hiện lên.
  "Tên chủ tài khoản": { en: "Account holder name", ru: "Имя владельца счёта", zh: "账户持有人姓名" },
  "Ghi chú cho người duyệt (tuỳ chọn)": { en: "Note for the reviewer (optional)", ru: "Примечание для проверяющего (необязательно)", zh: "给审核人的备注（可选）" },
  // 'Gửi yêu cầu' cũng đã có khoá ở phần đăng nhập (dòng ~99, "Send request") - không khai lại.
  "Khi gửi yêu cầu, số tiền sẽ được tạm giữ và trừ khỏi số dư có thể rút.": { en: "When you submit, the amount is held and deducted from your withdrawable balance.", ru: "После отправки сумма удерживается и вычитается из доступного баланса.", zh: "提交后该金额将被冻结，并从可提现余额中扣除。" },
  "Yêu cầu được admin kiểm duyệt thủ công. Nếu bị từ chối, tiền sẽ trả lại số dư có thể rút.": { en: "Requests are reviewed manually by an admin. If rejected, the money returns to your withdrawable balance.", ru: "Запросы проверяются администратором вручную. При отказе деньги вернутся на доступный баланс.", zh: "申请由管理员人工审核。若被拒绝，款项将退回可提现余额。" },
  "Mỗi lần chỉ gửi được một yêu cầu. Hãy kiểm tra kỹ số tài khoản trước khi gửi.": { en: "Only one request at a time. Double-check the account number before submitting.", ru: "Только один запрос за раз. Проверьте номер счёта перед отправкой.", zh: "一次只能提交一笔申请。提交前请仔细核对账号。" },
  "Đã gửi yêu cầu rút {0}. Chờ admin duyệt.": { en: "Withdrawal request for {0} submitted. Awaiting admin review.", ru: "Запрос на вывод {0} отправлен. Ожидает проверки администратором.", zh: "已提交 {0} 的提现申请，等待管理员审核。" },

  // ── Modal ở trạng thái "CHƯA ĐỦ ĐIỀU KIỆN" (thêm 2026-10-20) ──
  // Nút "Rút tiền" nay luôn bấm được; nếu còn vướng thì modal hiện tiêu đề dưới đây + câu lý do
  // (câu lý do DÙNG LẠI các khoá đã có ở trên: 'Cần tối thiểu {0} mới gửi được yêu cầu rút.',
  // 'Chương trình hoa hồng đang tạm dừng…', 'Bạn còn một yêu cầu rút…', 'Cần ít nhất {0} người…')
  // rồi một bảng số CỤ THỂ gồm mấy nhãn ngắn dưới đây.
  // ⚠️ Mấy khoá này cũng phải có trong web landing (public/i18n.js) - cùng bản dịch, vì
  // `withdrawBlock()` ở hai bên PHẢI ra cùng một câu. Đổi một bên thì đổi cả hai.
  "Chưa thể gửi yêu cầu rút": { en: "Can't request a withdrawal yet", ru: "Запрос на вывод пока невозможен", zh: "暂时无法申请提现" },
  // ⚠️ KHÁC khoá "Số dư có thể rút: {0}" ở dòng ~2877 (khoá chết của dòng phụ cũ dưới tiêu đề):
  // khoá dưới đây KHÔNG có dấu hai chấm và KHÔNG có {0} vì nó là NHÃN của một hàng hai cột, số
  // tiền nằm ở ô bên phải. Đừng gộp hai khoá lại - gộp là mất chỗ một trong hai.
  "Số dư có thể rút": { en: "Withdrawable balance", ru: "Доступно к выводу", zh: "可提现余额" },
  "Yêu cầu đang chờ": { en: "Pending request", ru: "Запрос в обработке", zh: "待处理的申请" },
  "Đã gửi lúc": { en: "Submitted at", ru: "Отправлен", zh: "提交时间" },
  "Mức tối thiểu": { en: "Minimum", ru: "Минимум", zh: "最低金额" },
  // ⚠️ KHÔNG trùng "Còn thiếu {0}" (dòng ~2684, trang Nâng cấp gói): bản đó là CẢ CÂU một text
  // node nên applyI18n không bao giờ khớp bản trần này, và ngược lại. Hai khoá khác nhau thật.
  "Còn thiếu": { en: "Short by", ru: "Не хватает", zh: "还差" },
  "Đã có phát sinh giao dịch": { en: "Made a purchase", ru: "Совершили покупку", zh: "已产生交易" },
  "Cần tối thiểu": { en: "Minimum required", ru: "Требуется минимум", zh: "至少需要" },
  // Khoá CÓ {0} nên chuỗi hiện trên màn hình ("23 người") không bao giờ khớp khoá ⇒ applyI18n
  // không thể quét-và-đổi bừa chữ 'người' ở các trang khác. ĐỪNG tách thành khoá 'người' trần.
  "{0} người": { en: "{0} people", ru: "{0} чел.", zh: "{0} 人" },

  // ── Lỗi / trạng thái của trang ──
  "Đang tải dữ liệu hoa hồng...": { en: "Loading commission data...", ru: "Загрузка данных о комиссии...", zh: "正在加载佣金数据…" },
  "Không tải được dữ liệu hoa hồng": { en: "Could not load the commission data", ru: "Не удалось загрузить данные о комиссии", zh: "无法加载佣金数据" },
  "Gửi yêu cầu rút thất bại": { en: "Could not submit the withdrawal request", ru: "Не удалось отправить запрос на вывод", zh: "提交提现申请失败" },
  "Chương trình hoa hồng đang tạm dừng": { en: "The commission program is paused", ru: "Партнёрская программа приостановлена", zh: "佣金计划已暂停" },
  "Hiện chưa ghi nhận hoa hồng mới và chưa gửi được yêu cầu rút. Số dư đã có vẫn được giữ nguyên.": { en: "No new commission is being recorded and withdrawals cannot be requested. Your existing balance is kept intact.", ru: "Новая комиссия не начисляется, запросы на вывод недоступны. Имеющийся баланс сохраняется.", zh: "目前不再记录新佣金，也无法申请提现。已有余额会完整保留。" },
  "Chương trình hoa hồng đang tạm dừng. Số dư của bạn vẫn được giữ nguyên.": { en: "The commission program is paused. Your balance is kept intact.", ru: "Партнёрская программа приостановлена. Ваш баланс сохраняется.", zh: "佣金计划已暂停。您的余额会完整保留。" },
  "Vui lòng điền đủ tên ngân hàng, số tài khoản và tên chủ tài khoản.": { en: "Please fill in the bank name, account number and account holder name.", ru: "Укажите название банка, номер счёта и имя владельца счёта.", zh: "请填写银行名称、账号和账户持有人姓名。" },
  "Số tiền rút tối thiểu là {0}.": { en: "The minimum withdrawal amount is {0}.", ru: "Минимальная сумма вывода - {0}.", zh: "最低提现金额为 {0}。" },
  "Số tiền rút vượt quá số dư có thể rút.": { en: "The amount exceeds your withdrawable balance.", ru: "Сумма превышает доступный к выводу баланс.", zh: "提现金额超过可提现余额。" },
  "Bạn còn một yêu cầu rút đang chờ duyệt. Vui lòng đợi duyệt xong rồi gửi yêu cầu mới.": { en: "You already have a withdrawal request pending. Please wait until it is reviewed before submitting a new one.", ru: "У вас уже есть запрос на вывод на проверке. Дождитесь решения, прежде чем отправлять новый.", zh: "您已有一笔待审的提现申请。请等待审核完成后再提交新的申请。" },
  "Cần ít nhất {0} người được giới thiệu đã phát sinh giao dịch mới được rút.": { en: "You need at least {0} referred people who have made a transaction before you can withdraw.", ru: "Для вывода нужно минимум {0} приглашённых, совершивших покупку.", zh: "至少需要 {0} 位已产生交易的被推荐人才能提现。" },

};

let currentLang = 'vi';

// Per-node memory of the authored (Vietnamese) values so `vi` and repeat applies
// are lossless. Keyed by the Text node / Element itself.
const origText = new WeakMap();   // Text node   -> original nodeValue
const origAttr = new WeakMap();   // Element      -> { title?, placeholder? }
const lastWrite = new WeakMap();  // Text node   -> the exact value WE last wrote
const origVal = new WeakMap();    // <input>      -> original .value (opt-in display inputs)
const lastWriteVal = new WeakMap();// <input>     -> the exact .value WE last wrote

export function getLang() { return currentLang; }

// Ngày tháng phải theo ĐỊNH DẠNG của ngôn ngữ đang chọn, không chỉ dịch chữ. Để nguyên
// 'vi-VN' thì "31/7/2026" hiện giữa giao diện tiếng Anh sẽ bị đọc thành 31 tháng 7 → đúng,
// nhưng "7/3/2026" thì người Mỹ đọc là 3 tháng 7 còn người Việt đọc 7 tháng 3 → SAI NGÀY.
// Vì vậy phải map sang locale tương ứng.
const DATE_LOCALE = { vi: 'vi-VN', en: 'en-US', ru: 'ru-RU', zh: 'zh-CN' };
export function fmtDate(ts) {
  if (ts == null || ts === '') return '';
  const d = ts instanceof Date ? ts : new Date(ts);
  if (Number.isNaN(d.getTime())) return '';
  return d.toLocaleDateString(DATE_LOCALE[currentLang] || 'vi-VN');
}

// Dấu câu KHÁC NHAU giữa các hệ chữ: tiếng Trung dùng dấu liệt kê 、 dấu phẩy toàn phần，
// dấu chấm 。 và dấu hai chấm ：. Ghép câu bằng dấu phẩy ASCII trong giao diện tiếng Trung
// là lỗi chính tả (nhìn thấy rõ vì chữ Hán rộng gấp đôi dấu ASCII).
const PUNCT = {
  vi: { list: ', ', dot: '.', dash: ' - ' },
  en: { list: ', ', dot: '.', dash: ' - ' },
  ru: { list: ', ', dot: '.', dash: ' - ' },
  zh: { list: '、', dot: '。', dash: '：' },
};
export function punct() { return PUNCT[currentLang] || PUNCT.vi; }

export function setLang(lang) {
  currentLang = SUPPORTED.has(lang) ? lang : 'vi';
  // Keep dynamically-rendered UI (datagrid rows, combobox dropdowns, modals,
  // toasts…) translated: run a MutationObserver only while a non-Vietnamese
  // language is active. Vietnamese (default) pays zero observer cost.
  if (currentLang === 'vi') stopObserver();
  else startObserver();
}

function lookup(key) {
  const entry = DICT[key];
  if (!entry) return null;
  return entry[currentLang] || null;
}

// Direct translator for code that renders text imperatively (e.g. into an input
// .value). Returns the translation for the active language, or the original
// Vietnamese string unchanged when there's no entry / language is Vietnamese.
export function t(key) {
  if (key == null) return key;
  if (currentLang === 'vi') return key;
  const hit = lookup(String(key).trim());
  return hit == null ? key : hit;
}

// Parameterized translator for strings that embed runtime values (counts, names,
// versions…). The PATTERN carries numbered placeholders {0}, {1}, … and lives in
// the DICT keyed on its exact Vietnamese form. `tf` looks the pattern up like
// `t`, then substitutes the args back in - so "Đã chọn {0}/{1}" translates while
// still rendering the live numbers. Falls back to the Vietnamese pattern when no
// entry exists / language is Vietnamese. Because the result is a finished string
// (no longer a DICT key), such text is produced at the ACTIVE language at build
// time; ephemeral UI (toasts/dialogs) is fine, and views re-render on nav.
export function tf(pattern, ...args) {
  const out = t(pattern);
  return String(out).replace(/\{(\d+)\}/g, (_, i) => {
    const v = args[Number(i)];
    return v == null ? '' : String(v);
  });
}

// Translate one Text node, preserving its surrounding whitespace so layout that
// relies on leading/trailing spaces is untouched.
function applyTextNode(node) {
  const raw = node.nodeValue;
  if (!raw) return;
  let original = origText.get(node);
  const mine = lastWrite.get(node);
  if (original === undefined) {
    if (!raw.trim()) return; // whitespace-only: nothing to ever translate
    original = raw;
    origText.set(node, original);
  } else if (mine !== undefined && raw !== mine && raw !== original) {
    // The app re-rendered this same node with new (Vietnamese) text after we had
    // translated it - treat the new value as the fresh source of truth.
    original = raw;
    origText.set(node, original);
  }
  if (currentLang === 'vi') {
    if (node.nodeValue !== original) node.nodeValue = original;
    lastWrite.delete(node);
    return;
  }
  const key = original.trim();
  const t = lookup(key);
  if (t == null) {
    if (node.nodeValue !== original) node.nodeValue = original;
    lastWrite.delete(node);
    return;
  }
  const lead = original.match(/^\s*/)[0];
  const trail = original.match(/\s*$/)[0];
  const out = lead + t + trail;
  if (node.nodeValue !== out) node.nodeValue = out;
  lastWrite.set(node, out);
}

function applyAttr(elm, attr) {
  const raw = elm.getAttribute(attr);
  let store = origAttr.get(elm);
  if (!store) { store = {}; origAttr.set(elm, store); }
  if (store[attr] === undefined) {
    if (raw == null || !raw.trim()) { store[attr] = raw; }
    else store[attr] = raw;
  }
  const original = store[attr];
  if (original == null || !String(original).trim()) return;
  if (currentLang === 'vi') { if (raw !== original) elm.setAttribute(attr, original); return; }
  const t = lookup(String(original).trim());
  if (t == null) { if (raw !== original) elm.setAttribute(attr, original); return; }
  if (raw !== t) elm.setAttribute(attr, t);
}

// Translate the custom tooltip text. The shared tooltip (ui.js installTooltips)
// moves an element's `title` into `data-tip` on first hover and REMOVES `title`,
// so applyAttr('title') can no longer keep it in sync on a later language switch.
// Here we re-translate `data-tip` directly, preferring the title's captured
// Vietnamese original as the source (data-tip was cloned from title) so switching
// RU→EN etc. resolves from the authored string rather than an already-translated one.
function applyTipAttr(elm) {
  const raw = elm.getAttribute('data-tip');
  if (raw == null) return;
  let store = origAttr.get(elm);
  if (!store) { store = {}; origAttr.set(elm, store); }
  // Source of truth: the title's original if we captured one before the tooltip
  // stripped it; otherwise capture data-tip's first-seen value once.
  let original = store.title;
  if (original === undefined || original == null || !String(original).trim()) {
    if (store._tip === undefined) store._tip = raw;
    original = store._tip;
  }
  if (original == null || !String(original).trim()) return;
  if (currentLang === 'vi') { if (raw !== original) elm.setAttribute('data-tip', original); return; }
  const tr = lookup(String(original).trim());
  if (tr == null) { if (raw !== original) elm.setAttribute('data-tip', original); return; }
  if (raw !== tr) elm.setAttribute('data-tip', tr);
}

// Translate the DISPLAYED .value of an opt-in input (class `pc-i18n-val`), e.g.
// the combobox trigger that shows the currently-selected option label as an
// <input> value (not a text node). Only inputs the app explicitly marks are
// touched, so real search/text fields the user types into are never altered.
function applyInputValue(input) {
  if (!input) return;
  // A combobox trigger clears its .value while OPEN (so the user can type to
  // filter). Never read/rewrite/recapture it in that state - doing so would
  // capture the intentional empty string as the new "original" and blank the
  // trigger after selection. Leave open/focused inputs entirely alone; they get
  // re-translated by renderTrigger()'s applyI18n(combo) once closed.
  const combo = input.closest && input.closest('.pc-select');
  if ((combo && combo.classList.contains('open')) || document.activeElement === input) return;
  const raw = input.value;
  let original = origVal.get(input);
  const mine = lastWriteVal.get(input);
  // Trigger bị xoá RỖNG có chủ ý (vd bấm "Đặt lại" → combo.value='') và combobox đang
  // ĐÓNG (đã qua guard mở/focus ở trên) ⇒ trạng thái placeholder. XOÁ bộ nhớ bản gốc để
  // chế độ tiếng Việt không kéo nhãn đã chọn trước đó về lại (giữ ô trống cho placeholder).
  if (!raw || !raw.trim()) {
    if (original !== undefined) origVal.delete(input);
    lastWriteVal.delete(input);
    return;
  }
  if (original === undefined) {
    original = raw;
    origVal.set(input, original);
  } else if (raw !== original && raw !== mine) {
    // Giá trị hiển thị đã đổi sang thứ KHÔNG phải bản dịch ta ghi (mine) → đây là lựa
    // chọn MỚI (người dùng chọn option, hoặc code set combo.value). Nhận nó làm "bản
    // gốc" mới để chế độ tiếng Việt không kéo ngược về nhãn đầu tiên (vd luôn về "Tất cả").
    // Ở tiếng Việt mine luôn undefined nên nhánh cũ (mine!==undefined) không bao giờ chạy.
    original = raw;
    origVal.set(input, original);
  }
  if (currentLang === 'vi') {
    if (input.value !== original) input.value = original;
    lastWriteVal.delete(input);
    return;
  }
  const t = lookup(original.trim());
  if (t == null) {
    if (input.value !== original) input.value = original;
    lastWriteVal.delete(input);
    return;
  }
  if (input.value !== t) input.value = t;
  lastWriteVal.set(input, t);
}

const SKIP_TAGS = new Set(['SCRIPT', 'STYLE', 'TEXTAREA', 'CODE', 'PRE']);

// Walk `root` (default document.body) translating text nodes + title/placeholder
// attributes. Idempotent: safe to call repeatedly and on already-translated DOM.
export function applyI18n(root) {
  root = root || document.body;
  if (!root) return;
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode(n) {
      if (!n.nodeValue || !n.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
      const p = n.parentNode;
      if (p && p.nodeName && SKIP_TAGS.has(p.nodeName)) return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    },
  });
  const nodes = [];
  let n;
  while ((n = walker.nextNode())) nodes.push(n);
  nodes.forEach(applyTextNode);

  // aria-label đi kèm title ở nhiều nút chỉ-có-icon (vd bong bóng hỗ trợ). Không quét thì trình
  // đọc màn hình đọc tiếng Việt giữa giao diện ngoại ngữ. applyAttr là hàm chung (lưu bản gốc
  // theo TÊN thuộc tính) nên chỉ cần thêm vào danh sách; chuỗi lạ không có trong DICT giữ nguyên.
  const attrEls = root.querySelectorAll('[title], [placeholder], [aria-label], [data-tip]');
  attrEls.forEach((elm) => {
    if (elm.hasAttribute('title')) applyAttr(elm, 'title');
    if (elm.hasAttribute('placeholder')) applyAttr(elm, 'placeholder');
    if (elm.hasAttribute('aria-label')) applyAttr(elm, 'aria-label');
    if (elm.hasAttribute('data-tip')) applyTipAttr(elm);
  });
  // Opt-in display inputs (combobox trigger etc.) whose selected label lives in
  // `.value` rather than a text node.
  root.querySelectorAll('input.pc-i18n-val').forEach(applyInputValue);
  if (root.nodeType === 1) {
    if (root.hasAttribute && root.hasAttribute('title')) applyAttr(root, 'title');
    if (root.hasAttribute && root.hasAttribute('placeholder')) applyAttr(root, 'placeholder');
    if (root.hasAttribute && root.hasAttribute('aria-label')) applyAttr(root, 'aria-label');
    if (root.hasAttribute && root.hasAttribute('data-tip')) applyTipAttr(root);
    if (root.matches && root.matches('input.pc-i18n-val')) applyInputValue(root);
  }
  // Safety net: if a non-Vietnamese language is active but the observer hasn't
  // started yet (e.g. setLang ran before document.body existed at boot), start
  // it now that we clearly have live DOM.
  if (currentLang !== 'vi') startObserver();
}

// ---------------------------------------------------------------------------
// Live coverage of dynamically-rendered DOM.
//
// applyI18n() only visits the DOM that exists when it runs. Datagrid rows drawn
// on scroll/sort/filter, combobox dropdowns opened on demand, modals, menus and
// toasts are all created LATER - so a single applyI18n() call after navigate
// leaves them in Vietnamese. A MutationObserver re-translates any subtree the
// app adds (and any text a component rewrites in place) while a non-Vietnamese
// language is active.
// ---------------------------------------------------------------------------
let observer = null;
let applying = false;          // re-entrancy guard: ignore our own mutations
const pending = new Set();     // nodes awaiting (batched) translation
let scheduled = false;

function flushPending() {
  scheduled = false;
  if (currentLang === 'vi') { pending.clear(); return; }
  const roots = [...pending];
  pending.clear();
  applying = true;
  try {
    for (const node of roots) {
      if (!node || !node.isConnected) continue;
      if (node.nodeType === 3) applyTextNode(node);       // Text node
      else if (node.nodeType === 1) applyI18n(node);      // Element subtree
    }
  } finally {
    // Discard the mutation records our own writes just generated so the
    // observer does not re-process (and loop on) them.
    if (observer) observer.takeRecords();
    applying = false;
  }
}

function schedule() {
  if (scheduled) return;
  scheduled = true;
  const raf = (typeof requestAnimationFrame === 'function')
    ? requestAnimationFrame
    : (cb) => setTimeout(cb, 16);
  raf(flushPending);
}

function startObserver() {
  if (observer || typeof MutationObserver === 'undefined') return;
  if (typeof document === 'undefined' || !document.body) return;
  observer = new MutationObserver((mutations) => {
    if (applying) return;
    for (const m of mutations) {
      if (m.type === 'childList') {
        m.addedNodes.forEach((n) => {
          if (n.nodeType === 1 || n.nodeType === 3) pending.add(n);
        });
      } else if (m.type === 'characterData') {
        pending.add(m.target);
      } else if (m.type === 'attributes' && m.target && m.target.nodeType === 1) {
        pending.add(m.target);
      }
    }
    if (pending.size) schedule();
  });
  observer.observe(document.body, {
    childList: true,
    subtree: true,
    characterData: true,
    attributes: true,
    attributeFilter: ['title', 'placeholder', 'aria-label', 'data-tip'],
  });
}

function stopObserver() {
  if (!observer) return;
  observer.disconnect();
  observer = null;
  pending.clear();
  scheduled = false;
}
