'use strict';

const { app, BrowserWindow, ipcMain, shell, dialog, screen } = require('electron');
const path = require('node:path');
const fs = require('node:fs');
const http = require('node:http');
const shortcuts = require('../src/core/shortcuts');

app.commandLine.appendSwitch('disable-features', 'PasswordCheck,PasswordBreachDetection,AutofillServerCommunication');
app.commandLine.appendSwitch('disable-save-password-bubble');

// Free GPU & DWM compositor for launched Chromium profiles (PolyLogin optimization)
try { app.disableHardwareAcceleration(); } catch {}
if (process.platform === 'win32') {
  try { app.setAppUserModelId('com.cgtmedia.cgtlogin'); } catch {}
}

let mainWindow = null;
let consoleWindow = null;
let pendingOpenProfile = shortcuts.parseOpenProfile(process.argv);
const API_PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 51888;
const APP_ICON = path.join(__dirname, '..', 'app.ico');

function checkServerReady(port) {
  return new Promise((resolve) => {
    const req = http.get(`http://127.0.0.1:${port}/api/v1/status`, (res) => {
      resolve(res.statusCode === 200);
    });
    req.on('error', () => resolve(false));
    req.setTimeout(1000, () => {
      req.destroy();
      resolve(false);
    });
  });
}

async function ensureBackendRunning() {
  const isUp = await checkServerReady(API_PORT);
  if (!isUp) {
    console.log(`[Electron] Starting internal CGT-Login v2.0 Core on port ${API_PORT}...`);
    const serverModule = require('../src/server');
    const config = require('../src/config');
    const license = require('../src/license-manager');
    const db = require('../src/db');

    config.ensureDirectories();
    db.getDb();
    await license.initLicense();
    await serverModule.startServer(API_PORT);
  }
}

async function triggerPendingProfileOpen(profileId) {
  if (!profileId) return;
  try {
    const launcher = require('../src/launcher');
    await launcher.startProfile(profileId);
  } catch (err) {
    console.warn(`[Electron] Shortcut auto-open failed for ${profileId}:`, err.message);
  }
}

async function createWindow() {
  await ensureBackendRunning();

  mainWindow = new BrowserWindow({
    width: 1360,
    height: 860,
    minWidth: 1024,
    minHeight: 660,
    title: 'CGT-Login Antidetect Workstation',
    icon: fs.existsSync(APP_ICON) ? APP_ICON : undefined,
    backgroundColor: '#0f172a',
    autoHideMenuBar: true,
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  });

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    mainWindow.focus();
    if (pendingOpenProfile) {
      const id = pendingOpenProfile;
      pendingOpenProfile = '';
      triggerPendingProfileOpen(id);
      try { mainWindow.webContents.send('shortcut:open-profile', id); } catch {}
    }
  });

  setTimeout(() => {
    if (mainWindow && !mainWindow.isVisible()) {
      mainWindow.show();
      mainWindow.focus();
    }
  }, 1500);

  try {
    await mainWindow.loadURL(`http://127.0.0.1:${API_PORT}`);
  } catch {
    await mainWindow.loadFile(path.join(__dirname, '../public/index.html')).catch(() => {});
  }

  mainWindow.on('closed', () => {
    mainWindow = null;
    if (consoleWindow && !consoleWindow.isDestroyed()) {
      try { consoleWindow.close(); } catch {}
    }
  });
}

// Detached Floating Action-Sync Console Window (500px Always-on-Top)
function openSyncConsole(profileIds = []) {
  if (consoleWindow && !consoleWindow.isDestroyed()) {
    consoleWindow.focus();
    return { ok: true };
  }
  const primary = screen.getPrimaryDisplay().workArea;
  consoleWindow = new BrowserWindow({
    width: 500,
    height: 360,
    minWidth: 500,
    maxWidth: 500,
    minHeight: 96,
    x: Math.max(0, primary.x + primary.width - 520),
    y: primary.y + 24,
    frame: false,
    alwaysOnTop: true,
    skipTaskbar: true,
    minimizable: false,
    resizable: true,
    icon: fs.existsSync(APP_ICON) ? APP_ICON : undefined,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  });

  const q = Array.isArray(profileIds) && profileIds.length ? `?syncConsole=1&ids=${encodeURIComponent(profileIds.join(','))}` : '?syncConsole=1';
  consoleWindow.loadURL(`http://127.0.0.1:${API_PORT}/${q}`).catch(() => {});
  consoleWindow.on('closed', () => { consoleWindow = null; });
  return { ok: true };
}

// IPC Handlers
ipcMain.on('window:minimize', () => { if (mainWindow) mainWindow.minimize(); });
ipcMain.on('window:maximize', () => {
  if (mainWindow) {
    if (mainWindow.isMaximized()) mainWindow.unmaximize();
    else mainWindow.maximize();
  }
});
ipcMain.on('window:close', () => { if (mainWindow) mainWindow.close(); });
ipcMain.on('app:ready', () => {
  if (mainWindow && !mainWindow.isVisible()) {
    mainWindow.show();
    mainWindow.focus();
  }
});

ipcMain.on('app:openExternal', (_e, url) => {
  if (url && (url.startsWith('http://') || url.startsWith('https://'))) {
    shell.openExternal(url);
  }
});

ipcMain.on('app:openPath', async (_e, targetPath) => {
  if (targetPath) {
    try { await shell.openPath(targetPath); } catch {}
  }
});

ipcMain.on('app:showItemInFolder', (_e, targetPath) => {
  if (targetPath) {
    try {
      const fullPath = path.isAbsolute(targetPath) ? targetPath : path.resolve(process.cwd(), targetPath);
      shell.showItemInFolder(fullPath);
    } catch {}
  }
});

ipcMain.on('app:versionSync', (e) => { e.returnValue = app.getVersion(); });
ipcMain.handle('app:version', () => app.getVersion());

ipcMain.handle('shortcut:takePendingOpen', () => {
  const id = pendingOpenProfile;
  pendingOpenProfile = '';
  return id;
});

ipcMain.handle('dialog:openDirectory', async (_e, opts = {}) => {
  if (!mainWindow) return null;
  const result = await dialog.showOpenDialog(mainWindow, {
    title: opts.title || 'Chọn thư mục',
    properties: ['openDirectory'],
  });
  return (!result.canceled && result.filePaths?.[0]) ? result.filePaths[0] : null;
});

ipcMain.handle('dialog:openFile', async (_e, opts = {}) => {
  if (!mainWindow) return null;
  const result = await dialog.showOpenDialog(mainWindow, {
    title: opts.title || 'Chọn tệp',
    filters: opts.filters || undefined,
    properties: ['openFile'],
  });
  return (!result.canceled && result.filePaths?.[0]) ? result.filePaths[0] : null;
});

ipcMain.handle('dialog:saveExport', async (_e, defaultName, content) => {
  if (!mainWindow) return { ok: false, canceled: true };
  const res = await dialog.showSaveDialog(mainWindow, {
    defaultPath: defaultName || 'export.json',
  });
  if (res.canceled || !res.filePath) return { ok: false, canceled: true };
  try {
    if (Buffer.isBuffer(content) || content instanceof Uint8Array) {
      fs.writeFileSync(res.filePath, Buffer.from(content));
    } else {
      fs.writeFileSync(res.filePath, String(content ?? ''), 'utf8');
    }
    return { ok: true, path: res.filePath };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});

ipcMain.handle('console:open', (_e, ids) => openSyncConsole(ids));
ipcMain.handle('console:close', () => {
  if (consoleWindow && !consoleWindow.isDestroyed()) consoleWindow.close();
  consoleWindow = null;
  return { ok: true };
});
ipcMain.handle('console:resize', (_e, h) => {
  if (consoleWindow && !consoleWindow.isDestroyed() && Number.isFinite(h)) {
    const bounds = consoleWindow.getBounds();
    consoleWindow.setBounds({ x: bounds.x, y: bounds.y, width: 500, height: Math.max(96, Math.round(h)) });
  }
});
ipcMain.handle('console:focus', () => {
  if (consoleWindow && !consoleWindow.isDestroyed()) consoleWindow.focus();
});

// Single-Instance Lock + Desktop Shortcut Handling
const gotTheLock = app.requestSingleInstanceLock();
if (!gotTheLock) {
  app.quit();
} else {
  app.on('second-instance', (_e, argv) => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
    const id = shortcuts.parseOpenProfile(argv);
    if (id) {
      triggerPendingProfileOpen(id);
      if (mainWindow && !mainWindow.isDestroyed()) {
        try { mainWindow.webContents.send('shortcut:open-profile', id); } catch {}
      }
    }
  });

  app.whenReady().then(createWindow);

  app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') app.quit();
  });

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });

  app.on('before-quit', async () => {
    try {
      const launcher = require('../src/launcher');
      await launcher.stopAllProfiles(2000);
    } catch {}
  });
}
