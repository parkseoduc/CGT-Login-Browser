'use strict';

const { contextBridge, ipcRenderer } = require('electron');

let appVersion = '3.1.0';
try {
  appVersion = ipcRenderer.sendSync('app:versionSync') || '3.1.0';
} catch {}

// Legacy bridge preserved 100% for backward compatibility
contextBridge.exposeInMainWorld('electronAPI', {
  isElectron: true,
  minimize: () => ipcRenderer.send('window:minimize'),
  maximize: () => ipcRenderer.send('window:maximize'),
  close: () => ipcRenderer.send('window:close'),
  openExternal: (url) => ipcRenderer.send('app:openExternal', url),
  openPath: (p) => ipcRenderer.send('app:openPath', p),
  showItemInFolder: (p) => ipcRenderer.send('app:showItemInFolder', p),
  getVersion: () => ipcRenderer.invoke('app:version'),
  openDirectory: () => ipcRenderer.invoke('dialog:openDirectory'),
});

// CGT-Login v2.0 Native Bridge (matches docs/CORE_UI_CONTRACT_V2.md)
contextBridge.exposeInMainWorld('cgt', {
  isElectron: true,
  appVersion,
  win: {
    minimize: () => ipcRenderer.send('window:minimize'),
    maximizeToggle: () => ipcRenderer.send('window:maximize'),
    close: () => ipcRenderer.send('window:close'),
    ready: () => ipcRenderer.send('app:ready'),
  },
  dialog: {
    openFolder: (opts) => ipcRenderer.invoke('dialog:openDirectory', opts),
    openFile: (opts) => ipcRenderer.invoke('dialog:openFile', opts),
    saveExport: (defaultName, content) => ipcRenderer.invoke('dialog:saveExport', defaultName, content),
  },
  shell: {
    openExternal: (url) => ipcRenderer.send('app:openExternal', url),
    openPath: (p) => ipcRenderer.send('app:openPath', p),
    showItemInFolder: (p) => ipcRenderer.send('app:showItemInFolder', p),
  },
  shortcuts: {
    takePendingOpen: () => ipcRenderer.invoke('shortcut:takePendingOpen'),
    onOpenProfile: (cb) => {
      const h = (_e, id) => cb(id);
      ipcRenderer.on('shortcut:open-profile', h);
      return () => ipcRenderer.removeListener('shortcut:open-profile', h);
    },
  },
  syncConsole: {
    open: (profileIds) => ipcRenderer.invoke('console:open', profileIds),
    close: () => ipcRenderer.invoke('console:close'),
    resize: (height) => ipcRenderer.invoke('console:resize', height),
    focus: () => ipcRenderer.invoke('console:focus'),
  },
});
