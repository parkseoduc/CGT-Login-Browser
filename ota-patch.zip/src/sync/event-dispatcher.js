'use strict';

/**
 * Action Synchronizer v2.0 - Smart Event Dispatcher
 * Dispatches Smart Element-Relative Clicks, Hover Moves, Proportional Scroll,
 * Vietnamese IME text, Selection Ranges, and Keyboard events onto Slave CDP sessions.
 */
class EventDispatcher {
  static async resolveSmartCoords(client, session, data) {
    let vpW = session.width || 1920;
    let vpH = session.height || 1080;

    if (data.sel) {
      try {
        const res = await client.send('Runtime.evaluate', {
          expression: `(() => {
            const w = window.innerWidth || 1920;
            const h = window.innerHeight || 1080;
            const el = document.querySelector(${JSON.stringify(data.sel)});
            if (!el) return { w, h, hit: false };
            const r = el.getBoundingClientRect();
            if (!r || r.width <= 0 || r.height <= 0) return { w, h, hit: false };
            return { w, h, hit: true, left: r.left, top: r.top, rw: r.width, rh: r.height };
          })()`,
          returnByValue: true,
        }, session.sessionId, 1200);
        const val = res?.result?.value;
        if (val) {
          session.width = vpW = val.w || vpW;
          session.height = vpH = val.h || vpH;
          if (val.hit) {
            const ox = typeof data.ox === 'number' ? data.ox : 0.5;
            const oy = typeof data.oy === 'number' ? data.oy : 0.5;
            return {
              x: Math.round(val.left + ox * val.rw),
              y: Math.round(val.top + oy * val.rh),
            };
          }
        }
      } catch {}
    }

    const nx = typeof data.nx === 'number' ? data.nx : ((data.x || 0) / (data.w || vpW));
    const ny = typeof data.ny === 'number' ? data.ny : ((data.y || 0) / (data.h || vpH));
    return {
      x: Math.round(nx * vpW),
      y: Math.round(ny * vpH),
    };
  }

  static async dispatchEvent(client, session, eventObj) {
    if (!client || !client.ws || client.ws.readyState !== 1 || !session || !session.sessionId) {
      return false;
    }

    const { type, data } = eventObj;
    const sessionId = session.sessionId;

    try {
      if (type === 'mousemove') {
        const targetX = Math.round((data.nx || 0) * (session.width || 1920));
        const targetY = Math.round((data.ny || 0) * (session.height || 1080));
        client.send('Input.dispatchMouseEvent', {
          type: 'mouseMoved',
          x: targetX,
          y: targetY,
          buttons: data.buttons || 0,
          modifiers: data.modifiers || 0,
        }, sessionId, 800).catch(() => {});
        return true;
      }

      if (type === 'mouse') {
        const { x: targetX, y: targetY } = await EventDispatcher.resolveSmartCoords(client, session, data);
        await client.send('Input.dispatchMouseEvent', {
          type: 'mouseMoved',
          x: targetX,
          y: targetY,
          modifiers: data.modifiers || 0,
        }, sessionId, 1200).catch(() => {});

        await client.send('Input.dispatchMouseEvent', {
          type: data.eventType,
          x: targetX,
          y: targetY,
          button: data.button || 'left',
          buttons: data.eventType === 'mousePressed' ? (data.buttons || 1) : 0,
          clickCount: data.clickCount || 1,
          modifiers: data.modifiers || 0,
        }, sessionId, 1200).catch(() => {});
        return true;
      }

      if (type === 'scroll') {
        const fx = Number(data.fx || 0);
        const fy = Number(data.fy || 0);
        client.send('Runtime.evaluate', {
          expression: `(() => {
            const doc = document.scrollingElement || document.documentElement;
            if (!doc) return;
            const maxX = Math.max(0, doc.scrollWidth - window.innerWidth);
            const maxY = Math.max(0, doc.scrollHeight - window.innerHeight);
            window.scrollTo({ left: Math.round(${fx} * maxX), top: Math.round(${fy} * maxY), behavior: 'instant' });
          })()`,
        }, sessionId, 800).catch(() => {});
        return true;
      }

      if (type === 'wheel') {
        const ratioX = (data.x || 0) / (data.w || session.width || 1920);
        const ratioY = (data.y || 0) / (data.h || session.height || 1080);
        await client.send('Input.dispatchMouseEvent', {
          type: 'mouseWheel',
          x: Math.round(ratioX * (session.width || 1920)),
          y: Math.round(ratioY * (session.height || 1080)),
          deltaX: data.deltaX || 0,
          deltaY: data.deltaY || 0,
        }, sessionId, 1200).catch(() => {});
        return true;
      }

      if (type === 'ime' && data.text) {
        await client.send('Input.insertText', { text: String(data.text) }, sessionId, 1500).catch(() => {});
        return true;
      }

      if (type === 'field' && data.sel && typeof data.start === 'number' && typeof data.end === 'number') {
        client.send('Runtime.evaluate', {
          expression: `(() => {
            const el = document.querySelector(${JSON.stringify(data.sel)});
            if (el && typeof el.setSelectionRange === 'function') {
              el.focus();
              el.setSelectionRange(${data.start}, ${data.end}, ${JSON.stringify(data.dir || 'none')});
            }
          })()`,
        }, sessionId, 800).catch(() => {});
        return true;
      }

      if (type === 'key') {
        await client.send('Input.dispatchKeyEvent', {
          type: data.eventType,
          key: data.key,
          code: data.code,
          windowsVirtualKeyCode: data.windowsVirtualKeyCode,
          nativeVirtualKeyCode: data.nativeVirtualKeyCode,
          text: data.text,
          unmodifiedText: data.unmodifiedText,
          modifiers: data.modifiers || 0,
        }, sessionId, 1500).catch(() => {});

        if (data.eventType === 'rawKeyDown' && data.text) {
          await client.send('Input.dispatchKeyEvent', {
            type: 'char',
            text: data.text,
            unmodifiedText: data.unmodifiedText,
            key: data.key,
            code: data.code,
          }, sessionId, 1500).catch(() => {});
        }
        return true;
      }

      if (type === 'nav' && data.url) {
        await client.send('Page.navigate', { url: data.url }, sessionId, 3000).catch(() => {});
        return true;
      }
    } catch {
      return false;
    }

    return false;
  }
}

module.exports = EventDispatcher;
