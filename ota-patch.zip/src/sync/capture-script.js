'use strict';

/**
 * Action Synchronizer v2.0 - Client-side DOM Event Capture Script (modeled after PolyLogin)
 * Captures:
 *  - Smart CSS-path element coordinates (ox, oy) + normalized viewport coords (nx, ny)
 *  - Idle mouse hover movement (~120Hz gated)
 *  - Vietnamese / CJK IME composition (compositionstart / compositionend)
 *  - Input/textarea focus & selection range tracking (`field`)
 *  - Proportional scroll position (`fx`, `fy` in [0..1]) + wheel
 */
function getCaptureScript() {
  return `
    (() => {
      if (window.__omniSyncInstalled) return;
      Object.defineProperty(window, '__omniSyncInstalled', { value: true, enumerable: false });

      function sendSync(type, data) {
        try {
          if (typeof window.__omniSyncEvent === 'function') {
            window.__omniSyncEvent(JSON.stringify({ type, data, ts: Date.now() }));
          }
        } catch (e) {}
      }

      function cssPath(el) {
        try {
          if (!el || el.nodeType !== 1) return '';
          if (el.id && /^[A-Za-z][\\w-]*$/.test(el.id)) return '#' + CSS.escape(el.id);
          const parts = [];
          let cur = el;
          let depth = 0;
          while (cur && cur.nodeType === 1 && cur !== document.documentElement && depth < 6) {
            let seg = cur.tagName.toLowerCase();
            if (cur.id && /^[A-Za-z][\\w-]*$/.test(cur.id)) {
              parts.unshift('#' + CSS.escape(cur.id));
              break;
            }
            const nameAttr = cur.getAttribute('name');
            if (nameAttr && (seg === 'input' || seg === 'textarea' || seg === 'select')) {
              seg += '[name="' + CSS.escape(nameAttr) + '"]';
            } else if (cur.parentElement) {
              const siblings = Array.from(cur.parentElement.children).filter(c => c.tagName === cur.tagName);
              if (siblings.length > 1) {
                seg += ':nth-of-type(' + (siblings.indexOf(cur) + 1) + ')';
              }
            }
            parts.unshift(seg);
            cur = cur.parentElement;
            depth++;
          }
          return parts.join(' > ');
        } catch {
          return '';
        }
      }

      function pointerPayload(e, eventType) {
        const w = Math.max(1, window.innerWidth || 1920);
        const h = Math.max(1, window.innerHeight || 1080);
        let sel = '';
        let ox = 0.5;
        let oy = 0.5;
        try {
          const t = e.target && e.target.nodeType === 1 ? e.target : null;
          if (t) {
            const rect = t.getBoundingClientRect();
            if (rect && rect.width > 2 && rect.height > 2) {
              sel = cssPath(t);
              ox = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
              oy = Math.max(0, Math.min(1, (e.clientY - rect.top) / rect.height));
            }
          }
        } catch {}
        return {
          eventType,
          x: e.clientX,
          y: e.clientY,
          nx: e.clientX / w,
          ny: e.clientY / h,
          sel,
          ox,
          oy,
          button: e.button === 0 ? 'left' : (e.button === 1 ? 'middle' : 'right'),
          buttons: e.buttons,
          clickCount: e.detail || 1,
          modifiers: (e.altKey ? 1 : 0) | (e.ctrlKey ? 2 : 0) | (e.metaKey ? 4 : 0) | (e.shiftKey ? 8 : 0),
          w,
          h,
        };
      }

      // 1. Mouse Move (~120Hz gated) & Smart Click/Drag
      let lastMoveTs = 0;
      window.addEventListener('mousemove', (e) => {
        if (!e.isTrusted) return;
        const now = performance.now();
        if (now - lastMoveTs < 8) return;
        lastMoveTs = now;
        const w = Math.max(1, window.innerWidth || 1920);
        const h = Math.max(1, window.innerHeight || 1080);
        sendSync('mousemove', {
          nx: e.clientX / w,
          ny: e.clientY / h,
          buttons: e.buttons || 0,
          modifiers: (e.altKey ? 1 : 0) | (e.ctrlKey ? 2 : 0) | (e.metaKey ? 4 : 0) | (e.shiftKey ? 8 : 0),
        });
      }, { passive: true, capture: true });

      window.addEventListener('mousedown', (e) => {
        if (!e.isTrusted) return;
        sendSync('mouse', pointerPayload(e, 'mousePressed'));
      }, true);

      window.addEventListener('mouseup', (e) => {
        if (!e.isTrusted) return;
        sendSync('mouse', pointerPayload(e, 'mouseReleased'));
      }, true);

      // 2. Proportional Scroll & Wheel
      let scrollPending = false;
      window.addEventListener('scroll', (e) => {
        if (scrollPending) return;
        scrollPending = true;
        requestAnimationFrame(() => {
          scrollPending = false;
          const doc = document.scrollingElement || document.documentElement;
          if (!doc) return;
          const maxX = Math.max(0, doc.scrollWidth - window.innerWidth);
          const maxY = Math.max(0, doc.scrollHeight - window.innerHeight);
          sendSync('scroll', {
            x: window.scrollX,
            y: window.scrollY,
            fx: maxX > 0 ? window.scrollX / maxX : 0,
            fy: maxY > 0 ? window.scrollY / maxY : 0,
          });
        });
      }, { passive: true, capture: true });

      window.addEventListener('wheel', (e) => {
        if (!e.isTrusted) return;
        sendSync('wheel', {
          eventType: 'mouseWheel',
          x: e.clientX,
          y: e.clientY,
          deltaX: e.deltaX,
          deltaY: e.deltaY,
          w: Math.max(1, window.innerWidth || 1920),
          h: Math.max(1, window.innerHeight || 1080),
        });
      }, { passive: true, capture: true });

      // 3. Vietnamese / CJK IME Composition + Keyboard
      let inComposition = false;
      window.addEventListener('compositionstart', () => {
        inComposition = true;
      }, true);

      window.addEventListener('compositionend', (e) => {
        inComposition = false;
        if (e.data) {
          sendSync('ime', { text: e.data });
        }
      }, true);

      window.addEventListener('keydown', (e) => {
        if (!e.isTrusted) return;
        if (inComposition || e.isComposing || e.keyCode === 229) return;
        let text = undefined;
        if (e.key === 'Enter') {
          text = '\\r';
        } else if (e.key.length === 1 && !e.ctrlKey && !e.altKey && !e.metaKey) {
          text = e.key;
        }
        sendSync('key', {
          eventType: 'rawKeyDown',
          key: e.key,
          code: e.code,
          windowsVirtualKeyCode: e.keyCode,
          nativeVirtualKeyCode: e.keyCode,
          text,
          unmodifiedText: text,
          modifiers: (e.altKey ? 1 : 0) | (e.ctrlKey ? 2 : 0) | (e.metaKey ? 4 : 0) | (e.shiftKey ? 8 : 0),
        });
      }, true);

      window.addEventListener('keyup', (e) => {
        if (!e.isTrusted || inComposition || e.isComposing) return;
        sendSync('key', {
          eventType: 'keyUp',
          key: e.key,
          code: e.code,
          windowsVirtualKeyCode: e.keyCode,
          nativeVirtualKeyCode: e.keyCode,
          modifiers: (e.altKey ? 1 : 0) | (e.ctrlKey ? 2 : 0) | (e.metaKey ? 4 : 0) | (e.shiftKey ? 8 : 0),
        });
      }, true);

      // 4. Track Focused Editable Field & Selection Range (for Floating Console text actions)
      function reportField(el) {
        if (!el || el.nodeType !== 1) return;
        const tag = el.tagName.toLowerCase();
        const isEditable = tag === 'input' || tag === 'textarea' || el.isContentEditable;
        if (!isEditable) return;
        const sel = cssPath(el);
        if (!sel) return;
        const payload = { sel };
        if (typeof el.selectionStart === 'number' && typeof el.selectionEnd === 'number') {
          payload.start = el.selectionStart;
          payload.end = el.selectionEnd;
          payload.dir = el.selectionDirection || 'none';
        }
        sendSync('field', payload);
      }

      window.addEventListener('focusin', (e) => reportField(e.target), true);
      document.addEventListener('selectionchange', () => {
        if (document.activeElement) reportField(document.activeElement);
      }, true);

      // 5. SPA URL Change Tracking
      let curHref = window.location.href;
      setInterval(() => {
        if (window.location.href !== curHref) {
          curHref = window.location.href;
          sendSync('nav', { url: curHref });
        }
      }, 450);
    })();
  `;
}

module.exports = { getCaptureScript };
