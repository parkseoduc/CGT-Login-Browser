'use strict';

const { CdpClient } = require('../cdp');
const { getCaptureScript } = require('./capture-script');

class SessionManager {
  static async attachToProfile(profileId, wsEndpoint, isMaster, callbacks = {}) {
    const client = new CdpClient(wsEndpoint);
    await client.connect(3500);

    const conn = {
      profileId,
      client,
      isMaster,
      sessions: new Map(),
    };

    const captureScript = getCaptureScript();

    const setupPageSession = async (targetId, sessionId, url = '', title = '') => {
      try {
        await client.send('Page.enable', {}, sessionId, 2000).catch(() => {});

        // Keep Slave background/occluded tabs fully active & focused without stealing OS foreground
        if (!isMaster) {
          await client.send('Page.setWebLifecycleState', { state: 'active' }, sessionId, 1500).catch(() => {});
          await client.send('Emulation.setFocusEmulationEnabled', { enabled: true }, sessionId, 1500).catch(() => {});
        }

        let width = 1920;
        let height = 1080;
        let visible = true;
        try {
          const evalRes = await client.send('Runtime.evaluate', {
            expression: '({ w: window.innerWidth, h: window.innerHeight, vis: document.visibilityState })',
            returnByValue: true,
          }, sessionId, 1500).catch(() => null);
          if (evalRes?.result?.value) {
            width = evalRes.result.value.w || 1920;
            height = evalRes.result.value.h || 1080;
            visible = evalRes.result.value.vis === 'visible';
          }
        } catch {}

        conn.sessions.set(targetId, {
          targetId,
          sessionId,
          width,
          height,
          visible,
          url: url || '',
          title: title || '',
          lastActive: Date.now(),
        });

        if (isMaster) {
          await client.send('Runtime.enable', {}, sessionId, 2000).catch(() => {});
          await client.send('Runtime.addBinding', { name: '__omniSyncEvent' }, sessionId, 2000).catch(() => {});
          await client.send('Page.addScriptToEvaluateOnNewDocument', { source: captureScript }, sessionId, 2000).catch(() => {});
          await client.send('Runtime.evaluate', { expression: captureScript }, sessionId, 2000).catch(() => {});
        }
      } catch {}
    };

    client.on('Page.javascriptDialogOpening', async () => {
      await client.send('Page.handleJavaScriptDialog', { accept: true }, null, 1500).catch(() => {});
    });

    client.on('Target.attachedToTarget', async (params) => {
      if (params?.targetInfo?.type === 'page') {
        await setupPageSession(params.targetInfo.targetId, params.sessionId, params.targetInfo.url, params.targetInfo.title);
        if (callbacks.onTabCreated) callbacks.onTabCreated(params.targetInfo.url);
      }
    });

    client.on('Target.detachedFromTarget', (params) => {
      if (params?.targetId) {
        conn.sessions.delete(params.targetId);
        if (callbacks.onTabClosed) callbacks.onTabClosed(params.targetId);
      }
    });

    client.on('Target.targetInfoChanged', (params) => {
      if (params?.targetInfo?.targetId) {
        const s = conn.sessions.get(params.targetInfo.targetId);
        if (s) {
          s.url = params.targetInfo.url || s.url;
          s.title = params.targetInfo.title || s.title;
          s.lastActive = Date.now();
        }
      }
    });

    if (isMaster) {
      client.on('Page.frameNavigated', (params) => {
        if (params?.frame && !params.frame.parentId && params.frame.url) {
          const fUrl = params.frame.url;
          if (fUrl && fUrl !== 'about:blank' && !fUrl.startsWith('chrome://') && !fUrl.startsWith('file://')) {
            if (callbacks.onNavigate) callbacks.onNavigate(fUrl);
          }
        }
      });

      client.on('Runtime.bindingCalled', (params) => {
        if (params?.name === '__omniSyncEvent' && callbacks.onSyncEvent) {
          try {
            callbacks.onSyncEvent(JSON.parse(params.payload));
          } catch {}
        }
      });
    }

    await client.send('Target.setAutoAttach', {
      autoAttach: true,
      waitForDebuggerOnStart: false,
      flatten: true,
    }, null, 3000).catch(() => {});

    const targetsRes = await client.send('Target.getTargets', {}, null, 3000).catch(() => ({ targetInfos: [] }));
    const pageTargets = (targetsRes.targetInfos || []).filter((t) => t.type === 'page');

    for (const pt of pageTargets) {
      if (!conn.sessions.has(pt.targetId)) {
        try {
          const attachRes = await client.send('Target.attachToTarget', {
            targetId: pt.targetId,
            flatten: true,
          }, null, 2500);
          if (attachRes?.sessionId) {
            await setupPageSession(pt.targetId, attachRes.sessionId, pt.url, pt.title);
          }
        } catch {}
      }
    }

    return conn;
  }

  static getBestTargetSession(conn) {
    if (!conn || !conn.sessions || conn.sessions.size === 0) return null;
    const list = Array.from(conn.sessions.values()).filter((s) => s && s.sessionId);
    if (!list.length) return null;
    const vis = list.find((s) => s.visible === true);
    if (vis) return vis;
    return [...list].sort((a, b) => (b.lastActive || 0) - (a.lastActive || 0))[0] || list[list.length - 1];
  }

  static closeConnection(conn) {
    if (!conn) return;
    try { if (conn.client) conn.client.close(); } catch {}
    if (conn.sessions) conn.sessions.clear();
  }
}

module.exports = SessionManager;
