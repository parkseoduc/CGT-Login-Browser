'use strict';

const { EventEmitter } = require('node:events');
const launcher = require('./launcher');
const eventBus = require('./core/event-bus');
const SessionManager = require('./sync/session-manager');
const EventDispatcher = require('./sync/event-dispatcher');
const WindowTiler = require('./sync/window-tiler');

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

class Synchronizer extends EventEmitter {
  constructor() {
    super();
    this.isSyncing = false;
    this.masterProfileId = null;
    this.slaveProfileIds = [];
    this.pausedSlaves = new Set();
    this.lastFieldSelector = '';
    this.options = {
      syncMouse: true,
      syncHover: true,
      syncKeyboard: true,
      syncScroll: true,
      syncNav: true,
      humanDelay: false,
      minDelayMs: 5,
      maxDelayMs: 25,
      speed: 180,
    };
    this.metrics = {
      eventsSent: 0,
      mouseEvents: 0,
      keyEvents: 0,
      scrollEvents: 0,
      startedAt: null,
    };

    this.connections = new Map();

    launcher.events.on('profile-stopped', ({ profileId }) => {
      if (!this.isSyncing) return;
      if (profileId === this.masterProfileId) {
        this.stopSync().catch(() => {});
      } else if (this.slaveProfileIds.includes(profileId)) {
        this.removeSlave(profileId);
      }
    });
  }

  getSyncStatus() {
    return {
      success: true,
      ok: true,
      isSyncing: this.isSyncing,
      masterProfileId: this.masterProfileId,
      slaveProfileIds: [...this.slaveProfileIds],
      pausedSlaves: [...this.pausedSlaves],
      activeSlavesCount: this.slaveProfileIds.filter((id) => !this.pausedSlaves.has(id)).length,
      lastFieldSelector: this.lastFieldSelector,
      options: { ...this.options },
      metrics: { ...this.metrics },
    };
  }

  _publishStatus() {
    const st = this.getSyncStatus();
    eventBus.publish('sync:status', st, { cacheSnapshot: true });
    return st;
  }

  async startSync({ masterId, slaveIds = [], options = {} }) {
    if (this.isSyncing) {
      await this.stopSync();
    }

    if (!masterId) {
      throw new Error('Vui lòng chọn 1 cửa sổ Profile làm Master điều khiển');
    }
    if (!launcher.isProfileRunning(masterId)) {
      throw new Error(`Profile Master (${masterId}) hiện không chạy. Vui lòng mở profile trước.`);
    }

    const validSlaveIds = (Array.isArray(slaveIds) ? slaveIds : [])
      .filter((id) => id !== masterId && launcher.isProfileRunning(id));

    if (validSlaveIds.length === 0) {
      throw new Error('Cần ít nhất 1 Profile Slave đang chạy khác với Master để đồng bộ.');
    }

    this.options = { ...this.options, ...options };
    this.masterProfileId = masterId;
    this.slaveProfileIds = validSlaveIds;
    this.pausedSlaves.clear();
    this.lastFieldSelector = '';
    this.metrics = {
      eventsSent: 0,
      mouseEvents: 0,
      keyEvents: 0,
      scrollEvents: 0,
      startedAt: new Date().toISOString(),
    };

    try {
      const masterInfo = launcher.getRunningInfo(masterId);
      if (!masterInfo || !masterInfo.wsEndpoint) {
        throw new Error('Không lấy được cổng kết nối CDP của Master');
      }

      const masterConn = await SessionManager.attachToProfile(masterId, masterInfo.wsEndpoint, true, {
        onSyncEvent: (ev) => {
          if (ev?.type === 'field' && ev.data?.sel) {
            this.lastFieldSelector = ev.data.sel;
          }
          this._broadcastToSlaves(ev);
        },
        onNavigate: (url) => this._broadcastToSlaves({ type: 'nav', data: { url } }),
        onTabCreated: (url) => {
          if (this.isSyncing) this._broadcastToSlaves({ type: 'tab-create', data: { url: url || 'about:blank' } });
        },
        onTabClosed: (targetId) => {
          if (this.isSyncing) this._broadcastToSlaves({ type: 'tab-close', data: { targetId } });
        },
      });
      this.connections.set(masterId, masterConn);

      for (const slaveId of validSlaveIds) {
        try {
          const sInfo = launcher.getRunningInfo(slaveId);
          if (sInfo && sInfo.wsEndpoint) {
            const sConn = await SessionManager.attachToProfile(slaveId, sInfo.wsEndpoint, false);
            this.connections.set(slaveId, sConn);
          }
        } catch (err) {
          console.warn(`[Synchronizer] Could not connect to slave ${slaveId}:`, err.message);
        }
      }

      if (this.connections.size <= 1) {
        throw new Error('Không thể thiết lập kết nối đồng bộ tới Profile Slave nào.');
      }

      this.isSyncing = true;
      const st = this._publishStatus();
      this.emit('sync-started', st);
      return st;
    } catch (err) {
      await this.stopSync();
      throw err;
    }
  }

  async stopSync() {
    if (!this.isSyncing && this.connections.size === 0) {
      return { success: true, ok: true, message: 'Sync was not active' };
    }

    this.isSyncing = false;
    for (const conn of this.connections.values()) {
      SessionManager.closeConnection(conn);
    }
    this.connections.clear();
    const prevMaster = this.masterProfileId;
    this.masterProfileId = null;
    this.slaveProfileIds = [];
    this.pausedSlaves.clear();

    this._publishStatus();
    this.emit('sync-stopped', { masterProfileId: prevMaster });
    return { success: true, ok: true };
  }

  setOptions(patch = {}) {
    this.options = { ...this.options, ...patch };
    return this._publishStatus();
  }

  pauseSlave(slaveId, paused = true) {
    if (paused) this.pausedSlaves.add(slaveId);
    else this.pausedSlaves.delete(slaveId);
    return this._publishStatus();
  }

  async setMaster(newMasterId) {
    if (!this.isSyncing) throw new Error('Chưa có phiên đồng bộ nào đang chạy');
    if (newMasterId === this.masterProfileId) return this.getSyncStatus();
    const allIds = [this.masterProfileId, ...this.slaveProfileIds].filter(Boolean);
    if (!allIds.includes(newMasterId)) {
      throw new Error('Hồ sơ không nằm trong nhóm đang đồng bộ');
    }
    const nextSlaves = allIds.filter((id) => id !== newMasterId);
    return await this.startSync({
      masterId: newMasterId,
      slaveIds: nextSlaves,
      options: this.options,
    });
  }

  removeSlave(slaveId) {
    this.slaveProfileIds = this.slaveProfileIds.filter((id) => id !== slaveId);
    this.pausedSlaves.delete(slaveId);
    const conn = this.connections.get(slaveId);
    if (conn) {
      SessionManager.closeConnection(conn);
      this.connections.delete(slaveId);
    }
    this._publishStatus();
    if (this.slaveProfileIds.length === 0) {
      this.stopSync().catch(() => {});
    }
  }

  async _broadcastToSlaves(eventObj) {
    if (!this.isSyncing || this.slaveProfileIds.length === 0) return;
    const { type, data } = eventObj;

    if (type === 'mouse' && !this.options.syncMouse) return;
    if (type === 'mousemove' && (!this.options.syncMouse || !this.options.syncHover)) return;
    if ((type === 'wheel' || type === 'scroll') && !this.options.syncScroll) return;
    if ((type === 'key' || type === 'ime') && !this.options.syncKeyboard) return;
    if (type === 'nav' && !this.options.syncNav) return;

    this.metrics.eventsSent++;
    if (type === 'mouse') this.metrics.mouseEvents++;
    else if (type === 'key' || type === 'ime') this.metrics.keyEvents++;
    else if (type === 'wheel' || type === 'scroll') this.metrics.scrollEvents++;

    for (const slaveId of this.slaveProfileIds) {
      if (this.pausedSlaves.has(slaveId)) continue;
      const conn = this.connections.get(slaveId);
      if (!conn || !conn.client || conn.client.ws?.readyState !== 1) continue;

      if (type === 'tab-create') {
        conn.client.send('Target.createTarget', { url: data.url || 'about:blank' }, null, 2500).catch(() => {});
        continue;
      }

      if (type === 'tab-close') {
        const sessionsList = Array.from(conn.sessions.values());
        if (sessionsList.length > 1) {
          const lastSession = sessionsList[sessionsList.length - 1];
          conn.client.send('Target.closeTarget', { targetId: lastSession.targetId }, null, 2500).catch(() => {});
        }
        continue;
      }

      const targetSession = SessionManager.getBestTargetSession(conn);
      if (!targetSession) continue;

      const dispatch = () => {
        EventDispatcher.dispatchEvent(conn.client, targetSession, eventObj);
      };

      if (this.options.humanDelay && type !== 'mousemove' && type !== 'scroll') {
        const delay = Math.floor(Math.random() * (this.options.maxDelayMs - this.options.minDelayMs + 1)) + this.options.minDelayMs;
        setTimeout(dispatch, delay);
      } else {
        dispatch();
      }
    }
  }

  _activeConnections(includeMaster = true) {
    const ids = [];
    if (includeMaster && this.masterProfileId) ids.push(this.masterProfileId);
    for (const id of this.slaveProfileIds) {
      if (!this.pausedSlaves.has(id)) ids.push(id);
    }
    return ids.map((id) => ({ id, conn: this.connections.get(id) })).filter((x) => x.conn);
  }

  async _focusLastField(client, sessionId) {
    if (!this.lastFieldSelector) return;
    await client.send('Runtime.evaluate', {
      expression: `(() => {
        const el = document.querySelector(${JSON.stringify(this.lastFieldSelector)});
        if (el && typeof el.focus === 'function') el.focus();
      })()`,
    }, sessionId, 1000).catch(() => {});
  }

  /**
   * Type identical text like a human across Master + active Slaves (±40% natural cadence jitter).
   */
  async typeText(text, speedMs = null) {
    const str = String(text ?? '');
    if (!str) return { ok: true, count: 0 };
    const targets = this._activeConnections(true);
    const baseDelay = Math.max(40, Number(speedMs || this.options.speed || 160));

    await Promise.all(targets.map(async ({ conn }) => {
      const s = SessionManager.getBestTargetSession(conn);
      if (!s) return;
      await this._focusLastField(conn.client, s.sessionId);
      for (const ch of Array.from(str)) {
        await conn.client.send('Input.insertText', { text: ch }, s.sessionId, 1500).catch(() => {});
        const jitter = Math.round(baseDelay * (0.6 + Math.random() * 0.8));
        await sleep(jitter);
      }
    }));

    return { ok: true, count: targets.length };
  }

  /**
   * Type DIFFERENT designated text per window (`[{ id, text }]`).
   */
  async typePerWindow(assignments = [], speedMs = null) {
    if (!Array.isArray(assignments) || !assignments.length) return { ok: true, count: 0 };
    const baseDelay = Math.max(35, Number(speedMs || this.options.speed || 140));

    await Promise.all(assignments.map(async ({ id, text }) => {
      if (!id || text == null || this.pausedSlaves.has(id)) return;
      const conn = this.connections.get(id);
      const s = SessionManager.getBestTargetSession(conn);
      if (!s) return;
      await this._focusLastField(conn.client, s.sessionId);
      for (const ch of Array.from(String(text))) {
        await conn.client.send('Input.insertText', { text: ch }, s.sessionId, 1500).catch(() => {});
        await sleep(Math.round(baseDelay * (0.6 + Math.random() * 0.8)));
      }
    }));

    return { ok: true, count: assignments.length };
  }

  async pasteText(text) {
    const str = String(text ?? '');
    const targets = this._activeConnections(true);
    await Promise.all(targets.map(async ({ conn }) => {
      const s = SessionManager.getBestTargetSession(conn);
      if (!s) return;
      await this._focusLastField(conn.client, s.sessionId);
      await conn.client.send('Input.insertText', { text: str }, s.sessionId, 1500).catch(() => {});
    }));
    return { ok: true, count: targets.length };
  }

  /**
   * Clear focused / remembered input field cleanly (works on React/Vue controlled inputs via native setter).
   */
  async clearText() {
    const targets = this._activeConnections(true);
    const selJson = JSON.stringify(this.lastFieldSelector || '');
    await Promise.all(targets.map(async ({ conn }) => {
      const s = SessionManager.getBestTargetSession(conn);
      if (!s) return;
      await conn.client.send('Runtime.evaluate', {
        expression: `(() => {
          const el = (${selJson} && document.querySelector(${selJson})) || document.activeElement;
          if (!el) return false;
          el.focus();
          if (el.isContentEditable) {
            el.textContent = '';
          } else {
            const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
            const desc = Object.getOwnPropertyDescriptor(proto, 'value');
            if (desc && desc.set) desc.set.call(el, '');
            else el.value = '';
          }
          el.dispatchEvent(new Event('input', { bubbles: true }));
          el.dispatchEvent(new Event('change', { bubbles: true }));
          return true;
        })()`,
      }, s.sessionId, 1500).catch(() => {});
    }));
    return { ok: true, count: targets.length };
  }

  /**
   * Batch Tab utilities across synced windows: `open` | `closeCurrent` | `closeOthers` | `closeBlank` | `resync`.
   */
  async controlTabs({ action, urls = [], sameTab = false } = {}) {
    const targets = this._activeConnections(true);
    if (action === 'open') {
      const cleanUrls = (Array.isArray(urls) ? urls : [urls]).map((u) => String(u || '').trim()).filter(Boolean);
      await Promise.all(targets.map(async ({ conn }) => {
        for (let i = 0; i < cleanUrls.length; i++) {
          const u = /^https?:\/\//i.test(cleanUrls[i]) ? cleanUrls[i] : `https://${cleanUrls[i]}`;
          if (sameTab && i === 0) {
            const s = SessionManager.getBestTargetSession(conn);
            if (s) {
              await conn.client.send('Page.navigate', { url: u }, s.sessionId, 2500).catch(() => {});
              continue;
            }
          }
          await conn.client.send('Target.createTarget', { url: u }, null, 2500).catch(() => {});
        }
      }));
      return { ok: true };
    }

    if (action === 'closeCurrent') {
      await Promise.all(targets.map(async ({ conn }) => {
        if (conn.sessions.size <= 1) return;
        const s = SessionManager.getBestTargetSession(conn);
        if (s) await conn.client.send('Target.closeTarget', { targetId: s.targetId }, null, 2000).catch(() => {});
      }));
      return { ok: true };
    }

    if (action === 'closeOthers') {
      await Promise.all(targets.map(async ({ conn }) => {
        const keep = SessionManager.getBestTargetSession(conn);
        for (const s of conn.sessions.values()) {
          if (keep && s.targetId !== keep.targetId) {
            await conn.client.send('Target.closeTarget', { targetId: s.targetId }, null, 2000).catch(() => {});
          }
        }
      }));
      return { ok: true };
    }

    if (action === 'closeBlank') {
      await Promise.all(targets.map(async ({ conn }) => {
        const list = Array.from(conn.sessions.values());
        for (const s of list) {
          if (conn.sessions.size <= 1) break;
          if (!s.url || s.url === 'about:blank' || s.url.startsWith('chrome://newtab')) {
            await conn.client.send('Target.closeTarget', { targetId: s.targetId }, null, 2000).catch(() => {});
          }
        }
      }));
      return { ok: true };
    }

    if (action === 'resync' && this.masterProfileId) {
      const mConn = this.connections.get(this.masterProfileId);
      const mSession = SessionManager.getBestTargetSession(mConn);
      if (mSession && mSession.url) {
        await this._broadcastToSlaves({ type: 'nav', data: { url: mSession.url } });
      }
      return { ok: true };
    }

    return { ok: false, error: `Unknown tab action: ${action}` };
  }

  async arrangeWindows(profileIds = [], layout = 'grid', opts = {}) {
    const ids = Array.isArray(profileIds) && profileIds.length
      ? profileIds
      : (this.isSyncing ? [this.masterProfileId, ...this.slaveProfileIds].filter(Boolean) : []);
    return launcher.arrangeProfileWindows(ids, layout, { uniformCells: true, ...opts });
  }

  async tileWindows(params = {}) {
    if (params.layout || params.multiMonitor) {
      return this.arrangeWindows(params.profileIds || [], params.layout || 'grid', params);
    }
    return WindowTiler.tile(params);
  }
}

const synchronizer = new Synchronizer();
module.exports = synchronizer;
