'use strict';

const crypto = require('node:crypto');
const kernelManager = require('./core/kernel-manager');

const CHROME_BUILDS = {
  153: ['153.0.7993.0', '153.0.7993.42', '153.0.7993.68'],
  152: ['152.0.7940.112', '152.0.7940.88'],
  151: ['151.0.7901.95', '151.0.7901.64'],
  150: ['150.0.7871.187', '150.0.7871.130', '150.0.7871.116', '150.0.7871.49'],
  149: ['149.0.7827.201', '149.0.7827.158', '149.0.7827.116'],
  148: ['148.0.7778.218', '148.0.7778.181', '148.0.7778.98'],
  147: ['147.0.7727.139', '147.0.7727.119'],
  146: ['146.0.7680.180', '146.0.7680.155'],
  145: ['145.0.7632.162', '145.0.7632.119'],
  144: ['144.0.7559.135', '144.0.7559.112'],
  142: ['142.0.7444.177', '142.0.7444.136'],
  140: ['140.0.7339.264', '140.0.7339.210', '140.0.7339.187', '140.0.7339.129'],
  138: ['138.0.7204.185', '138.0.7204.159'],
  136: ['136.0.7103.177', '136.0.7103.116'],
  134: ['134.0.6998.179', '134.0.6998.119'],
  132: ['132.0.6834.197', '132.0.6834.162'],
  130: ['130.0.6723.119', '130.0.6723.117', '130.0.6723.93'],
};

const OS_PRESETS = {
  windows: {
    platform: 'Win32',
    oscpu: 'Windows NT 10.0; Win64; x64',
    appVersion: '5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36',
    userAgentTemplate: (majorOrVer) => {
      const maj = String(majorOrVer || '153').split('.')[0];
      return `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${maj}.0.0.0 Safari/537.36`;
    },
    firefoxUaTemplate: (ver) => `Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:${ver}) Gecko/20100101 Firefox/${ver}`,
    clientHintsPlatform: 'Windows',
    clientHintsPlatformVersion: '15.0.0', // Windows 11 WICG spec
    architecture: 'x86',
    bitness: '64',
    mobile: false,
    maxTouchPoints: 0,
  },
  mac: {
    platform: 'MacIntel',
    oscpu: 'Intel Mac OS X 10_15_7',
    appVersion: '5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36',
    userAgentTemplate: (majorOrVer) => {
      const maj = String(majorOrVer || '153').split('.')[0];
      return `Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${maj}.0.0.0 Safari/537.36`;
    },
    firefoxUaTemplate: (ver) => `Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:${ver}) Gecko/20100101 Firefox/${ver}`,
    clientHintsPlatform: 'macOS',
    clientHintsPlatformVersion: '14.5.0',
    architecture: 'arm',
    bitness: '64',
    mobile: false,
    maxTouchPoints: 0,
  },
  linux: {
    platform: 'Linux x86_64',
    oscpu: 'Linux x86_64',
    appVersion: '5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36',
    userAgentTemplate: (majorOrVer) => {
      const maj = String(majorOrVer || '153').split('.')[0];
      return `Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${maj}.0.0.0 Safari/537.36`;
    },
    firefoxUaTemplate: (ver) => `Mozilla/5.0 (X11; Linux x86_64; rv:${ver}) Gecko/20100101 Firefox/${ver}`,
    clientHintsPlatform: 'Linux',
    clientHintsPlatformVersion: '6.5.0',
    architecture: 'x86',
    bitness: '64',
    mobile: false,
    maxTouchPoints: 0,
  },
  android: {
    platform: 'Linux armv81',
    oscpu: 'Linux aarch64',
    appVersion: '5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Mobile Safari/537.36',
    userAgentTemplate: (majorOrVer) => {
      const maj = String(majorOrVer || '153').split('.')[0];
      return `Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${maj}.0.0.0 Mobile Safari/537.36`;
    },
    firefoxUaTemplate: (ver) => `Mozilla/5.0 (Android 14; Mobile; rv:${ver}) Gecko/${ver} Firefox/${ver}`,
    clientHintsPlatform: 'Android',
    clientHintsPlatformVersion: '14.0.0',
    architecture: '',
    bitness: '',
    model: 'SM-S928B',
    mobile: true,
    maxTouchPoints: 5,
  },
  ios: {
    platform: 'iPhone',
    oscpu: 'iPhone OS 17_5 like Mac OS X',
    appVersion: '5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/153.0.7993.0 Mobile/15E148 Safari/604.1',
    userAgentTemplate: (fullVer) => `Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/${fullVer || '153.0.7993.0'} Mobile/15E148 Safari/604.1`,
    firefoxUaTemplate: (ver) => `Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) FxiOS/${ver} Mobile/15E148 Safari/605.1.15`,
    clientHintsPlatform: 'iOS',
    clientHintsPlatformVersion: '17.5.0',
    architecture: '',
    bitness: '',
    model: 'iPhone',
    mobile: true,
    maxTouchPoints: 5,
  },
};

const WEBGL_RENDERERS = [
  {
    vendor: 'Google Inc. (NVIDIA)',
    renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 4070 (0x00002786) Direct3D11 vs_5_0 ps_5_0, D3D11)',
    unmaskedVendor: 'Google Inc. (NVIDIA)',
    unmaskedRenderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 4070 (0x00002786) Direct3D11 vs_5_0 ps_5_0, D3D11)',
  },
  {
    vendor: 'Google Inc. (NVIDIA)',
    renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 (0x00002504) Direct3D11 vs_5_0 ps_5_0, D3D11)',
    unmaskedVendor: 'Google Inc. (NVIDIA)',
    unmaskedRenderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 (0x00002504) Direct3D11 vs_5_0 ps_5_0, D3D11)',
  },
  {
    vendor: 'Google Inc. (NVIDIA)',
    renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 3080 (0x00002206) Direct3D11 vs_5_0 ps_5_0, D3D11)',
    unmaskedVendor: 'Google Inc. (NVIDIA)',
    unmaskedRenderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 3080 (0x00002206) Direct3D11 vs_5_0 ps_5_0, D3D11)',
  },
  {
    vendor: 'Google Inc. (NVIDIA)',
    renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 4060 (0x00002882) Direct3D11 vs_5_0 ps_5_0, D3D11)',
    unmaskedVendor: 'Google Inc. (NVIDIA)',
    unmaskedRenderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 4060 (0x00002882) Direct3D11 vs_5_0 ps_5_0, D3D11)',
  },
  {
    vendor: 'Google Inc. (AMD)',
    renderer: 'ANGLE (AMD, AMD Radeon RX 6700 XT (0x000073DF) Direct3D11 vs_5_0 ps_5_0, D3D11)',
    unmaskedVendor: 'Google Inc. (AMD)',
    unmaskedRenderer: 'ANGLE (AMD, AMD Radeon RX 6700 XT (0x000073DF) Direct3D11 vs_5_0 ps_5_0, D3D11)',
  },
  {
    vendor: 'Google Inc. (Intel)',
    renderer: 'ANGLE (Intel, Intel(R) Iris(R) Xe Graphics (0x00009A49) Direct3D11 vs_5_0 ps_5_0, D3D11)',
    unmaskedVendor: 'Google Inc. (Intel)',
    unmaskedRenderer: 'ANGLE (Intel, Intel(R) Iris(R) Xe Graphics (0x00009A49) Direct3D11 vs_5_0 ps_5_0, D3D11)',
  },
  {
    vendor: 'Google Inc. (NVIDIA)',
    renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 4090 (0x00002684) Direct3D11 vs_5_0 ps_5_0, D3D11)',
    unmaskedVendor: 'Google Inc. (NVIDIA)',
    unmaskedRenderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 4090 (0x00002684) Direct3D11 vs_5_0 ps_5_0, D3D11)',
  },
  {
    vendor: 'Google Inc. (NVIDIA)',
    renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 3070 (0x00002484) Direct3D11 vs_5_0 ps_5_0, D3D11)',
    unmaskedVendor: 'Google Inc. (NVIDIA)',
    unmaskedRenderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 3070 (0x00002484) Direct3D11 vs_5_0 ps_5_0, D3D11)',
  },
  {
    vendor: 'Google Inc. (NVIDIA)',
    renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 2060 (0x00001F08) Direct3D11 vs_5_0 ps_5_0, D3D11)',
    unmaskedVendor: 'Google Inc. (NVIDIA)',
    unmaskedRenderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 2060 (0x00001F08) Direct3D11 vs_5_0 ps_5_0, D3D11)',
  },
  {
    vendor: 'Google Inc. (NVIDIA)',
    renderer: 'ANGLE (NVIDIA, NVIDIA GeForce GTX 1660 SUPER (0x000021C4) Direct3D11 vs_5_0 ps_5_0, D3D11)',
    unmaskedVendor: 'Google Inc. (NVIDIA)',
    unmaskedRenderer: 'ANGLE (NVIDIA, NVIDIA GeForce GTX 1660 SUPER (0x000021C4) Direct3D11 vs_5_0 ps_5_0, D3D11)',
  },
  {
    vendor: 'Google Inc. (AMD)',
    renderer: 'ANGLE (AMD, AMD Radeon RX 7800 XT (0x0000747E) Direct3D11 vs_5_0 ps_5_0, D3D11)',
    unmaskedVendor: 'Google Inc. (AMD)',
    unmaskedRenderer: 'ANGLE (AMD, AMD Radeon RX 7800 XT (0x0000747E) Direct3D11 vs_5_0 ps_5_0, D3D11)',
  },
  {
    vendor: 'Google Inc. (AMD)',
    renderer: 'ANGLE (AMD, AMD Radeon RX 6600 (0x000073FF) Direct3D11 vs_5_0 ps_5_0, D3D11)',
    unmaskedVendor: 'Google Inc. (AMD)',
    unmaskedRenderer: 'ANGLE (AMD, AMD Radeon RX 6600 (0x000073FF) Direct3D11 vs_5_0 ps_5_0, D3D11)',
  },
  {
    vendor: 'Google Inc. (Intel)',
    renderer: 'ANGLE (Intel, Intel(R) UHD Graphics 770 (0x00004680) Direct3D11 vs_5_0 ps_5_0, D3D11)',
    unmaskedVendor: 'Google Inc. (Intel)',
    unmaskedRenderer: 'ANGLE (Intel, Intel(R) UHD Graphics 770 (0x00004680) Direct3D11 vs_5_0 ps_5_0, D3D11)',
  },
  {
    vendor: 'Google Inc. (Intel)',
    renderer: 'ANGLE (Intel, Intel(R) UHD Graphics 630 (0x00003E92) Direct3D11 vs_5_0 ps_5_0, D3D11)',
    unmaskedVendor: 'Google Inc. (Intel)',
    unmaskedRenderer: 'ANGLE (Intel, Intel(R) UHD Graphics 630 (0x00003E92) Direct3D11 vs_5_0 ps_5_0, D3D11)',
  },
  {
    vendor: 'Apple',
    renderer: 'ANGLE (Apple, ANGLE Metal Renderer: Apple M2 Pro, Unspecified Version)',
    unmaskedVendor: 'Google Inc. (Apple)',
    unmaskedRenderer: 'ANGLE (Apple, ANGLE Metal Renderer: Apple M2 Pro, Unspecified Version)',
  },
  {
    vendor: 'Qualcomm',
    renderer: 'Adreno (TM) 750',
    unmaskedVendor: 'Qualcomm',
    unmaskedRenderer: 'Adreno (TM) 750',
  },
];

const RESOLUTIONS = [
  { width: 1920, height: 1080, name: '1920 x 1080 (FHD)' },
  { width: 1536, height: 864, name: '1536 x 864 (Laptop standard)' },
  { width: 1440, height: 900, name: '1440 x 900 (MacBook standard)' },
  { width: 1366, height: 768, name: '1366 x 768 (Compact laptop)' },
  { width: 2560, height: 1440, name: '2560 x 1440 (2K QHD)' },
];

const CPU_CORES = [4, 6, 8, 12, 16, 24];
// Giới hạn giá trị RAM theo chuẩn W3C Device Memory API (0.25, 0.5, 1, 2, 4, 8 GB)
// Tránh lỗi "non-standard value" trên các hệ thống kiểm tra bot như BrowserLeaks
const RAM_SIZES = [4, 8];

// PCI Device ID -> Dawn WebGPU architecture mapping (ported from PolyLogin)
const GPU_ARCH_BY_DEVICE = [
  ['nvidia', 'maxwell', [[0x1300, 0x14ff], [0x1600, 0x17ff]]],
  ['nvidia', 'pascal', [[0x1500, 0x15ff], [0x1b00, 0x1dff]]],
  ['nvidia', 'turing', [[0x1e00, 0x1fff], [0x2100, 0x21ff]]],
  ['nvidia', 'ampere', [[0x2000, 0x20ff], [0x2200, 0x25ff]]],
  ['nvidia', 'lovelace', [[0x2600, 0x28ff]]],
  ['nvidia', 'blackwell', [[0x2900, 0x2fff]]],
  ['amd', 'rdna-1', [[0x7310, 0x736f]]],
  ['amd', 'rdna-2', [[0x73a0, 0x743f]]],
  ['amd', 'rdna-3', [[0x7440, 0x749f]]],
  ['intel', 'gen-9', [[0x1900, 0x19ff], [0x5900, 0x59ff], [0x3e00, 0x3eff], [0x9b00, 0x9bff]]],
  ['intel', 'gen-12lp', [[0x9a00, 0x9aff], [0x4600, 0x46ff], [0xa700, 0xa7ff]]],
  ['intel', 'xe-lpg', [[0x7d00, 0x7dff]]],
];

function webgpuFromRenderer(renderer, webglVendor) {
  const raw = String(renderer || '').trim();
  if (!raw) return null;

  let vendorTok = '';
  let gpu = raw;
  const angle = raw.match(/^ANGLE \((.*)\)$/s);
  if (angle) {
    const inner = angle[1];
    const first = inner.indexOf(', ');
    vendorTok = first > 0 ? inner.slice(0, first) : '';
    const rest = first > 0 ? inner.slice(first + 2) : inner;
    const last = rest.lastIndexOf(', ');
    gpu = last > 0 ? rest.slice(0, last) : rest;
  }
  const metal = gpu.match(/^ANGLE Metal Renderer:\s*(.*)$/i);
  if (metal) gpu = metal[1];

  let device = '';
  const idm = gpu.match(/\s*\(0x([0-9a-f]{1,8})\)/i);
  if (idm) {
    device = '0x' + parseInt(idm[1], 16).toString(16);
    gpu = gpu.replace(idm[0], '');
  }
  const desc = gpu
    .replace(/\s+Direct3D(?:9Ex|11|12)?\s+vs_\d_\d\s+ps_\d_\d.*$/i, '')
    .replace(/\s+OpenGL Engine$/i, '')
    .trim();

  const h = `${vendorTok} ${desc} ${webglVendor || ''}`.toLowerCase();
  const vendor = /nvidia|geforce|quadro/.test(h) ? 'nvidia'
    : /\bamd\b|radeon/.test(h) ? 'amd'
      : /intel/.test(h) ? 'intel'
        : /qualcomm|adreno/.test(h) ? 'qualcomm'
          : /apple/.test(h) ? 'apple' : 'nvidia';

  let architecture = '';
  const idNum = parseInt(device.replace(/^0x/i, ''), 16);
  if (Number.isFinite(idNum)) {
    for (const [v, arch, ranges] of GPU_ARCH_BY_DEVICE) {
      if (v === vendor && ranges.some(([lo, hi]) => idNum >= lo && idNum <= hi)) {
        architecture = arch;
        break;
      }
    }
  }
  if (!architecture) {
    if (vendor === 'apple') architecture = 'metal-3';
    else if (vendor === 'qualcomm') architecture = 'adreno-7xx';
    else if (vendor === 'nvidia') architecture = 'lovelace';
    else if (vendor === 'amd') architecture = 'rdna-2';
    else if (vendor === 'intel') architecture = 'gen-12lp';
  }

  return { vendor, architecture, device, description: desc };
}

function quantizeDeviceMemory(ram) {
  const n = Number(ram) || 8;
  const steps = [0.25, 0.5, 1, 2, 4, 8];
  let best = 8;
  let minDiff = Infinity;
  const clamped = Math.min(8, Math.max(0.25, n));
  for (const s of steps) {
    const d = Math.abs(s - clamped);
    if (d < minDiff) { minDiff = d; best = s; }
  }
  return best;
}

function resolveDefaultChromeVersion(engine = 'chromium', kernelMajor = null) {
  try {
    const k = kernelManager.resolveKernelForProfile({ engine, kernelMajor });
    if (k && k.version && /^\d+\.\d+\.\d+\.\d+$/.test(k.version)) {
      return k.version;
    }
    if (k && k.major && CHROME_BUILDS[k.major]) {
      return CHROME_BUILDS[k.major][0];
    }
  } catch {}
  if (kernelMajor && CHROME_BUILDS[kernelMajor]) {
    return CHROME_BUILDS[kernelMajor][0];
  }
  return '153.0.7993.0';
}

function generateSeedInt() {
  return crypto.randomInt(100000000, 2147483647);
}

/**
 * Generate a complete, cross-consistent fingerprint for a profile.
 */
function generateFingerprint(options = {}) {
  const osKey = String(options.os || 'windows').toLowerCase();
  const osPreset = OS_PRESETS[osKey] || OS_PRESETS.windows;
  const engine = String(options.engine || 'chromium').toLowerCase();

  const chromeVersion = options.chromeVersion || resolveDefaultChromeVersion(engine, options.kernelMajor);
  const majorVer = String(chromeVersion).split('.')[0] || '153';

  let resolution = options.resolution;
  if (!resolution || !resolution.width || !resolution.height) {
    if (osKey === 'android') resolution = { width: 412, height: 915 };
    else if (osKey === 'ios') resolution = { width: 393, height: 852 };
    else resolution = RESOLUTIONS[Math.floor(Math.random() * RESOLUTIONS.length)];
  }

  const cpu = options.cpu || CPU_CORES[Math.floor(Math.random() * CPU_CORES.length)];
  const memory = options.memory || RAM_SIZES[Math.floor(Math.random() * RAM_SIZES.length)];

  let webgl = options.webgl;
  if (!webgl) {
    if (osKey === 'mac' || osKey === 'ios') {
      webgl = WEBGL_RENDERERS.find((r) => r.vendor === 'Apple') || WEBGL_RENDERERS[0];
    } else if (osKey === 'android') {
      webgl = WEBGL_RENDERERS.find((r) => r.vendor === 'Qualcomm') || WEBGL_RENDERERS[0];
    } else {
      const pcRenderers = WEBGL_RENDERERS.filter((r) => r.vendor !== 'Apple' && r.vendor !== 'Qualcomm');
      webgl = pcRenderers[Math.floor(Math.random() * pcRenderers.length)];
    }
  }

  const webglVendor = webgl.unmaskedVendor || webgl.vendor || 'Google Inc. (NVIDIA)';
  const webglRenderer = webgl.unmaskedRenderer || webgl.renderer;
  const webgpu = webgpuFromRenderer(webglRenderer, webglVendor);

  const seed = options.seed || generateSeedInt();
  const canvasNoiseSeed = options.canvasNoiseSeed || (Math.random() * 0.00005 + 0.00001);
  const audioNoiseSeed = options.audioNoiseSeed || (Math.random() * 0.0000001 + 0.00000001);

  const defaultUa = engine === 'firefox'
    ? osPreset.firefoxUaTemplate(options.firefoxVersion || '135.0')
    : (osKey === 'ios' ? osPreset.userAgentTemplate(chromeVersion) : osPreset.userAgentTemplate(majorVer));
  const userAgent = options.userAgent || defaultUa;

  return {
    seed,
    engine,
    os: osKey,
    platform: osPreset.platform,
    oscpu: osPreset.oscpu,
    appVersion: (options.appVersion || userAgent).replace(/^Mozilla\//, ''),
    userAgent,
    chromeVersion,
    chromeMajor: parseInt(majorVer, 10) || 153,
    clientHints: {
      platform: osPreset.clientHintsPlatform,
      platformVersion: options.platformVersion || osPreset.clientHintsPlatformVersion,
      architecture: osPreset.architecture,
      bitness: osPreset.bitness,
      mobile: Boolean(osPreset.mobile),
      model: osPreset.model || '',
      fullVersion: chromeVersion,
    },
    screen: {
      width: resolution.width,
      height: resolution.height,
      availWidth: resolution.width,
      availHeight: osPreset.mobile ? resolution.height : Math.max(200, resolution.height - 40),
      colorDepth: 24,
      pixelDepth: 24,
      devicePixelRatio: osPreset.mobile ? 3 : 1,
    },
    maxTouchPoints: osPreset.maxTouchPoints || 0,
    hardwareConcurrency: cpu,
    deviceMemory: memory,
    quantizedDeviceMemory: quantizeDeviceMemory(memory),
    webgl: {
      vendor: webglVendor,
      renderer: webglRenderer,
      noise: options.webglNoise !== false,
    },
    webgpu,
    canvas: {
      mode: options.canvasMode || 'noise',
      noiseSeed: canvasNoiseSeed,
    },
    clientRects: {
      mode: options.clientRectsMode || 'noise',
    },
    audio: {
      mode: options.audioMode || 'real',
      noiseSeed: audioNoiseSeed,
    },
    webrtc: {
      mode: options.webrtcMode || 'proxy_match', // 'proxy_match' | 'fake_ip' | 'disabled' | 'real'
      policy: 'disable_non_proxied_udp',
      publicIp: options.publicIp || '',
    },
    geolocation: {
      mode: options.geoMode || 'auto', // 'auto' | 'fake' | 'disabled' | 'real'
      latitude: options.latitude ?? null,
      longitude: options.longitude ?? null,
      accuracy: options.accuracy || 100,
    },
    languages: options.languages || ['vi-VN', 'vi', 'en-US', 'en'],
    timezone: options.timezone || 'Asia/Ho_Chi_Minh',
    mediaDevices: {
      audioInputs: 1,
      audioOutputs: 1,
      videoInputs: 1,
    },
    doNotTrack: options.doNotTrack ?? null,
  };
}

/**
 * Build WICG UserAgentMetadata object for CDP Emulation.setUserAgentOverride.
 */
function buildUserAgentMetadata(fp) {
  if (!fp || fp.engine === 'firefox' || fp.os === 'ios') return undefined;
  const fullVer = fp.clientHints?.fullVersion || fp.chromeVersion || '153.0.7993.0';
  const major = String(fullVer).split('.')[0] || '153';
  const ch = fp.clientHints || {};
  return {
    brands: [
      { brand: 'Not(A:Brand', version: '99' },
      { brand: 'Google Chrome', version: major },
      { brand: 'Chromium', version: major },
    ],
    fullVersionList: [
      { brand: 'Not(A:Brand', version: '99.0.0.0' },
      { brand: 'Google Chrome', version: fullVer },
      { brand: 'Chromium', version: fullVer },
    ],
    fullVersion: fullVer,
    platform: ch.platform || 'Windows',
    platformVersion: ch.platformVersion || '15.0.0',
    architecture: ch.mobile ? '' : (ch.architecture || 'x86'),
    model: ch.model || '',
    mobile: Boolean(ch.mobile),
    bitness: ch.mobile ? '' : (ch.bitness || '64'),
    wow64: false,
  };
}

/**
 * Build `--fp-config` JSON compatible with C++-patched Poly Browser kernels (Chromium & Firefox).
 */
function buildPolyFpConfig(fp, profileName = '', proxyCfg = null) {
  if (!fp) return null;
  const cfg = {
    seed: fp.seed || generateSeedInt(),
    custom_text: profileName || '',
    timezone: fp.timezone || 'Asia/Ho_Chi_Minh',
    locale: (fp.languages && fp.languages[0]) || 'vi-VN',
    navigator: {
      platform: fp.platform || 'Win32',
      webdriver: false,
      hardwareConcurrency: fp.hardwareConcurrency || 8,
      deviceMemory: quantizeDeviceMemory(fp.deviceMemory || 8),
      languages: Array.isArray(fp.languages) ? fp.languages : ['vi-VN', 'vi', 'en-US', 'en'],
    },
    screen: {
      width: fp.screen?.width || 1920,
      height: fp.screen?.height || 1080,
      availWidth: fp.screen?.availWidth || fp.screen?.width || 1920,
      availHeight: fp.screen?.availHeight || ((fp.screen?.height || 1080) - 40),
      colorDepth: 24,
      devicePixelRatio: fp.screen?.devicePixelRatio || 1.0,
    },
    webgl: {
      noise: fp.webgl?.noise !== false,
      vendor: fp.webgl?.vendor || 'Google Inc. (NVIDIA)',
      renderer: fp.webgl?.renderer || WEBGL_RENDERERS[0].unmaskedRenderer,
    },
  };

  if (fp.maxTouchPoints > 0) cfg.navigator.maxTouchPoints = fp.maxTouchPoints;
  if (fp.webgpu) cfg.webgpu = fp.webgpu;
  if (fp.canvas?.mode === 'noise') cfg.canvas = { noise: true };
  if (fp.audio?.mode === 'noise') cfg.audio = { noise: true, factor: 1e-7 };
  if (fp.clientRects?.mode !== 'real') cfg.clientRects = { noise: true };

  const rtcMode = fp.webrtc?.mode || 'fake_ip';
  if (rtcMode === 'disabled') {
    cfg.webrtc = { mode: 'disabled' };
  } else if (rtcMode === 'fake_ip' || rtcMode === 'proxy_match') {
    cfg.webrtc = {
      mode: 'fake_ip',
      hideStatsHostname: true,
      hideStatsMac: true,
      ...(fp.webrtc?.publicIp ? { publicIp: fp.webrtc.publicIp } : {}),
    };
  }

  if (fp.geolocation && fp.geolocation.mode !== 'real') {
    if (fp.geolocation.mode === 'disabled') {
      cfg.geolocation = { mode: 'disabled', accuracy: 100 };
    } else if (Number.isFinite(fp.geolocation.latitude) && Number.isFinite(fp.geolocation.longitude)) {
      cfg.geolocation = {
        mode: 'fake',
        latitude: fp.geolocation.latitude,
        longitude: fp.geolocation.longitude,
        accuracy: fp.geolocation.accuracy || 100,
      };
    }
  }

  if (proxyCfg && proxyCfg.host && proxyCfg.port) {
    cfg.proxy = {
      scheme: (proxyCfg.type || 'http').toLowerCase(),
      host: proxyCfg.host,
      port: Number(proxyCfg.port),
      username: proxyCfg.username || '',
      password: proxyCfg.password || '',
    };
  }

  const uaMeta = buildUserAgentMetadata(fp);
  if (fp.userAgent) {
    cfg.user_agent = {
      value: fp.userAgent,
      ...(uaMeta || {}),
    };
  }

  return cfg;
}

/**
 * Chuẩn hóa cấu trúc fingerprint (hỗ trợ cả dạng phẳng và dạng lồng nhau Poly UI { meta, fpConfig, ui })
 */
function normalizeFingerprint(fp, profile = {}) {
  if (!fp) return null;
  const meta = fp.meta || {};
  const cfg = fp.fpConfig || {};
  const nav = cfg.navigator || {};
  const ui = fp.ui || {};

  const osLower = (meta.os || fp.os || profile.os || 'windows').toLowerCase();
  const kernelMajor = parseInt(meta.kernelMajor || fp.chromeMajor || profile.kernel_major || '153', 10);
  const userAgent = fp.userAgent || meta.userAgent || cfg.user_agent?.value || profile.user_agent || (
    osLower === 'mac'
      ? `Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${kernelMajor}.0.0.0 Safari/537.36`
      : `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${kernelMajor}.0.0.0 Safari/537.36`
  );

  const rawMem = fp.deviceMemory || nav.deviceMemory || profile.ram_gb || ui.ram || 8;
  const deviceMemory = Number(rawMem) <= 4 ? 4 : 8;

  const rawCores = fp.hardwareConcurrency || nav.hardwareConcurrency || profile.cpu_cores || ui.cpu || 8;
  const hardwareConcurrency = Number(rawCores) || 8;

  const languages = (Array.isArray(fp.languages) && fp.languages.length)
    ? fp.languages
    : ((Array.isArray(nav.languages) && nav.languages.length)
      ? nav.languages
      : (Array.isArray(ui.languageList) && ui.languageList.length ? ui.languageList : ['vi-VN', 'vi', 'en-US', 'en']));

  const timezone = fp.timezone || cfg.timezone || ui.timezoneValue || 'Asia/Ho_Chi_Minh';

  const clientHints = fp.clientHints || {
    platform: osLower === 'mac' ? 'macOS' : (osLower === 'linux' ? 'Linux' : 'Windows'),
    platformVersion: osLower === 'mac' ? '14.5.0' : '15.0.0',
    architecture: 'x86',
    bitness: '64',
    model: '',
    mobile: false,
    fullVersion: meta.kernelMajor ? `${meta.kernelMajor}.0.7993.0` : (fp.chromeVersion || '153.0.7993.0'),
  };

  return {
    ...fp,
    seed: cfg.seed || fp.seed || 12345678,
    engine: meta.engine || fp.engine || profile.engine || 'chromium',
    os: osLower,
    platform: fp.platform || nav.platform || (osLower === 'mac' ? 'MacIntel' : (osLower === 'linux' ? 'Linux x86_64' : 'Win32')),
    oscpu: fp.oscpu || (osLower === 'mac' ? 'Intel Mac OS X 10_15_7' : (osLower === 'linux' ? 'Linux x86_64' : 'Windows NT 10.0; Win64; x64')),
    userAgent,
    appVersion: userAgent.replace(/^Mozilla\//, ''),
    chromeVersion: clientHints.fullVersion,
    chromeMajor: kernelMajor,
    clientHints,
    hardwareConcurrency,
    deviceMemory,
    languages,
    timezone,
    screen: fp.screen || {
      width: profile.screen_width || cfg.screen?.width || 1920,
      height: profile.screen_height || cfg.screen?.height || 1080,
      availWidth: profile.screen_width || 1920,
      availHeight: (profile.screen_height || 1080) - 40,
      colorDepth: 24,
      devicePixelRatio: 1.0,
    },
    webgl: fp.webgl || {
      vendor: cfg.webgl?.vendor || 'Google Inc. (NVIDIA)',
      renderer: cfg.webgl?.renderer || 'ANGLE (NVIDIA, NVIDIA GeForce RTX 4070 Direct3D11 vs_5_0 ps_5_0, D3D11)',
    },
    webgpu: fp.webgpu || cfg.webgpu || null,
    maxTouchPoints: fp.maxTouchPoints || nav.maxTouchPoints || 0,
  };
}

/**
 * Build stealth JavaScript payload injected before any page/iframe/worker script runs via CDP
 * (`Page.addScriptToEvaluateOnNewDocument`) for unpatched Chromium kernels (e.g., MyBrowser 153).
 */
function getInjectionScript(rawFp) {
  const fp = normalizeFingerprint(rawFp);
  const jsonFp = JSON.stringify(fp);

  const workerPreambleCode = `(function() {
    try {
      const FP = ${jsonFp};
      if (typeof self !== 'undefined' && self.navigator) {
        const nav = self.navigator;
        const N_FN = new WeakSet();
        const origToString = Function.prototype.toString;
        function fakeToString() {
          if (this && N_FN.has(this)) {
            const n = this.name || '';
            return 'function ' + n + '() { [native code] }';
          }
          return origToString.call(this);
        }
        N_FN.add(fakeToString);
        try {
          Object.defineProperty(fakeToString, 'name', { value: 'toString', configurable: true });
          Function.prototype.toString = fakeToString;
        } catch (e) {}

        const proto = (typeof WorkerNavigator !== 'undefined' && WorkerNavigator.prototype) ? WorkerNavigator.prototype : nav;
        function defineWorkerGetter(p, prop, getterFn) {
          try {
            const helper = {
              ['get ' + prop]() {
                if (this !== nav) throw new TypeError('Illegal invocation');
                return getterFn.call(this);
              }
            };
            const fn = helper['get ' + prop];
            N_FN.add(fn);
            Object.defineProperty(p, prop, { get: fn, configurable: true, enumerable: true });
          } catch (e) {}
        }

        defineWorkerGetter(proto, 'hardwareConcurrency', () => FP.hardwareConcurrency);
        defineWorkerGetter(proto, 'deviceMemory', () => FP.deviceMemory);
        defineWorkerGetter(proto, 'platform', () => FP.platform);
        defineWorkerGetter(proto, 'userAgent', () => FP.userAgent);
        defineWorkerGetter(proto, 'appVersion', () => (FP.userAgent || '').replace(/^Mozilla\\//, ''));
        defineWorkerGetter(proto, 'languages', () => Object.freeze([...FP.languages]));
        defineWorkerGetter(proto, 'language', () => FP.languages[0] || 'vi-VN');
        defineWorkerGetter(proto, 'webdriver', () => false);

        if (typeof WebGLRenderingContext !== 'undefined' && FP.webgl) {
          const origP = WebGLRenderingContext.prototype.getParameter;
          WebGLRenderingContext.prototype.getParameter = function(p) {
            if (p === 0x9245 && FP.webgl.vendor) return FP.webgl.vendor;
            if (p === 0x9246 && FP.webgl.renderer) return FP.webgl.renderer;
            return origP.apply(this, arguments);
          };
        }
        if (typeof WebGL2RenderingContext !== 'undefined' && FP.webgl) {
          const origP2 = WebGL2RenderingContext.prototype.getParameter;
          WebGL2RenderingContext.prototype.getParameter = function(p) {
            if (p === 0x9245 && FP.webgl.vendor) return FP.webgl.vendor;
            if (p === 0x9246 && FP.webgl.renderer) return FP.webgl.renderer;
            return origP2.apply(this, arguments);
          };
        }
      }
    } catch (e) {}
  })();`;

  const workerPreambleLiteral = JSON.stringify(workerPreambleCode);

  return `(function() {
    'use strict';
    if (window.__antidetect_injected) return;
    Object.defineProperty(window, '__antidetect_injected', { value: true, enumerable: false, configurable: false });

    const FP = ${jsonFp};
    const NATIVE_FN = new WeakSet();

    const origToString = Function.prototype.toString;
    function fakeToString() {
      if (this && NATIVE_FN.has(this)) {
        const n = this.name || '';
        return 'function ' + n + '() { [native code] }';
      }
      return origToString.call(this);
    }
    NATIVE_FN.add(fakeToString);
    try {
      Object.defineProperty(fakeToString, 'name', { value: 'toString', configurable: true });
      Function.prototype.toString = fakeToString;
    } catch (e) {}

    function defineBoundProxyGetter(proto, prop, realObj, getterFn) {
      try {
        function fakeTarget() {}
        const bound = fakeTarget.bind(null);
        try {
          Object.defineProperty(bound, 'name', { value: 'get ' + prop, configurable: true });
        } catch(e) {}

        const proxyGetter = new Proxy(bound, {
          apply(target, thisArg, argArray) {
            if (!thisArg || thisArg === proto) {
              throw new TypeError('Illegal invocation');
            }
            return getterFn.call(thisArg);
          }
        });

        Object.defineProperty(proto, prop, {
          get: proxyGetter,
          set: undefined,
          enumerable: true,
          configurable: true
        });
      } catch (e) {}
    }

    function defineNativeGetter(proto, prop, realObj, getterFn) {
      try {
        const helper = {
          ['get ' + prop]() {
            if (realObj && this !== realObj) throw new TypeError('Illegal invocation');
            return getterFn.call(this);
          }
        };
        const fn = Object.getOwnPropertyDescriptor(helper, 'get ' + prop).value;
        Object.defineProperty(fn, 'name', { value: 'get ' + prop, configurable: true });
        NATIVE_FN.add(fn);
        Object.defineProperty(proto, prop, { get: fn, configurable: true, enumerable: true });
      } catch (e) {}
    }

    function defineNativeMethod(proto, name, methodFn) {
      try {
        const helper = { [name](...args) { return methodFn.apply(this, args); } };
        const fn = helper[name];
        NATIVE_FN.add(fn);
        Object.defineProperty(proto, name, { value: fn, writable: true, configurable: true, enumerable: true });
      } catch (e) {}
    }

    // 1. Ensure navigator.webdriver is naturally false
    try {
      defineBoundProxyGetter(Navigator.prototype, 'webdriver', navigator, () => false);
    } catch (e) {}

    // 2. Navigator Hardware Spoofing (Bound Native Proxy Getters)
    try {
      // Sử dụng V8 Bound Proxy Getter chuẩn native cho hardwareConcurrency và deviceMemory để vượt qua kiểm tra toString native code sâu
      defineBoundProxyGetter(Navigator.prototype, 'hardwareConcurrency', navigator, () => FP.hardwareConcurrency);
      defineBoundProxyGetter(Navigator.prototype, 'deviceMemory', navigator, () => FP.deviceMemory);
      // Lưu ý: User-Agent, platform, languages đã được nhân Blink xử lý tự nhiên 100% qua CDP Network.setUserAgentOverride và tham số --lang
      // Không ghi đè JS prototype để tránh lỗi "UA getter overridden (stealth injection in all frames)"
    } catch (e) {}

    // 2.1. Intercept Web Worker onmessage để đồng bộ hardwareConcurrency và deviceMemory vào background threads
    try {
      const OrigWorker = window.Worker;
      if (OrigWorker) {
        window.Worker = class Worker extends OrigWorker {
          constructor(scriptURL, options) {
            super(scriptURL, options);
            this.addEventListener('message', function(ev) {
              if (ev && ev.data && typeof ev.data === 'object') {
                if ('deviceMemory' in ev.data) ev.data.deviceMemory = FP.deviceMemory;
                if ('hardwareConcurrency' in ev.data) ev.data.hardwareConcurrency = FP.hardwareConcurrency;
              }
            }, true);
          }
        };
        Object.defineProperty(window.Worker, 'name', { value: 'Worker', configurable: true });
      }
    } catch(e) {}

    // 2.2. Khởi tạo sớm Web SpeechSynthesis API để chống false-positive kiểm tra độ trễ giọng nói
    try {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.getVoices();
      }
    } catch(e) {}

    // 3. Web Worker Blob Preamble
    try {
      const workerPreamble = ${workerPreambleLiteral};
      if (window.Blob) {
        const OrigBlob = window.Blob;
        function Blob(blobParts, options) {
          if (!new.target) throw new TypeError("Failed to construct 'Blob': Please use the 'new' operator.");
          try {
            let isScript = options && options.type && (options.type.includes('javascript') || options.type.includes('ecmascript'));
            if (!isScript && Array.isArray(blobParts) && typeof blobParts[0] === 'string') {
              if (blobParts[0].includes('onmessage') || blobParts[0].includes('postMessage') || blobParts[0].includes('self.')) {
                isScript = true;
              }
            }
            if (isScript && Array.isArray(blobParts)) {
              return new OrigBlob([workerPreamble + '\\n;', ...blobParts], options);
            }
          } catch (e) {}
          return new OrigBlob(blobParts, options);
        }
        Blob.prototype = OrigBlob.prototype;
        try { OrigBlob.prototype.constructor = Blob; } catch (e) {}
        Object.defineProperty(Blob, 'name', { value: 'Blob', configurable: true });
        NATIVE_FN.add(Blob);
        window.Blob = Blob;
      }
    } catch (e) {}

    // 4. WebGL & WebGL2 Unmasked Vendor/Renderer (Native Proxy Wrapper)
    try {
      const patchWebGL = (Proto) => {
        if (!Proto || !Proto.prototype) return;
        const origGetParam = Proto.prototype.getParameter;
        const proxyGetParam = new Proxy(origGetParam, {
          apply(target, thisArg, argArray) {
            const param = argArray[0];
            if (param === 0x9245 && FP.webgl && FP.webgl.vendor) return FP.webgl.vendor;
            if (param === 0x9246 && FP.webgl && FP.webgl.renderer) return FP.webgl.renderer;
            return Reflect.apply(target, thisArg, argArray);
          }
        });
        Proto.prototype.getParameter = proxyGetParam;
      };
      patchWebGL(window.WebGLRenderingContext);
      patchWebGL(window.WebGL2RenderingContext);
    } catch (e) {}

    // 5. WebGPU Adapter Info Consistency (matches WebGL PCI Device ID)
    try {
      if (FP.webgpu && navigator.gpu && typeof navigator.gpu.requestAdapter === 'function') {
        const origReqAdapter = navigator.gpu.requestAdapter.bind(navigator.gpu);
        defineNativeMethod(Object.getPrototypeOf(navigator.gpu), 'requestAdapter', async function(...args) {
          const adapter = await origReqAdapter(...args);
          if (adapter && FP.webgpu) {
            try {
              const fakeInfo = Object.freeze({
                vendor: FP.webgpu.vendor || '',
                architecture: FP.webgpu.architecture || '',
                device: FP.webgpu.device || '',
                description: FP.webgpu.description || ''
              });
              defineNativeGetter(Object.getPrototypeOf(adapter), 'info', null, () => fakeInfo);
            } catch (e) {}
          }
          return adapter;
        });
      }
    } catch (e) {}

    // 6. Deterministic Seeded Canvas 2D Micro-Noise
    try {
      if (FP.canvas && FP.canvas.mode === 'noise') {
        const seedInt = Math.max(1, Math.floor((FP.seed || (FP.canvas.noiseSeed * 1e9) || 13379) % 251));
        const applyCanvasNoise = (canvas) => {
          try {
            const ctx = canvas.getContext('2d');
            if (!ctx || canvas.width <= 0 || canvas.height <= 0) return;
            const w = Math.min(8, canvas.width);
            const h = Math.min(8, canvas.height);
            const imgData = origGetImageData.call(ctx, 0, 0, w, h);
            const idx = ((seedInt * 7) % Math.max(1, imgData.data.length / 4)) * 4;
            imgData.data[idx] = (imgData.data[idx] ^ 1) & 0xFF;
            ctx.putImageData(imgData, 0, 0);
          } catch (e) {}
        };

        const origGetImageData = CanvasRenderingContext2D.prototype.getImageData;
        defineNativeMethod(CanvasRenderingContext2D.prototype, 'getImageData', function(...args) {
          const imgData = origGetImageData.apply(this, args);
          try {
            if (imgData && imgData.data && imgData.data.length >= 16) {
              const idx = ((seedInt * 13) % Math.floor(imgData.data.length / 4)) * 4;
              imgData.data[idx] = (imgData.data[idx] ^ 1) & 0xFF;
            }
          } catch (e) {}
          return imgData;
        });

        const origToDataURL = HTMLCanvasElement.prototype.toDataURL;
        defineNativeMethod(HTMLCanvasElement.prototype, 'toDataURL', function(...args) {
          applyCanvasNoise(this);
          return origToDataURL.apply(this, args);
        });

        const origToBlob = HTMLCanvasElement.prototype.toBlob;
        defineNativeMethod(HTMLCanvasElement.prototype, 'toBlob', function(cb, ...args) {
          applyCanvasNoise(this);
          return origToBlob.apply(this, [cb, ...args]);
        });
      }
    } catch (e) {}

    // 7. Screen & Resolution Consistency
    // 7. Screen Dimensions Spoofing via Bound Native Proxy Getters
    try {
      if (FP.screen && (FP.screen.width !== screen.width || FP.screen.height !== screen.height)) {
        const scrW = FP.screen.width || 1920;
        const scrH = FP.screen.height || 1080;
        const avW = FP.screen.availWidth || scrW;
        const avH = FP.screen.availHeight || (scrH - 40);
        defineBoundProxyGetter(Screen.prototype, 'width', screen, () => scrW);
        defineBoundProxyGetter(Screen.prototype, 'height', screen, () => scrH);
        defineBoundProxyGetter(Screen.prototype, 'availWidth', screen, () => avW);
        defineBoundProxyGetter(Screen.prototype, 'availHeight', screen, () => avH);
      }
    } catch (e) {}

    // 8. WebRTC IP Leak Prevention when disabled
    try {
      if (FP.webrtc && FP.webrtc.mode === 'disabled') {
        delete window.RTCPeerConnection;
        delete window.webkitRTCPeerConnection;
      }
    } catch (e) {}
  })();`;
}

module.exports = {
  CHROME_BUILDS,
  OS_PRESETS,
  WEBGL_RENDERERS,
  RESOLUTIONS,
  CPU_CORES,
  RAM_SIZES,
  webgpuFromRenderer,
  quantizeDeviceMemory,
  resolveDefaultChromeVersion,
  generateFingerprint,
  buildUserAgentMetadata,
  buildPolyFpConfig,
  normalizeFingerprint,
  getInjectionScript,
};
