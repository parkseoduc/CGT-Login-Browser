'use strict';

/**
 * CGT-Login v2.0 — Stateless Streamable HTTP MCP Server (`POST /mcp`)
 * - Supports MCP protocol versions: `2025-06-18`, `2025-03-26`, `2024-11-05`
 * - Strict `Origin` header validation against DNS Rebinding attacks
 * - Resource: `cgtlogin://nodes` (full 52-node RPA catalog + `COND_OPS` + `VAR_TYPES`)
 * - 6 MCP Tools (unrestricted full access for CGT team — ZERO plan-gate blocking):
 *   1. `list_profiles`
 *   2. `open_profile`
 *   3. `close_profile`
 *   4. `delete_profile`
 *   5. `create_workflow`
 *   6. `run_workflow`
 * Zero external npm dependencies.
 */

const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');

const catalogMod = require('../rpa/node-catalog');

const MCP_PATH = '/mcp';
const SERVER_KEY = 'cgt-login';
const SERVER_VERSION = '3.1.0';
const PROTOCOL = '2025-06-18';
const PROTOCOLS = ['2025-06-18', '2025-03-26', '2024-11-05'];
const NODES_URI = 'cgtlogin://nodes';

// Canvas layout constants for `create_workflow`
const X0 = 80;
const Y0 = 80;
const COL_GAP = 320;
const ROW_GAP = 170;
const WIRE = '#3B82F6';
const WIRE_ELSE = '#EF4444';

// Dependency Injection store (with lazy `require` fallback)
const _deps = {
  db: null,
  launcher: null,
  cookies: null,
  taskRunner: null,
  port: 51888,
};

function init(deps = {}) {
  if (deps.db) _deps.db = deps.db;
  if (deps.launcher) _deps.launcher = deps.launcher;
  if (deps.cookies) _deps.cookies = deps.cookies;
  if (deps.taskRunner) _deps.taskRunner = deps.taskRunner;
  if (deps.port) _deps.port = Number(deps.port) || 51888;
}

function getDb(overrideDeps) {
  if (overrideDeps && overrideDeps.db) return overrideDeps.db;
  if (_deps.db) return _deps.db;
  try { _deps.db = require('../db'); } catch { /* standalone mode */ }
  return _deps.db;
}

function getLauncher(overrideDeps) {
  if (overrideDeps && overrideDeps.launcher) return overrideDeps.launcher;
  if (_deps.launcher) return _deps.launcher;
  try { _deps.launcher = require('../launcher'); } catch { /* standalone mode */ }
  return _deps.launcher;
}

function getTaskRunner(overrideDeps) {
  if (overrideDeps && overrideDeps.taskRunner) return overrideDeps.taskRunner;
  if (_deps.taskRunner) return _deps.taskRunner;
  try {
    _deps.taskRunner = require('../rpa/task-runner');
    _deps.taskRunner.init({ db: getDb(), launcher: getLauncher(), cookies: _deps.cookies });
  } catch { /* standalone mode */ }
  return _deps.taskRunner;
}

// ─────────────────────────────────────────────────────────────────────────────
// BRIDGE & CLIENT CONFIG GENERATORS (Claude, Cursor, Antigravity, VS Code, Codex)
// ─────────────────────────────────────────────────────────────────────────────

function endpointUrl(port = _deps.port || 51888) {
  return `http://127.0.0.1:${Number(port) || 51888}${MCP_PATH}`;
}

function resolveBridgePath() {
  const localBridge = path.resolve(__dirname, 'stdio-bridge.js');
  // If running inside an Electron `.asar` archive, copy bridge to writable disk
  if (localBridge.includes('.asar')) {
    const dst = path.join(os.tmpdir(), 'cgt-login-mcp', 'stdio-bridge.js');
    try {
      const src = fs.readFileSync(localBridge, 'utf8');
      fs.mkdirSync(path.dirname(dst), { recursive: true });
      let cur = null;
      try { cur = fs.readFileSync(dst, 'utf8'); } catch { /* ignore */ }
      if (cur !== src) fs.writeFileSync(dst, src, 'utf8');
      return dst;
    } catch {
      return dst;
    }
  }
  return localBridge;
}

function clientEntry(port = _deps.port || 51888) {
  const env = {
    CGT_MCP_URL: endpointUrl(port),
  };
  if (process.versions && process.versions.electron) {
    env.ELECTRON_RUN_AS_NODE = '1';
  }
  return {
    command: process.execPath,
    args: [resolveBridgePath()],
    env,
  };
}

function configJson(port = _deps.port || 51888) {
  return JSON.stringify({ mcpServers: { [SERVER_KEY]: clientEntry(port) } }, null, 2);
}

function tomlStr(s) {
  const v = String(s);
  if (!v.includes("'") && !/[\n\r\t]/.test(v)) return `'${v}'`;
  return JSON.stringify(v);
}

function configToml(port = _deps.port || 51888) {
  const e = clientEntry(port);
  const lines = [
    `[mcp_servers.${SERVER_KEY}]`,
    `command = ${tomlStr(e.command)}`,
    `args = [${e.args.map(tomlStr).join(', ')}]`,
    '',
    `[mcp_servers.${SERVER_KEY}.env]`,
  ];
  for (const [k, v] of Object.entries(e.env)) {
    lines.push(`${k} = ${tomlStr(v)}`);
  }
  return `${lines.join('\n')}\n`;
}

// ─────────────────────────────────────────────────────────────────────────────
// CAPABILITIES & TOOL SCHEMAS (6 TOOLS)
// ─────────────────────────────────────────────────────────────────────────────

const CAPS = [
  {
    key: 'list',
    tool: 'list_profiles',
    label: 'Danh sách hồ sơ',
    desc: 'Liệt kê các hồ sơ trình duyệt (hỗ trợ tìm kiếm theo từ khóa, nhóm và trạng thái đang chạy).',
  },
  {
    key: 'open',
    tool: 'open_profile',
    label: 'Mở hồ sơ',
    desc: 'Khởi động trình duyệt của hồ sơ theo ID hoặc Tên và trả về địa chỉ kết nối CDP (wsEndpoint).',
  },
  {
    key: 'close',
    tool: 'close_profile',
    label: 'Đóng hồ sơ',
    desc: 'Đóng trình duyệt của một hoặc nhiều hồ sơ đang mở.',
  },
  {
    key: 'delete',
    tool: 'delete_profile',
    label: 'Xóa hồ sơ',
    desc: 'Chuyển hồ sơ vào Thùng rác (chặn ký tự đại diện *, all, tất cả).',
  },
  {
    key: 'create_flow',
    tool: 'create_workflow',
    label: 'Tạo quy trình RPA',
    desc: 'Dựng và kiểm tra đồ thị quy trình RPA trực quan từ cây bước (hỗ trợ rẽ nhánh then/else & vòng lặp body) và lưu vào hệ thống.',
  },
  {
    key: 'run_flow',
    tool: 'run_workflow',
    label: 'Chạy quy trình RPA',
    desc: 'Thực thi một quy trình RPA đã lưu trên danh sách hồ sơ theo cơ chế đa luồng chia ô màn hình.',
  },
];

const CAP_BY_TOOL = new Map(CAPS.map((c) => [c.tool, c]));

const PROFILE_ARG = {
  type: 'string',
  description: 'ID hoặc TÊN chính xác của hồ sơ. Nếu không khớp sẽ liệt kê các hồ sơ hiện có.',
};

const STEP_SCHEMA = {
  type: 'object',
  required: ['type'],
  properties: {
    type: {
      type: 'string',
      description: 'Loại node lấy từ resource cgtlogin://nodes (vd: mo_url, nhan_chuot, nhap_van_ban, doi, dieu_kien, lap_du_lieu).',
    },
    params: {
      type: 'object',
      description: 'Tham số cấu hình của node. Tên khóa phải khớp danh mục trong cgtlogin://nodes.',
    },
    note: {
      type: 'string',
      description: 'Ghi chú hiển thị trên thẻ node (lưu vào params.__note).',
    },
    onError: {
      type: 'string',
      enum: ['Mặc định', 'Gián đoạn', 'Bỏ qua'],
      description: 'Chính sách xử lý lỗi riêng cho node này.',
    },
    disabled: {
      type: 'boolean',
      description: 'Tắt tạm thời bước này mà vẫn giữ trong đồ thị.',
    },
    then: {
      type: 'array',
      description: 'Dùng cho node "dieu_kien": mảng các bước chạy khi điều kiện ĐÚNG (nhánh if).',
      items: { type: 'object' },
    },
    else: {
      type: 'array',
      description: 'Dùng cho node "dieu_kien": mảng các bước chạy khi điều kiện SAI (nhánh else).',
      items: { type: 'object' },
    },
    body: {
      type: 'array',
      description: 'BẮT BUỘC với node lặp ("lap_du_lieu", "lap_co_dieu_kien"): các bước bên trong vòng lặp. Node "diem_cuoi_vong_lap" và "loop_id" được sinh tự động.',
      items: { type: 'object' },
    },
  },
};

function toolList() {
  return [
    {
      name: 'list_profiles',
      title: 'Danh sách hồ sơ',
      description: 'Tìm kiếm và liệt kê danh sách hồ sơ trình duyệt trong CGT-Login kèm trạng thái mở và cổng CDP.',
      inputSchema: {
        type: 'object',
        properties: {
          search: { type: 'string', description: 'Từ khóa tìm theo tên, ID, ghi chú hoặc proxy.' },
          group: { type: 'string', description: 'Lọc theo ID nhóm hoặc tên nhóm.' },
          status: { type: 'string', enum: ['all', 'running', 'stopped'], description: 'Lọc theo trạng thái đang mở/đã đóng.' },
          limit: { type: 'number', description: 'Giới hạn số lượng kết quả trả về (mặc định 100).' },
        },
      },
    },
    {
      name: 'open_profile',
      title: 'Mở hồ sơ',
      description: 'Khởi chạy trình duyệt của hồ sơ theo ID hoặc Tên và trả về địa chỉ WebSocket CDP (wsEndpoint) để điều khiển.',
      inputSchema: {
        type: 'object',
        properties: {
          profile: PROFILE_ARG,
          profiles: { type: 'array', items: { type: 'string' }, description: 'Mở nhiều hồ sơ cùng lúc.' },
          blank: { type: 'boolean', description: 'Mở trang trắng about:blank thay vì Start URL.' },
        },
      },
    },
    {
      name: 'close_profile',
      title: 'Đóng hồ sơ',
      description: 'Đóng trình duyệt của hồ sơ đang mở theo ID hoặc Tên.',
      inputSchema: {
        type: 'object',
        properties: {
          profile: PROFILE_ARG,
          profiles: { type: 'array', items: { type: 'string' }, description: 'Đóng nhiều hồ sơ cùng lúc.' },
        },
      },
    },
    {
      name: 'delete_profile',
      title: 'Xóa hồ sơ (vào Thùng rác)',
      description: 'Chuyển hồ sơ vào Thùng rác (có thể khôi phục). Không chấp nhận ký tự đại diện (*, all, tất cả).',
      inputSchema: {
        type: 'object',
        properties: {
          profile: PROFILE_ARG,
          profiles: { type: 'array', items: { type: 'string' }, description: 'Danh sách hồ sơ cụ thể cần chuyển vào Thùng rác.' },
        },
      },
    },
    {
      name: 'create_workflow',
      title: 'Tạo quy trình RPA',
      description: [
        'Tạo mới một quy trình RPA trực quan trong CGT-Login.',
        'TRƯỚC KHI GỌI: hãy đọc resource cgtlogin://nodes để biết danh sách 52 loại node, toán tử điều kiện COND_OPS và tham số hợp lệ.',
        'Hỗ trợ kiểm tra thử với dryRun=true trước khi lưu thật.',
        'Rẽ nhánh dùng node "dieu_kien" kèm "then"/"else"; vòng lặp dùng "lap_du_lieu" hoặc "lap_co_dieu_kien" kèm "body" ("diem_cuoi_vong_lap" và "loop_id" tự động sinh).',
      ].join(' '),
      inputSchema: {
        type: 'object',
        required: ['name', 'steps'],
        properties: {
          name: { type: 'string', description: 'Tên quy trình (tối đa 100 ký tự).' },
          steps: { type: 'array', minItems: 1, items: STEP_SCHEMA, description: 'Cây các bước của quy trình. Node "start" được chèn tự động.' },
          variables: {
            type: 'array',
            description: 'Danh sách biến quy trình.',
            items: {
              type: 'object',
              required: ['name'],
              properties: {
                name: { type: 'string' },
                type: { type: 'string', enum: catalogMod.VAR_TYPES },
                value: { description: 'Giá trị mặc định.' },
                desc: { type: 'string' },
                label: { type: 'string' },
                local: { type: 'boolean' },
              },
            },
          },
          group: { type: 'string', description: 'Nhóm quy trình (mặc định "Chưa chia nhóm").' },
          remark: { type: 'string', description: 'Mô tả ngắn cho quy trình.' },
          settings: {
            type: 'object',
            properties: {
              onError: { type: 'string', enum: ['Bỏ qua', 'Gián đoạn'] },
              onCompleteBrowser: { type: 'string', enum: ['Giữ trình duyệt', 'Đóng trình duyệt'] },
              timeoutSec: { type: 'number' },
              delayMin: { type: 'number' },
              layout: { type: 'string', enum: ['Ngang', 'Dọc'] },
              autoConnect: { type: 'boolean' },
            },
          },
          dryRun: { type: 'boolean', description: 'true = chỉ kiểm tra hợp lệ và trả về đồ thị, KHÔNG lưu DB.' },
        },
      },
    },
    {
      name: 'run_workflow',
      title: 'Chạy quy trình RPA',
      description: 'Thực thi một quy trình RPA đã lưu trên một hoặc nhiều hồ sơ qua bộ chạy đa luồng (taskRunner).',
      inputSchema: {
        type: 'object',
        required: ['workflow'],
        properties: {
          workflow: { type: 'string', description: 'ID hoặc Tên của quy trình RPA đã lưu.' },
          profileIds: { type: 'array', items: { type: 'string' }, description: 'Danh sách ID hoặc Tên các hồ sơ cần chạy.' },
          profile: { type: 'string', description: 'ID hoặc Tên một hồ sơ đơn lẻ (thay cho profileIds).' },
          inputs: { type: 'object', description: 'Giá trị biến đầu vào ghi đè theo tên biến.' },
          threads: { type: 'number', description: 'Số luồng chạy song song (mặc định 1).' },
          keepOpen: { type: 'boolean', description: 'Giữ cửa sổ trình duyệt mở sau khi chạy xong (mặc định false).' },
          async: { type: 'boolean', description: 'true = khởi chạy nền và trả về runId ngay lập tức.' },
        },
      },
    },
  ];
}

function getStatus(port = _deps.port || 51888) {
  const p = Number(port) || _deps.port || 51888;
  const bPath = resolveBridgePath();
  return {
    ok: true,
    serverName: SERVER_KEY,
    version: SERVER_VERSION,
    protocolVersion: PROTOCOL,
    protocols: PROTOCOLS,
    resourceUri: NODES_URI,
    endpoint: endpointUrl(p),
    bridgePath: bPath,
    clientEntry: clientEntry(p),
    configJson: configJson(p),
    configToml: configToml(p),
    tools: CAPS.map((c) => ({
      key: c.key,
      tool: c.tool,
      name: c.tool,
      label: c.label,
      title: c.label,
      desc: c.desc,
      description: c.desc,
    })),
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// WORKFLOW GRAPH BUILDER & VALIDATOR (`create_workflow`)
// ─────────────────────────────────────────────────────────────────────────────

function stripDash(v) {
  if (typeof v === 'string') return v.replace(/\u2014/g, '-');
  if (Array.isArray(v)) return v.map(stripDash);
  if (v && typeof v === 'object') {
    const out = {};
    for (const k of Object.keys(v)) out[k] = stripDash(v[k]);
    return out;
  }
  return v;
}

const SETTABLE = (f) => !!(f && f.k && f.t !== 'info');

function coerceField(f, raw) {
  const hasVar = typeof raw === 'string' && (raw.includes('${') || raw.includes('{{') || raw.includes('{'));
  if (f.t === 'number' && !hasVar) {
    if (raw === '' || raw == null) return '';
    const n = Number(raw);
    return Number.isFinite(n) ? n : raw;
  }
  if (f.t === 'check' || f.t === 'switch') {
    if (typeof raw === 'boolean') return raw;
    if (raw === 'true' || raw === 1 || raw === '1') return true;
    if (raw === 'false' || raw === 0 || raw === '0') return false;
    return !!raw;
  }
  if (f.t === 'checks') {
    return Array.isArray(raw) ? raw : (raw == null || raw === '' ? [] : [raw]);
  }
  if (f.t === 'conds') {
    const list = Array.isArray(raw) ? raw : (raw && Array.isArray(raw.conditions) ? raw.conditions : null);
    if (!list) return raw;
    const logic = (raw && String(raw.logic).toUpperCase() === 'OR') ? 'OR' : 'AND';
    return {
      logic,
      conditions: list.map((c) => ({
        left: String((c && c.left) != null ? c.left : ''),
        op: String((c && c.op) != null ? c.op : 'Bằng'),
        right: String((c && c.right) != null ? c.right : ''),
      })),
    };
  }
  return raw;
}

const SETTINGS_DEFAULT = {
  layout: 'Ngang',
  autoConnect: true,
  onError: 'Bỏ qua',
  onCompleteBrowser: 'Giữ trình duyệt',
  timeoutSec: 0,
  delayMin: 0,
};
const SETTINGS_KEYS = Object.keys(SETTINGS_DEFAULT);

function buildWorkflowGraph(input = {}) {
  const errs = [];
  const nodes = [];
  const connections = [];
  const taken = new Set();
  const stamp = Date.now().toString(36);
  let seq = 0;
  const nid = () => `n${++seq}${stamp}`;

  const place = (col, row) => {
    let r = Math.max(0, row);
    while (taken.has(`${col}:${r}`)) r += 1;
    taken.add(`${col}:${r}`);
    return { x: X0 + col * COL_GAP, y: Y0 + r * ROW_GAP, row: r };
  };

  const link = (source, target, branch = null) => {
    if (!source || !target) return;
    connections.push({
      source,
      target,
      branch: branch || null,
      color: branch === 'else' ? WIRE_ELSE : WIRE,
    });
  };

  const startSpot = place(0, 0);
  nodes.push({
    id: 'start',
    type: 'start',
    title: 'Bắt đầu quy trình',
    color: catalogMod.COL_START,
    x: startSpot.x,
    y: startSpot.y,
    params: {},
  });

  function makeParams(def, given, where) {
    const params = {};
    def.fields.forEach((f) => {
      if (f.k) params[f.k] = catalogMod.fieldDefault(f);
    });
    const byKey = new Map(def.fields.filter(SETTABLE).map((f) => [f.k, f]));
    for (const k of Object.keys(given || {})) {
      if (k === '__note') continue;
      const f = byKey.get(k);
      if (!f) {
        errs.push(`${where}: node "${def.type}" không có tham số "${k}". Tham số hợp lệ: ${[...byKey.keys()].join(', ') || '(không có)'}`);
        continue;
      }
      params[k] = coerceField(f, given[k]);
    }
    def.fields.forEach((f) => {
      if (!f.req || !SETTABLE(f) || !catalogMod.fieldVisible(def, params, f)) return;
      const v = params[f.k];
      const empty = v == null || v === ''
        || (Array.isArray(v) && !v.length)
        || (f.t === 'conds' && !(v && Array.isArray(v.conditions) && v.conditions.length));
      if (empty) {
        errs.push(`${where}: node "${def.type}" thiếu tham số bắt buộc "${f.k}" (${f.label || f.k})`);
      }
    });
    return params;
  }

  function addNode(def, params, step, col, row) {
    const spot = place(col, row);
    const n = {
      id: nid(),
      type: def.type,
      title: def.title,
      icon: def.icon,
      color: def.color,
      x: spot.x,
      y: spot.y,
      params,
    };
    const note = step && (step.note || (step.params && step.params.__note));
    if (note) n.params.__note = String(note);
    if (step && step.onError) n.onError = String(step.onError);
    if (step && step.disabled) n.disabled = true;
    nodes.push(n);
    return { id: n.id, row: spot.row };
  }

  function emitStep(step, col, row, where) {
    if (!step || typeof step !== 'object' || !step.type) {
      errs.push(`${where}: mỗi bước phải là object có khóa "type"`);
      return null;
    }
    const type = String(step.type);
    if (type === 'start') {
      errs.push(`${where}: node "start" được sinh tự động, không khai trong steps`);
      return null;
    }
    if (type === 'diem_cuoi_vong_lap') {
      errs.push(`${where}: node "diem_cuoi_vong_lap" được sinh tự động - hãy khai mảng "body" cho node lặp`);
      return null;
    }

    const def = catalogMod.getNodeDef(type);
    if (!def) {
      errs.push(`${where}: không tồn tại loại node "${type}". Hãy đọc resource ${NODES_URI} để lấy danh sách type hợp lệ.`);
      return null;
    }

    const isLoop = type === 'lap_du_lieu' || type === 'lap_co_dieu_kien';
    let given = step.params;
    if (isLoop && !String((given && given.loop_id) || '').trim()) {
      given = { ...(given || {}), loop_id: `loop${seq + 1}${stamp}` };
    }

    const params = makeParams(def, given, where);

    if (def.branches && def.branches.length >= 2) {
      const me = addNode(def, params, step, col, row);
      const thenSteps = Array.isArray(step.then) ? step.then : [];
      const elseSteps = Array.isArray(step.else) ? step.else : [];
      const a = emitChain(thenSteps, col + 1, me.row, `${where}.then`);
      const b = emitChain(elseSteps, col + 1, me.row + 1, `${where}.else`);
      if (a.headId) link(me.id, a.headId, 'if');
      if (b.headId) link(me.id, b.headId, 'else');
      const tails = []
        .concat(a.headId ? a.tails : [{ id: me.id, branch: 'if' }])
        .concat(b.headId ? b.tails : [{ id: me.id, branch: 'else' }]);
      return { headId: me.id, tails, nextCol: Math.max(a.nextCol, b.nextCol, col + 1) };
    }

    if (isLoop && Array.isArray(step.body)) {
      const me = addNode(def, params, step, col, row);
      const body = emitChain(step.body, col + 1, me.row + 1, `${where}.body`);
      const endDef = catalogMod.getNodeDef('diem_cuoi_vong_lap');
      const endCol = Math.max(body.nextCol, col + 1);
      const end = addNode(endDef, makeParams(endDef, { loop_id: params.loop_id }, `${where}.loopEnd`), null, endCol, me.row);
      if (body.headId) {
        link(me.id, body.headId, null);
        body.tails.forEach((t) => link(t.id, end.id, t.branch));
      } else {
        link(me.id, end.id, null);
      }
      return { headId: me.id, tails: [{ id: end.id, branch: null }], nextCol: endCol + 1 };
    }

    if (isLoop) {
      errs.push(`${where}: node lặp "${type}" bắt buộc phải khai "body" (mảng các bước bên trong vòng lặp, dùng [] nếu chỉ đếm)`);
      return null;
    }

    const me = addNode(def, params, step, col, row);
    return { headId: me.id, tails: [{ id: me.id, branch: null }], nextCol: col + 1 };
  }

  function emitChain(steps, col, row, where) {
    let headId = null;
    let tails = [];
    let c = col;
    (Array.isArray(steps) ? steps : []).forEach((st, i) => {
      const r = emitStep(st, c, row, `${where}[${i}]`);
      if (!r) return;
      if (!headId) headId = r.headId;
      else tails.forEach((t) => link(t.id, r.headId, t.branch));
      tails = r.tails;
      c = r.nextCol;
    });
    return { headId, tails, nextCol: c };
  }

  const main = emitChain(input.steps, 1, 0, 'steps');
  if (main.headId) link('start', main.headId, null);

  const variables = [];
  (Array.isArray(input.variables) ? input.variables : []).forEach((v, i) => {
    const name = String((v && v.name) || '').trim();
    if (!name) { errs.push(`variables[${i}]: thiếu "name"`); return; }
    if (!/^[A-Za-z_$][\w$]*$/.test(name)) {
      errs.push(`variables[${i}]: tên biến "${name}" không hợp lệ (chỉ gồm chữ/số/_ và không bắt đầu bằng số)`);
      return;
    }
    const type = String((v && v.type) || 'String');
    if (!catalogMod.VAR_TYPES.includes(type)) {
      errs.push(`variables[${i}]: kiểu "${type}" không hợp lệ (${catalogMod.VAR_TYPES.join(', ')})`);
      return;
    }
    const local = !!(v && v.local);
    variables.push({
      name,
      type,
      value: v && v.value != null ? v.value : (type === 'Array' ? [] : (type === 'Boolean' ? false : '')),
      desc: String((v && v.desc) || (local ? name : '')),
      label: v && v.label ? String(v.label) : undefined,
      local: local ? true : undefined,
    });
  });

  const runSettings = { ...SETTINGS_DEFAULT };
  const givenSet = (input.settings && typeof input.settings === 'object') ? input.settings : {};
  for (const k of Object.keys(givenSet)) {
    if (!SETTINGS_KEYS.includes(k)) {
      errs.push(`settings: không có khóa "${k}" (hợp lệ: ${SETTINGS_KEYS.join(', ')})`);
      continue;
    }
    runSettings[k] = givenSet[k];
  }

  const edges = connections.map((c, idx) => ({
    id: `e${idx + 1}`,
    source: c.source,
    target: c.target,
    branch: c.branch,
    sourceHandle: c.branch,
    color: c.color,
  }));

  return {
    graph: stripDash({
      variables,
      settings: runSettings,
      nodes,
      connections,
      edges,
    }),
    errs,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// RESOURCE `cgtlogin://nodes`
// ─────────────────────────────────────────────────────────────────────────────

function nodeCatalogDoc() {
  const catName = new Map(catalogMod.CATEGORIES);
  return {
    note: 'Danh mục 52 node RPA cấu hình của CGT-Login (cùng node start tự động = 53 node). Dùng "type" trong create_workflow.steps[].type và "key" trong fields làm tên tham số.',
    conditionOps: catalogMod.COND_OPS.map((o) => ({ value: o.value, symbol: o.right, hint: catalogMod.COND_OP_HINTS[o.value] || '' })),
    variableTypes: catalogMod.VAR_TYPES,
    systemVariables: catalogMod.SYS_VARS,
    branching: 'Node "dieu_kien" có hai nhánh ra: khai "then" (nhánh if/#3B82F6) và "else" (nhánh else/#EF4444). Vòng lặp "lap_du_lieu" và "lap_co_dieu_kien" BẮT BUỘC khai "body" (mảng bước bên trong, dùng [] nếu chỉ đếm); node "diem_cuoi_vong_lap" và "loop_id" được sinh tự động.',
    nodes: catalogMod.NODES.map((n) => ({
      type: n.type,
      title: n.title,
      category: catName.get(n.category) || n.category,
      categoryKey: n.category,
      about: n.subtitle || '',
      branches: n.branches || undefined,
      managedByServer: n.type === 'diem_cuoi_vong_lap'
        ? 'Node này được sinh tự động khi khai "body" cho vòng lặp. Đừng đưa vào steps.'
        : undefined,
      fields: (n.fields || []).filter(SETTABLE).map((f) => ({
        key: f.k,
        label: f.label || '',
        kind: f.t,
        required: !!f.req,
        default: catalogMod.fieldDefault(f),
        options: Array.isArray(f.options) && f.options.length
          ? f.options.map((o) => (o && typeof o === 'object' ? o.value : o))
          : undefined,
        onlyWhen: f.when || undefined,
        acceptsVariables: f.varIns ? true : undefined,
      })),
    })),
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// TOOL IMPLEMENTATIONS
// ─────────────────────────────────────────────────────────────────────────────

function fetchAllActiveProfiles(db) {
  if (!db) return [];
  let list = [];
  if (typeof db.listProfiles === 'function') list = db.listProfiles() || [];
  else if (typeof db.listAllProfiles === 'function') list = db.listAllProfiles() || [];
  return list.filter((p) => p && !p.deleted_at && !p.is_deleted && !p.trashed);
}

function resolveProfile(db, ref) {
  const key = String(ref == null ? '' : ref).trim();
  if (!key) return { error: 'Thiếu tên hoặc ID hồ sơ' };
  const list = fetchAllActiveProfiles(db);
  const byId = list.find((p) => String(p.id) === key);
  if (byId) return { profile: byId };
  const lower = key.toLowerCase();
  const byName = list.filter((p) => String(p.name || '').trim().toLowerCase() === lower);
  if (byName.length === 1) return { profile: byName[0] };
  if (byName.length > 1) {
    return { error: `Có ${byName.length} hồ sơ trùng tên "${key}" - hãy gọi bằng ID: ${byName.map((p) => p.id).join(', ')}` };
  }
  const sample = list.slice(0, 40).map((p) => `${p.name || '(không tên)'} [${p.id}]`);
  return {
    error: `Không tìm thấy hồ sơ "${key}". Hồ sơ hiện có${list.length > 40 ? ` (40/${list.length})` : ''}: ${sample.join('; ') || '(trống)'}`,
  };
}

function refsFromArgs(args) {
  const out = [];
  if (args && args.profile != null) out.push(args.profile);
  if (args && Array.isArray(args.profiles)) out.push(...args.profiles);
  if (args && Array.isArray(args.profileIds)) out.push(...args.profileIds);
  return out.map((s) => String(s == null ? '' : s).trim()).filter(Boolean);
}

async function execListProfiles(args, overrideDeps) {
  const db = getDb(overrideDeps);
  const launcher = getLauncher(overrideDeps);
  if (!db) return { isError: true, text: 'Chưa kết nối cơ sở dữ liệu hồ sơ.' };

  let list = fetchAllActiveProfiles(db);
  let groupsMap = new Map();
  if (typeof db.listGroups === 'function') {
    try {
      (db.listGroups() || []).forEach((g) => { if (g && g.id) groupsMap.set(String(g.id), g.name || ''); });
    } catch { /* ignore */ }
  }

  const search = String((args && args.search) || '').trim().toLowerCase();
  const groupFilter = String((args && args.group) || '').trim().toLowerCase();
  const statusFilter = String((args && args.status) || 'all').toLowerCase();
  const limit = Math.max(1, Math.min(500, parseInt(args && args.limit, 10) || 100));

  const enriched = list.map((p) => {
    const runInfo = (launcher && typeof launcher.getRunningInfo === 'function') ? launcher.getRunningInfo(p.id) : null;
    const gName = p.group_name || groupsMap.get(String(p.group_id || '')) || 'Chưa phân nhóm';
    return {
      id: p.id,
      name: p.name || '',
      groupId: p.group_id || null,
      groupName: gName,
      notes: p.notes || '',
      proxy: p.proxy_host ? `${p.proxy_type || 'http'}://${p.proxy_host}:${p.proxy_port}` : null,
      running: !!runInfo,
      wsEndpoint: runInfo ? runInfo.wsEndpoint : null,
      port: runInfo ? runInfo.port : null,
    };
  });

  const filtered = enriched.filter((p) => {
    if (search) {
      const hay = `${p.name} ${p.id} ${p.notes} ${p.proxy || ''} ${p.groupName}`.toLowerCase();
      if (!hay.includes(search)) return false;
    }
    if (groupFilter) {
      const gMatch = (p.groupId && String(p.groupId).toLowerCase() === groupFilter)
        || p.groupName.toLowerCase().includes(groupFilter);
      if (!gMatch) return false;
    }
    if (statusFilter === 'running' && !p.running) return false;
    if (statusFilter === 'stopped' && p.running) return false;
    return true;
  }).slice(0, limit);

  if (!filtered.length) {
    return { isError: false, text: 'Không có hồ sơ nào khớp bộ lọc.', data: { count: 0, profiles: [] } };
  }

  const lines = filtered.map((p, idx) => (
    `${idx + 1}. "${p.name}" [id: ${p.id}] - Nhóm: ${p.groupName} - ${p.running ? `ĐANG MỞ (CDP: ${p.wsEndpoint})` : 'Đã đóng'}`
  ));
  return {
    isError: false,
    text: `Tìm thấy ${filtered.length} hồ sơ:\n${lines.join('\n')}`,
    data: { count: filtered.length, profiles: filtered },
  };
}

async function execOpenProfile(args, overrideDeps) {
  const db = getDb(overrideDeps);
  const launcher = getLauncher(overrideDeps);
  if (!db || !launcher) return { isError: true, text: 'Launcher hoặc Database chưa sẵn sàng.' };

  const refs = refsFromArgs(args);
  if (!refs.length) return { isError: true, text: 'Thiếu tham số "profile" hoặc "profiles".' };

  const lines = [];
  const opened = [];
  let bad = 0;

  for (const ref of refs) {
    const r = resolveProfile(db, ref);
    if (r.error) {
      bad += 1;
      lines.push(`✗ ${ref}: ${r.error}`);
      continue;
    }
    try {
      const overrides = {};
      if (args && args.blank) overrides.start_url = 'about:blank';
      if (args && args.bounds && typeof args.bounds === 'object') {
        overrides.bounds = args.bounds;
        overrides.window_x = args.bounds.x;
        overrides.window_y = args.bounds.y;
        overrides.screen_width = args.bounds.width;
        overrides.screen_height = args.bounds.height;
      }
      const info = await launcher.startProfile(r.profile.id, overrides);
      const wsEndpoint = (info && (info.wsEndpoint || info.webSocketDebuggerUrl)) || '';
      opened.push({
        id: r.profile.id,
        name: r.profile.name,
        wsEndpoint,
        webSocketDebuggerUrl: wsEndpoint,
        port: info ? info.port : null,
        pid: info ? info.pid : null,
        alreadyRunning: !!(info && info.alreadyRunning),
      });
      lines.push(`✓ Đã mở "${r.profile.name || r.profile.id}" (id ${r.profile.id})${wsEndpoint ? ` - CDP: ${wsEndpoint}` : ''}`);
    } catch (e) {
      bad += 1;
      lines.push(`✗ ${r.profile.name || r.profile.id}: ${(e && e.message) || 'mở thất bại'}`);
    }
  }

  return {
    isError: bad === refs.length,
    text: lines.join('\n'),
    data: { profiles: opened },
  };
}

async function execCloseProfile(args, overrideDeps) {
  const db = getDb(overrideDeps);
  const launcher = getLauncher(overrideDeps);
  if (!db || !launcher) return { isError: true, text: 'Launcher hoặc Database chưa sẵn sàng.' };

  const refs = refsFromArgs(args);
  if (!refs.length) return { isError: true, text: 'Thiếu tham số "profile" hoặc "profiles".' };

  const lines = [];
  let bad = 0;

  for (const ref of refs) {
    const r = resolveProfile(db, ref);
    if (r.error) {
      bad += 1;
      lines.push(`✗ ${ref}: ${r.error}`);
      continue;
    }
    const name = r.profile.name || r.profile.id;
    const isOpen = typeof launcher.isProfileRunning === 'function' ? launcher.isProfileRunning(r.profile.id) : true;
    if (!isOpen) {
      lines.push(`• "${name}" vốn đang đóng - bỏ qua`);
      continue;
    }
    try {
      await launcher.stopProfile(r.profile.id);
      lines.push(`✓ Đã đóng "${name}" (id ${r.profile.id})`);
    } catch (e) {
      bad += 1;
      lines.push(`✗ ${name}: ${(e && e.message) || 'đóng thất bại'}`);
    }
  }

  return { isError: bad === refs.length, text: lines.join('\n') };
}

async function execDeleteProfile(args, overrideDeps) {
  const db = getDb(overrideDeps);
  const launcher = getLauncher(overrideDeps);
  if (!db) return { isError: true, text: 'Database chưa sẵn sàng.' };

  const refs = refsFromArgs(args);
  if (!refs.length) return { isError: true, text: 'Thiếu tham số "profile" hoặc "profiles".' };

  const wild = refs.find((s) => s === '*' || /^(all|tất cả|tat ca)$/i.test(s));
  if (wild) {
    return {
      isError: true,
      text: 'Công cụ delete_profile chặn ký tự đại diện (*, all, tất cả). Vui lòng chỉ định rõ ID hoặc Tên từng hồ sơ.',
    };
  }

  const lines = [];
  let bad = 0;

  for (const ref of refs) {
    const r = resolveProfile(db, ref);
    if (r.error) {
      bad += 1;
      lines.push(`✗ ${ref}: ${r.error}`);
      continue;
    }
    const id = r.profile.id;
    const name = r.profile.name || id;
    try {
      if (launcher && typeof launcher.isProfileRunning === 'function' && launcher.isProfileRunning(id)) {
        await launcher.stopProfile(id).catch(() => {});
      }
      let ok = false;
      if (typeof db.trashProfile === 'function') ok = await db.trashProfile(id);
      else if (typeof db.moveProfileToTrash === 'function') ok = await db.moveProfileToTrash(id);
      else if (typeof db.softDeleteProfile === 'function') ok = await db.softDeleteProfile(id);
      else if (typeof db.deleteProfile === 'function') ok = await db.deleteProfile(id);
      if (ok !== false) {
        lines.push(`✓ Đã chuyển "${name}" (id ${id}) vào Thùng rác`);
      } else {
        bad += 1;
        lines.push(`✗ ${name}: không thể xóa hồ sơ`);
      }
    } catch (e) {
      bad += 1;
      lines.push(`✗ ${name}: ${(e && e.message) || 'xóa thất bại'}`);
    }
  }

  return { isError: bad === refs.length, text: lines.join('\n') };
}

const newFlowId = () => `flow_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`;

async function execCreateWorkflow(args, overrideDeps) {
  const name = String((args && args.name) || '').trim();
  if (!name) return { isError: true, text: 'Thiếu "name" (tên quy trình).' };
  if (name.length > 100) return { isError: true, text: 'Tên quy trình tối đa 100 ký tự.' };
  if (!Array.isArray(args.steps) || !args.steps.length) {
    return { isError: true, text: `Thiếu "steps" (danh sách bước). Hãy đọc resource ${NODES_URI} để lấy loại node hợp lệ.` };
  }

  const { graph, errs } = buildWorkflowGraph(args);
  if (errs.length) {
    return {
      isError: true,
      text: `Quy trình chưa hợp lệ, KHÔNG lưu:\n- ${errs.join('\n- ')}`,
    };
  }

  const summary = `${graph.nodes.length} node, ${graph.connections.length} dây nối, ${graph.variables.length} biến`;
  if (args.dryRun) {
    return {
      isError: false,
      text: `✓ Kiểm tra hợp lệ (dryRun - chưa lưu): ${summary}`,
      data: { dryRun: true, graph },
    };
  }

  const db = getDb(overrideDeps);
  if (!db) {
    return { isError: true, text: 'Database chưa sẵn sàng để lưu quy trình.' };
  }

  const flow = {
    id: newFlowId(),
    name,
    version: '2.0',
    remark: String(args.remark || '').replace(/\u2014/g, '-'),
    description: String(args.remark || '').replace(/\u2014/g, '-'),
    group: String(args.group || '').trim() || 'Chưa chia nhóm',
    category: String(args.group || '').trim() || 'general',
    graph,
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };

  let saved = null;
  try {
    if (typeof db.saveRpaFlow === 'function') {
      saved = await db.saveRpaFlow(flow);
    } else if (typeof db.createRpaFlow === 'function') {
      saved = await db.createRpaFlow(flow);
    } else if (typeof db.upsertRpaFlow === 'function') {
      saved = await db.upsertRpaFlow(flow);
    } else if (typeof db.createAutomationScript === 'function') {
      saved = await db.createAutomationScript({
        id: flow.id,
        name: flow.name,
        description: flow.remark,
        category: flow.category,
        icon: '⚡',
        steps: JSON.stringify(flow.graph),
      });
    } else {
      return { isError: true, text: 'Database chưa có hàm saveRpaFlow.' };
    }
  } catch (e) {
    return { isError: true, text: `Lưu quy trình thất bại: ${(e && e.message) || String(e)}` };
  }

  const savedId = (saved && saved.id) || flow.id;
  return {
    isError: false,
    text: `✓ Đã tạo quy trình "${name}" (id: ${savedId}) - ${summary}. Có thể chạy ngay bằng công cụ run_workflow.`,
    data: { workflowId: savedId, name, nodes: graph.nodes.length, edges: graph.connections.length },
  };
}

function findWorkflowInDb(db, ref) {
  const key = String(ref || '').trim();
  if (!key || !db) return null;
  if (typeof db.getRpaFlow === 'function') {
    const direct = db.getRpaFlow(key);
    if (direct) return direct;
  }
  if (typeof db.listRpaFlows === 'function') {
    const list = db.listRpaFlows() || [];
    const byId = list.find((f) => f && String(f.id) === key);
    if (byId) return byId;
    const lower = key.toLowerCase();
    const byName = list.find((f) => f && String(f.name || '').trim().toLowerCase() === lower);
    if (byName) return byName;
  }
  if (typeof db.getAutomationScript === 'function') {
    const sc = db.getAutomationScript(key);
    if (sc) {
      let parsed = sc.steps;
      if (typeof parsed === 'string') { try { parsed = JSON.parse(parsed); } catch { /* keep */ } }
      return { id: sc.id, name: sc.name, graph: Array.isArray(parsed) ? { steps: parsed } : parsed };
    }
  }
  if (typeof db.listAutomationScripts === 'function') {
    const list = db.listAutomationScripts() || [];
    const lower = key.toLowerCase();
    const sc = list.find((s) => s && (String(s.id) === key || String(s.name || '').trim().toLowerCase() === lower));
    if (sc) {
      let parsed = sc.steps;
      if (typeof parsed === 'string') { try { parsed = JSON.parse(parsed); } catch { /* keep */ } }
      return { id: sc.id, name: sc.name, graph: Array.isArray(parsed) ? { steps: parsed } : parsed };
    }
  }
  return null;
}

async function execRunWorkflow(args, overrideDeps) {
  const db = getDb(overrideDeps);
  const runner = getTaskRunner(overrideDeps);
  if (!db || !runner) return { isError: true, text: 'TaskRunner hoặc Database chưa sẵn sàng.' };

  const wfRef = String((args && (args.workflow || args.flowId)) || '').trim();
  if (!wfRef) return { isError: true, text: 'Thiếu tham số "workflow" (ID hoặc Tên quy trình).' };

  const flow = findWorkflowInDb(db, wfRef);
  if (!flow) return { isError: true, text: `Không tìm thấy quy trình "${wfRef}".` };

  const refs = refsFromArgs(args);
  if (!refs.length) return { isError: true, text: 'Thiếu danh sách hồ sơ cần chạy ("profileIds" hoặc "profile").' };

  const resolvedIds = [];
  const errs = [];
  for (const ref of refs) {
    const r = resolveProfile(db, ref);
    if (r.error) errs.push(r.error);
    else resolvedIds.push(r.profile.id);
  }
  if (errs.length) {
    return { isError: true, text: `Không thể chạy quy trình:\n- ${errs.join('\n- ')}` };
  }

  const runId = `mcp_batch_${Date.now().toString(36)}`;
  const config = {
    threads: Math.max(1, parseInt(args.threads, 10) || 1),
    keepOpen: Boolean(args.keepOpen),
  };

  if (args.async) {
    runner.runBatch({
      runId,
      flow,
      flowId: flow.id,
      flowName: flow.name,
      profileIds: resolvedIds,
      inputs: args.inputs || {},
      config,
    }).catch((err) => {
      console.error(`[MCP run_workflow async] ${runId} error:`, err.message);
    });
    return {
      isError: false,
      text: `✓ Đã khởi chạy nền quy trình "${flow.name}" (runId: ${runId}) trên ${resolvedIds.length} hồ sơ (${config.threads} luồng).`,
      data: { runId, async: true, workflowId: flow.id, profileIds: resolvedIds },
    };
  }

  const summary = await runner.runBatch({
    runId,
    flow,
    flowId: flow.id,
    flowName: flow.name,
    profileIds: resolvedIds,
    inputs: args.inputs || {},
    config,
  });

  return {
    isError: summary.status === 'error',
    text: `✓ Hoàn tất quy trình "${flow.name}" (trạng thái: ${summary.status}) - Thành công: ${summary.okCount}/${summary.total} hồ sơ (${summary.durationMs}ms).`,
    data: summary,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// JSON-RPC 2.0 & STREAMABLE HTTP DISPATCHER
// ─────────────────────────────────────────────────────────────────────────────

const RPC_PARSE = -32700;
const RPC_INVALID = -32600;
const RPC_NO_METHOD = -32601;
const RPC_INTERNAL = -32603;

const okResult = (id, result) => ({ jsonrpc: '2.0', id, result });
const rpcError = (id, code, message, data) => ({
  jsonrpc: '2.0',
  id,
  error: { code, message, ...(data ? { data } : {}) },
});

function formatToolResult(out) {
  const res = {
    content: [{ type: 'text', text: String((out && out.text) || '') }],
  };
  if (out && out.isError) res.isError = true;
  if (out && out.data !== undefined) res.structuredContent = out.data;
  return res;
}

const INSTRUCTIONS = [
  'CGT-Login v2.0 là nền tảng trình duyệt chống phát hiện đa hồ sơ tích hợp Visual RPA Engine & Wave/Lane Scheduler.',
  'Mọi công cụ tác động trực tiếp lên phiên CGT-Login đang chạy cục bộ (không giới hạn tính năng).',
  `Khi dựng quy trình mới bằng create_workflow, hãy đọc resource ${NODES_URI} trước và thử với dryRun=true để xác thực đồ thị.`,
].join(' ');

async function dispatch(method, params, overrideDeps) {
  if (method === 'initialize') {
    const want = params && params.protocolVersion;
    return {
      protocolVersion: PROTOCOLS.includes(want) ? want : PROTOCOL,
      capabilities: {
        tools: { listChanged: false },
        resources: { listChanged: false },
      },
      serverInfo: {
        name: SERVER_KEY,
        title: 'CGT-Login v2.0',
        version: SERVER_VERSION,
      },
      instructions: INSTRUCTIONS,
    };
  }

  if (method === 'notifications/initialized' || method === 'initialized') {
    return {};
  }

  if (method === 'ping') {
    return {};
  }

  if (method === 'tools/list') {
    return { tools: toolList() };
  }

  if (method === 'resources/list') {
    return {
      resources: [
        {
          uri: NODES_URI,
          name: 'Danh mục 52 Node RPA CGT-Login',
          description: 'Toàn bộ 52 loại node RPA cấu hình, toán tử điều kiện COND_OPS, kiểu biến VAR_TYPES và lược đồ tham số cho create_workflow.',
          mimeType: 'application/json',
        },
      ],
    };
  }

  if (method === 'resources/read') {
    const uri = params && params.uri;
    if (uri !== NODES_URI && uri !== 'polylogin://nodes') {
      throw Object.assign(new Error(`Không tồn tại resource "${uri}" (hỗ trợ: ${NODES_URI})`), { rpc: RPC_INVALID });
    }
    const doc = nodeCatalogDoc();
    return {
      contents: [
        {
          uri: NODES_URI,
          mimeType: 'application/json',
          text: JSON.stringify(doc, null, 2),
        },
      ],
    };
  }

  if (method === 'prompts/list') return { prompts: [] };
  if (method === 'resources/templates/list') return { resourceTemplates: [] };

  if (method === 'tools/call') {
    const name = params && params.name;
    const args = (params && params.arguments) || {};
    if (!CAP_BY_TOOL.has(name)) {
      return formatToolResult({ isError: true, text: `Không có công cụ "${name}".` });
    }
    try {
      let out;
      switch (name) {
        case 'list_profiles': out = await execListProfiles(args, overrideDeps); break;
        case 'open_profile': out = await execOpenProfile(args, overrideDeps); break;
        case 'close_profile': out = await execCloseProfile(args, overrideDeps); break;
        case 'delete_profile': out = await execDeleteProfile(args, overrideDeps); break;
        case 'create_workflow': out = await execCreateWorkflow(args, overrideDeps); break;
        case 'run_workflow': out = await execRunWorkflow(args, overrideDeps); break;
        default: out = { isError: true, text: `Chưa hỗ trợ công cụ "${name}"` };
      }
      return formatToolResult(out);
    } catch (e) {
      return formatToolResult({ isError: true, text: `Lỗi khi thực thi "${name}": ${(e && e.message) || String(e)}` });
    }
  }

  throw Object.assign(new Error(`Không hỗ trợ method "${method}"`), { rpc: RPC_NO_METHOD });
}

async function handleRpc(msg, overrideDeps) {
  const id = msg && typeof msg === 'object' && Object.prototype.hasOwnProperty.call(msg, 'id')
    ? msg.id
    : undefined;
  if (!msg || typeof msg !== 'object' || msg.jsonrpc !== '2.0' || typeof msg.method !== 'string') {
    return rpcError(id === undefined ? null : id, RPC_INVALID, 'Yêu cầu JSON-RPC 2.0 không hợp lệ');
  }
  // Notification (no `id`) -> execute silently and return null (HTTP 202)
  if (id === undefined) {
    try { await dispatch(msg.method, msg.params, overrideDeps); } catch { /* notification */ }
    return null;
  }
  try {
    return okResult(id, await dispatch(msg.method, msg.params, overrideDeps));
  } catch (e) {
    return rpcError(id, (e && e.rpc) || RPC_INTERNAL, (e && e.message) || 'Lỗi nội bộ MCP');
  }
}

/**
 * Strict Origin validation against DNS Rebinding attacks on loopback HTTP servers.
 */
function originOk(req) {
  const origin = req && req.headers && req.headers.origin;
  if (!origin) return true;
  if (/^(app|vscode-webview|file):\/\//i.test(origin)) return true;
  try {
    const h = new URL(origin).hostname.toLowerCase();
    return h === '127.0.0.1' || h === 'localhost' || h === '::1' || h === '[::1]';
  } catch {
    return false;
  }
}

function defaultSendJson(req, res, statusCode, payload) {
  const headers = {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
  };
  const origin = req && req.headers && req.headers.origin;
  if (origin && originOk(req)) {
    headers['Access-Control-Allow-Origin'] = origin;
    headers['Access-Control-Allow-Methods'] = 'POST, DELETE, OPTIONS';
    headers['Access-Control-Allow-Headers'] = 'Content-Type, Accept, Mcp-Session-Id, MCP-Protocol-Version';
  }
  res.writeHead(statusCode, headers);
  if (statusCode === 204 || statusCode === 202 || payload === undefined) {
    res.end();
  } else {
    res.end(JSON.stringify(payload));
  }
}

function defaultReadBody(req) {
  return new Promise((resolve) => {
    let raw = '';
    req.setEncoding('utf8');
    req.on('data', (chunk) => { raw += chunk; });
    req.on('end', () => {
      if (!raw.trim()) return resolve(null);
      try {
        resolve(JSON.parse(raw));
      } catch {
        resolve(null);
      }
    });
    req.on('error', () => resolve(null));
  });
}

/**
 * HTTP request handler for `/mcp`. Works both standalone `(req, res)` and with injected `overrideDeps`.
 */
async function handleRequest(req, res, overrideDeps = {}) {
  const method = (req.method || 'GET').toUpperCase();
  const send = (status, data) => {
    if (overrideDeps && typeof overrideDeps.sendJson === 'function') {
      if (status === 202 || status === 204) {
        res.writeHead(status).end();
        return;
      }
      overrideDeps.sendJson(res, status, data);
      return;
    }
    defaultSendJson(req, res, status, data);
  };

  if (!originOk(req)) {
    send(403, { error: 'Origin không được phép (DNS Rebinding Protection)' });
    return true;
  }

  if (method === 'OPTIONS') {
    defaultSendJson(req, res, 204);
    return true;
  }

  if (method === 'GET') {
    send(405, { error: 'Máy chủ MCP này hoạt động ở chế độ Stateless Streamable HTTP (chỉ nhận POST /mcp)' });
    return true;
  }

  if (method === 'DELETE') {
    defaultSendJson(req, res, 204);
    return true;
  }

  if (method !== 'POST') {
    send(405, { error: 'Phương thức HTTP không được hỗ trợ' });
    return true;
  }

  const body = overrideDeps && overrideDeps.parsedBody !== undefined
    ? overrideDeps.parsedBody
    : (overrideDeps && typeof overrideDeps.readBody === 'function'
      ? await overrideDeps.readBody(req)
      : await defaultReadBody(req));

  if (!body || typeof body !== 'object') {
    send(400, rpcError(null, RPC_PARSE, 'Body không phải JSON-RPC hợp lệ'));
    return true;
  }

  if (Array.isArray(body)) {
    if (!body.length) {
      send(400, rpcError(null, RPC_INVALID, 'Batch JSON-RPC rỗng'));
      return true;
    }
    const out = [];
    for (const item of body) {
      const r = await handleRpc(item, overrideDeps);
      if (r) out.push(r);
    }
    if (!out.length) {
      res.writeHead(202).end();
      return true;
    }
    send(200, out);
    return true;
  }

  const out = await handleRpc(body, overrideDeps);
  if (!out) {
    res.writeHead(202).end();
    return true;
  }
  send(200, out);
  return true;
}

module.exports = {
  PATH: MCP_PATH,
  MCP_PATH,
  SERVER_KEY,
  PROTOCOL,
  PROTOCOLS,
  NODES_URI,
  CAPS,
  init,
  handle: handleRequest,
  handleRequest,
  handleRpc,
  dispatch,
  originOk,
  getStatus,
  status: getStatus,
  endpointUrl,
  bridgePath: resolveBridgePath,
  clientEntry,
  configJson,
  configToml,
  toolList,
  nodeCatalogDoc,
  buildGraph: buildWorkflowGraph,
  buildWorkflowGraph,
};
