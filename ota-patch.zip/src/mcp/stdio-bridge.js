'use strict';

/**
 * CGT-Login v2.0 — MCP Stdio-to-Streamable-HTTP Bridge
 * Bridges line-delimited JSON-RPC 2.0 on `stdin`/`stdout` to `POST http://127.0.0.1:51888/mcp`.
 * Compatible with Claude Desktop, Cursor, Antigravity, VS Code, Windsurf, and OpenAI Codex.
 * Zero external npm dependencies.
 */

const http = require('node:http');
const https = require('node:https');

const TARGET = new URL(
  process.env.CGT_MCP_URL
  || process.env.PL_MCP_URL
  || `http://127.0.0.1:${process.env.PORT || 51888}/mcp`
);

const isHttps = TARGET.protocol === 'https:';
const transport = isHttps ? https : http;
const agent = new transport.Agent({ keepAlive: true, maxSockets: 4 });

const logErr = (msg) => {
  try { process.stderr.write(`[cgt-login-mcp] ${msg}\n`); } catch { /* ignore */ }
};

const writeOut = (obj) => {
  try { process.stdout.write(`${JSON.stringify(obj)}\n`); } catch { /* ignore */ }
};

function postRpc(rawBody) {
  return new Promise((resolve, reject) => {
    const buf = Buffer.from(rawBody, 'utf8');
    const req = transport.request({
      agent,
      hostname: TARGET.hostname,
      port: TARGET.port || (isHttps ? 443 : 80),
      path: TARGET.pathname + TARGET.search,
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        accept: 'application/json, text/event-stream',
        'content-length': buf.length,
      },
    }, (res) => {
      let data = '';
      res.setEncoding('utf8');
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => resolve({ status: res.statusCode || 0, data }));
    });
    req.on('error', reject);
    req.end(buf);
  });
}

function extractId(line) {
  try {
    const msg = JSON.parse(line);
    if (msg && typeof msg === 'object' && Object.prototype.hasOwnProperty.call(msg, 'id')) {
      return msg.id;
    }
  } catch { /* ignore */ }
  return undefined;
}

async function pumpLine(line) {
  const id = extractId(line);
  let res;
  try {
    res = await postRpc(line);
  } catch (err) {
    const detail = (err && err.message) || String(err);
    logErr(`Không kết nối được ${TARGET.href}: ${detail}`);
    if (id !== undefined) {
      writeOut({
        jsonrpc: '2.0',
        id,
        error: {
          code: -32001,
          message: `Không kết nối được máy chủ CGT-Login tại ${TARGET.href}. Hãy mở ứng dụng CGT-Login trước.`,
        },
      });
    }
    return;
  }

  const txt = (res.data || '').trim();
  // HTTP 202 with empty body = JSON-RPC notification acknowledged
  if (!txt) return;

  let parsed;
  try {
    parsed = JSON.parse(txt);
  } catch {
    logErr(`Phản hồi không phải JSON hợp lệ (HTTP ${res.status}): ${txt.slice(0, 200)}`);
    if (id !== undefined) {
      writeOut({
        jsonrpc: '2.0',
        id,
        error: {
          code: -32603,
          message: `CGT-Login trả về phản hồi không hợp lệ (HTTP ${res.status}).`,
        },
      });
    }
    return;
  }

  writeOut(parsed);
}

let buffer = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', (chunk) => {
  buffer += chunk;
  for (;;) {
    const idx = buffer.indexOf('\n');
    if (idx < 0) break;
    const line = buffer.slice(0, idx).trim();
    buffer = buffer.slice(idx + 1);
    if (line) pumpLine(line);
  }
});

process.stdin.on('end', () => {
  const tail = buffer.trim();
  if (tail) {
    pumpLine(tail).finally(() => process.exit(0));
  } else {
    process.exit(0);
  }
});

process.stdin.on('error', (err) => {
  logErr(`stdin error: ${(err && err.message) || err}`);
  process.exit(0);
});
