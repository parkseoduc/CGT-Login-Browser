'use strict';

module.exports = require('./mcp-server');
