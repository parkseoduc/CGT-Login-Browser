'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const eventBus = require('../core/event-bus');
const vault = require('./vault');
const pack = require('./pack');
const { sanitizeFileId } = require('./http-client');

const localProvider = require('./providers/local-fs');
const s3Provider = require('./providers/s3');
const gdriveProvider = require('./providers/gdrive');
const telegramProvider = require('./providers/telegram');

const PROVIDERS = {
  local: localProvider,
  s3: s3Provider,
  gdrive: gdriveProvider,
  telegram: telegramProvider,
};

// Anti-clobber session ledger:
//   profileId -> 'restored' | 'fresh' | 'restore-failed'
const _openState = new Map();
const _inflightUploads = new Set();

const sleep = (ms) =>
  new Promise((resolve) => {
    const t = setTimeout(resolve, ms);
    if (t.unref) t.unref();
  });

function withTimeout(promise, ms, timeoutMessage = 'CLOUD_SYNC_TIMEOUT') {
  let timer;
  const timeoutPromise = new Promise((_, reject) => {
    timer = setTimeout(() => {
      reject(Object.assign(new Error(timeoutMessage), { code: 'CLOUD_SYNC_TIMEOUT' }));
    }, ms);
    if (timer.unref) timer.unref();
  });
  return Promise.race([promise, timeoutPromise]).finally(() => clearTimeout(timer));
}

function normalizeDestName(dest) {
  const raw = String(dest || '').trim().toLowerCase();
  if (raw === 'local-fs' || raw === 'localfs' || raw === 'folder') return 'local';
  return raw;
}

function getProviderOrThrow(dest) {
  const key = normalizeDestName(dest);
  const provider = PROVIDERS[key];
  if (!provider) {
    throw Object.assign(
      new Error(`Nhà cung cấp đám mây không hợp lệ: "${dest}". Hỗ trợ: local, s3, gdrive, telegram.`),
      { code: 'INVALID_PROVIDER' }
    );
  }
  return { key, provider };
}

function resolveConnectedDest(explicitDest = '') {
  const settings = vault.getSettings();
  const candidate = normalizeDestName(explicitDest || settings.syncDest);

  if (candidate && PROVIDERS[candidate]) {
    const st = PROVIDERS[candidate].status();
    if (st && st.connected) {
      return { dest: candidate, provider: PROVIDERS[candidate], settings };
    }
    throw Object.assign(
      new Error(`Đích đồng bộ "${candidate}" chưa được kết nối.`),
      { code: 'NOT_CONNECTED' }
    );
  }

  // Fallback for manual push/pull if syncDest wasn't explicitly selected yet: pick first connected provider
  for (const [name, prov] of Object.entries(PROVIDERS)) {
    const st = prov.status();
    if (st && st.connected) {
      return { dest: name, provider: prov, settings };
    }
  }

  throw Object.assign(
    new Error('Chưa kết nối nhà cung cấp đồng bộ đám mây nào (local, s3, gdrive, telegram).'),
    { code: 'NOT_CONNECTED' }
  );
}

function getActiveAutoSyncContext() {
  const settings = vault.getSettings();
  const dest = normalizeDestName(settings.syncDest);
  if (!settings.syncEnabled || !dest || !PROVIDERS[dest]) {
    return null;
  }
  const st = PROVIDERS[dest].status();
  if (!st || !st.connected) {
    return null;
  }
  return {
    dest,
    provider: PROVIDERS[dest],
    passphrase: settings.vaultPassphrase || '',
  };
}

function emitProgress(profileId, phase, dest, message = '', extra = {}) {
  try {
    eventBus.publish('cloud:progress', {
      profileId: profileId != null ? String(profileId) : null,
      phase,
      dest: dest || '',
      message,
      timestamp: new Date().toISOString(),
      ...extra,
    });
  } catch {
    // Never let event listeners interrupt sync lifecycle
  }
}

function ensureTmpFilePath(prefix, profileId) {
  const tmpDir = path.join(vault.getDataDir(), 'cloud-sync-tmp');
  fs.mkdirSync(tmpDir, { recursive: true });
  const rand = crypto.randomBytes(4).toString('hex');
  return path.join(tmpDir, `${prefix}-${sanitizeFileId(profileId)}-${process.pid}-${Date.now()}-${rand}.tgz`);
}

async function manifestWithRetry(profileId, opts = {}, tries = 10, baseDelayMs = 350) {
  let lastErr;
  for (let i = 0; i < tries; i += 1) {
    try {
      return pack.manifest(profileId, { userDataDir: opts.userDataDir });
    } catch (err) {
      lastErr = err;
      if (i < tries - 1) {
        await sleep(Math.min(1200, baseDelayMs + i * 150));
      }
    }
  }
  throw lastErr || new Error('MANIFEST_FAILED');
}

async function packWithRetry(profileId, opts = {}, tries = 12, baseDelayMs = 400) {
  let lastErr;
  for (let i = 0; i < tries; i += 1) {
    try {
      return await pack.pack(profileId, {
        passphrase: opts.passphrase,
        userDataDir: opts.userDataDir,
      });
    } catch (err) {
      if (err && (err.code === 'PROFILE_DATA_EMPTY' || err.code === 'PROFILE_DATA_NOT_FOUND')) {
        throw err;
      }
      lastErr = err;
      if (i < tries - 1) {
        await sleep(Math.min(1500, baseDelayMs + i * 150));
      }
    }
  }
  throw lastErr || new Error('PACK_FAILED');
}

// ─────────────────────────────────────────────────────── Public Orchestrator API

function getStatus() {
  const settings = vault.getSettings();
  const syncDest = normalizeDestName(settings.syncDest);
  const syncedIds = vault.getSyncedIds();

  return {
    syncEnabled: Boolean(settings.syncEnabled),
    syncDest,
    e2eeEnabled: Boolean(settings.vaultPassphrase && settings.vaultPassphrase.length > 0),
    providers: {
      local: localProvider.status(),
      s3: s3Provider.status(),
      gdrive: gdriveProvider.status(),
      telegram: telegramProvider.status(),
    },
    syncedCount: syncedIds.length,
  };
}

function updateSettings({ syncEnabled, syncDest, vaultPassphrase } = {}) {
  const patch = {};
  if (syncEnabled !== undefined) {
    patch.syncEnabled = Boolean(syncEnabled);
  }
  if (syncDest !== undefined) {
    const normDest = normalizeDestName(syncDest);
    if (normDest !== '' && !PROVIDERS[normDest]) {
      throw Object.assign(
        new Error(`Đích đồng bộ không hợp lệ: "${syncDest}". Hỗ trợ: local, s3, gdrive, telegram.`),
        { code: 'INVALID_PROVIDER' }
      );
    }
    patch.syncDest = normDest;
  }
  if (vaultPassphrase !== undefined) {
    patch.vaultPassphrase = vaultPassphrase === null ? '' : String(vaultPassphrase);
  }

  vault.updateSettings(patch);
  const st = getStatus();
  emitProgress(null, 'settings-updated', st.syncDest, 'Đã cập nhật cấu hình đồng bộ đám mây');
  return st;
}

async function connectProvider(dest, config = {}) {
  const { key, provider } = getProviderOrThrow(dest);
  const providerStatus = await provider.connect(config);

  // Auto-select this provider as syncDest if none was selected yet
  const curSettings = vault.getSettings();
  if (!curSettings.syncDest) {
    vault.updateSettings({ syncDest: key });
  }

  const syncStatus = getStatus();
  emitProgress(null, 'provider-connected', key, `Đã kết nối ${key}`);
  return {
    ...providerStatus,
    sync: syncStatus,
  };
}

async function disconnectProvider(dest) {
  const { key, provider } = getProviderOrThrow(dest);
  const providerStatus = await provider.disconnect();
  const syncStatus = getStatus();
  emitProgress(null, 'provider-disconnected', key, `Đã ngắt kết nối ${key}`);
  return {
    ...providerStatus,
    sync: syncStatus,
  };
}

/**
 * Lifecycle hook BEFORE launching browser profile.
 * Downloads & unpacks cloud archive if auto-sync is enabled.
 * Records _openState ('restored' | 'fresh' | 'restore-failed') for anti-clobber protection.
 */
async function beforeOpen(profileId, opts = {}) {
  const id = String(profileId);
  const ctx = getActiveAutoSyncContext();
  if (!ctx) {
    return { synced: false, reason: 'off' };
  }

  const { dest, provider } = ctx;
  const passphrase = opts.passphrase !== undefined ? String(opts.passphrase || '') : ctx.passphrase;
  const timeoutMs = opts.timeoutMs || 30000;
  const tmpFile = ensureTmpFilePath('dl', id);

  emitProgress(id, 'download', dest, 'Đang tải dữ liệu hồ sơ từ đám mây…');

  try {
    const dl = await withTimeout(
      provider.download(id, tmpFile),
      timeoutMs,
      'Quá thời gian tải dữ liệu đám mây — mở bằng dữ liệu cục bộ'
    );

    if (!dl || !dl.found) {
      _openState.set(id, 'fresh');
      emitProgress(id, 'idle', dest, '');
      return { synced: false, reason: 'no-backup', state: 'fresh' };
    }

    emitProgress(id, 'unpack', dest, 'Đang giải nén và khôi phục hồ sơ…');
    const mf = await pack.unpack(id, tmpFile, {
      mode: opts.mode || 'merge',
      passphrase,
      userDataDir: opts.userDataDir,
    });

    vault.setProfileSyncState(id, {
      digest: mf.digest,
      dest,
      size: dl.size || mf.totalBytes,
      encrypted: Boolean(passphrase),
      syncedAt: new Date().toISOString(),
    });

    _openState.set(id, 'restored');
    emitProgress(id, 'done', dest, 'Đã khôi phục dữ liệu hồ sơ từ đám mây');
    return {
      synced: true,
      reason: 'restored',
      state: 'restored',
      dest,
      digest: mf.digest,
    };
  } catch (err) {
    // Cloud had a backup (or failed mid-flight / E2EE passphrase mismatch):
    // mark 'restore-failed' so afterClose() will NEVER clobber the cloud backup!
    _openState.set(id, 'restore-failed');
    const message = (err && err.message) || 'Khôi phục dữ liệu đám mây thất bại';
    emitProgress(id, 'error', dest, message, { code: err && err.code });
    return {
      synced: false,
      reason: 'restore-failed',
      state: 'restore-failed',
      error: message,
      code: err && err.code,
    };
  } finally {
    try {
      if (fs.existsSync(tmpFile)) fs.rmSync(tmpFile, { force: true });
    } catch {
      // ignore
    }
  }
}

/**
 * Lifecycle hook AFTER closing browser profile.
 * Enforces:
 *   1. Anti-clobber guard (skips upload if _openState === 'restore-failed')
 *   2. SHA-256 delta check (skips upload if digest, dest & E2EE state are unchanged)
 */
async function afterClose(profileId, opts = {}) {
  const id = String(profileId);
  if (_inflightUploads.has(id)) {
    return { synced: false, reason: 'inflight' };
  }

  const openSt = _openState.get(id);
  _openState.delete(id);

  const ctx = getActiveAutoSyncContext();
  if (!ctx) {
    return { synced: false, reason: 'off' };
  }

  const { dest, provider } = ctx;
  const passphrase = opts.passphrase !== undefined ? String(opts.passphrase || '') : ctx.passphrase;
  const wantEncrypted = Boolean(passphrase);

  // 1. ANTI-CLOBBER GUARD
  if (openSt === 'restore-failed') {
    const msg = 'Giữ nguyên bản sao lưu trên đám mây (bỏ qua tải lên do lần mở trước khôi phục lỗi)';
    emitProgress(id, 'skipped', dest, msg, { reason: 'restore-failed' });
    return { synced: false, skipped: true, reason: 'restore-failed-skip' };
  }

  _inflightUploads.add(id);

  try {
    // 2. Pre-pack SHA-256 delta check to avoid unnecessary tar + encryption + network upload
    if (!opts.force) {
      const mf = await manifestWithRetry(id, { userDataDir: opts.userDataDir });
      if (mf.fileCount === 0) {
        emitProgress(id, 'idle', dest, '');
        return { synced: false, reason: 'empty' };
      }

      const prev = vault.getProfileSyncState(id);
      const encryptionMatches =
        prev && (prev.encrypted === undefined || Boolean(prev.encrypted) === wantEncrypted);

      if (prev && prev.digest === mf.digest && prev.dest === dest && encryptionMatches) {
        emitProgress(id, 'done', dest, 'Dữ liệu không đổi (bỏ qua tải lên)', { unchanged: true });
        return { synced: true, skipped: true, reason: 'unchanged', digest: mf.digest, dest };
      }
    }

    // 3. Stage, pack (& optionally E2EE encrypt) with retry for lingering Windows SQLite handles
    emitProgress(id, 'pack', dest, 'Đang đóng gói dữ liệu hồ sơ…');
    let packed;
    try {
      packed = await packWithRetry(id, {
        passphrase,
        userDataDir: opts.userDataDir,
      });
    } catch (err) {
      if (err && (err.code === 'PROFILE_DATA_EMPTY' || err.code === 'PROFILE_DATA_NOT_FOUND')) {
        emitProgress(id, 'idle', dest, '');
        return { synced: false, reason: 'empty' };
      }
      throw err;
    }

    // Secondary delta check on exact staged snapshot digest
    if (!opts.force) {
      const prev = vault.getProfileSyncState(id);
      const encryptionMatches =
        prev && (prev.encrypted === undefined || Boolean(prev.encrypted) === wantEncrypted);
      if (prev && prev.digest === packed.digest && prev.dest === dest && encryptionMatches) {
        try {
          if (fs.existsSync(packed.path)) fs.rmSync(packed.path, { force: true });
        } catch {
          // ignore
        }
        emitProgress(id, 'done', dest, 'Dữ liệu không đổi (bỏ qua tải lên)', { unchanged: true });
        return { synced: true, skipped: true, reason: 'unchanged', digest: packed.digest, dest };
      }
    }

    // 4. Upload to active cloud destination
    emitProgress(id, 'upload', dest, `Đang đồng bộ lên ${dest}…`);
    let uploadRes;
    try {
      uploadRes = await provider.upload(id, packed.path);
    } finally {
      try {
        if (packed && packed.path && fs.existsSync(packed.path)) {
          fs.rmSync(packed.path, { force: true });
        }
      } catch {
        // ignore
      }
    }

    const syncedAt = new Date().toISOString();
    vault.setProfileSyncState(id, {
      digest: packed.digest,
      dest,
      size: packed.size,
      encrypted: packed.encrypted,
      syncedAt,
    });

    const targetLabel = (uploadRes && uploadRes.target) ? ` (${uploadRes.target})` : '';
    emitProgress(id, 'done', dest, `Đã đồng bộ thành công${targetLabel}`, {
      size: packed.size,
      encrypted: packed.encrypted,
    });

    return {
      synced: true,
      dest,
      digest: packed.digest,
      size: packed.size,
      encrypted: packed.encrypted,
      syncedAt,
    };
  } catch (err) {
    const message = (err && err.message) || 'Đồng bộ sau khi đóng thất bại';
    emitProgress(id, 'error', dest, message, { code: err && err.code });
    return {
      synced: false,
      reason: 'upload-error',
      error: message,
      code: err && err.code,
    };
  } finally {
    _inflightUploads.delete(id);
  }
}

/**
 * Manual on-demand push of a single profile to the connected cloud provider.
 */
async function pushProfile(profileId, opts = {}) {
  const id = String(profileId);
  const { dest, provider, settings } = resolveConnectedDest(opts.dest);
  const passphrase =
    opts.passphrase !== undefined ? String(opts.passphrase || '') : settings.vaultPassphrase || '';

  emitProgress(id, 'pack', dest, 'Đang đóng gói hồ sơ để đẩy lên đám mây…');
  let packed = null;

  try {
    packed = await packWithRetry(id, {
      passphrase,
      userDataDir: opts.userDataDir,
    });

    emitProgress(id, 'upload', dest, `Đang đẩy hồ sơ lên ${dest}…`);
    const uploadRes = await provider.upload(id, packed.path);
    const syncedAt = new Date().toISOString();

    vault.setProfileSyncState(id, {
      digest: packed.digest,
      dest,
      size: packed.size,
      encrypted: packed.encrypted,
      syncedAt,
    });

    emitProgress(id, 'done', dest, `Đã đẩy hồ sơ lên ${dest} thành công`, {
      size: packed.size,
      encrypted: packed.encrypted,
    });

    return {
      ok: true,
      synced: true,
      profileId: id,
      dest,
      digest: packed.digest,
      size: packed.size,
      encrypted: packed.encrypted,
      target: uploadRes && uploadRes.target,
      syncedAt,
    };
  } catch (err) {
    emitProgress(id, 'error', dest, (err && err.message) || 'Đẩy hồ sơ thất bại', {
      code: err && err.code,
    });
    throw err;
  } finally {
    try {
      if (packed && packed.path && fs.existsSync(packed.path)) {
        fs.rmSync(packed.path, { force: true });
      }
    } catch {
      // ignore
    }
  }
}

/**
 * Manual on-demand pull & restore of a single profile from the connected cloud provider.
 */
async function pullProfile(profileId, opts = {}) {
  const id = String(profileId);
  const { dest, provider, settings } = resolveConnectedDest(opts.dest);
  const passphrase =
    opts.passphrase !== undefined ? String(opts.passphrase || '') : settings.vaultPassphrase || '';
  const tmpFile = ensureTmpFilePath('pull', id);

  emitProgress(id, 'download', dest, `Đang kéo hồ sơ từ ${dest}…`);

  try {
    const dl = await provider.download(id, tmpFile);
    if (!dl || !dl.found) {
      emitProgress(id, 'idle', dest, 'Không tìm thấy bản sao lưu trên đám mây');
      throw Object.assign(new Error('CLOUD_BACKUP_NOT_FOUND'), {
        code: 'CLOUD_BACKUP_NOT_FOUND',
        profileId: id,
        dest,
      });
    }

    emitProgress(id, 'unpack', dest, 'Đang giải nén và khôi phục hồ sơ…');
    const mf = await pack.unpack(id, tmpFile, {
      mode: opts.mode || 'merge',
      passphrase,
      userDataDir: opts.userDataDir,
    });

    const syncedAt = new Date().toISOString();
    vault.setProfileSyncState(id, {
      digest: mf.digest,
      dest,
      size: dl.size || mf.totalBytes,
      encrypted: Boolean(passphrase),
      syncedAt,
    });

    // Clear any prior 'restore-failed' state since profile is now cleanly restored
    _openState.set(id, 'restored');

    emitProgress(id, 'done', dest, `Đã khôi phục hồ sơ từ ${dest} thành công`);
    return {
      ok: true,
      synced: true,
      found: true,
      profileId: id,
      dest,
      digest: mf.digest,
      fileCount: mf.fileCount,
      totalBytes: mf.totalBytes,
      syncedAt,
    };
  } catch (err) {
    emitProgress(id, 'error', dest, (err && err.message) || 'Kéo hồ sơ thất bại', {
      code: err && err.code,
    });
    throw err;
  } finally {
    try {
      if (fs.existsSync(tmpFile)) fs.rmSync(tmpFile, { force: true });
    } catch {
      // ignore
    }
  }
}

async function listBackups(dest = '') {
  const { dest: resolvedDest, provider } = resolveConnectedDest(dest);
  const backups = await provider.listBackups();
  return {
    dest: resolvedDest,
    backups,
  };
}

function isProfileSynced(profileId) {
  return Boolean(vault.getProfileSyncState(profileId));
}

function getSyncedIds() {
  return vault.getSyncedIds();
}

module.exports = {
  getStatus,
  updateSettings,
  connectProvider,
  disconnectProvider,
  beforeOpen,
  afterClose,
  pushProfile,
  pullProfile,
  listBackups,
  isProfileSynced,
  getSyncedIds,
  vault,
  pack,
  providers: PROVIDERS,
  _openState,
};
