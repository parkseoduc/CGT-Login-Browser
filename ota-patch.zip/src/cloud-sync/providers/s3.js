'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { URL } = require('node:url');
const vault = require('../vault');
const {
  backupFilename,
  parseProfileIdFromFilename,
  httpRequest,
} = require('../http-client');

const EMPTY_SHA256 = crypto.createHash('sha256').update('').digest('hex');

function sha256hex(data) {
  return crypto.createHash('sha256').update(data).digest('hex');
}

function hmac(key, str) {
  return crypto.createHmac('sha256', key).update(str, 'utf8').digest();
}

// RFC 3986 strict percent-encoding required by AWS Signature V4
function enc(str) {
  return encodeURIComponent(String(str)).replace(
    /[!*'()]/g,
    (c) => '%' + c.charCodeAt(0).toString(16).toUpperCase()
  );
}

function signS3Request(cfg, { method, subPath, query = {}, payloadHash = EMPTY_SHA256 }) {
  const u = new URL(cfg.endpoint);
  const host = u.host;
  const basePath = u.pathname.replace(/\/+$/, '');
  const canonicalUri = `${basePath}${subPath}` || '/';
  const region = cfg.region || 'us-east-1';
  const service = 's3';

  const now = new Date();
  const amzdate = now.toISOString().replace(/[:-]|\.\d{3}/g, ''); // YYYYMMDDTHHMMSSZ
  const datestamp = amzdate.slice(0, 8);

  const canonicalQuery = Object.keys(query)
    .sort()
    .map((k) => `${enc(k)}=${enc(String(query[k]))}`)
    .join('&');

  const canonicalHeaders =
    `host:${host}\n` +
    `x-amz-content-sha256:${payloadHash}\n` +
    `x-amz-date:${amzdate}\n`;
  const signedHeaders = 'host;x-amz-content-sha256;x-amz-date';

  const canonicalRequest = [
    method.toUpperCase(),
    canonicalUri,
    canonicalQuery,
    canonicalHeaders,
    signedHeaders,
    payloadHash,
  ].join('\n');

  const scope = `${datestamp}/${region}/${service}/aws4_request`;
  const stringToSign = [
    'AWS4-HMAC-SHA256',
    amzdate,
    scope,
    sha256hex(Buffer.from(canonicalRequest, 'utf8')),
  ].join('\n');

  const kDate = hmac(`AWS4${cfg.secretAccessKey}`, datestamp);
  const kRegion = hmac(kDate, region);
  const kService = hmac(kRegion, service);
  const kSigning = hmac(kService, 'aws4_request');
  const signature = crypto.createHmac('sha256', kSigning).update(stringToSign, 'utf8').digest('hex');

  const authorization =
    `AWS4-HMAC-SHA256 Credential=${cfg.accessKeyId}/${scope}, ` +
    `SignedHeaders=${signedHeaders}, Signature=${signature}`;

  const qs = canonicalQuery ? `?${canonicalQuery}` : '';
  const url = `${u.protocol}//${host}${canonicalUri}${qs}`;
  const headers = {
    'x-amz-date': amzdate,
    'x-amz-content-sha256': payloadHash,
    Authorization: authorization,
  };

  return { url, headers };
}

function objectKey(cfg, filename) {
  const pfx = String(cfg.prefix || '').replace(/^\/+|\/+$/g, '');
  return pfx ? `${pfx}/${filename}` : filename;
}

function objectSubPath(cfg, key) {
  const encodedKey = String(key)
    .split('/')
    .map(enc)
    .join('/');
  return `/${enc(cfg.bucket)}/${encodedKey}`;
}

function decodeXml(s) {
  return String(s || '')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&amp;/g, '&');
}

function firstTag(block, tag) {
  const m = new RegExp(`<${tag}>([\\s\\S]*?)</${tag}>`).exec(block || '');
  return m ? decodeXml(m[1]) : '';
}

function normalizeConfig(input = {}) {
  const region = String(input.region || '').trim() || 'us-east-1';
  let endpoint = String(input.endpoint || '').trim().replace(/\/+$/, '');
  if (!endpoint && region && region !== 'auto') {
    endpoint = `https://s3.${region}.amazonaws.com`;
  } else if (endpoint && !/^https?:\/\//i.test(endpoint)) {
    endpoint = `https://${endpoint}`;
  }

  return {
    endpoint,
    region,
    bucket: String(input.bucket || '').trim(),
    accessKeyId: String(input.accessKeyId || '').trim(),
    secretAccessKey: String(input.secretAccessKey || '').trim(),
    prefix: String(input.prefix || '').trim().replace(/^\/+|\/+$/g, ''),
  };
}

function publicConfig(cfg) {
  if (!cfg) return null;
  return {
    endpoint: cfg.endpoint || '',
    region: cfg.region || 'us-east-1',
    bucket: cfg.bucket || '',
    accessKeyId: cfg.accessKeyId || '',
    prefix: cfg.prefix || '',
    hasSecretAccessKey: Boolean(cfg.secretAccessKey),
  };
}

function getConfigOrThrow() {
  const st = vault.getProviderState('s3');
  if (!st.connected || !st.config) {
    throw Object.assign(new Error('Chưa kết nối S3/R2/MinIO'), { code: 'NOT_CONNECTED' });
  }
  return st.config;
}

async function listObjectsV2(cfg, { maxKeys = 1000 } = {}) {
  const subPath = `/${enc(cfg.bucket)}`;
  const items = [];
  let continuationToken = '';

  do {
    const query = {
      'list-type': '2',
      'max-keys': String(Math.min(1000, maxKeys - items.length)),
    };
    if (cfg.prefix) query.prefix = `${cfg.prefix}/`;
    if (continuationToken) query['continuation-token'] = continuationToken;

    const { url, headers } = signS3Request(cfg, {
      method: 'GET',
      subPath,
      query,
      payloadHash: EMPTY_SHA256,
    });

    let res;
    try {
      res = await httpRequest(url, { method: 'GET', headers, timeoutMs: 30000 });
    } catch (err) {
      throw Object.assign(new Error(`Không kết nối được endpoint S3: ${err.message}`), {
        code: 'S3_NETWORK',
        cause: err,
      });
    }

    const text = res.text();
    if (!res.ok) {
      const code = firstTag(text, 'Code') || `HTTP_${res.status}`;
      const msg = firstTag(text, 'Message') || '';
      throw Object.assign(new Error(msg ? `${code}: ${msg}` : `Lỗi S3 (${code})`), {
        code,
        status: res.status,
      });
    }

    const re = /<Contents>([\s\S]*?)<\/Contents>/g;
    let m;
    while ((m = re.exec(text)) !== null) {
      const block = m[1];
      items.push({
        key: firstTag(block, 'Key'),
        size: Number(firstTag(block, 'Size') || 0),
        lastModified: firstTag(block, 'LastModified'),
      });
    }

    const isTruncated = firstTag(text, 'IsTruncated').toLowerCase() === 'true';
    continuationToken = isTruncated ? firstTag(text, 'NextContinuationToken') : '';
  } while (continuationToken && items.length < maxKeys);

  return items;
}

function resolveUploadArgs(arg1, arg2) {
  if (arg1 && typeof arg1 === 'object') {
    const profileId = arg1.profileId || parseProfileIdFromFilename(arg1.filename || '');
    const localFile = arg1.localFile || arg1.filePath;
    const filename = arg1.filename || backupFilename(profileId);
    return { profileId: String(profileId), localFile, filename };
  }
  const profileId = String(arg1);
  return { profileId, localFile: arg2, filename: backupFilename(profileId) };
}

function resolveDownloadArgs(arg1, arg2) {
  if (arg1 && typeof arg1 === 'object') {
    const profileId = arg1.profileId || parseProfileIdFromFilename(arg1.filename || '');
    const destFile = arg1.destFile || arg1.destPath;
    const filename = arg1.filename || backupFilename(profileId);
    return { profileId: String(profileId), destFile, filename };
  }
  const profileId = String(arg1);
  return { profileId, destFile: arg2, filename: backupFilename(profileId) };
}

function atomicWriteFileSync(destFile, buf) {
  fs.mkdirSync(path.dirname(destFile), { recursive: true });
  const tmpFile = `${destFile}.${process.pid}.${Date.now()}.${crypto.randomBytes(4).toString('hex')}.tmp`;
  try {
    fs.writeFileSync(tmpFile, buf);
    try {
      fs.renameSync(tmpFile, destFile);
    } catch {
      fs.copyFileSync(tmpFile, destFile);
      fs.unlinkSync(tmpFile);
    }
  } finally {
    try {
      if (fs.existsSync(tmpFile)) fs.unlinkSync(tmpFile);
    } catch {
      // ignore
    }
  }
}

function status() {
  const st = vault.getProviderState('s3');
  const connected = Boolean(st.connected && st.config && st.config.bucket);
  return {
    connected,
    provider: 's3',
    config: connected ? publicConfig(st.config) : null,
  };
}

async function connect(input = {}) {
  // Support preserving existing secretAccessKey when user updates prefix/region without retyping secret
  const existing = vault.getProviderState('s3');
  const mergedInput = { ...(input || {}) };
  if (!mergedInput.secretAccessKey && existing.config && existing.config.secretAccessKey) {
    mergedInput.secretAccessKey = existing.config.secretAccessKey;
  }

  const cfg = normalizeConfig(mergedInput);
  const missing = [];
  if (!cfg.bucket) missing.push('bucket');
  if (!cfg.endpoint) missing.push('endpoint');
  if (!cfg.accessKeyId) missing.push('accessKeyId');
  if (!cfg.secretAccessKey) missing.push('secretAccessKey');

  if (missing.length) {
    throw Object.assign(new Error(`Thiếu cấu hình S3 bắt buộc: ${missing.join(', ')}`), {
      code: 'MISSING_FIELDS',
    });
  }

  await listObjectsV2(cfg, { maxKeys: 1 });
  vault.setProviderState('s3', { connected: true, config: cfg });
  return status();
}

async function disconnect() {
  vault.clearProviderState('s3');
  return status();
}

async function upload(arg1, arg2) {
  const { localFile, filename } = resolveUploadArgs(arg1, arg2);
  const cfg = getConfigOrThrow();

  if (!localFile || !fs.existsSync(localFile)) {
    throw Object.assign(new Error('S3_SOURCE_NOT_FOUND'), { code: 'S3_SOURCE_NOT_FOUND' });
  }

  const body = fs.readFileSync(localFile);
  const payloadHash = sha256hex(body);
  const key = objectKey(cfg, filename);
  const subPath = objectSubPath(cfg, key);
  const { url, headers } = signS3Request(cfg, {
    method: 'PUT',
    subPath,
    payloadHash,
  });
  headers['Content-Type'] = 'application/octet-stream';

  let res;
  try {
    res = await httpRequest(url, {
      method: 'PUT',
      headers,
      body,
      timeoutMs: 5 * 60 * 1000,
    });
  } catch (err) {
    throw Object.assign(new Error(`Không tải lên được S3: ${err.message}`), {
      code: 'S3_NETWORK',
      cause: err,
    });
  }

  if (!res.ok) {
    const text = res.text();
    const code = firstTag(text, 'Code') || `HTTP_${res.status}`;
    const msg = firstTag(text, 'Message') || '';
    throw Object.assign(new Error(msg ? `${code}: ${msg}` : `Lỗi S3 PUT (${code})`), {
      code,
      status: res.status,
    });
  }

  return {
    ok: true,
    provider: 's3',
    key,
    target: cfg.prefix ? `${cfg.bucket}/${cfg.prefix}` : cfg.bucket,
    size: body.length,
  };
}

async function download(arg1, arg2) {
  const { destFile, filename } = resolveDownloadArgs(arg1, arg2);
  const cfg = getConfigOrThrow();
  const key = objectKey(cfg, filename);
  const subPath = objectSubPath(cfg, key);
  const { url, headers } = signS3Request(cfg, {
    method: 'GET',
    subPath,
    payloadHash: EMPTY_SHA256,
  });

  let res;
  try {
    res = await httpRequest(url, {
      method: 'GET',
      headers,
      timeoutMs: 5 * 60 * 1000,
    });
  } catch (err) {
    throw Object.assign(new Error(`Không tải được từ S3: ${err.message}`), {
      code: 'S3_NETWORK',
      cause: err,
    });
  }

  if (res.status === 404) {
    return { found: false, path: null };
  }
  if (!res.ok) {
    const text = res.text();
    const code = firstTag(text, 'Code') || `HTTP_${res.status}`;
    if (code === 'NoSuchKey') {
      return { found: false, path: null };
    }
    const msg = firstTag(text, 'Message') || '';
    throw Object.assign(new Error(msg ? `${code}: ${msg}` : `Lỗi S3 GET (${code})`), {
      code,
      status: res.status,
    });
  }

  atomicWriteFileSync(destFile, res.body);
  return { found: true, path: destFile, size: res.body.length };
}

async function listBackups() {
  const cfg = getConfigOrThrow();
  const items = await listObjectsV2(cfg, { maxKeys: 2000 });
  const backups = [];

  for (const it of items) {
    const baseName = String(it.key || '').split('/').pop() || '';
    const profileId = parseProfileIdFromFilename(baseName);
    if (!profileId) continue;
    backups.push({
      id: it.key,
      key: it.key,
      profileId,
      name: baseName,
      size: it.size,
      updatedAt: it.lastModified || '',
      createdTime: it.lastModified || '',
    });
  }

  backups.sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || ''));
  return backups;
}

module.exports = {
  status,
  connect,
  disconnect,
  upload,
  download,
  listBackups,
  _signS3Request: signS3Request,
};
