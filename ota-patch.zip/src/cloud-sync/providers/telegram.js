'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const vault = require('../vault');
const {
  backupFilename,
  parseProfileIdFromFilename,
  httpRequest,
  buildMultipartFormData,
} = require('../http-client');

const TG_API_BASE = 'https://api.telegram.org';
const TG_MAX_BOT_DOWNLOAD_BYTES = 20 * 1024 * 1024; // Telegram Bot API getFile 20MB limit
const INDEX_FILENAME = 'cgt-sync-index.json';
const INDEX_CAPTION = '#CGT_LOGIN_SYNC_INDEX v2 (Do not delete)';
const BACKUP_CAPTION_PREFIX = '#cgt_profile_backup:';

function atomicWriteFileSync(destFile, buf) {
  fs.mkdirSync(path.dirname(destFile), { recursive: true });
  const tmpFile = `${destFile}.${process.pid}.${Date.now()}.${crypto.randomBytes(4).toString('hex')}.tmp`;
  try {
    fs.writeFileSync(tmpFile, buf);
    try {
      fs.renameSync(tmpFile, destFile);
    } catch {
      fs.copyFileSync(tmpFile, destFile);
      fs.unlinkSync(tmpFile);
    }
  } finally {
    try {
      if (fs.existsSync(tmpFile)) fs.unlinkSync(tmpFile);
    } catch {
      // ignore
    }
  }
}

function resolveUploadArgs(arg1, arg2) {
  if (arg1 && typeof arg1 === 'object') {
    const profileId = arg1.profileId || parseProfileIdFromFilename(arg1.filename || '');
    const localFile = arg1.localFile || arg1.filePath;
    const filename = arg1.filename || backupFilename(profileId);
    return { profileId: String(profileId), localFile, filename };
  }
  const profileId = String(arg1);
  return { profileId, localFile: arg2, filename: backupFilename(profileId) };
}

function resolveDownloadArgs(arg1, arg2) {
  if (arg1 && typeof arg1 === 'object') {
    const profileId = arg1.profileId || parseProfileIdFromFilename(arg1.filename || '');
    const destFile = arg1.destFile || arg1.destPath;
    const filename = arg1.filename || backupFilename(profileId);
    return { profileId: String(profileId), destFile, filename };
  }
  const profileId = String(arg1);
  return { profileId, destFile: arg2, filename: backupFilename(profileId) };
}

function getStateOrThrow() {
  const st = vault.getProviderState('telegram');
  if (!st.connected || !st.config || !st.config.botToken || !st.config.chatId) {
    throw Object.assign(new Error('Chưa kết nối Telegram Bot Cloud'), { code: 'NOT_CONNECTED' });
  }
  const index = st.index && typeof st.index === 'object'
    ? { indexMessageId: st.index.indexMessageId || null, profiles: { ...(st.index.profiles || {}) } }
    : { indexMessageId: null, profiles: {} };
  return { config: st.config, index };
}

async function tgApiJson(botToken, methodName, payload = {}, timeoutMs = 30000) {
  const url = `${TG_API_BASE}/bot${botToken}/${methodName}`;
  let res;
  try {
    res = await httpRequest(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json; charset=utf-8' },
      body: JSON.stringify(payload),
      timeoutMs,
    });
  } catch (err) {
    throw Object.assign(new Error(`Không kết nối được Telegram API (${methodName}): ${err.message}`), {
      code: 'TELEGRAM_NETWORK',
      cause: err,
    });
  }

  let data = {};
  try {
    data = res.json();
  } catch {
    data = {};
  }

  if (!res.ok || !data.ok) {
    const desc = data.description || `Telegram HTTP ${res.status}`;
    throw Object.assign(new Error(`Telegram API (${methodName}): ${desc}`), {
      code: `TG_${data.error_code || res.status}`,
      status: data.error_code || res.status,
      description: desc,
    });
  }

  return data.result;
}

async function tgApiMultipart(botToken, methodName, fields, files, timeoutMs = 5 * 60 * 1000) {
  const url = `${TG_API_BASE}/bot${botToken}/${methodName}`;
  const mp = buildMultipartFormData(fields, files);
  let res;
  try {
    res = await httpRequest(url, {
      method: 'POST',
      headers: { 'Content-Type': mp.contentType },
      body: mp.body,
      timeoutMs,
    });
  } catch (err) {
    throw Object.assign(new Error(`Không tải lên được Telegram (${methodName}): ${err.message}`), {
      code: 'TELEGRAM_NETWORK',
      cause: err,
    });
  }

  let data = {};
  try {
    data = res.json();
  } catch {
    data = {};
  }

  if (!res.ok || !data.ok) {
    const desc = data.description || `Telegram HTTP ${res.status}`;
    throw Object.assign(new Error(`Telegram API (${methodName}): ${desc}`), {
      code: `TG_${data.error_code || res.status}`,
      status: data.error_code || res.status,
      description: desc,
    });
  }

  return data.result;
}

async function downloadFileById(botToken, fileId, timeoutMs = 5 * 60 * 1000) {
  let fileInfo;
  try {
    fileInfo = await tgApiJson(botToken, 'getFile', { file_id: fileId }, 30000);
  } catch (err) {
    if (/wrong file_id|invalid file_id|not found|temporarily unavailable/i.test(err.message || '')) {
      return null;
    }
    throw err;
  }

  if (!fileInfo || !fileInfo.file_path) return null;

  const dlUrl = `${TG_API_BASE}/file/bot${botToken}/${fileInfo.file_path}`;
  const res = await httpRequest(dlUrl, { method: 'GET', timeoutMs });
  if (res.status === 404) return null;
  if (!res.ok) {
    throw Object.assign(new Error(`Không tải được tệp Telegram (HTTP ${res.status})`), {
      code: `HTTP_${res.status}`,
      status: res.status,
    });
  }
  return res.body;
}

function mergeIndexMaps(localProfiles = {}, remoteProfiles = {}) {
  const merged = { ...localProfiles };
  for (const [profileId, remoteEntry] of Object.entries(remoteProfiles || {})) {
    if (!remoteEntry || !remoteEntry.fileId) continue;
    const cur = merged[profileId];
    if (!cur || (remoteEntry.updatedAt || '') >= (cur.updatedAt || '')) {
      merged[profileId] = { ...remoteEntry };
    }
  }
  return merged;
}

/**
 * Sync backup index from chat's pinned message (if present) and recent non-consumed Bot updates
 * so a second machine connecting with the same { botToken, chatId } discovers existing backups.
 */
async function syncIndexFromRemote(config, currentIndex) {
  const nextIndex = {
    indexMessageId: currentIndex.indexMessageId || null,
    profiles: { ...(currentIndex.profiles || {}) },
  };

  // 1. Inspect pinned index document/message on chat via getChat
  try {
    const chat = await tgApiJson(config.botToken, 'getChat', { chat_id: config.chatId });
    const pinned = chat && chat.pinned_message;
    if (pinned) {
      const captionOrText = String(pinned.caption || pinned.text || '');
      const isOurDoc =
        pinned.document &&
        (pinned.document.file_name === INDEX_FILENAME || captionOrText.startsWith('#CGT_LOGIN_SYNC_INDEX'));

      if (isOurDoc && pinned.document.file_id) {
        nextIndex.indexMessageId = pinned.message_id;
        const buf = await downloadFileById(config.botToken, pinned.document.file_id, 30000);
        if (buf) {
          const parsed = JSON.parse(buf.toString('utf8'));
          if (parsed && parsed.profiles && typeof parsed.profiles === 'object') {
            nextIndex.profiles = mergeIndexMaps(nextIndex.profiles, parsed.profiles);
          }
        }
      } else if (captionOrText.startsWith('#CGT_LOGIN_SYNC_INDEX')) {
        nextIndex.indexMessageId = pinned.message_id;
        const newlineIdx = captionOrText.indexOf('\n');
        if (newlineIdx > 0) {
          const parsed = JSON.parse(captionOrText.slice(newlineIdx + 1));
          if (parsed && parsed.profiles && typeof parsed.profiles === 'object') {
            nextIndex.profiles = mergeIndexMaps(nextIndex.profiles, parsed.profiles);
          }
        }
      }
    }
  } catch {
    // Non-fatal: continue with local vault index
  }

  // 2. Also scan any recent unconsumed getUpdates messages with #cgt_profile_backup:<id> captions
  try {
    const updates = await tgApiJson(config.botToken, 'getUpdates', { limit: 100, timeout: 0 }, 15000);
    if (Array.isArray(updates)) {
      for (const u of updates) {
        const msg = u.message || u.channel_post || u.edited_message || u.edited_channel_post;
        if (!msg || !msg.chat || String(msg.chat.id) !== String(config.chatId)) continue;
        if (!msg.document || !msg.document.file_id) continue;

        const fileName = msg.document.file_name || '';
        const caption = String(msg.caption || '');
        let profileId = parseProfileIdFromFilename(fileName);
        if (!profileId && caption.startsWith(BACKUP_CAPTION_PREFIX)) {
          profileId = caption.slice(BACKUP_CAPTION_PREFIX.length).trim();
        }
        if (!profileId) continue;

        const updatedAt = msg.date ? new Date(msg.date * 1000).toISOString() : '';
        const cur = nextIndex.profiles[profileId];
        if (!cur || !cur.messageId || msg.message_id >= cur.messageId) {
          nextIndex.profiles[profileId] = {
            fileId: msg.document.file_id,
            messageId: msg.message_id,
            name: fileName || backupFilename(profileId),
            size: Number(msg.document.file_size || 0),
            updatedAt: updatedAt || new Date().toISOString(),
          };
        }
      }
    }
  } catch {
    // getUpdates fails if webhook is active; safe to ignore
  }

  return nextIndex;
}

/**
 * Publish updated metadata index document to Telegram chat and pin it (best-effort)
 * so cross-machine restores always know the latest { file_id, message_id } per profile.
 */
async function publishRemoteIndex(config, index) {
  const indexPayload = Buffer.from(
    JSON.stringify(
      {
        version: 2,
        updatedAt: new Date().toISOString(),
        profiles: index.profiles,
      },
      null,
      2
    ),
    'utf8'
  );

  if (index.indexMessageId) {
    try {
      const mediaJson = JSON.stringify({
        type: 'document',
        media: 'attach://index_doc',
        caption: INDEX_CAPTION,
      });
      const edited = await tgApiMultipart(
        config.botToken,
        'editMessageMedia',
        {
          chat_id: config.chatId,
          message_id: String(index.indexMessageId),
          media: mediaJson,
        },
        [{ fieldName: 'index_doc', filename: INDEX_FILENAME, data: indexPayload, contentType: 'application/json' }],
        30000
      );
      if (edited && edited.message_id) {
        return edited.message_id;
      }
    } catch {
      // Fall through to send a fresh index document if old message was manually deleted
    }
  }

  try {
    const sent = await tgApiMultipart(
      config.botToken,
      'sendDocument',
      {
        chat_id: config.chatId,
        caption: INDEX_CAPTION,
        disable_notification: 'true',
      },
      [{ fieldName: 'document', filename: INDEX_FILENAME, data: indexPayload, contentType: 'application/json' }],
      30000
    );
    const msgId = sent && sent.message_id ? sent.message_id : null;
    if (msgId) {
      try {
        await tgApiJson(config.botToken, 'pinChatMessage', {
          chat_id: config.chatId,
          message_id: msgId,
          disable_notification: true,
        });
      } catch {
        // Bot may lack pin permission in restricted groups; local vault still works
      }
    }
    return msgId;
  } catch {
    return index.indexMessageId || null;
  }
}

function formatChatTitle(chat, fallbackId) {
  if (!chat) return String(fallbackId || '');
  if (chat.title) return chat.title;
  const fullName = [chat.first_name, chat.last_name].filter(Boolean).join(' ').trim();
  if (fullName) return fullName;
  if (chat.username) return `@${chat.username}`;
  return String(chat.id || fallbackId || '');
}

function status() {
  const st = vault.getProviderState('telegram');
  const cfg = st.config || null;
  const connected = Boolean(st.connected && cfg && cfg.botToken && cfg.chatId);
  const indexedCount = st.index && st.index.profiles ? Object.keys(st.index.profiles).length : 0;

  return {
    connected,
    provider: 'telegram',
    indexedCount,
    config: connected
      ? {
          chatId: String(cfg.chatId),
          chatTitle: cfg.chatTitle || String(cfg.chatId),
          botUsername: cfg.botUsername || '',
          botName: cfg.botName || '',
        }
      : null,
  };
}

async function connect(input = {}) {
  const existing = vault.getProviderState('telegram');
  let botToken = String(input.botToken || '').trim();
  if (!botToken && existing.config && existing.config.botToken) {
    botToken = existing.config.botToken;
  }
  const chatId = String(input.chatId == null ? '' : input.chatId).trim();

  if (!botToken || !chatId) {
    throw Object.assign(new Error('Vui lòng cung cấp đầy đủ Bot Token và Chat ID của Telegram'), {
      code: 'MISSING_FIELDS',
    });
  }

  // 1. Validate Bot Token via getMe
  const me = await tgApiJson(botToken, 'getMe', {});
  // 2. Validate Chat ID & permissions via getChat
  const chat = await tgApiJson(botToken, 'getChat', { chat_id: chatId });

  const resolvedChatId = chat && chat.id != null ? String(chat.id) : chatId;
  const config = {
    botToken,
    chatId: resolvedChatId,
    chatTitle: formatChatTitle(chat, resolvedChatId),
    botUsername: (me && me.username) || '',
    botName: (me && me.first_name) || 'Telegram Bot',
  };

  const prevSameChat =
    existing.config && String(existing.config.chatId) === resolvedChatId && existing.index
      ? existing.index
      : { indexMessageId: null, profiles: {} };

  const syncedIndex = await syncIndexFromRemote(config, prevSameChat);

  vault.setProviderState('telegram', {
    connected: true,
    config,
    index: syncedIndex,
  });

  return status();
}

async function disconnect() {
  vault.clearProviderState('telegram');
  return status();
}

async function upload(arg1, arg2) {
  const { profileId, localFile, filename } = resolveUploadArgs(arg1, arg2);
  const { config, index } = getStateOrThrow();

  if (!localFile || !fs.existsSync(localFile)) {
    throw Object.assign(new Error('TELEGRAM_SOURCE_NOT_FOUND'), { code: 'TELEGRAM_SOURCE_NOT_FOUND' });
  }

  const fileBuf = fs.readFileSync(localFile);
  if (fileBuf.length > TG_MAX_BOT_DOWNLOAD_BYTES) {
    throw Object.assign(
      new Error(
        `Gói hồ sơ (${(fileBuf.length / (1024 * 1024)).toFixed(1)} MB) vượt giới hạn tải về 20 MB của Telegram Bot API. Hãy dùng S3, Google Drive hoặc Local/NAS.`
      ),
      { code: 'TELEGRAM_FILE_TOO_LARGE' }
    );
  }

  const mergedIndex = await syncIndexFromRemote(config, index);
  const prevEntry = mergedIndex.profiles[profileId] || null;

  const sent = await tgApiMultipart(
    config.botToken,
    'sendDocument',
    {
      chat_id: config.chatId,
      caption: `${BACKUP_CAPTION_PREFIX}${profileId}`,
      disable_notification: 'true',
    },
    [{ fieldName: 'document', filename, data: fileBuf, contentType: 'application/octet-stream' }]
  );

  const doc = sent && sent.document;
  if (!doc || !doc.file_id) {
    throw Object.assign(new Error('Telegram không trả về document.file_id sau khi tải lên'), {
      code: 'TELEGRAM_UPLOAD_INCOMPLETE',
    });
  }

  // Delete previous backup message AFTER new backup succeeded so backup is never lost
  if (prevEntry && prevEntry.messageId && prevEntry.messageId !== sent.message_id) {
    try {
      await tgApiJson(config.botToken, 'deleteMessage', {
        chat_id: config.chatId,
        message_id: prevEntry.messageId,
      });
    } catch {
      // Best-effort cleanup (messages >48h or already deleted are safely ignored)
    }
  }

  mergedIndex.profiles[profileId] = {
    fileId: doc.file_id,
    messageId: sent.message_id,
    name: filename,
    size: Number(doc.file_size || fileBuf.length),
    updatedAt: new Date().toISOString(),
  };

  mergedIndex.indexMessageId = await publishRemoteIndex(config, mergedIndex);

  vault.setProviderState('telegram', {
    connected: true,
    config,
    index: mergedIndex,
  });

  return {
    ok: true,
    provider: 'telegram',
    fileId: doc.file_id,
    messageId: sent.message_id,
    target: config.chatTitle || `Telegram (${config.chatId})`,
    size: fileBuf.length,
  };
}

async function download(arg1, arg2) {
  const { profileId, destFile } = resolveDownloadArgs(arg1, arg2);
  const { config, index } = getStateOrThrow();

  let currentIndex = index;
  let entry = currentIndex.profiles[profileId];
  let fileBuf = null;

  if (entry && entry.fileId) {
    fileBuf = await downloadFileById(config.botToken, entry.fileId);
  }

  // Refresh from remote pinned index if missing locally or rotated by another machine
  if (!fileBuf) {
    currentIndex = await syncIndexFromRemote(config, currentIndex);
    vault.setProviderState('telegram', {
      connected: true,
      config,
      index: currentIndex,
    });
    entry = currentIndex.profiles[profileId];
    if (!entry || !entry.fileId) {
      return { found: false, path: null };
    }
    fileBuf = await downloadFileById(config.botToken, entry.fileId);
    if (!fileBuf) {
      return { found: false, path: null };
    }
  }

  atomicWriteFileSync(destFile, fileBuf);
  return { found: true, path: destFile, size: fileBuf.length };
}

async function listBackups() {
  const { config, index } = getStateOrThrow();
  const syncedIndex = await syncIndexFromRemote(config, index);

  vault.setProviderState('telegram', {
    connected: true,
    config,
    index: syncedIndex,
  });

  const backups = [];
  for (const [profileId, info] of Object.entries(syncedIndex.profiles || {})) {
    if (!info || !info.fileId) continue;
    const updatedAt = info.updatedAt || '';
    backups.push({
      id: info.fileId,
      fileId: info.fileId,
      messageId: info.messageId || null,
      profileId,
      name: info.name || backupFilename(profileId),
      size: Number(info.size || 0),
      updatedAt,
      createdTime: updatedAt,
    });
  }

  backups.sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || ''));
  return backups;
}

module.exports = {
  status,
  connect,
  disconnect,
  upload,
  download,
  listBackups,
};
