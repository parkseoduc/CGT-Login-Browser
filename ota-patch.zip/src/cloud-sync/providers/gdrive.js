'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { URLSearchParams } = require('node:url');
const vault = require('../vault');
const {
  backupFilename,
  parseProfileIdFromFilename,
  httpRequest,
  buildMultipartFormData,
} = require('../http-client');

const GOOGLE_AUTH_URL = 'https://accounts.google.com/o/oauth2/v2/auth';
const GOOGLE_TOKEN_URL = 'https://oauth2.googleapis.com/token';
const DRIVE_API = 'https://www.googleapis.com/drive/v3';
const DRIVE_UPLOAD_API = 'https://www.googleapis.com/upload/drive/v3';
const DRIVE_SCOPE = 'https://www.googleapis.com/auth/drive.file';
const FOLDER_NAME = 'CGT-Login Backup';
const FOLDER_MIME = 'application/vnd.google-apps.folder';

let _refreshInflight = null;
let _folderInflight = null;

const sleep = (ms) =>
  new Promise((resolve) => {
    const t = setTimeout(resolve, ms);
    if (t.unref) t.unref();
  });

function escapeDriveQuery(s) {
  return String(s || '').replace(/\\/g, '\\\\').replace(/'/g, "\\'");
}

function atomicWriteFileSync(destFile, buf) {
  fs.mkdirSync(path.dirname(destFile), { recursive: true });
  const tmpFile = `${destFile}.${process.pid}.${Date.now()}.${crypto.randomBytes(4).toString('hex')}.tmp`;
  try {
    fs.writeFileSync(tmpFile, buf);
    try {
      fs.renameSync(tmpFile, destFile);
    } catch {
      fs.copyFileSync(tmpFile, destFile);
      fs.unlinkSync(tmpFile);
    }
  } finally {
    try {
      if (fs.existsSync(tmpFile)) fs.unlinkSync(tmpFile);
    } catch {
      // ignore
    }
  }
}

function resolveUploadArgs(arg1, arg2) {
  if (arg1 && typeof arg1 === 'object') {
    const profileId = arg1.profileId || parseProfileIdFromFilename(arg1.filename || '');
    const localFile = arg1.localFile || arg1.filePath;
    const filename = arg1.filename || backupFilename(profileId);
    return { profileId: String(profileId), localFile, filename };
  }
  const profileId = String(arg1);
  return { profileId, localFile: arg2, filename: backupFilename(profileId) };
}

function resolveDownloadArgs(arg1, arg2) {
  if (arg1 && typeof arg1 === 'object') {
    const profileId = arg1.profileId || parseProfileIdFromFilename(arg1.filename || '');
    const destFile = arg1.destFile || arg1.destPath;
    const filename = arg1.filename || backupFilename(profileId);
    return { profileId: String(profileId), destFile, filename };
  }
  const profileId = String(arg1);
  return { profileId, destFile: arg2, filename: backupFilename(profileId) };
}

function buildAuthUrl({ clientId, redirectUri, state = '', codeChallenge = '' } = {}) {
  const params = new URLSearchParams({
    client_id: String(clientId || '').trim(),
    redirect_uri: String(redirectUri || '').trim(),
    response_type: 'code',
    scope: `openid email profile ${DRIVE_SCOPE}`,
    access_type: 'offline',
    prompt: 'consent select_account',
  });
  if (state) params.set('state', state);
  if (codeChallenge) {
    params.set('code_challenge', codeChallenge);
    params.set('code_challenge_method', 'S256');
  }
  return `${GOOGLE_AUTH_URL}?${params.toString()}`;
}

async function requestGoogleToken(formFields) {
  const body = new URLSearchParams(formFields).toString();
  let res;
  try {
    res = await httpRequest(GOOGLE_TOKEN_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body,
      timeoutMs: 30000,
    });
  } catch (err) {
    throw Object.assign(new Error(`Không kết nối được máy chủ OAuth Google: ${err.message}`), {
      code: 'GDRIVE_NETWORK',
      cause: err,
    });
  }

  let data = {};
  try {
    data = res.json();
  } catch {
    data = {};
  }

  if (!res.ok) {
    const errCode = data.error || `HTTP_${res.status}`;
    const desc = data.error_description || data.message || errCode;
    throw Object.assign(new Error(`Google OAuth lỗi (${errCode}): ${desc}`), {
      code: errCode,
      status: res.status,
    });
  }

  return data;
}

function getStoredConfigOrThrow() {
  const st = vault.getProviderState('gdrive');
  if (!st.connected || !st.config) {
    throw Object.assign(new Error('Chưa kết nối Google Drive'), { code: 'NOT_CONNECTED' });
  }
  return st.config;
}

async function refreshAccessToken() {
  if (_refreshInflight) return _refreshInflight;
  _refreshInflight = (async () => {
    const cfg = getStoredConfigOrThrow();
    if (!cfg.refreshToken || !cfg.clientId) {
      throw Object.assign(
        new Error('Access Token Google Drive đã hết hạn và không có Refresh Token. Vui lòng kết nối lại.'),
        { code: 'GDRIVE_TOKEN_EXPIRED' }
      );
    }

    const form = {
      client_id: cfg.clientId,
      refresh_token: cfg.refreshToken,
      grant_type: 'refresh_token',
    };
    if (cfg.clientSecret) {
      form.client_secret = cfg.clientSecret;
    }

    let tok;
    try {
      tok = await requestGoogleToken(form);
    } catch (err) {
      if (err.code === 'invalid_grant') {
        vault.setProviderState('gdrive', {
          connected: false,
          config: { ...cfg, accessToken: '', expiresAt: 0, needsReauth: true },
        });
      }
      throw err;
    }

    const expiresInSec = Number(tok.expires_in || 3600);
    const updatedCfg = {
      ...cfg,
      accessToken: tok.access_token,
      refreshToken: tok.refresh_token || cfg.refreshToken,
      expiresAt: Date.now() + Math.max(60, expiresInSec - 60) * 1000,
      needsReauth: false,
    };
    vault.setProviderState('gdrive', { connected: true, config: updatedCfg });
    return updatedCfg.accessToken;
  })().finally(() => {
    _refreshInflight = null;
  });

  return _refreshInflight;
}

async function getValidAccessToken(forceRefresh = false) {
  const cfg = getStoredConfigOrThrow();
  const expired = cfg.expiresAt && Date.now() >= cfg.expiresAt;

  if (!forceRefresh && cfg.accessToken && !expired) {
    return cfg.accessToken;
  }
  if (cfg.refreshToken && cfg.clientId) {
    return refreshAccessToken();
  }
  if (!forceRefresh && cfg.accessToken) {
    return cfg.accessToken;
  }
  throw Object.assign(new Error('Token Google Drive đã hết hạn. Vui lòng kết nối lại.'), {
    code: 'GDRIVE_TOKEN_EXPIRED',
  });
}

async function driveRequest(url, opts = {}) {
  const method = (opts.method || 'GET').toUpperCase();
  let forceRefresh = false;

  for (let attempt = 0; attempt < 4; attempt += 1) {
    const token = opts.explicitToken || (await getValidAccessToken(forceRefresh));
    let res;
    try {
      res = await httpRequest(url, {
        method,
        headers: {
          Authorization: `Bearer ${token}`,
          ...(opts.headers || {}),
        },
        body: opts.body,
        timeoutMs: opts.timeoutMs || 60000,
        followRedirects: opts.followRedirects !== false,
      });
    } catch (err) {
      if (attempt < 2) {
        await sleep(500 * (attempt + 1));
        continue;
      }
      throw Object.assign(new Error(`Lỗi mạng Google Drive: ${err.message}`), {
        code: 'GDRIVE_NETWORK',
        cause: err,
      });
    }

    if (res.status === 401 && !opts.explicitToken && !forceRefresh) {
      forceRefresh = true;
      continue;
    }

    if ((res.status === 429 || res.status >= 500) && attempt < 2) {
      await sleep(700 * (attempt + 1));
      continue;
    }

    if (opts.allowStatuses && opts.allowStatuses.includes(res.status)) {
      return res;
    }

    if (!res.ok) {
      let errJson = {};
      try {
        errJson = res.json();
      } catch {
        errJson = {};
      }
      const reason =
        errJson.error && Array.isArray(errJson.error.errors) && errJson.error.errors[0]
          ? errJson.error.errors[0].reason
          : '';
      const message = (errJson.error && errJson.error.message) || `Google Drive HTTP ${res.status}`;
      throw Object.assign(new Error(message), {
        code: reason || `HTTP_${res.status}`,
        status: res.status,
      });
    }

    if (opts.raw) return res;
    return res.json();
  }

  throw Object.assign(new Error('Google Drive không phản hồi sau nhiều lần thử'), {
    code: 'GDRIVE_UNAVAILABLE',
  });
}

async function fetchDriveAccount(accessToken) {
  const data = await driveRequest(
    `${DRIVE_API}/about?fields=user(displayName,emailAddress,photoLink)`,
    { explicitToken: accessToken }
  );
  const u = (data && data.user) || {};
  return {
    email: u.emailAddress || '',
    name: u.displayName || u.emailAddress || 'Google Drive User',
    picture: u.photoLink || '',
  };
}

async function ensureFolder() {
  if (_folderInflight) return _folderInflight;
  _folderInflight = (async () => {
    const cfg = getStoredConfigOrThrow();
    if (cfg.folderId) {
      try {
        const meta = await driveRequest(
          `${DRIVE_API}/files/${encodeURIComponent(cfg.folderId)}?fields=id,trashed`
        );
        if (meta && meta.id && !meta.trashed) {
          return meta.id;
        }
      } catch (err) {
        if (err.status !== 404) throw err;
      }
    }

    const searchParams = new URLSearchParams({
      q: `mimeType='${FOLDER_MIME}' and name='${escapeDriveQuery(FOLDER_NAME)}' and trashed=false`,
      fields: 'files(id,createdTime)',
      orderBy: 'createdTime',
      pageSize: '10',
      spaces: 'drive',
    });
    const found = await driveRequest(`${DRIVE_API}/files?${searchParams.toString()}`);
    let folderId = found && Array.isArray(found.files) && found.files[0] ? found.files[0].id : '';

    if (!folderId) {
      const created = await driveRequest(`${DRIVE_API}/files?fields=id`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json; charset=UTF-8' },
        body: JSON.stringify({
          name: FOLDER_NAME,
          mimeType: FOLDER_MIME,
          parents: ['root'],
        }),
      });
      folderId = created.id;
    }

    const latestCfg = getStoredConfigOrThrow();
    vault.setProviderState('gdrive', {
      connected: true,
      config: { ...latestCfg, folderId },
    });
    return folderId;
  })().finally(() => {
    _folderInflight = null;
  });

  return _folderInflight;
}

async function findFilesByName(folderId, filename) {
  const params = new URLSearchParams({
    q: `name='${escapeDriveQuery(filename)}' and '${escapeDriveQuery(folderId)}' in parents and trashed=false`,
    fields: 'files(id,name,size,modifiedTime,createdTime)',
    orderBy: 'modifiedTime desc',
    pageSize: '20',
    spaces: 'drive',
  });
  const res = await driveRequest(`${DRIVE_API}/files?${params.toString()}`);
  return (res && res.files) || [];
}

function status() {
  const st = vault.getProviderState('gdrive');
  const cfg = st.config || null;
  const connected = Boolean(st.connected && cfg && (cfg.refreshToken || cfg.accessToken));
  return {
    connected,
    provider: 'gdrive',
    needsReauth: Boolean(cfg && cfg.needsReauth),
    folder: FOLDER_NAME,
    account: connected && cfg.account ? cfg.account : null,
    config: connected
      ? {
          clientId: cfg.clientId || '',
          authMode: cfg.refreshToken ? 'refresh_token' : 'access_token',
          folderId: cfg.folderId || '',
          folderName: FOLDER_NAME,
        }
      : null,
  };
}

async function connect(input = {}) {
  const clientId = String(input.clientId || '').trim();
  const clientSecret = String(input.clientSecret || '').trim();
  let refreshToken = String(input.refreshToken || '').trim();
  let accessToken = String(input.accessToken || '').trim();
  const code = String(input.code || '').trim();
  const redirectUri = String(input.redirectUri || '').trim();
  const codeVerifier = String(input.codeVerifier || '').trim();

  let expiresAt = 0;

  if (code && clientId && redirectUri) {
    const tokenForm = {
      code,
      client_id: clientId,
      redirect_uri: redirectUri,
      grant_type: 'authorization_code',
    };
    if (clientSecret) tokenForm.client_secret = clientSecret;
    if (codeVerifier) tokenForm.code_verifier = codeVerifier;

    const tok = await requestGoogleToken(tokenForm);
    accessToken = tok.access_token || '';
    refreshToken = tok.refresh_token || refreshToken;
    expiresAt = Date.now() + Math.max(60, Number(tok.expires_in || 3600) - 60) * 1000;
  } else if (refreshToken && clientId) {
    const tokenForm = {
      client_id: clientId,
      refresh_token: refreshToken,
      grant_type: 'refresh_token',
    };
    if (clientSecret) tokenForm.client_secret = clientSecret;

    const tok = await requestGoogleToken(tokenForm);
    accessToken = tok.access_token || '';
    refreshToken = tok.refresh_token || refreshToken;
    expiresAt = Date.now() + Math.max(60, Number(tok.expires_in || 3600) - 60) * 1000;
  } else if (accessToken) {
    if (input.expiresIn) {
      expiresAt = Date.now() + Math.max(60, Number(input.expiresIn) - 60) * 1000;
    }
  } else {
    throw Object.assign(
      new Error('Cần cung cấp { clientId, clientSecret, refreshToken } hoặc { accessToken } để kết nối Google Drive'),
      { code: 'MISSING_FIELDS' }
    );
  }

  const account = await fetchDriveAccount(accessToken);

  vault.setProviderState('gdrive', {
    connected: true,
    config: {
      clientId,
      clientSecret,
      refreshToken,
      accessToken,
      expiresAt,
      account,
      folderId: '',
      needsReauth: false,
    },
  });

  await ensureFolder();
  return status();
}

async function disconnect() {
  vault.clearProviderState('gdrive');
  return status();
}

async function uploadMultipartFallback(folderId, existingFile, filename, body) {
  const metadata = existingFile
    ? { name: filename, mimeType: 'application/octet-stream' }
    : { name: filename, parents: [folderId], mimeType: 'application/octet-stream' };

  const boundary = `----CGTGDriveMultipart${crypto.randomBytes(12).toString('hex')}`;
  const multipartBody = Buffer.concat([
    Buffer.from(
      `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify(metadata)}\r\n` +
        `--${boundary}\r\nContent-Type: application/octet-stream\r\n\r\n`,
      'utf8'
    ),
    body,
    Buffer.from(`\r\n--${boundary}--\r\n`, 'utf8'),
  ]);

  const url = existingFile
    ? `${DRIVE_UPLOAD_API}/files/${encodeURIComponent(existingFile.id)}?uploadType=multipart&fields=id,name,size`
    : `${DRIVE_UPLOAD_API}/files?uploadType=multipart&fields=id,name,size`;

  return driveRequest(url, {
    method: existingFile ? 'PATCH' : 'POST',
    headers: { 'Content-Type': `multipart/related; boundary=${boundary}` },
    body: multipartBody,
    timeoutMs: 5 * 60 * 1000,
  });
}

async function upload(arg1, arg2) {
  const { localFile, filename } = resolveUploadArgs(arg1, arg2);
  if (!localFile || !fs.existsSync(localFile)) {
    throw Object.assign(new Error('GDRIVE_SOURCE_NOT_FOUND'), { code: 'GDRIVE_SOURCE_NOT_FOUND' });
  }

  const folderId = await ensureFolder();
  const existing = await findFilesByName(folderId, filename);
  const target = existing[0] || null;
  const body = fs.readFileSync(localFile);

  let uploadedMeta = null;

  // Use Resumable Upload (overwriting existing file ID via PATCH when present);
  // falls back to Multipart for tiny payloads if resumable Location header is ever omitted.
  const initUrl = target
    ? `${DRIVE_UPLOAD_API}/files/${encodeURIComponent(target.id)}?uploadType=resumable&fields=id,name,size`
    : `${DRIVE_UPLOAD_API}/files?uploadType=resumable&fields=id,name,size`;
  const metadata = target
    ? { mimeType: 'application/octet-stream' }
    : { name: filename, parents: [folderId], mimeType: 'application/octet-stream' };

  const initRes = await driveRequest(initUrl, {
    method: target ? 'PATCH' : 'POST',
    raw: true,
    followRedirects: false,
    headers: {
      'Content-Type': 'application/json; charset=UTF-8',
      'X-Upload-Content-Type': 'application/octet-stream',
      'X-Upload-Content-Length': String(body.length),
    },
    body: JSON.stringify(metadata),
  });

  const sessionLocation = initRes.headers && initRes.headers.location;
  if (sessionLocation) {
    const putRes = await httpRequest(sessionLocation, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/octet-stream',
        'Content-Length': String(body.length),
      },
      body,
      timeoutMs: 10 * 60 * 1000,
      followRedirects: false,
    });
    if (!putRes.ok) {
      throw Object.assign(new Error(`Google Drive Resumable PUT thất bại (HTTP ${putRes.status})`), {
        code: `HTTP_${putRes.status}`,
        status: putRes.status,
      });
    }
    try {
      uploadedMeta = putRes.json();
    } catch {
      uploadedMeta = {};
    }
  } else if (body.length <= 5 * 1024 * 1024) {
    uploadedMeta = await uploadMultipartFallback(folderId, target, filename, body);
  } else {
    throw Object.assign(new Error('Google Drive không trả về Resumable Upload Location'), {
      code: 'GDRIVE_NO_UPLOAD_SESSION',
    });
  }

  const finalId = (uploadedMeta && uploadedMeta.id) || (target && target.id) || '';

  // Clean up any stale duplicates with the same filename
  for (const dup of existing.slice(1)) {
    if (dup.id && dup.id !== finalId) {
      try {
        await driveRequest(`${DRIVE_API}/files/${encodeURIComponent(dup.id)}`, {
          method: 'DELETE',
          raw: true,
        });
      } catch {
        // best-effort cleanup
      }
    }
  }

  return {
    ok: true,
    provider: 'gdrive',
    id: finalId,
    target: `Google Drive (${FOLDER_NAME})`,
    size: body.length,
  };
}

async function download(arg1, arg2) {
  const { destFile, filename } = resolveDownloadArgs(arg1, arg2);
  const folderId = await ensureFolder();
  const existing = await findFilesByName(folderId, filename);
  if (!existing.length) {
    return { found: false, path: null };
  }

  const fileId = existing[0].id;
  const res = await driveRequest(
    `${DRIVE_API}/files/${encodeURIComponent(fileId)}?alt=media`,
    { raw: true, timeoutMs: 10 * 60 * 1000 }
  );

  atomicWriteFileSync(destFile, res.body);
  return { found: true, path: destFile, size: res.body.length };
}

async function listBackups() {
  const folderId = await ensureFolder();
  const backups = [];
  let pageToken = '';

  do {
    const params = new URLSearchParams({
      q: `'${escapeDriveQuery(folderId)}' in parents and trashed=false and mimeType!='${FOLDER_MIME}'`,
      fields: 'nextPageToken,files(id,name,size,createdTime,modifiedTime)',
      orderBy: 'modifiedTime desc',
      pageSize: '500',
      spaces: 'drive',
    });
    if (pageToken) params.set('pageToken', pageToken);

    const res = await driveRequest(`${DRIVE_API}/files?${params.toString()}`);
    for (const f of (res && res.files) || []) {
      const profileId = parseProfileIdFromFilename(f.name || '');
      if (!profileId) continue;
      const updatedAt = f.modifiedTime || f.createdTime || '';
      backups.push({
        id: f.id,
        profileId,
        name: f.name,
        size: f.size != null ? Number(f.size) : 0,
        updatedAt,
        createdTime: updatedAt,
      });
    }
    pageToken = (res && res.nextPageToken) || '';
  } while (pageToken && backups.length < 2000);

  backups.sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || ''));
  return backups;
}

module.exports = {
  FOLDER_NAME,
  DRIVE_SCOPE,
  buildAuthUrl,
  status,
  connect,
  disconnect,
  upload,
  download,
  listBackups,
  _buildMultipartFormData: buildMultipartFormData,
};
