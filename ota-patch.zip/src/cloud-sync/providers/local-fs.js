'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const vault = require('../vault');
const { backupFilename, parseProfileIdFromFilename } = require('../http-client');

function resolveUploadArgs(arg1, arg2) {
  if (arg1 && typeof arg1 === 'object') {
    const profileId = arg1.profileId || parseProfileIdFromFilename(arg1.filename || '');
    const localFile = arg1.localFile || arg1.filePath;
    const filename = arg1.filename || backupFilename(profileId);
    return { profileId: String(profileId), localFile, filename };
  }
  const profileId = String(arg1);
  return { profileId, localFile: arg2, filename: backupFilename(profileId) };
}

function resolveDownloadArgs(arg1, arg2) {
  if (arg1 && typeof arg1 === 'object') {
    const profileId = arg1.profileId || parseProfileIdFromFilename(arg1.filename || '');
    const destFile = arg1.destFile || arg1.destPath;
    const filename = arg1.filename || backupFilename(profileId);
    return { profileId: String(profileId), destFile, filename };
  }
  const profileId = String(arg1);
  return { profileId, destFile: arg2, filename: backupFilename(profileId) };
}

function atomicCopyFileSync(srcFile, destFile) {
  fs.mkdirSync(path.dirname(destFile), { recursive: true });
  const tmpFile = `${destFile}.${process.pid}.${Date.now()}.${crypto.randomBytes(4).toString('hex')}.tmp`;
  try {
    fs.copyFileSync(srcFile, tmpFile);
    try {
      fs.renameSync(tmpFile, destFile);
    } catch {
      fs.copyFileSync(tmpFile, destFile);
      fs.unlinkSync(tmpFile);
    }
  } finally {
    try {
      if (fs.existsSync(tmpFile)) fs.unlinkSync(tmpFile);
    } catch {
      // ignore
    }
  }
}

function getActiveFolderOrThrow() {
  const st = vault.getProviderState('local');
  if (!st.connected || !st.config || !st.config.folderPath) {
    throw Object.assign(new Error('Chưa kết nối thư mục đồng bộ Local/NAS'), { code: 'NOT_CONNECTED' });
  }
  return st.config.folderPath;
}

function status() {
  const st = vault.getProviderState('local');
  const folderPath = st.config && st.config.folderPath ? String(st.config.folderPath) : '';
  const connected = Boolean(st.connected && folderPath);
  let accessible = false;
  if (connected) {
    try {
      accessible = fs.existsSync(folderPath);
    } catch {
      accessible = false;
    }
  }
  return {
    connected,
    provider: 'local',
    accessible,
    config: connected ? { folderPath } : null,
  };
}

async function connect(input) {
  const rawPath = typeof input === 'string' ? input : input && input.folderPath;
  const trimmed = String(rawPath || '').trim();
  if (!trimmed) {
    throw Object.assign(new Error('Vui lòng nhập đường dẫn thư mục đồng bộ (folderPath)'), {
      code: 'MISSING_FIELDS',
    });
  }

  const folderPath = path.resolve(trimmed);
  try {
    fs.mkdirSync(folderPath, { recursive: true });
    const probeFile = path.join(folderPath, `.cgt-sync-probe-${process.pid}-${Date.now()}.tmp`);
    fs.writeFileSync(probeFile, 'ok', 'utf8');
    fs.unlinkSync(probeFile);
  } catch (err) {
    throw Object.assign(
      new Error(`Không thể ghi vào thư mục "${folderPath}": ${err.message}`),
      { code: 'LOCAL_FOLDER_UNWRITABLE', cause: err }
    );
  }

  vault.setProviderState('local', {
    connected: true,
    config: { folderPath },
  });

  return status();
}

async function disconnect() {
  vault.clearProviderState('local');
  return status();
}

async function upload(arg1, arg2) {
  const { localFile, filename } = resolveUploadArgs(arg1, arg2);
  const folderPath = getActiveFolderOrThrow();

  if (!localFile || !fs.existsSync(localFile)) {
    throw Object.assign(new Error('LOCAL_SOURCE_NOT_FOUND'), { code: 'LOCAL_SOURCE_NOT_FOUND' });
  }

  fs.mkdirSync(folderPath, { recursive: true });
  const targetFile = path.join(folderPath, filename);
  atomicCopyFileSync(localFile, targetFile);
  const size = fs.statSync(targetFile).size;

  return {
    ok: true,
    provider: 'local',
    target: folderPath,
    path: targetFile,
    size,
  };
}

async function download(arg1, arg2) {
  const { destFile, filename } = resolveDownloadArgs(arg1, arg2);
  const folderPath = getActiveFolderOrThrow();

  if (!fs.existsSync(folderPath)) {
    throw Object.assign(new Error(`Thư mục đồng bộ không truy cập được: ${folderPath}`), {
      code: 'LOCAL_FOLDER_UNREACHABLE',
    });
  }

  const srcFile = path.join(folderPath, filename);
  if (!fs.existsSync(srcFile)) {
    return { found: false, path: null };
  }

  atomicCopyFileSync(srcFile, destFile);
  const size = fs.statSync(destFile).size;
  return { found: true, path: destFile, size };
}

async function listBackups() {
  const folderPath = getActiveFolderOrThrow();
  if (!fs.existsSync(folderPath)) return [];

  const entries = fs.readdirSync(folderPath);
  const backups = [];

  for (const name of entries) {
    const profileId = parseProfileIdFromFilename(name);
    if (!profileId) continue;
    const fullPath = path.join(folderPath, name);
    let st;
    try {
      st = fs.statSync(fullPath);
    } catch {
      continue;
    }
    if (!st.isFile()) continue;
    const updatedAt = st.mtime.toISOString();
    backups.push({
      id: name,
      profileId,
      name,
      path: fullPath,
      size: st.size,
      updatedAt,
      createdTime: updatedAt,
    });
  }

  backups.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  return backups;
}

module.exports = {
  status,
  connect,
  disconnect,
  upload,
  download,
  listBackups,
};
