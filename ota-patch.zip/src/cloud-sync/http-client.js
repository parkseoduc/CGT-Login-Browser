'use strict';

const http = require('node:http');
const https = require('node:https');
const { URL } = require('node:url');

const PROFILE_BACKUP_PREFIX = 'cgt-profile-';
const PROFILE_BACKUP_RE = /^cgt-profile-(.+)\.tgz$/;

function sanitizeFileId(profileId) {
  const s = String(profileId == null ? '' : profileId).trim();
  if (!s) throw Object.assign(new Error('INVALID_PROFILE_ID'), { code: 'INVALID_PROFILE_ID' });
  return s.replace(/[<>:"/\\|?*\x00-\x1f]/g, '_');
}

function backupFilename(profileId) {
  return `${PROFILE_BACKUP_PREFIX}${sanitizeFileId(profileId)}.tgz`;
}

function parseProfileIdFromFilename(filename) {
  const m = PROFILE_BACKUP_RE.exec(String(filename || '').trim());
  return m ? m[1] : null;
}

/**
 * Pure Node.js built-in HTTP/HTTPS client with timeout, binary Buffer support,
 * and optional redirect following (stripping Authorization across origins).
 */
function httpRequest(urlStr, opts = {}, _redirectDepth = 0) {
  return new Promise((resolve, reject) => {
    let parsed;
    try {
      parsed = new URL(urlStr);
    } catch (err) {
      reject(Object.assign(new Error(`Invalid URL: ${urlStr}`), { code: 'INVALID_URL', cause: err }));
      return;
    }

    const isHttps = parsed.protocol === 'https:';
    const transport = isHttps ? https : http;
    const method = (opts.method || 'GET').toUpperCase();
    const timeoutMs = opts.timeoutMs || 60000;
    const followRedirects = opts.followRedirects !== false;
    const maxRedirects = opts.maxRedirects != null ? opts.maxRedirects : 5;

    let bodyBuf = null;
    if (opts.body != null) {
      if (Buffer.isBuffer(opts.body)) {
        bodyBuf = opts.body;
      } else if (typeof opts.body === 'string') {
        bodyBuf = Buffer.from(opts.body, 'utf8');
      } else if (opts.body instanceof Uint8Array) {
        bodyBuf = Buffer.from(opts.body);
      } else {
        bodyBuf = Buffer.from(JSON.stringify(opts.body), 'utf8');
      }
    }

    const headers = { ...(opts.headers || {}) };
    const hasContentLength = Object.keys(headers).some((k) => k.toLowerCase() === 'content-length');
    if (bodyBuf && !hasContentLength) {
      headers['Content-Length'] = String(bodyBuf.length);
    } else if (!bodyBuf && (method === 'POST' || method === 'PUT' || method === 'PATCH') && !hasContentLength) {
      headers['Content-Length'] = '0';
    }

    const reqOpts = {
      protocol: parsed.protocol,
      hostname: parsed.hostname,
      port: parsed.port || (isHttps ? 443 : 80),
      path: `${parsed.pathname}${parsed.search}`,
      method,
      headers,
    };

    let settled = false;
    const done = (fn, val) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      fn(val);
    };

    const req = transport.request(reqOpts, (res) => {
      const status = res.statusCode || 0;
      const location = res.headers.location;

      if (
        followRedirects &&
        location &&
        (status === 301 || status === 302 || status === 303 || status === 307 || status === 308)
      ) {
        res.resume();
        if (_redirectDepth >= maxRedirects) {
          done(reject, Object.assign(new Error('Too many HTTP redirects'), { code: 'MAX_REDIRECTS' }));
          return;
        }
        let nextUrl;
        try {
          nextUrl = new URL(location, parsed).toString();
        } catch (err) {
          done(reject, err);
          return;
        }
        const nextParsed = new URL(nextUrl);
        const nextHeaders = { ...headers };
        delete nextHeaders['Content-Length'];
        delete nextHeaders['content-length'];
        delete nextHeaders.Host;
        delete nextHeaders.host;
        if (nextParsed.origin !== parsed.origin) {
          delete nextHeaders.Authorization;
          delete nextHeaders.authorization;
        }
        const nextMethod = status === 303 ? 'GET' : method;
        const nextBody = status === 303 ? null : bodyBuf;
        clearTimeout(timer);
        settled = true;
        httpRequest(
          nextUrl,
          { ...opts, method: nextMethod, headers: nextHeaders, body: nextBody },
          _redirectDepth + 1
        ).then(resolve, reject);
        return;
      }

      const chunks = [];
      res.on('data', (chunk) => chunks.push(chunk));
      res.on('error', (err) => done(reject, err));
      res.on('end', () => {
        const rawBody = Buffer.concat(chunks);
        done(resolve, {
          status,
          ok: status >= 200 && status < 300,
          headers: res.headers || {},
          body: rawBody,
          text() {
            return rawBody.toString('utf8');
          },
          json() {
            const t = rawBody.toString('utf8').trim();
            return t ? JSON.parse(t) : {};
          },
        });
      });
    });

    const timer = setTimeout(() => {
      req.destroy(Object.assign(new Error(`HTTP request timed out after ${timeoutMs}ms`), { code: 'ETIMEDOUT' }));
    }, timeoutMs);
    if (timer.unref) timer.unref();

    req.on('error', (err) => done(reject, err));

    if (bodyBuf && bodyBuf.length > 0) {
      req.write(bodyBuf);
    }
    req.end();
  });
}

function buildMultipartFormData(fields = {}, files = []) {
  const boundary = `----CGTCloudSync${Date.now().toString(16)}${Math.random().toString(16).slice(2)}`;
  const parts = [];

  for (const [key, value] of Object.entries(fields)) {
    if (value === undefined || value === null) continue;
    parts.push(
      Buffer.from(
        `--${boundary}\r\nContent-Disposition: form-data; name="${key}"\r\n\r\n${String(value)}\r\n`,
        'utf8'
      )
    );
  }

  for (const file of files) {
    const safeName = String(file.filename || 'file.bin').replace(/["\r\n]/g, '_');
    const contentType = file.contentType || 'application/octet-stream';
    parts.push(
      Buffer.from(
        `--${boundary}\r\nContent-Disposition: form-data; name="${file.fieldName}"; filename="${safeName}"\r\nContent-Type: ${contentType}\r\n\r\n`,
        'utf8'
      )
    );
    parts.push(Buffer.isBuffer(file.data) ? file.data : Buffer.from(file.data));
    parts.push(Buffer.from('\r\n', 'utf8'));
  }

  parts.push(Buffer.from(`--${boundary}--\r\n`, 'utf8'));

  return {
    boundary,
    contentType: `multipart/form-data; boundary=${boundary}`,
    body: Buffer.concat(parts),
  };
}

module.exports = {
  PROFILE_BACKUP_PREFIX,
  PROFILE_BACKUP_RE,
  sanitizeFileId,
  backupFilename,
  parseProfileIdFromFilename,
  httpRequest,
  buildMultipartFormData,
};
