'use strict';

const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const { execFileSync } = require('node:child_process');
const { DATA_DIR } = require('../config');

// Binary envelope for encrypted-at-rest cloud-sync-vault.enc:
//   [0..8)   "CGTVLT1\0" (8 bytes)
//   [8..24)  salt        (16 bytes)
//   [24..36) nonce / iv  (12 bytes)
//   [36..52) authTag     (16 bytes)
//   [52..)   ciphertext  (AES-256-GCM encrypted UTF-8 JSON)
const VAULT_MAGIC = Buffer.from('CGTVLT1\0', 'utf8');
const VAULT_HEADER_LEN = 8 + 16 + 12 + 16; // 52 bytes

let _customDataDir = null;
let _cachedMachineSecret = null;
let _vaultCache = null;
let _ledgerCache = null;
const _derivedKeyCache = new Map(); // saltHex -> Buffer(32)

function getDataDir() {
  return _customDataDir || process.env.CGT_CLOUD_SYNC_DATA_DIR || DATA_DIR;
}

function setDataDir(dir) {
  _customDataDir = dir ? path.resolve(dir) : null;
  _vaultCache = null;
  _ledgerCache = null;
}

function resetCache() {
  _vaultCache = null;
  _ledgerCache = null;
}

function getVaultPath() {
  return path.join(getDataDir(), 'cloud-sync-vault.enc');
}

function getStatePath() {
  return path.join(getDataDir(), 'cloud-sync-state.json');
}

function resolveMachineGuid() {
  if (_cachedMachineSecret) return _cachedMachineSecret;

  let machineId = '';
  if (process.platform === 'win32') {
    try {
      const regExe = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'reg.exe');
      const out = execFileSync(
        fs.existsSync(regExe) ? regExe : 'reg.exe',
        ['query', 'HKLM\\SOFTWARE\\Microsoft\\Cryptography', '/v', 'MachineGuid'],
        { encoding: 'utf8', windowsHide: true, timeout: 3000, stdio: ['ignore', 'pipe', 'ignore'] }
      );
      const m = /MachineGuid\s+REG_SZ\s+([^\r\n]+)/i.exec(out || '');
      if (m && m[1]) {
        machineId = m[1].trim();
      }
    } catch {
      // Fallback below
    }
  }

  if (!machineId) {
    let username = 'user';
    try {
      username = os.userInfo().username || 'user';
    } catch {
      username = process.env.USERNAME || process.env.USER || 'user';
    }
    machineId = `${os.hostname()}:${username}`;
  }

  _cachedMachineSecret = `cgt-login-v2-vault:${machineId}`;
  return _cachedMachineSecret;
}

function deriveVaultKey(salt) {
  const saltHex = salt.toString('hex');
  const cached = _derivedKeyCache.get(saltHex);
  if (cached) return cached;

  const key = crypto.scryptSync(resolveMachineGuid(), salt, 32);
  if (_derivedKeyCache.size >= 8) {
    const firstKey = _derivedKeyCache.keys().next().value;
    _derivedKeyCache.delete(firstKey);
  }
  _derivedKeyCache.set(saltHex, key);
  return key;
}

function atomicWriteBufferSync(filePath, buf) {
  const dir = path.dirname(filePath);
  fs.mkdirSync(dir, { recursive: true });
  const tmpPath = `${filePath}.${process.pid}.${Date.now()}.${crypto.randomBytes(4).toString('hex')}.tmp`;
  try {
    fs.writeFileSync(tmpPath, buf, { mode: 0o600 });
    try {
      fs.renameSync(tmpPath, filePath);
    } catch {
      fs.copyFileSync(tmpPath, filePath);
      fs.unlinkSync(tmpPath);
    }
  } finally {
    try {
      if (fs.existsSync(tmpPath)) fs.unlinkSync(tmpPath);
    } catch {
      // ignore cleanup error
    }
  }
}

function defaultVaultData() {
  return {
    version: 1,
    settings: {
      syncEnabled: false,
      syncDest: '',
      vaultPassphrase: '',
    },
    providers: {
      local: { connected: false, config: null },
      s3: { connected: false, config: null },
      gdrive: { connected: false, config: null },
      telegram: { connected: false, config: null, index: { indexMessageId: null, profiles: {} } },
    },
  };
}

function normalizeVaultData(raw) {
  const base = defaultVaultData();
  if (!raw || typeof raw !== 'object') return base;

  const s = raw.settings && typeof raw.settings === 'object' ? raw.settings : {};
  base.settings = {
    syncEnabled: Boolean(s.syncEnabled),
    syncDest: typeof s.syncDest === 'string' ? s.syncDest : '',
    vaultPassphrase: typeof s.vaultPassphrase === 'string' ? s.vaultPassphrase : '',
  };

  const p = raw.providers && typeof raw.providers === 'object' ? raw.providers : {};
  for (const name of ['local', 's3', 'gdrive', 'telegram']) {
    if (p[name] && typeof p[name] === 'object') {
      base.providers[name] = {
        ...base.providers[name],
        ...p[name],
        connected: Boolean(p[name].connected),
      };
    }
  }
  if (!base.providers.telegram.index || typeof base.providers.telegram.index !== 'object') {
    base.providers.telegram.index = { indexMessageId: null, profiles: {} };
  }
  if (!base.providers.telegram.index.profiles || typeof base.providers.telegram.index.profiles !== 'object') {
    base.providers.telegram.index.profiles = {};
  }

  return base;
}

function encryptVaultPayload(obj, existingSalt = null) {
  const salt = existingSalt && existingSalt.length === 16 ? existingSalt : crypto.randomBytes(16);
  const nonce = crypto.randomBytes(12);
  const key = deriveVaultKey(salt);
  const plaintext = Buffer.from(JSON.stringify(obj), 'utf8');

  const cipher = crypto.createCipheriv('aes-256-gcm', key, nonce);
  const ciphertext = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  const tag = cipher.getAuthTag();

  return {
    salt,
    buffer: Buffer.concat([VAULT_MAGIC, salt, nonce, tag, ciphertext]),
  };
}

function decryptVaultPayload(buf) {
  if (!Buffer.isBuffer(buf) || buf.length < VAULT_HEADER_LEN) {
    throw Object.assign(new Error('VAULT_CORRUPT_HEADER'), { code: 'VAULT_CORRUPT_HEADER' });
  }
  if (!buf.subarray(0, 8).equals(VAULT_MAGIC)) {
    throw Object.assign(new Error('VAULT_INVALID_MAGIC'), { code: 'VAULT_INVALID_MAGIC' });
  }

  const salt = buf.subarray(8, 24);
  const nonce = buf.subarray(24, 36);
  const tag = buf.subarray(36, 52);
  const ciphertext = buf.subarray(52);
  const key = deriveVaultKey(salt);

  try {
    const decipher = crypto.createDecipheriv('aes-256-gcm', key, nonce);
    decipher.setAuthTag(tag);
    const plaintext = Buffer.concat([decipher.update(ciphertext), decipher.final()]);
    return {
      salt,
      data: normalizeVaultData(JSON.parse(plaintext.toString('utf8'))),
    };
  } catch (err) {
    throw Object.assign(new Error('VAULT_DECRYPT_FAILED'), { code: 'VAULT_DECRYPT_FAILED', cause: err });
  }
}

let _currentVaultSalt = null;

function loadVault() {
  if (_vaultCache) return _vaultCache;

  const vaultFile = getVaultPath();
  if (!fs.existsSync(vaultFile)) {
    _vaultCache = defaultVaultData();
    return _vaultCache;
  }

  try {
    const raw = fs.readFileSync(vaultFile);
    const { salt, data } = decryptVaultPayload(raw);
    _currentVaultSalt = salt;
    _vaultCache = data;
    return _vaultCache;
  } catch {
    // If vault was corrupted or transferred from another machine with different MachineGuid,
    // fall back cleanly without crashing the host server.
    _vaultCache = defaultVaultData();
    _currentVaultSalt = null;
    return _vaultCache;
  }
}

function saveVault(nextData) {
  const normalized = normalizeVaultData(nextData);
  const { salt, buffer } = encryptVaultPayload(normalized, _currentVaultSalt);
  atomicWriteBufferSync(getVaultPath(), buffer);
  _currentVaultSalt = salt;
  _vaultCache = normalized;
  return _vaultCache;
}

function getSettings() {
  const v = loadVault();
  return { ...v.settings };
}

function updateSettings(patch = {}) {
  const v = loadVault();
  const nextSettings = { ...v.settings };

  if (patch.syncEnabled !== undefined) {
    nextSettings.syncEnabled = Boolean(patch.syncEnabled);
  }
  if (patch.syncDest !== undefined) {
    const rawDest = String(patch.syncDest || '').trim().toLowerCase();
    nextSettings.syncDest = rawDest === 'local-fs' ? 'local' : rawDest;
  }
  if (patch.vaultPassphrase !== undefined) {
    nextSettings.vaultPassphrase = patch.vaultPassphrase === null ? '' : String(patch.vaultPassphrase);
  }

  saveVault({ ...v, settings: nextSettings });
  return { ...nextSettings };
}

function getProviderState(providerName) {
  const key = providerName === 'local-fs' ? 'local' : providerName;
  const v = loadVault();
  const st = v.providers[key];
  if (!st) return { connected: false, config: null };
  return JSON.parse(JSON.stringify(st));
}

function setProviderState(providerName, nextState) {
  const key = providerName === 'local-fs' ? 'local' : providerName;
  const v = loadVault();
  const nextProviders = {
    ...v.providers,
    [key]: {
      ...(v.providers[key] || {}),
      ...nextState,
      connected: Boolean(nextState && nextState.connected),
    },
  };
  saveVault({ ...v, providers: nextProviders });
  return getProviderState(key);
}

function clearProviderState(providerName) {
  const key = providerName === 'local-fs' ? 'local' : providerName;
  const reset =
    key === 'telegram'
      ? { connected: false, config: null, index: { indexMessageId: null, profiles: {} } }
      : { connected: false, config: null };
  return setProviderState(key, reset);
}

// ─────────────────────────────────────────────────────── Sync State Ledger
function loadLedger() {
  if (_ledgerCache) return _ledgerCache;
  const stateFile = getStatePath();
  if (!fs.existsSync(stateFile)) {
    _ledgerCache = {};
    return _ledgerCache;
  }
  try {
    const parsed = JSON.parse(fs.readFileSync(stateFile, 'utf8'));
    _ledgerCache = parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
  } catch {
    _ledgerCache = {};
  }
  return _ledgerCache;
}

function saveLedger(nextLedger) {
  const clean = nextLedger && typeof nextLedger === 'object' && !Array.isArray(nextLedger) ? nextLedger : {};
  atomicWriteBufferSync(getStatePath(), Buffer.from(JSON.stringify(clean, null, 2), 'utf8'));
  _ledgerCache = clean;
  return _ledgerCache;
}

function getProfileSyncState(profileId) {
  const ledger = loadLedger();
  const entry = ledger[String(profileId)];
  return entry && typeof entry === 'object' ? { ...entry } : null;
}

function setProfileSyncState(profileId, { digest, dest, size, syncedAt, encrypted } = {}) {
  const ledger = { ...loadLedger() };
  const record = {
    digest: String(digest || ''),
    dest: String(dest || ''),
    size: Number(size || 0),
    syncedAt: syncedAt || new Date().toISOString(),
  };
  if (encrypted !== undefined) {
    record.encrypted = Boolean(encrypted);
  }
  ledger[String(profileId)] = record;
  saveLedger(ledger);
  return { ...record };
}

function removeProfileSyncState(profileId) {
  const ledger = { ...loadLedger() };
  delete ledger[String(profileId)];
  saveLedger(ledger);
}

function getSyncedIds(destFilter = '') {
  const ledger = loadLedger();
  const filter = destFilter === 'local-fs' ? 'local' : String(destFilter || '').trim();
  return Object.keys(ledger).filter((id) => {
    const item = ledger[id];
    if (!item || typeof item !== 'object') return false;
    if (filter && item.dest !== filter) return false;
    return Boolean(item.syncedAt || item.digest);
  });
}

module.exports = {
  VAULT_MAGIC,
  getDataDir,
  setDataDir,
  resetCache,
  getVaultPath,
  getStatePath,
  resolveMachineGuid,
  encryptVaultPayload,
  decryptVaultPayload,
  loadVault,
  saveVault,
  getSettings,
  updateSettings,
  getProviderState,
  setProviderState,
  clearProviderState,
  loadLedger,
  saveLedger,
  getProfileSyncState,
  setProfileSyncState,
  removeProfileSyncState,
  getSyncedIds,
};
