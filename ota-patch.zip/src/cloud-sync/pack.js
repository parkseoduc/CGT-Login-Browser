'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { execFile } = require('node:child_process');
const { PROFILES_DIR } = require('../config');
const vault = require('./vault');
const { sanitizeFileId } = require('./http-client');
const cookieSqlite = require('../core/cookie-sqlite');

// E2EE Binary Envelope Specification:
//   [0..8)   "CGTE2E1\0" (8 bytes magic header)
//   [8..24)  salt        (16 bytes)
//   [24..36) nonce       (12 bytes)
//   [36..52) authTag     (16 bytes)
//   [52..)   ciphertext  (AES-256-GCM encrypted .tgz, key = scryptSync(passphrase, salt, 32))
const E2EE_MAGIC = Buffer.from('CGTE2E1\0', 'utf8');
const E2EE_HEADER_LEN = 8 + 16 + 12 + 16; // 52 bytes

// Chromium userDataDir state whitelist (including SQLite WAL/SHM/Journal sidecars)
const WHITELIST = [
  'cgt-portable-cookies.json',
  'Local State',
  'Default/Preferences',
  'Default/Secure Preferences',
  'Default/Web Data',
  'Default/Web Data-wal',
  'Default/Web Data-shm',
  'Default/Web Data-journal',
  'Default/History',
  'Default/History-wal',
  'Default/History-shm',
  'Default/History-journal',
  'Default/Bookmarks',
  'Default/Login Data',
  'Default/Login Data-wal',
  'Default/Login Data-shm',
  'Default/Login Data-journal',
  'Default/Network/Cookies',
  'Default/Network/Cookies-wal',
  'Default/Network/Cookies-shm',
  'Default/Network/Cookies-journal',
  'Default/Local Storage',
  'Default/Session Storage',
  'Default/IndexedDB',
  'Default/WebStorage',
  'Default/Local Extension Settings',
  'Default/Extension State',
];

// Firefox / Gecko profile whitelist
const FIREFOX_WHITELIST = [
  'prefs.js',
  'key4.db',
  'cert9.db',
  'pkcs11.txt',
  'cookies.sqlite',
  'cookies.sqlite-wal',
  'cookies.sqlite-shm',
  'cookies.sqlite-journal',
  'places.sqlite',
  'places.sqlite-wal',
  'places.sqlite-shm',
  'places.sqlite-journal',
  'formhistory.sqlite',
  'formhistory.sqlite-wal',
  'formhistory.sqlite-shm',
  'formhistory.sqlite-journal',
  'autofill-profiles.json',
  'logins.db',
  'logins.db-wal',
  'logins.db-shm',
  'logins.json',
  'logins-backup.json',
  'permissions.sqlite',
  'permissions.sqlite-wal',
  'permissions.sqlite-shm',
  'content-prefs.sqlite',
  'content-prefs.sqlite-wal',
  'content-prefs.sqlite-shm',
  'webappsstore.sqlite',
  'webappsstore.sqlite-wal',
  'webappsstore.sqlite-shm',
  'storage.sqlite',
  'storage.sqlite-wal',
  'storage.sqlite-shm',
  'storage/default',
  'storage/permanent',
  'storage/ls-archive.sqlite',
  'extensions',
  'extensions.json',
  'extension-preferences.json',
  'extension-store',
  'addonStartup.json.lz4',
  'containers.json',
  'handlers.json',
  'search.json.mozlz4',
  'xulstore.json',
  'times.json',
];

const ALL_ENTRIES = WHITELIST.concat(FIREFOX_WHITELIST);
const FIREFOX_ROOT_SET = new Set(FIREFOX_WHITELIST.map((e) => e.split('/')[0]));

// Exclude auto-regenerated caches even if nested inside whitelisted directories
const EXCLUDE_RE = /(^|[\\/])(Cache|Code Cache|GPUCache|CacheStorage|Service Worker|GrShaderCache|DawnCache|DawnGraphiteCache|blob_storage)([\\/]|$)/i;

let _customProfilesDir = null;

function getProfilesDir() {
  return _customProfilesDir || process.env.CGT_CLOUD_SYNC_PROFILES_DIR || PROFILES_DIR;
}

function setProfilesDir(dir) {
  _customProfilesDir = dir ? path.resolve(dir) : null;
}

function getTarExecutable() {
  if (process.platform === 'win32') {
    const sysTar = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'tar.exe');
    if (fs.existsSync(sysTar)) return sysTar;
  }
  return 'tar';
}

function runTar(args) {
  return new Promise((resolve, reject) => {
    execFile(
      getTarExecutable(),
      args,
      {
        windowsHide: true,
        maxBuffer: 64 * 1024 * 1024,
        timeout: 120000,
      },
      (err, stdout, stderr) => {
        if (err) {
          const msg = (stderr && stderr.trim()) || err.message || 'TAR_EXECUTION_FAILED';
          reject(Object.assign(new Error(`TAR_FAILED: ${msg}`), { code: 'TAR_FAILED', cause: err }));
          return;
        }
        resolve({ stdout: stdout || '', stderr: stderr || '' });
      }
    );
  });
}

function norm(p) {
  return String(p).split(path.sep).join('/').replace(/\\/g, '/');
}

function existingEntries(root) {
  if (!root || !fs.existsSync(root)) return [];
  return ALL_ENTRIES.filter((rel) => fs.existsSync(path.join(root, rel)));
}

function resolveUserDataDir(profileId, explicitUserDataDir, { preferFirefox = false } = {}) {
  if (explicitUserDataDir) {
    return path.resolve(explicitUserDataDir);
  }
  const safeId = sanitizeFileId(profileId);
  const baseProfileDir = path.join(getProfilesDir(), safeId);
  const chromeDir = path.join(baseProfileDir, 'chrome');
  const firefoxDir = path.join(baseProfileDir, 'firefox');

  const chromeEntries = existingEntries(chromeDir);
  if (chromeEntries.length > 0) return chromeDir;

  const firefoxEntries = existingEntries(firefoxDir);
  if (firefoxEntries.length > 0) return firefoxDir;

  if (preferFirefox) {
    if (fs.existsSync(chromeDir) && !fs.existsSync(firefoxDir)) return chromeDir;
    return firefoxDir;
  }

  if (fs.existsSync(chromeDir)) return chromeDir;
  if (fs.existsSync(firefoxDir)) return firefoxDir;
  return chromeDir;
}

function walkFiles(root, rel, out, seen) {
  const abs = path.join(root, rel);
  let st;
  try {
    st = fs.lstatSync(abs);
  } catch {
    return;
  }
  // Never traverse symlinks/junctions
  if (st.isSymbolicLink()) return;

  const normalizedRel = norm(rel);
  if (EXCLUDE_RE.test(normalizedRel + (st.isDirectory() ? '/' : ''))) return;

  if (st.isDirectory()) {
    let names;
    try {
      names = fs.readdirSync(abs).sort();
    } catch {
      return;
    }
    for (const name of names) {
      walkFiles(root, path.join(rel, name), out, seen);
    }
  } else if (st.isFile()) {
    if (seen.has(normalizedRel)) return;
    seen.add(normalizedRel);
    out.push({ rel: normalizedRel, size: st.size, mtimeMs: st.mtimeMs });
  }
}

function parseUserDataDirArg(arg) {
  if (!arg) return undefined;
  if (typeof arg === 'string') return arg;
  if (typeof arg === 'object' && arg.userDataDir) return arg.userDataDir;
  return undefined;
}

/**
 * Compute deterministic SHA-256 manifest of whitelisted profile runtime state.
 * @param {string} profileId
 * @param {string | { userDataDir?: string }} [optsOrDir]
 */
function manifest(profileId, optsOrDir) {
  const explicitDir = parseUserDataDirArg(optsOrDir);
  const root = resolveUserDataDir(profileId, explicitDir);
  try { cookieSqlite.ensurePortableSidecarFromDisk(root); } catch {}
  const files = [];
  const seen = new Set();

  for (const entry of existingEntries(root)) {
    walkFiles(root, entry, files, seen);
  }

  let totalBytes = 0;
  const entries = files.map((f) => {
    const buf = fs.readFileSync(path.join(root, f.rel));
    totalBytes += buf.length;
    const sha256 = crypto.createHash('sha256').update(buf).digest('hex');
    return { rel: f.rel, size: buf.length, sha256 };
  });

  entries.sort((a, b) => (a.rel < b.rel ? -1 : a.rel > b.rel ? 1 : 0));

  const digest = crypto
    .createHash('sha256')
    .update(entries.map((e) => `${e.rel}:${e.sha256}`).join('\n'))
    .digest('hex');

  return {
    id: String(profileId),
    totalBytes,
    fileCount: entries.length,
    digest,
    entries,
  };
}

function isEncryptedBuffer(buf) {
  return Buffer.isBuffer(buf) && buf.length >= 8 && buf.subarray(0, 8).equals(E2EE_MAGIC);
}

function isEncryptedFile(filePath) {
  const fd = fs.openSync(filePath, 'r');
  try {
    const header = Buffer.alloc(8);
    const bytesRead = fs.readSync(fd, header, 0, 8, 0);
    return bytesRead === 8 && header.equals(E2EE_MAGIC);
  } finally {
    fs.closeSync(fd);
  }
}

function encryptArchiveBuffer(plainBuf, passphrase) {
  const salt = crypto.randomBytes(16);
  const nonce = crypto.randomBytes(12);
  const key = crypto.scryptSync(passphrase, salt, 32);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, nonce);
  const ciphertext = Buffer.concat([cipher.update(plainBuf), cipher.final()]);
  const tag = cipher.getAuthTag();
  return Buffer.concat([E2EE_MAGIC, salt, nonce, tag, ciphertext]);
}

function decryptArchiveBuffer(encBuf, passphrase) {
  if (!passphrase || typeof passphrase !== 'string' || passphrase.length === 0) {
    throw Object.assign(new Error('E2EE_PASSPHRASE_REQUIRED'), {
      code: 'E2EE_PASSPHRASE_REQUIRED',
      detail: 'Archive is encrypted with E2EE; a passphrase is required to unpack.',
    });
  }
  if (!Buffer.isBuffer(encBuf) || encBuf.length < E2EE_HEADER_LEN || !isEncryptedBuffer(encBuf)) {
    throw Object.assign(new Error('E2EE_DECRYPT_FAILED'), {
      code: 'E2EE_DECRYPT_FAILED',
      detail: 'Invalid or truncated CGTE2E1 envelope.',
    });
  }

  const salt = encBuf.subarray(8, 24);
  const nonce = encBuf.subarray(24, 36);
  const tag = encBuf.subarray(36, 52);
  const ciphertext = encBuf.subarray(52);

  try {
    const key = crypto.scryptSync(passphrase, salt, 32);
    const decipher = crypto.createDecipheriv('aes-256-gcm', key, nonce);
    decipher.setAuthTag(tag);
    return Buffer.concat([decipher.update(ciphertext), decipher.final()]);
  } catch (err) {
    throw Object.assign(new Error('E2EE_DECRYPT_FAILED'), {
      code: 'E2EE_DECRYPT_FAILED',
      detail: 'Incorrect E2EE passphrase or corrupted encrypted archive.',
      cause: err,
    });
  }
}

function ensureSyncTmpDir() {
  const dir = path.join(vault.getDataDir(), 'cloud-sync-tmp');
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

/**
 * Validate every tar entry path BEFORE extraction to prevent Zip-Slip / Tar-Slip path traversal.
 */
function validateArchiveEntryPaths(rawLines) {
  const cleaned = [];
  for (const line of rawLines) {
    const raw = String(line || '').replace(/\r$/, '');
    if (!raw) continue;

    if (raw.includes('\0')) {
      throw Object.assign(new Error('ARCHIVE_PATH_TRAVERSAL'), {
        code: 'ARCHIVE_PATH_TRAVERSAL',
        entry: raw,
      });
    }

    // Reject Windows drive-letter paths (C:...), UNC paths (\\...), or absolute paths (/...)
    if (/^[a-zA-Z]:/.test(raw) || /^[\\/]{2}/.test(raw) || /^[\\/]/.test(raw)) {
      throw Object.assign(new Error('ARCHIVE_PATH_TRAVERSAL'), {
        code: 'ARCHIVE_PATH_TRAVERSAL',
        entry: raw,
      });
    }

    let normalized = raw.replace(/\\/g, '/');
    if (normalized.startsWith('./')) {
      normalized = normalized.slice(2);
    }
    normalized = normalized.replace(/\/+$/, '');
    if (!normalized || normalized === '.') continue;

    const segments = normalized.split('/');
    for (const seg of segments) {
      if (!seg || seg === '.' || seg === '..') {
        throw Object.assign(new Error('ARCHIVE_PATH_TRAVERSAL'), {
          code: 'ARCHIVE_PATH_TRAVERSAL',
          entry: raw,
        });
      }
    }

    // Extra belt-and-suspenders check via path.resolve containment
    const dummyRoot = path.resolve(ensureSyncTmpDir(), '__containment_root__');
    const resolved = path.resolve(dummyRoot, normalized);
    if (!resolved.startsWith(dummyRoot + path.sep)) {
      throw Object.assign(new Error('ARCHIVE_PATH_TRAVERSAL'), {
        code: 'ARCHIVE_PATH_TRAVERSAL',
        entry: raw,
      });
    }

    cleaned.push(normalized);
  }

  return cleaned;
}

function isFirefoxOnlyArchive(entries) {
  if (!entries.length) return false;
  let hasFirefox = false;
  for (const rel of entries) {
    const top = rel.split('/')[0];
    if (top === 'Default' || top === 'Local State') return false;
    if (FIREFOX_ROOT_SET.has(top)) hasFirefox = true;
  }
  return hasFirefox;
}

function copyValidatedTree(stageRoot, targetRoot, relDir = '') {
  const currentSrc = relDir ? path.join(stageRoot, relDir) : stageRoot;
  const items = fs.readdirSync(currentSrc);

  for (const name of items) {
    const nextRel = relDir ? path.join(relDir, name) : name;
    const srcPath = path.join(stageRoot, nextRel);
    const st = fs.lstatSync(srcPath);

    if (st.isSymbolicLink()) {
      throw Object.assign(new Error('ARCHIVE_PATH_TRAVERSAL'), {
        code: 'ARCHIVE_PATH_TRAVERSAL',
        detail: `Symbolic link prohibited inside profile archive: ${nextRel}`,
      });
    }

    const normalizedRel = norm(nextRel);
    if (EXCLUDE_RE.test(normalizedRel + (st.isDirectory() ? '/' : ''))) {
      continue;
    }

    const destPath = path.resolve(targetRoot, nextRel);
    if (!destPath.startsWith(path.resolve(targetRoot) + path.sep)) {
      throw Object.assign(new Error('ARCHIVE_PATH_TRAVERSAL'), {
        code: 'ARCHIVE_PATH_TRAVERSAL',
        entry: nextRel,
      });
    }

    if (st.isDirectory()) {
      fs.mkdirSync(destPath, { recursive: true });
      copyValidatedTree(stageRoot, targetRoot, nextRel);
    } else if (st.isFile()) {
      fs.mkdirSync(path.dirname(destPath), { recursive: true });
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

/**
 * Pack a profile's whitelisted state into a .tgz archive (optionally E2EE encrypted).
 * @param {string} profileId
 * @param {object|string} [opts] - { passphrase?, userDataDir?, outFile? }
 */
async function pack(profileId, opts = {}) {
  const options = typeof opts === 'string' ? { outFile: opts } : opts || {};
  const passphrase = typeof options.passphrase === 'string' ? options.passphrase : '';
  const root = resolveUserDataDir(profileId, options.userDataDir);

  if (!fs.existsSync(root)) {
    throw Object.assign(new Error('PROFILE_DATA_NOT_FOUND'), { code: 'PROFILE_DATA_NOT_FOUND' });
  }

  // Refresh decrypted portable cookie sidecar right before staging .tgz (protected inside E2EE CGTE2E1)
  try { cookieSqlite.ensurePortableSidecarFromDisk(root); } catch {}

  const topEntries = existingEntries(root);
  if (!topEntries.length) {
    throw Object.assign(new Error('PROFILE_DATA_EMPTY'), { code: 'PROFILE_DATA_EMPTY' });
  }

  const files = [];
  const seen = new Set();
  for (const entry of topEntries) {
    walkFiles(root, entry, files, seen);
  }
  if (!files.length) {
    throw Object.assign(new Error('PROFILE_DATA_EMPTY'), { code: 'PROFILE_DATA_EMPTY' });
  }

  const tmpRoot = ensureSyncTmpDir();
  const uniqueTag = `${sanitizeFileId(profileId)}-${process.pid}-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;
  const stageDir = path.join(tmpRoot, `stage-${uniqueTag}`);
  const rawTgzPath = path.join(tmpRoot, `raw-${uniqueTag}.tgz`);
  const outPath = options.outFile ? path.resolve(options.outFile) : path.join(tmpRoot, `cgt-profile-${uniqueTag}.tgz`);

  fs.mkdirSync(stageDir, { recursive: true });
  fs.mkdirSync(path.dirname(outPath), { recursive: true });

  try {
    let totalBytes = 0;
    const manifestEntries = [];

    // Stage clean whitelisted files and compute exact snapshot SHA-256 in a single pass
    for (const f of files) {
      const srcFile = path.join(root, f.rel);
      const dstFile = path.join(stageDir, f.rel);
      const buf = fs.readFileSync(srcFile);
      fs.mkdirSync(path.dirname(dstFile), { recursive: true });
      fs.writeFileSync(dstFile, buf);

      totalBytes += buf.length;
      const sha256 = crypto.createHash('sha256').update(buf).digest('hex');
      manifestEntries.push({ rel: f.rel, size: buf.length, sha256 });
    }

    manifestEntries.sort((a, b) => (a.rel < b.rel ? -1 : a.rel > b.rel ? 1 : 0));
    const digest = crypto
      .createHash('sha256')
      .update(manifestEntries.map((e) => `${e.rel}:${e.sha256}`).join('\n'))
      .digest('hex');

    const topStageItems = fs.readdirSync(stageDir).sort();
    const targetForTar = passphrase ? rawTgzPath : outPath;

    await runTar(['-czf', targetForTar, '-C', stageDir, ...topStageItems]);

    if (passphrase) {
      const plainTgz = fs.readFileSync(rawTgzPath);
      const encryptedBuf = encryptArchiveBuffer(plainTgz, passphrase);
      fs.writeFileSync(outPath, encryptedBuf);
    }

    const size = fs.statSync(outPath).size;
    return {
      path: outPath,
      size,
      digest,
      encrypted: Boolean(passphrase),
      fileCount: manifestEntries.length,
      totalBytes,
    };
  } finally {
    try {
      fs.rmSync(stageDir, { recursive: true, force: true });
    } catch {
      // ignore
    }
    try {
      if (fs.existsSync(rawTgzPath)) fs.rmSync(rawTgzPath, { force: true });
    } catch {
      // ignore
    }
  }
}

/**
 * Unpack a plain or CGTE2E1-encrypted .tgz package into a profile's userDataDir.
 * Verifies path-traversal safety and symlink absence BEFORE touching userDataDir.
 * @param {string} profileId
 * @param {string} packageFile
 * @param {object|string} [opts] - { mode?: 'merge' | 'replace', passphrase?: string, userDataDir?: string }
 */
async function unpack(profileId, packageFile, opts = {}) {
  const options = typeof opts === 'string' ? { mode: opts } : opts || {};
  const mode = options.mode || 'merge';
  const passphrase = typeof options.passphrase === 'string' ? options.passphrase : '';

  if (!packageFile || !fs.existsSync(packageFile)) {
    throw Object.assign(new Error('PACKAGE_NOT_FOUND'), { code: 'PACKAGE_NOT_FOUND' });
  }

  const tmpRoot = ensureSyncTmpDir();
  const uniqueTag = `${sanitizeFileId(profileId)}-${process.pid}-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;
  const decryptedTgzPath = path.join(tmpRoot, `dec-${uniqueTag}.tgz`);
  const extractStageDir = path.join(tmpRoot, `unpack-${uniqueTag}`);

  let tgzToExtract = path.resolve(packageFile);

  try {
    if (isEncryptedFile(tgzToExtract)) {
      const encBuf = fs.readFileSync(tgzToExtract);
      const plainBuf = decryptArchiveBuffer(encBuf, passphrase);
      fs.writeFileSync(decryptedTgzPath, plainBuf);
      tgzToExtract = decryptedTgzPath;
    }

    // 1. Inspect archive table-of-contents BEFORE extracting any bytes to disk
    const { stdout } = await runTar(['-tzf', tgzToExtract]);
    const lines = stdout.split(/\r?\n/).filter(Boolean);
    const validatedEntries = validateArchiveEntryPaths(lines);

    // 2. Extract into an isolated staging directory first
    fs.mkdirSync(extractStageDir, { recursive: true });
    await runTar(['-xzf', tgzToExtract, '-C', extractStageDir]);

    // 3. Resolve target userDataDir (supporting Chromium & Firefox layouts)
    const preferFirefox = isFirefoxOnlyArchive(validatedEntries);
    const targetRoot = resolveUserDataDir(profileId, options.userDataDir, { preferFirefox });
    fs.mkdirSync(targetRoot, { recursive: true });

    // 4. Only wipe previous whitelist roots in 'replace' mode AFTER decrypt + extract succeeded
    if (mode === 'replace') {
      const rootsToClear = new Set(['Default', 'Local State']);
      for (const rel of FIREFOX_WHITELIST) {
        rootsToClear.add(rel.split('/')[0]);
      }
      for (const rel of rootsToClear) {
        try {
          fs.rmSync(path.join(targetRoot, rel), { recursive: true, force: true });
        } catch {
          // ignore
        }
      }
    }

    // 5. Copy validated regular files (rejecting symlinks & excluded cache paths) into targetRoot
    copyValidatedTree(extractStageDir, targetRoot);

    return manifest(profileId, { userDataDir: targetRoot });
  } finally {
    try {
      if (fs.existsSync(decryptedTgzPath)) fs.rmSync(decryptedTgzPath, { force: true });
    } catch {
      // ignore
    }
    try {
      if (fs.existsSync(extractStageDir)) fs.rmSync(extractStageDir, { recursive: true, force: true });
    } catch {
      // ignore
    }
  }
}

module.exports = {
  E2EE_MAGIC,
  WHITELIST,
  FIREFOX_WHITELIST,
  ALL_ENTRIES,
  EXCLUDE_RE,
  getProfilesDir,
  setProfilesDir,
  resolveUserDataDir,
  manifest,
  isEncryptedFile,
  isEncryptedBuffer,
  pack,
  unpack,
};
