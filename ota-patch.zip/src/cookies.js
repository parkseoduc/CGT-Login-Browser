'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { CdpClient } = require('./cdp');
const { PROFILES_DIR } = require('./config');
const db = require('./db');
const cookieSqlite = require('./core/cookie-sqlite');

function getLauncher() {
  return require('./launcher');
}

function normSameSite(v) {
  if (v == null || v === '') return undefined;
  const s = String(v).trim().toLowerCase();
  if (s === 'strict' || s === '2') return 'Strict';
  if (s === 'lax' || s === '1') return 'Lax';
  if (s === 'none' || s === 'no_restriction' || s === '0') return 'None';
  return undefined;
}

function toBool(v) {
  if (v == null || v === '') return false;
  if (typeof v === 'boolean') return v;
  const s = String(v).trim().toLowerCase();
  return !(s === '0' || s === 'false' || s === 'no');
}

function mapCookieItem(c, fallbackDomain = '') {
  if (!c || !c.name) return null;
  const domain = String(c.domain || c.Domain || fallbackDomain || '').trim();
  const sameSite = normSameSite(c.same_site !== undefined ? c.same_site : c.sameSite);
  const expRaw = c.expiration_time ?? c.expires ?? c.expirationDate;
  const expNum = Number(expRaw);
  const item = {
    name: String(c.name).trim(),
    value: String(c.value ?? ''),
    path: c.path ? String(c.path) : '/',
    secure: sameSite === 'None' ? true : toBool(c.secure),
    httpOnly: toBool(c.http_only !== undefined ? c.http_only : c.httpOnly),
  };
  if (domain) item.domain = domain;
  else if (c.url) item.url = String(c.url);
  if (sameSite) item.sameSite = sameSite;
  if (Number.isFinite(expNum) && expNum > 0) item.expires = expNum;
  return item;
}

function looksNetscape(txt) {
  if (/^#\s*(?:Netscape\s+)?HTTP\s+Cookie\s+File/im.test(txt)) return true;
  return txt.split(/\r?\n/).some((line) => {
    if (!line || (line[0] === '#' && !/^#HttpOnly_/i.test(line))) return false;
    return line.split('\t').length >= 7;
  });
}

function parseNetscape(txt) {
  const out = [];
  for (let line of txt.split(/\r?\n/)) {
    if (!line || !line.trim()) continue;
    let httpOnly = false;
    if (/^#HttpOnly_/i.test(line)) {
      httpOnly = true;
      line = line.replace(/^#HttpOnly_/i, '');
    } else if (line[0] === '#') {
      continue;
    }
    const parts = line.split('\t');
    if (parts.length < 7) continue;
    const name = (parts[5] || '').trim();
    if (!name) continue;
    out.push({
      domain: (parts[0] || '').trim(),
      path: (parts[2] || '/').trim(),
      secure: /^true$/i.test((parts[3] || '').trim()),
      expiration_time: Number((parts[4] || '').trim()) || 0,
      name,
      value: parts.slice(6).join('\t').trim(),
      http_only: httpOnly,
    });
  }
  return out;
}

/**
 * Auto-detect & parse 3 standard cookie formats:
 * 1. JSON array/object (Chrome / Cookie-Editor / MKTLogin)
 * 2. Netscape cookies.txt (tab-separated 7 columns)
 * 3. Header key=value pairs (`k1=v1; k2=v2`)
 */
function parseCookieInput(rawInput, fallbackDomain = '') {
  if (Array.isArray(rawInput)) {
    return rawInput.map((c) => mapCookieItem(c, fallbackDomain)).filter(Boolean);
  }
  const txt = String(rawInput == null ? '' : rawInput).trim();
  if (!txt) return [];
  let list = [];
  if (txt[0] === '[' || txt[0] === '{') {
    const parsed = JSON.parse(txt);
    list = Array.isArray(parsed) ? parsed : [parsed];
  } else if (looksNetscape(txt)) {
    list = parseNetscape(txt);
  } else {
    list = txt
      .split(/\r?\n/)
      .flatMap((l) => l.split(';'))
      .map((s) => s.trim())
      .filter(Boolean)
      .map((pair) => {
        const idx = pair.indexOf('=');
        return {
          name: (idx < 0 ? pair : pair.slice(0, idx)).trim(),
          value: idx < 0 ? '' : pair.slice(idx + 1).trim(),
          domain: fallbackDomain,
        };
      });
  }
  return list.map((c) => mapCookieItem(c, fallbackDomain)).filter(Boolean);
}

/**
 * Export cookies via CDP (if running, reads live; otherwise checks saved seed or temporarily launches).
 */
async function exportCookies(profileId, { autoLaunch = false, forceLaunch = false } = {}) {
  const launcher = getLauncher();
  const wasRunning = launcher.isProfileRunning(profileId);
  let info = launcher.getRunningInfo(profileId);

  if (!info && !forceLaunch) {
    const prof = db.getProfile(profileId);
    const engine = prof && String(prof.engine || '').toLowerCase() === 'firefox' ? 'firefox' : 'chromium';
    const primaryDir = path.join(PROFILES_DIR, String(profileId), engine === 'firefox' ? 'firefox' : 'chrome');
    const altDir = path.join(PROFILES_DIR, String(profileId), engine === 'firefox' ? 'chrome' : 'firefox');

    let diskCookies = cookieSqlite.readOfflineCookies(primaryDir);
    if (!diskCookies.length && fs.existsSync(altDir)) {
      diskCookies = cookieSqlite.readOfflineCookies(altDir);
    }

    const seeded = prof && prof.cookie_seed ? parseCookieInput(prof.cookie_seed) : [];
    const mergedMap = new Map();
    for (const c of [...seeded, ...diskCookies]) {
      if (!c || !c.name) continue;
      mergedMap.set(`${c.domain || ''}|${c.path || '/'}|${c.name}`, c);
    }
    const merged = [...mergedMap.values()];

    if (merged.length > 0 || !autoLaunch || fs.existsSync(primaryDir)) {
      return {
        success: true,
        ok: true,
        offline: true,
        count: merged.length,
        cookies: merged,
        text: JSON.stringify(merged),
        netscape: convertToNetscape(merged),
      };
    }
  }

  if (!info) {
    info = await launcher.startProfile(profileId, { blank: true });
    await new Promise((r) => setTimeout(r, 1500));
  }

  if (!info || !info.wsEndpoint) {
    throw new Error('Không thể kết nối tới trình duyệt để xuất cookie');
  }

  const client = new CdpClient(info.wsEndpoint);
  await client.connect(5000);

  try {
    let res = null;
    try {
      res = await client.send('Storage.getCookies');
    } catch {
      res = await client.send('Network.getAllCookies');
    }
    const cookies = (res && res.cookies) ? res.cookies : [];

    if (!wasRunning) {
      setTimeout(() => launcher.stopProfile(profileId).catch(() => {}), 1000);
    }

    return {
      success: true,
      ok: true,
      count: cookies.length,
      cookies,
      text: JSON.stringify(cookies),
      netscape: convertToNetscape(cookies),
    };
  } finally {
    client.close();
  }
}

/**
 * Import cookies (accepts Array, JSON string, Netscape string, or `k=v;` string).
 * If profile is closed and `deferIfClosed: true`, stores in `cookie_seed` to apply at next launch.
 */
async function importCookies(profileId, cookiesInput, { fallbackDomain = '', deferIfClosed = false } = {}) {
  const formatted = parseCookieInput(cookiesInput, fallbackDomain);
  if (!formatted.length) {
    throw new Error('Danh sách cookie không hợp lệ hoặc trống');
  }

  // Persist latest seed in profile DB & portable sidecar
  try {
    db.updateProfile(profileId, { cookie_seed: JSON.stringify(formatted) });
    const prof = db.getProfile(profileId);
    const sub = prof && String(prof.engine || '').toLowerCase() === 'firefox' ? 'firefox' : 'chrome';
    const userDataDir = path.join(PROFILES_DIR, String(profileId), sub);
    cookieSqlite.writePortableSidecar(userDataDir, formatted);
  } catch {}

  const launcher = getLauncher();
  let info = launcher.getRunningInfo(profileId);
  const wasRunning = Boolean(info);

  if (!info && deferIfClosed) {
    return { success: true, ok: true, deferred: true, count: formatted.length };
  }

  if (!info) {
    info = await launcher.startProfile(profileId, { blank: true });
    await new Promise((r) => setTimeout(r, 1500));
  }

  const client = new CdpClient(info.wsEndpoint);
  await client.connect(5000);

  try {
    const validForCdp = formatted.filter((c) => c.domain || c.url);
    if (validForCdp.length) {
      try {
        await client.send('Storage.setCookies', { cookies: validForCdp });
      } catch {
        await client.send('Network.setCookies', { cookies: validForCdp });
      }
    }

    if (!wasRunning) {
      setTimeout(() => launcher.stopProfile(profileId).catch(() => {}), 1200);
    }

    return {
      success: true,
      ok: true,
      count: validForCdp.length,
    };
  } finally {
    client.close();
  }
}

/**
 * Clear profile cache and/or cookies safely.
 */
async function clearProfileData(profileId, { cookies = false, cache = true } = {}) {
  const launcher = getLauncher();
  const info = launcher.getRunningInfo(profileId);
  if (info && info.wsEndpoint) {
    const client = new CdpClient(info.wsEndpoint);
    try {
      await client.connect(3000);
      if (cookies) await client.send('Network.clearBrowserCookies').catch(() => {});
      if (cache) await client.send('Network.clearBrowserCache').catch(() => {});
    } finally {
      client.close();
    }
    if (cookies) {
      try { db.updateProfile(profileId, { cookie_seed: '' }); } catch {}
    }
    return { ok: true, online: true };
  }

  const userDataDir = path.join(PROFILES_DIR, profileId, 'chrome');
  if (cache && fs.existsSync(userDataDir)) {
    const cacheDirs = [
      path.join(userDataDir, 'Default', 'Cache'),
      path.join(userDataDir, 'Default', 'Code Cache'),
      path.join(userDataDir, 'Default', 'GPUCache'),
      path.join(userDataDir, 'ShaderCache'),
      path.join(userDataDir, 'GrShaderCache'),
    ];
    for (const d of cacheDirs) {
      try { if (fs.existsSync(d)) fs.rmSync(d, { recursive: true, force: true }); } catch {}
    }
  }
  if (cookies) {
    try { db.updateProfile(profileId, { cookie_seed: '' }); } catch {}
    for (const f of [
      path.join(userDataDir, 'Default', 'Network', 'Cookies'),
      path.join(userDataDir, 'Default', 'Network', 'Cookies-wal'),
      path.join(userDataDir, 'Default', 'Cookies'),
    ]) {
      try { if (fs.existsSync(f)) fs.unlinkSync(f); } catch {}
    }
  }
  return { ok: true, online: false };
}

function convertToNetscape(cookies) {
  const lines = ['# Netscape HTTP Cookie File', '# https://curl.haxx.se/rfc/cookie_spec.html', ''];
  for (const c of cookies) {
    const domain = c.domain || '';
    const flag = domain.startsWith('.') ? 'TRUE' : 'FALSE';
    const p = c.path || '/';
    const secure = c.secure ? 'TRUE' : 'FALSE';
    const expires = Math.floor(c.expires || c.expiration_time || 2147483647);
    lines.push(`${domain}\t${flag}\t${p}\t${secure}\t${expires}\t${c.name}\t${c.value}`);
  }
  return lines.join('\n');
}

module.exports = {
  parseCookieInput,
  exportCookies,
  importCookies,
  clearProfileData,
  convertToNetscape,
};
