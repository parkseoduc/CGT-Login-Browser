'use strict';

const kernelManager = require('./core/kernel-manager');

/**
 * Dynamically generate OpenAPI 3.0.3 Specification reflecting installed Chromium & Firefox kernels
 * for CGT-Login v2.0 Automation API & Swagger UI (`/v3/api-docs`).
 */
function buildOpenApiSpec(port = 51888) {
  const kernels = kernelManager.listKernels();
  const chromiumMajors = kernels.filter((k) => k.engine === 'chromium').map((k) => k.major);
  const firefoxMajors = kernels.filter((k) => k.engine === 'firefox').map((k) => k.major);

  return {
    openapi: '3.0.3',
    info: {
      title: 'CGTBrowser v3.1 Local Automation & Antidetect API',
      version: '3.1.0',
      description: `REST & CDP Automation API cho CGT-Login. Nhân đã cài: Chromium [${chromiumMajors.join(', ') || '153'}], Firefox [${firefoxMajors.join(', ') || 'none'}].`,
    },
    servers: [
      { url: `http://127.0.0.1:${port}`, description: 'Local Loopback Engine' },
    ],
    tags: [
      { name: 'System', description: 'Trạng thái hệ thống & SSE Realtime' },
      { name: 'Profiles', description: 'Quản lý hồ sơ, khởi chạy trình duyệt & Cookie' },
      { name: 'Trash & Tags', description: 'Thùng rác khôi phục & Thẻ phân loại' },
      { name: 'Kernels', description: 'Quản lý đa nhân Chromium & Firefox' },
      { name: 'Action Sync', description: 'Đồng bộ thao tác đa cửa sổ & xếp lưới' },
      { name: 'Visual RPA', description: 'Quy trình 53 node RPA, Nhiệm vụ đa luồng & Hẹn giờ' },
      { name: 'Cloud Sync', description: 'Đồng bộ dữ liệu đám mây E2EE (Local, S3, Drive, Telegram)' },
      { name: 'MCP', description: 'Model Context Protocol cho AI Agents' },
    ],
    paths: {
      '/api/v1/status': {
        get: { tags: ['System'], summary: 'Kiểm tra trạng thái hệ thống & nhân trình duyệt', responses: { 200: { description: 'OK' } } },
      },
      '/api/v1/events/stream': {
        get: { tags: ['System'], summary: 'Luồng SSE Realtime (profile:state, sync:status, rpa:log, cloud:progress)', responses: { 200: { description: 'text/event-stream' } } },
      },
      '/api/v1/profiles': {
        get: { tags: ['Profiles'], summary: 'Lấy danh sách hồ sơ (lọc search, groupId, tag, engine)', responses: { 200: { description: 'OK' } } },
        post: { tags: ['Profiles'], summary: 'Tạo hồ sơ mới với vân tay tự động nhất quán', responses: { 201: { description: 'Created' } } },
      },
      '/api/v1/profiles/{id}/start': {
        post: { tags: ['Profiles'], summary: 'Mở trình duyệt hồ sơ và nhận wsEndpoint CDP', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], responses: { 200: { description: 'Started with wsEndpoint' } } },
      },
      '/api/v1/profiles/{id}/stop': {
        post: { tags: ['Profiles'], summary: 'Đóng êm trình duyệt hồ sơ (flush Cookie + Cloud Sync)', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], responses: { 200: { description: 'Stopped' } } },
      },
      '/api/v1/profiles/{id}/cookies': {
        get: { tags: ['Profiles'], summary: 'Xuất Cookie (JSON & Netscape)', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], responses: { 200: { description: 'OK' } } },
        post: { tags: ['Profiles'], summary: 'Nhập Cookie (tự nhận JSON, Netscape, k=v;)', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], responses: { 200: { description: 'OK' } } },
      },
      '/api/v1/trash': {
        get: { tags: ['Trash & Tags'], summary: 'Danh sách hồ sơ trong Thùng rác', responses: { 200: { description: 'OK' } } },
      },
      '/api/v1/trash/restore': {
        post: { tags: ['Trash & Tags'], summary: 'Khôi phục hồ sơ từ Thùng rác', responses: { 200: { description: 'OK' } } },
      },
      '/api/v1/kernels': {
        get: { tags: ['Kernels'], summary: 'Danh sách nhân trình duyệt Chromium & Firefox', responses: { 200: { description: 'OK' } } },
      },
      '/api/v1/sync/start': {
        post: { tags: ['Action Sync'], summary: 'Bắt đầu đồng bộ thao tác Master -> Slaves', responses: { 200: { description: 'OK' } } },
      },
      '/api/v1/sync/arrange': {
        post: { tags: ['Action Sync'], summary: 'Xếp cửa sổ chuẩn Uniform Grid / Cascade / Manual', responses: { 200: { description: 'OK' } } },
      },
      '/api/v1/rpa/catalog': {
        get: { tags: ['Visual RPA'], summary: 'Danh mục 53 loại node RPA & toán tử điều kiện', responses: { 200: { description: 'OK' } } },
      },
      '/api/v1/rpa/flows': {
        get: { tags: ['Visual RPA'], summary: 'Danh sách quy trình Visual RPA', responses: { 200: { description: 'OK' } } },
        post: { tags: ['Visual RPA'], summary: 'Lưu đồ thị quy trình Visual RPA', responses: { 200: { description: 'OK' } } },
      },
      '/api/v1/rpa/run': {
        post: { tags: ['Visual RPA'], summary: 'Thực thi quy trình RPA (đơn lẻ hoặc đa luồng Làn sóng)', responses: { 200: { description: 'OK' } } },
      },
      '/api/v1/cloud-sync/status': {
        get: { tags: ['Cloud Sync'], summary: 'Trạng thái đồng bộ đám mây E2EE', responses: { 200: { description: 'OK' } } },
      },
      '/mcp': {
        post: { tags: ['MCP'], summary: 'MCP Streamable HTTP JSON-RPC 2.0 cho AI Agents', responses: { 200: { description: 'JSON-RPC' } } },
      },
    },
  };
}

module.exports = { buildOpenApiSpec };
