'use strict';

const { spawn, execSync, execFileSync } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
const EventEmitter = require('node:events');

const { PROFILES_DIR, getDefaultKernelPath, BASE_DIR } = require('./config');
const db = require('./db');
const cdp = require('./cdp');
const fingerprint = require('./fingerprint');
const proxy = require('./proxy');
const eventBus = require('./core/event-bus');
const kernelManager = require('./core/kernel-manager');
const launchPrep = require('./core/launch-prep');
const prepPool = require('./core/launch-prep-pool');
const geoIp = require('./core/geo-ip');
const windowLayout = require('./core/window-layout');
const cookieSqlite = require('./core/cookie-sqlite');

let cloudSync = null;
function getCloudSync() {
  if (!cloudSync) {
    try { cloudSync = require('./cloud-sync'); } catch { cloudSync = null; }
  }
  return cloudSync;
}

class LauncherEvents extends EventEmitter {}
const events = new LauncherEvents();

// profileId -> { pid, child, engine, userDataDir, port, wsEndpoint, slot, startedAt, cdpClient, proxyForwarder, fingerprint, geo }
const _running = new Map();
const _closing = new Set();
const _slots = new Map();
const _launchPending = new Set();

function assignSlot(profileId) {
  if (_slots.has(profileId)) return _slots.get(profileId);
  const used = new Set(_slots.values());
  let n = 1;
  while (used.has(n)) n += 1;
  _slots.set(profileId, n);
  return n;
}

function releaseSlot(profileId) {
  _slots.delete(profileId);
}

function getSlot(profileId) {
  return _slots.get(profileId) || null;
}

function getStateSnapshot() {
  const runningIds = [];
  const details = {};
  const slots = {};
  for (const [id, info] of [..._running.entries()]) {
    if (isProfileRunning(id)) {
      runningIds.push(id);
      slots[id] = info.slot || null;
      details[id] = {
        pid: info.pid,
        port: info.port,
        wsEndpoint: info.wsEndpoint,
        slot: info.slot || null,
        engine: info.engine || 'chromium',
        startedAt: info.startedAt,
      };
    }
  }
  return {
    runningIds,
    closingIds: [..._closing],
    slots,
    details,
  };
}

function broadcastState() {
  const snap = getStateSnapshot();
  eventBus.publish('profile:state', snap, { cacheSnapshot: true });
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/**
 * Internal title extension tagging `[#slot ProfileName]` onto tab & taskbar window title.
 */
function ensureProfileTitleExtension(userDataDir, profileName, slot) {
  const extDir = path.join(userDataDir, 'title_extension');
  fs.mkdirSync(extDir, { recursive: true });

  const safeName = (profileName || 'Profile').trim();
  const badgePrefix = slot ? `#${slot} ${safeName}` : safeName;
  const manifest = {
    manifest_version: 3,
    name: `CGT Profile Tag: ${badgePrefix}`,
    version: '2.0.0',
    description: 'Internal profile title tagger for taskbar and window identification',
    content_scripts: [
      {
        matches: ['<all_urls>'],
        js: ['content.js'],
        run_at: 'document_start',
        all_frames: false,
      },
    ],
  };

  const contentScript = `(() => {
  const TAG = '[' + ${JSON.stringify(badgePrefix)} + ']';
  let isSetting = false;
  function formatTitle(raw) {
    if (!raw) return TAG;
    const trimmed = raw.trim();
    if (trimmed.startsWith(TAG)) return trimmed;
    return TAG + ' ' + trimmed;
  }
  function applyTitle() {
    if (isSetting) return;
    const cur = document.title || '';
    if (!cur && document.readyState === 'loading') return;
    if (!cur.startsWith(TAG)) {
      isSetting = true;
      try { document.title = formatTitle(cur); } catch {}
      Promise.resolve().then(() => { isSetting = false; });
    }
  }
  applyTitle();
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', applyTitle, { once: true });
  }
  window.addEventListener('load', applyTitle, { once: true });
  const obs = new MutationObserver(() => applyTitle());
  const attach = () => {
    const t = document.querySelector('head') || document.documentElement;
    if (t) { obs.observe(t, { childList: true, subtree: true, characterData: true }); return true; }
    return false;
  };
  if (!attach()) {
    const poll = setInterval(() => { if (attach()) clearInterval(poll); }, 60);
  }
})();`;

  fs.writeFileSync(path.join(extDir, 'manifest.json'), JSON.stringify(manifest, null, 2), 'utf8');
  fs.writeFileSync(path.join(extDir, 'content.js'), contentScript, 'utf8');
  return extDir;
}

/**
 * Attach stealth CDP overrides (UserAgent + WICG ClientHints, Timezone, Geolocation,
 * and Document/Worker Fingerprint Script) onto every existing and newly created page target.
 */
async function attachCdpStealthToSession(cdpClient, sessionId, fp, injectionScript) {
  if (!cdpClient || !sessionId || !fp) return;
  try {
    await cdpClient.send('Page.enable', {}, sessionId, 2500).catch(() => {});

    // 1. Native Blink User-Agent + WICG Client Hints override
    const uaMetadata = fingerprint.buildUserAgentMetadata(fp);
    const acceptLang = Array.isArray(fp.languages) && fp.languages.length ? fp.languages.join(',') : 'vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7';
    await cdpClient.send('Emulation.setUserAgentOverride', {
      userAgent: fp.userAgent,
      acceptLanguage: acceptLang,
      platform: fp.platform || 'Win32',
      ...(uaMetadata ? { userAgentMetadata: uaMetadata } : {}),
    }, sessionId, 2500).catch(() => {});

    // Đồng bộ Network.setUserAgentOverride để HTTP Client Hints headers & CDP devtools protocol khớp 100%
    await cdpClient.send('Network.setUserAgentOverride', {
      userAgent: fp.userAgent,
      acceptLanguage: acceptLang,
      platform: fp.platform || 'Win32',
      ...(uaMetadata ? { userAgentMetadata: uaMetadata } : {}),
    }, sessionId, 2500).catch(() => {});

    // 2. Timezone override
    if (fp.timezone) {
      await cdpClient.send('Emulation.setTimezoneOverride', { timezoneId: fp.timezone }, sessionId, 2500).catch(() => {});
    }

    // 3. Geolocation override
    if (fp.geolocation && Number.isFinite(fp.geolocation.latitude) && Number.isFinite(fp.geolocation.longitude)) {
      await cdpClient.send('Emulation.setGeolocationOverride', {
        latitude: fp.geolocation.latitude,
        longitude: fp.geolocation.longitude,
        accuracy: fp.geolocation.accuracy || 100,
      }, sessionId, 2500).catch(() => {});
    }

    // 4. Mobile touch & device metrics when profile OS is Android/iOS
    if (fp.os === 'android' || fp.os === 'ios') {
      await cdpClient.send('Emulation.setTouchEmulationEnabled', {
        enabled: true,
        maxTouchPoints: fp.maxTouchPoints || 5,
      }, sessionId, 2500).catch(() => {});
      await cdpClient.send('Emulation.setDeviceMetricsOverride', {
        width: fp.screen?.width || 412,
        height: fp.screen?.height || 915,
        deviceScaleFactor: fp.screen?.devicePixelRatio || 3,
        mobile: true,
      }, sessionId, 2500).catch(() => {});
    }

    // 5. Register script for all future navigations & frames
    if (injectionScript) {
      await cdpClient.send('Page.addScriptToEvaluateOnNewDocument', { source: injectionScript }, sessionId, 2500).catch(() => {});
    }
  } catch {}
}

function writeFirefoxPrefs(userDataDir, proxyUrl, fp, profileName) {
  const lines = [];
  const P = (k, v) => lines.push(`user_pref(${JSON.stringify(k)}, ${JSON.stringify(v)});`);
  const langs = Array.isArray(fp?.languages) && fp.languages.length ? fp.languages : ['vi-VN', 'vi', 'en-US', 'en'];
  P('intl.accept_languages', langs.join(', '));
  P('browser.antidetect.customText', profileName || '');
  P('browser.startup.homepage_override.mstone', 'ignore');
  P('startup.homepage_welcome_url', '');
  P('browser.aboutwelcome.enabled', false);
  P('browser.shell.checkDefaultBrowser', false);
  P('browser.sessionstore.resume_from_crash', false);
  P('toolkit.telemetry.enabled', false);
  P('datareporting.healthreport.uploadEnabled', false);
  P('app.update.enabled', false);
  P('taskbar.grouping.useprofile', true);
  if (fp?.userAgent) P('general.useragent.override', fp.userAgent);

  if (proxyUrl) {
    const pm = String(proxyUrl).trim().match(/^(?:(\w+):\/\/)?([^:/]+):(\d+)$/);
    if (pm) {
      const scheme = (pm[1] || 'http').toLowerCase();
      const host = pm[2];
      const port = parseInt(pm[3], 10);
      P('network.proxy.type', 1);
      if (scheme.startsWith('socks')) {
        P('network.proxy.socks', host);
        P('network.proxy.socks_port', port);
        P('network.proxy.socks_version', scheme === 'socks4' ? 4 : 5);
        P('network.proxy.socks_remote_dns', true);
      } else {
        P('network.proxy.http', host);
        P('network.proxy.http_port', port);
        P('network.proxy.ssl', host);
        P('network.proxy.ssl_port', port);
        P('network.proxy.share_proxy_settings', true);
      }
      P('network.proxy.no_proxies_on', 'localhost, 127.0.0.1');
      P('network.proxy.failover_direct', false);
    }
  } else {
    P('network.proxy.type', 0);
  }

  if (fp?.webrtc?.mode === 'disabled') {
    P('media.peerconnection.enabled', false);
  } else {
    P('media.peerconnection.ice.no_host', true);
    P('media.peerconnection.ice.obfuscate_host_addresses', true);
  }

  fs.mkdirSync(userDataDir, { recursive: true });
  fs.writeFileSync(path.join(userDataDir, 'user.js'), lines.join('\n') + '\n', 'utf8');
}

/**
 * Launch a profile with Worker Pool prep, Cloud Restore, Proxy Guard, Auto-GeoIP,
 * Dual-Mode Fingerprint Spoofing (Native --fp-config OR CDP Stealth), and Session Tab Persistence.
 */
async function startProfile(profileId, overrides = {}) {
  const profile = db.getProfile(profileId);
  if (!profile) {
    throw new Error(`Profile ${profileId} not found in database`);
  }
  if (profile.deleted_at) {
    throw new Error(`Hồ sơ "${profile.name}" đang nằm trong Thùng rác. Hãy khôi phục trước khi mở.`);
  }
  if (_closing.has(profileId)) {
    throw new Error(`Hồ sơ "${profile.name}" đang lưu dữ liệu đóng phiên. Vui lòng chờ 1-2 giây.`);
  }

  if (_running.has(profileId)) {
    const existing = _running.get(profileId);
    if (cdp.isPidAlive(existing.pid)) {
      return {
        alreadyRunning: true,
        profileId,
        pid: existing.pid,
        port: existing.port,
        debugPort: existing.port,
        wsEndpoint: existing.wsEndpoint,
        slot: existing.slot,
      };
    }
    _running.delete(profileId);
    releaseSlot(profileId);
  }

  if (_launchPending.has(profileId)) {
    throw new Error(`Hồ sơ "${profile.name}" đang khởi động...`);
  }
  _launchPending.add(profileId);

  try {
    // 1. Resolve Kernel (supports multi-kernel Chromium & Firefox)
    const engine = String(overrides.engine || profile.engine || 'chromium').toLowerCase();
    const kernelDesc = kernelManager.resolveKernelForProfile({
      engine,
      kernelMajor: overrides.kernelMajor || profile.kernel_major || null,
      kernelPath: overrides.kernel_path || profile.kernel_path || null,
    });
    if (!kernelDesc || !fs.existsSync(kernelDesc.exe)) {
      throw new Error(`Không tìm thấy nhân trình duyệt (${engine}). Vui lòng tải nhân trong mục Quản lý Nhân.`);
    }
    const kernelPath = kernelDesc.exe;

    // 2. Cloud Sync Restore before opening (if enabled)
    const cs = getCloudSync();
    if (cs && typeof cs.beforeOpen === 'function') {
      try { await cs.beforeOpen(profileId); } catch (e) {
        console.warn(`[CloudSync] beforeOpen warning for ${profileId}:`, e.message);
      }
    }

    // 3. Auto-rotate proxy if enabled
    if (profile.auto_rotate_proxy && profile.proxy_id) {
      const proxyRecord = db.getProxy(profile.proxy_id);
      if (proxyRecord && proxyRecord.rotation_api_url) {
        try { await proxy.triggerProxyRotation(proxyRecord); } catch (rotErr) {
          console.warn(`[Launcher] Auto-rotate proxy warning: ${rotErr.message}`);
        }
      }
    }

    // 4. Pre-launch Proxy Guard
    const hasProxy = Boolean(profile.proxy_host && profile.proxy_port);
    const proxyCfg = hasProxy ? {
      type: profile.proxy_type || 'http',
      host: profile.proxy_host,
      port: profile.proxy_port,
      username: profile.proxy_user || '',
      password: profile.proxy_pass || '',
    } : null;

    const isGuardEnabled = (profile.proxy_guard !== 0) && !overrides.bypass_proxy_guard;
    let guardInfo = null;
    if (isGuardEnabled && proxyCfg) {
      guardInfo = await proxy.checkProxy(proxyCfg, 4500);
      if (!guardInfo.live) {
        const errMsg = `Proxy (${proxyCfg.host}:${proxyCfg.port}) mất kết nối (${guardInfo.error || 'Timeout'}). Đã chặn mở để bảo vệ tài khoản.`;
        const err = new Error(errMsg);
        err.code = 'PROXY_GUARD_FAILED';
        err.proxyHost = proxyCfg.host;
        err.proxyPort = proxyCfg.port;
        err.proxyError = guardInfo.error || 'Connection Timeout';
        err.proxyId = profile.proxy_id;
        err.profileId = profile.id;
        err.profileName = profile.name;
        throw err;
      }
    }

    // 5. Start Local Proxy Forwarder (handles HTTP/SOCKS5 auth seamlessly for any engine)
    let proxyForwarder = null;
    let proxyUrl = overrides.proxy_url || null;
    if (!proxyUrl && proxyCfg) {
      if (proxyCfg.username || proxyCfg.type.toLowerCase() === 'socks5') {
        try {
          proxyForwarder = await proxy.createLocalProxyForwarder(proxyCfg);
          proxyUrl = proxyForwarder.url;
        } catch {
          proxyUrl = buildProxyUrl(profile);
        }
      } else {
        proxyUrl = buildProxyUrl(profile);
      }
    }

    // 6. Resolve Fingerprint & Auto-Match GeoIP when proxy is present
    let fp = null;
    if (profile.fingerprint) {
      try {
        fp = typeof profile.fingerprint === 'string' ? JSON.parse(profile.fingerprint) : profile.fingerprint;
      } catch { fp = null; }
    }
    if (!fp) {
      fp = fingerprint.generateFingerprint({
        os: profile.os || 'windows',
        engine,
        kernelMajor: kernelDesc.major,
        chromeVersion: kernelDesc.version,
        cpu: profile.cpu_cores,
        memory: profile.ram_gb,
        resolution: { width: profile.screen_width, height: profile.screen_height },
        userAgent: profile.user_agent,
        canvasMode: profile.canvas_noise === 0 ? 'real' : 'noise',
        audioMode: profile.audio_noise === 0 ? 'real' : 'noise',
        webrtcMode: profile.webrtc_mode,
      });
      try { db.updateProfile(profileId, { fingerprint: fp }); } catch {}
    }

    // Chuẩn hóa fingerprint (hỗ trợ cả dạng phẳng và dạng lồng nhau Poly UI { meta, fpConfig, ui })
    fp = fingerprint.normalizeFingerprint(fp, profile);

    // Synchronize outdated default Chrome/130 UA with actual installed Chromium major when unpinned
    if (engine === 'chromium' && kernelDesc.version && fp.chromeVersion === '130.0.6723.117' && kernelDesc.major !== 130) {
      fp.chromeVersion = kernelDesc.version;
      fp.chromeMajor = kernelDesc.major;
      if (fp.clientHints) fp.clientHints.fullVersion = kernelDesc.version;
      if (fp.userAgent && fp.userAgent.includes('Chrome/130.0.6723.117')) {
        fp.userAgent = fp.userAgent.replace('Chrome/130.0.6723.117', `Chrome/${kernelDesc.major}.0.0.0`);
        fp.appVersion = fp.userAgent.replace(/^Mozilla\//, '');
      }
    }

    let geoResult = null;
    if (proxyCfg && !overrides.skipGeoIp) {
      try {
        geoResult = await geoIp.resolveGeoIp(proxyCfg, {
          existingForwarderUrl: proxyForwarder ? proxyForwarder.url : null,
          timeoutMs: 3500,
        });
        if (geoResult) {
          fp = JSON.parse(JSON.stringify(fp));
          if (geoResult.timezone) fp.timezone = geoResult.timezone;
          if (geoResult.languages) fp.languages = geoResult.languages;
          fp.webrtc = fp.webrtc || {};
          fp.webrtc.publicIp = geoResult.ip;
          if (!fp.geolocation || fp.geolocation.mode === 'auto') {
            fp.geolocation = {
              mode: 'fake',
              latitude: geoResult.latitude,
              longitude: geoResult.longitude,
              accuracy: 100,
            };
          }
        }
      } catch {}
    }

    // 7. UserDataDir & Downgrade Quarantine
    const subFolder = engine === 'firefox' ? 'firefox' : 'chrome';
    const userDataDir = path.join(PROFILES_DIR, profileId, subFolder);
    fs.mkdirSync(userDataDir, { recursive: true });

    if (engine === 'chromium') {
      const dgErr = launchPrep.prepareForKernel(userDataDir, kernelDesc.major);
      if (dgErr) throw new Error(dgErr);
    }

    // Prepare Cross-Machine Portable Cookies (handles foreign Windows DPAPI Local State seamlessly)
    const crossMachineCookies = cookieSqlite.prepareCrossMachineCookies(userDataDir, {
      isPolyPatched: kernelDesc.isPolyPatched,
      engine,
    });

    let uiCfg = {};
    try { uiCfg = typeof profile.ui_config === 'string' ? JSON.parse(profile.ui_config || '{}') : (profile.ui_config || {}); } catch {}
    const polyFpConfig = kernelDesc.isPolyPatched ? fingerprint.buildPolyFpConfig(fp, profile.name, proxyCfg) : null;

    // 8. Off-thread Worker Pool Preparation (Preferences + SNSS Open Tabs + --fp-config encryption)
    let prepInfo;
    if (engine === 'chromium') {
      try {
        prepInfo = await prepPool.prep({ userDataDir, ui: uiCfg, fpConfig: polyFpConfig });
      } catch {
        prepInfo = launchPrep.prep({ userDataDir, ui: uiCfg, fpConfig: polyFpConfig });
      }
    } else {
      const firstLaunch = !fs.existsSync(path.join(userDataDir, 'prefs.js'));
      const fpArg = polyFpConfig ? launchPrep.buildFpBlob(polyFpConfig) : null;
      writeFirefoxPrefs(userDataDir, proxyUrl, fp, profile.name);
      prepInfo = { firstLaunch, restoredUrls: [], fpArg };
    }

    // Clean stale lock files before spawning
    const staleFiles = ['DevToolsActivePort', 'lockfile', 'SingletonLock', 'SingletonCookie', 'SingletonSocket', 'parent.lock'];
    for (const f of staleFiles) {
      try {
        const p = path.join(userDataDir, f);
        if (fs.existsSync(p)) fs.unlinkSync(p);
      } catch {}
    }

    const slot = assignSlot(profileId);
    const rawStartUrl = (overrides.start_url !== undefined ? overrides.start_url : profile.start_url) || '';
    const startUrl = rawStartUrl.trim().replace(/^http:\/\/iphey\.com/i, 'https://iphey.com');

    // 9. Assemble CLI Arguments
    const args = [];
    if (engine === 'firefox') {
      args.push('-profile', userDataDir, '-no-remote', '--allow-downgrade');
      if (prepInfo.fpArg) args.push(`--fp-config=${prepInfo.fpArg}`);
      args.push('--remote-debugging-port=0');
      if (!overrides.blank && prepInfo.firstLaunch && startUrl) args.push(startUrl);
    } else {
      args.push(
        `--user-data-dir=${userDataDir}`,
        '--no-sandbox',
        '--test-type',
        '--no-first-run',
        '--no-default-browser-check',
        '--disable-blink-features=AutomationControlled',
        '--disable-background-mode',
        '--remote-debugging-port=0',
        '--remote-debugging-address=127.0.0.1',
        '--disable-session-crashed-bubble',
        '--disable-breakpad',
        '--disable-crash-reporter',
        '--noerrdialogs',
        '--disable-background-networking',
        '--disable-component-update',
        '--disable-domain-reliability',
        '--disable-sync',
        '--disable-client-side-phishing-detection',
        '--no-pings',
        '--force-color-profile=srgb',
        '--password-store=basic',
        '--disable-gpu-watchdog',
        '--disk-cache-size=104857600',
        `--app-user-model-id=CGTLogin.Profile.${String(profileId).replace(/[^A-Za-z0-9]/g, '')}`
      );

      const disabledFeatures = new Set([
        'MediaRouter',
        'CalculateNativeWinOcclusion',
        'DirectCompositionVideoOverlays',
        'FlashDeprecationWarning',
        'EnablePasswordsAccountStorage',
      ]);

      if (kernelDesc.isPolyPatched && prepInfo.fpArg) {
        args.push(`--fp-config=${prepInfo.fpArg}`);
        args.push('--mirror-mode');
        args.push('--origin-trial-disabled-features=CanvasTextNg|WebAssemblyCustomDescriptors');
      }

      if (fp.webrtc?.mode !== 'real') {
        args.push('--webrtc-ip-handling-policy=disable_non_proxied_udp');
        args.push('--enforce-webrtc-ip-permission-check');
      }

      if (fp.languages && fp.languages[0]) {
        args.push(`--lang=${fp.languages[0]}`);
      }

      // Window Bounds / Scale
      const bounds = overrides.bounds;
      if (bounds && Number.isFinite(bounds.width) && Number.isFinite(bounds.height)) {
        args.push(`--window-position=${Math.round(bounds.x || 0)},${Math.round(bounds.y || 0)}`);
        args.push(`--window-size=${Math.round(bounds.width)},${Math.round(bounds.height)}`);
      } else {
        const width = overrides.screen_width || (fp.screen ? fp.screen.width : 1280);
        const height = overrides.screen_height || (fp.screen ? fp.screen.height : 800);
        args.push(`--window-size=${width},${height}`);
        if (overrides.window_x !== undefined && overrides.window_y !== undefined) {
          args.push(`--window-position=${overrides.window_x},${overrides.window_y}`);
        }
      }

      if (overrides.scale && Number(overrides.scale) > 0 && Number(overrides.scale) !== 1) {
        args.push(`--force-device-scale-factor=${Number(overrides.scale)}`);
        args.push('--high-dpi-support=1');
      }

      if (proxyUrl) {
        args.push(`--proxy-server=${proxyUrl}`);
      }

      const ua = overrides.user_agent || fp.userAgent || profile.user_agent;
      if (ua && ua.trim()) {
        args.push(`--user-agent=${ua.trim()}`);
      }

      // Cấu hình RAM phần cứng (Device Memory) cho nhân Chromium C++
      const memory = fp.deviceMemory || fp.memory || profile.memory || 8;
      if (memory) {
        args.push(`--device-memory=${memory}`);
        args.push(`--force-device-memory=${memory}`);
      }

      const customFlags = overrides.custom_flags || profile.custom_flags;
      if (customFlags && customFlags.trim()) {
        for (const tok of customFlags.trim().split(/\s+/).filter(Boolean)) {
          if (tok.startsWith('--disable-features=')) {
            tok.slice('--disable-features='.length).split(',').forEach((f) => { if (f) disabledFeatures.add(f); });
          } else {
            args.push(tok);
          }
        }
      }

      args.push(`--disable-features=${[...disabledFeatures].join(',')}`);

      // Extensions (Title tagger + user extensions)
      try {
        const titleExtDir = ensureProfileTitleExtension(userDataDir, profile.name, slot);
        const userExtPaths = db.getActiveExtensionPathsForProfile(profileId) || [];
        const allExts = [titleExtDir, ...userExtPaths];
        const joinedExts = allExts.join(',');
        args.push(`--load-extension=${joinedExts}`);
        args.push(`--disable-extensions-except=${joinedExts}`);
      } catch (err) {
        console.warn('[Launcher] Extension load warning:', err.message);
      }

      // Smart Session Tab Restore & Clean Startup (Mở trực tiếp Google New Tab hoặc startUrl, loại bỏ hoàn toàn start.html)
      if (overrides.blank || startUrl === 'about:blank') {
        args.push('about:blank');
      } else if (!prepInfo.firstLaunch && prepInfo.restoredUrls && prepInfo.restoredUrls.length > 0) {
        args.push('--restore-last-session');
      } else if (startUrl && startUrl !== 'about:blank' && !startUrl.startsWith('data:') && startUrl !== 'chrome://newtab') {
        args.push(startUrl);
      } else {
        args.push('chrome://newtab');
      }

      // Dọn dẹp tệp start.html cũ nếu có từ các phiên trước
      const splashPath = path.join(userDataDir, 'start.html');
      if (fs.existsSync(splashPath)) {
        try { fs.rmSync(splashPath, { force: true }); } catch {}
      }
    }

    // 10. Spawn Process
    let child = null;
    let pid = null;
    const spawnDesktopExe = path.join(BASE_DIR, 'bin', 'spawn-desktop.exe');

    if (process.platform === 'win32' && engine === 'chromium' && fs.existsSync(spawnDesktopExe)) {
      try {
        const out = execFileSync(spawnDesktopExe, [kernelPath, ...args], { encoding: 'utf8', windowsHide: true }).trim();
        const parsedPid = parseInt(out, 10);
        if (parsedPid && !Number.isNaN(parsedPid)) {
          pid = parsedPid;
        }
      } catch {}
    }

    if (!pid) {
      child = spawn(kernelPath, args, {
        cwd: path.dirname(kernelPath),
        detached: true,
        windowsHide: false,
        stdio: 'ignore',
      });
      child.unref();
      pid = child.pid;
    }

    if (!pid) {
      releaseSlot(profileId);
      throw new Error('Failed to spawn browser process');
    }

    let exitHandled = false;
    const handleProcessExit = (code = 0, signal = null) => {
      if (exitHandled) return;
      exitHandled = true;
      const current = _running.get(profileId);
      if (current) {
        if (current.cdpClient) {
          try { current.cdpClient.close(); } catch {}
        }
        if (current.proxyForwarder) {
          try { current.proxyForwarder.close(); } catch {}
        }
      }
      _running.delete(profileId);
      releaseSlot(profileId);
      if (!_closing.has(profileId)) {
        // Closed manually by user -> run Cloud Sync afterClose in background
        const syncMod = getCloudSync();
        if (syncMod && typeof syncMod.afterClose === 'function') {
          syncMod.afterClose(profileId).catch(() => {});
        }
      }
      broadcastState();
      events.emit('profile-exited', { profileId, pid, code, signal });
      events.emit('profile-stopped', { profileId, pid, graceful: true });
    };

    if (child) {
      child.on('exit', (code, signal) => handleProcessExit(code, signal));
    } else {
      const exitTimer = setInterval(() => {
        if (!cdp.isPidAlive(pid)) {
          clearInterval(exitTimer);
          handleProcessExit(0, null);
        }
      }, 900);
      if (exitTimer.unref) exitTimer.unref();
    }

    // 11. Connect Loopback CDP & Apply Stealth Fingerprint Overrides + Cookie Seed
    const ep = engine === 'chromium' ? await cdp.waitForDevToolsEndpoint(userDataDir, 10000) : null;
    const port = ep ? ep.port : null;
    const wsEndpoint = ep ? ep.wsEndpoint : null;

    let cdpClient = null;
    const pageSessions = new Map();

    if (wsEndpoint) {
      try {
        cdpClient = new cdp.CdpClient(wsEndpoint);
        await cdpClient.connect(3500);

        cdpClient.on('close', () => {
          if (!_closing.has(profileId) && !cdp.isPidAlive(pid)) {
            handleProcessExit(0, null);
          }
        });

        // Restore Portable Cross-Machine Cookies if synced from another Windows PC / User
        if (crossMachineCookies.needsRestore && crossMachineCookies.cookies.length > 0) {
          try {
            await cdpClient.send('Storage.setCookies', { cookies: crossMachineCookies.cookies }, null, 3500);
            cookieSqlite.markSidecarApplied(userDataDir);
          } catch (ckErr) {
            console.warn(`[Launcher] Cross-machine cookie restore warning for ${profileId}:`, ckErr.message);
          }
        }

        // Inject Cookie Seed if stored on profile
        if (profile.cookie_seed && String(profile.cookie_seed).trim()) {
          try {
            const cookieMod = require('./cookies');
            const parsedCookies = cookieMod.parseCookieInput(profile.cookie_seed);
            const validCdpCookies = parsedCookies.filter((c) => c.domain || c.url);
            if (validCdpCookies.length) {
              await cdpClient.send('Storage.setCookies', { cookies: validCdpCookies }, null, 2500).catch(() => {});
            }
          } catch {}
        }

        // Dynamic CDP Stealth Mode when kernel does not natively consume --fp-config
        if (!kernelDesc.isPolyPatched) {
          const injectionScript = fingerprint.getInjectionScript(fp);

          cdpClient.on('Target.attachedToTarget', (params) => {
            if (params && params.sessionId && params.targetInfo?.type === 'page') {
              pageSessions.set(params.targetInfo.targetId, params.sessionId);
              attachCdpStealthToSession(cdpClient, params.sessionId, fp, injectionScript).catch(() => {});
            }
          });

          cdpClient.on('Target.detachedFromTarget', (params) => {
            if (params?.targetId) pageSessions.delete(params.targetId);
          });

          await cdpClient.send('Target.setAutoAttach', {
            autoAttach: true,
            waitForDebuggerOnStart: false,
            flatten: true,
          }, null, 3000).catch(() => {});

          // Ensure all already-open page targets also receive overrides immediately
          const { targetInfos } = await cdpClient.send('Target.getTargets', {}, null, 2500).catch(() => ({ targetInfos: [] }));
          for (const t of (targetInfos || [])) {
            if (t.type === 'page' && !pageSessions.has(t.targetId)) {
              try {
                const { sessionId } = await cdpClient.send('Target.attachToTarget', { targetId: t.targetId, flatten: true }, null, 2500);
                if (sessionId) {
                  pageSessions.set(t.targetId, sessionId);
                  await attachCdpStealthToSession(cdpClient, sessionId, fp, injectionScript);
                }
              } catch {}
            } else if (t.type === 'page' && pageSessions.has(t.targetId)) {
              await attachCdpStealthToSession(cdpClient, pageSessions.get(t.targetId), fp, injectionScript);
            }
          }
        }
      } catch (err) {
        console.warn(`[Launcher] CDP attach warning for ${profileId}:`, err.message);
      }
    }

    const info = {
      profileId,
      pid,
      child,
      engine,
      userDataDir,
      port,
      debugPort: port,
      wsEndpoint,
      slot,
      cdpClient,
      pageSessions,
      proxyForwarder,
      fingerprint: fp,
      geo: geoResult || guardInfo || null,
      startedAt: new Date().toISOString(),
    };

    _running.set(profileId, info);
    db.updateProfileLastRun(profileId);
    broadcastState();
    events.emit('profile-started', info);

    return {
      success: true,
      profileId,
      pid,
      port,
      debugPort: port,
      wsEndpoint,
      slot,
      engine,
      cdpClient,
      pageSessions,
      fingerprint: fp,
      geo: info.geo,
      startedAt: info.startedAt,
    };
  } finally {
    _launchPending.delete(profileId);
  }
}

/**
 * Graceful Stop with `closingIds` ("Đang lưu") state:
 * Flushes Cookies/IndexedDB via CDP Browser.close -> reaps orphan child processes -> Cloud Sync afterClose.
 */
async function stopProfile(profileId, timeoutMs = 3500) {
  const info = _running.get(profileId);
  if (!info) {
    const userDataDir = path.join(PROFILES_DIR, profileId, 'chrome');
    await cdp.gracefulQuit(userDataDir, null, 1000).catch(() => {});
    return { success: true, message: 'Profile was not running', graceful: true };
  }

  _closing.add(profileId);
  broadcastState();

  let closedGracefully = false;
  try {
    // Snapshot live decrypted cookies into portable sidecar BEFORE closing (ensures 100% cross-PC session sync)
    if (info.cdpClient) {
      try {
        const ckRes = await info.cdpClient.send('Storage.getCookies', {}, null, 1800).catch(() => null);
        if (ckRes && Array.isArray(ckRes.cookies) && ckRes.cookies.length > 0) {
          cookieSqlite.writePortableSidecar(info.userDataDir, ckRes.cookies);
        }
      } catch {}
      try { info.cdpClient.close(); } catch {}
      info.cdpClient = null;
    }

    // Send Browser.close via fresh loopback connection and wait for Chromium to flush SQLite WAL
    closedGracefully = await cdp.gracefulQuit(info.userDataDir, info.pid, timeoutMs);

    if (info.proxyForwarder) {
      try { await info.proxyForwarder.close(); } catch {}
    }

    if (info.pid && cdp.isPidAlive(info.pid)) {
      forceKillPid(info.pid);
    }
    cleanupOrphansForProfile(profileId);

    const staleFiles = ['DevToolsActivePort', 'lockfile', 'SingletonLock', 'SingletonCookie', 'SingletonSocket', 'parent.lock'];
    for (const f of staleFiles) {
      try {
        const targetP = path.join(info.userDataDir, f);
        if (fs.existsSync(targetP)) fs.unlinkSync(targetP);
      } catch {}
    }

    _running.delete(profileId);
    releaseSlot(profileId);

    // Run Cloud Sync pack & upload AFTER cookies are flushed and file locks are released
    const cs = getCloudSync();
    if (cs && typeof cs.afterClose === 'function') {
      try { await cs.afterClose(profileId); } catch (e) {
        console.warn(`[CloudSync] afterClose warning for ${profileId}:`, e.message);
      }
    }
  } finally {
    _closing.delete(profileId);
    broadcastState();
  }

  events.emit('profile-stopped', { profileId, pid: info.pid, graceful: closedGracefully });

  return {
    success: true,
    profileId,
    pid: info.pid,
    graceful: closedGracefully,
  };
}

function cleanupOrphansForProfile(profileId) {
  if (process.platform !== 'win32' || !profileId) return;
  try {
    const script = `Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*${profileId}*' } | Stop-Process -Force`;
    const b64 = Buffer.from(script, 'utf16le').toString('base64');
    execSync(`powershell.exe -NoProfile -NonInteractive -EncodedCommand ${b64}`, { stdio: 'ignore', windowsHide: true });
  } catch {}
}

async function stopAllProfiles(timeoutMs = 2500) {
  const running = getRunningProfiles();
  const results = await Promise.all(running.map(async (p) => {
    try {
      const res = await stopProfile(p.profileId, timeoutMs);
      return { profileId: p.profileId, success: true, ...res };
    } catch (e) {
      return { profileId: p.profileId, success: false, error: e.message };
    }
  }));
  return { success: true, count: results.length, results };
}

function forceKillPid(pid) {
  if (!pid) return;
  try {
    execSync(`taskkill.exe /PID ${pid} /T /F`, { stdio: 'ignore', windowsHide: true });
  } catch {
    try { process.kill(pid); } catch {}
  }
}

function buildProxyUrl(profile) {
  if (!profile.proxy_host || !profile.proxy_port) return null;
  const type = profile.proxy_type || 'http';
  return `${type}://${profile.proxy_host}:${profile.proxy_port}`;
}

function getRunningProfiles() {
  const result = [];
  for (const [id, info] of [..._running.entries()]) {
    if (isProfileRunning(id)) {
      result.push({
        profileId: id,
        pid: info.pid,
        port: info.port,
        debugPort: info.port,
        wsEndpoint: info.wsEndpoint,
        slot: info.slot || null,
        engine: info.engine || 'chromium',
        startedAt: info.startedAt,
      });
    }
  }
  return result;
}

function getClosingProfileIds() {
  return [..._closing];
}

function isProfileClosing(profileId) {
  return _closing.has(profileId);
}

function isProfileRunning(profileId) {
  const info = _running.get(profileId);
  if (!info) return false;
  if (cdp.isPidAlive(info.pid)) return true;
  _running.delete(profileId);
  releaseSlot(profileId);
  return false;
}

function getRunningInfo(profileId) {
  const info = _running.get(profileId);
  if (!info || !cdp.isPidAlive(info.pid)) return null;
  return info;
}

function showProfileWindow(profileId, noActivate = false) {
  const info = getRunningInfo(profileId);
  if (!info || !info.pid) return false;
  return windowLayout.showWindowByPid(info.pid, noActivate);
}

function arrangeProfileWindows(profileIds = [], layout = 'grid', opts = {}) {
  const targetIds = Array.isArray(profileIds) && profileIds.length
    ? profileIds.filter((id) => isProfileRunning(id))
    : getRunningProfiles().map((p) => p.profileId);
  const pids = targetIds.map((id) => getRunningInfo(id)?.pid).filter(Boolean);
  return windowLayout.arrangeByPids(pids, layout, opts);
}

async function purgeProfileStorage(profileId) {
  if (isProfileRunning(profileId)) {
    await stopProfile(profileId, 2000).catch(() => {});
  }
  const profileDir = path.join(PROFILES_DIR, profileId);
  if (fs.existsSync(profileDir)) {
    try {
      fs.rmSync(profileDir, { recursive: true, force: true });
      return true;
    } catch {
      return false;
    }
  }
  return true;
}

module.exports = {
  startProfile,
  stopProfile,
  stopAllProfiles,
  cleanupOrphansForProfile,
  getRunningProfiles,
  getClosingProfileIds,
  isProfileClosing,
  isProfileRunning,
  getRunningInfo,
  getSlot,
  getStateSnapshot,
  showProfileWindow,
  arrangeProfileWindows,
  purgeProfileStorage,
  events,
};
