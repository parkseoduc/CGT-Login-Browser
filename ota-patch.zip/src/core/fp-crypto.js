'use strict';

const crypto = require('node:crypto');

const NONCE_LEN = 12;
const TAG_LEN = 16;

// Compatible default key when launching a patched Poly Browser binary, overridable via env or kernel config
const DEFAULT_POLY_FP_KEY = process.env.CGT_FP_CONFIG_KEY || '434804f3058d24a5f84133df693ad70f';

function deriveKey(keyString) {
  return crypto.createHash('sha256').update(Buffer.from(keyString || DEFAULT_POLY_FP_KEY, 'utf8')).digest();
}

/**
 * Encrypt per-profile fingerprint JSON into AES-256-GCM inline blob:
 * base64( nonce[12] || ciphertext || authTag[16] )
 */
function encryptConfig(jsonOrObj, keyString = DEFAULT_POLY_FP_KEY) {
  try {
    const jsonText = typeof jsonOrObj === 'string' ? jsonOrObj : JSON.stringify(jsonOrObj);
    const key = deriveKey(keyString);
    const nonce = crypto.randomBytes(NONCE_LEN);
    const cipher = crypto.createCipheriv('aes-256-gcm', key, nonce);
    const ct = Buffer.concat([cipher.update(Buffer.from(jsonText, 'utf8')), cipher.final()]);
    const tag = cipher.getAuthTag();
    return Buffer.concat([nonce, ct, tag]).toString('base64');
  } catch {
    return null;
  }
}

function decryptConfig(blobB64, keyString = DEFAULT_POLY_FP_KEY) {
  try {
    const buf = Buffer.from(String(blobB64 || ''), 'base64');
    if (buf.length < NONCE_LEN + TAG_LEN) return null;
    const key = deriveKey(keyString);
    const nonce = buf.subarray(0, NONCE_LEN);
    const tag = buf.subarray(buf.length - TAG_LEN);
    const ct = buf.subarray(NONCE_LEN, buf.length - TAG_LEN);
    const decipher = crypto.createDecipheriv('aes-256-gcm', key, nonce);
    decipher.setAuthTag(tag);
    const plain = Buffer.concat([decipher.update(ct), decipher.final()]).toString('utf8');
    return JSON.parse(plain);
  } catch {
    return null;
  }
}

module.exports = {
  NONCE_LEN,
  TAG_LEN,
  DEFAULT_POLY_FP_KEY,
  deriveKey,
  encryptConfig,
  decryptConfig,
};
