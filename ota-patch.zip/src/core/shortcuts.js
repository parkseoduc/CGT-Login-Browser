'use strict';

const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { execFileSync } = require('node:child_process');
const config = require('../config');

const ARG_PREFIX = '--open-profile=';
const BAD_CHARS = /[\\/:*?"<>|\u0000-\u001f]/g;

function parseOpenProfile(argv) {
  const list = Array.isArray(argv) ? argv : [];
  for (const raw of list) {
    const s = String(raw || '');
    if (s.startsWith(ARG_PREFIX)) {
      const id = s.slice(ARG_PREFIX.length).replace(/^"|"$/g, '').trim();
      if (id) return id;
    }
  }
  return '';
}

function defaultDesktopDir() {
  try {
    const electron = require('electron');
    if (electron && electron.app && typeof electron.app.getPath === 'function') {
      return electron.app.getPath('desktop');
    }
  } catch {}
  return path.join(os.homedir(), 'Desktop');
}

function safeBase(name) {
  let s = String(name || '').replace(BAD_CHARS, ' ').replace(/\s+/g, ' ').trim();
  s = s.replace(/[. ]+$/, '');
  if (/^(con|prn|aux|nul|com[1-9]|lpt[1-9])$/i.test(s)) s = '_' + s;
  if (s.length > 120) s = s.slice(0, 120).trim();
  return s;
}

function uniqueLnkPath(dir, base, used) {
  let file = path.join(dir, `${base}.lnk`);
  if (!used.has(file.toLowerCase()) && !fs.existsSync(file)) {
    used.add(file.toLowerCase());
    return file;
  }
  for (let n = 2; n <= 9999; n++) {
    file = path.join(dir, `${base} (${n}).lnk`);
    if (!used.has(file.toLowerCase()) && !fs.existsSync(file)) {
      used.add(file.toLowerCase());
      return file;
    }
  }
  used.add(file.toLowerCase());
  return file;
}

function createShortcuts({ profiles = [], dir = '', pattern = '{name}' } = {}) {
  if (process.platform !== 'win32') return { ok: false, error: 'Chỉ hỗ trợ tạo lối tắt .lnk trên Windows' };
  const outDir = dir && String(dir).trim() ? String(dir).trim() : defaultDesktopDir();
  fs.mkdirSync(outDir, { recursive: true });

  const iconIco = path.join(config.BASE_DIR, 'app.ico');
  const iconLocation = fs.existsSync(iconIco) ? iconIco : process.execPath;

  // Target launcher: prefer CGTBrowser.exe / OmniBrowser.exe / start-desktop.bat or Electron execPath
  let targetExe = process.execPath;
  let baseArgs = '';
  try {
    const electron = require('electron');
    if (electron && electron.app) {
      targetExe = process.execPath;
      baseArgs = electron.app.isPackaged ? '' : `"${path.join(config.BASE_DIR, 'desktop', 'main.js')}" `;
    } else {
      throw new Error('not electron');
    }
  } catch {
    const cgtExe = path.join(config.BASE_DIR, 'CGTBrowser.exe');
    const startBat = path.join(config.BASE_DIR, 'start-desktop.bat');
    if (fs.existsSync(cgtExe)) {
      targetExe = cgtExe;
      baseArgs = '';
    } else if (fs.existsSync(startBat)) {
      targetExe = 'cmd.exe';
      baseArgs = `/c "${startBat}" `;
    }
  }

  const used = new Set();
  const items = [];
  let created = 0;
  let failed = 0;

  profiles.forEach((p, idx) => {
    const id = p && p.id ? String(p.id) : '';
    if (!id) { failed++; return; }
    const rawName = String(pattern || '{name}')
      .replace(/\{name\}/g, String(p.name || id))
      .replace(/\{id\}/g, id)
      .replace(/\{index\}/g, String(idx + 1));
    const base = safeBase(rawName) || `CGT-Profile-${id.slice(0, 8)}`;
    const lnkFile = uniqueLnkPath(outDir, base, used);
    const fullArgs = `${baseArgs}${ARG_PREFIX}${id}`;

    try {
      let wroteViaElectron = false;
      try {
        const electron = require('electron');
        if (electron && electron.shell && typeof electron.shell.writeShortcutLink === 'function') {
          wroteViaElectron = electron.shell.writeShortcutLink(lnkFile, 'create', {
            target: targetExe,
            args: fullArgs,
            description: `Mở hồ sơ ${p.name || id} bằng CGT-Login`,
            icon: iconLocation,
            iconIndex: 0,
          });
        }
      } catch {}

      if (!wroteViaElectron) {
        const ps = `
$ws = New-Object -ComObject WScript.Shell
$sc = $ws.CreateShortcut(${JSON.stringify(lnkFile)})
$sc.TargetPath = ${JSON.stringify(targetExe)}
$sc.Arguments = ${JSON.stringify(fullArgs)}
$sc.WorkingDirectory = ${JSON.stringify(config.BASE_DIR)}
$sc.IconLocation = ${JSON.stringify(iconLocation + ',0')}
$sc.Description = ${JSON.stringify(`Mở hồ sơ ${p.name || id} bằng CGT-Login`)}
$sc.Save()
`;
        execFileSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', ps], { windowsHide: true });
      }
      created++;
      items.push({ id, path: lnkFile, status: 'created' });
    } catch (err) {
      failed++;
      items.push({ id, path: lnkFile, status: 'failed', error: err.message });
    }
  });

  return { ok: created > 0, dir: outDir, created, failed, items };
}

module.exports = {
  ARG_PREFIX,
  parseOpenProfile,
  defaultDesktopDir,
  createShortcuts,
};
