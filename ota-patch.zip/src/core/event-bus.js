'use strict';

const { EventEmitter } = require('node:events');

/**
 * Central Event Bus & Server-Sent Events (SSE) Broadcaster for CGT-Login v2.0.
 * Allows any backend module (launcher, synchronizer, rpa, cloud-sync, kernel-manager)
 * to broadcast live state updates to connected Frontend UI clients with 0ms polling delay.
 */
class CoreEventBus extends EventEmitter {
  constructor() {
    super();
    this.setMaxListeners(100);
    /** @type {Set<import('node:http').ServerResponse>} */
    this.sseClients = new Set();
    this.lastSnapshots = new Map();
  }

  /**
   * Broadcast a named event to internal listeners AND all connected SSE clients.
   * @param {string} eventName - e.g. 'profile:state', 'sync:status', 'rpa:log', 'cloud:progress', 'kernel:progress'
   * @param {object} payload - JSON-serializable object
   * @param {object} [opts] - { cacheSnapshot?: boolean }
   */
  publish(eventName, payload, opts = {}) {
    const data = payload === undefined ? {} : payload;
    if (opts.cacheSnapshot) {
      this.lastSnapshots.set(eventName, data);
    }
    try {
      this.emit(eventName, data);
    } catch { /* ignore listener errors */ }

    if (this.sseClients.size === 0) return;

    let serialized;
    try {
      serialized = `event: ${eventName}\ndata: ${JSON.stringify(data)}\n\n`;
    } catch {
      return;
    }

    for (const res of [...this.sseClients]) {
      try {
        if (res.writableEnded || res.destroyed) {
          this.sseClients.delete(res);
          continue;
        }
        res.write(serialized);
      } catch {
        this.sseClients.delete(res);
      }
    }
  }

  /**
   * Attach an HTTP response as a Server-Sent Events (SSE) stream (`GET /api/v1/events/stream`).
   * Immediately sends cached snapshots (`profile:state`, `sync:status`, etc.) upon connect.
   */
  attachSse(req, res, extraHeaders = {}) {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
      'X-Accel-Buffering': 'no',
      ...extraHeaders,
    });

    res.write(`: connected ${new Date().toISOString()}\n\n`);

    // Replay latest state snapshots immediately so UI initializes cleanly
    for (const [eventName, snapshot] of this.lastSnapshots.entries()) {
      try {
        res.write(`event: ${eventName}\ndata: ${JSON.stringify(snapshot)}\n\n`);
      } catch {}
    }

    this.sseClients.add(res);

    const heartbeat = setInterval(() => {
      if (res.writableEnded || res.destroyed) {
        clearInterval(heartbeat);
        this.sseClients.delete(res);
        return;
      }
      try {
        res.write(': ping\n\n');
      } catch {
        clearInterval(heartbeat);
        this.sseClients.delete(res);
      }
    }, 20000);
    if (heartbeat.unref) heartbeat.unref();

    const cleanup = () => {
      clearInterval(heartbeat);
      this.sseClients.delete(res);
    };

    req.on('close', cleanup);
    req.on('error', cleanup);
    res.on('close', cleanup);
  }
}

const eventBus = new CoreEventBus();
module.exports = eventBus;
