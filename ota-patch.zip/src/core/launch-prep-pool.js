'use strict';

const path = require('node:path');
const os = require('node:os');

let Worker = null;
try { ({ Worker } = require('node:worker_threads')); } catch { Worker = null; }

const WORKER_FILE = path.join(__dirname, 'launch-prep-worker.js');
const MAX_WORKERS = Math.max(1, Math.min(4, ((os.cpus() || []).length) || 1));
const FAIL_LIMIT = MAX_WORKERS * 2 + 1;

let _workers = [];
const _pending = new Map();
let _seq = 0;
let _failCount = 0;
let _disabled = false;

function _retireEntry(entry, err) {
  for (const id of entry.inflight) {
    const p = _pending.get(id);
    if (p) {
      _pending.delete(id);
      try { p.reject(err || new Error('prep worker gone')); } catch {}
    }
  }
  entry.inflight.clear();
  _workers = _workers.filter((e) => e !== entry);
  _failCount += 1;
  if (_failCount >= FAIL_LIMIT) _disabled = true;
  try { entry.worker.terminate(); } catch {}
}

function ensureWorkers() {
  if (!Worker || _disabled) return null;
  while (_workers.length < MAX_WORKERS) {
    let w;
    try {
      w = new Worker(WORKER_FILE);
      if (w.unref) w.unref();
    } catch {
      _disabled = true;
      return _workers.length ? _workers : null;
    }
    const entry = { worker: w, inflight: new Set() };
    w.on('message', (msg) => {
      if (!msg || msg.id == null) return;
      const p = _pending.get(msg.id);
      if (!p) return;
      _pending.delete(msg.id);
      entry.inflight.delete(msg.id);
      if (msg.ok) p.resolve({ firstLaunch: msg.firstLaunch, restoredUrls: msg.restoredUrls, fpArg: msg.fpArg });
      else p.reject(new Error(msg.error || 'prep failed'));
    });
    w.on('error', (e) => _retireEntry(entry, e));
    w.on('exit', (code) => {
      if (code !== 0) _retireEntry(entry, new Error('prep worker exited: ' + code));
    });
    _workers.push(entry);
  }
  return _workers.length ? _workers : null;
}

function prep(job) {
  const pool = ensureWorkers();
  if (!pool || !pool.length) return Promise.reject(new Error('prep pool unavailable'));
  const entry = pool.reduce((a, b) => (b.inflight.size < a.inflight.size ? b : a));
  const id = ++_seq;
  return new Promise((resolve, reject) => {
    _pending.set(id, { resolve, reject });
    entry.inflight.add(id);
    try {
      entry.worker.postMessage({
        id,
        type: 'prep',
        userDataDir: job.userDataDir,
        ui: job.ui,
        fpConfig: job.fpConfig,
        keyString: job.keyString,
      });
    } catch (e) {
      _pending.delete(id);
      entry.inflight.delete(id);
      reject(e);
    }
  });
}

function dispose() {
  _disabled = true;
  for (const entry of _workers.splice(0)) {
    try { entry.worker.terminate(); } catch {}
  }
  for (const [, p] of _pending) {
    try { p.reject(new Error('prep pool disposed')); } catch {}
  }
  _pending.clear();
}

module.exports = { prep, dispose };
