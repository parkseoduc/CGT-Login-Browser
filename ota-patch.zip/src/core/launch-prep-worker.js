'use strict';

const { parentPort } = require('node:worker_threads');
const launchPrep = require('./launch-prep');

if (parentPort) {
  parentPort.on('message', (msg) => {
    if (!msg || msg.type !== 'prep') return;
    try {
      const res = launchPrep.prep({
        userDataDir: msg.userDataDir,
        ui: msg.ui,
        fpConfig: msg.fpConfig,
        keyString: msg.keyString,
      });
      parentPort.postMessage({ id: msg.id, ok: true, ...res });
    } catch (err) {
      parentPort.postMessage({ id: msg.id, ok: false, error: err && err.message ? err.message : String(err) });
    }
  });
}
