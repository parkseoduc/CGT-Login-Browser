'use strict';

const fs = require('node:fs');
const path = require('node:path');
const sessionReader = require('./session-reader');
const fpCrypto = require('./fp-crypto');

const DOWNGRADE_QUARANTINE = ['Sync Data'];
const BAK_SUFFIX = '.cgt-bak';

function majorOf(v) {
  const n = parseInt(String(v || '').trim().split('.')[0], 10);
  return Number.isFinite(n) ? n : 0;
}

function lastRunMajor(userDataDir) {
  try {
    return majorOf(fs.readFileSync(path.join(userDataDir, 'Last Version'), 'utf8'));
  } catch {
    return 0;
  }
}

/**
 * Prevent Chromium STATUS_BREAKPOINT (0x80000003) crash when downgrading a profile's kernel
 * (e.g. from Chromium 153 -> 140) by quarantining Default/Sync Data while preserving 100% cookies & storage.
 */
function prepareForKernel(userDataDir, kernelMajor) {
  const now = majorOf(kernelMajor);
  if (!now) return null;
  const last = lastRunMajor(userDataDir);
  if (!last || last <= now) return null;

  for (const name of DOWNGRADE_QUARANTINE) {
    const live = path.join(userDataDir, 'Default', name);
    if (!fs.existsSync(live)) continue;
    const bak = live + BAK_SUFFIX;
    try {
      fs.rmSync(bak, { recursive: true, force: true });
      fs.renameSync(live, bak);
    } catch (e) {
      return `Không thể hạ nhân về bản ${now} khi hồ sơ đang giữ dữ liệu bản ${last} (${e.message || e}). Hãy đóng hẳn hồ sơ rồi thử lại.`;
    }
  }
  return null;
}

/**
 * Patch Default/Preferences to prevent "Restore pages?" crash bubble, apply Do Not Track,
 * and configure Mobile DevTools device toolbar if profile OS is Android/iOS.
 */
function prepareSessionPrefs(userDataDir, ui, fpConfig) {
  const prefsPath = path.join(userDataDir, 'Default', 'Preferences');
  const firstLaunch = !fs.existsSync(prefsPath);
  try {
    let prefs = {};
    if (!firstLaunch) {
      try {
        prefs = JSON.parse(fs.readFileSync(prefsPath, 'utf8')) || {};
      } catch {
        prefs = {};
      }
    }
    prefs.profile = prefs.profile || {};
    prefs.profile.exit_type = 'Normal';
    prefs.profile.exited_cleanly = true;

    // Suppress password save prompt
    prefs.credentials_enable_service = false;
    prefs.profile.password_manager_enabled = false;

    if (ui && (ui.doNotTrack === true || ui.doNotTrack === '1' || ui.doNotTrack === 'Mở')) {
      prefs.enable_do_not_track = true;
    } else if (ui && (ui.doNotTrack === false || ui.doNotTrack === '0' || ui.doNotTrack === 'Đóng')) {
      prefs.enable_do_not_track = false;
    }

    fs.mkdirSync(path.dirname(prefsPath), { recursive: true });
    fs.writeFileSync(prefsPath, JSON.stringify(prefs), 'utf8');
  } catch { /* ignore */ }
  return firstLaunch;
}

function buildFpBlob(fpConfig, keyString) {
  if (!fpConfig || typeof fpConfig !== 'object' || !Object.keys(fpConfig).length) return null;
  return fpCrypto.encryptConfig(fpConfig, keyString || fpCrypto.DEFAULT_POLY_FP_KEY);
}

function prep({ userDataDir, ui, fpConfig, keyString }) {
  try { fs.mkdirSync(userDataDir, { recursive: true }); } catch {}
  const firstLaunch = prepareSessionPrefs(userDataDir, ui, fpConfig);
  const restoredUrls = sessionReader.readOpenTabUrls(userDataDir);
  const fpArg = buildFpBlob(fpConfig, keyString);
  return { firstLaunch, restoredUrls, fpArg };
}

module.exports = {
  prep,
  prepareSessionPrefs,
  prepareForKernel,
  buildFpBlob,
  lastRunMajor,
};
