'use strict';

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawn, execSync } = require('node:child_process');

const DEFAULTS = {
  mode: 'grid',
  multiMonitor: 'active',
  gap: 2,
  minWidth: 360,
  minHeight: 250,
  minCellWidth: null,
  minCellHeight: null,
  minCellWidthHard: null,
  minCellHeightHard: null,
  targetRatio: null,
  wastePenalty: 0.35,
  cascadeOffset: 30,
  cascadeRatio: 0.7,
  uniformCells: false,
};

function ratioOf(w, h) {
  return h > 0 ? w / h : 1;
}

function chooseGrid(n, W, H, targetRatio, wastePenalty, maxCols, maxRows) {
  if (n <= 1) return { cols: 1, rows: 1 };
  const tr = (targetRatio && targetRatio > 0) ? targetRatio : ratioOf(W, H);
  const mc = Math.max(1, Math.min(n, maxCols || n));
  const mr = Math.max(1, maxRows || n);
  const lo = Math.max(1, Math.ceil(n / mr));
  const hi = mc;
  if (lo > hi) return { cols: hi, rows: Math.ceil(n / hi) };
  const guess = Math.min(hi, Math.max(lo, Math.ceil(Math.sqrt(n * (W / H)))));
  let best = null;
  for (let cols = lo; cols <= hi; cols++) {
    const rows = Math.ceil(n / cols);
    const cellW = W / cols;
    const cellH = H / rows;
    const r = ratioOf(cellW, cellH);
    const aspDist = r >= tr ? r / tr : tr / r;
    const waste = cols * rows - n;
    const score = aspDist + wastePenalty * waste + 0.001 * Math.abs(cols - guess);
    if (!best || score < best.score) best = { cols, rows, score };
  }
  return { cols: best.cols, rows: best.rows };
}

function gridCells(n, area, cols, rows, opts) {
  const o = opts || {};
  const gap = Math.max(0, o.gap || 0);
  const minWidth = o.minWidth;
  const minHeight = o.minHeight;
  const uniform = !!o.uniformCells;
  const hardW = o.minCellWidthHard > 0 ? o.minCellWidthHard : 0;
  const hardH = o.minCellHeightHard > 0 ? o.minCellHeightHard : 0;

  const { x: ax, y: ay, width: W, height: H } = area;
  const baseH = Math.floor(H / rows);
  const uniW = Math.floor(W / cols);

  const spanY = H - gap;
  const squeezeY = hardH > 0 && rows > 1 && (baseH - gap) < hardH;
  const boxHsq = Math.min(hardH, spanY);
  const stepYsq = squeezeY ? (spanY - boxHsq) / (rows - 1) : 0;

  const spanX = W - gap;
  const squeezeX = hardW > 0 && cols > 1 && (uniW - gap) < hardW;
  const boxWsq = Math.min(hardW, spanX);
  const stepXsq = squeezeX ? (spanX - boxWsq) / (cols - 1) : 0;

  const cells = [];
  let placed = 0;
  for (let row = 0; row < rows && placed < n; row++) {
    const remaining = n - placed;
    const inRow = Math.min(cols, remaining);
    const colW = uniform ? uniW : Math.floor(W / inRow);
    const y = ay + row * baseH;
    const h = uniform ? baseH : ((row === rows - 1) ? (H - row * baseH) : baseH);
    for (let col = 0; col < inRow; col++) {
      const x = ax + col * colW;
      const w = uniform ? uniW : ((col === inRow - 1) ? (W - col * colW) : colW);
      let rx = x, ry = y, rw = w, rh = h;
      if (gap > 0) {
        const g = gap / 2;
        rx += g; ry += g; rw -= gap; rh -= gap;
      }
      if (squeezeY) { ry = ay + gap / 2 + row * stepYsq; rh = boxHsq; }
      if (squeezeX) { rx = ax + gap / 2 + col * stepXsq; rw = boxWsq; }
      const fitW = Math.min(minWidth, Math.round(rw));
      const fitH = Math.min(minHeight, Math.round(rh));
      cells.push({
        x: Math.round(rx),
        y: Math.round(ry),
        width: Math.max(fitW, Math.round(rw)),
        height: Math.max(fitH, Math.round(rh)),
      });
      placed++;
    }
  }
  return cells;
}

function cascadeCells(n, area, opts) {
  const floorW = Math.max(opts.minWidth || 0, opts.minCellWidthHard || 0);
  const floorH = Math.max(opts.minHeight || 0, opts.minCellHeightHard || 0);
  const w = Math.min(area.width, Math.max(floorW, Math.floor(area.width * opts.cascadeRatio)));
  const h = Math.min(area.height, Math.max(floorH, Math.floor(area.height * opts.cascadeRatio)));
  const maxX = Math.max(1, area.width - w);
  const maxY = Math.max(1, area.height - h);
  const cells = [];
  for (let i = 0; i < n; i++) {
    const ox = (i * opts.cascadeOffset) % maxX;
    const oy = (i * opts.cascadeOffset) % maxY;
    cells.push({ x: area.x + ox, y: area.y + oy, width: w, height: h });
  }
  return cells;
}

function stackCells(n, area) {
  const cells = [];
  for (let i = 0; i < n; i++) {
    cells.push({ x: area.x, y: area.y, width: area.width, height: area.height });
  }
  return cells;
}

function layoutOnDisplay(n, workArea, opts) {
  if (n <= 0) return [];
  const colCap = () => (opts.minCellWidth > 0 ? Math.max(1, Math.floor(workArea.width / opts.minCellWidth)) : n);
  switch (opts.mode) {
    case 'stack':
      return stackCells(n, workArea);
    case 'cascade':
      return cascadeCells(n, workArea, opts);
    case 'columns': {
      const cols = Math.max(1, Math.min(n, colCap()));
      return gridCells(n, workArea, cols, Math.ceil(n / cols), opts);
    }
    case 'grid':
    default: {
      if (n === 1) return gridCells(1, workArea, 1, 1, opts);
      const maxCols = colCap();
      const maxRows = opts.minCellHeight > 0 ? Math.max(1, Math.floor(workArea.height / opts.minCellHeight)) : n;
      const { cols, rows } = chooseGrid(n, workArea.width, workArea.height, opts.targetRatio, opts.wastePenalty, maxCols, maxRows);
      return gridCells(n, workArea, cols, rows, opts);
    }
  }
}

function allocateSpread(windows, displays) {
  const n = windows.length;
  const areas = displays.map((d) => Math.max(1, d.workArea.width * d.workArea.height));
  const total = areas.reduce((a, b) => a + b, 0);
  const counts = areas.map((a) => Math.round((n * a) / total));
  let diff = n - counts.reduce((a, b) => a + b, 0);
  const order = displays.map((_, i) => i).sort((a, b) => areas[b] - areas[a]);
  let k = 0;
  while (diff !== 0 && order.length) {
    const idx = order[k % order.length];
    if (diff > 0) { counts[idx]++; diff--; }
    else if (counts[idx] > 0) { counts[idx]--; diff++; }
    k++;
  }
  const groups = [];
  let p = 0;
  displays.forEach((d, i) => {
    if (counts[i] > 0) {
      groups.push({ display: d, windows: windows.slice(p, p + counts[i]) });
      p += counts[i];
    }
  });
  return groups;
}

function computeLayout(windows, displays, options) {
  const opts = Object.assign({}, DEFAULTS, options || {});
  const n = Array.isArray(windows) ? windows.length : 0;
  if (n === 0 || !Array.isArray(displays) || displays.length === 0) return [];

  const byId = new Map(displays.map((d) => [d.id, d]));
  const primary = (opts.primaryDisplayId != null && byId.get(opts.primaryDisplayId))
    || displays.find((d) => d.primary) || displays[0];

  let groups;
  if (opts.multiMonitor === 'spread' && displays.length > 1) {
    groups = allocateSpread(windows, displays);
  } else {
    let target = primary;
    if (opts.multiMonitor === 'active' && opts.activeDisplayId != null && byId.get(opts.activeDisplayId)) {
      target = byId.get(opts.activeDisplayId);
    }
    groups = [{ display: target, windows }];
  }

  const result = [];
  for (const g of groups) {
    const cells = layoutOnDisplay(g.windows.length, g.display.workArea, opts);
    g.windows.forEach((win, i) => {
      const c = cells[i];
      if (!c) return;
      result.push({ windowId: win.id, displayId: g.display.id, x: c.x, y: c.y, width: c.width, height: c.height });
    });
  }
  return result;
}

function maxWindowsForArea(area, minWidth = 516, minHeight = 360) {
  const cols = Math.max(1, Math.floor(area.width / minWidth));
  const rows = Math.max(1, Math.floor(area.height / minHeight));
  return cols * rows;
}

/**
 * Gather display work areas from Electron `screen` (when running inside Electron)
 * or fallback to Windows `System.Windows.Forms.Screen` / default 1920x1040 work area.
 */
function gatherDisplays() {
  try {
    const electron = require('electron');
    if (electron && electron.screen && typeof electron.screen.getAllDisplays === 'function') {
      const all = electron.screen.getAllDisplays().map((d) => ({
        id: d.id,
        workArea: { x: d.workArea.x, y: d.workArea.y, width: d.workArea.width, height: d.workArea.height },
        scaleFactor: d.scaleFactor || 1,
        primary: false,
      }));
      if (all.length) {
        const primaryId = electron.screen.getPrimaryDisplay().id;
        const pd = all.find((d) => d.id === primaryId);
        if (pd) pd.primary = true;
        let activeId = primaryId;
        try {
          const pt = electron.screen.getCursorScreenPoint();
          activeId = electron.screen.getDisplayNearestPoint(pt).id;
        } catch {}
        return { displays: all, primaryId, activeId };
      }
    }
  } catch {}

  if (process.platform === 'win32') {
    try {
      const cmd = `Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.Screen]::AllScreens | ForEach-Object { "$($_.DeviceName)|$($_.Primary)|$($_.WorkingArea.X)|$($_.WorkingArea.Y)|$($_.WorkingArea.Width)|$($_.WorkingArea.Height)" }`;
      const out = execSync(`powershell.exe -NoProfile -NonInteractive -Command "${cmd}"`, {
        encoding: 'utf8',
        windowsHide: true,
        timeout: 2500,
      }).trim();
      const displays = out.split(/\r?\n/).filter(Boolean).map((line, idx) => {
        const parts = line.split('|');
        const primary = /^true$/i.test(parts[1] || '');
        return {
          id: parts[0] || `display-${idx}`,
          primary,
          scaleFactor: 1,
          workArea: {
            x: parseInt(parts[2], 10) || 0,
            y: parseInt(parts[3], 10) || 0,
            width: parseInt(parts[4], 10) || 1920,
            height: parseInt(parts[5], 10) || 1040,
          },
        };
      });
      if (displays.length) {
        const primary = displays.find((d) => d.primary) || displays[0];
        return { displays, primaryId: primary.id, activeId: primary.id };
      }
    } catch {}
  }

  return {
    displays: [{ id: 'primary', primary: true, scaleFactor: 1, workArea: { x: 0, y: 0, width: 1920, height: 1040 } }],
    primaryId: 'primary',
    activeId: 'primary',
  };
}

const APPLY_PS = `param([string]$Specs)
$ErrorActionPreference='SilentlyContinue'
Add-Type @"
using System;using System.Runtime.InteropServices;using System.Text;
public class CGTWA{
 [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc cb,IntPtr p);
 [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h,out uint pid);
 [DllImport("user32.dll",CharSet=CharSet.Auto)] public static extern int GetClassName(IntPtr h,StringBuilder s,int n);
 [DllImport("user32.dll")] public static extern int GetWindowTextLength(IntPtr h);
 [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h,int c);
 [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
 [DllImport("user32.dll")] public static extern bool IsZoomed(IntPtr h);
 [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h,IntPtr after,int x,int y,int cx,int cy,uint flags);
 [DllImport("user32.dll")] public static extern bool GetWindowPlacement(IntPtr h,ref WINDOWPLACEMENT w);
 [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h,out RECT r);
 public struct RECT{public int left;public int top;public int right;public int bottom;}
 public struct POINT{public int x;public int y;}
 public struct WINDOWPLACEMENT{public int length;public int flags;public int showCmd;public POINT minPos;public POINT maxPos;public RECT normalPos;}
 public delegate bool EnumWindowsProc(IntPtr h,IntPtr p);
 public static IntPtr Found=IntPtr.Zero; public static long BestArea=0; public static uint Target=0;
 public static bool Cb(IntPtr h,IntPtr p){
  uint wp; GetWindowThreadProcessId(h,out wp);
  if(wp!=Target)return true; var sb=new StringBuilder(256); GetClassName(h,sb,256);
  if(sb.ToString()!="Chrome_WidgetWin_1" && sb.ToString()!="MozillaWindowClass")return true; if(GetWindowTextLength(h)==0)return true;
  WINDOWPLACEMENT wpl=new WINDOWPLACEMENT(); wpl.length=Marshal.SizeOf(typeof(WINDOWPLACEMENT)); GetWindowPlacement(h,ref wpl);
  RECT rc; GetWindowRect(h,out rc);
  int nw=wpl.normalPos.right-wpl.normalPos.left; int nh=wpl.normalPos.bottom-wpl.normalPos.top;
  int lw=rc.right-rc.left; int lh=rc.bottom-rc.top;
  int w=Math.Max(nw,lw); int ht=Math.Max(nh,lh);
  if(w<200||ht<200)return true; long area=(long)w*ht;
  if(area>BestArea){BestArea=area;Found=h;} return true;}
 public static IntPtr Find(uint pid){Found=IntPtr.Zero;BestArea=0;Target=pid;EnumWindows(new EnumWindowsProc(Cb),IntPtr.Zero);return Found;}
 public static void Place(IntPtr h,int x,int y,int w,int ht){
  if(IsIconic(h)||IsZoomed(h))ShowWindow(h,4);
  SetWindowPos(h,(IntPtr)(-1),x,y,w,ht,0x0050);
  SetWindowPos(h,(IntPtr)(-2),x,y,w,ht,0x0050);
 }
}
"@
foreach($spec in ($Specs.Split(';') | Where-Object { $_ -ne '' })){
  try{
    $f=$spec.Split(',')
    if($f.Count -lt 5){ continue }
    $h=[CGTWA]::Find([uint32]$f[0])
    if($h -ne [IntPtr]::Zero){
      [CGTWA]::Place($h,[int]$f[1],[int]$f[2],[int]$f[3],[int]$f[4])
    }
  } catch { }
}`;

const SHOW_PS = `param([int]$ProcId,[switch]$NoActivate)
$ErrorActionPreference='SilentlyContinue'
Add-Type @"
using System;using System.Runtime.InteropServices;using System.Text;
public class CGTW{
 [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc cb,IntPtr p);
 [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h,out uint pid);
 [DllImport("user32.dll",CharSet=CharSet.Auto)] public static extern int GetClassName(IntPtr h,StringBuilder s,int n);
 [DllImport("user32.dll")] public static extern int GetWindowTextLength(IntPtr h);
 [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h,int c);
 [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
 [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h);
 [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
 [DllImport("user32.dll")] public static extern bool SystemParametersInfo(uint a,uint b,ref uint v,uint f);
 [DllImport("user32.dll")] public static extern bool SystemParametersInfo(uint a,uint b,IntPtr v,uint f);
 [DllImport("user32.dll")] public static extern bool GetWindowPlacement(IntPtr h,ref WINDOWPLACEMENT w);
 public struct RECT{public int left;public int top;public int right;public int bottom;}
 public struct POINT{public int x;public int y;}
 public struct WINDOWPLACEMENT{public int length;public int flags;public int showCmd;public POINT minPos;public POINT maxPos;public RECT normalPos;}
 public delegate bool EnumWindowsProc(IntPtr h,IntPtr p);
 public static IntPtr Found=IntPtr.Zero; public static long BestArea=0; public static uint Target=0;
 public static bool Cb(IntPtr h,IntPtr p){
  uint wp; GetWindowThreadProcessId(h,out wp);
  if(wp!=Target)return true; var sb=new StringBuilder(256); GetClassName(h,sb,256);
  if(sb.ToString()!="Chrome_WidgetWin_1" && sb.ToString()!="MozillaWindowClass")return true; if(GetWindowTextLength(h)==0)return true;
  WINDOWPLACEMENT wpl=new WINDOWPLACEMENT(); wpl.length=Marshal.SizeOf(typeof(WINDOWPLACEMENT)); GetWindowPlacement(h,ref wpl);
  int w=wpl.normalPos.right-wpl.normalPos.left; int ht=wpl.normalPos.bottom-wpl.normalPos.top;
  if(w<200||ht<200)return true; long area=(long)w*ht;
  if(area>BestArea){BestArea=area;Found=h;} return true;}
 public static IntPtr Find(uint pid){Found=IntPtr.Zero;BestArea=0;Target=pid;EnumWindows(new EnumWindowsProc(Cb),IntPtr.Zero);return Found;}
 public static void Foreground(IntPtr h){
  if(IsIconic(h))ShowWindow(h,9);
  uint old=0; SystemParametersInfo(0x2000,0,ref old,0);
  SystemParametersInfo(0x2001,0,IntPtr.Zero,2);
  BringWindowToTop(h); SetForegroundWindow(h);
  SystemParametersInfo(0x2001,0,(IntPtr)old,2);
 }
 public static void Surface(IntPtr h){ if(IsIconic(h))ShowWindow(h,4); }
}
"@
$hwnd=[CGTW]::Find([uint32]$ProcId)
if($hwnd -ne [IntPtr]::Zero){ if($NoActivate){[CGTW]::Surface($hwnd)}else{[CGTW]::Foreground($hwnd)} }`;

let _applyScriptPath = null;
let _showScriptPath = null;

function ensureScript(filePath, content) {
  try {
    if (!fs.existsSync(filePath)) fs.writeFileSync(filePath, content, 'utf8');
    return filePath;
  } catch {
    return null;
  }
}

function spawnHiddenPs(script, args) {
  try {
    const c = spawn('powershell.exe', [
      '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden',
      '-File', script, ...args,
    ], { detached: false, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
    if (c.stdout) c.stdout.on('data', () => {});
    if (c.stderr) c.stderr.on('data', () => {});
    c.on('error', () => {});
    if (c.unref) c.unref();
    return true;
  } catch {
    return false;
  }
}

function manualSpecs(pids, opts = {}) {
  const i = (v, d) => { const n = parseInt(v, 10); return Number.isFinite(n) ? n : d; };
  const mx = i(opts.x, 0), my = i(opts.y, 0);
  const mw = i(opts.w, 520), mh = i(opts.h, 640);
  const hs = i(opts.hs, 2), vs = i(opts.vs, 2);
  const perRow = Math.max(1, i(opts.perRow, 3));
  const CHROME_MIN_W = 516, CHROME_MIN_H = 96, GAP_MIN = 2;
  const realW = Math.max(mw, CHROME_MIN_W);
  const realH = Math.max(mh, CHROME_MIN_H);
  const stepX = realW + Math.max(hs, GAP_MIN);
  const stepY = realH + Math.max(vs, GAP_MIN);
  return pids.map((pid, idx) => {
    const col = idx % perRow;
    const row = Math.floor(idx / perRow);
    return `${pid},${mx + col * stepX},${my + row * stepY},${realW},${realH}`;
  });
}

function arrangeByPids(pids, layout = 'grid', opts = {}) {
  if (process.platform !== 'win32' || !Array.isArray(pids) || !pids.length) return { count: 0, rects: [] };
  if (!_applyScriptPath) _applyScriptPath = path.join(os.tmpdir(), 'cgt-apply-layout.ps1');
  const script = ensureScript(_applyScriptPath, APPLY_PS);

  let specs = [];
  let rects = [];
  if (layout === 'manual') {
    specs = manualSpecs(pids, opts);
    rects = specs.map((s) => {
      const [pid, x, y, width, height] = s.split(',').map(Number);
      return { windowId: pid, x, y, width, height };
    });
  } else {
    const info = gatherDisplays();
    const gap = Math.max(2, Number.isFinite(opts.gap) ? opts.gap : 2);
    const MIN_WIN_W = 516, MIN_WIN_H = 360, HARD_WIN_W = 516, HARD_WIN_H = 96;
    rects = computeLayout(pids.map((pid) => ({ id: pid })), info.displays, {
      mode: ['grid', 'columns', 'cascade', 'stack'].includes(layout) ? layout : 'grid',
      multiMonitor: opts.multiMonitor || 'active',
      activeDisplayId: info.activeId,
      primaryDisplayId: info.primaryId,
      gap,
      minCellWidth: MIN_WIN_W + gap,
      minCellHeight: MIN_WIN_H + gap,
      minCellWidthHard: HARD_WIN_W + gap,
      minCellHeightHard: HARD_WIN_H + gap,
      uniformCells: opts.uniformCells !== false,
    });
    specs = rects.map((r) => `${r.windowId},${r.x},${r.y},${r.width},${r.height}`);
  }

  if (script && specs.length) {
    spawnHiddenPs(script, ['-Specs', specs.join(';')]);
  }
  return { count: pids.length, rects };
}

function showWindowByPid(pid, noActivate = false) {
  if (process.platform !== 'win32' || !pid || pid <= 0) return false;
  if (!_showScriptPath) _showScriptPath = path.join(os.tmpdir(), 'cgt-show-window.ps1');
  const script = ensureScript(_showScriptPath, SHOW_PS);
  if (!script) return false;
  const args = ['-ProcId', String(pid)];
  if (noActivate) args.push('-NoActivate');
  return spawnHiddenPs(script, args);
}

module.exports = {
  DEFAULTS,
  computeLayout,
  chooseGrid,
  gridCells,
  allocateSpread,
  maxWindowsForArea,
  gatherDisplays,
  arrangeByPids,
  showWindowByPid,
};
