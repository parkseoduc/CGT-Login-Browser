'use strict';

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { execFileSync, execSync } = require('node:child_process');
const { DatabaseSync } = require('node:sqlite');

const SIDECAR_FILENAME = 'cgt-portable-cookies.json';
const DPAPI_HELPER_EXE = path.resolve(__dirname, '..', '..', 'bin', 'dpapi-helper.exe');
const EPOCH_DIFF_SECONDS = 11644473600; // Seconds between 1601-01-01 (WebKit) and 1970-01-01 (Unix)

let _cachedMachineStamp = null;

/**
 * Deterministic fingerprint of current Windows DPAPI domain (MachineGuid + OS Username).
 */
function getMachineStamp() {
  if (_cachedMachineStamp) return _cachedMachineStamp;
  let machineGuid = os.hostname();
  if (process.platform === 'win32') {
    try {
      const out = execSync(
        'reg query "HKLM\\SOFTWARE\\Microsoft\\Cryptography" /v MachineGuid',
        { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'], windowsHide: true }
      );
      const m = out.match(/MachineGuid\s+REG_SZ\s+([^\r\n]+)/i);
      if (m && m[1]) machineGuid = m[1].trim();
    } catch {}
  }
  let user = 'default';
  try { user = os.userInfo().username || 'default'; } catch {}
  _cachedMachineStamp = crypto
    .createHash('sha256')
    .update(`${machineGuid}|${user}`, 'utf8')
    .digest('hex')
    .slice(0, 20);
  return _cachedMachineStamp;
}

/**
 * Unprotect Windows CurrentUser DPAPI blob in ~8ms via bin/dpapi-helper.exe (fallback PowerShell).
 * Returns Buffer or null if encrypted under a different Windows machine/user.
 */
function dpapiUnprotect(cipherBuf) {
  if (process.platform !== 'win32' || !Buffer.isBuffer(cipherBuf) || cipherBuf.length === 0) {
    return null;
  }
  const b64In = cipherBuf.toString('base64');

  if (fs.existsSync(DPAPI_HELPER_EXE)) {
    try {
      const out = execFileSync(DPAPI_HELPER_EXE, ['unprotect', b64In], {
        encoding: 'utf8',
        stdio: ['ignore', 'pipe', 'pipe'],
        windowsHide: true,
        timeout: 4000,
      });
      if (out && out.trim()) return Buffer.from(out.trim(), 'base64');
    } catch {
      return null;
    }
  }

  try {
    const ps = `Add-Type -AssemblyName System.Security; [Convert]::ToBase64String([System.Security.Cryptography.ProtectedData]::Unprotect([Convert]::FromBase64String('${b64In}'), $null, [System.Security.Cryptography.DataProtectionScope]::CurrentUser))`;
    const encoded = Buffer.from(ps, 'utf16le').toString('base64');
    const out = execFileSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-EncodedCommand', encoded], {
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'pipe'],
      windowsHide: true,
      timeout: 6000,
    });
    if (out && out.trim()) return Buffer.from(out.trim(), 'base64');
  } catch {
    return null;
  }
  return null;
}

/**
 * Extract 32-byte AES-256 master key from Chromium `<userDataDir>/Local State`.
 * Returns `{ key: Buffer, portable: boolean, foreignKey: boolean }`.
 */
function extractChromiumMasterKey(userDataDir) {
  const localStatePath = path.join(userDataDir, 'Local State');
  if (!fs.existsSync(localStatePath)) {
    return { key: null, portable: false, foreignKey: false };
  }
  try {
    const raw = JSON.parse(fs.readFileSync(localStatePath, 'utf8'));
    const encKeyB64 = raw && raw.os_crypt && raw.os_crypt.encrypted_key;
    if (!encKeyB64 || typeof encKeyB64 !== 'string') {
      return { key: null, portable: false, foreignKey: false };
    }
    const buf = Buffer.from(encKeyB64, 'base64');

    // 1. Portable raw key ("poly" + 32 bytes)
    if (buf.length === 36 && buf.subarray(0, 4).toString('ascii') === 'poly') {
      return { key: buf.subarray(4), portable: true, foreignKey: false };
    }

    // 2. Standard Windows DPAPI key ("DPAPI" + ProtectedBytes)
    if (buf.length > 5 && buf.subarray(0, 5).toString('ascii') === 'DPAPI') {
      const plainKey = dpapiUnprotect(buf.subarray(5));
      if (plainKey && plainKey.length === 32) {
        return { key: plainKey, portable: false, foreignKey: false };
      }
      // Present DPAPI key that failed Unprotect => came from another Windows PC / user!
      return { key: null, portable: false, foreignKey: true };
    }
  } catch {}
  return { key: null, portable: false, foreignKey: false };
}

function mapSameSiteInt(val) {
  const n = Number(val);
  if (n === 0) return 'None';
  if (n === 1) return 'Lax';
  if (n === 2) return 'Strict';
  return undefined;
}

function decryptChromiumCookieValue(encryptedBuf, masterKey, hostKey, metaVersion = 0) {
  if (!encryptedBuf || !encryptedBuf.length) return null;
  const buf = Buffer.isBuffer(encryptedBuf) ? encryptedBuf : Buffer.from(encryptedBuf);
  if (buf.length < 3 + 12 + 16) return null;

  const prefix = buf.subarray(0, 3).toString('ascii');
  if (prefix !== 'v10' && prefix !== 'v11' && prefix !== 'v20') {
    return null;
  }
  if (!masterKey || masterKey.length !== 32) return null;

  try {
    const nonce = buf.subarray(3, 15);
    const tag = buf.subarray(buf.length - 16);
    const ciphertext = buf.subarray(15, buf.length - 16);

    const decipher = crypto.createDecipheriv('aes-256-gcm', masterKey, nonce);
    decipher.setAuthTag(tag);
    let plain = Buffer.concat([decipher.update(ciphertext), decipher.final()]);

    // Chromium M124+ (SQLite meta version >= 24) prepends 32-byte SHA-256(host_key) to prevent domain-swapping
    if (plain.length >= 32 && hostKey) {
      const expectedHash = crypto.createHash('sha256').update(String(hostKey), 'utf8').digest();
      if (plain.subarray(0, 32).equals(expectedHash) || metaVersion >= 24) {
        plain = plain.subarray(32);
      }
    }
    return plain.toString('utf8');
  } catch {
    return null;
  }
}

function copySqliteSnapshotToTemp(dbFile) {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'cgt-ck-'));
  const baseName = path.basename(dbFile);
  const dstFile = path.join(tmpDir, baseName);
  fs.copyFileSync(dbFile, dstFile);
  for (const suffix of ['-wal', '-shm', '-journal']) {
    const side = dbFile + suffix;
    if (fs.existsSync(side)) {
      try { fs.copyFileSync(side, dstFile + suffix); } catch {}
    }
  }
  return { tmpDir, dstFile };
}

function readChromiumSqliteCookies(userDataDir) {
  const candidates = [
    path.join(userDataDir, 'Default', 'Network', 'Cookies'),
    path.join(userDataDir, 'Default', 'Cookies'),
  ];
  const cookieDbPath = candidates.find((p) => fs.existsSync(p));
  if (!cookieDbPath) return { ok: false, cookies: [], foreignKey: false };

  const { key: masterKey, foreignKey } = extractChromiumMasterKey(userDataDir);
  if (foreignKey && !masterKey) {
    return { ok: false, cookies: [], foreignKey: true };
  }

  const { tmpDir, dstFile } = copySqliteSnapshotToTemp(cookieDbPath);
  let dbConn = null;
  try {
    dbConn = new DatabaseSync(dstFile);
    let metaVersion = 0;
    try {
      const metaRow = dbConn.prepare("SELECT value FROM meta WHERE key = 'version'").get();
      if (metaRow && metaRow.value != null) metaVersion = parseInt(String(metaRow.value), 10) || 0;
    } catch {}

    const rows = dbConn.prepare(`
      SELECT host_key, name, value, encrypted_value, path, CAST(expires_utc AS TEXT) AS expires_utc, is_secure, is_httponly, samesite, has_expires
      FROM cookies
    `).all();

    const out = [];
    for (const r of rows) {
      let val = r.value ? String(r.value) : '';
      if (!val && r.encrypted_value && r.encrypted_value.length > 0) {
        const dec = decryptChromiumCookieValue(r.encrypted_value, masterKey, r.host_key, metaVersion);
        if (dec === null) continue; // Skip undecryptable cookie
        val = dec;
      }

      const item = {
        name: String(r.name || ''),
        value: val,
        domain: String(r.host_key || ''),
        path: String(r.path || '/'),
        secure: Boolean(r.is_secure),
        httpOnly: Boolean(r.is_httponly),
      };
      const ss = mapSameSiteInt(r.samesite);
      if (ss) item.sameSite = ss;
      if (item.sameSite === 'None') item.secure = true;

      if (r.has_expires && r.expires_utc && r.expires_utc !== '0') {
        try {
          const unixSec = Number(BigInt(String(r.expires_utc)) / 1000000n - BigInt(EPOCH_DIFF_SECONDS));
          if (unixSec > 0) item.expires = unixSec;
        } catch {}
      }
      if (item.name && item.domain) out.push(item);
    }

    return { ok: true, cookies: out, foreignKey: false };
  } catch {
    return { ok: false, cookies: [], foreignKey };
  } finally {
    try { if (dbConn) dbConn.close(); } catch {}
    try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch {}
  }
}

function readFirefoxSqliteCookies(userDataDir) {
  const ffCookiePath = path.join(userDataDir, 'cookies.sqlite');
  if (!fs.existsSync(ffCookiePath)) return { ok: false, cookies: [] };

  const { tmpDir, dstFile } = copySqliteSnapshotToTemp(ffCookiePath);
  let dbConn = null;
  try {
    dbConn = new DatabaseSync(dstFile);
    const rows = dbConn.prepare(`
      SELECT host, name, value, path, CAST(expiry AS TEXT) AS expiry, isSecure, isHttpOnly, sameSite
      FROM moz_cookies
    `).all();
    const out = rows
      .map((r) => {
        const item = {
          name: String(r.name || ''),
          value: String(r.value ?? ''),
          domain: String(r.host || ''),
          path: String(r.path || '/'),
          secure: Boolean(r.isSecure),
          httpOnly: Boolean(r.isHttpOnly),
        };
        const ss = mapSameSiteInt(r.sameSite);
        if (ss) item.sameSite = ss;
        if (item.sameSite === 'None') item.secure = true;
        if (Number(r.expiry) > 0) item.expires = Math.floor(Number(r.expiry));
        return item.name && item.domain ? item : null;
      })
      .filter(Boolean);
    return { ok: true, cookies: out };
  } catch {
    return { ok: false, cookies: [] };
  } finally {
    try { if (dbConn) dbConn.close(); } catch {}
    try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch {}
  }
}

function normalizeCookieForCdp(c) {
  if (!c || !c.name || !(c.domain || c.url)) return null;
  const item = {
    name: String(c.name).trim(),
    value: String(c.value ?? ''),
    path: c.path ? String(c.path) : '/',
    secure: Boolean(c.secure),
    httpOnly: Boolean(c.httpOnly),
  };
  if (c.domain) item.domain = String(c.domain).trim();
  else if (c.url) item.url = String(c.url).trim();
  if (c.sameSite && ['Strict', 'Lax', 'None'].includes(c.sameSite)) {
    item.sameSite = c.sameSite;
    if (item.sameSite === 'None') item.secure = true;
  }
  const exp = Number(c.expires ?? c.expirationDate ?? c.expiration_time);
  if (Number.isFinite(exp) && exp > 0) item.expires = exp;
  return item;
}

function readPortableSidecar(userDataDir) {
  const p = path.join(userDataDir, SIDECAR_FILENAME);
  if (!fs.existsSync(p)) return null;
  try {
    const data = JSON.parse(fs.readFileSync(p, 'utf8'));
    if (data && Array.isArray(data.cookies)) return data;
  } catch {}
  return null;
}

function writePortableSidecar(userDataDir, cookies, opts = {}) {
  if (!userDataDir) return null;
  fs.mkdirSync(userDataDir, { recursive: true });
  const normalized = (Array.isArray(cookies) ? cookies : [])
    .map(normalizeCookieForCdp)
    .filter(Boolean);

  const stamp = opts.sourceStamp || getMachineStamp();
  const payload = {
    version: 2,
    sourceStamp: stamp,
    appliedStamp: opts.appliedStamp !== undefined ? opts.appliedStamp : stamp,
    updatedAt: new Date().toISOString(),
    count: normalized.length,
    cookies: normalized,
  };
  const outPath = path.join(userDataDir, SIDECAR_FILENAME);
  fs.writeFileSync(outPath, JSON.stringify(payload), 'utf8');
  return payload;
}

/**
 * Read cookies offline from a closed profile directory (`chrome` or `firefox`):
 * 1. Native SQLite + DPAPI decryption (same-PC or Poly portable key or Firefox)
 * 2. Portable sidecar `cgt-portable-cookies.json` (when synced from another PC before first launch)
 */
function readOfflineCookies(userDataDir) {
  if (!userDataDir || !fs.existsSync(userDataDir)) return [];

  const cr = readChromiumSqliteCookies(userDataDir);
  if (cr.ok && cr.cookies.length > 0) {
    return cr.cookies;
  }

  const ff = readFirefoxSqliteCookies(userDataDir);
  if (ff.ok && ff.cookies.length > 0) {
    return ff.cookies;
  }

  const sidecar = readPortableSidecar(userDataDir);
  if (sidecar && sidecar.cookies.length > 0) {
    return sidecar.cookies;
  }

  return [];
}

/**
 * Ensure `cgt-portable-cookies.json` is up to date on disk right before Cloud Sync `pack()`.
 * Works even if the profile was NEVER opened in the current app session!
 */
function ensurePortableSidecarFromDisk(userDataDir) {
  if (!userDataDir || !fs.existsSync(userDataDir)) return null;
  const cr = readChromiumSqliteCookies(userDataDir);
  if (cr.ok && cr.cookies.length > 0) {
    return writePortableSidecar(userDataDir, cr.cookies);
  }
  const ff = readFirefoxSqliteCookies(userDataDir);
  if (ff.ok && ff.cookies.length > 0) {
    return writePortableSidecar(userDataDir, ff.cookies);
  }
  return readPortableSidecar(userDataDir);
}

/**
 * Called right BEFORE spawning Chromium in `launcher.js` (after `cloudSync.beforeOpen`):
 * Detects if profile arrived from a DIFFERENT Windows PC/user (foreign DPAPI key in `Local State`).
 * If so, strips only the foreign `os_crypt` block + unreadable `Cookies` DB so Chromium initializes
 * a valid local DPAPI key, and returns `{ needsRestore: true, cookies }` for immediate CDP injection!
 */
function prepareCrossMachineCookies(userDataDir, { isPolyPatched = false, engine = 'chromium' } = {}) {
  if (engine !== 'chromium' || isPolyPatched || !userDataDir || !fs.existsSync(userDataDir)) {
    return { needsRestore: false, cookies: [] };
  }

  const currentStamp = getMachineStamp();
  const sidecar = readPortableSidecar(userDataDir);
  const { foreignKey } = extractChromiumMasterKey(userDataDir);

  const stampMismatch = Boolean(sidecar && sidecar.appliedStamp && sidecar.appliedStamp !== currentStamp);
  if (!foreignKey && !stampMismatch) {
    return { needsRestore: false, cookies: [] };
  }

  // Foreign DPAPI key detected (or sidecar from another machine not yet bound to local DPAPI):
  // 1. Clean foreign `os_crypt` from `Local State` so Chromium creates a fresh local DPAPI key
  const localStatePath = path.join(userDataDir, 'Local State');
  if (fs.existsSync(localStatePath)) {
    try {
      const ls = JSON.parse(fs.readFileSync(localStatePath, 'utf8'));
      if (ls && ls.os_crypt) {
        delete ls.os_crypt;
        fs.writeFileSync(localStatePath, JSON.stringify(ls), 'utf8');
      }
    } catch {}
  }

  // 2. Remove foreign DPAPI-encrypted SQLite Cookies files (Local Storage & IndexedDB remain 100% intact!)
  const cookiePaths = [
    path.join(userDataDir, 'Default', 'Network', 'Cookies'),
    path.join(userDataDir, 'Default', 'Cookies'),
  ];
  for (const base of cookiePaths) {
    for (const suffix of ['', '-wal', '-shm', '-journal']) {
      const target = base + suffix;
      if (fs.existsSync(target)) {
        try { fs.unlinkSync(target); } catch {}
      }
    }
  }

  const cookies = sidecar && Array.isArray(sidecar.cookies) ? sidecar.cookies : [];
  return {
    needsRestore: cookies.length > 0,
    cookies,
  };
}

function markSidecarApplied(userDataDir) {
  const sidecar = readPortableSidecar(userDataDir);
  if (!sidecar) return;
  const currentStamp = getMachineStamp();
  sidecar.appliedStamp = currentStamp;
  sidecar.restoredAt = new Date().toISOString();
  try {
    fs.writeFileSync(path.join(userDataDir, SIDECAR_FILENAME), JSON.stringify(sidecar), 'utf8');
  } catch {}
}

module.exports = {
  SIDECAR_FILENAME,
  getMachineStamp,
  dpapiUnprotect,
  extractChromiumMasterKey,
  readOfflineCookies,
  readPortableSidecar,
  writePortableSidecar,
  ensurePortableSidecarFromDisk,
  prepareCrossMachineCookies,
  markSidecarApplied,
};
