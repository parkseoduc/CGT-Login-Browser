'use strict';

const fs = require('node:fs');
const path = require('node:path');

const CMD_SET_TAB_WINDOW = 0;
const CMD_SET_TAB_INDEX_IN_WINDOW = 2;
const CMD_UPDATE_TAB_NAVIGATION = 6;
const CMD_SET_SELECTED_NAVIGATION_INDEX = 7;
const CMD_SET_WINDOW_TYPE = 9;
const CMD_TAB_CLOSED = 16;
const CMD_WINDOW_CLOSED = 17;

function newestSessionFile(userDataDir) {
  const dir = path.join(userDataDir, 'Default', 'Sessions');
  let best = null;
  let bestM = -1;
  try {
    for (const name of fs.readdirSync(dir)) {
      if (!name.startsWith('Session_')) continue;
      const full = path.join(dir, name);
      const m = fs.statSync(full).mtimeMs;
      if (m > bestM) {
        bestM = m;
        best = full;
      }
    }
  } catch {
    return null;
  }
  return best;
}

/**
 * Parse Chromium binary SNSS session file to discover open tab URLs from the previous run.
 */
function readOpenTabUrls(userDataDir) {
  try {
    const file = newestSessionFile(userDataDir);
    if (!file) return [];
    const buf = fs.readFileSync(file);
    if (buf.length < 8 || buf.toString('latin1', 0, 4) !== 'SNSS') return [];

    const windows = new Map();
    const tabs = new Map();
    let order = 0;

    const win = (id) => {
      if (!windows.has(id)) windows.set(id, { type: 0, removed: false });
      return windows.get(id);
    };
    const tab = (id) => {
      if (!tabs.has(id)) {
        tabs.set(id, { winId: null, idxInWin: 0, navs: new Map(), selIdx: -1, order: order++ });
      }
      return tabs.get(id);
    };

    let pos = 8;
    while (pos + 2 <= buf.length) {
      const size = buf.readUInt16LE(pos);
      pos += 2;
      if (size === 0 || pos + size > buf.length) break;
      const id = buf.readUInt8(pos);
      const content = buf.subarray(pos + 1, pos + size);
      pos += size;
      try {
        switch (id) {
          case CMD_SET_TAB_WINDOW: {
            const w = content.readInt32LE(0);
            const t = content.readInt32LE(4);
            win(w);
            tab(t).winId = w;
            break;
          }
          case CMD_SET_TAB_INDEX_IN_WINDOW: {
            const t = content.readInt32LE(0);
            tab(t).idxInWin = content.readInt32LE(4);
            break;
          }
          case CMD_UPDATE_TAB_NAVIGATION: {
            let p = 4;
            const t = content.readInt32LE(p); p += 4;
            const navIdx = content.readInt32LE(p); p += 4;
            const len = content.readInt32LE(p); p += 4;
            if (len < 0 || p + len > content.length) break;
            tab(t).navs.set(navIdx, content.toString('utf8', p, p + len));
            break;
          }
          case CMD_SET_SELECTED_NAVIGATION_INDEX: {
            const t = content.readInt32LE(0);
            tab(t).selIdx = content.readInt32LE(4);
            break;
          }
          case CMD_SET_WINDOW_TYPE: {
            const w = content.readInt32LE(0);
            win(w).type = content.readInt32LE(4);
            break;
          }
          case CMD_TAB_CLOSED: {
            tabs.delete(content.readInt32LE(0));
            break;
          }
          case CMD_WINDOW_CLOSED: {
            win(content.readInt32LE(0)).removed = true;
            break;
          }
          default:
            break;
        }
      } catch { /* skip malformed command */ }
    }

    const list = [...tabs.values()].filter((t) => {
      if (t.winId == null) return false;
      const w = windows.get(t.winId);
      if (w && w.removed) return false;
      if (w && w.type !== 0) return false;
      return true;
    });
    list.sort((a, b) => (a.winId - b.winId) || (a.idxInWin - b.idxInWin) || (a.order - b.order));

    const out = [];
    for (const t of list) {
      let url = t.navs.get(t.selIdx);
      if (url == null) {
        let maxK = -1;
        for (const k of t.navs.keys()) if (k > maxK) maxK = k;
        url = t.navs.get(maxK);
      }
      if (!url) continue;
      if (!/^(https?|ftp):\/\//i.test(url)) continue;
      out.push(url);
      if (out.length >= 50) break;
    }
    return out;
  } catch {
    return [];
  }
}

module.exports = { readOpenTabUrls, newestSessionFile };
