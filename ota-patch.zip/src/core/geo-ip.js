'use strict';

const http = require('node:http');
const proxyHelper = require('../proxy');

// Country code -> primary language list mapping for realistic GeoIP auto-matching
const COUNTRY_LANGS = {
  VN: ['vi-VN', 'vi', 'en-US', 'en'],
  US: ['en-US', 'en'],
  GB: ['en-GB', 'en-US', 'en'],
  AU: ['en-AU', 'en-US', 'en'],
  CA: ['en-CA', 'en-US', 'en'],
  SG: ['en-SG', 'en-US', 'en'],
  JP: ['ja-JP', 'ja', 'en-US', 'en'],
  KR: ['ko-KR', 'ko', 'en-US', 'en'],
  CN: ['zh-CN', 'zh', 'en-US', 'en'],
  TW: ['zh-TW', 'zh', 'en-US', 'en'],
  HK: ['zh-HK', 'zh-TW', 'en-US', 'en'],
  TH: ['th-TH', 'th', 'en-US', 'en'],
  ID: ['id-ID', 'id', 'en-US', 'en'],
  MY: ['ms-MY', 'en-MY', 'en-US', 'en'],
  PH: ['en-PH', 'en-US', 'en'],
  IN: ['en-IN', 'hi-IN', 'en-US', 'en'],
  DE: ['de-DE', 'de', 'en-US', 'en'],
  FR: ['fr-FR', 'fr', 'en-US', 'en'],
  ES: ['es-ES', 'es', 'en-US', 'en'],
  IT: ['it-IT', 'it', 'en-US', 'en'],
  NL: ['nl-NL', 'nl', 'en-US', 'en'],
  RU: ['ru-RU', 'ru', 'en-US', 'en'],
  UA: ['uk-UA', 'ru-RU', 'en-US', 'en'],
  BR: ['pt-BR', 'pt', 'en-US', 'en'],
  PT: ['pt-PT', 'pt', 'en-US', 'en'],
  MX: ['es-MX', 'es', 'en-US', 'en'],
  TR: ['tr-TR', 'tr', 'en-US', 'en'],
  PL: ['pl-PL', 'pl', 'en-US', 'en'],
};

const CACHE_TTL_MS = 30 * 60 * 1000; // 30 minutes
const _geoCache = new Map();

function proxyKey(p) {
  if (!p || !p.host || !p.port) return 'direct';
  return `${(p.type || 'http').toLowerCase()}://${p.username || ''}@${p.host}:${p.port}`;
}

function httpGetViaLocalProxy(localProxyHost, localProxyPort, targetUrl, timeoutMs = 5000) {
  return new Promise((resolve, reject) => {
    const u = new URL(targetUrl);
    const req = http.request({
      host: localProxyHost,
      port: localProxyPort,
      method: 'GET',
      path: targetUrl,
      headers: {
        Host: u.host,
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/153.0.0.0 Safari/537.36',
        Accept: 'application/json',
      },
      timeout: timeoutMs,
    }, (res) => {
      let raw = '';
      res.on('data', (c) => { raw += c; });
      res.on('end', () => {
        if (res.statusCode >= 200 && res.statusCode < 300) {
          try { resolve(JSON.parse(raw)); } catch (e) { reject(e); }
        } else {
          reject(new Error(`HTTP ${res.statusCode}`));
        }
      });
    });
    req.on('timeout', () => { req.destroy(); reject(new Error('GeoIP Timeout')); });
    req.on('error', reject);
    req.end();
  });
}

function httpGetDirect(targetUrl, timeoutMs = 4500) {
  return new Promise((resolve, reject) => {
    const req = http.get(targetUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/153.0.0.0 Safari/537.36',
        Accept: 'application/json',
      },
      timeout: timeoutMs,
    }, (res) => {
      let raw = '';
      res.on('data', (c) => { raw += c; });
      res.on('end', () => {
        if (res.statusCode >= 200 && res.statusCode < 300) {
          try { resolve(JSON.parse(raw)); } catch (e) { reject(e); }
        } else {
          reject(new Error(`HTTP ${res.statusCode}`));
        }
      });
    });
    req.on('timeout', () => { req.destroy(); reject(new Error('GeoIP Timeout')); });
    req.on('error', reject);
  });
}

function normalizeIpApiResponse(j) {
  if (!j || j.status !== 'success') return null;
  const cc = String(j.countryCode || 'US').toUpperCase();
  const langs = COUNTRY_LANGS[cc] || ['en-US', 'en'];
  return {
    ip: j.query || '',
    countryCode: cc,
    country: j.country || cc,
    city: j.city || '',
    region: j.regionName || '',
    timezone: j.timezone || 'UTC',
    latitude: typeof j.lat === 'number' ? j.lat : 0,
    longitude: typeof j.lon === 'number' ? j.lon : 0,
    isp: j.isp || '',
    languages: langs,
    locale: langs[0],
  };
}

/**
 * Resolve exit IP, IANA Timezone, Languages, and GPS Coordinates through a profile's proxy
 * (supports both HTTP/HTTPS and SOCKS5 via temporary local proxy forwarder if needed).
 */
async function resolveGeoIp(proxyCfg, { forceFresh = false, existingForwarderUrl = null, timeoutMs = 5000 } = {}) {
  const key = proxyKey(proxyCfg);
  if (!forceFresh && _geoCache.has(key)) {
    const hit = _geoCache.get(key);
    if (Date.now() - hit.at < CACHE_TTL_MS) {
      return hit.data;
    }
    _geoCache.delete(key);
  }

  const endpoint = 'http://ip-api.com/json/?fields=status,message,country,countryCode,regionName,city,lat,lon,timezone,isp,query';
  let tempForwarder = null;

  try {
    let rawJson = null;
    if (existingForwarderUrl) {
      const u = new URL(existingForwarderUrl);
      rawJson = await httpGetViaLocalProxy(u.hostname, parseInt(u.port, 10), endpoint, timeoutMs);
    } else if (proxyCfg && proxyCfg.host && proxyCfg.port) {
      tempForwarder = await proxyHelper.createLocalProxyForwarder({
        type: proxyCfg.type || 'http',
        host: proxyCfg.host,
        port: proxyCfg.port,
        username: proxyCfg.username || '',
        password: proxyCfg.password || '',
      });
      const u = new URL(tempForwarder.url);
      rawJson = await httpGetViaLocalProxy(u.hostname, parseInt(u.port, 10), endpoint, timeoutMs);
    } else {
      rawJson = await httpGetDirect(endpoint, timeoutMs);
    }

    const parsed = normalizeIpApiResponse(rawJson);
    if (parsed && parsed.ip) {
      _geoCache.set(key, { at: Date.now(), data: parsed });
      return parsed;
    }
    return null;
  } catch {
    return null;
  } finally {
    if (tempForwarder) {
      try { await tempForwarder.close(); } catch {}
    }
  }
}

function clearGeoCache(proxyCfg) {
  if (!proxyCfg) _geoCache.clear();
  else _geoCache.delete(proxyKey(proxyCfg));
}

module.exports = {
  COUNTRY_LANGS,
  resolveGeoIp,
  clearGeoCache,
};
