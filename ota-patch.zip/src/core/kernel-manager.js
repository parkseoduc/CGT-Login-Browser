'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const http = require('node:http');
const https = require('node:https');
const { exec } = require('node:child_process');

const config = require('../config');
const eventBus = require('./event-bus');

const KERNELS_ROOT = path.join(config.DATA_DIR, 'kernels');
const MANIFEST_FILE = path.join(KERNELS_ROOT, 'manifest.json');
const ENGINES = ['chromium', 'firefox'];

const EXE_CANDIDATES = {
  chromium: ['Poly Browser.exe', 'chrome.exe', 'msedge.exe'],
  firefox: ['Poly Browser.exe', 'firefox.exe'],
};

const _downloading = new Set();

function normEngine(e) {
  const s = String(e == null ? 'chromium' : e).trim().toLowerCase();
  return ENGINES.includes(s) ? s : 'chromium';
}

function majorOf(v) {
  const n = parseInt(String(v || '').trim().replace(/^v/i, '').split('.')[0], 10);
  return Number.isFinite(n) && n > 0 ? n : 0;
}

function readFolderFullVersion(dir) {
  try {
    if (!dir || !fs.existsSync(dir)) return null;
    const files = fs.readdirSync(dir);
    for (const f of files) {
      const m = f.match(/^(\d+\.\d+\.\d+\.\d+)\.manifest$/i);
      if (m) return m[1];
    }
    const ini = path.join(dir, 'application.ini');
    if (fs.existsSync(ini)) {
      const txt = fs.readFileSync(ini, 'utf8');
      const m = txt.match(/^Version=([^\r\n]+)/m);
      if (m) return m[1].trim();
    }
  } catch {}
  return null;
}

function isPolyPatchedBinary(exePath) {
  if (!exePath) return false;
  const base = path.basename(exePath).toLowerCase();
  if (base === 'poly browser.exe') return true;
  if (exePath.toLowerCase().includes('antibrowser\\kernels')) return true;
  return false;
}

function emptyManifest() {
  return {
    version: 1,
    active: { chromium: null, firefox: null },
    installed: { chromium: {}, firefox: {} },
  };
}

function readManifest() {
  try {
    if (!fs.existsSync(MANIFEST_FILE)) return emptyManifest();
    const raw = JSON.parse(fs.readFileSync(MANIFEST_FILE, 'utf8'));
    const m = emptyManifest();
    for (const e of ENGINES) {
      if (raw?.active?.[e]) m.active[e] = String(raw.active[e]);
      if (raw?.installed?.[e] && typeof raw.installed[e] === 'object') {
        m.installed[e] = raw.installed[e];
      }
    }
    return m;
  } catch {
    return emptyManifest();
  }
}

function writeManifest(m) {
  fs.mkdirSync(KERNELS_ROOT, { recursive: true });
  const tmp = `${MANIFEST_FILE}.tmp-${process.pid}`;
  fs.writeFileSync(tmp, JSON.stringify(m, null, 2), 'utf8');
  fs.renameSync(tmp, MANIFEST_FILE);
}

function isCustomKernelInstalled() {
  const isWin = process.platform === 'win32';
  const portableExe = path.join(config.BASE_DIR, 'bin', 'chromium', isWin ? 'chrome.exe' : 'chrome');
  if (fs.existsSync(portableExe)) return true;

  const managed153 = path.join(KERNELS_ROOT, 'chromium', '153');
  if (fs.existsSync(managed153)) {
    const found = findExeInDir(managed153, 'chromium');
    if (found) return true;
  }

  const m = readManifest();
  if (m.installed && m.installed.chromium && m.installed.chromium['153']) {
    return true;
  }
  return false;
}

/**
 * Discover all installed kernels from:
 * 1. CGT-Login managed store (`data/kernels/<engine>/<major>`)
 * 2. Bundled portable Chromium (`bin/chromium/chrome.exe` - e.g. MyBrowser 153.0.7993.0)
 * 3. Installed PolyLogin kernels (`%LOCALAPPDATA%\AntiBrowser\kernels\<engine>\<major>`) if present
 * 4. System Chrome / Edge / Firefox fallbacks
 */
function listKernels(engineFilter = null, includeCatalog = false) {
  const m = readManifest();
  let manifestChanged = false;
  const results = [];
  const seenExes = new Set();

  const enginesToScan = engineFilter ? [normEngine(engineFilter)] : ENGINES;

  for (const eng of enginesToScan) {
    // 1. Managed kernels in data/kernels/<eng>/<major>
    const bucket = m.installed[eng] || {};
    for (const majorKey of Object.keys(bucket)) {
      const rec = bucket[majorKey];
      const dir = path.join(KERNELS_ROOT, eng, majorKey);
      const exePath = rec && rec.exe ? (path.isAbsolute(rec.exe) ? rec.exe : path.join(dir, rec.exe)) : null;
      if (!exePath || !fs.existsSync(exePath)) {
        delete bucket[majorKey];
        if (m.active[eng] === majorKey) m.active[eng] = null;
        manifestChanged = true;
        continue;
      }
      const fullVer = rec.version || readFolderFullVersion(path.dirname(exePath)) || `${majorKey}.0.0.0`;
      seenExes.add(exePath.toLowerCase());
      results.push({
        id: `${eng}-${majorKey}`,
        engine: eng,
        major: majorOf(fullVer) || Number(majorKey),
        version: fullVer,
        name: rec.name || `${eng === 'firefox' ? 'Firefox' : 'Chromium'} ${majorKey}`,
        exe: exePath,
        isPolyPatched: isPolyPatchedBinary(exePath),
        managed: true,
        installed: true,
        active: m.active[eng] === String(majorKey),
        sizeMb: rec.sizeMb || null,
        installedAt: rec.installedAt || null,
      });
    }

    // 2. Bundled portable Chromium in bin/chromium
    if (eng === 'chromium') {
      const portableDir = path.join(config.BASE_DIR, 'bin', 'chromium');
      const portableExe = path.join(portableDir, process.platform === 'win32' ? 'chrome.exe' : 'chrome');
      if (fs.existsSync(portableExe) && !seenExes.has(portableExe.toLowerCase())) {
        const fullVer = readFolderFullVersion(portableDir) || '153.0.7993.0';
        const maj = majorOf(fullVer) || 153;
        seenExes.add(portableExe.toLowerCase());
        results.push({
          id: `portable-chromium-${maj}`,
          engine: 'chromium',
          major: maj,
          version: fullVer,
          name: `CGT Chromium ${maj} Portable`,
          exe: portableExe,
          isPolyPatched: isPolyPatchedBinary(portableExe),
          managed: false,
          installed: true,
          active: !m.active.chromium || m.active.chromium === String(maj),
          sizeMb: Math.round(fs.statSync(portableExe).size / 1024 / 1024) || 4,
          installedAt: null,
        });
      }
    }

    // 3. Auto-discover PolyLogin kernels in %LOCALAPPDATA%\AntiBrowser\kernels\<eng>
    if (process.platform === 'win32' && process.env.LOCALAPPDATA) {
      const polyRoot = path.join(process.env.LOCALAPPDATA, 'AntiBrowser', 'kernels', eng);
      if (fs.existsSync(polyRoot)) {
        try {
          for (const sub of fs.readdirSync(polyRoot)) {
            const subDir = path.join(polyRoot, sub);
            if (!fs.statSync(subDir).isDirectory()) continue;
            const foundName = EXE_CANDIDATES[eng].find((c) => fs.existsSync(path.join(subDir, c)));
            if (!foundName) continue;
            const fullExe = path.join(subDir, foundName);
            if (seenExes.has(fullExe.toLowerCase())) continue;
            seenExes.add(fullExe.toLowerCase());
            const fullVer = readFolderFullVersion(subDir) || `${sub}.0.0.0`;
            const maj = majorOf(fullVer) || majorOf(sub) || 140;
            results.push({
              id: `poly-${eng}-${maj}`,
              engine: eng,
              major: maj,
              version: fullVer,
              name: `Poly ${eng === 'firefox' ? 'Firefox' : 'Chromium'} ${maj} (Native Patched)`,
              exe: fullExe,
              isPolyPatched: true,
              managed: false,
              installed: true,
              active: m.active[eng] === String(maj),
              sizeMb: null,
              installedAt: null,
            });
          }
        } catch {}
      }
    }

    // 4. System browser fallbacks
    if (eng === 'firefox' && process.platform === 'win32') {
      for (const ffPath of [
        'C:\\Program Files\\Mozilla Firefox\\firefox.exe',
        'C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe',
      ]) {
        if (fs.existsSync(ffPath) && !seenExes.has(ffPath.toLowerCase())) {
          seenExes.add(ffPath.toLowerCase());
          const fullVer = readFolderFullVersion(path.dirname(ffPath)) || '135.0';
          results.push({
            id: 'system-firefox',
            engine: 'firefox',
            major: majorOf(fullVer) || 135,
            version: fullVer,
            name: 'System Mozilla Firefox',
            exe: ffPath,
            isPolyPatched: false,
            managed: false,
            installed: true,
            active: !results.some((r) => r.engine === 'firefox' && r.active),
            sizeMb: null,
            installedAt: null,
          });
        }
      }
    }

    // 5. If includeCatalog is enabled, ensure official downloadable catalog kernels are present
    if (includeCatalog) {
      if (eng === 'chromium') {
        const chr153 = results.find((r) => r.engine === 'chromium' && r.major === 153 && r.installed);
        if (chr153) {
          chr153.mandatory = true;
          chr153.recommended = true;
          chr153.name = 'CGT Chromium 153 Core (Khuyên dùng)';
        } else {
          results.unshift({
            id: 'chromium-153-catalog',
            engine: 'chromium',
            major: 153,
            version: '153.0.7993.0',
            name: 'CGT Chromium 153 Core (Khuyên dùng)',
            exe: null,
            isPolyPatched: false,
            managed: true,
            installed: false,
            active: false,
            sizeMb: 215,
            mandatory: true,
            recommended: true,
            source: 'server',
            url: resolveCatalogUrl('chromium', 153),
            installedAt: null,
          });
        }
      } else if (eng === 'firefox') {
        if (!results.some((r) => r.engine === 'firefox' && r.major === 135)) {
          results.push({
            id: 'firefox-135-catalog',
            engine: 'firefox',
            major: 135,
            version: '135.0.1',
            name: 'CGT Firefox 135',
            exe: null,
            isPolyPatched: false,
            managed: true,
            installed: false,
            active: false,
            sizeMb: 142,
            mandatory: false,
            recommended: false,
            source: 'server',
            url: resolveCatalogUrl('firefox', 135),
            installedAt: null,
          });
        }
      }
    }
  }

  if (manifestChanged) writeManifest(m);

  // Ensure at least one active per engine if installed exists
  for (const eng of enginesToScan) {
    const group = results.filter((r) => r.engine === eng);
    if (group.length && !group.some((r) => r.active)) {
      group.sort((a, b) => b.major - a.major);
      group[0].active = true;
    }
  }

  results.sort((a, b) => {
    if (a.engine !== b.engine) return a.engine === 'chromium' ? -1 : 1;
    return b.major - a.major;
  });

  return results;
}

/**
 * Resolve exact kernel descriptor `{ exe, engine, major, version, isPolyPatched }` for a profile.
 */
function resolveKernelForProfile({ engine = 'chromium', kernelMajor = null, kernelPath = null } = {}) {
  const eng = normEngine(engine);
  const available = listKernels(eng);

  // 1. Pinned major version
  if (kernelMajor) {
    const pinnedMaj = majorOf(kernelMajor);
    const hit = available.find((k) => k.major === pinnedMaj);
    if (hit && fs.existsSync(hit.exe)) return hit;
  }

  // 2. Explicit valid kernel_path matching engine
  if (kernelPath && fs.existsSync(kernelPath)) {
    const byExe = available.find((k) => k.exe.toLowerCase() === kernelPath.toLowerCase());
    if (byExe) return byExe;
    const dirVer = readFolderFullVersion(path.dirname(kernelPath)) || (eng === 'firefox' ? '135.0' : '153.0.7993.0');
    return {
      id: 'custom-path',
      engine: eng,
      major: majorOf(dirVer) || 153,
      version: dirVer,
      name: path.basename(kernelPath),
      exe: kernelPath,
      isPolyPatched: isPolyPatchedBinary(kernelPath),
      installed: true,
      active: false,
    };
  }

  // 3. Active kernel for engine
  const active = available.find((k) => k.active) || available[0];
  if (active && fs.existsSync(active.exe)) return active;

  // 4. Fallback to config.getDefaultKernelPath() for chromium
  if (eng === 'chromium') {
    const def = config.getDefaultKernelPath();
    if (def && fs.existsSync(def)) {
      const fullVer = readFolderFullVersion(path.dirname(def)) || '130.0.6723.117';
      return {
        id: 'system-default',
        engine: 'chromium',
        major: majorOf(fullVer) || 130,
        version: fullVer,
        name: path.basename(def),
        exe: def,
        isPolyPatched: isPolyPatchedBinary(def),
        installed: true,
        active: true,
      };
    }
  }

  return null;
}

function setActiveKernel(engine, major) {
  const eng = normEngine(engine);
  const majStr = String(majorOf(major) || major);
  const available = listKernels(eng);
  const exists = available.find((k) => String(k.major) === majStr);
  if (!exists) return false;
  const m = readManifest();
  m.active[eng] = majStr;
  writeManifest(m);
  return true;
}

function removeKernel(engine, major) {
  const eng = normEngine(engine);
  const majStr = String(majorOf(major) || major);
  const dir = path.join(KERNELS_ROOT, eng, majStr);
  const m = readManifest();
  if (m.installed[eng] && m.installed[eng][majStr]) {
    delete m.installed[eng][majStr];
    if (m.active[eng] === majStr) m.active[eng] = null;
    writeManifest(m);
  }
  if (fs.existsSync(dir)) {
    fs.rmSync(dir, { recursive: true, force: true });
    return true;
  }
  return false;
}

function findExeInDir(dir, engine, depth = 0) {
  if (depth > 2 || !fs.existsSync(dir)) return null;
  const candidates = EXE_CANDIDATES[engine] || EXE_CANDIDATES.chromium;
  for (const c of candidates) {
    const p = path.join(dir, c);
    if (fs.existsSync(p)) return { exeDir: dir, exeName: c };
  }
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.isDirectory()) {
      const sub = findExeInDir(path.join(dir, entry.name), engine, depth + 1);
      if (sub) return sub;
    }
  }
  return null;
}

function extractArchive(archivePath, destDir) {
  fs.mkdirSync(destDir, { recursive: true });
  return new Promise((resolve, reject) => {
    exec(`tar.exe -xf "${archivePath}" -C "${destDir}"`, { windowsHide: true }, (err) => {
      if (!err) return resolve();
      const psCmd = `Expand-Archive -Path "${archivePath}" -DestinationPath "${destDir}" -Force`;
      exec(`powershell.exe -NoProfile -NonInteractive -Command "${psCmd}"`, { windowsHide: true }, (err2) => {
        if (err2) return reject(new Error(`Giải nén nhân thất bại: ${err2.message}`));
        resolve();
      });
    });
  });
}

async function installFromArchive({ engine = 'chromium', major = null, archivePath, sha256 = null, name = null }) {
  const eng = normEngine(engine);
  if (!archivePath || !fs.existsSync(archivePath)) {
    throw new Error(`Không tìm thấy gói nén nhân: ${archivePath}`);
  }

  if (sha256) {
    eventBus.publish('kernel:progress', { engine: eng, major, phase: 'verifying', percent: 90, speed: 'Đang kiểm tra SHA-256...' });
    const hash = crypto.createHash('sha256');
    const buf = fs.readFileSync(archivePath);
    hash.update(buf);
    const actual = hash.digest('hex').toLowerCase();
    if (actual !== String(sha256).trim().toLowerCase()) {
      throw new Error(`Sai mã kiểm tra SHA-256 (Kỳ vọng: ${sha256}, Thực tế: ${actual})`);
    }
  }

  const tmpDir = path.join(KERNELS_ROOT, '.tmp', `extract-${Date.now()}-${process.pid}`);
  fs.mkdirSync(tmpDir, { recursive: true });

  try {
    eventBus.publish('kernel:progress', { engine: eng, major, phase: 'extracting', percent: 95, speed: 'Đang giải nén...' });
    await extractArchive(archivePath, tmpDir);
    const found = findExeInDir(tmpDir, eng);
    if (!found) {
      throw new Error(`Gói nén không chứa tệp thực thi hợp lệ cho nhân ${eng}`);
    }

    const fullVer = readFolderFullVersion(found.exeDir) || (major ? `${major}.0.0.0` : '153.0.0.0');
    const resolvedMajor = String(majorOf(major) || majorOf(fullVer) || 153);
    const finalDir = path.join(KERNELS_ROOT, eng, resolvedMajor);

    fs.mkdirSync(path.dirname(finalDir), { recursive: true });
    if (fs.existsSync(finalDir)) {
      try { fs.rmSync(finalDir, { recursive: true, force: true }); } catch {}
    }

    if (path.resolve(found.exeDir) === path.resolve(tmpDir)) {
      try {
        fs.renameSync(tmpDir, finalDir);
      } catch {
        fs.mkdirSync(finalDir, { recursive: true });
        for (const entry of fs.readdirSync(tmpDir)) {
          const sPath = path.join(tmpDir, entry);
          const dPath = path.join(finalDir, entry);
          try { fs.renameSync(sPath, dPath); } catch {
            try { fs.copyFileSync(sPath, dPath); } catch {}
          }
        }
      }
    } else {
      try {
        fs.renameSync(found.exeDir, finalDir);
      } catch {
        fs.mkdirSync(finalDir, { recursive: true });
        for (const entry of fs.readdirSync(found.exeDir)) {
          const sPath = path.join(found.exeDir, entry);
          const dPath = path.join(finalDir, entry);
          try { fs.renameSync(sPath, dPath); } catch {
            try { fs.copyFileSync(sPath, dPath); } catch {}
          }
        }
      }
    }

    const sizeMb = Math.round(fs.statSync(archivePath).size / (1024 * 1024));
    const m = readManifest();
    m.installed[eng][resolvedMajor] = {
      exe: found.exeName,
      version: fullVer,
      name: name || `${eng === 'firefox' ? 'Firefox' : 'Chromium'} ${resolvedMajor}`,
      sizeMb,
      sha256: sha256 || null,
      installedAt: new Date().toISOString(),
    };
    if (!m.active[eng]) m.active[eng] = resolvedMajor;
    writeManifest(m);

    // Sync to bin/chromium so legacy portable loaders and config.getDefaultKernelPath find it immediately
    if (eng === 'chromium') {
      const binChromium = path.join(config.BASE_DIR, 'bin', 'chromium');
      const binExe = path.join(binChromium, process.platform === 'win32' ? 'chrome.exe' : 'chrome');
      if (!fs.existsSync(binExe)) {
        try {
          if (!fs.existsSync(binChromium)) fs.mkdirSync(binChromium, { recursive: true });
          for (const entry of fs.readdirSync(finalDir)) {
            const sPath = path.join(finalDir, entry);
            const dPath = path.join(binChromium, entry);
            if (!fs.existsSync(dPath)) {
              try { fs.copyFileSync(sPath, dPath); } catch {}
            }
          }
        } catch (cpErr) {
          console.warn('[KernelManager] Note: Could not sync to bin/chromium:', cpErr.message);
        }
      }
    }

    eventBus.publish('kernel:progress', { engine: eng, major: Number(resolvedMajor), phase: 'done', percent: 100, speed: 'Hoàn tất' });
    return {
      ok: true,
      engine: eng,
      major: Number(resolvedMajor),
      version: fullVer,
      exe: path.join(finalDir, found.exeName),
    };
  } finally {
    try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch {}
  }
}

function resolveCatalogUrl(eng, major) {
  const catalogFile = path.join(KERNELS_ROOT, 'catalog.json');
  const majKey = major ? String(majorOf(major) || major) : 'default';
  if (fs.existsSync(catalogFile)) {
    try {
      const cat = JSON.parse(fs.readFileSync(catalogFile, 'utf8'));
      const bucket = cat && cat[eng];
      if (bucket && (bucket[majKey] || bucket.default)) {
        const entry = bucket[majKey] || bucket.default;
        return typeof entry === 'string' ? entry : entry.url;
      }
    } catch {}
  }
  if (eng === 'chromium') {
    if (process.env.CGT_CHROMIUM_KERNEL_URL) return process.env.CGT_CHROMIUM_KERNEL_URL;
    return 'https://github.com/parkseoduc/CGT-Login-Browser/releases/download/v2.0-kernel/MyBrowser-153-win64.zip';
  }
  if (eng === 'firefox') {
    if (process.env.CGT_FIREFOX_KERNEL_URL) return process.env.CGT_FIREFOX_KERNEL_URL;
    return `https://github.com/parkseoduc/CGT-Login-Browser/releases/download/v2.0-kernel/CGTFirefox-${majorOf(major) || 152}-win64.zip`;
  }
  return '';
}

async function downloadAndInstall({ engine = 'chromium', major = null, url, sha256 = null, name = null }) {
  const eng = normEngine(engine);
  const lockKey = `${eng}:${major || 'latest'}`;
  if (_downloading.has(lockKey)) {
    return new Promise((resolve, reject) => {
      const onProgress = (data) => {
        if (!data || data.engine !== eng) return;
        if (data.phase === 'done') {
          eventBus.unsubscribe('kernel:progress', onProgress);
          resolve({ ok: true, engine: eng, major: Number(major || 153) });
        } else if (data.phase === 'error') {
          eventBus.unsubscribe('kernel:progress', onProgress);
          reject(new Error(data.message || 'Tải thất bại'));
        }
      };
      eventBus.subscribe('kernel:progress', onProgress);
      setTimeout(() => {
        eventBus.unsubscribe('kernel:progress', onProgress);
        resolve({ ok: true, engine: eng, major: Number(major || 153) });
      }, 300000);
    });
  }

  const targetUrl = url || resolveCatalogUrl(eng, major);
  if (!targetUrl) {
    throw new Error(`Vui lòng cung cấp URL tải gói nhân cho ${eng}`);
  }

  _downloading.add(lockKey);
  const tmpDir = path.join(KERNELS_ROOT, '.tmp');
  fs.mkdirSync(tmpDir, { recursive: true });
  const ext = targetUrl.endsWith('.tar.gz') || targetUrl.endsWith('.tgz') ? '.tar.gz' : '.zip';
  const tmpArchive = path.join(tmpDir, `dl-${eng}-${Date.now()}${ext}`);

  try {
    await new Promise((resolve, reject) => {
      const downloadStep = (reqUrl, redirects = 0) => {
        if (redirects > 10) return reject(new Error('Quá nhiều chuyển hướng HTTP'));
        const client = reqUrl.startsWith('https:') ? https : http;
        const req = client.get(reqUrl, {
          headers: { 'User-Agent': 'CGT-Login-Kernel-Manager/2.0' },
        }, (res) => {
          if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
            return downloadStep(new URL(res.headers.location, reqUrl).href, redirects + 1);
          }
          if (res.statusCode !== 200) {
            return reject(new Error(`Tải thất bại với mã HTTP ${res.statusCode}`));
          }
          const total = parseInt(res.headers['content-length'] || '0', 10);
          let received = 0;
          let lastTick = Date.now();
          let lastBytes = 0;
          const out = fs.createWriteStream(tmpArchive);

          res.on('data', (chunk) => {
            received += chunk.length;
            const now = Date.now();
            if (now - lastTick >= 500) {
              const bps = (received - lastBytes) / ((now - lastTick) / 1000);
              const speed = bps > 1048576 ? `${(bps / 1048576).toFixed(1)} MB/s` : `${Math.round(bps / 1024)} KB/s`;
              const percent = total > 0 ? Math.min(90, Math.round((received / total) * 90)) : 50;
              eventBus.publish('kernel:progress', { engine: eng, major, phase: 'downloading', received, total, percent, speed });
              lastTick = now;
              lastBytes = received;
            }
          });

          res.pipe(out);
          out.on('finish', () => out.close(() => resolve()));
          out.on('error', reject);
        });
        req.on('error', reject);
      };
      downloadStep(targetUrl);
    });

    return await installFromArchive({ engine: eng, major, archivePath: tmpArchive, sha256, name });
  } catch (err) {
    eventBus.publish('kernel:progress', { engine: eng, major, phase: 'error', percent: 0, message: err.message });
    throw err;
  } finally {
    _downloading.delete(lockKey);
    try { if (fs.existsSync(tmpArchive)) fs.unlinkSync(tmpArchive); } catch {}
  }
}

module.exports = {
  KERNELS_ROOT,
  ENGINES,
  normEngine,
  majorOf,
  readFolderFullVersion,
  listKernels,
  resolveKernelForProfile,
  setActiveKernel,
  removeKernel,
  installFromArchive,
  downloadAndInstall,
  isCustomKernelInstalled,
  resolveCatalogUrl,
};
