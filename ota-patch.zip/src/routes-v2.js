'use strict';

const config = require('./config');
const db = require('./db');
const auth = require('./auth');
const launcher = require('./launcher');
const cookiesModule = require('./cookies');
const synchronizer = require('./synchronizer');
const eventBus = require('./core/event-bus');
const kernelManager = require('./core/kernel-manager');
const shortcuts = require('./core/shortcuts');
const openapi = require('./openapi');
const cloudSync = require('./cloud-sync');
const rpaCatalog = require('./rpa/node-catalog');
const rpaExecutor = require('./rpa/executor');
const rpaTaskRunner = require('./rpa/task-runner');

// Wire dependencies into RPA engine & scheduler
rpaExecutor.init({ db, launcher, cookies: cookiesModule, eventBus });
rpaTaskRunner.init({ db, launcher, executor: rpaExecutor, eventBus });

let _schedulesArmed = false;
function ensureSchedulesArmed() {
  if (_schedulesArmed) return;
  _schedulesArmed = true;
  try { rpaTaskRunner.armAll(); } catch {}
}

function getMcpServer() {
  try {
    const mcp = require('./mcp/mcp-server');
    if (typeof mcp.init === 'function') {
      mcp.init({ db, launcher, executor: rpaExecutor, taskRunner: rpaTaskRunner, catalog: rpaCatalog });
    }
    return mcp;
  } catch {
    return null;
  }
}

/**
 * Security Guard against DNS Rebinding & Cross-Site Localhost Abuse
 * (Fixes PolyLogin's unauthenticated wildcard CORS vulnerability on localhost).
 */
function checkLocalOriginSecurity(req) {
  const host = String(req.headers.host || '').toLowerCase();
  if (host && !/^(127\.0\.0\.1|localhost|\[::1\])(:\d+)?$/.test(host)) {
    return { allowed: false, reason: 'Blocked non-loopback Host header (DNS Rebinding protection)' };
  }

  const origin = String(req.headers.origin || '').trim();
  if (origin && origin !== 'null') {
    const isTrustedLocalOrigin = /^(https?:\/\/(127\.0\.0\.1|localhost|\[::1\])(:\d+)?|file:\/\/|app:\/\/)/i.test(origin);
    if (!isTrustedLocalOrigin) {
      const configuredKey = process.env.CGT_API_KEY || '';
      const providedKey = req.headers['x-api-key'] || '';
      if (!configuredKey || providedKey !== configuredKey) {
        return { allowed: false, reason: `Untrusted cross-origin request blocked: ${origin}` };
      }
    }
  }

  const requiredApiKey = process.env.CGT_API_KEY || '';
  if (requiredApiKey && !origin) {
    // Allow internal UI requests from same-origin Referer, enforce key for external scripts when CGT_API_KEY is set
    const referer = String(req.headers.referer || '');
    const isInternalUi = /^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?\//i.test(referer);
    if (!isInternalUi && req.headers['x-api-key'] !== requiredApiKey) {
      return { allowed: false, reason: 'Invalid or missing x-api-key header' };
    }
  }

  return { allowed: true };
}

function enrichProfile(p, syncedSet) {
  let tags = [];
  try { tags = typeof p.tags === 'string' ? JSON.parse(p.tags || '[]') : (p.tags || []); } catch {}
  let ui = {};
  try { ui = typeof p.ui_config === 'string' ? JSON.parse(p.ui_config || '{}') : (p.ui_config || {}); } catch {}

  const running = launcher.isProfileRunning(p.id);
  const closing = launcher.isProfileClosing(p.id);
  const slot = launcher.getSlot(p.id);

  return {
    ...p,
    tags,
    ui,
    kernelEngine: p.engine || 'chromium',
    kernelMajor: p.kernel_major || 0,
    isRunning: running,
    running,
    closing,
    slot,
    cloudSynced: syncedSet ? syncedSet.has(p.id) : cloudSync.isProfileSynced(p.id),
  };
}

/**
 * Handle all CGT-Login v2.0 routes. Returns `true` if handled, `false` to fall through to legacy v1 routes.
 */
async function handleV2Routes(req, res, { pathname, method, reqUrl, sendJson, parseJsonBody }) {
  ensureSchedulesArmed();

  // Security check on all API & MCP routes
  if (pathname.startsWith('/api/') || pathname === '/mcp' || pathname === '/v3/api-docs') {
    const sec = checkLocalOriginSecurity(req);
    if (!sec.allowed) {
      sendJson(res, 403, { success: false, ok: false, error: sec.reason });
      return true;
    }
  }

  // ── 1. SSE Realtime Stream & OpenAPI Spec ──────────────────────────────────
  if (method === 'GET' && pathname === '/api/v1/events/stream') {
    eventBus.attachSse(req, res, {
      'Access-Control-Allow-Origin': req.headers.origin || '*',
    });
    // Push initial profile & sync snapshots immediately
    const snap = launcher.getStateSnapshot();
    res.write(`event: profile:state\ndata: ${JSON.stringify(snap)}\n\n`);
    res.write(`event: sync:status\ndata: ${JSON.stringify(synchronizer.getSyncStatus())}\n\n`);
    return true;
  }

  if (method === 'GET' && (pathname === '/v3/api-docs' || pathname === '/api/v1/openapi.json')) {
    sendJson(res, 200, openapi.buildOpenApiSpec(config.API_PORT));
    return true;
  }

  // Enhanced Status endpoint
  if (method === 'GET' && pathname === '/api/v1/status') {
    const runningProfiles = launcher.getRunningProfiles();
    const kernels = kernelManager.listKernels();
    sendJson(res, 200, {
      ok: true,
      status: 'ok',
      name: 'CGT-Login Antidetect Workstation API',
      version: '3.1.0',
      activeProfiles: runningProfiles.length,
      runningProfiles,
      closingIds: launcher.getClosingProfileIds(),
      kernels: config.getAvailableKernels(),
      managedKernels: kernels,
      defaultKernel: config.getDefaultKernelPath(),
      cloudSync: cloudSync.getStatus(),
    });
    return true;
  }

  // ── 2. MCP Streamable HTTP Endpoint (`/mcp` & `/api/v1/mcp/status`) ────────
  if (pathname === '/mcp') {
    const mcp = getMcpServer();
    const fn = mcp && (mcp.handleRequest || mcp.handle || mcp.handleHttpRequest);
    if (!fn) {
      sendJson(res, 503, { ok: false, error: 'MCP Server module initializing' });
      return true;
    }
    await fn(req, res);
    return true;
  }

  if (method === 'GET' && pathname === '/api/v1/mcp/status') {
    const mcp = getMcpServer();
    const status = mcp && typeof mcp.getStatus === 'function'
      ? mcp.getStatus(config.API_PORT)
      : { endpoint: `http://127.0.0.1:${config.API_PORT}/mcp`, tools: [] };
    sendJson(res, 200, { success: true, ok: true, data: status, ...status });
    return true;
  }

  // ── 3. Enhanced Profiles List, Filter, Trash, Tags & Shortcuts ─────────────
  if (method === 'GET' && pathname === '/api/v1/profiles') {
    const user = await auth.getUserFromRequest(req);
    const effectiveUserId = (user && user.owner_id) ? user.owner_id : (user ? user.id : null);
    const syncedSet = new Set(cloudSync.getSyncedIds());

    let list = db.listProfiles(effectiveUserId).map((p) => enrichProfile(p, syncedSet));

    if (user && (user.role === 'staff' || user.role === 'leader') && Array.isArray(user.assigned_groups) && user.assigned_groups.length > 0) {
      list = list.filter((p) => user.assigned_groups.includes(p.group_id));
    }

    // Query filters
    const qSearch = (reqUrl.searchParams.get('search') || '').trim().toLowerCase();
    const qGroup = reqUrl.searchParams.get('groupId');
    const qTag = reqUrl.searchParams.get('tag');
    const qEngine = reqUrl.searchParams.get('engine');

    if (qGroup) list = list.filter((p) => p.group_id === qGroup);
    if (qEngine) list = list.filter((p) => p.kernelEngine === qEngine.toLowerCase());
    if (qTag) list = list.filter((p) => Array.isArray(p.tags) && p.tags.includes(qTag));
    if (qSearch) {
      list = list.filter((p) =>
        (p.name || '').toLowerCase().includes(qSearch) ||
        (p.notes || '').toLowerCase().includes(qSearch) ||
        (p.id || '').toLowerCase().includes(qSearch)
      );
    }

    if (user && (user.safe_launch_mode || user.role === 'staff')) {
      list = list.map((p) => {
        const safe = { ...p };
        if (safe.proxy_pass) safe.proxy_pass = '••••••••';
        if (safe.proxy_password) safe.proxy_password = '••••••••';
        return safe;
      });
    }

    sendJson(res, 200, {
      success: true,
      ok: true,
      count: list.length,
      total: list.length,
      profiles: list,
      data: list,
    });
    return true;
  }

  // Move profiles to group
  if (method === 'POST' && pathname === '/api/v1/profiles/move') {
    const body = await parseJsonBody(req);
    const ids = body.profileIds || body.ids || [];
    const moved = db.moveProfilesToGroup(ids, body.groupId ?? body.group_id ?? null);
    db.addActivityLog({ action: 'profile.move', details: { count: moved, groupId: body.groupId } });
    sendJson(res, 200, { success: true, ok: true, moved });
    return true;
  }

  // Create Desktop Shortcuts (.lnk)
  if (method === 'POST' && pathname === '/api/v1/profiles/shortcuts') {
    const body = await parseJsonBody(req);
    const ids = body.profileIds || [];
    const profs = ids.map((id) => db.getProfile(id)).filter(Boolean).map((p) => ({ id: p.id, name: p.name }));
    const result = shortcuts.createShortcuts({
      profiles: body.profiles || profs,
      dir: body.dir || '',
      pattern: body.pattern || '{name}',
    });
    sendJson(res, 200, { success: result.ok, ...result });
    return true;
  }

  // Enhanced Batch Delete (supports Trash soft-delete by default or permanent=true)
  if (method === 'POST' && pathname === '/api/v1/profiles/batch-delete') {
    const body = await parseJsonBody(req);
    const ids = Array.isArray(body.profileIds) ? body.profileIds : (Array.isArray(body.ids) ? body.ids : []);
    for (const id of ids) {
      if (launcher.isProfileRunning(id)) {
        await launcher.stopProfile(id, 2000).catch(() => {});
      }
    }
    if (body.permanent) {
      for (const id of ids) await launcher.purgeProfileStorage(id);
      const deleted = db.hardDeleteProfiles(ids);
      db.addActivityLog({ action: 'profile.hard_delete_batch', details: { count: deleted } });
      sendJson(res, 200, { success: true, ok: true, deleted, permanent: true });
    } else {
      const trashed = db.softDeleteProfiles(ids);
      db.addActivityLog({ action: 'profile.soft_delete_batch', details: { count: trashed } });
      sendJson(res, 200, { success: true, ok: true, deleted: trashed, trashed, permanent: false });
    }
    return true;
  }

  // Enhanced Batch Start with optional auto-tiling
  if (method === 'POST' && pathname === '/api/v1/profiles/batch-start') {
    const body = await parseJsonBody(req);
    const ids = Array.isArray(body.profileIds) ? body.profileIds : [];
    const results = await Promise.all(ids.map(async (id) => {
      try {
        const r = await launcher.startProfile(id, body.overrides || {});
        return { profileId: id, success: true, ...r };
      } catch (err) {
        return { profileId: id, success: false, error: err.message };
      }
    }));
    if (body.arrangeLayout && body.arrangeLayout !== 'none') {
      setTimeout(() => {
        launcher.arrangeProfileWindows(ids, body.arrangeLayout, body.layoutOptions || {});
      }, 600);
    }
    sendJson(res, 200, { success: true, ok: true, results });
    return true;
  }

  // Profile sub-actions v2
  const profV2Match = pathname.match(/^\/api\/v1\/profiles\/([a-zA-Z0-9_-]+)\/(duplicate|new-fingerprint|fingerprint|show|clear-cache|permanent|cookies|open|close)$/);
  if (profV2Match) {
    const profileId = profV2Match[1];
    const sub = profV2Match[2];

    if (method === 'POST' && sub === 'duplicate') {
      const copy = db.duplicateProfile(profileId);
      if (!copy) { sendJson(res, 404, { success: false, ok: false, error: 'Profile not found' }); return true; }
      db.addActivityLog({ action: 'profile.duplicate', targetId: copy.id, details: { from: profileId } });
      sendJson(res, 201, { success: true, ok: true, profile: enrichProfile(copy), data: enrichProfile(copy) });
      return true;
    }

    if (method === 'POST' && (sub === 'new-fingerprint' || sub === 'fingerprint')) {
      const body = await parseJsonBody(req);
      const updated = db.regenerateProfileFingerprint(profileId, body);
      if (!updated) { sendJson(res, 404, { success: false, ok: false, error: 'Profile not found' }); return true; }
      sendJson(res, 200, { success: true, ok: true, profile: enrichProfile(updated), data: enrichProfile(updated) });
      return true;
    }

    if (method === 'POST' && sub === 'show') {
      const body = await parseJsonBody(req);
      const shown = launcher.showProfileWindow(profileId, Boolean(body.noActivate));
      sendJson(res, 200, { success: shown, ok: shown });
      return true;
    }

    if (method === 'POST' && sub === 'clear-cache') {
      const body = await parseJsonBody(req);
      const out = await cookiesModule.clearProfileData(profileId, {
        cookies: Boolean(body.cookies),
        cache: body.cache !== false,
      });
      sendJson(res, 200, { success: true, ...out });
      return true;
    }

    if (method === 'DELETE' && sub === 'permanent') {
      await launcher.purgeProfileStorage(profileId);
      db.hardDeleteProfiles([profileId]);
      db.addActivityLog({ action: 'profile.hard_delete', targetId: profileId });
      sendJson(res, 200, { success: true, ok: true, deleted: 1, permanent: true });
      return true;
    }

    // Multi-format Cookies GET/POST
    if (sub === 'cookies') {
      if (method === 'GET') {
        const autoLaunch = reqUrl.searchParams.get('autoLaunch') !== '0';
        const out = await cookiesModule.exportCookies(profileId, { autoLaunch });
        sendJson(res, 200, out);
        return true;
      }
      if (method === 'POST') {
        const body = await parseJsonBody(req);
        const raw = body.cookies !== undefined ? body.cookies : (body.text || body.raw || '');
        const out = await cookiesModule.importCookies(profileId, raw, {
          fallbackDomain: body.domain || '',
          deferIfClosed: Boolean(body.deferIfClosed),
        });
        sendJson(res, 200, out);
        return true;
      }
    }

    // PolyLogin/AdsPower compatible GET /open & /close aliases
    if ((method === 'GET' || method === 'POST') && sub === 'open') {
      const info = await launcher.startProfile(profileId);
      sendJson(res, 200, {
        success: true,
        ok: true,
        data: {
          id: profileId,
          pid: info.pid,
          debugPort: info.port,
          ws: { puppeteer: info.wsEndpoint, selenium: `127.0.0.1:${info.port}` },
          webSocketDebuggerUrl: info.wsEndpoint,
        },
        ...info,
      });
      return true;
    }

    if ((method === 'GET' || method === 'POST') && sub === 'close') {
      const out = await launcher.stopProfile(profileId);
      sendJson(res, 200, { success: true, ok: true, ...out });
      return true;
    }
  }

  // Soft Delete on DELETE /api/v1/profiles/:id (unless ?permanent=1)
  const singleDelMatch = pathname.match(/^\/api\/v1\/profiles\/([a-zA-Z0-9_-]+)$/);
  if (method === 'DELETE' && singleDelMatch) {
    const profileId = singleDelMatch[1];
    const permanent = reqUrl.searchParams.get('permanent') === '1' || reqUrl.searchParams.get('permanent') === 'true';
    if (launcher.isProfileRunning(profileId)) {
      await launcher.stopProfile(profileId, 2000).catch(() => {});
    }
    if (permanent) {
      await launcher.purgeProfileStorage(profileId);
      db.hardDeleteProfiles([profileId]);
      sendJson(res, 200, { success: true, ok: true, message: 'Profile permanently deleted', permanent: true });
    } else {
      db.softDeleteProfiles([profileId]);
      sendJson(res, 200, { success: true, ok: true, message: 'Profile moved to Trash', permanent: false });
    }
    return true;
  }

  // Trash Endpoints
  if (pathname === '/api/v1/trash' && method === 'GET') {
    const user = await auth.getUserFromRequest(req);
    const effectiveUserId = (user && user.owner_id) ? user.owner_id : (user ? user.id : null);
    const items = db.listTrashProfiles(effectiveUserId);
    sendJson(res, 200, { success: true, ok: true, count: items.length, profiles: items, data: items });
    return true;
  }

  if (pathname === '/api/v1/trash/restore' && method === 'POST') {
    const body = await parseJsonBody(req);
    const ids = body.profileIds || body.ids || [];
    const restored = db.restoreProfiles(ids);
    sendJson(res, 200, { success: true, ok: true, restored });
    return true;
  }

  if ((pathname === '/api/v1/trash/empty' || pathname === '/api/v1/trash/delete') && method === 'POST') {
    const body = await parseJsonBody(req);
    let ids = body.profileIds || body.ids;
    if (!Array.isArray(ids) || !ids.length) {
      ids = db.listTrashProfiles().map((p) => p.id);
    }
    for (const id of ids) await launcher.purgeProfileStorage(id);
    const deleted = db.hardDeleteProfiles(ids);
    sendJson(res, 200, { success: true, ok: true, deleted });
    return true;
  }

  // Tags Endpoints
  if (pathname === '/api/v1/tags') {
    if (method === 'GET') {
      const tags = db.listTags();
      sendJson(res, 200, { success: true, ok: true, tags, data: tags });
      return true;
    }
    if (method === 'POST') {
      const body = await parseJsonBody(req);
      const tag = db.createTag(body.name, body.color);
      sendJson(res, 201, { success: true, ok: true, tag, data: tag });
      return true;
    }
    if (method === 'PUT') {
      const body = await parseJsonBody(req);
      const ok = db.renameTag(body.oldName, body.newName);
      sendJson(res, 200, { success: ok, ok });
      return true;
    }
    if (method === 'DELETE') {
      const body = await parseJsonBody(req);
      const name = body.name || reqUrl.searchParams.get('name');
      const ok = db.deleteTag(name);
      sendJson(res, 200, { success: ok, ok });
      return true;
    }
  }

  // ── 4. Multi-Kernel Manager (`/api/v1/kernels/*`) ──────────────────────────
  if (pathname === '/api/v1/kernels' && method === 'GET') {
    const engine = reqUrl.searchParams.get('engine') || null;
    const list = kernelManager.listKernels(engine, true);
    const isInstalled = kernelManager.isCustomKernelInstalled ? kernelManager.isCustomKernelInstalled() : false;
    sendJson(res, 200, { success: true, ok: true, isCustomKernelInstalled: isInstalled, kernels: list, data: list });
    return true;
  }

  if (pathname === '/api/v1/kernel/check' && method === 'GET') {
    const isInstalled = kernelManager.isCustomKernelInstalled ? kernelManager.isCustomKernelInstalled() : false;
    sendJson(res, 200, {
      success: true,
      ok: true,
      isInstalled,
      version: '153.0.7993.0',
      url: kernelManager.resolveCatalogUrl ? kernelManager.resolveCatalogUrl('chromium', 153) : 'https://github.com/parkseoduc/CGT-Login-Browser/releases/download/v2.0-kernel/MyBrowser-153-win64.zip',
    });
    return true;
  }

  if (pathname === '/api/v1/kernels/download' && method === 'POST') {
    const body = await parseJsonBody(req);
    try {
      const out = await kernelManager.downloadAndInstall(body);
      sendJson(res, 200, { success: true, ...out });
    } catch (err) {
      sendJson(res, 400, { success: false, ok: false, error: err.message });
    }
    return true;
  }

  if (pathname === '/api/v1/kernels/install-local' && method === 'POST') {
    const body = await parseJsonBody(req);
    try {
      const out = await kernelManager.installFromArchive({
        engine: body.engine || 'chromium',
        major: body.major || null,
        archivePath: body.zipPath || body.archivePath || body.path,
        sha256: body.sha256 || null,
        name: body.name || null,
      });
      sendJson(res, 200, { success: true, ...out });
    } catch (err) {
      sendJson(res, 400, { success: false, ok: false, error: err.message });
    }
    return true;
  }

  if (pathname === '/api/v1/kernels/set-active' && method === 'POST') {
    const body = await parseJsonBody(req);
    const ok = kernelManager.setActiveKernel(body.engine || 'chromium', body.major);
    sendJson(res, 200, { success: ok, ok });
    return true;
  }

  const kernelDelMatch = pathname.match(/^\/api\/v1\/kernels\/(chromium|firefox)\/(\d+)$/);
  if (method === 'DELETE' && kernelDelMatch) {
    const ok = kernelManager.removeKernel(kernelDelMatch[1], kernelDelMatch[2]);
    sendJson(res, 200, { success: ok, ok });
    return true;
  }

  // ── 5. Multi-Window Action Sync 2.0 (`/api/v1/sync/*`) ─────────────────────
  if (pathname === '/api/v1/sync/options' && method === 'POST') {
    const body = await parseJsonBody(req);
    sendJson(res, 200, synchronizer.setOptions(body));
    return true;
  }

  if (pathname === '/api/v1/sync/set-master' && method === 'POST') {
    const body = await parseJsonBody(req);
    const st = await synchronizer.setMaster(body.masterId || body.id);
    sendJson(res, 200, st);
    return true;
  }

  if (pathname === '/api/v1/sync/pause-slave' && method === 'POST') {
    const body = await parseJsonBody(req);
    const st = synchronizer.pauseSlave(body.profileId || body.id, Boolean(body.paused));
    sendJson(res, 200, st);
    return true;
  }

  if (pathname === '/api/v1/sync/arrange' && method === 'POST') {
    const body = await parseJsonBody(req);
    const out = await synchronizer.arrangeWindows(body.profileIds || [], body.layout || 'grid', body.options || body);
    sendJson(res, 200, { success: true, ok: true, ...out });
    return true;
  }

  if (pathname === '/api/v1/sync/text' && method === 'POST') {
    const body = await parseJsonBody(req);
    let out;
    switch (body.action) {
      case 'typePerWindow':
        out = await synchronizer.typePerWindow(body.assignments || [], body.speed);
        break;
      case 'paste':
        out = await synchronizer.pasteText(body.text || '');
        break;
      case 'clear':
        out = await synchronizer.clearText();
        break;
      case 'type':
      default:
        out = await synchronizer.typeText(body.text || '', body.speed);
        break;
    }
    sendJson(res, 200, { success: out.ok, ...out });
    return true;
  }

  if (pathname === '/api/v1/sync/tabs' && method === 'POST') {
    const body = await parseJsonBody(req);
    const out = await synchronizer.controlTabs(body);
    sendJson(res, 200, { success: out.ok, ...out });
    return true;
  }

  // ── 6. Visual RPA Studio (53 Nodes), Tasks & Schedules (`/api/v1/rpa/*`) ───
  if (method === 'GET' && pathname === '/api/v1/rpa/catalog') {
    sendJson(res, 200, {
      success: true,
      ok: true,
      categories: rpaCatalog.CATEGORIES,
      nodes: rpaCatalog.NODE_CATALOG || rpaCatalog.NODES,
      condOps: rpaCatalog.COND_OPS,
      varTypes: rpaCatalog.VAR_TYPES,
      sysVars: rpaCatalog.SYS_VARS,
    });
    return true;
  }

  if (pathname === '/api/v1/rpa/flows' || pathname === '/api/v1/workflows') {
    if (method === 'GET') {
      const flows = db.listRpaFlows();
      sendJson(res, 200, { success: true, ok: true, flows, workflows: flows, data: flows });
      return true;
    }
    if (method === 'POST') {
      const body = await parseJsonBody(req);
      const saved = db.saveRpaFlow(body);
      sendJson(res, 200, { success: true, ok: true, flow: saved, data: saved });
      return true;
    }
  }

  const rpaFlowMatch = pathname.match(/^\/api\/v1\/rpa\/flows\/([a-zA-Z0-9_-]+)$/);
  if (rpaFlowMatch) {
    const flowId = rpaFlowMatch[1];
    if (method === 'GET') {
      const flow = db.getRpaFlow(flowId);
      if (!flow) { sendJson(res, 404, { success: false, ok: false, error: 'Flow not found' }); return true; }
      sendJson(res, 200, { success: true, ok: true, flow, data: flow });
      return true;
    }
    if (method === 'PUT') {
      const body = await parseJsonBody(req);
      const saved = db.saveRpaFlow({ ...body, id: flowId });
      sendJson(res, 200, { success: true, ok: true, flow: saved, data: saved });
      return true;
    }
    if (method === 'DELETE') {
      const ok = db.deleteRpaFlow(flowId);
      sendJson(res, 200, { success: ok, ok });
      return true;
    }
  }

  if (method === 'POST' && (pathname === '/api/v1/rpa/run' || pathname === '/api/v1/workflows/run')) {
    const body = await parseJsonBody(req);
    const flow = body.graph || body.flow || db.getRpaFlow(body.flowId || body.workflowId);
    if (!flow) {
      sendJson(res, 404, { success: false, ok: false, error: 'Không tìm thấy quy trình RPA cần chạy' });
      return true;
    }
    const profileIds = Array.isArray(body.profileIds)
      ? body.profileIds
      : (body.profileId ? [body.profileId] : []);
    if (!profileIds.length) {
      sendJson(res, 400, { success: false, ok: false, error: 'Vui lòng chọn ít nhất 1 hồ sơ để chạy quy trình' });
      return true;
    }

    const runId = body.runId || `run_${Date.now()}`;
    // Single debug run vs multi-profile Wave/Lane batch
    if (profileIds.length === 1 && body.wait === true) {
      const out = await rpaTaskRunner.runBatch({
        runId,
        taskId: body.taskId || '',
        flow,
        profileIds,
        config: { threads: 1, keepOpen: body.keepOpen !== false, ...(body.config || {}) },
      });
      sendJson(res, 200, { success: true, ok: true, runId, result: out });
      return true;
    }

    // Non-blocking background execution (streams logs via SSE `rpa:log` & `rpa:task-state`)
    rpaTaskRunner.runBatch({
      runId,
      taskId: body.taskId || '',
      flow,
      profileIds,
      config: body.config || {},
    }).catch((err) => {
      console.error('[RPA Batch Error]', err.message);
    });

    sendJson(res, 200, { success: true, ok: true, started: true, runId, totalProfiles: profileIds.length });
    return true;
  }

  if (method === 'POST' && pathname === '/api/v1/rpa/stop') {
    const body = await parseJsonBody(req);
    const runId = body.runId || body.taskId;
    if (runId) {
      rpaExecutor.stopRun(runId);
      rpaTaskRunner.stopBatch(runId);
    } else {
      rpaExecutor.stopAllRuns();
    }
    sendJson(res, 200, { success: true, ok: true });
    return true;
  }

  if (pathname === '/api/v1/rpa/tasks') {
    if (method === 'GET') {
      const tasks = db.listRpaTasks();
      sendJson(res, 200, { success: true, ok: true, tasks, data: tasks });
      return true;
    }
    if (method === 'POST') {
      const body = await parseJsonBody(req);
      const saved = db.saveRpaTask(body);
      sendJson(res, 200, { success: true, ok: true, task: saved, data: saved });
      return true;
    }
  }

  const rpaTaskMatch = pathname.match(/^\/api\/v1\/rpa\/tasks\/([a-zA-Z0-9_-]+)(?:\/(run))?$/);
  if (rpaTaskMatch) {
    const taskId = rpaTaskMatch[1];
    const act = rpaTaskMatch[2];
    if (method === 'POST' && act === 'run') {
      rpaTaskRunner.runTask(taskId).catch(() => {});
      sendJson(res, 200, { success: true, ok: true, started: true, taskId });
      return true;
    }
    if (method === 'DELETE' && !act) {
      const ok = db.deleteRpaTask(taskId);
      sendJson(res, 200, { success: ok, ok });
      return true;
    }
  }

  if (pathname === '/api/v1/rpa/schedules') {
    if (method === 'GET') {
      const schedules = db.listRpaSchedules();
      sendJson(res, 200, { success: true, ok: true, schedules, armed: rpaTaskRunner.listScheduled(), data: schedules });
      return true;
    }
    if (method === 'POST') {
      const body = await parseJsonBody(req);
      const saved = db.saveRpaSchedule(body);
      if (saved.enabled) rpaTaskRunner.scheduleTask(saved);
      else rpaTaskRunner.unscheduleTask(saved.id);
      sendJson(res, 200, { success: true, ok: true, schedule: saved, data: saved });
      return true;
    }
  }

  const rpaSchedMatch = pathname.match(/^\/api\/v1\/rpa\/schedules\/([a-zA-Z0-9_-]+)$/);
  if (method === 'DELETE' && rpaSchedMatch) {
    const id = rpaSchedMatch[1];
    rpaTaskRunner.unscheduleTask(id);
    const ok = db.deleteRpaSchedule(id);
    sendJson(res, 200, { success: ok, ok });
    return true;
  }

  if (pathname === '/api/v1/rpa/logs') {
    if (method === 'GET') {
      const taskId = reqUrl.searchParams.get('taskId') || null;
      const logs = db.listRpaLogs(taskId);
      sendJson(res, 200, { success: true, ok: true, logs, data: logs });
      return true;
    }
    if (method === 'DELETE') {
      const taskId = reqUrl.searchParams.get('taskId') || null;
      const cleared = db.clearRpaLogs(taskId);
      sendJson(res, 200, { success: true, ok: true, cleared });
      return true;
    }
  }

  // ── 7. Cloud Profile Data Sync E2EE (`/api/v1/cloud-sync/*`) ───────────────
  if (method === 'GET' && pathname === '/api/v1/cloud-sync/status') {
    const st = cloudSync.getStatus();
    sendJson(res, 200, { success: true, ok: true, data: st, ...st });
    return true;
  }

  if (method === 'POST' && pathname === '/api/v1/cloud-sync/settings') {
    const body = await parseJsonBody(req);
    const st = cloudSync.updateSettings(body);
    sendJson(res, 200, { success: true, ok: true, data: st, ...st });
    return true;
  }

  const cloudProvMatch = pathname.match(/^\/api\/v1\/cloud-sync\/(local|s3|gdrive|telegram)\/(connect|disconnect)$/);
  if (method === 'POST' && cloudProvMatch) {
    const dest = cloudProvMatch[1];
    const act = cloudProvMatch[2];
    if (act === 'connect') {
      const body = await parseJsonBody(req);
      const out = await cloudSync.connectProvider(dest, body);
      sendJson(res, 200, { success: true, ok: true, data: out, ...out });
    } else {
      const out = await cloudSync.disconnectProvider(dest);
      sendJson(res, 200, { success: true, ok: true, data: out, ...out });
    }
    return true;
  }

  const cloudProfMatch = pathname.match(/^\/api\/v1\/cloud-sync\/profiles\/([a-zA-Z0-9_-]+)\/(push|pull)$/);
  if (method === 'POST' && cloudProfMatch) {
    const profileId = cloudProfMatch[1];
    const act = cloudProfMatch[2];
    if (act === 'push') {
      if (launcher.isProfileRunning(profileId)) {
        sendJson(res, 400, { success: false, ok: false, error: 'Hãy đóng trình duyệt của hồ sơ trước khi đẩy dữ liệu lên đám mây.' });
        return true;
      }
      const out = await cloudSync.pushProfile(profileId);
      sendJson(res, 200, { success: true, ok: true, data: out, ...out });
    } else {
      if (launcher.isProfileRunning(profileId)) {
        sendJson(res, 400, { success: false, ok: false, error: 'Hãy đóng trình duyệt của hồ sơ trước khi khôi phục dữ liệu.' });
        return true;
      }
      const out = await cloudSync.pullProfile(profileId);
      sendJson(res, 200, { success: true, ok: true, data: out, ...out });
    }
    return true;
  }

  if (method === 'GET' && pathname === '/api/v1/cloud-sync/backups') {
    const dest = reqUrl.searchParams.get('dest') || undefined;
    const out = await cloudSync.listBackups(dest);
    const arr = Array.isArray(out) ? out : (out.backups || []);
    sendJson(res, 200, { success: true, ok: true, dest: out.dest, backups: arr, data: arr });
    return true;
  }

  // ── 8. Activity Logs (`/api/v1/activity-logs`) ─────────────────────────────
  if (pathname === '/api/v1/activity-logs') {
    if (method === 'GET') {
      const limit = Number(reqUrl.searchParams.get('limit')) || 200;
      const items = db.listActivityLogs(limit);
      sendJson(res, 200, { success: true, ok: true, items, data: items });
      return true;
    }
    if (method === 'POST') {
      const body = await parseJsonBody(req);
      const item = db.addActivityLog(body);
      sendJson(res, 201, { success: true, ok: true, item });
      return true;
    }
    if (method === 'DELETE') {
      const cleared = db.clearActivityLogs();
      sendJson(res, 200, { success: true, ok: true, cleared });
      return true;
    }
  }

  return false;
}

module.exports = {
  handleV2Routes,
  checkLocalOriginSecurity,
};
