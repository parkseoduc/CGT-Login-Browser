'use strict';

const nodeCatalog = require('./node-catalog');
const gsheetApi = require('./gsheet-api');
const executor = require('./executor');
const taskRunner = require('./task-runner');

function init(deps = {}) {
  executor.init(deps);
  taskRunner.init(deps);
}

module.exports = {
  init,
  nodeCatalog,
  gsheetApi,
  executor,
  taskRunner,
  ...nodeCatalog,
  runFlow: executor.runFlow,
  stopRun: executor.stopRun,
  runBatch: taskRunner.runBatch,
  runTask: taskRunner.runTask,
  stopBatch: taskRunner.stopBatch,
  computeNextFire: taskRunner.computeNextFire,
  scheduleTask: taskRunner.scheduleTask,
  unscheduleTask: taskRunner.unscheduleTask,
  armAll: taskRunner.armAll,
};
