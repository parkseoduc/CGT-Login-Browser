'use strict';

/**
 * CGT-Login v2.0 — Wave/Lane Multi-Threaded RPA Task Runner & Built-in Scheduler
 * - Spawns `threads` concurrent lanes (`0..threads-1`), each bound to a fixed screen tile
 *   (`516x210px` minimum floor, diagonal cascade on screen overflow).
 * - Executes: `launcher.startProfile` -> `executor.runFlow` -> `launcher.stopProfile` (unless `keepOpen: true`).
 * - Publishes live progress via `eventBus.publish('rpa:task-state', ...)` and persists run logs via `db`.
 * - Built-in Scheduler (`armAll`, `scheduleTask`, `unscheduleTask`, `computeNextFire`) supporting
 *   `once`, `interval`, `daily`, `weekly`, `monthly` with `startAt` / `endAt`.
 * Zero external npm dependencies.
 */

const { CdpClient } = require('../cdp');
const defaultEventBus = require('../core/event-bus');
const defaultExecutor = require('./executor');

const HARD_MIN_W = 516; // Chromium hard minimum outer window width on Windows
const MIN_H = 210;      // Usable window height floor (tab bar + omnibox + viewport)
const MAX_TIMEOUT_MS = 2_147_483_647; // Max signed 32-bit int for Node setTimeout (~24.8 days)

const _deps = {
  db: null,
  launcher: null,
  cookies: null,
  executor: defaultExecutor,
  eventBus: defaultEventBus,
};

function init(deps = {}) {
  if (deps.db) _deps.db = deps.db;
  if (deps.launcher) _deps.launcher = deps.launcher;
  if (deps.cookies) _deps.cookies = deps.cookies;
  if (deps.executor) _deps.executor = deps.executor;
  if (deps.eventBus) _deps.eventBus = deps.eventBus;
  if (_deps.executor && typeof _deps.executor.init === 'function') {
    _deps.executor.init({
      db: _deps.db,
      launcher: _deps.launcher,
      cookies: _deps.cookies,
      eventBus: _deps.eventBus,
    });
  }
}

function getDb() {
  if (_deps.db) return _deps.db;
  try { _deps.db = require('../db'); } catch { /* standalone mode */ }
  return _deps.db;
}

function getLauncher() {
  if (_deps.launcher) return _deps.launcher;
  try { _deps.launcher = require('../launcher'); } catch { /* standalone mode */ }
  return _deps.launcher;
}

function getExecutor() {
  return _deps.executor || defaultExecutor;
}

function getBus() {
  return _deps.eventBus || defaultEventBus;
}

// ─────────────────────────────────────────────────────────────────────────────
// CONFIG & SMART SCREEN LANE TILING
// ─────────────────────────────────────────────────────────────────────────────

const posInt = (v, d) => {
  const n = parseInt(v, 10);
  return Number.isFinite(n) && n > 0 ? n : d;
};

const nonNeg = (v, d) => {
  const n = parseInt(v, 10);
  return Number.isFinite(n) && n >= 0 ? n : d;
};

const posFloat = (v, d) => {
  const n = parseFloat(v);
  return Number.isFinite(n) && n > 0 ? n : d;
};

function normalizeRunConfig(raw = {}) {
  return {
    threads: posInt(raw.threads != null ? raw.threads : raw.concurrency, 1),
    openDelay: nonNeg(raw.openDelay != null ? raw.openDelay : raw.delayMs, 300),
    perRow: posInt(raw.perRow != null ? raw.perRow : raw.winCount, 4),
    winW: posInt(raw.winW != null ? raw.winW : raw.width, 520),
    winH: posInt(raw.winH != null ? raw.winH : raw.height, 640),
    winScale: posFloat(raw.winScale != null ? raw.winScale : raw.scale, 1),
    gap: nonNeg(raw.gap, 2),
    screenW: posInt(raw.screenW != null ? raw.screenW : raw.screenWidth, 1920),
    screenH: posInt(raw.screenH != null ? raw.screenH : raw.screenHeight, 1040),
    mouseSim: raw.mouseSim !== false,
    keepOpen: Boolean(raw.keepOpen || raw.autoClose === false),
    blank: raw.blank !== false,
    order: raw.order === 'random' ? 'random' : 'sequential',
  };
}

/**
 * Compute fixed screen tile `{ x, y, width, height }` for each lane (`0..threads-1`).
 * Enforces `516x210px` minimum floor and cascades diagonally when screen capacity overflows.
 */
function computeLaneTiles(threadsCount, rawConfig = {}) {
  const cfg = normalizeRunConfig(rawConfig);
  const n = Math.max(1, posInt(threadsCount, cfg.threads));
  const GAP = Math.max(cfg.gap, 2);
  const screenW = cfg.screenW;
  const screenH = cfg.screenH;

  const maxCols = Math.max(1, Math.floor((screenW + GAP) / (HARD_MIN_W + GAP)));
  const cols = Math.max(1, Math.min(cfg.perRow, maxCols, n));
  const neededRows = Math.ceil(n / cols);
  const maxRows = Math.max(1, Math.floor((screenH + GAP) / (MIN_H + GAP)));
  const rowsToPlace = Math.min(neededRows, maxRows);

  const fitW = Math.floor((screenW - GAP * (cols - 1)) / cols);
  const fitH = Math.floor((screenH - GAP * (rowsToPlace - 1)) / rowsToPlace);
  const cellW = Math.max(HARD_MIN_W, Math.min(cfg.winW, fitW));
  const cellH = Math.max(MIN_H, Math.min(cfg.winH, fitH));
  const onScreen = cols * maxRows;

  const tiles = [];
  for (let lane = 0; lane < n; lane += 1) {
    if (lane < onScreen) {
      const col = lane % cols;
      const row = Math.floor(lane / cols);
      tiles.push({
        lane,
        x: col * (cellW + GAP),
        y: row * (cellH + GAP),
        width: cellW,
        height: cellH,
        cascaded: false,
      });
    } else {
      const k = lane - onScreen + 1;
      const STEP = 32;
      const maxX = Math.max(0, screenW - cellW);
      const maxY = Math.max(0, screenH - cellH);
      tiles.push({
        lane,
        x: Math.min(maxX, k * STEP),
        y: Math.min(maxY, k * STEP),
        width: cellW,
        height: cellH,
        cascaded: true,
      });
    }
  }
  return {
    cols,
    rows: rowsToPlace,
    onScreenCapacity: onScreen,
    cellWidth: cellW,
    cellHeight: cellH,
    tiles,
  };
}

function shuffleArray(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function applyTaskInputs(flow, inputs) {
  if (!flow || !inputs || typeof inputs !== 'object' || !Object.keys(inputs).length) return flow;
  const graph = flow.graph ? (typeof flow.graph === 'string' ? JSON.parse(flow.graph) : flow.graph) : flow;
  if (!Array.isArray(graph.variables)) return flow;
  const patchedVars = graph.variables.map((v) => (
    v && v.name != null && Object.prototype.hasOwnProperty.call(inputs, v.name)
      ? { ...v, value: inputs[v.name] }
      : v
  ));
  if (flow.graph) {
    return { ...flow, graph: { ...graph, variables: patchedVars } };
  }
  return { ...graph, variables: patchedVars };
}

/**
 * Best-effort CDP window reposition when a profile was already open prior to lane assignment.
 */
async function applyWindowBoundsViaCdp(wsEndpoint, bounds) {
  if (!wsEndpoint || !bounds) return;
  let client = null;
  try {
    client = new CdpClient(wsEndpoint);
    await client.connect(2000);
    const { targetInfos = [] } = await client.send('Target.getTargets', {}, null, 2000);
    const pageTarget = targetInfos.find((t) => t.type === 'page') || targetInfos[0];
    if (pageTarget) {
      const win = await client.send('Browser.getWindowForTarget', { targetId: pageTarget.targetId }, null, 2000);
      if (win && win.windowId) {
        await client.send('Browser.setWindowBounds', {
          windowId: win.windowId,
          bounds: {
            left: bounds.x,
            top: bounds.y,
            width: bounds.width,
            height: bounds.height,
            windowState: 'normal',
          },
        }, null, 2000);
      }
    }
  } catch { /* best-effort */ } finally {
    if (client) client.close();
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// WAVE / LANE BATCH RUNNER
// ─────────────────────────────────────────────────────────────────────────────

// batchRunId -> batch state
const _activeBatches = new Map();
const _recentRunLogs = [];

function publishTaskState(payload) {
  const bus = getBus();
  if (bus && typeof bus.publish === 'function') {
    bus.publish('rpa:task-state', payload, { cacheSnapshot: true });
  }
}

function recordRunLog(entry) {
  _recentRunLogs.unshift(entry);
  if (_recentRunLogs.length > 300) _recentRunLogs.length = 300;
  const db = getDb();
  if (!db) return;
  try {
    if (typeof db.addRpaRunLog === 'function') db.addRpaRunLog(entry);
    else if (typeof db.saveRpaRunLog === 'function') db.saveRpaRunLog(entry);
    else if (typeof db.createRpaRunLog === 'function') db.createRpaRunLog(entry);
    else if (typeof db.recordRpaRun === 'function') db.recordRpaRun(entry);
  } catch { /* non-fatal */ }
}

function resolveFlowFromDb(flowOrId) {
  if (!flowOrId) return null;
  if (typeof flowOrId === 'object') return flowOrId;
  const db = getDb();
  if (!db) return null;
  const id = String(flowOrId);
  try {
    if (typeof db.getRpaFlow === 'function') {
      const f = db.getRpaFlow(id);
      if (f) return f;
    }
    if (typeof db.listRpaFlows === 'function') {
      const all = db.listRpaFlows() || [];
      const hit = all.find((f) => f && (String(f.id) === id || String(f.name) === id));
      if (hit) return hit;
    }
    if (typeof db.getAutomationScript === 'function') {
      const s = db.getAutomationScript(id);
      if (s) return s;
    }
  } catch { /* ignore */ }
  return null;
}

/**
 * Run a flow across `profileIds` using `threads` concurrent screen-tiled lanes.
 */
async function runBatch(opts = {}) {
  const batchRunId = String(opts.runId || `batch_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`);
  const taskId = String(opts.taskId || '');
  const rawFlow = opts.flow || resolveFlowFromDb(opts.flowId);
  if (!rawFlow) {
    throw new Error('Không tìm thấy quy trình RPA để thực thi');
  }

  const flow = applyTaskInputs(rawFlow, opts.inputs);
  const flowId = String(opts.flowId || rawFlow.id || '');
  const flowName = String(opts.flowName || rawFlow.name || 'Quy trình RPA');
  const taskName = String(opts.taskName || flowName);

  const rawIds = Array.isArray(opts.profileIds) ? opts.profileIds.filter(Boolean) : [];
  if (!rawIds.length) {
    throw new Error('Danh sách profileIds trống');
  }

  const cfg = normalizeRunConfig(opts.config || opts.run || {});
  const order = cfg.order === 'random' ? shuffleArray(rawIds) : rawIds.slice();
  const threads = Math.max(1, Math.min(cfg.threads, order.length));
  const layout = computeLaneTiles(threads, cfg);

  const startedAt = Date.now();
  const batchState = {
    runId: batchRunId,
    taskId,
    taskName,
    flowId,
    flowName,
    status: 'running',
    cancelled: false,
    threads,
    total: order.length,
    completed: 0,
    okCount: 0,
    failCount: 0,
    percent: 0,
    startedAt,
    endedAt: null,
    activeLanes: {},
    childRunIds: new Set(),
    results: [],
  };

  _activeBatches.set(batchRunId, batchState);

  const emitSnapshot = () => {
    publishTaskState({
      runId: batchState.runId,
      taskId: batchState.taskId,
      taskName: batchState.taskName,
      flowId: batchState.flowId,
      flowName: batchState.flowName,
      status: batchState.status,
      threads: batchState.threads,
      total: batchState.total,
      completed: batchState.completed,
      okCount: batchState.okCount,
      failCount: batchState.failCount,
      percent: batchState.total ? Math.round((batchState.completed / batchState.total) * 100) : 100,
      startedAt: batchState.startedAt,
      endedAt: batchState.endedAt,
      activeLanes: { ...batchState.activeLanes },
      results: batchState.results.slice(),
    });
  };

  emitSnapshot();

  // Staggered launch gate so consecutive browser launches are spaced by `openDelay` ms
  let firstGate = true;
  let gateChain = Promise.resolve();
  const sleep = (ms) => new Promise((r) => setTimeout(r, Math.max(0, ms)));
  const passLaunchGate = () => {
    const delay = firstGate ? 0 : cfg.openDelay;
    firstGate = false;
    const next = gateChain.then(() => (delay > 0 ? sleep(delay) : undefined));
    gateChain = next;
    return next;
  };

  const launcher = getLauncher();
  const executor = getExecutor();
  const db = getDb();

  let cursor = 0;

  async function runLane(laneIdx) {
    const tile = layout.tiles[laneIdx];
    const bounds = { x: tile.x, y: tile.y, width: tile.width, height: tile.height };

    while (!batchState.cancelled) {
      const idx = cursor;
      cursor += 1;
      if (idx >= order.length) return;

      const profileId = String(order[idx]);
      await passLaunchGate();
      if (batchState.cancelled) return;

      const childRunId = `${batchRunId}_L${laneIdx}_${idx + 1}`;
      batchState.childRunIds.add(childRunId);
      batchState.activeLanes[laneIdx] = { profileId, runId: childRunId, bounds, phase: 'starting' };
      emitSnapshot();

      const profStartedAt = Date.now();
      let ok = false;
      let errText = '';
      let skipped = 0;

      try {
        let launchInfo = null;
        if (launcher && typeof launcher.startProfile === 'function') {
          const launchOpts = {
            bounds,
            winBounds: bounds,
            scale: cfg.winScale,
            blank: cfg.blank !== false,
            // Compatible with both legacy and v2 launcher overrides
            window_x: bounds.x,
            window_y: bounds.y,
            screen_width: bounds.width,
            screen_height: bounds.height,
            ...(cfg.blank !== false ? { start_url: 'about:blank' } : {}),
            ...(cfg.winScale && cfg.winScale !== 1 ? { custom_flags: `--force-device-scale-factor=${cfg.winScale}` } : {}),
          };
          launchInfo = await launcher.startProfile(profileId, launchOpts);
          if (launchInfo && launchInfo.alreadyRunning && launchInfo.wsEndpoint) {
            await applyWindowBoundsViaCdp(launchInfo.wsEndpoint, bounds);
          }
        }

        if (batchState.cancelled) {
          throw new Error('stopped');
        }

        batchState.activeLanes[laneIdx] = { profileId, runId: childRunId, bounds, phase: 'executing' };
        emitSnapshot();

        const profMeta = (db && typeof db.getProfile === 'function' ? db.getProfile(profileId) : null) || { id: profileId };
        const res = await executor.runFlow({
          runId: childRunId,
          batchId: batchRunId,
          taskId,
          taskName,
          profileId,
          profile: profMeta,
          wsEndpoint: launchInfo ? launchInfo.wsEndpoint : undefined,
          userDataDir: launchInfo ? launchInfo.userDataDir : undefined,
          flow,
          flowId,
          flowName,
          inputs: opts.inputs,
          mouseSim: cfg.mouseSim,
          onLog: opts.onLog,
          isStopped: () => batchState.cancelled,
        });

        skipped = (res && res.skipped) || 0;
        ok = !!(res && res.ok) && skipped === 0;
        if (!ok) errText = (res && res.error) || (skipped ? `${skipped} bước lỗi` : 'Thực thi thất bại');
      } catch (err) {
        ok = false;
        errText = err && err.message ? err.message : String(err);
      } finally {
        batchState.childRunIds.delete(childRunId);
        delete batchState.activeLanes[laneIdx];

        if (!cfg.keepOpen && launcher && typeof launcher.stopProfile === 'function') {
          try {
            await launcher.stopProfile(profileId);
          } catch { /* ignore */ }
        }

        const profEndedAt = Date.now();
        batchState.completed += 1;
        if (ok) batchState.okCount += 1;
        else batchState.failCount += 1;

        batchState.results.push({
          profileId,
          lane: laneIdx,
          ok,
          skipped,
          error: errText || undefined,
          startedAt: profStartedAt,
          endedAt: profEndedAt,
          durationMs: profEndedAt - profStartedAt,
        });

        emitSnapshot();
      }
    }
  }

  try {
    await Promise.all(Array.from({ length: threads }, (_, lane) => runLane(lane)));
  } finally {
    batchState.endedAt = Date.now();
    batchState.status = batchState.cancelled
      ? 'stopped'
      : (batchState.okCount === batchState.results.length
        ? 'done'
        : (batchState.okCount === 0 ? 'error' : 'partial'));
    emitSnapshot();
    _activeBatches.delete(batchRunId);
  }

  const logEntry = {
    id: `runlog_${startedAt}_${Math.random().toString(36).slice(2, 6)}`,
    runId: batchRunId,
    taskId,
    taskName,
    flowId,
    flowName,
    status: batchState.status,
    threads,
    total: batchState.total,
    okCount: batchState.okCount,
    failCount: batchState.failCount,
    startedAt: batchState.startedAt,
    endedAt: batchState.endedAt,
    durationMs: batchState.endedAt - batchState.startedAt,
    results: batchState.results,
  };
  recordRunLog(logEntry);

  return logEntry;
}

function stopBatch(runIdOrTaskId) {
  const key = String(runIdOrTaskId || '');
  if (!key) return { ok: false };
  const executor = getExecutor();
  let matched = 0;
  for (const batch of _activeBatches.values()) {
    if (batch.runId === key || (batch.taskId && batch.taskId === key)) {
      batch.cancelled = true;
      matched += 1;
      for (const childId of batch.childRunIds) {
        executor.stopRun(childId);
      }
    }
  }
  return { ok: matched > 0, stoppedBatches: matched };
}

function isTaskRunning(taskId) {
  const key = String(taskId || '');
  for (const batch of _activeBatches.values()) {
    if (batch.taskId === key || batch.runId === key) return true;
  }
  return false;
}

function listActiveBatches() {
  return Array.from(_activeBatches.values()).map((b) => ({
    runId: b.runId,
    taskId: b.taskId,
    taskName: b.taskName,
    flowId: b.flowId,
    flowName: b.flowName,
    status: b.status,
    threads: b.threads,
    total: b.total,
    completed: b.completed,
    okCount: b.okCount,
    failCount: b.failCount,
    startedAt: b.startedAt,
    activeLanes: { ...b.activeLanes },
  }));
}

function listRunLogs(taskId = null) {
  const db = getDb();
  if (db) {
    try {
      if (typeof db.listRpaRunLogs === 'function') return db.listRpaRunLogs(taskId);
    } catch { /* fallback to memory */ }
  }
  if (!taskId) return _recentRunLogs.slice();
  return _recentRunLogs.filter((l) => l.taskId === taskId);
}

async function runTask(taskOrId) {
  let task = taskOrId;
  const db = getDb();
  if (typeof task === 'string' && db) {
    if (typeof db.getRpaTask === 'function') task = db.getRpaTask(task);
    else if (typeof db.listRpaTasks === 'function') {
      task = (db.listRpaTasks() || []).find((t) => t && String(t.id) === task);
    }
  }
  if (!task || typeof task !== 'object') {
    throw new Error('Không tìm thấy nhiệm vụ RPA');
  }
  if (task.id && isTaskRunning(task.id)) {
    throw new Error(`Nhiệm vụ "${task.name || task.id}" đang chạy`);
  }
  const flow = task.flow || resolveFlowFromDb(task.flowId || task.workflowId);
  if (!flow) {
    throw new Error(`Không tìm thấy quy trình (${task.flowId || ''}) của nhiệm vụ "${task.name || task.id}"`);
  }
  const profileIds = Array.isArray(task.profileIds)
    ? task.profileIds
    : (typeof task.profileIds === 'string' ? JSON.parse(task.profileIds || '[]') : []);
  const inputs = typeof task.inputs === 'string' ? JSON.parse(task.inputs || '{}') : (task.inputs || {});
  const runCfg = typeof task.run === 'string'
    ? JSON.parse(task.run || '{}')
    : (task.config || task.run || {});

  return runBatch({
    taskId: task.id || '',
    taskName: task.name || flow.name || 'Nhiệm vụ RPA',
    flow,
    flowId: flow.id,
    flowName: flow.name,
    profileIds,
    inputs: { ...inputs, ...(task.order ? {} : {}) },
    config: { ...runCfg, order: task.order || runCfg.order },
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// BUILT-IN TASK SCHEDULER (`once`, `interval`, `daily`, `weekly`, `monthly`)
// ─────────────────────────────────────────────────────────────────────────────

const WEEKDAY_MAP = {
  sunday: 0, sun: 0, 'chủ nhật': 0, cn: 0, '0': 0,
  monday: 1, mon: 1, 'thứ hai': 1, t2: 1, '1': 1,
  tuesday: 2, tue: 2, 'thứ ba': 2, t3: 2, '2': 2,
  wednesday: 3, wed: 3, 'thứ tư': 3, t4: 3, '3': 3,
  thursday: 4, thu: 4, 'thứ năm': 4, t5: 4, '4': 4,
  friday: 5, fri: 5, 'thứ sáu': 5, t6: 5, '5': 5,
  saturday: 6, sat: 6, 'thứ bảy': 6, t7: 6, '6': 6,
};

function parseTimestamp(v) {
  if (v == null || v === '') return NaN;
  if (typeof v === 'number') return Number.isFinite(v) ? v : NaN;
  const s = String(v).trim();
  if (/^\d{10,13}$/.test(s)) {
    const n = Number(s);
    return s.length === 10 ? n * 1000 : n;
  }
  const ms = new Date(s).getTime();
  return Number.isNaN(ms) ? NaN : ms;
}

function parseHHMM(timeStr, fallbackMs) {
  if (timeStr && typeof timeStr === 'string' && timeStr.includes(':')) {
    const parts = timeStr.trim().split(':');
    const hh = parseInt(parts[0], 10);
    const mm = parseInt(parts[1], 10);
    if (Number.isFinite(hh) && Number.isFinite(mm) && hh >= 0 && hh <= 23 && mm >= 0 && mm <= 59) {
      return { hh, mm };
    }
  }
  if (Number.isFinite(fallbackMs)) {
    const d = new Date(fallbackMs);
    return { hh: d.getHours(), mm: d.getMinutes() };
  }
  return null;
}

function daysInMonth(year, monthZeroBased) {
  return new Date(year, monthZeroBased + 1, 0).getDate();
}

/**
 * Compute next fire epoch timestamp (ms) >= `fromMs`, respecting `startAt` and `endAt`.
 * Returns `null` if schedule has expired or cannot fire.
 */
function computeNextFire(sched, fromMs = Date.now()) {
  if (!sched || typeof sched !== 'object') return null;
  const freq = String(sched.freq || sched.frequency || sched.type || 'once').toLowerCase();
  const startMs = parseTimestamp(sched.startAt);
  const endMs = parseTimestamp(sched.endAt);
  const hasStart = Number.isFinite(startMs) && startMs > 0;
  const hasEnd = Number.isFinite(endMs) && endMs > 0;
  const floor = hasStart ? Math.max(fromMs, startMs) : fromMs;

  let next = null;

  if (freq === 'once') {
    if (!hasStart) return null;
    next = startMs >= fromMs ? startMs : null;
  } else if (freq === 'interval') {
    const min = Math.max(1, parseInt(sched.intervalMin || sched.intervalMinutes || sched.interval, 10) || 1);
    const step = min * 60000;
    let t = hasStart ? startMs : fromMs;
    if (t < fromMs) {
      const k = Math.ceil((fromMs - t) / step);
      t += k * step;
    }
    next = t;
  } else if (freq === 'daily') {
    const hm = parseHHMM(sched.time, hasStart ? startMs : NaN);
    if (!hm) return null;
    const d = new Date(floor);
    d.setHours(hm.hh, hm.mm, 0, 0);
    let guard = 0;
    while ((d.getTime() < fromMs || (hasStart && d.getTime() < startMs)) && guard < 800) {
      d.setDate(d.getDate() + 1);
      guard += 1;
    }
    next = d.getTime();
  } else if (freq === 'weekly') {
    const hm = parseHHMM(sched.time, hasStart ? startMs : NaN);
    if (!hm) return null;
    const wdKey = String(sched.weekday != null ? sched.weekday : 'Monday').trim().toLowerCase();
    const targetDay = WEEKDAY_MAP[wdKey] != null ? WEEKDAY_MAP[wdKey] : 1;
    const d = new Date(floor);
    d.setHours(hm.hh, hm.mm, 0, 0);
    let guard = 0;
    while ((d.getDay() !== targetDay || d.getTime() < fromMs || (hasStart && d.getTime() < startMs)) && guard < 800) {
      d.setDate(d.getDate() + 1);
      guard += 1;
    }
    next = d.getTime();
  } else if (freq === 'monthly') {
    const hm = parseHHMM(sched.time, hasStart ? startMs : NaN);
    if (!hm) return null;
    const wantDay = Math.min(31, Math.max(1, parseInt(sched.monthday || sched.dayOfMonth || 1, 10) || 1));
    const d = new Date(floor);
    let yr = d.getFullYear();
    let mo = d.getMonth();
    const setCandidate = (y, m) => new Date(y, m, Math.min(wantDay, daysInMonth(y, m)), hm.hh, hm.mm, 0, 0);
    let cand = setCandidate(yr, mo);
    let guard = 0;
    while ((cand.getTime() < fromMs || (hasStart && cand.getTime() < startMs)) && guard < 120) {
      mo += 1;
      if (mo > 11) { mo = 0; yr += 1; }
      cand = setCandidate(yr, mo);
      guard += 1;
    }
    next = cand.getTime();
  }

  if (next == null || !Number.isFinite(next)) return null;
  if (hasEnd && next > endMs) return null;
  return next;
}

// Active armed schedules: id -> { sched, timer, nextFireAt }
const _armedSchedules = new Map();

function setLongTimeout(fn, targetEpochMs) {
  const now = Date.now();
  const remaining = Math.max(0, targetEpochMs - now);
  if (remaining > MAX_TIMEOUT_MS) {
    const t = setTimeout(() => {
      const entry = fn._holder;
      if (entry && !entry.disarmed) {
        entry.timer = setLongTimeout(fn, targetEpochMs);
      }
    }, MAX_TIMEOUT_MS);
    if (t.unref) t.unref();
    return t;
  }
  const t = setTimeout(fn, remaining);
  if (t.unref) t.unref();
  return t;
}

function unscheduleTask(id) {
  const key = String(id || '');
  const entry = _armedSchedules.get(key);
  if (!entry) return false;
  entry.disarmed = true;
  if (entry.timer) clearTimeout(entry.timer);
  _armedSchedules.delete(key);
  return true;
}

function disarmAll() {
  for (const id of Array.from(_armedSchedules.keys())) {
    unscheduleTask(id);
  }
}

function persistScheduleUpdate(sched) {
  const db = getDb();
  if (!db) return;
  const clean = { ...sched };
  delete clean._timer;
  delete clean._onFire;
  try {
    if (typeof db.saveRpaSchedule === 'function') db.saveRpaSchedule(clean);
    else if (typeof db.updateRpaSchedule === 'function') db.updateRpaSchedule(clean.id, clean);
  } catch { /* ignore */ }
}

function scheduleTask(sched) {
  if (!sched || !sched.id) return null;
  const id = String(sched.id);
  unscheduleTask(id);

  if (sched.enabled === false) {
    return { id, armed: false, nextFireAt: null };
  }

  const entry = { sched: { ...sched }, timer: null, nextFireAt: null, disarmed: false };

  const armNext = () => {
    if (entry.disarmed || entry.sched.enabled === false) return;
    const next = computeNextFire(entry.sched, Date.now() + 500);
    entry.nextFireAt = next;
    if (next == null) {
      _armedSchedules.delete(id);
      return;
    }

    const onFire = async () => {
      if (entry.disarmed) return;
      entry.sched.lastRun = Date.now();
      const bus = getBus();
      if (bus && typeof bus.publish === 'function') {
        bus.publish('rpa:schedule-fired', {
          scheduleId: id,
          name: entry.sched.name || '',
          taskId: entry.sched.taskId || '',
          firedAt: entry.sched.lastRun,
        });
      }

      // Execute linked task or direct flow+profileIds payload
      Promise.resolve().then(async () => {
        try {
          if (entry.sched.taskId) {
            await runTask(entry.sched.taskId);
          } else if (entry.sched.flowId && Array.isArray(entry.sched.profileIds)) {
            await runBatch({
              taskId: id,
              taskName: entry.sched.name || 'Lịch chạy tự động',
              flowId: entry.sched.flowId,
              profileIds: entry.sched.profileIds,
              config: entry.sched.config || entry.sched.run || {},
            });
          }
        } catch (err) {
          console.error(`[RPA Scheduler] Schedule "${entry.sched.name || id}" execution error:`, err.message);
        }
      });

      const freq = String(entry.sched.freq || entry.sched.frequency || 'once').toLowerCase();
      if (freq === 'once') {
        entry.sched.enabled = false;
        entry.nextFireAt = null;
        persistScheduleUpdate(entry.sched);
        _armedSchedules.delete(id);
        return;
      }

      persistScheduleUpdate(entry.sched);
      armNext();
    };
    onFire._holder = entry;
    entry.timer = setLongTimeout(onFire, next);
  };

  _armedSchedules.set(id, entry);
  armNext();
  return { id, armed: _armedSchedules.has(id), nextFireAt: entry.nextFireAt };
}

function armAll(schedulesInput = null) {
  disarmAll();
  let list = schedulesInput;
  if (!Array.isArray(list)) {
    const db = getDb();
    if (db && typeof db.listRpaSchedules === 'function') {
      try { list = db.listRpaSchedules() || []; } catch { list = []; }
    } else {
      list = [];
    }
  }
  const armed = [];
  for (const s of list) {
    if (s && s.id && s.enabled !== false) {
      armed.push(scheduleTask(s));
    }
  }
  return armed;
}

function listScheduled() {
  return Array.from(_armedSchedules.values()).map((e) => ({
    id: e.sched.id,
    name: e.sched.name || '',
    taskId: e.sched.taskId || '',
    freq: e.sched.freq || 'once',
    nextFireAt: e.nextFireAt,
    lastRun: e.sched.lastRun || null,
  }));
}

module.exports = {
  init,
  // Wave / Lane Runner
  HARD_MIN_W,
  MIN_H,
  normalizeRunConfig,
  computeLaneTiles,
  runBatch,
  runTask,
  stopBatch,
  stopTask: stopBatch,
  isTaskRunning,
  listActiveBatches,
  listRunLogs,
  // Scheduler
  computeNextFire,
  scheduleTask,
  unscheduleTask,
  armAll,
  disarmAll,
  listScheduled,
};
