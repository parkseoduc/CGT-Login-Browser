'use strict';

/**
 * CGT-Login v2.0 — Graph-based Instruction-Pointer RPA Executor
 * Runs directly over `CdpClient` (`../cdp`) with ZERO external npm dependencies.
 * Supports:
 *   - Visual Flow Graph (`{ nodes, connections/edges, variables, settings }`)
 *   - Nested/Linear Steps fallback (`{ steps: [...] }` or `[...]`)
 *   - All 53 catalog nodes (GENERAL, BROWSER, WEB, DATA, FLOW, FILE, API, AI, OTHER)
 *   - Cancellation via `stopRun(runId)` & live SSE logs via `eventBus.publish('rpa:log', ...)`
 */

const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const vm = require('node:vm');
const crypto = require('node:crypto');
const cp = require('node:child_process');

const { CdpClient, readDevToolsEndpoint, waitForDevToolsEndpoint } = require('../cdp');
const defaultEventBus = require('../core/event-bus');
const gsheetApi = require('./gsheet-api');

// Injected dependencies (lazy require fallback to avoid circular require at load time)
const _deps = {
  db: null,
  launcher: null,
  cookies: null,
  eventBus: defaultEventBus,
};

function init(deps = {}) {
  if (deps.db) _deps.db = deps.db;
  if (deps.launcher) _deps.launcher = deps.launcher;
  if (deps.cookies) _deps.cookies = deps.cookies;
  if (deps.eventBus) _deps.eventBus = deps.eventBus;
}

function getDb() {
  if (_deps.db) return _deps.db;
  try { _deps.db = require('../db'); } catch { /* optional in standalone test */ }
  return _deps.db;
}

function getLauncher() {
  if (_deps.launcher) return _deps.launcher;
  try { _deps.launcher = require('../launcher'); } catch { /* optional in standalone test */ }
  return _deps.launcher;
}

function getBus() {
  return _deps.eventBus || defaultEventBus;
}

class StopSignal extends Error {
  constructor(reason = 'stopped') {
    super(reason);
    this.name = 'StopSignal';
    this.reason = reason;
  }
}

const MAX_STEPS = 200000;
const MAX_ITERS = 100000;

// Active run registry: runId -> { runId, stopped, startedAt, profileId, flowId, flowName }
const activeRuns = new Map();

function stopRun(runId) {
  if (!runId) return { ok: false, error: 'Missing runId' };
  const st = activeRuns.get(String(runId));
  if (!st) return { ok: false, found: false };
  st.stopped = true;
  return { ok: true, runId: String(runId) };
}

function stopAllRuns() {
  let count = 0;
  for (const st of activeRuns.values()) {
    st.stopped = true;
    count += 1;
  }
  return { ok: true, stoppedCount: count };
}

function isRunActive(runId) {
  const st = activeRuns.get(String(runId || ''));
  return !!(st && !st.stopped);
}

function listActiveRuns() {
  return Array.from(activeRuns.values()).map((r) => ({
    runId: r.runId,
    profileId: r.profileId,
    flowId: r.flowId,
    flowName: r.flowName,
    startedAt: r.startedAt,
    stopped: r.stopped,
  }));
}

// ─────────────────────────────────────────────────────────────────────────────
// KEYBOARD MAPPING (JS keyCode -> CDP key / code / windowsVirtualKeyCode)
// ─────────────────────────────────────────────────────────────────────────────

const KEYCODE_MAP = {
  3: 'Cancel', 8: 'Backspace', 9: 'Tab', 12: 'Clear', 13: 'Enter', 16: 'Shift',
  17: 'Control', 18: 'Alt', 19: 'Pause', 20: 'CapsLock', 27: 'Escape', 32: ' ',
  33: 'PageUp', 34: 'PageDown', 35: 'End', 36: 'Home', 37: 'ArrowLeft', 38: 'ArrowUp',
  39: 'ArrowRight', 40: 'ArrowDown', 41: 'Select', 42: 'PrintScreen', 43: 'Execute',
  45: 'Insert', 46: 'Delete', 47: 'Help', 91: 'Meta', 92: 'Meta', 93: 'ContextMenu',
  95: 'Standby', 144: 'NumLock', 145: 'ScrollLock',
  112: 'F1', 113: 'F2', 114: 'F3', 115: 'F4', 116: 'F5', 117: 'F6',
  118: 'F7', 119: 'F8', 120: 'F9', 121: 'F10', 122: 'F11', 123: 'F12',
  124: 'F13', 125: 'F14', 126: 'F15', 127: 'F16', 128: 'F17', 129: 'F18',
  130: 'F19', 131: 'F20', 132: 'F21', 133: 'F22', 134: 'F23', 135: 'F24',
  186: ';', 187: '=', 188: ',', 189: '-', 190: '.', 191: '/', 192: '`',
  219: '[', 220: '\\', 221: ']', 222: "'", 226: '\\',
  106: '*', 107: '+', 108: ',', 109: '-', 110: '.', 111: '/',
  166: 'BrowserBack', 167: 'BrowserForward', 168: 'BrowserRefresh',
  174: 'AudioVolumeDown', 175: 'AudioVolumeUp',
  176: 'MediaTrackNext', 177: 'MediaTrackPrevious', 178: 'MediaStop', 179: 'MediaPlayPause',
  180: 'LaunchMail', 181: 'AudioVolumeMute', 182: 'AudioVolumeDown', 183: 'AudioVolumeUp',
  225: 'AltGraph', 255: 'WakeUp',
};

const KEYNAME_TO_VK = {
  Backspace: 8, Tab: 9, Enter: 13, Shift: 16, Control: 17, Alt: 18, Pause: 19,
  CapsLock: 20, Escape: 27, Space: 32, ' ': 32, PageUp: 33, PageDown: 34,
  End: 35, Home: 36, ArrowLeft: 37, ArrowUp: 38, ArrowRight: 39, ArrowDown: 40,
  Insert: 45, Delete: 46, Meta: 91, ContextMenu: 93,
  F1: 112, F2: 113, F3: 114, F4: 115, F5: 116, F6: 117,
  F7: 118, F8: 119, F9: 120, F10: 121, F11: 122, F12: 123,
};

function keySpecFromCodeOrName(raw) {
  if (raw == null) return null;
  const s = String(raw).trim();
  const n = Number(s);
  if (Number.isInteger(n) && s !== '') {
    if (KEYCODE_MAP[n]) {
      const k = KEYCODE_MAP[n];
      return { key: k, code: k === ' ' ? 'Space' : k, vk: n };
    }
    if (n >= 65 && n <= 90) {
      const ch = String.fromCharCode(n).toLowerCase();
      return { key: ch, code: `Key${String.fromCharCode(n)}`, vk: n, text: ch };
    }
    if (n >= 48 && n <= 57) {
      const ch = String.fromCharCode(n);
      return { key: ch, code: `Digit${ch}`, vk: n, text: ch };
    }
    if (n >= 96 && n <= 105) {
      const ch = String(n - 96);
      return { key: ch, code: `Numpad${ch}`, vk: n, text: ch };
    }
    return null;
  }
  if (KEYNAME_TO_VK[s]) {
    return { key: s === 'Space' ? ' ' : s, code: s === ' ' ? 'Space' : s, vk: KEYNAME_TO_VK[s] };
  }
  if (s.length === 1) {
    const upper = s.toUpperCase().charCodeAt(0);
    return { key: s, code: /[a-z]/i.test(s) ? `Key${s.toUpperCase()}` : '', vk: upper, text: s };
  }
  return { key: s, code: s, vk: 0 };
}

function modifierBit(key) {
  if (key === 'Alt' || key === 'AltGraph') return 1;
  if (key === 'Control') return 2;
  if (key === 'Meta') return 4;
  if (key === 'Shift') return 8;
  return 0;
}

// ─────────────────────────────────────────────────────────────────────────────
// PURE HELPERS (TOTP 2FA, CSV, INTERPOLATION, CONDITIONS, GRAPH NORMALIZATION)
// ─────────────────────────────────────────────────────────────────────────────

function nowIso() {
  return new Date().toISOString();
}

function ensureDir(dir) {
  if (!dir) return;
  try { fs.mkdirSync(dir, { recursive: true }); } catch { /* ignore */ }
}

function safeName(s) {
  return String(s || '').replace(/[\\/:*?"<>|]/g, '_').trim() || 'file';
}

function uniquePath(dir, base, ext) {
  let name = `${base}${ext}`;
  let i = 1;
  while (fs.existsSync(path.join(dir, name))) {
    name = `${base}-${i}${ext}`;
    i += 1;
  }
  return path.join(dir, name);
}

function toCsv(rows) {
  const esc = (v) => {
    const s = v == null ? '' : (typeof v === 'object' ? JSON.stringify(v) : String(v));
    return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return rows.map((r) => (Array.isArray(r) ? r : [r]).map(esc).join(',')).join('\r\n');
}

function parseCsv(text, sep = ',') {
  const rows = [];
  let row = [];
  let cur = '';
  let q = false;
  for (let i = 0; i < text.length; i += 1) {
    const c = text[i];
    if (q) {
      if (c === '"') {
        if (text[i + 1] === '"') { cur += '"'; i += 1; } else q = false;
      } else cur += c;
    } else if (c === '"') q = true;
    else if (c === sep) { row.push(cur); cur = ''; }
    else if (c === '\n') { row.push(cur); rows.push(row); row = []; cur = ''; }
    else if (c === '\r') { /* skip */ }
    else cur += c;
  }
  if (cur !== '' || row.length) {
    row.push(cur);
    rows.push(row);
  }
  return rows;
}

function parseKvBlock(text, sep = ':') {
  const out = {};
  const s = String(text == null ? '' : text).trim();
  if (!s) return out;
  if (s.startsWith('{')) {
    try {
      const o = JSON.parse(s);
      if (o && typeof o === 'object') {
        Object.entries(o).forEach(([k, v]) => {
          out[k] = v == null ? '' : (typeof v === 'object' ? JSON.stringify(v) : String(v));
        });
        return out;
      }
    } catch { /* fall through */ }
  }
  s.split(/\r?\n/).forEach((line) => {
    const t = line.trim();
    if (!t) return;
    const i = t.indexOf(sep);
    if (i < 0) { out[t] = ''; return; }
    out[t.slice(0, i).trim()] = t.slice(i + 1).trim();
  });
  return out;
}

/**
 * Pure `node:crypto` RFC-6238 SHA1 TOTP generator.
 * Accepts raw Base32 secret OR `otpauth://totp/...?secret=XXXX` URI.
 */
function base32Decode(secretInput) {
  let raw = String(secretInput || '').trim();
  if (/^otpauth:\/\//i.test(raw)) {
    try {
      const u = new URL(raw);
      raw = u.searchParams.get('secret') || raw;
    } catch { /* keep raw */ }
  }
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  const clean = raw.toUpperCase().replace(/[^A-Z2-7]/g, '');
  let bits = '';
  for (const c of clean) {
    const v = alphabet.indexOf(c);
    if (v >= 0) bits += v.toString(2).padStart(5, '0');
  }
  const bytes = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) {
    bytes.push(parseInt(bits.slice(i, i + 8), 2));
  }
  return Buffer.from(bytes);
}

function totp(secret, { digits = 6, period = 30, algo = 'sha1', timestamp = Date.now() } = {}) {
  const key = base32Decode(secret);
  if (!key.length) throw new Error('Khóa 2FA Base32 không hợp lệ');
  const counter = Math.floor(timestamp / 1000 / period);
  const buf = Buffer.alloc(8);
  buf.writeUInt32BE(Math.floor(counter / 2 ** 32), 0);
  buf.writeUInt32BE(counter >>> 0, 4);
  const hmac = crypto.createHmac(algo, key).update(buf).digest();
  const offset = hmac[hmac.length - 1] & 0x0f;
  const code = ((hmac[offset] & 0x7f) << 24)
    | ((hmac[offset + 1] & 0xff) << 16)
    | ((hmac[offset + 2] & 0xff) << 8)
    | (hmac[offset + 3] & 0xff);
  return String(code % (10 ** digits)).padStart(digits, '0');
}

function coerceVar(value, type) {
  if (value == null) return value;
  try {
    switch (type) {
      case 'Number': return value === '' ? '' : Number(value);
      case 'Boolean': return value === true || value === 'true' || value === '1' || value === 1;
      case 'Array':
      case 'Object':
        return typeof value === 'string' && value.trim() ? JSON.parse(value) : value;
      default:
        return value;
    }
  } catch {
    return value;
  }
}

function getPath(obj, pathStr) {
  const raw = String(pathStr == null ? '' : pathStr).trim();
  if (!raw) return obj;
  const parts = raw.replace(/\[(\w+)\]/g, '.$1').split('.').filter((p) => p !== '');
  let cur = obj;
  for (const p of parts) {
    if (cur == null) return undefined;
    cur = cur[p];
  }
  return cur;
}

function interp(str, ctx, opts) {
  if (str == null || typeof str !== 'string') return str;
  const jsonSafe = !!(opts && opts.jsonSafe);
  const vars = (ctx && ctx.vars) || {};
  const sys = (ctx && ctx.sys) || {};
  const look = (name) => {
    const key = String(name).trim();
    if (key in vars) return vars[key];
    if (key in sys) return sys[key];
    if (key.includes('.') || key.includes('[')) {
      const root = key.replace(/\[(\w+)\]/g, '.$1').split('.')[0];
      if (root in vars) return getPath(vars, key);
      if (root in sys) return getPath(sys, key);
    }
    return undefined;
  };
  const re = jsonSafe
    ? /\$\{([^}]+)\}|\{\{([^}]+)\}\}|\{([A-Za-z_$][\w$]*)\}/g
    : /\$\{([^}]+)\}|\{\{([^}]+)\}\}|\{([^}]+)\}/g;
  return str.replace(re, (m, a, b, c) => {
    const v = look(a || b || c);
    if (v == null) return jsonSafe ? m : '';
    return typeof v === 'object' ? JSON.stringify(v) : String(v);
  });
}

function compare(left, op, right) {
  const exists = left != null && left !== '';
  const numL = Number(left);
  const numR = Number(right);
  const bothNum = !Number.isNaN(numL) && !Number.isNaN(numR) && String(left).trim() !== '' && String(right).trim() !== '';
  const list = () => String(right == null ? '' : right).split(/[\n,]/).map((s) => s.trim()).filter(Boolean);
  switch (op) {
    case 'Tồn tại': case 'exists': return exists;
    case 'Không tồn tại': case '!exists': return !exists;
    case 'Bằng': case '==': return bothNum ? numL === numR : String(left) === String(right);
    case 'Không bằng': case '!=': return bothNum ? numL !== numR : String(left) !== String(right);
    case 'Nhỏ hơn': case '<': return !Number.isNaN(numL) && !Number.isNaN(numR) && String(left).trim() !== '' && String(right).trim() !== '' ? numL < numR : false;
    case 'Nhỏ hơn hoặc bằng': case '<=': return !Number.isNaN(numL) && !Number.isNaN(numR) && String(left).trim() !== '' && String(right).trim() !== '' ? numL <= numR : false;
    case 'Lớn hơn': case 'Nhiều hơn': case '>': return !Number.isNaN(numL) && !Number.isNaN(numR) && String(left).trim() !== '' && String(right).trim() !== '' ? numL > numR : false;
    case 'Lớn hơn hoặc bằng': case 'Nhiều hơn hoặc bằng': case '>=': return !Number.isNaN(numL) && !Number.isNaN(numR) && String(left).trim() !== '' && String(right).trim() !== '' ? numL >= numR : false;
    case 'Bao gồm': case 'includes': return String(left).includes(String(right));
    case 'Không bao gồm': case '!includes': return !String(left).includes(String(right));
    case 'Nằm trong': case 'Một trong': case 'in': return list().includes(String(left));
    case 'Không nằm trong': case 'Không nằm trong số đó': case '!in': return !list().includes(String(left));
    default: return false;
  }
}

function fmtTime(fmt) {
  const d = new Date();
  const p2 = (n) => String(n).padStart(2, '0');
  const Y = d.getFullYear();
  const Mo = p2(d.getMonth() + 1);
  const Da = p2(d.getDate());
  const H = p2(d.getHours());
  const Mi = p2(d.getMinutes());
  const S = p2(d.getSeconds());
  switch (fmt) {
    case 'timestamp': return String(Date.now());
    case 'DD_MM_YYYY': return `${Da}/${Mo}/${Y}`;
    case 'DD_MM_YYYY_HH_mm_ss': return `${Da}/${Mo}/${Y} ${H}:${Mi}:${S}`;
    case 'YYYY_MM_DD': return `${Y}-${Mo}-${Da}`;
    case 'YYYY_MM_DD_HH_mm_ss': return `${Y}-${Mo}-${Da} ${H}:${Mi}:${S}`;
    case 'HH_mm_ss': return `${H}:${Mi}:${S}`;
    default: return String(Date.now());
  }
}

function coerceMaybeNum(v) {
  if (typeof v !== 'string') return v;
  const t = v.trim();
  if (t !== '' && !Number.isNaN(Number(t))) return Number(t);
  return v;
}

/**
 * Convert legacy linear steps OR nested tree steps (`then`/`else`, `body`) into a standard graph.
 */
function stepsToGraph(stepsInput, variables = [], settings = {}) {
  const nodes = [{ id: 'start', type: 'start', title: 'Bắt đầu quy trình', params: {} }];
  const connections = [];
  let seq = 0;
  const nid = () => `s_${++seq}`;
  const link = (source, target, branch = null) => {
    if (source && target) connections.push({ source, target, branch });
  };

  function mapLegacyStep(st) {
    if (!st || typeof st !== 'object') return null;
    if (st.params && typeof st.params === 'object') return { type: st.type, params: st.params, onError: st.onError, disabled: st.disabled, then: st.then, else: st.else, body: st.body };
    const { type, onError, disabled, then: th, else: el, body, ...rest } = st;
    switch (type) {
      case 'navigate':
        return { type: 'mo_url', params: { url: rest.url || 'about:blank', wait_until: 'domcontentloaded', timeout: rest.waitSec || 30 } };
      case 'sleep':
      case 'delay':
        if (rest.maxSec != null && rest.minSec != null && Number(rest.maxSec) > Number(rest.minSec)) {
          return { type: 'doi', params: { time_type: 'random', num_start: Number(rest.minSec), num_end: Number(rest.maxSec) } };
        }
        return { type: 'doi', params: { time_type: 'fixed', num_seconds: Number(rest.sec || rest.minSec || 1) } };
      case 'scroll':
        return { type: 'cuon_chuot', params: { scroll_type: 'coordinates', direction: rest.direction === 'up' ? 'up' : 'down', x_coordinates: 0, y_coordinates: Number(rest.maxDistance || rest.minDistance || 400), speed: 5 } };
      case 'click':
        return { type: 'nhan_chuot', params: { mode: 'normal', button: 'left', select_by: 'selector', selector_type: String(rest.selector || '').startsWith('/') ? 'xpath' : 'css', selector: rest.selector || 'button', timeout: 10 } };
      case 'type':
        return { type: 'nhap_van_ban', params: { selector_type: rest.selector ? (String(rest.selector).startsWith('/') ? 'xpath' : 'css') : '', selector: rest.selector || '', text: rest.text || '', speed: 0.05 } };
      case 'press_key':
        return { type: 'nhan_phim', params: { keys: [rest.key || 'Enter'] } };
      case 'screenshot':
        return { type: 'chup_man_hinh', params: { file_name: rest.name || `shot_${Date.now()}`, folder_output: rest.folder || os.tmpdir() } };
      default:
        return { type, params: rest, onError, disabled, then: th, else: el, body };
    }
  }

  function emitChain(arr) {
    let headId = null;
    let tails = [];
    for (const raw of (Array.isArray(arr) ? arr : [])) {
      const s = mapLegacyStep(raw);
      if (!s || !s.type) continue;
      if (s.type === 'start') continue;
      const id = nid();
      const isLoop = s.type === 'lap_du_lieu' || s.type === 'lap_co_dieu_kien';
      const params = { ...(s.params || {}) };
      if (isLoop && !params.loop_id) params.loop_id = `loop_${id}`;
      const nodeObj = { id, type: s.type, title: raw.title || s.type, params, onError: s.onError, disabled: s.disabled };
      nodes.push(nodeObj);

      if (!headId) headId = id;
      else tails.forEach((t) => link(t.id, id, t.branch));

      if (s.type === 'dieu_kien' && (Array.isArray(s.then) || Array.isArray(s.else))) {
        const a = emitChain(s.then || []);
        const b = emitChain(s.else || []);
        if (a.headId) link(id, a.headId, 'if');
        if (b.headId) link(id, b.headId, 'else');
        tails = []
          .concat(a.headId ? a.tails : [{ id, branch: 'if' }])
          .concat(b.headId ? b.tails : [{ id, branch: 'else' }]);
      } else if (isLoop && Array.isArray(s.body)) {
        const bodyChain = emitChain(s.body);
        const endId = nid();
        nodes.push({ id: endId, type: 'diem_cuoi_vong_lap', title: 'Điểm cuối vòng lặp', params: { loop_id: params.loop_id } });
        if (bodyChain.headId) {
          link(id, bodyChain.headId, null);
          bodyChain.tails.forEach((t) => link(t.id, endId, t.branch));
        } else {
          link(id, endId, null);
        }
        tails = [{ id: endId, branch: null }];
      } else {
        tails = [{ id, branch: null }];
      }
    }
    return { headId, tails };
  }

  const main = emitChain(stepsInput);
  if (main.headId) link('start', main.headId, null);
  return { nodes, connections, variables: normalizeVariablesArray(variables), settings };
}

function normalizeVariablesArray(rawVars) {
  if (!rawVars) return [];
  if (Array.isArray(rawVars)) return rawVars;
  if (typeof rawVars === 'object') {
    return Object.entries(rawVars).map(([name, value]) => ({ name, value }));
  }
  return [];
}

/**
 * Normalize any flow/graph input into `{ nodes, connections, variables, settings }`.
 * Supports `{ nodes, connections }`, `{ nodes, edges }` (ReactFlow / Canvas),
 * `{ graph: {...} }`, `{ steps: [...] }`, and raw `[...]` step arrays.
 */
function normalizeFlowToGraph(input) {
  if (!input) return { nodes: [], connections: [], variables: [], settings: {} };
  let obj = input;
  if (typeof obj === 'string') {
    try { obj = JSON.parse(obj); } catch { return { nodes: [], connections: [], variables: [], settings: {} }; }
  }
  if (Array.isArray(obj)) {
    return stepsToGraph(obj);
  }
  if (obj.graph) {
    const inner = typeof obj.graph === 'string' ? JSON.parse(obj.graph) : obj.graph;
    return normalizeFlowToGraph({
      ...inner,
      variables: inner.variables || obj.variables || [],
      settings: inner.settings || obj.settings || {},
    });
  }
  if (!Array.isArray(obj.nodes) && Array.isArray(obj.steps)) {
    let steps = obj.steps;
    if (typeof steps === 'string') {
      try { steps = JSON.parse(steps); } catch { steps = []; }
    }
    return stepsToGraph(steps, obj.variables || [], obj.settings || {});
  }

  const rawNodes = Array.isArray(obj.nodes) ? obj.nodes : [];
  const nodes = rawNodes.map((n) => {
    const data = (n && n.data && typeof n.data === 'object') ? n.data : {};
    const params = n.params || n.config || data.params || data.config || {};
    return {
      ...n,
      id: String(n.id),
      type: n.type === 'default' && data.type ? data.type : (n.type || data.type || ''),
      title: n.title || n.label || data.title || data.label || n.type || '',
      params,
      disabled: !!(n.disabled || data.disabled),
      onError: n.onError || data.onError,
    };
  });

  // Prefer `connections`; fall back to `edges` so graphs having both never duplicate wires
  const rawEdges = (Array.isArray(obj.connections) && obj.connections.length)
    ? obj.connections
    : (Array.isArray(obj.edges) ? obj.edges : []);

  const connections = rawEdges.map((e) => {
    let br = e.branch != null ? e.branch : (e.sourceHandle != null ? e.sourceHandle : e.handle);
    if (br === '' || br === 'default' || br === 'out' || br === 'next' || br === 'output') br = null;
    return {
      source: String(e.source),
      target: String(e.target),
      branch: br || null,
      color: e.color,
    };
  });

  return {
    nodes,
    connections,
    variables: normalizeVariablesArray(obj.variables),
    settings: (obj.settings && typeof obj.settings === 'object') ? obj.settings : {},
  };
}

function buildGraph(graphInput) {
  const norm = normalizeFlowToGraph(graphInput);
  const gnodes = norm.nodes;
  const gconns = norm.connections;
  const byId = new Map(gnodes.map((n) => [n.id, n]));
  const out = new Map();
  gconns.forEach((c) => {
    if (!out.has(c.source)) out.set(c.source, []);
    out.get(c.source).push({ branch: c.branch || null, target: c.target });
  });
  const nextOf = (id, branch) => {
    const edges = out.get(id) || [];
    const want = branch || null;
    const hit = edges.find((e) => e.branch === want)
      || (want === null ? edges.find((e) => e.branch === null) : null);
    return hit ? hit.target : null;
  };
  const outsOf = (id) => out.get(id) || [];
  return {
    nodes: gnodes,
    connections: gconns,
    variables: norm.variables,
    settings: norm.settings,
    byId,
    nextOf,
    outsOf,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// NATIVE CDP ELEMENT, PAGE & BROWSER WRAPPERS (OVER `../cdp` CdpClient)
// ─────────────────────────────────────────────────────────────────────────────

class CdpElementHandle {
  constructor(page, sessionId, contextId, objectId) {
    this.page = page;
    this.sessionId = sessionId;
    this.contextId = contextId;
    this.objectId = objectId;
  }

  async evaluate(fn, ...args) {
    const fnStr = typeof fn === 'function' ? fn.toString() : `function(el){ return (${fn}); }`;
    const res = await this.page.client.send('Runtime.callFunctionOn', {
      objectId: this.objectId,
      functionDeclaration: fnStr,
      arguments: args.map((v) => ({ value: v })),
      returnByValue: true,
      awaitPromise: true,
    }, this.sessionId);
    if (res && res.exceptionDetails) {
      const msg = (res.exceptionDetails.exception && res.exceptionDetails.exception.description)
        || res.exceptionDetails.text || 'Element evaluate error';
      throw new Error(msg);
    }
    return res && res.result ? res.result.value : undefined;
  }

  async scrollIntoView() {
    await this.evaluate((el) => {
      if (el && typeof el.scrollIntoView === 'function') {
        const r = el.getBoundingClientRect();
        if (r.top < 0 || r.left < 0 || r.bottom > window.innerHeight || r.right > window.innerWidth) {
          el.scrollIntoView({ block: 'center', inline: 'center', behavior: 'instant' });
        }
      }
    }).catch(() => {});
  }

  async boundingBox() {
    await this.scrollIntoView();
    try {
      const bm = await this.page.client.send('DOM.getBoxModel', { objectId: this.objectId }, this.sessionId, 5000);
      if (bm && bm.model && Array.isArray(bm.model.content) && bm.model.content.length >= 8) {
        const q = bm.model.content;
        const xs = [q[0], q[2], q[4], q[6]];
        const ys = [q[1], q[3], q[5], q[7]];
        const minX = Math.min(...xs);
        const maxX = Math.max(...xs);
        const minY = Math.min(...ys);
        const maxY = Math.max(...ys);
        if (maxX - minX > 0 && maxY - minY > 0) {
          return { x: minX, y: minY, width: maxX - minX, height: maxY - minY };
        }
      }
    } catch { /* fallback to getBoundingClientRect */ }

    const rect = await this.evaluate((el) => {
      if (!el || typeof el.getBoundingClientRect !== 'function') return null;
      const r = el.getBoundingClientRect();
      return { x: r.left, y: r.top, width: r.width, height: r.height };
    }).catch(() => null);
    if (rect && rect.width > 0 && rect.height > 0) return rect;
    return null;
  }

  async focus() {
    try {
      await this.page.client.send('DOM.focus', { objectId: this.objectId }, this.sessionId, 4000);
    } catch {
      await this.evaluate((el) => el && el.focus && el.focus()).catch(() => {});
    }
  }

  async click() {
    await this.evaluate((el) => {
      if (el && typeof el.click === 'function') el.click();
    });
  }

  async select(val) {
    const targetVal = String(val == null ? '' : val);
    await this.evaluate((el, v) => {
      if (!el) throw new Error('Phần tử select không tồn tại');
      if (el.tagName !== 'SELECT') {
        el.value = v;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        return;
      }
      const opts = Array.from(el.options || []);
      let matched = opts.find((o) => o.value === v);
      if (!matched) matched = opts.find((o) => (o.textContent || '').trim() === v);
      if (!matched) matched = opts.find((o) => (o.textContent || '').trim().toLowerCase().includes(v.toLowerCase()));
      if (matched) {
        matched.selected = true;
        el.value = matched.value;
      } else {
        el.value = v;
      }
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
    }, targetVal);
  }

  async uploadFiles(files) {
    const desc = await this.page.client.send('DOM.describeNode', { objectId: this.objectId }, this.sessionId, 5000);
    const backendNodeId = desc && desc.node && desc.node.backendNodeId;
    if (!backendNodeId) throw new Error('Không xác định được backendNodeId cho ô tải tệp');
    await this.page.client.send('DOM.setFileInputFiles', {
      files,
      backendNodeId,
    }, this.sessionId, 15000);
  }

  async dispose() {
    if (!this.objectId) return;
    const oid = this.objectId;
    this.objectId = null;
    await this.page.client.send('Runtime.releaseObject', { objectId: oid }, this.sessionId, 2000).catch(() => {});
  }
}

class CdpPage {
  constructor(browser, targetInfo) {
    this.browser = browser;
    this.client = browser.client;
    this.targetId = targetInfo.targetId;
    this._url = targetInfo.url || 'about:blank';
    this._title = targetInfo.title || '';
    this.sessionId = null;
    this.curFrameId = null;
    this._frameContexts = new Map();
    this._oopifSessions = new Map();
    this._inflight = new Set();
    this._lastNetActivity = Date.now();
    this._listeners = [];
  }

  _on(event, fn) {
    this.client.on(event, fn);
    this._listeners.push([event, fn]);
  }

  async attach() {
    if (this.sessionId) return this;
    const res = await this.client.send('Target.attachToTarget', {
      targetId: this.targetId,
      flatten: true,
    }, null, 8000);
    this.sessionId = res.sessionId;

    this._on('Runtime.executionContextCreated', (params, sid) => {
      if (!params || !params.context) return;
      const aux = params.context.auxData || {};
      if (sid === this.sessionId && aux.isDefault && aux.frameId) {
        this._frameContexts.set(aux.frameId, params.context.id);
      }
    });

    this._on('Runtime.executionContextsCleared', (_params, sid) => {
      if (sid === this.sessionId) this._frameContexts.clear();
    });

    this._on('Page.frameNavigated', (params, sid) => {
      if (sid === this.sessionId && params && params.frame && !params.frame.parentId) {
        this._url = params.frame.url || this._url;
      }
    });

    this._on('Network.requestWillBeSent', (params, sid) => {
      if (sid === this.sessionId && params && params.requestId) {
        this._inflight.add(params.requestId);
        this._lastNetActivity = Date.now();
      }
    });

    const onNetDone = (params, sid) => {
      if (sid === this.sessionId && params && params.requestId) {
        this._inflight.delete(params.requestId);
        this._lastNetActivity = Date.now();
      }
    };
    this._on('Network.loadingFinished', onNetDone);
    this._on('Network.loadingFailed', onNetDone);

    this._on('Target.attachedToTarget', (params) => {
      if (params && params.targetInfo && params.targetInfo.type === 'iframe' && params.sessionId) {
        this._oopifSessions.set(params.targetInfo.targetId, params.sessionId);
        this.client.send('Runtime.enable', {}, params.sessionId, 4000).catch(() => {});
        this.client.send('DOM.enable', {}, params.sessionId, 4000).catch(() => {});
      }
    });

    await this.client.send('Page.enable', {}, this.sessionId, 6000).catch(() => {});
    await this.client.send('Runtime.enable', {}, this.sessionId, 6000).catch(() => {});
    await this.client.send('DOM.enable', {}, this.sessionId, 6000).catch(() => {});
    await this.client.send('Network.enable', {}, this.sessionId, 6000).catch(() => {});
    await this.client.send('Target.setAutoAttach', {
      autoAttach: true,
      waitForDebuggerOnStart: false,
      flatten: true,
    }, this.sessionId, 4000).catch(() => {});

    await this.refreshUrl().catch(() => {});
    return this;
  }

  cleanupListeners() {
    for (const [ev, fn] of this._listeners) {
      this.client.removeListener(ev, fn);
    }
    this._listeners.length = 0;
  }

  url() {
    return this._url || 'about:blank';
  }

  async refreshUrl() {
    try {
      const r = await this.client.send('Runtime.evaluate', {
        expression: 'window.location.href',
        returnByValue: true,
      }, this.sessionId, 3000);
      if (r && r.result && typeof r.result.value === 'string') {
        this._url = r.result.value;
      }
    } catch { /* ignore */ }
    return this._url;
  }

  async title() {
    try {
      const r = await this.client.send('Runtime.evaluate', {
        expression: 'document.title',
        returnByValue: true,
      }, this.sessionId, 3000);
      return (r && r.result && r.result.value) || '';
    } catch {
      return this._title || '';
    }
  }

  async bringToFront() {
    await this.client.send('Target.activateTarget', { targetId: this.targetId }, null, 4000).catch(() => {});
    await this.client.send('Page.bringToFront', {}, this.sessionId, 4000).catch(() => {});
  }

  async close() {
    this.cleanupListeners();
    this.browser._pages.delete(this.targetId);
    await this.client.send('Target.closeTarget', { targetId: this.targetId }, null, 5000).catch(() => {});
  }

  async _resolveExecutionTarget() {
    if (!this.curFrameId) {
      return { sessionId: this.sessionId, contextId: undefined };
    }
    if (this._oopifSessions.has(this.curFrameId)) {
      return { sessionId: this._oopifSessions.get(this.curFrameId), contextId: undefined };
    }
    if (this._frameContexts.has(this.curFrameId)) {
      return { sessionId: this.sessionId, contextId: this._frameContexts.get(this.curFrameId) };
    }
    try {
      const world = await this.client.send('Page.createIsolatedWorld', {
        frameId: this.curFrameId,
        worldName: 'cgt_rpa_ctx',
        grantUniveralAccess: true,
      }, this.sessionId, 5000);
      if (world && world.executionContextId) {
        this._frameContexts.set(this.curFrameId, world.executionContextId);
        return { sessionId: this.sessionId, contextId: world.executionContextId };
      }
    } catch { /* fallback to main frame */ }
    return { sessionId: this.sessionId, contextId: undefined };
  }

  async evaluate(fnOrExpr, ...args) {
    const { sessionId, contextId } = await this._resolveExecutionTarget();
    let expression;
    if (typeof fnOrExpr === 'function') {
      const serializedArgs = args.map((a) => JSON.stringify(a)).join(', ');
      expression = `(${fnOrExpr.toString()})(${serializedArgs})`;
    } else {
      expression = String(fnOrExpr);
    }
    const params = {
      expression,
      returnByValue: true,
      awaitPromise: true,
    };
    if (contextId) params.contextId = contextId;
    const res = await this.client.send('Runtime.evaluate', params, sessionId, 30000);
    if (res && res.exceptionDetails) {
      const msg = (res.exceptionDetails.exception && res.exceptionDetails.exception.description)
        || res.exceptionDetails.text || 'Script evaluation error';
      throw new Error(msg);
    }
    return res && res.result ? res.result.value : undefined;
  }

  async content() {
    return this.evaluate(() => (document.documentElement ? document.documentElement.outerHTML : ''));
  }

  async waitForLoadState(waitUntil = 'domcontentloaded', timeoutMs = 30000) {
    const maxWait = timeoutMs > 0 ? timeoutMs : 60000;
    const deadline = Date.now() + maxWait;
    const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

    if (waitUntil === 'networkidle0' || waitUntil === 'networkidle2') {
      const threshold = waitUntil === 'networkidle2' ? 2 : 0;
      let idleSince = null;
      while (Date.now() < deadline) {
        const ready = await this.evaluate(() => document.readyState).catch(() => 'loading');
        if (ready === 'complete' && this._inflight.size <= threshold) {
          if (idleSince === null) idleSince = Date.now();
          if (Date.now() - idleSince >= 500) {
            await this.refreshUrl();
            return;
          }
        } else {
          idleSince = null;
        }
        await sleep(100);
      }
      throw new Error(`Trang chưa tải xong sau ${Math.round(maxWait / 1000)}s (${waitUntil})`);
    }

    const needInteractive = waitUntil === 'domcontentloaded';
    while (Date.now() < deadline) {
      const ready = await this.evaluate(() => document.readyState).catch(() => 'loading');
      if (ready === 'complete' || (needInteractive && ready === 'interactive')) {
        await this.refreshUrl();
        return;
      }
      await sleep(100);
    }
    throw new Error(`Trang chưa tải xong sau ${Math.round(maxWait / 1000)}s (${waitUntil})`);
  }

  async goto(rawUrl, { waitUntil = 'domcontentloaded', timeout = 30000 } = {}) {
    let url = String(rawUrl || '').trim();
    if (!url) throw new Error('URL trống');
    if (!/^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(url)) {
      url = `https://${url}`;
    }
    const maxWait = timeout > 0 ? timeout : 60000;
    this._inflight.clear();
    const navRes = await this.client.send('Page.navigate', { url }, this.sessionId, maxWait);
    if (navRes && navRes.errorText && navRes.errorText !== 'net::ERR_ABORTED') {
      throw new Error(`Không mở được URL (${navRes.errorText}): ${url}`);
    }
    this.curFrameId = null;
    this._url = url;
    await new Promise((r) => setTimeout(r, 80));
    await this.waitForLoadState(waitUntil, maxWait);
    await this.refreshUrl();
  }

  async goBack(timeoutMs = 30000) {
    const hist = await this.client.send('Page.getNavigationHistory', {}, this.sessionId, 5000);
    if (!hist || hist.currentIndex <= 0 || !Array.isArray(hist.entries)) return false;
    const prev = hist.entries[hist.currentIndex - 1];
    if (!prev) return false;
    await this.client.send('Page.navigateToHistoryEntry', { entryId: prev.id }, this.sessionId, timeoutMs);
    this.curFrameId = null;
    await new Promise((r) => setTimeout(r, 120));
    await this.waitForLoadState('domcontentloaded', timeoutMs).catch(() => {});
    await this.refreshUrl();
    return true;
  }

  async goForward(timeoutMs = 30000) {
    const hist = await this.client.send('Page.getNavigationHistory', {}, this.sessionId, 5000);
    if (!hist || !Array.isArray(hist.entries) || hist.currentIndex >= hist.entries.length - 1) return false;
    const next = hist.entries[hist.currentIndex + 1];
    if (!next) return false;
    await this.client.send('Page.navigateToHistoryEntry', { entryId: next.id }, this.sessionId, timeoutMs);
    this.curFrameId = null;
    await new Promise((r) => setTimeout(r, 120));
    await this.waitForLoadState('domcontentloaded', timeoutMs).catch(() => {});
    await this.refreshUrl();
    return true;
  }

  async reload(timeoutMs = 30000) {
    await this.client.send('Page.reload', { ignoreCache: false }, this.sessionId, timeoutMs);
    this.curFrameId = null;
    await new Promise((r) => setTimeout(r, 120));
    await this.waitForLoadState('load', timeoutMs).catch(() => {});
    await this.refreshUrl();
  }

  async screenshot(filePath, fullPage = true) {
    const params = { format: 'png' };
    if (fullPage) params.captureBeyondViewport = true;
    const res = await this.client.send('Page.captureScreenshot', params, this.sessionId, 20000);
    if (!res || !res.data) throw new Error('Không chụp được ảnh màn hình qua CDP');
    const buf = Buffer.from(res.data, 'base64');
    if (filePath) fs.writeFileSync(filePath, buf);
    return buf;
  }

  // ── Element Querying (CSS & XPath) ─────────────────────────────────────────
  async queryAll(selType, selector) {
    const sel = String(selector == null ? '' : selector).trim();
    if (!sel) return [];
    const { sessionId, contextId } = await this._resolveExecutionTarget();
    const mode = String(selType || 'css').toLowerCase();

    const evalParams = {
      expression: `((mode, sel) => {
        const cleanXpath = sel.startsWith('xpath=') ? sel.slice(6) : sel;
        const looksXpath = cleanXpath.startsWith('//') || cleanXpath.startsWith('(//') || cleanXpath.startsWith('./') || cleanXpath.startsWith('/html');
        const evalXpath = (xp) => {
          const out = [];
          const snap = document.evaluate(xp, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
          for (let i = 0; i < snap.snapshotLength; i++) out.push(snap.snapshotItem(i));
          return out;
        };
        if (mode === 'text') {
          return evalXpath('//*[contains(normalize-space(.), ' + JSON.stringify(sel) + ')]');
        }
        if (mode === 'xpath' || looksXpath) {
          try { return evalXpath(cleanXpath); }
          catch (e) {
            if (!looksXpath) {
              try { return Array.from(document.querySelectorAll(sel)); } catch {}
            }
            return [];
          }
        }
        try { return Array.from(document.querySelectorAll(sel)); }
        catch (e) {
          if (looksXpath) { try { return evalXpath(cleanXpath); } catch {} }
          return [];
        }
      })(${JSON.stringify(mode)}, ${JSON.stringify(sel)})`,
      returnByValue: false,
    };
    if (contextId) evalParams.contextId = contextId;

    let arrObj;
    try {
      arrObj = await this.client.send('Runtime.evaluate', evalParams, sessionId, 8000);
    } catch {
      return [];
    }
    const arrId = arrObj && arrObj.result && arrObj.result.objectId;
    if (!arrId) return [];

    const handles = [];
    try {
      const props = await this.client.send('Runtime.getProperties', {
        objectId: arrId,
        ownProperties: true,
      }, sessionId, 8000);
      for (const p of (props && props.result) || []) {
        if (/^\d+$/.test(p.name) && p.value && p.value.objectId) {
          handles.push(new CdpElementHandle(this, sessionId, contextId, p.value.objectId));
        }
      }
    } finally {
      await this.client.send('Runtime.releaseObject', { objectId: arrId }, sessionId, 2000).catch(() => {});
    }
    return handles;
  }

  async queryOne(selType, selector) {
    const list = await this.queryAll(selType, selector);
    if (!list.length) return null;
    for (let i = 1; i < list.length; i += 1) {
      list[i].dispose().catch(() => {});
    }
    return list[0];
  }

  async waitOne(selType, selector, timeoutSec = 30, isStopped = null) {
    const sel = String(selector == null ? '' : selector).trim();
    if (!sel) throw new Error('Bộ chọn trống');
    const secs = Number.isFinite(Number(timeoutSec)) && Number(timeoutSec) > 0 ? Number(timeoutSec) : 30;
    const deadline = Date.now() + secs * 1000;
    while (Date.now() <= deadline) {
      if (isStopped && isStopped()) throw new StopSignal('stopped');
      const hit = await this.queryOne(selType, sel);
      if (hit) return hit;
      await new Promise((r) => setTimeout(r, 150));
    }
    const volatile = /_R_[a-z0-9]+_|:r[0-9a-z]+:|\bember\d+\b|[?&][a-z_]*token=/i.test(sel);
    throw new Error(
      `Không tìm thấy phần tử sau ${secs}s: ${sel}`
      + (volatile ? ' - bộ chọn đang bám vào id tự sinh biến đổi theo phiên. Hãy dùng name, aria-label, placeholder hoặc class ổn định.' : '')
    );
  }

  // ── Frame Management ───────────────────────────────────────────────────────
  async switchFrame({ frameType = 'sub', chooseType = 'url', urlChar = '', orderVal = 1, selectorType = 'css', selectorVal = '' }) {
    if (frameType === 'main') {
      this.curFrameId = null;
      return;
    }
    const treeRes = await this.client.send('Page.getFrameTree', {}, this.sessionId, 5000);
    const childFrames = [];
    const walk = (node, isRoot) => {
      if (!node) return;
      if (!isRoot && node.frame) childFrames.push(node.frame);
      for (const ch of (node.childFrames || [])) walk(ch, false);
    };
    walk(treeRes && treeRes.frameTree, true);

    if (chooseType === 'url') {
      const needle = String(urlChar || '');
      const hit = childFrames.find((f) => (f.url || '').includes(needle));
      if (!hit) throw new Error(`Không tìm thấy frame khớp URL "${needle}"`);
      this.curFrameId = hit.id;
      return;
    }
    if (chooseType === 'order') {
      const idx = Math.max(1, Number(orderVal) || 1) - 1;
      const hit = childFrames[idx];
      if (!hit) throw new Error(`Không tìm thấy frame ở thứ tự ${idx + 1}`);
      this.curFrameId = hit.id;
      return;
    }
    // selector
    const el = await this.queryOne(selectorType, selectorVal);
    if (!el) throw new Error(`Không tìm thấy phần tử iframe: ${selectorVal}`);
    try {
      const desc = await this.client.send('DOM.describeNode', { objectId: el.objectId, depth: 1 }, el.sessionId, 5000);
      const fid = desc && desc.node && (desc.node.frameId || (desc.node.contentDocument && desc.node.contentDocument.frameId));
      if (!fid) throw new Error('Phần tử được chọn không phải iframe hợp lệ');
      this.curFrameId = fid;
    } finally {
      await el.dispose();
    }
  }

  // ── Mouse, Wheel & Keyboard Simulation ─────────────────────────────────────
  async dispatchMouse(type, x, y, button = 'none', buttons = 0, extra = {}) {
    await this.client.send('Input.dispatchMouseEvent', {
      type,
      x: Math.round(x * 100) / 100,
      y: Math.round(y * 100) / 100,
      button,
      buttons,
      clickCount: extra.clickCount || (type === 'mousePressed' || type === 'mouseReleased' ? 1 : 0),
      ...(extra.deltaX != null ? { deltaX: extra.deltaX } : {}),
      ...(extra.deltaY != null ? { deltaY: extra.deltaY } : {}),
    }, this.sessionId, 5000);
  }

  async typeText(text, delayMs = 80, mouseSim = true, isStopped = null) {
    const str = String(text == null ? '' : text);
    const sleep = (ms) => new Promise((r) => setTimeout(r, Math.max(0, ms)));
    for (const ch of str) {
      if (isStopped && isStopped()) throw new StopSignal('stopped');
      if (ch === '\r') continue;
      if (ch === '\n') {
        await this.client.send('Input.dispatchKeyEvent', {
          type: 'keyDown', key: 'Enter', code: 'Enter', windowsVirtualKeyCode: 13, text: '\r', unmodifiedText: '\r',
        }, this.sessionId, 4000);
        await this.client.send('Input.dispatchKeyEvent', {
          type: 'keyUp', key: 'Enter', code: 'Enter', windowsVirtualKeyCode: 13,
        }, this.sessionId, 4000);
      } else if (ch.charCodeAt(0) >= 32 && ch.charCodeAt(0) <= 126) {
        const vk = ch.toUpperCase().charCodeAt(0);
        await this.client.send('Input.dispatchKeyEvent', {
          type: 'keyDown', key: ch, text: ch, unmodifiedText: ch, windowsVirtualKeyCode: vk,
        }, this.sessionId, 4000);
        await this.client.send('Input.dispatchKeyEvent', {
          type: 'keyUp', key: ch, windowsVirtualKeyCode: vk,
        }, this.sessionId, 4000);
      } else {
        // Unicode / Vietnamese diacritics / Emoji -> insertText avoids IME corruption & double chars
        await this.client.send('Input.insertText', { text: ch }, this.sessionId, 4000);
      }
      if (delayMs > 0) {
        const jitter = mouseSim ? delayMs * (0.8 + Math.random() * 0.4) : delayMs;
        await sleep(jitter);
      }
    }
  }

  async pressKeysChord(specs) {
    let modifiers = 0;
    // Press down leading keys (modifiers)
    for (let i = 0; i < specs.length - 1; i += 1) {
      const sp = specs[i];
      modifiers |= modifierBit(sp.key);
      await this.client.send('Input.dispatchKeyEvent', {
        type: 'keyDown',
        key: sp.key,
        code: sp.code,
        windowsVirtualKeyCode: sp.vk,
        modifiers,
      }, this.sessionId, 4000);
    }
    // Press & release final key
    const last = specs[specs.length - 1];
    const finalMod = modifiers | modifierBit(last.key);
    await this.client.send('Input.dispatchKeyEvent', {
      type: 'keyDown',
      key: last.key,
      code: last.code,
      windowsVirtualKeyCode: last.vk,
      modifiers: finalMod,
      ...(modifiers === 0 && last.text ? { text: last.text, unmodifiedText: last.text } : {}),
    }, this.sessionId, 4000);
    await new Promise((r) => setTimeout(r, 35));
    await this.client.send('Input.dispatchKeyEvent', {
      type: 'keyUp',
      key: last.key,
      code: last.code,
      windowsVirtualKeyCode: last.vk,
      modifiers,
    }, this.sessionId, 4000);
    // Release leading keys in reverse order
    for (let i = specs.length - 2; i >= 0; i -= 1) {
      const sp = specs[i];
      modifiers &= ~modifierBit(sp.key);
      await this.client.send('Input.dispatchKeyEvent', {
        type: 'keyUp',
        key: sp.key,
        code: sp.code,
        windowsVirtualKeyCode: sp.vk,
        modifiers,
      }, this.sessionId, 4000);
    }
  }

  // ── Cookies ────────────────────────────────────────────────────────────────
  async getAllCookies() {
    const res = await this.client.send('Network.getAllCookies', {}, this.sessionId, 8000);
    return (res && res.cookies) || [];
  }

  async clearBrowserCookies() {
    await this.client.send('Network.clearBrowserCookies', {}, this.sessionId, 8000);
  }

  async setCookies(cookiesList) {
    await this.client.send('Network.setCookies', { cookies: cookiesList }, this.sessionId, 10000);
  }
}

class CdpBrowser {
  constructor(client, ownsClient = true) {
    this.client = client;
    this.ownsClient = ownsClient;
    this._pages = new Map();
  }

  async userPages() {
    const { targetInfos = [] } = await this.client.send('Target.getTargets', {}, null, 6000);
    const pageTargets = targetInfos.filter(
      (t) => t.type === 'page' && !/^(devtools|chrome-extension):/i.test(t.url || '')
    );
    const out = [];
    const liveIds = new Set(pageTargets.map((t) => t.targetId));
    for (const [tid, pg] of this._pages.entries()) {
      if (!liveIds.has(tid)) {
        pg.cleanupListeners();
        this._pages.delete(tid);
      }
    }
    for (const t of pageTargets) {
      let pg = this._pages.get(t.targetId);
      if (!pg) {
        pg = new CdpPage(this, t);
        await pg.attach();
        this._pages.set(t.targetId, pg);
      } else {
        pg._url = t.url || pg._url;
        pg._title = t.title || pg._title;
      }
      out.push(pg);
    }
    return out;
  }

  async newPage(url = 'about:blank') {
    const { targetId } = await this.client.send('Target.createTarget', { url: 'about:blank' }, null, 8000);
    const pg = new CdpPage(this, { targetId, url: 'about:blank', title: '' });
    await pg.attach();
    this._pages.set(targetId, pg);
    if (url && url !== 'about:blank') {
      await pg.goto(url);
    }
    return pg;
  }

  async disconnect() {
    for (const pg of this._pages.values()) {
      pg.cleanupListeners();
    }
    this._pages.clear();
    if (this.ownsClient && this.client) {
      this.client.close();
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// CLIPBOARD HELPERS (Browser + Windows OS Fallback)
// ─────────────────────────────────────────────────────────────────────────────

async function readClipboardWithFallback(page) {
  if (page) {
    await page.bringToFront().catch(() => {});
    try {
      return await page.evaluate(() => navigator.clipboard.readText());
    } catch { /* fallback to OS clipboard */ }
  }
  if (process.platform === 'win32') {
    return new Promise((resolve, reject) => {
      cp.execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', 'Get-Clipboard -Raw'], { windowsHide: true, timeout: 5000 }, (err, stdout) => {
        if (err) return reject(new Error(`Không đọc được bộ nhớ tạm: ${err.message}`));
        resolve(String(stdout || '').replace(/\r\n$/, ''));
      });
    });
  }
  throw new Error('Không đọc được bộ nhớ tạm trên trang hiện tại');
}

async function writeClipboardWithFallback(page, text) {
  const val = String(text == null ? '' : text);
  if (page) {
    await page.bringToFront().catch(() => {});
    try {
      await page.evaluate((t) => navigator.clipboard.writeText(t), val);
      return;
    } catch { /* fallback to OS clipboard */ }
  }
  if (process.platform === 'win32') {
    const b64 = Buffer.from(val, 'utf8').toString('base64');
    const cmd = `Set-Clipboard -Value ([System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String('${b64}')))`;
    await new Promise((resolve, reject) => {
      cp.execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', cmd], { windowsHide: true, timeout: 5000 }, (err) => {
        if (err) return reject(new Error(`Không ghi được bộ nhớ tạm: ${err.message}`));
        resolve();
      });
    });
    return;
  }
  throw new Error('Không ghi được bộ nhớ tạm trên trang hiện tại');
}

// ─────────────────────────────────────────────────────────────────────────────
// COOKIE PARSER (JSON / Netscape 7-column / Header `k=v;`)
// ─────────────────────────────────────────────────────────────────────────────

function parseCookiesInput(raw, fallbackUrl) {
  const trimmed = String(raw || '').trim();
  if (!trimmed) return [];
  let list = [];
  if (trimmed.startsWith('[') || trimmed.startsWith('{')) {
    const parsed = JSON.parse(trimmed);
    list = Array.isArray(parsed) ? parsed : (Array.isArray(parsed.cookies) ? parsed.cookies : [parsed]);
  } else if (trimmed.includes('\t')) {
    // Netscape cookie format: domain \t flag \t path \t secure \t expiration \t name \t value
    for (const line of trimmed.split(/\r?\n/)) {
      const l = line.trim();
      if (!l || l.startsWith('#')) continue;
      const parts = l.split('\t');
      if (parts.length >= 7) {
        list.push({
          domain: parts[0],
          path: parts[2] || '/',
          secure: /^true$/i.test(parts[3]),
          expires: Number(parts[4]) || undefined,
          name: parts[5],
          value: parts[6],
        });
      }
    }
  } else {
    list = trimmed
      .split(/;|\r?\n/)
      .map((s) => s.trim())
      .filter(Boolean)
      .map((pair) => {
        const i = pair.indexOf('=');
        return {
          name: (i < 0 ? pair : pair.slice(0, i)).trim(),
          value: (i < 0 ? '' : pair.slice(i + 1)).trim(),
        };
      });
  }

  const validUrl = /^https?:\/\//i.test(fallbackUrl || '') ? fallbackUrl : 'https://example.com/';
  return list
    .filter((c) => c && c.name)
    .map((c) => {
      const o = {
        name: String(c.name),
        value: String(c.value == null ? '' : c.value),
      };
      if (c.domain) o.domain = String(c.domain);
      else o.url = c.url || validUrl;
      o.path = c.path || '/';
      if (c.expires != null && c.expires !== '' && Number.isFinite(Number(c.expires))) {
        o.expires = Number(c.expires);
      } else if (c.expirationDate != null && Number.isFinite(Number(c.expirationDate))) {
        o.expires = Number(c.expirationDate);
      }
      if (c.httpOnly != null) o.httpOnly = !!c.httpOnly;
      if (c.secure != null) o.secure = !!c.secure;
      if (c.sameSite) {
        const ss = String(c.sameSite).toLowerCase();
        if (ss === 'strict') o.sameSite = 'Strict';
        else if (ss === 'lax') o.sameSite = 'Lax';
        else if (ss === 'none' || ss === 'no_restriction') o.sameSite = 'None';
      }
      return o;
    });
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN GRAPH EXECUTOR (`runFlow` / `run`)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Execute an RPA flow graph or linear step list.
 * @param {object} opts
 * @param {function} [legacyOnLog]
 * @param {function} [legacyIsStopped]
 */
async function runFlow(opts = {}, legacyOnLog = null, legacyIsStopped = null) {
  const runId = String(opts.runId || `rpa_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`);
  const batchId = String(opts.batchId || `batch_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`);
  const profileId = opts.profileId || (opts.profile && opts.profile.id) || '';
  const flowObj = opts.flow || opts.graph || (opts.steps ? { steps: opts.steps, variables: opts.variables } : {});
  const flowId = opts.flowId || (opts.flow && opts.flow.id) || '';
  const flowName = opts.flowName || (opts.flow && opts.flow.name) || 'Quy trình RPA';
  const onLogCb = opts.onLog || legacyOnLog;
  const extStopped = opts.isStopped || legacyIsStopped;
  const mouseSim = opts.mouseSim !== false && !(opts.config && opts.config.mouseSim === false);
  const hooks = opts.hooks || {};

  const runState = {
    runId,
    stopped: false,
    startedAt: Date.now(),
    profileId,
    flowId,
    flowName,
  };
  activeRuns.set(runId, runState);

  const checkStopped = () => !!(runState.stopped || (extStopped && extStopped()));

  const bus = getBus();
  const log = (level, msg, node) => {
    const entry = {
      runId,
      batchId,
      profileId,
      flowId,
      flowName,
      ts: nowIso(),
      level,
      msg: String(msg == null ? '' : msg),
      message: String(msg == null ? '' : msg),
      nodeId: node ? node.id : undefined,
      type: node ? node.type : undefined,
      title: node ? (node.title || '') : undefined,
    };
    try {
      if (bus && typeof bus.publish === 'function') {
        bus.publish('rpa:log', entry);
      }
    } catch { /* ignore */ }
    try {
      if (typeof onLogCb === 'function') onLogCb(entry);
    } catch { /* ignore */ }
  };

  // Build graph & resolve variables
  const mainGraph = buildGraph(flowObj);
  const vars = {};
  for (const v of mainGraph.variables) {
    if (v && v.name) vars[v.name] = coerceVar(v.value, v.type);
  }
  if (opts.variables && typeof opts.variables === 'object' && !Array.isArray(opts.variables)) {
    Object.assign(vars, opts.variables);
  }
  if (opts.inputs && typeof opts.inputs === 'object') {
    for (const [k, val] of Object.entries(opts.inputs)) {
      const decl = mainGraph.variables.find((x) => x && x.name === k);
      vars[k] = decl ? coerceVar(val, decl.type) : val;
    }
  }

  // Resolve profile metadata if available
  let profMeta = opts.profile || {};
  if (!profMeta.name && profileId) {
    const db = getDb();
    if (db && typeof db.getProfile === 'function') {
      try { profMeta = db.getProfile(profileId) || profMeta; } catch { /* ignore */ }
    }
  }

  const sys = {
    task_id: String(opts.taskId || flowId || ''),
    task_name: String(opts.taskName || flowName || ''),
    serial_number: String(profMeta.serial_number || profMeta.profileId || profileId || ''),
    browser_name: String(profMeta.name || ''),
    acc_id: String(profileId || profMeta.id || ''),
    comment: String(profMeta.notes || profMeta.note || ''),
    user_name: String(profMeta.username || ''),
    password: String(profMeta.password || ''),
    cookies: '',
    batch_id: batchId,
  };

  const settings = mainGraph.settings || {};
  const globalOnError = settings.onError || 'Gián đoạn';
  const defaultStepTimeout = (() => {
    const n = Number(settings.timeoutSec);
    return Number.isFinite(n) && n > 0 ? n : 30;
  })();

  let browser = null;
  let page = null;

  // Connect CDP upfront if endpoint/userDataDir/profileId was supplied, or lazily when a browser node runs
  async function ensureBrowserAndPage() {
    if (browser && page) return { browser, page };

    let client = opts.cdpClient || null;
    let ownsClient = false;

    if (!client) {
      let wsEndpoint = opts.wsEndpoint || '';
      if (!wsEndpoint && opts.userDataDir) {
        const ep = readDevToolsEndpoint(opts.userDataDir) || await waitForDevToolsEndpoint(opts.userDataDir, 8000);
        if (ep && ep.wsEndpoint) wsEndpoint = ep.wsEndpoint;
      }
      if (!wsEndpoint && profileId) {
        const launcher = getLauncher();
        if (launcher) {
          let info = typeof launcher.getRunningInfo === 'function' ? launcher.getRunningInfo(profileId) : null;
          if (!info && opts.autoStartProfile !== false && typeof launcher.startProfile === 'function') {
            info = await launcher.startProfile(profileId);
          }
          if (info && info.wsEndpoint) wsEndpoint = info.wsEndpoint;
        }
      }
      if (!wsEndpoint) {
        throw new Error('Chưa kết nối trình duyệt CDP (thiếu wsEndpoint / profileId đang mở)');
      }
      client = new CdpClient(wsEndpoint);
      await client.connect(8000);
      ownsClient = true;
    }

    browser = new CdpBrowser(client, ownsClient);
    const pages = await browser.userPages();
    let active = null;
    for (const pg of pages) {
      const vis = await Promise.race([
        pg.evaluate(() => document.visibilityState).catch(() => null),
        new Promise((r) => setTimeout(() => r(null), 500)),
      ]);
      if (vis === 'visible') {
        active = pg;
        break;
      }
    }
    page = active || pages[pages.length - 1] || (await browser.newPage('about:blank'));

    // Optional single-tab cleanup on fresh run (unless disabled)
    if (opts.cleanExtraTabs) {
      for (const pg of pages) {
        if (pg !== page) await pg.close().catch(() => {});
      }
    }
    await page.bringToFront().catch(() => {});
    log('info', `Đã kết nối trình duyệt CDP (${page.url() || 'about:blank'})`);
    return { browser, page };
  }

  const hasExplicitCdp = Boolean(opts.cdpClient || opts.wsEndpoint || opts.userDataDir);
  const hasBrowserTarget = Boolean(hasExplicitCdp || profileId);

  log('info', `Bắt đầu quy trình "${flowName}" (${mainGraph.nodes.length} node)`);

  const ctx = {
    get browser() { return browser; },
    get page() { return page; },
    set page(p) { page = p; },
    vars,
    sys,
    settings,
    hooks,
    log,
    mouseSim,
    steps: 0,
  };

  const guard = () => {
    if (checkStopped()) throw new StopSignal('stopped');
    ctx.steps += 1;
    if (ctx.steps > MAX_STEPS) throw new StopSignal('Vượt quá giới hạn số bước thực thi (200,000 bước)');
  };

  const errPolicy = (node) => (node.onError && node.onError !== 'Mặc định' ? node.onError : globalOnError);

  const sleep = async (ms) => {
    const total = Math.max(0, Number(ms) || 0);
    if (total <= 250) {
      await new Promise((r) => setTimeout(r, total));
      if (checkStopped()) throw new StopSignal('stopped');
      return;
    }
    const deadline = Date.now() + total;
    while (Date.now() < deadline) {
      if (checkStopped()) throw new StopSignal('stopped');
      await new Promise((r) => setTimeout(r, Math.min(250, deadline - Date.now())));
    }
  };

  const S = (v) => interp(v == null ? '' : String(v), ctx);
  const NUM = (v, d = 0) => {
    const s = interp(String(v == null ? '' : v), ctx).trim();
    if (s === '') return d;
    const n = Number(s);
    return Number.isFinite(n) ? n : d;
  };
  const setVar = (name, value) => {
    const key = String(name == null ? '' : name).trim();
    if (key) ctx.vars[key] = value;
  };
  const kvToObj = (v) => {
    const out = {};
    if (v == null) return out;
    if (Array.isArray(v)) {
      v.forEach((row) => {
        if (!row) return;
        const k = interp(String(row.key == null ? '' : row.key), ctx).trim();
        if (k) out[k] = interp(String(row.value == null ? '' : row.value), ctx);
      });
      return out;
    }
    if (typeof v === 'object') {
      Object.entries(v).forEach(([k, val]) => {
        out[k] = interp(String(val == null ? '' : val), ctx);
      });
      return out;
    }
    return parseKvBlock(interp(String(v), ctx), ':');
  };

  // ── Human-like Mouse Simulation (6-16 jittered steps + press/release) ──────
  let _lastPtr = { x: 100, y: 100 };

  async function humanMove(x, y) {
    const { page: pg } = await ensureBrowserAndPage();
    if (!ctx.mouseSim) {
      await pg.dispatchMouse('mouseMoved', x, y, 'none', 0);
      _lastPtr = { x, y };
      return;
    }
    const from = _lastPtr;
    const dist = Math.hypot(x - from.x, y - from.y);
    const steps = Math.max(6, Math.min(16, Math.round(dist / 35) || 6));
    const curveArc = (Math.random() - 0.5) * Math.min(24, dist * 0.12);
    for (let i = 1; i <= steps; i += 1) {
      if (checkStopped()) throw new StopSignal('stopped');
      const t = i / steps;
      // Smooth ease-out cubic trajectory + subtle arc
      const ease = 1 - (1 - t) ** 2;
      const arc = i < steps ? Math.sin(t * Math.PI) * curveArc : 0;
      const jx = i < steps ? (Math.random() - 0.5) * 2 : 0;
      const jy = i < steps ? (Math.random() - 0.5) * 2 : 0;
      const px = from.x + (x - from.x) * ease + arc * 0.5 + jx;
      const py = from.y + (y - from.y) * ease + arc + jy;
      await pg.dispatchMouse('mouseMoved', px, py, 'none', 0);
      await new Promise((r) => setTimeout(r, 4 + Math.random() * 8));
    }
    _lastPtr = { x, y };
  }

  function buttonMask(btn) {
    if (btn === 'right') return 2;
    if (btn === 'middle') return 4;
    return 1;
  }

  async function humanClickAt(x, y, button = 'left', holdMs = 0) {
    const { page: pg } = await ensureBrowserAndPage();
    const mask = buttonMask(button);
    await humanMove(x, y);
    await pg.dispatchMouse('mousePressed', x, y, button, mask, { clickCount: 1 });
    if (holdMs > 0) {
      await sleep(holdMs);
    } else if (ctx.mouseSim) {
      await new Promise((r) => setTimeout(r, 35 + Math.random() * 65));
    }
    await pg.dispatchMouse('mouseReleased', x, y, button, 0, { clickCount: 1 });
  }

  async function humanClickEl(el, button = 'left') {
    if (ctx.mouseSim || button !== 'left') {
      const box = await el.boundingBox().catch(() => null);
      if (box) {
        // Subtle human aim offset within central 40% of element
        const ox = (Math.random() - 0.5) * Math.min(12, box.width * 0.3);
        const oy = (Math.random() - 0.5) * Math.min(8, box.height * 0.3);
        await humanClickAt(box.x + box.width / 2 + ox, box.y + box.height / 2 + oy, button, 0);
        return;
      }
    }
    await el.click();
  }

  async function withRetry(fn, maxTries = 50, budgetMs = 10000) {
    const start = Date.now();
    let lastErr = null;
    for (let i = 0; i < maxTries; i += 1) {
      if (checkStopped()) throw new StopSignal('stopped');
      try {
        return await fn(Math.max(1, (budgetMs - (Date.now() - start)) / 1000));
      } catch (e) {
        if (e instanceof StopSignal) throw e;
        lastErr = e;
        if (Date.now() - start >= budgetMs) break;
        await new Promise((r) => setTimeout(r, 120));
      }
    }
    throw lastErr || new Error('Thất bại sau nhiều lần thử');
  }

  // ── Media Download in-page (preserves browser Proxy & Cookies!) ────────────
  async function downloadViaBrowser(url) {
    const { page: pg } = await ensureBrowserAndPage();
    try {
      const b64 = await pg.evaluate(async (u) => {
        const r = await fetch(u, { credentials: 'include' });
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        const ab = await r.arrayBuffer();
        const bytes = new Uint8Array(ab);
        const chunk = 0x8000;
        let bin = '';
        for (let i = 0; i < bytes.length; i += chunk) {
          bin += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
        }
        return btoa(bin);
      }, url);
      return Buffer.from(b64, 'base64');
    } catch (e1) {
      // Fallback: CDP Network.loadNetworkResource (still uses Chromium's proxy & cookie jar!)
      try {
        const tree = await pg.client.send('Page.getFrameTree', {}, pg.sessionId, 5000);
        const mainFrameId = tree && tree.frameTree && tree.frameTree.frame && tree.frameTree.frame.id;
        const netRes = await pg.client.send('Network.loadNetworkResource', {
          frameId: mainFrameId,
          url,
          options: { disableCache: false, includeCredentials: true },
        }, pg.sessionId, 30000);
        if (netRes && netRes.resource && netRes.resource.stream) {
          const chunks = [];
          for (;;) {
            const readRes = await pg.client.send('IO.read', { handle: netRes.resource.stream, size: 65536 }, pg.sessionId, 10000);
            if (readRes && readRes.data) {
              chunks.push(readRes.base64Encoded ? Buffer.from(readRes.data, 'base64') : Buffer.from(readRes.data, 'utf8'));
            }
            if (!readRes || readRes.eof) break;
          }
          await pg.client.send('IO.close', { handle: netRes.resource.stream }, pg.sessionId, 3000).catch(() => {});
          return Buffer.concat(chunks);
        }
        throw new Error('Network.loadNetworkResource không trả dữ liệu');
      } catch (e2) {
        throw new Error(`Không tải được media qua trình duyệt: ${e1.message} / ${e2.message}`);
      }
    }
  }

  // ── Condition Evaluation ───────────────────────────────────────────────────
  let condTrace = '';
  const UNARY_COND_OPS = new Set(['Tồn tại', 'Không tồn tại', 'exists', '!exists']);
  const COND_OP_LABELS = {
    'Tồn tại': 'exists', 'Không tồn tại': '!exists',
    'Bằng': '==', 'Không bằng': '!=',
    'Bao gồm': 'includes', 'Không bao gồm': '!includes',
    'Lớn hơn': '>', 'Nhiều hơn': '>', 'Lớn hơn hoặc bằng': '>=', 'Nhiều hơn hoặc bằng': '>=',
    'Nhỏ hơn': '<', 'Nhỏ hơn hoặc bằng': '<=',
    'Nằm trong': 'in', 'Một trong': 'in',
    'Không nằm trong': '!in', 'Không nằm trong số đó': '!in',
  };

  function evalCondList(obj, customCtx = ctx) {
    const arr = Array.isArray(obj) ? obj : (Array.isArray(obj.conditions) ? obj.conditions : [obj]);
    const logic = (obj && obj.logic) || 'AND';
    const parts = [];
    const results = arr.map((c) => {
      if (c == null || typeof c !== 'object') {
        parts.push(`${JSON.stringify(c)} -> ${c ? 'đúng' : 'sai'}`);
        return !!c;
      }
      const left = interp(String(c.left != null ? c.left : (c.variable != null ? c.variable : '')), customCtx);
      const op = c.op || c.operator || 'Tồn tại';
      const right = interp(String(c.right != null ? c.right : (c.value != null ? c.value : '')), customCtx);
      const hit = compare(left, op, right);
      parts.push(`"${left}" ${COND_OP_LABELS[op] || op}${UNARY_COND_OPS.has(op) ? '' : ` "${right}"`} -> ${hit ? 'đúng' : 'sai'}`);
      return hit;
    });
    condTrace = parts.join(/or/i.test(logic) ? ' HOẶC ' : ' VÀ ');
    return /or/i.test(logic) ? results.some(Boolean) : results.every(Boolean);
  }

  function evalConditions(raw, customCtx = ctx) {
    condTrace = '';
    if (raw == null || raw === '') {
      condTrace = '(bỏ trống -> coi như đúng)';
      return true;
    }
    if (typeof raw === 'object') {
      const rows = Array.isArray(raw) ? raw : (Array.isArray(raw.conditions) ? raw.conditions : null);
      if (rows && !rows.length && raw.expr) return evalConditions(String(raw.expr), customCtx);
      return evalCondList(raw, customCtx);
    }
    const s = String(raw).trim();
    if (!s) {
      condTrace = '(bỏ trống -> coi như đúng)';
      return true;
    }
    if (s.startsWith('[') || s.startsWith('{')) {
      try { return evalCondList(JSON.parse(s), customCtx); } catch { /* fall through */ }
    }
    const expr = interp(s, customCtx);
    condTrace = `biểu thức: ${expr}`;
    try {
      const fn = new Function('vars', 'sys', `"use strict"; return (${expr});`);
      return !!fn(customCtx.vars, customCtx.sys);
    } catch {
      const t = String(expr).trim().toLowerCase();
      return !(t === '' || t === 'false' || t === '0' || t === 'null' || t === 'undefined' || t === 'nan');
    }
  }

  function regexApply(str, p) {
    const action = p.regex_action || 'match';
    const pat = interp(p.regex_pattern == null ? '' : String(p.regex_pattern), ctx, { jsonSafe: true });
    let re;
    try { re = new RegExp(pat, /all/i.test(action) ? 'g' : ''); } catch { throw new Error('Regex không hợp lệ'); }
    switch (action) {
      case 'match': { const m = str.match(re); return m ? m[0] : null; }
      case 'match_all': return str.match(new RegExp(pat, 'g')) || [];
      case 'search': return str.search(re);
      case 'replace': return str.replace(new RegExp(pat, ''), S(p.regex_replacement));
      case 'replace_all': return str.replace(new RegExp(pat, 'g'), S(p.regex_replacement));
      case 'split': return str.split(re);
      default: return str;
    }
  }

  function coerceDefaultVal(v, type) {
    try {
      if (type === 'number') return Number(v);
      if (type === 'object' || type === 'list') return JSON.parse(v);
    } catch { /* keep string */ }
    return v;
  }

  // ───────────────────────────────────────────────────────────────────────────
  // NODE HANDLERS (ALL CATEGORIES)
  // ───────────────────────────────────────────────────────────────────────────
  const exec = {};

  // ── 1. GENERAL ─────────────────────────────────────────────────────────────
  Object.assign(exec, {
    async doi(n) {
      const p = n.params || {};
      let sec;
      if ((p.time_type || 'random') === 'fixed') {
        sec = NUM(p.num_seconds, 1);
      } else {
        const a = NUM(p.num_start, 1);
        const b = NUM(p.num_end, 3);
        sec = a + Math.random() * Math.max(0, b - a);
      }
      log('info', `Đợi ${sec.toFixed(2)}s`, n);
      await sleep(sec * 1000);
    },

    async http_request(n) {
      const p = n.params || {};
      const method = String(p.method || 'GET').toUpperCase();
      let url = S(p.url);
      if (!url) throw new Error('URL trống');
      const qp = kvToObj(p.params);
      if (Object.keys(qp).length) {
        try {
          const u = new URL(url);
          Object.entries(qp).forEach(([k, v]) => u.searchParams.set(k, v));
          url = u.toString();
        } catch {
          throw new Error('URL không hợp lệ');
        }
      }
      const headers = kvToObj(p.headers);
      const hasCT = () => Object.keys(headers).some((k) => /content-type/i.test(k));
      const reqInit = { method, headers };
      if (method !== 'GET' && method !== 'HEAD') {
        const ct = p.content_type || 'json';
        if (ct === 'json') {
          const raw = interp(p.json_string_data == null ? '' : String(p.json_string_data), ctx, { jsonSafe: true });
          if (raw && raw.trim()) {
            reqInit.body = raw;
            if (!hasCT()) headers['Content-Type'] = 'application/json';
          }
        } else if (ct === 'form_urlencoded') {
          reqInit.body = new URLSearchParams(kvToObj(p.data__form_urlencoded)).toString();
          if (!hasCT()) headers['Content-Type'] = 'application/x-www-form-urlencoded';
        } else if (ct === 'form_multipart') {
          const fd = new FormData();
          Object.entries(kvToObj(p.data__form_multipart)).forEach(([k, v]) => fd.append(k, v));
          reqInit.body = fd;
        } else if (ct === 'text') {
          reqInit.body = interp(p.data__text == null ? '' : String(p.data__text), ctx, { jsonSafe: true });
        }
      }
      const res = await fetch(url, reqInit);
      const rt = p.response_type || 'json';
      let out;
      if (rt === 'arraybuffer') {
        out = Buffer.from(await res.arrayBuffer()).toString('base64');
      } else if (rt === 'text') {
        out = await res.text();
      } else {
        const txt = await res.text();
        try { out = JSON.parse(txt); } catch { out = txt; }
        if (p.path_data && out && typeof out === 'object') {
          out = getPath(out, S(p.path_data));
        }
      }
      setVar(p.variable_name, out);
      log('info', `HTTP ${method} -> ${res.status}`, n);
    },

    async bo_nho_tam(n) {
      const p = n.params || {};
      let pg = page;
      if (!pg && hasBrowserTarget) {
        const r = await ensureBrowserAndPage();
        pg = r.page;
      }
      if ((p.action_type || 'get') === 'get') {
        const txt = await readClipboardWithFallback(pg);
        if (p.save_to_var || p.variable_name) setVar(p.variable_name, txt);
        log('info', `Đã đọc bộ nhớ tạm (${String(txt).length} ký tự)`, n);
      } else {
        let text;
        if (p.is_from_selection && pg) {
          text = await pg.evaluate(() => String(window.getSelection ? window.getSelection() : '')).catch(() => '');
        } else {
          text = S(p.text);
        }
        await writeClipboardWithFallback(pg, text);
        log('info', 'Đã ghi bộ nhớ tạm', n);
      }
    },

    async lay_thoi_gian(n) {
      const p = n.params || {};
      const v = fmtTime(p.format_return);
      setVar(p.variable_name, v);
      log('info', `Thời gian = ${v}`, n);
    },

    async log(n) {
      const raw = n.params && n.params.message != null ? String(n.params.message) : '';
      const msg = S(raw);
      if (raw.trim() && !msg.trim()) {
        const toks = raw.match(/\$\{[^}]+\}|\{\{[^}]+\}\}|\{[^}]+\}/g);
        log('warn', toks ? `Log rỗng - chưa có giá trị cho ${toks.join(', ')}` : 'Log rỗng', n);
        return;
      }
      log('info', msg, n);
    },

    async code(n) {
      const p = n.params || {};
      const src = p.js_code == null ? '' : String(p.js_code);
      const nodeLog = (...args) => log('info', args.map((a) => (typeof a === 'object' ? JSON.stringify(a) : String(a))).join(' '), n);
      const sandbox = vm.createContext({
        vars: ctx.vars,
        sys: ctx.sys,
        log: nodeLog,
        console: { log: nodeLog, info: nodeLog, warn: (...a) => log('warn', a.join(' '), n), error: (...a) => log('error', a.join(' '), n) },
        JSON, Math, Date, Number, String, Boolean, Array, Object, RegExp, Error, Promise,
        parseInt, parseFloat, isNaN, isFinite, encodeURIComponent, decodeURIComponent, encodeURI, decodeURI,
        Buffer, URL, URLSearchParams, fetch, crypto,
        setTimeout, clearTimeout,
      });
      const script = new vm.Script(`(async () => {\n${src}\n})()`);
      const res = await script.runInContext(sandbox, { timeout: 30000 });
      if (p.variable_name && res !== undefined) setVar(p.variable_name, res);
      log('info', 'Đã chạy Code', n);
    },
  });

  // ── 2. BROWSER ─────────────────────────────────────────────────────────────
  Object.assign(exec, {
    async mo_url(n) {
      const { page: pg } = await ensureBrowserAndPage();
      const p = n.params || {};
      const url = S(p.url);
      if (!url) throw new Error('URL trống');
      await pg.goto(url, { waitUntil: p.wait_until || 'domcontentloaded', timeout: NUM(p.timeout, 0) * 1000 });
      log('info', `Đã mở ${pg.url()}`, n);
    },

    async mo_tab_moi(n) {
      const { browser: br } = await ensureBrowserAndPage();
      const p = n.params || {};
      const url = S(p.url);
      page = await br.newPage('about:blank');
      await page.bringToFront().catch(() => {});
      if (url) {
        await page.goto(url, { waitUntil: p.wait_until || 'domcontentloaded', timeout: NUM(p.timeout, 0) * 1000 });
      }
      log('info', `Đã mở tab mới${url ? `: ${url}` : ''}`, n);
    },

    async chuyen_tab(n) {
      const { browser: br, page: curPg } = await ensureBrowserAndPage();
      const p = n.params || {};
      const by = p.find_by || 'match_pattern';
      const pages = await br.userPages();
      let target = null;
      if (by === 'match_pattern') {
        const pat = S(p.pattern);
        target = pages.find((pg) => pg.url().includes(pat));
      } else if (by === 'match_tile' || by === 'match_title') {
        const want = S(p.title);
        for (const pg of pages) {
          const ti = await pg.title();
          if (ti.includes(want)) { target = pg; break; }
        }
      } else if (by === 'tab_order') {
        const idx = Math.max(1, NUM(p.order_number, 1)) - 1;
        target = pages[idx];
      } else {
        const curIdx = pages.indexOf(curPg);
        target = by === 'next_tab'
          ? (pages[curIdx + 1] || pages[0])
          : (pages[curIdx - 1] || pages[pages.length - 1]);
      }
      if (!target) throw new Error('Không tìm thấy tab phù hợp');
      page = target;
      page.curFrameId = null;
      if (p.is_active !== false) await page.bringToFront().catch(() => {});
      log('info', `Đã chuyển sang tab: ${page.url()}`, n);
    },

    async dong_tab(n) {
      const { browser: br, page: curPg } = await ensureBrowserAndPage();
      const p = n.params || {};
      const ct = p.close_type || 'current';
      const pages = await br.userPages();
      const switchFallback = async (closingPg) => {
        const rest = pages.filter((x) => x !== closingPg);
        page = rest[rest.length - 1] || (await br.newPage('about:blank'));
        await page.bringToFront().catch(() => {});
      };
      if (ct === 'current') {
        await switchFallback(curPg);
        await curPg.close();
      } else if (ct === 'other_tabs') {
        for (const pg of pages) {
          if (pg !== curPg) await pg.close();
        }
      } else if (ct === 'order') {
        const idx = Math.max(1, NUM(p.number_order, 1)) - 1;
        const target = pages[idx];
        if (target) {
          if (target === curPg) await switchFallback(curPg);
          await target.close();
        }
      } else {
        const pat = S(p.pattern);
        const tt = S(p.title);
        for (const pg of pages) {
          let hit = false;
          if (ct === 'match_pattern') hit = pg.url().includes(pat);
          else hit = (await pg.title()).includes(tt);
          if (hit) {
            if (pg === curPg) await switchFallback(curPg);
            await pg.close();
          }
        }
      }
      log('info', 'Đã đóng tab', n);
    },

    async quay_lai(n) {
      const { page: pg } = await ensureBrowserAndPage();
      const moved = await pg.goBack(30000);
      log(moved ? 'info' : 'warn', moved ? 'Đã quay lại trang trước' : 'Không còn trang nào để quay lại', n);
    },

    async tien_len(n) {
      const { page: pg } = await ensureBrowserAndPage();
      const moved = await pg.goForward(30000);
      log(moved ? 'info' : 'warn', moved ? 'Đã tiến lên trang kế' : 'Không còn trang nào để tiến tới', n);
    },

    async tai_lai_trang(n) {
      const { page: pg } = await ensureBrowserAndPage();
      await pg.reload(30000);
      log('info', 'Đã tải lại trang', n);
    },

    async chup_man_hinh(n) {
      const { page: pg } = await ensureBrowserAndPage();
      const p = n.params || {};
      const dir = S(p.folder_output) || hooks.defaultDir || os.tmpdir();
      ensureDir(dir);
      const base = safeName(S(p.file_name) || `screenshot-${Date.now()}`).replace(/\.png$/i, '');
      const file = uniquePath(dir, base, '.png');
      await pg.screenshot(file, true);
      log('info', `Đã lưu ảnh màn hình: ${file}`, n);
    },

    async lay_url(n) {
      const { page: pg } = await ensureBrowserAndPage();
      await pg.refreshUrl();
      const u = pg.url();
      setVar(n.params && n.params.variable_name, u);
      log('info', `URL = ${u}`, n);
    },

    async chay_ma_javascript(n) {
      const { page: pg } = await ensureBrowserAndPage();
      const p = n.params || {};
      const src = p.script == null ? '' : String(p.script);
      const result = await pg.evaluate(async (s) => {
        try {
          // eslint-disable-next-line no-eval
          return await eval(s);
        } catch (e) {
          if (!(e instanceof SyntaxError)) throw e;
          return await (new Function(`return (async () => {\n${s}\n})();`))();
        }
      }, src);
      setVar(p.variable_name, result);
      log('info', 'Đã chạy JavaScript trên trang', n);
    },

    async cookies(n) {
      const { page: pg } = await ensureBrowserAndPage();
      const p = n.params || {};
      const act = p.action_type || 'import';
      if (act === 'export') {
        const cs = await pg.getAllCookies();
        setVar(p.variable_name, cs);
        log('info', `Đã xuất ${cs.length} cookie`, n);
        return;
      }
      if (act === 'clear') {
        await pg.clearBrowserCookies();
        log('info', 'Đã xóa toàn bộ cookie trình duyệt', n);
        return;
      }
      const raw = String(interp(p.cookie_str == null ? '' : String(p.cookie_str), ctx, { jsonSafe: true })).trim();
      if (!raw) throw new Error('Chuỗi cookie trống');
      await pg.refreshUrl();
      const ck = parseCookiesInput(raw, pg.url());
      if (!ck.length) throw new Error('Không phân tích được cookie hợp lệ');
      await pg.setCookies(ck);
      log('info', `Đã nhập ${ck.length} cookie`, n);
    },

    async lay_noi_dung_html(n) {
      const { page: pg } = await ensureBrowserAndPage();
      const html = await pg.content();
      setVar(n.params && n.params.variable_name, html);
      log('info', `Đã lấy HTML (${html.length} ký tự)`, n);
    },

    async cho_tai_trang(n) {
      const { page: pg } = await ensureBrowserAndPage();
      const p = n.params || {};
      const st = p.wait_until || 'load';
      const to = NUM(p.timeout, 30) * 1000;
      await pg.waitForLoadState(st, to);
      log('info', `Đã chờ tải trang (${st})`, n);
    },

    async chuyen_frame(n) {
      const { page: pg } = await ensureBrowserAndPage();
      const p = n.params || {};
      const frameType = p.frame_type || 'sub';
      await pg.switchFrame({
        frameType,
        chooseType: p.choose_type || 'url',
        urlChar: S(p.url_char),
        orderVal: NUM(p.order_val, 1),
        selectorType: p.selector_type || 'css',
        selectorVal: S(p.selector_val),
      });
      log('info', frameType === 'main' ? 'Đã chuyển về frame chính' : 'Đã chuyển sang frame con', n);
    },

    async dong_trinh_duyet(n) {
      log('info', 'Đóng trình duyệt', n);
      if (typeof hooks.closeBrowser === 'function') {
        await hooks.closeBrowser(profMeta);
      } else if (profileId) {
        const launcher = getLauncher();
        if (launcher && typeof launcher.stopProfile === 'function') {
          await launcher.stopProfile(profileId).catch(() => {});
        }
      } else if (browser && browser.client) {
        await browser.client.send('Browser.close', {}, null, 3000).catch(() => {});
      }
      throw new StopSignal('close_browser');
    },
  });

  // ── 3. WEB INTERACTION ─────────────────────────────────────────────────────
  Object.assign(exec, {
    async nhan_chuot(n) {
      const { page: pg } = await ensureBrowserAndPage();
      const p = n.params || {};
      const button = p.button || 'left';
      const mode = p.mode || 'normal';
      const st = p.selector_type || 'xpath';
      const by = p.select_by || 'selector';
      const useEl = mode === 'normal' || (mode === 'press_hold' && p.is_click_on_element);

      if (mode === 'press_hold') {
        let x;
        let y;
        if (useEl && by === 'selector') {
          const el = await pg.waitOne(st, S(p.selector), NUM(p.timeout, 10), checkStopped);
          const box = await el.boundingBox();
          await el.dispose();
          if (!box) throw new Error('Không lấy được tọa độ phần tử');
          x = box.x + box.width / 2;
          y = box.y + box.height / 2;
        } else {
          x = NUM(p.x_coordinates, 0);
          y = NUM(p.y_coordinates, 0);
        }
        await humanClickAt(x, y, button, NUM(p.press_time, 0) * 1000);
      } else if (by === 'coordinates') {
        await humanClickAt(NUM(p.x_coordinates, 0), NUM(p.y_coordinates, 0), button, 0);
      } else {
        const waitSec = NUM(p.timeout, 10);
        await withRetry(
          async (remSec) => {
            const el = await pg.waitOne(st, S(p.selector), Math.min(waitSec, remSec), checkStopped);
            try {
              await humanClickEl(el, button);
            } finally {
              await el.dispose();
            }
          },
          50,
          Math.max(1, waitSec) * 1000
        );
      }
      log('info', 'Đã nhấn chuột', n);
    },

    async lay_van_ban(n) {
      const { page: pg } = await ensureBrowserAndPage();
      const p = n.params || {};
      const el = await pg.waitOne(p.selector_type || 'xpath', S(p.selector), defaultStepTimeout, checkStopped);
      let txt = '';
      try {
        txt = await el.evaluate((e) => {
          if (e.innerText != null && e.innerText !== '') return e.innerText;
          if (e.textContent != null && e.textContent !== '') return e.textContent;
          return e.value != null ? String(e.value) : '';
        });
      } finally {
        await el.dispose();
      }
      setVar(p.variable_name, txt);
      log('info', 'Đã lấy văn bản phần tử', n);
    },

    async nhap_van_ban(n) {
      const { page: pg } = await ensureBrowserAndPage();
      const p = n.params || {};
      const text = S(p.text);
      const delayMs = Math.max(0, NUM(p.speed, 0.1) * 1000);
      const stype = p.selector_type;
      const sel = S(p.selector);

      if (!stype || (stype !== 'css' && stype !== 'xpath') || !sel) {
        await pg.typeText(text, delayMs, ctx.mouseSim, checkStopped);
        log('info', `Đã nhập văn bản (${text.length} ký tự, tại con trỏ)`, n);
        return;
      }

      const el = await pg.waitOne(stype, sel, defaultStepTimeout, checkStopped);
      try {
        await el.focus();
        await pg.typeText(text, delayMs, ctx.mouseSim, checkStopped);
      } finally {
        await el.dispose();
      }
      log('info', `Đã nhập văn bản (${text.length} ký tự)`, n);
    },

    async nhan_phim(n) {
      const { page: pg } = await ensureBrowserAndPage();
      const p = n.params || {};
      const codes = Array.isArray(p.keys) ? p.keys : (p.keys ? [p.keys] : []);
      const specs = codes.map(keySpecFromCodeOrName).filter(Boolean);
      if (!specs.length) throw new Error('Chưa chọn phím hợp lệ');
      await pg.pressKeysChord(specs);
      log('info', `Đã nhấn phím ${specs.map((s) => (s.key === ' ' ? 'Space' : s.key)).join('+')}`, n);
    },

    async cuon_chuot(n) {
      const { page: pg } = await ensureBrowserAndPage();
      const p = n.params || {};
      const st = p.scroll_type || 'coordinates';
      if (st === 'coordinates') {
        const dir = p.direction === 'up' ? -1 : 1;
        const dx = NUM(p.x_coordinates, 0);
        const yRaw = p.y_coordinates == null || String(p.y_coordinates).trim() === '' ? 300 : NUM(p.y_coordinates, 300);
        const dy = yRaw * dir;
        const spd = Math.max(1, NUM(p.speed, 5));
        await pg.evaluate(async (scrollX, scrollY, speed) => {
          if (scrollX) window.scrollBy(scrollX, 0);
          const step = Math.max(20, Math.round(60 * speed)) * (scrollY < 0 ? -1 : 1);
          let rem = scrollY;
          while (Math.abs(rem) > 0.5) {
            const hop = Math.abs(rem) < Math.abs(step) ? rem : step;
            const before = window.scrollY;
            window.scrollBy(0, hop);
            rem -= hop;
            if (window.scrollY === before) break;
            await new Promise((r) => setTimeout(r, 16));
          }
        }, dx, dy, spd);
      } else {
        const tsec = st === 'xpath' ? NUM(p.timeout__xpath, 30) : NUM(p.timeout__css_selector, 30);
        const el = await pg.waitOne(st === 'xpath' ? 'xpath' : 'css', S(p.element_selector), tsec, checkStopped);
        try {
          await el.evaluate((e) => e.scrollIntoView({ block: 'center', behavior: 'instant' }));
        } finally {
          await el.dispose();
        }
      }
      log('info', 'Đã cuộn chuột', n);
    },

    async luu_media(n) {
      const { page: pg } = await ensureBrowserAndPage();
      const p = n.params || {};
      let src = '';
      if (p.media_type === 'element') {
        const el = await pg.waitOne(p.selector_type || 'xpath', S(p.selector), NUM(p.timeout, 30), checkStopped);
        try {
          src = await el.evaluate((e) => e.currentSrc
            || e.src
            || e.getAttribute('href')
            || (getComputedStyle(e).backgroundImage.match(/url\(["']?(.*?)["']?\)/) || [])[1]
            || '');
        } finally {
          await el.dispose();
        }
      } else {
        src = S(p.url_string);
      }
      if (!src) throw new Error('Không tìm thấy URL media');
      await pg.refreshUrl();
      try { src = new URL(src, pg.url()).toString(); } catch { /* keep */ }
      const buf = await downloadViaBrowser(src);
      const dir = S(p.output_path) || hooks.defaultDir || os.tmpdir();
      ensureDir(dir);
      let ext = '';
      try { ext = path.extname(new URL(src).pathname) || ''; } catch { ext = ''; }
      const base = safeName(S(p.file_name) || `media-${Date.now()}`);
      const file = uniquePath(dir, base, ext || '.bin');
      fs.writeFileSync(file, buf);
      log('info', `Đã lưu media: ${file}`, n);
    },

    async tai_tep_len(n) {
      const { page: pg } = await ensureBrowserAndPage();
      const p = n.params || {};
      const st = p.selector_type || 'xpath';
      const timeout = NUM(p.timeout, 30);
      let files = [];

      if (p.is_upload_folder) {
        const dir = S(p.path);
        if (!fs.existsSync(dir) || !fs.statSync(dir).isDirectory()) {
          throw new Error(`Thư mục tải lên không tồn tại: ${dir}`);
        }
        files = fs.readdirSync(dir)
          .map((f) => path.join(dir, f))
          .filter((f) => { try { return fs.statSync(f).isFile(); } catch { return false; } });
        const cnt = NUM(p.file_count, 0);
        if (cnt > 0 && cnt < files.length) {
          for (let i = files.length - 1; i > 0; i -= 1) {
            const j = Math.floor(Math.random() * (i + 1));
            [files[i], files[j]] = [files[j], files[i]];
          }
          files = files.slice(0, cnt);
        }
      } else {
        files = S(p.path).split(/\r?\n|,/).map((s) => s.trim()).filter(Boolean);
      }

      if (!files.length) throw new Error('Không có tệp để tải lên');

      if (p.is_upload_by_dialog) {
        await pg.client.send('Page.setInterceptFileChooserDialog', { enabled: true }, pg.sessionId, 5000);
        try {
          const chooserPromise = new Promise((resolve, reject) => {
            const timer = setTimeout(() => {
              pg.client.removeListener('Page.fileChooserOpened', onChooser);
              reject(new Error('Hết thời gian chờ hộp thoại chọn tệp (fileChooserOpened)'));
            }, timeout * 1000);
            function onChooser(params, sid) {
              if (sid !== pg.sessionId) return;
              clearTimeout(timer);
              pg.client.removeListener('Page.fileChooserOpened', onChooser);
              resolve(params);
            }
            pg.client.on('Page.fileChooserOpened', onChooser);
          });
          const el = await pg.waitOne(st, S(p.selector), timeout, checkStopped);
          try { await humanClickEl(el, 'left'); } finally { await el.dispose(); }
          const chooser = await chooserPromise;
          if (!chooser || !chooser.backendNodeId) throw new Error('Không lấy được ô tệp từ hộp thoại');
          await pg.client.send('DOM.setFileInputFiles', {
            files,
            backendNodeId: chooser.backendNodeId,
          }, pg.sessionId, 15000);
        } finally {
          await pg.client.send('Page.setInterceptFileChooserDialog', { enabled: false }, pg.sessionId, 3000).catch(() => {});
        }
      } else {
        const el = await pg.waitOne(st, S(p.selector), timeout, checkStopped);
        try {
          await el.uploadFiles(files);
        } finally {
          await el.dispose();
        }
      }
      log('info', `Đã tải lên ${files.length} tệp`, n);
    },

    async di_chuyen_chuot(n) {
      const { page: pg } = await ensureBrowserAndPage();
      const p = n.params || {};
      if ((p.target || 'element') === 'coordinates') {
        await humanMove(NUM(p.x_coordinates, 0), NUM(p.y_coordinates, 0));
      } else {
        const el = await pg.waitOne(p.selector_type || 'xpath', S(p.selector), NUM(p.timeout, 10), checkStopped);
        let box = null;
        try { box = await el.boundingBox(); } finally { await el.dispose(); }
        if (!box) throw new Error('Không lấy được vị trí phần tử');
        await humanMove(box.x + box.width / 2, box.y + box.height / 2);
      }
      log('info', 'Đã di chuyển chuột', n);
    },

    async chon_tuy_chon(n) {
      const { page: pg } = await ensureBrowserAndPage();
      const p = n.params || {};
      const el = await pg.waitOne(p.selector_type || 'xpath', S(p.selector), NUM(p.timeout, 10), checkStopped);
      const val = S(p.value);
      try {
        await el.select(val);
      } finally {
        await el.dispose();
      }
      log('info', `Đã chọn tùy chọn "${val}"`, n);
    },
  });

  // ── 4. DATA ────────────────────────────────────────────────────────────────
  Object.assign(exec, {
    async ngau_nhien(n) {
      const p = n.params || {};
      let out;
      if ((p.random_type || 'number') === 'number') {
        const lo = NUM(p.min, 0);
        const hi = NUM(p.max, 10);
        const mn = Math.min(lo, hi);
        const mx = Math.max(lo, hi);
        out = Math.floor(mn + Math.random() * (mx - mn + 1));
      } else {
        const len = Math.max(1, NUM(p.length, 10));
        let pool = '';
        if (p.has_upper_case !== false) pool += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        if (p.has_lower_case !== false) pool += 'abcdefghijklmnopqrstuvwxyz';
        if (p.has_number !== false) pool += '0123456789';
        if (p.has_special) pool += '!@#$%^&*()-_=+[]{}';
        if (!pool) pool = 'abcdefghijklmnopqrstuvwxyz';
        out = '';
        for (let i = 0; i < len; i += 1) {
          out += pool[Math.floor(Math.random() * pool.length)];
        }
      }
      setVar(p.variable_name, out);
      log('info', `Ngẫu nhiên = ${out}`, n);
    },

    async xu_ly_bien(n) {
      const p = n.params || {};
      const src = ctx.vars[String(p.variable || '').trim()];
      const m = p.method || 's_length';
      const str = src == null ? '' : String(src);
      const arr = Array.isArray(src) ? src : (src == null ? [] : [src]);
      let out;

      switch (m) {
        case 's_length': out = str.length; break;
        case 's_to_upper': out = str.toUpperCase(); break;
        case 's_capitalize': out = str.replace(/\b\w/g, (c) => c.toUpperCase()); break;
        case 's_to_lower': out = str.toLowerCase(); break;
        case 's_trim': out = str.trim(); break;
        case 's_substring': {
          const a = NUM(p.sub_start, 1) - 1;
          const b = (p.sub_end === '' || p.sub_end == null) ? undefined : NUM(p.sub_end, 0);
          out = str.substring(Math.max(0, a), b);
          break;
        }
        case 's_replace':
          out = p.replace_all
            ? str.split(S(p.search_value)).join(S(p.new_value))
            : str.replace(S(p.search_value), S(p.new_value));
          break;
        case 's_split': out = str.split(S(p.split_separator)); break;
        case 's_concat':
          out = [str, ...String(p.concat_strings == null ? '' : p.concat_strings).split(/\r?\n/)]
            .map((x) => interp(x, ctx))
            .filter((x) => x !== '')
            .join(S(p.concat_separator));
          break;
        case 's_json_parse':
          try { out = JSON.parse(str); } catch { throw new Error('JSON không hợp lệ'); }
          break;
        case 's_regex': out = regexApply(str, p); break;
        case 'a_length': out = arr.length; break;
        case 'a_random': out = arr.length ? arr[Math.floor(Math.random() * arr.length)] : undefined; break;
        case 'a_get_order': out = arr[NUM(p.order_number, 1) - 1]; break;
        case 'a_shuffle': {
          const copy = arr.slice();
          for (let i = copy.length - 1; i > 0; i -= 1) {
            const j = Math.floor(Math.random() * (i + 1));
            [copy[i], copy[j]] = [copy[j], copy[i]];
          }
          out = copy;
          break;
        }
        case 'a_slice': {
          const a = NUM(p.slice_start, 1) - 1;
          const b = (p.slice_end === '' || p.slice_end == null) ? undefined : NUM(p.slice_end, 0);
          out = arr.slice(Math.max(0, a), b);
          break;
        }
        case 'a_search':
        case 'a_filter': {
          if (p.conditions) {
            const pred = (item) => evalConditions(p.conditions, { vars: { ...ctx.vars, ITEM: item }, sys: ctx.sys });
            out = m === 'a_search' ? arr.find(pred) : arr.filter(pred);
          } else {
            out = arr;
            log('warn', `"${m === 'a_search' ? 'Tìm kiếm' : 'Bộ lọc'}" chưa có điều kiện - giữ nguyên danh sách`, n);
          }
          break;
        }
        case 'o_get_property': {
          out = getPath(src, S(p.path));
          if ((out === undefined || out === null) && p.is_return_default) {
            out = coerceDefaultVal(S(p.default_value), p.default_type);
          }
          break;
        }
        default: out = src;
      }
      setVar(p.variable_output, out);
      log('info', `Xử lý biến (${m})`, n);
    },

    async du_lieu_phan_tu(n) {
      const { page: pg } = await ensureBrowserAndPage();
      const p = n.params || {};
      const types = Array.isArray(p.data_types) ? p.data_types : [];
      const st = p.selector_type === 'css' ? 'css' : 'xpath';
      const sel = S(p.selector);

      if (types.length === 1 && types[0] === 'count') {
        const els = await pg.queryAll(st, sel);
        const cnt = els.length;
        els.forEach((e) => e.dispose().catch(() => {}));
        setVar(p.variable_name, cnt);
        log('info', `Số lượng phần tử = ${cnt}`, n);
        return;
      }

      const el = await pg.waitOne(st, sel, NUM(p.timeout, 30), checkStopped);
      const out = {};
      try {
        if (types.includes('position') || types.includes('size')) {
          const box = (await el.boundingBox()) || { x: 0, y: 0, width: 0, height: 0 };
          if (types.includes('position')) { out.x = box.x; out.y = box.y; }
          if (types.includes('size')) { out.width = box.width; out.height = box.height; }
        }
        if (types.includes('attribute')) {
          out.attribute = await el.evaluate((e, attr) => e.getAttribute(attr), S(p.data_path));
        }
        if (types.includes('count')) {
          const els = await pg.queryAll(st, sel);
          out.count = els.length;
          els.forEach((e) => e.dispose().catch(() => {}));
        }
      } finally {
        await el.dispose();
      }
      const keys = Object.keys(out);
      setVar(p.variable_name, keys.length === 1 ? out[keys[0]] : out);
      log('info', 'Đã lấy dữ liệu phần tử', n);
    },

    async gan_bien(n) {
      const p = n.params || {};
      const name = String(p.variable_name || '').trim();
      if (!name) throw new Error('Chưa chọn tên biến');
      const op = String(p.operator || '=').trim();
      const rawVal = p.value_two != null ? p.value_two : p.value;
      const rhs = typeof rawVal === 'string' ? S(rawVal) : rawVal;

      if (op === '=') {
        ctx.vars[name] = typeof rhs === 'string' ? coerceMaybeNum(rhs) : rhs;
      } else {
        const a = Number(ctx.vars[name] || 0);
        const b = Number(rhs);
        if (op === '+' || op === '+=') ctx.vars[name] = a + b;
        else if (op === '-' || op === '-=') ctx.vars[name] = a - b;
        else if (op === '*' || op === '*=') ctx.vars[name] = a * b;
        else if (op === '/' || op === '/=') ctx.vars[name] = b === 0 ? 0 : a / b;
        else ctx.vars[name] = a;
      }
      log('info', `${name} = ${JSON.stringify(ctx.vars[name])}`, n);
    },

    async math(n) {
      const p = n.params || {};
      const m = p.method || 'round';
      const raw = S(p.value);
      let out;
      const unary = { round: Math.round, floor: Math.floor, ceil: Math.ceil, trunc: Math.trunc, abs: Math.abs, sqrt: Math.sqrt };
      if (m === 'max' || m === 'min') {
        const nums = raw.replace(/[[\]"']/g, ' ').split(/[,\s]+/).map(Number).filter((x) => Number.isFinite(x));
        if (!nums.length) throw new Error('Không có số nào hợp lệ trong giá trị đã nhập');
        out = m === 'max' ? Math.max(...nums) : Math.min(...nums);
      } else if (unary[m]) {
        const v = Number(raw.trim());
        if (!Number.isFinite(v)) throw new Error(`Giá trị không phải số: "${raw}"`);
        out = unary[m](v);
      } else {
        throw new Error(`Phương thức toán học không hỗ trợ: ${m}`);
      }
      setVar(p.variable_name, out);
      log('info', `Toán học (${m}) = ${out}`, n);
    },

    async bang_tinh(n) {
      const p = n.params || {};
      if ((p.spreadsheet_type || 'excel') !== 'excel') {
        // Google Sheets v4 via `gsheet-api`
        const credFile = S(p.credentials_json);
        if (!credFile) throw new Error('Thiếu đường dẫn file json xác thực Google Sheets');
        const spreadsheetId = S(p.sheet_id);
        if (!spreadsheetId) throw new Error('Thiếu ID Bảng tính');
        const sheetName = S(p.sheet_name);
        const gact = p.action_type__google_sheet || 'read';

        if (gact === 'read') {
          const r = await gsheetApi.read({
            credentials: credFile,
            spreadsheetId,
            sheetName,
            range: S(p.range__read),
            firstRowAsKey: p.is_choose_first_rows_as_key__read !== false,
          });
          setVar(p.variable_name__read, r.data);
          log('info', `Đã đọc ${r.rowsCount} dòng từ Google Sheet "${r.sheetTitle}"`, n);
          return;
        }
        if (gact === 'find_row') {
          const r = await gsheetApi.find_row({
            credentials: credFile,
            spreadsheetId,
            sheetName,
            searchField: S(p.search_field__find_row),
            searchValue: S(p.search_value__find_row),
          });
          setVar(p.variable_name__find_row, r.data);
          log('info', r.found ? 'Tìm thấy hàng khớp trên Google Sheet' : 'Không tìm thấy hàng khớp trên Google Sheet', n);
          return;
        }
        if (gact === 'write') {
          const varName = String(p.data__write || '').trim();
          const r = await gsheetApi.write({
            credentials: credFile,
            spreadsheetId,
            sheetName,
            range: S(p.range__write),
            data: ctx.vars[varName],
            firstRowAsKey: p.is_choose_first_rows_as_key__write !== false,
          });
          log('info', `Đã ghi ${r.writtenRows} dòng lên Google Sheet`, n);
          return;
        }
        if (gact === 'append') {
          const varName = String(p.data__append || '').trim();
          const r = await gsheetApi.append({
            credentials: credFile,
            spreadsheetId,
            sheetName,
            data: ctx.vars[varName],
            firstRowAsKey: p.is_choose_first_rows_as_key__append !== false,
          });
          log('info', `Đã thêm ${r.appendedRows} dòng vào Google Sheet`, n);
          return;
        }
        if (gact === 'update') {
          const rawPatch = interp(p.data_update__update == null ? '' : String(p.data_update__update), ctx, { jsonSafe: true });
          const r = await gsheetApi.update({
            credentials: credFile,
            spreadsheetId,
            sheetName,
            searchField: S(p.search_field__update),
            searchValue: S(p.search_value__update),
            patch: rawPatch,
          });
          log('info', `Đã cập nhật ${r.updatedRows} hàng trên Google Sheet`, n);
          return;
        }
        if (gact === 'clear') {
          await gsheetApi.clear({
            credentials: credFile,
            spreadsheetId,
            sheetName,
            range: S(p.range__clear),
          });
          log('info', 'Đã xóa giá trị vùng ô trên Google Sheet', n);
          return;
        }
        if (gact === 'delete_row') {
          const r = await gsheetApi.delete_row({
            credentials: credFile,
            spreadsheetId,
            sheetName,
            searchField: S(p.search_field__delete_row),
            searchValue: S(p.search_value__delete_row),
          });
          log('info', `Đã xóa ${r.deletedRows} hàng trên Google Sheet`, n);
          return;
        }
        log('warn', `Thao tác Google Sheet "${gact}" chưa hỗ trợ`, n);
        return;
      }

      // Local CSV Spreadsheet
      const file = S(p.file_path);
      if (!file) throw new Error('Thiếu đường dẫn tệp CSV');
      if (/\.(xlsx|xls|xlsm|ods)$/i.test(file)) {
        throw new Error('Hiện bảng tính cục bộ hỗ trợ định dạng .csv - vui lòng xuất sang CSV hoặc dùng Google Sheets');
      }
      const act = p.action_type__excel || 'read';
      const readRows = () => (fs.existsSync(file) ? parseCsv(fs.readFileSync(file, 'utf8'), ',') : []);
      const saveRows = (rows) => { ensureDir(path.dirname(file)); fs.writeFileSync(file, toCsv(rows), 'utf8'); };
      const parseRange = (s) => {
        const m = String(s || '').trim().toUpperCase().match(/^([A-Z]+)(\d+)(?::([A-Z]+)(\d+))?$/);
        if (!m) return null;
        const col = (t) => t.split('').reduce((a, ch) => a * 26 + (ch.charCodeAt(0) - 64), 0) - 1;
        return { c1: col(m[1]), r1: Number(m[2]) - 1, c2: m[3] ? col(m[3]) : Infinity, r2: m[4] ? Number(m[4]) - 1 : Infinity };
      };

      if (act === 'read') {
        let rows = readRows();
        const rgTxt = S(p.range__read);
        if (rgTxt) {
          const rg = parseRange(rgTxt);
          if (!rg) throw new Error('Range không hợp lệ (ví dụ: A2:C10)');
          rows = rows.slice(rg.r1, rg.r2 === Infinity ? undefined : rg.r2 + 1)
            .map((r) => r.slice(rg.c1, rg.c2 === Infinity ? undefined : rg.c2 + 1));
        }
        let out = rows;
        if (p.is_choose_first_rows_as_key__read !== false && rows.length) {
          const hdr = rows[0];
          out = rows.slice(1).map((r) => {
            const o = {};
            hdr.forEach((h, i) => { o[h] = r[i]; });
            return o;
          });
        }
        setVar(p.variable_name__read, out);
        log('info', `Đã đọc ${out.length} dòng từ CSV`, n);
        return;
      }

      if (act === 'write' || act === 'append') {
        const rows = ctx.vars[String((act === 'write' ? p.data__write : p.data__append) || '').trim()];
        const list = Array.isArray(rows) ? rows : (rows != null ? [rows] : []);
        const lines = [];
        const asKey = (act === 'write' ? p.is_choose_first_rows_as_key__write : p.is_choose_first_rows_as_key__append) !== false;
        if (list.length && typeof list[0] === 'object' && !Array.isArray(list[0])) {
          const hdr = Object.keys(list[0]);
          if (asKey && (act === 'write' || !fs.existsSync(file))) lines.push(hdr);
          list.forEach((r) => lines.push(hdr.map((h) => r[h])));
        } else {
          list.forEach((r) => lines.push(Array.isArray(r) ? r : [r]));
        }
        ensureDir(path.dirname(file));
        const csv = toCsv(lines);
        if (act === 'append' && fs.existsSync(file) && fs.statSync(file).size > 0) {
          fs.appendFileSync(file, `\r\n${csv}`, 'utf8');
        } else {
          fs.writeFileSync(file, csv, 'utf8');
        }
        log('info', `Đã ${act === 'write' ? 'ghi' : 'thêm'} ${list.length} dòng vào CSV`, n);
        return;
      }

      if (act === 'update' || act === 'delete_row') {
        const rows = readRows();
        if (rows.length < 2) throw new Error('Tệp CSV rỗng hoặc chỉ có hàng tiêu đề');
        const hdr = rows[0];
        const body = rows.slice(1);
        const field = S(act === 'update' ? p.search_field__update : p.search_field__delete_row);
        const value = S(act === 'update' ? p.search_value__update : p.search_value__delete_row);
        const ci = hdr.indexOf(field);
        if (ci < 0) throw new Error(`Không tìm thấy cột "${field}" ở hàng tiêu đề`);
        const hit = [];
        body.forEach((r, i) => { if (String(r[ci] == null ? '' : r[ci]) === value) hit.push(i); });
        if (!hit.length) { log('warn', `Không có hàng nào khớp ${field} = ${value}`, n); return; }
        if (act === 'delete_row') {
          const drop = new Set(hit);
          saveRows([hdr, ...body.filter((_, i) => !drop.has(i))]);
          log('info', `Đã xóa ${hit.length} hàng khỏi CSV`, n);
          return;
        }
        let patch;
        const raw = interp(p.data_update__update == null ? '' : String(p.data_update__update), ctx, { jsonSafe: true });
        try { patch = JSON.parse(raw); } catch { patch = null; }
        if (!patch || typeof patch !== 'object' || Array.isArray(patch)) {
          throw new Error('"Dữ liệu cập nhật" phải là JSON dạng {"tên cột":"giá trị"}');
        }
        Object.keys(patch).forEach((k) => { if (hdr.indexOf(k) < 0) hdr.push(k); });
        hit.forEach((i) => {
          Object.entries(patch).forEach(([k, v]) => { body[i][hdr.indexOf(k)] = v == null ? '' : String(v); });
        });
        saveRows([hdr, ...body]);
        log('info', `Đã cập nhật ${hit.length} hàng trong CSV`, n);
        return;
      }

      if (act === 'clear') {
        const rg = parseRange(S(p.range__clear));
        if (!rg) throw new Error('Range không hợp lệ (ví dụ: A2:C10)');
        const rows = readRows();
        const rEnd = Math.min(rg.r2, rows.length - 1);
        for (let r = rg.r1; r <= rEnd; r += 1) {
          if (!rows[r]) continue;
          const cEnd = Math.min(rg.c2, rows[r].length - 1);
          for (let c = rg.c1; c <= cEnd; c += 1) rows[r][c] = '';
        }
        saveRows(rows);
        log('info', 'Đã xóa giá trị ô CSV', n);
      }
    },
  });

  // ── 5. FILE ────────────────────────────────────────────────────────────────
  Object.assign(exec, {
    async ghi_tep(n) {
      const p = n.params || {};
      const file = S(p.file_path);
      if (!file) throw new Error('Thiếu đường dẫn tệp');
      ensureDir(path.dirname(file));
      const data = S(p.input_data);
      const wm = p.write_mode || 'owrite';
      if (wm === 'append') {
        let pre = '';
        if (fs.existsSync(file) && fs.statSync(file).size > 0) {
          pre = p.append_type === 'same_line' ? S(p.delimiter) : '\n';
        }
        fs.appendFileSync(file, pre + data, 'utf8');
      } else if (wm === 'create' || wm === 'wx') {
        fs.writeFileSync(file, data, { encoding: 'utf8', flag: 'wx' });
      } else {
        fs.writeFileSync(file, data, 'utf8');
      }
      log('info', `Đã ghi tệp: ${file}`, n);
    },

    async xoa_tep(n) {
      const p = n.params || {};
      const file = S(p.file_path);
      if (file && fs.existsSync(file)) fs.unlinkSync(file);
      log('info', `Đã xóa tệp: ${file}`, n);
    },

    async doc_tep_txt(n) {
      const p = n.params || {};
      const file = S(p.file_path);
      if (!file || !fs.existsSync(file)) throw new Error(`Tệp không tồn tại: ${file}`);
      const lines = fs.readFileSync(file, 'utf8').split(/\r?\n/);
      let out;
      if ((p.mode || 'all_line') === 'all_line') {
        out = lines;
      } else {
        const nonEmpty = [];
        lines.forEach((l, i) => { if (l.length) nonEmpty.push(i); });
        if (!nonEmpty.length) throw new Error('Tệp không có dòng nội dung nào');
        let k;
        if (p.line_position === 'first') k = 0;
        else if (p.line_position === 'last') k = nonEmpty.length - 1;
        else k = Math.floor(Math.random() * nonEmpty.length);
        const row = nonEmpty[k];
        out = lines[row];
        if (p.is_delete_after_read !== false) {
          lines.splice(row, 1);
          fs.writeFileSync(file, lines.join('\n'), 'utf8');
        }
      }
      setVar(p.variable_name, out);
      log('info', 'Đã đọc tệp txt', n);
    },

    async doc_thu_muc(n) {
      const p = n.params || {};
      const dir = S(p.folder_path);
      if (!dir || !fs.existsSync(dir)) throw new Error(`Thư mục không tồn tại: ${dir}`);
      const out = [];
      const walk = (d) => {
        for (const e of fs.readdirSync(d, { withFileTypes: true })) {
          const full = path.join(d, e.name);
          if (e.isDirectory()) {
            if (p.include_subdirectories) walk(full);
          } else {
            out.push(full);
          }
        }
      };
      walk(dir);
      setVar(p.variable_name, out);
      log('info', `Đã đọc ${out.length} tệp trong thư mục`, n);
    },
  });

  // ── 6. API, AI & OTHER ─────────────────────────────────────────────────────
  Object.assign(exec, {
    async lay_ma_otp_2fa(n) {
      const p = n.params || {};
      const secret = S(p.two_fa).replace(/\s/g, '');
      if (!secret) throw new Error('Thiếu khóa 2FA');
      const code = totp(secret);
      setVar(p.variable_name, code);
      log('info', `Đã tạo mã OTP 2FA: ${code}`, n);
    },

    async facebook_api(n) {
      const { page: pg } = await ensureBrowserAndPage();
      const p = n.params || {};
      const apiType = p.api_type || 'getCurrentUserData';
      if (apiType === 'getCurrentUserData') {
        const cookies = await pg.getAllCookies();
        const cUser = cookies.find((c) => c.name === 'c_user' && (c.domain || '').includes('facebook'));
        const info = await pg.evaluate(() => ({
          url: location.href,
          title: document.title,
        })).catch(() => ({}));
        const data = { uid: cUser ? cUser.value : '', ...info };
        setVar(p.variable_name, data);
        log('info', `Facebook user UID = ${data.uid || '(chưa đăng nhập)'}`, n);
        return;
      }
      if (apiType === 'switchProfilePage' && p.profile_id) {
        await pg.goto(`https://www.facebook.com/${encodeURIComponent(S(p.profile_id))}`);
        log('info', `Đã chuyển tới trang Facebook ${S(p.profile_id)}`, n);
        return;
      }
      log('warn', `Gói Facebook API "${apiType}" yêu cầu phiên Graph mở rộng - bỏ qua`, n);
    },

    async chatgpt(n) {
      const p = n.params || {};
      const key = S(p.api_key);
      if (!key) throw new Error('Thiếu OpenAI API key');
      if ((p.output_type || 'text') === 'image') {
        const size = p.image_size || '1024x1024';
        const fmt = p.response_type === 'base64' ? 'b64_json' : 'url';
        const body = { model: 'dall-e-3', prompt: S(p.prompt__image), size, response_format: fmt, n: 1 };
        const res = await fetch('https://api.openai.com/v1/images/generations', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
          body: JSON.stringify(body),
        });
        const j = await res.json();
        if (!res.ok) throw new Error((j.error && j.error.message) || `HTTP ${res.status}`);
        const d = (j.data && j.data[0]) || {};
        setVar(p.variable_output, d.url || d.b64_json || '');
      } else {
        const model = (p.model === 'custom' ? S(p.model_custom) : p.model) || 'gpt-4o-mini';
        const res = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
          body: JSON.stringify({ model, messages: [{ role: 'user', content: S(p.prompt__text || p.prompt) }] }),
        });
        const j = await res.json();
        if (!res.ok) throw new Error((j.error && j.error.message) || `HTTP ${res.status}`);
        setVar(p.variable_output, (j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content) || '');
      }
      log('info', 'ChatGPT hoàn tất', n);
    },

    async gemini(n) {
      const p = n.params || {};
      const key = S(p.api_key);
      if (!key) throw new Error('Thiếu Gemini API key');
      const model = (p.model === 'custom' ? S(p.model_custom) : p.model) || 'gemini-2.5-flash';
      if (/embedding/i.test(model)) {
        throw new Error(`Model "${model}" là model embedding, không hỗ trợ generateContent`);
      }
      const parts = [{ text: S(p.prompt) }];
      const imgPath = S(p.image_attachment);
      if (imgPath && fs.existsSync(imgPath)) {
        const ext = (path.extname(imgPath).slice(1) || 'png').toLowerCase();
        const mime = ext === 'jpg' ? 'image/jpeg' : `image/${ext}`;
        parts.push({ inline_data: { mime_type: mime, data: fs.readFileSync(imgPath).toString('base64') } });
      }
      const res = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ contents: [{ parts }] }),
        }
      );
      const j = await res.json();
      if (!res.ok) throw new Error((j.error && j.error.message) || `HTTP ${res.status}`);
      const outParts = (((j.candidates || [])[0] || {}).content || {}).parts;
      setVar(p.variable_output, (outParts && outParts[0] && outParts[0].text) || '');
      log('info', 'Gemini hoàn tất', n);
    },

    async commandCmd(n) {
      const p = n.params || {};
      const cmd = S(p.command);
      if (!cmd) throw new Error('Lệnh CMD trống');
      if (p.waitForOutput) {
        const out = await new Promise((resolve, reject) => {
          cp.exec(cmd, { windowsHide: true, timeout: 120000 }, (err, stdout) => (err ? reject(err) : resolve(stdout)));
        });
        if (p.variable_name) setVar(p.variable_name, String(out));
        log('info', `Kết quả CMD: ${String(out).trim().slice(0, 200)}`, n);
      } else {
        cp.exec(cmd, { windowsHide: true }, () => {});
        log('info', 'Đã phát lệnh CMD nền', n);
      }
    },
  });

  // ───────────────────────────────────────────────────────────────────────────
  // GRAPH INSTRUCTION-POINTER INTERPRETER (`FLOW` NODES + LOOP STACK)
  // ───────────────────────────────────────────────────────────────────────────

  const LOOP_START = new Set(['lap_du_lieu', 'lap_co_dieu_kien']);
  const BRANCH_TRUE = ['if', 'true', 'then', 'Đúng', 'yes', '1'];
  const BRANCH_FALSE = ['else', 'false', 'Sai', 'no', '0'];

  const branchOut = (g, id, names) => {
    for (const b of names) {
      const t = g.nextOf(id, b);
      if (t != null) return t;
    }
    return null;
  };

  function nextDefault(g, id) {
    const hit = g.nextOf(id, null);
    if (hit != null) return hit;
    const edges = g.outsOf(id);
    return edges.length ? edges[0].target : null;
  }

  function findLoopEnd(g, startNode) {
    const lid = String((startNode.params || {}).loop_id || '').trim();
    if (lid) {
      const hit = g.nodes.find(
        (n) => n.type === 'diem_cuoi_vong_lap' && String((n.params || {}).loop_id || '').trim() === lid
      );
      if (hit) return hit.id;
    }
    let cur = nextDefault(g, startNode.id);
    let depth = 0;
    const seen = new Set();
    while (cur != null && !seen.has(cur)) {
      seen.add(cur);
      const n = g.byId.get(cur);
      if (!n) break;
      if (LOOP_START.has(n.type)) depth += 1;
      else if (n.type === 'diem_cuoi_vong_lap') {
        if (depth === 0) return n.id;
        depth -= 1;
      }
      cur = nextDefault(g, cur);
    }
    return null;
  }

  async function findElsFromSelectorField(sel) {
    if (!sel) return [];
    const { page: pg } = await ensureBrowserAndPage();
    if (typeof sel === 'string') {
      const v = S(sel);
      return pg.queryAll(v.startsWith('/') ? 'xpath' : 'css', v);
    }
    if (sel.tab === 'stored') {
      log('warn', 'Bộ chọn đã lưu chưa được cấu hình - vui lòng nhập trực tiếp');
      return [];
    }
    const mode = String(sel.mode || 'Selector').toLowerCase();
    const value = S(sel.value);
    if (!value) return [];
    if (mode === 'xpath') return pg.queryAll('xpath', value);
    if (mode === 'text') return pg.queryAll('text', value);
    return pg.queryAll('css', value);
  }

  async function dataLoopItems(node) {
    const p = node.params || {};
    const through = p.loop_through || 'number';
    if (through === 'number') {
      const from = NUM(p.from, 1);
      const to = NUM(p.to, 10);
      const out = [];
      const dir = from <= to ? 1 : -1;
      for (let v = from; dir > 0 ? v <= to : v >= to; v += dir) {
        out.push(v);
        if (out.length > MAX_ITERS) break;
      }
      return out;
    }

    let base = [];
    if (through === 'variable') {
      const refKey = String(p.refererce_key || p.reference_key || '').trim();
      const src = ctx.vars[refKey];
      if (Array.isArray(src)) base = src;
      else if (src && typeof src === 'object') base = Object.values(src);
      else if (src != null) base = [src];
    } else if (through === 'element') {
      let els = await findElsFromSelectorField(p.element_selector);
      if (!els.length && p.selector_switch) {
        const until = Date.now() + Math.max(1, NUM(p.selector_timeout, 30)) * 1000;
        while (!els.length && Date.now() < until) {
          if (checkStopped()) throw new StopSignal('stopped');
          await sleep(250);
          els = await findElsFromSelectorField(p.element_selector);
        }
      }
      if (!els.length) log('warn', 'Không tìm thấy phần tử khớp bộ chọn - vòng lặp chạy 0 lần', node);
      for (const el of els) {
        const v = await el.evaluate((e) => ({
          text: e.innerText != null ? e.innerText : e.textContent,
          html: e.outerHTML,
        })).catch(() => ({}));
        base.push(v);
        await el.dispose();
      }
    }

    const startIdx = Math.max(1, NUM(p.index_start, 1)) - 1;
    let sliced = base.slice(startIdx);
    const maxLoop = NUM(p.max_loop, 0);
    if (maxLoop > 0 && sliced.length > maxLoop) sliced = sliced.slice(0, maxLoop);
    return sliced;
  }

  const loopStack = [];

  async function makeLoopFrame(g, node) {
    const p = node.params || {};
    const isCond = node.type === 'lap_co_dieu_kien';
    const loopId = String(p.loop_id || '').trim();
    if (!ctx.vars.loop || typeof ctx.vars.loop !== 'object') ctx.vars.loop = {};
    const scope = {};
    if (loopId) ctx.vars.loop[loopId] = scope;
    const plainKey = (v) => {
      const s = String(v == null ? '' : v).trim();
      return /^[A-Za-z_$][\w$]*$/.test(s) ? s : '';
    };
    const dataKey = plainKey(p.data);
    const orderKey = plainKey(p.loop_order);
    log('info', `Bắt đầu vòng lặp (${isCond ? 'điều kiện' : 'dữ liệu'}${loopId ? `: ${loopId}` : ''})`, node);
    return {
      loopId,
      startId: node.id,
      endId: findLoopEnd(g, node),
      isCond,
      items: isCond ? null : await dataLoopItems(node),
      idx: 0,
      count: 0,
      setScope(item, order) {
        scope.data = item;
        scope.loop_order = order;
        if (dataKey) ctx.vars[dataKey] = item;
        if (orderKey) ctx.vars[orderKey] = order;
      },
    };
  }

  function exitLoop(g, frame, node) {
    const pos = loopStack.indexOf(frame);
    if (pos >= 0) loopStack.splice(pos);
    else loopStack.pop();
    log('info', `Kết thúc vòng lặp (${frame.count} lần)`, node);
    if (frame.endId == null) {
      log('warn', 'Không tìm thấy "Điểm cuối vòng lặp" - luồng dừng tại đây', node);
      return null;
    }
    return nextDefault(g, frame.endId);
  }

  async function stepLoop(g, node) {
    let frame = loopStack[loopStack.length - 1];
    if (!frame || frame.startId !== node.id) {
      frame = await makeLoopFrame(g, node);
      loopStack.push(frame);
    }
    if (frame.count >= MAX_ITERS) return exitLoop(g, frame, node);
    if (frame.isCond) {
      const pass = evalConditions((node.params || {}).conditions);
      if (condTrace) log('info', `Xét điều kiện lặp: ${condTrace}`, node);
      if (!pass) return exitLoop(g, frame, node);
      frame.setScope(undefined, frame.count + 1);
    } else {
      if (frame.idx >= frame.items.length) return exitLoop(g, frame, node);
      frame.setScope(frame.items[frame.idx], frame.idx + 1);
      frame.idx += 1;
    }
    frame.count += 1;
    const body = nextDefault(g, node.id);
    return body != null ? body : exitLoop(g, frame, node);
  }

  function stepLoopEnd(g, node) {
    const lid = String((node.params || {}).loop_id || '').trim();
    let hit = loopStack.findIndex((f) => f.endId === node.id);
    if (hit < 0 && lid) {
      hit = loopStack.findIndex((f) => f.loopId === lid);
    }
    if (hit >= 0) {
      while (loopStack.length - 1 > hit) {
        const inner = loopStack.pop();
        log('info', `Kết thúc vòng lặp (${inner.count} lần)`, node);
      }
      return loopStack[hit].startId;
    }
    const frame = loopStack[loopStack.length - 1];
    if (frame && frame.endId == null) {
      frame.endId = node.id;
      return frame.startId;
    }
    return nextDefault(g, node.id);
  }

  function stepBreak(g, node) {
    const lid = String((node.params || {}).loop_id || '').trim();
    let frame = loopStack[loopStack.length - 1];
    if (lid) {
      const byId = [...loopStack].reverse().find((f) => f.loopId === lid);
      if (byId) frame = byId;
    }
    log('info', 'Dừng vòng lặp', node);
    if (!frame) return nextDefault(g, node.id);
    return exitLoop(g, frame, node);
  }

  function stepContinue(g, node) {
    const lid = String((node.params || {}).loop_id || '').trim();
    let frame = loopStack[loopStack.length - 1];
    if (lid) {
      const byId = [...loopStack].reverse().find((f) => f.loopId === lid);
      if (byId) frame = byId;
    }
    log('info', 'Tiếp tục vòng lặp', node);
    if (!frame) return nextDefault(g, node.id);
    while (loopStack.length && loopStack[loopStack.length - 1] !== frame) {
      loopStack.pop();
    }
    return frame.startId;
  }

  async function stepCondition(g, node) {
    const p = node.params || {};
    const check = () => evalConditions(p.conditions);
    let ok = check();
    if (!ok && p.retry) {
      const tries = Math.max(1, NUM(p.try_for, 10));
      const gap = Math.max(0, NUM(p.timeout, 1000));
      for (let i = 0; i < tries && !ok; i += 1) {
        await sleep(gap);
        ok = check();
      }
    }
    if (condTrace) log('info', `Xét điều kiện: ${condTrace}`, node);

    const want = ok ? 'if' : 'else';
    const hit = branchOut(g, node.id, ok ? BRANCH_TRUE : BRANCH_FALSE);
    if (hit != null) {
      const to = g.byId.get(hit);
      log('info', `Điều kiện: ${ok ? 'đúng' : 'sai'} -> nhánh "${want}"${to ? ` (${to.title || to.type})` : ''}`, node);
      return hit;
    }

    const hasPorts = g.outsOf(node.id).some((e) => e.branch != null);
    if (hasPorts) {
      log('info', `Điều kiện: ${ok ? 'đúng' : 'sai'} -> cổng "${want}" để trống, kết thúc nhánh`, node);
      return null;
    }

    const plain = g.nextOf(node.id, null);
    if (ok) return plain;
    if (errPolicy(node) !== 'Bỏ qua') throw new Error('Điều kiện không thỏa mãn (cổng "else" chưa nối dây)');
    return plain;
  }

  let skipped = 0;

  async function stepNode(g, node) {
    guard();
    if (node.disabled) {
      log('info', 'Bỏ qua bước đã tắt', node);
      return nextDefault(g, node.id);
    }
    try {
      switch (node.type) {
        case 'start':
        case 'note':
          return nextDefault(g, node.id);
        case 'lap_du_lieu':
        case 'lap_co_dieu_kien':
          return await stepLoop(g, node);
        case 'diem_cuoi_vong_lap':
          return stepLoopEnd(g, node);
        case 'dung_vong_lap':
          return stepBreak(g, node);
        case 'tiep_tuc_vong_lap':
          return stepContinue(g, node);
        case 'dieu_kien':
          return await stepCondition(g, node);
        default:
          break;
      }

      const fn = exec[node.type];
      if (!fn) {
        log('warn', `Loại node "${node.type}" chưa được hỗ trợ - bỏ qua`, node);
        return nextDefault(g, node.id);
      }
      await fn(node);
    } catch (e) {
      if (e instanceof StopSignal) throw e;
      log('error', `Lỗi: ${e.message}`, node);
      if (errPolicy(node) !== 'Bỏ qua') throw e;
      skipped += 1;
    }
    return nextDefault(g, node.id);
  }

  async function applyStartDelay() {
    const delayMs = Math.max(0, Number(settings.delayMin) || 0) * 60000;
    if (delayMs > 0) {
      log('info', `Trì hoãn ${settings.delayMin} phút trước khi chạy...`);
      await sleep(delayMs);
    }
  }

  async function applyCompleteBrowser() {
    if (settings.onCompleteBrowser === 'Đóng trình duyệt') {
      if (typeof hooks.closeBrowser === 'function') {
        await hooks.closeBrowser(profMeta).catch(() => {});
      } else if (profileId) {
        const launcher = getLauncher();
        if (launcher && typeof launcher.stopProfile === 'function') {
          await launcher.stopProfile(profileId).catch(() => {});
        }
      }
    }
  }

  const startNode = mainGraph.nodes.find((n) => n.type === 'start') || mainGraph.nodes[0];

  try {
    // Connect upfront if an explicit CDP endpoint/client/userDataDir was supplied and autoConnect !== false
    if (hasExplicitCdp && settings.autoConnect !== false && opts.connectUpfront !== false) {
      await ensureBrowserAndPage();
    }

    await applyStartDelay();

    let cur = startNode ? startNode.id : null;
    while (cur != null) {
      const node = mainGraph.byId.get(cur);
      if (!node) break;
      cur = await stepNode(mainGraph, node);
    }

    if (skipped > 0) {
      log('warn', `Quy trình kết thúc với ${skipped} bước bị lỗi (được bỏ qua)`);
      await applyCompleteBrowser();
      return { ok: true, runId, skipped, stepsExecuted: ctx.steps, vars: ctx.vars };
    }

    log('success', 'Quy trình hoàn tất');
    await applyCompleteBrowser();
    return { ok: true, runId, skipped: 0, stepsExecuted: ctx.steps, vars: ctx.vars };
  } catch (e) {
    if (e instanceof StopSignal) {
      if (e.reason === 'close_browser') {
        log('success', 'Quy trình kết thúc (đã đóng trình duyệt)');
        return { ok: true, runId, closedBrowser: true, stepsExecuted: ctx.steps, vars: ctx.vars };
      }
      log('warn', `Đã dừng quy trình: ${e.message}`);
      return { ok: false, runId, stopped: true, vars: ctx.vars };
    }
    log('error', `Quy trình thất bại: ${e.message}`);
    return { ok: false, runId, error: e.message, vars: ctx.vars };
  } finally {
    activeRuns.delete(runId);
    if (browser) {
      await browser.disconnect().catch(() => {});
    }
  }
}

module.exports = {
  init,
  runFlow,
  run: runFlow,
  stopRun,
  stopAllRuns,
  isRunActive,
  listActiveRuns,
  // Exported helpers for testing & composition
  totp,
  base32Decode,
  compare,
  interp,
  getPath,
  buildGraph,
  normalizeFlowToGraph,
  stepsToGraph,
  CdpPage,
  CdpBrowser,
  CdpElementHandle,
};
