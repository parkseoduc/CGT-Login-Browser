'use strict';

/**
 * CGT-Login v2.0 — Direct Google Sheets v4 REST API Client
 * Uses pure `node:crypto` RS256 JWT signing + built-in `fetch`/`https` with ~59m token cache.
 * Supports actions: `read`, `find_row`, `write`, `append`, `update`, `clear`, `delete_row`.
 * Zero external dependencies.
 */

const fs = require('node:fs');
const https = require('node:https');
const crypto = require('node:crypto');

const TOKEN_URL = 'https://oauth2.googleapis.com/token';
const API_BASE = 'https://sheets.googleapis.com/v4/spreadsheets';
const SCOPE = 'https://www.googleapis.com/auth/spreadsheets';

// client_email -> { token, exp(ms) }. Tokens live ~60m; reuse until 60s before expiry (~59m).
const tokenCache = new Map();

function b64url(buf) {
  return Buffer.from(buf)
    .toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
}

/**
 * Fallback HTTPS request helper in case `globalThis.fetch` is unavailable or mocked.
 */
function httpJsonRequest(urlStr, opts = {}) {
  if (typeof globalThis.fetch === 'function') {
    return globalThis.fetch(urlStr, opts).then(async (res) => {
      const text = await res.text();
      return { ok: res.ok, status: res.status, statusText: res.statusText, text };
    });
  }
  return new Promise((resolve, reject) => {
    const u = new URL(urlStr);
    const bodyBuf = opts.body ? Buffer.from(String(opts.body), 'utf8') : null;
    const req = https.request({
      hostname: u.hostname,
      port: u.port || 443,
      path: u.pathname + u.search,
      method: opts.method || 'GET',
      headers: {
        ...(opts.headers || {}),
        ...(bodyBuf ? { 'Content-Length': bodyBuf.length } : {}),
      },
    }, (res) => {
      let text = '';
      res.setEncoding('utf8');
      res.on('data', (chunk) => { text += chunk; });
      res.on('end', () => {
        const status = res.statusCode || 0;
        resolve({
          ok: status >= 200 && status < 300,
          status,
          statusText: res.statusMessage || '',
          text,
        });
      });
    });
    req.on('error', reject);
    if (bodyBuf) req.write(bodyBuf);
    req.end();
  });
}

/**
 * Load & validate Google Service Account credentials from a `.json` file path,
 * raw JSON string, or parsed object.
 */
function loadCredentials(credInput) {
  if (!credInput) {
    throw new Error('Thiếu thông tin xác thực Google Service Account');
  }
  let cred = null;
  if (typeof credInput === 'object') {
    cred = credInput;
  } else {
    const str = String(credInput).trim();
    if (str.startsWith('{')) {
      try {
        cred = JSON.parse(str);
      } catch {
        throw new Error('Chuỗi JSON xác thực không hợp lệ');
      }
    } else {
      let raw;
      try {
        raw = fs.readFileSync(str, 'utf8');
      } catch {
        throw new Error(`Không đọc được file json xác thực: ${str}`);
      }
      try {
        cred = JSON.parse(raw);
      } catch {
        throw new Error('File json xác thực không phải JSON hợp lệ');
      }
    }
  }

  if (!cred || cred.type !== 'service_account' || !cred.client_email || !cred.private_key) {
    throw new Error(
      'File json phải là khóa "service_account" (có client_email và private_key). Hãy tải đúng file khóa từ Google Cloud Console.'
    );
  }
  return cred;
}

/**
 * Sign an RS256 JWT assertion using `node:crypto` and exchange it for an OAuth2 access token.
 * Cached for ~59 minutes per `client_email`.
 */
async function getAccessToken(credInput) {
  const cred = loadCredentials(credInput);
  const cached = tokenCache.get(cred.client_email);
  const now = Date.now();
  if (cached && cached.exp - 60000 > now) {
    return cached.token;
  }

  const iat = Math.floor(now / 1000);
  const exp = iat + 3600;
  const header = b64url(JSON.stringify({ alg: 'RS256', typ: 'JWT' }));
  const claim = b64url(JSON.stringify({
    iss: cred.client_email,
    scope: SCOPE,
    aud: cred.token_uri || TOKEN_URL,
    iat,
    exp,
  }));

  const signingInput = `${header}.${claim}`;
  const signer = crypto.createSign('RSA-SHA256');
  signer.update(signingInput);
  let signature;
  try {
    signature = signer.sign(cred.private_key);
  } catch {
    throw new Error('Không ký được JWT - private_key trong file json không hợp lệ');
  }
  const assertion = `${signingInput}.${b64url(signature)}`;

  const body = new URLSearchParams({
    grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer',
    assertion,
  });

  const res = await httpJsonRequest(cred.token_uri || TOKEN_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: body.toString(),
  });

  let data = {};
  try { data = res.text ? JSON.parse(res.text) : {}; } catch { data = {}; }
  if (!res.ok || !data.access_token) {
    throw new Error(`Lấy access token thất bại: ${data.error_description || data.error || res.status}`);
  }

  const ttlMs = (Number(data.expires_in) || 3600) * 1000;
  tokenCache.set(cred.client_email, { token: data.access_token, exp: now + ttlMs });
  return data.access_token;
}

async function apiFetch(token, url, opts = {}) {
  const res = await httpJsonRequest(url, {
    ...opts,
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
      ...(opts.headers || {}),
    },
  });
  let data;
  try {
    data = res.text ? JSON.parse(res.text) : {};
  } catch {
    data = { raw: res.text };
  }
  if (!res.ok) {
    const msg = (data && data.error && data.error.message) || res.statusText || `HTTP ${res.status}`;
    throw new Error(`Google Sheets API lỗi: ${msg}`);
  }
  return data;
}

function qualifyRange(title, a1) {
  const t = String(title || '').replace(/'/g, "''");
  return a1 ? `'${t}'!${a1}` : `'${t}'`;
}

async function getSheetMeta(token, spreadsheetId, sheetName) {
  const data = await apiFetch(
    token,
    `${API_BASE}/${encodeURIComponent(spreadsheetId)}?fields=sheets.properties`
  );
  const sheets = (data.sheets || []).map((s) => s.properties).filter(Boolean);
  if (!sheets.length) throw new Error('Bảng tính không có trang tính nào');
  const titles = sheets.map((s) => s.title);
  const want = String(sheetName || '').trim();
  let found = want ? sheets.find((s) => s.title === want) : sheets[0];
  if (!found && want) {
    found = sheets.find((s) => s.title.trim().toLowerCase() === want.toLowerCase());
  }
  if (!found) {
    throw new Error(`Không tìm thấy trang tính tên "${want}". Các tab đang có: ${titles.map((t) => `"${t}"`).join(', ')}`);
  }
  return { sheetId: found.sheetId, title: found.title, titles };
}

async function getValues(token, spreadsheetId, range) {
  const data = await apiFetch(
    token,
    `${API_BASE}/${encodeURIComponent(spreadsheetId)}/values/${encodeURIComponent(range)}?majorDimension=ROWS&valueRenderOption=UNFORMATTED_VALUE`
  );
  return data.values || [];
}

async function updateValues(token, spreadsheetId, range, values) {
  return apiFetch(
    token,
    `${API_BASE}/${encodeURIComponent(spreadsheetId)}/values/${encodeURIComponent(range)}?valueInputOption=RAW`,
    {
      method: 'PUT',
      body: JSON.stringify({ range, majorDimension: 'ROWS', values }),
    }
  );
}

async function appendValues(token, spreadsheetId, range, values) {
  return apiFetch(
    token,
    `${API_BASE}/${encodeURIComponent(spreadsheetId)}/values/${encodeURIComponent(range)}:append?valueInputOption=RAW&insertDataOption=INSERT_ROWS`,
    {
      method: 'POST',
      body: JSON.stringify({ range, majorDimension: 'ROWS', values }),
    }
  );
}

async function clearValues(token, spreadsheetId, range) {
  return apiFetch(
    token,
    `${API_BASE}/${encodeURIComponent(spreadsheetId)}/values/${encodeURIComponent(range)}:clear`,
    {
      method: 'POST',
      body: '{}',
    }
  );
}

async function deleteRows(token, spreadsheetId, sheetId, absoluteRowIndices) {
  const sorted = [...new Set(absoluteRowIndices)].sort((a, b) => b - a);
  const requests = sorted.map((r) => ({
    deleteDimension: {
      range: { sheetId, dimension: 'ROWS', startIndex: r, endIndex: r + 1 },
    },
  }));
  if (!requests.length) return null;
  return apiFetch(
    token,
    `${API_BASE}/${encodeURIComponent(spreadsheetId)}:batchUpdate`,
    {
      method: 'POST',
      body: JSON.stringify({ requests }),
    }
  );
}

function rowsToObjects(rows) {
  if (!Array.isArray(rows) || !rows.length) return [];
  const hdr = rows[0].map((h) => (h == null ? '' : String(h)));
  return rows.slice(1).map((r) => {
    const o = {};
    hdr.forEach((h, i) => {
      o[h] = r[i] == null ? '' : r[i];
    });
    return o;
  });
}

function valueToGrid(value, includeHeader = true) {
  if (value == null) return [];
  if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
    const lines = String(value).replace(/\r\n/g, '\n').split('\n');
    if (lines.length && lines[lines.length - 1] === '') lines.pop();
    return lines.map((ln) => (ln.includes('\t') ? ln.split('\t') : [ln]));
  }
  const list = Array.isArray(value) ? value : [];
  const grid = [];
  if (list.length && typeof list[0] === 'object' && list[0] !== null && !Array.isArray(list[0])) {
    const hdr = Object.keys(list[0]);
    if (includeHeader) grid.push(hdr);
    list.forEach((r) => grid.push(hdr.map((h) => (r[h] == null ? '' : r[h]))));
  } else {
    list.forEach((r) => grid.push(Array.isArray(r) ? r : [r]));
  }
  return grid;
}

/**
 * High-level Google Sheets operations (`read`, `find_row`, `write`, `append`, `update`, `clear`, `delete_row`).
 */
async function read({ credentials, spreadsheetId, sheetName = '', range = '', firstRowAsKey = true }) {
  const token = await getAccessToken(credentials);
  const meta = await getSheetMeta(token, spreadsheetId, sheetName);
  const rgTxt = String(range || '').trim();
  const rows = await getValues(token, spreadsheetId, qualifyRange(meta.title, rgTxt));
  const isSingleCell = /^[A-Za-z]+\d+$/.test(rgTxt);
  let data;
  if (isSingleCell) {
    data = rows.length && rows[0].length ? rows[0][0] : '';
  } else {
    data = firstRowAsKey && rows.length > 1 ? rowsToObjects(rows) : rows;
  }
  return { data, rowsCount: Array.isArray(data) ? data.length : (data === '' ? 0 : 1), sheetTitle: meta.title };
}

async function find_row({ credentials, spreadsheetId, sheetName = '', searchField, searchValue }) {
  const token = await getAccessToken(credentials);
  const meta = await getSheetMeta(token, spreadsheetId, sheetName);
  const rows = await getValues(token, spreadsheetId, qualifyRange(meta.title, ''));
  const field = String(searchField || '');
  const want = String(searchValue == null ? '' : searchValue);
  const hit = rowsToObjects(rows).find((o) => String(o[field] == null ? '' : o[field]) === want) || null;
  return { data: hit, found: !!hit, sheetTitle: meta.title };
}

async function write({ credentials, spreadsheetId, sheetName = '', range = '', data, firstRowAsKey = true }) {
  const token = await getAccessToken(credentials);
  const meta = await getSheetMeta(token, spreadsheetId, sheetName);
  const grid = valueToGrid(data, firstRowAsKey);
  if (!grid.length) throw new Error('Dữ liệu ghi Google Sheet đang rỗng');
  const rgTxt = String(range || '').trim();
  if (rgTxt) {
    await updateValues(token, spreadsheetId, qualifyRange(meta.title, rgTxt), grid);
  } else {
    await clearValues(token, spreadsheetId, qualifyRange(meta.title, ''));
    await updateValues(token, spreadsheetId, qualifyRange(meta.title, 'A1'), grid);
  }
  return { writtenRows: grid.length, sheetTitle: meta.title };
}

async function append({ credentials, spreadsheetId, sheetName = '', data, firstRowAsKey = true }) {
  const token = await getAccessToken(credentials);
  const meta = await getSheetMeta(token, spreadsheetId, sheetName);
  const existing = await getValues(token, spreadsheetId, qualifyRange(meta.title, ''));
  const grid = valueToGrid(data, firstRowAsKey && existing.length === 0);
  if (!grid.length) throw new Error('Dữ liệu thêm Google Sheet đang rỗng');
  await appendValues(token, spreadsheetId, qualifyRange(meta.title, 'A1'), grid);
  return { appendedRows: grid.length, sheetTitle: meta.title };
}

async function update({ credentials, spreadsheetId, sheetName = '', searchField, searchValue, patch }) {
  const token = await getAccessToken(credentials);
  const meta = await getSheetMeta(token, spreadsheetId, sheetName);
  const rows = await getValues(token, spreadsheetId, qualifyRange(meta.title, ''));
  if (rows.length < 2) throw new Error('Bảng tính rỗng hoặc chỉ có hàng tiêu đề');
  const hdr = rows[0].map((h) => (h == null ? '' : String(h)));
  const body = rows.slice(1);
  const field = String(searchField || '');
  const want = String(searchValue == null ? '' : searchValue);
  const ci = hdr.indexOf(field);
  if (ci < 0) throw new Error(`Không tìm thấy cột "${field}" ở hàng tiêu đề`);
  const hit = [];
  body.forEach((r, i) => {
    if (String(r[ci] == null ? '' : r[ci]) === want) hit.push(i);
  });
  if (!hit.length) return { updatedRows: 0, sheetTitle: meta.title };

  let patchObj = patch;
  if (typeof patchObj === 'string') {
    try { patchObj = JSON.parse(patchObj); } catch { patchObj = null; }
  }
  if (!patchObj || typeof patchObj !== 'object' || Array.isArray(patchObj)) {
    throw new Error('"Dữ liệu cập nhật" phải là JSON dạng {"tên cột":"giá trị"}');
  }
  Object.keys(patchObj).forEach((k) => {
    if (hdr.indexOf(k) < 0) hdr.push(k);
  });
  hit.forEach((i) => {
    Object.entries(patchObj).forEach(([k, v]) => {
      body[i][hdr.indexOf(k)] = v == null ? '' : String(v);
    });
  });
  const grid = [
    hdr,
    ...body.map((r) => {
      const rr = r.slice(0, hdr.length);
      while (rr.length < hdr.length) rr.push('');
      return rr.map((c) => (c == null ? '' : c));
    }),
  ];
  await clearValues(token, spreadsheetId, qualifyRange(meta.title, ''));
  await updateValues(token, spreadsheetId, qualifyRange(meta.title, 'A1'), grid);
  return { updatedRows: hit.length, sheetTitle: meta.title };
}

async function clear({ credentials, spreadsheetId, sheetName = '', range }) {
  const rgTxt = String(range || '').trim();
  if (!rgTxt) throw new Error('Range không hợp lệ (ví dụ: A2:C10)');
  const token = await getAccessToken(credentials);
  const meta = await getSheetMeta(token, spreadsheetId, sheetName);
  await clearValues(token, spreadsheetId, qualifyRange(meta.title, rgTxt));
  return { clearedRange: rgTxt, sheetTitle: meta.title };
}

async function delete_row({ credentials, spreadsheetId, sheetName = '', searchField, searchValue }) {
  const token = await getAccessToken(credentials);
  const meta = await getSheetMeta(token, spreadsheetId, sheetName);
  const rows = await getValues(token, spreadsheetId, qualifyRange(meta.title, ''));
  if (rows.length < 2) throw new Error('Bảng tính rỗng hoặc chỉ có hàng tiêu đề');
  const hdr = rows[0].map((h) => (h == null ? '' : String(h)));
  const body = rows.slice(1);
  const field = String(searchField || '');
  const want = String(searchValue == null ? '' : searchValue);
  const ci = hdr.indexOf(field);
  if (ci < 0) throw new Error(`Không tìm thấy cột "${field}" ở hàng tiêu đề`);
  const hit = [];
  body.forEach((r, i) => {
    if (String(r[ci] == null ? '' : r[ci]) === want) hit.push(i);
  });
  if (!hit.length) return { deletedRows: 0, sheetTitle: meta.title };
  await deleteRows(token, spreadsheetId, meta.sheetId, hit.map((i) => i + 1));
  return { deletedRows: hit.length, sheetTitle: meta.title };
}

async function executeAction(action, params) {
  switch (action) {
    case 'read': return read(params);
    case 'find_row': return find_row(params);
    case 'write': return write(params);
    case 'append': return append(params);
    case 'update': return update(params);
    case 'clear': return clear(params);
    case 'delete_row': return delete_row(params);
    default: throw new Error(`Thao tác Google Sheet "${action}" chưa hỗ trợ`);
  }
}

function clearTokenCache() {
  tokenCache.clear();
}

module.exports = {
  loadCredentials,
  getAccessToken,
  getSheetMeta,
  qualifyRange,
  getValues,
  updateValues,
  appendValues,
  clearValues,
  deleteRows,
  rowsToObjects,
  valueToGrid,
  read,
  find_row,
  findRow: find_row,
  write,
  append,
  update,
  clear,
  delete_row,
  deleteRow: delete_row,
  executeAction,
  clearTokenCache,
};
