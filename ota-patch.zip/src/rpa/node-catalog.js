'use strict';

/**
 * CGT-Login v2.0 — Visual RPA Node Catalog (53 Nodes: `start` + 52 Configurable Nodes)
 * Ported & upgraded to CommonJS from PolyLogin's RPA specification.
 * Zero external dependencies.
 */

const CAT = {
  GENERAL: 'GENERAL',
  BROWSER: 'BROWSER',
  WEB: 'WEB',
  DATA: 'DATA',
  FLOW: 'FLOW',
  FILE: 'FILE',
  API: 'API',
  AI: 'AI',
  OTHER: 'OTHER',
};

const CAT_COLOR = {
  [CAT.GENERAL]: '#64748B',
  [CAT.BROWSER]: '#3B82F6',
  [CAT.WEB]: '#8B5CF6',
  [CAT.DATA]: '#06B6D4',
  [CAT.FLOW]: '#F97316',
  [CAT.FILE]: '#10B981',
  [CAT.API]: '#EC4899',
  [CAT.AI]: '#14B8A6',
  [CAT.OTHER]: '#6366F1',
};

const COL_START = '#22C55E';

const CATEGORIES = [
  [CAT.GENERAL, 'Chung'],
  [CAT.BROWSER, 'Trình duyệt'],
  [CAT.WEB, 'Tương tác Web'],
  [CAT.DATA, 'Dữ liệu'],
  [CAT.FLOW, 'Luồng điều khiển'],
  [CAT.FILE, 'Xử lý tệp & thư mục'],
  [CAT.API, 'API'],
  [CAT.AI, 'AI'],
  [CAT.OTHER, 'Khác'],
];

const OPS = [
  'Tồn tại',
  'Không tồn tại',
  'Nhỏ hơn',
  'Nhỏ hơn hoặc bằng',
  'Bằng',
  'Không bằng',
  'Lớn hơn',
  'Lớn hơn hoặc bằng',
  'Bao gồm',
  'Không bao gồm',
  'Nằm trong',
  'Không nằm trong',
];

const VAR_TYPES = ['String', 'Number', 'Boolean', 'Array', 'Object', 'Text', 'File', 'Folder'];

const SYS_VARS = [
  { name: 'task_id', desc: 'ID nhiệm vụ', type: 'String' },
  { name: 'task_name', desc: 'Tên nhiệm vụ', type: 'String' },
  { name: 'serial_number', desc: 'Số hồ sơ', type: 'String' },
  { name: 'browser_name', desc: 'Tên hồ sơ', type: 'String' },
  { name: 'acc_id', desc: 'ID hồ sơ', type: 'String' },
  { name: 'user_name', desc: 'Tài khoản nền tảng', type: 'String' },
  { name: 'password', desc: 'Mật khẩu', type: 'String' },
];

const VAR_OUT_KEYS = { variable_name: 'Any', variable_output: 'Any', loop_id: 'String' };

const COND_OPS = [
  { value: 'Tồn tại', label: 'Tồn tại', right: 'exists' },
  { value: 'Không tồn tại', label: 'Không tồn tại', right: '!exists' },
  { value: 'Bằng', label: 'Bằng', right: '==' },
  { value: 'Không bằng', label: 'Không bằng', right: '!=' },
  { value: 'Bao gồm', label: 'Bao gồm', right: 'includes' },
  { value: 'Không bao gồm', label: 'Không bao gồm', right: '!includes' },
  { value: 'Lớn hơn', label: 'Lớn hơn', right: '>' },
  { value: 'Lớn hơn hoặc bằng', label: 'Lớn hơn hoặc bằng', right: '>=' },
  { value: 'Nhỏ hơn', label: 'Nhỏ hơn', right: '<' },
  { value: 'Nhỏ hơn hoặc bằng', label: 'Nhỏ hơn hoặc bằng', right: '<=' },
  { value: 'Nằm trong', label: 'Nằm trong', right: 'in' },
  { value: 'Không nằm trong', label: 'Không nằm trong', right: '!in' },
];

const COND_OP_SYMBOLS = COND_OPS.reduce((m, o) => {
  m[o.value] = o.right || o.label;
  return m;
}, {});

const COND_OPS_UNARY = ['Tồn tại', 'Không tồn tại'];
const COND_OPS_LIST = ['Nằm trong', 'Không nằm trong'];

const COND_OP_HINTS = {
  'Tồn tại': 'A khác rỗng và đã được gán.',
  'Không tồn tại': 'A rỗng hoặc chưa được gán.',
  'Bằng': 'A == B. Hai vế đều là số thì so theo số, còn lại so chuỗi (phân biệt HOA/thường).',
  'Không bằng': 'A != B.',
  'Bao gồm': 'A.includes(B) - A CHỨA B. VD A = https://www.facebook.com/, B = face -> đúng.',
  'Không bao gồm': '!A.includes(B) - A không chứa B.',
  'Lớn hơn': 'A > B. Ép về SỐ; vế nào không phải số thì luôn sai.',
  'Lớn hơn hoặc bằng': 'A >= B. Ép về SỐ; vế nào không phải số thì luôn sai.',
  'Nhỏ hơn': 'A < B. Ép về SỐ; vế nào không phải số thì luôn sai.',
  'Nhỏ hơn hoặc bằng': 'A <= B. Ép về SỐ; vế nào không phải số thì luôn sai.',
  'Nằm trong': '[B].includes(A) - B là DANH SÁCH (ngăn bằng dấu phẩy hoặc xuống dòng), A phải khớp NGUYÊN một mục.',
  'Không nằm trong': 'A không khớp mục nào trong danh sách B.',
};

const KEY_OPTIONS = [
  { value: '3', label: 'Cancel' }, { value: '8', label: 'Backspace' }, { value: '9', label: 'Tab' },
  { value: '12', label: 'Clear' }, { value: '13', label: 'Enter' }, { value: '16', label: 'Shift' },
  { value: '17', label: 'Control' }, { value: '18', label: 'Alt' }, { value: '19', label: 'Pause' },
  { value: '20', label: 'CapsLock' }, { value: '27', label: 'Escape' }, { value: '28', label: 'henkan' },
  { value: '29', label: 'muhenkan' }, { value: '32', label: '(blank space)' }, { value: '33', label: 'PageUp' },
  { value: '34', label: 'PageDown' }, { value: '35', label: 'End' }, { value: '36', label: 'Home' },
  { value: '37', label: 'ArrowLeft' }, { value: '38', label: 'ArrowUp' }, { value: '39', label: 'ArrowRight' },
  { value: '40', label: 'ArrowDown' }, { value: '41', label: 'Select' }, { value: '42', label: 'Print' },
  { value: '43', label: 'Execute' }, { value: '44', label: 'F13' }, { value: '45', label: 'Insert' },
  { value: '46', label: 'Delete' }, { value: '47', label: 'Help' },
  { value: '48', label: '0' }, { value: '49', label: '1' }, { value: '50', label: '2' },
  { value: '51', label: '3' }, { value: '52', label: '4' }, { value: '53', label: '5' },
  { value: '54', label: '6' }, { value: '55', label: '7' }, { value: '56', label: '8' },
  { value: '57', label: '9' }, { value: '58', label: ':' }, { value: '59', label: ';' },
  { value: '60', label: '<' }, { value: '61', label: '=' }, { value: '63', label: 'ß' },
  { value: '64', label: '@' },
  { value: '65', label: 'a' }, { value: '66', label: 'b' }, { value: '67', label: 'c' },
  { value: '68', label: 'd' }, { value: '69', label: 'e' }, { value: '70', label: 'f' },
  { value: '71', label: 'g' }, { value: '72', label: 'h' }, { value: '73', label: 'i' },
  { value: '74', label: 'j' }, { value: '75', label: 'k' }, { value: '76', label: 'l' },
  { value: '77', label: 'm' }, { value: '78', label: 'n' }, { value: '79', label: 'o' },
  { value: '80', label: 'p' }, { value: '81', label: 'q' }, { value: '82', label: 'r' },
  { value: '83', label: 's' }, { value: '84', label: 't' }, { value: '85', label: 'u' },
  { value: '86', label: 'v' }, { value: '87', label: 'w' }, { value: '88', label: 'x' },
  { value: '89', label: 'y' }, { value: '90', label: 'z' },
  { value: '91', label: 'Meta' }, { value: '92', label: 'Meta' }, { value: '93', label: 'ContextMenu' },
  { value: '95', label: 'Standby' },
  { value: '96', label: '0' }, { value: '97', label: '1' }, { value: '98', label: '2' },
  { value: '99', label: '3' }, { value: '100', label: '4' }, { value: '101', label: '5' },
  { value: '102', label: '6' }, { value: '103', label: '7' }, { value: '104', label: '8' },
  { value: '105', label: '9' }, { value: '106', label: '*' }, { value: '107', label: '+' },
  { value: '108', label: ',' }, { value: '109', label: '-' }, { value: '110', label: '.' },
  { value: '111', label: '/' },
  { value: '112', label: 'F1' }, { value: '113', label: 'F2' }, { value: '114', label: 'F3' },
  { value: '115', label: 'F4' }, { value: '116', label: 'F5' }, { value: '117', label: 'F6' },
  { value: '118', label: 'F7' }, { value: '119', label: 'F8' }, { value: '120', label: 'F9' },
  { value: '121', label: 'F10' }, { value: '122', label: 'F11' }, { value: '123', label: 'F12' },
  { value: '124', label: 'F13' }, { value: '125', label: 'F14' }, { value: '126', label: 'F15' },
  { value: '127', label: 'F16' }, { value: '128', label: 'F17' }, { value: '129', label: 'F18' },
  { value: '130', label: 'F19' }, { value: '131', label: 'F20' }, { value: '132', label: 'F21' },
  { value: '133', label: 'F22' }, { value: '134', label: 'F23' }, { value: '135', label: 'F24' },
  { value: '136', label: 'F25' }, { value: '137', label: 'F26' }, { value: '138', label: 'F27' },
  { value: '139', label: 'F28' }, { value: '140', label: 'F29' }, { value: '141', label: 'F30' },
  { value: '142', label: 'F31' }, { value: '143', label: 'F32' },
  { value: '144', label: 'NumLock' }, { value: '145', label: 'ScrollLock' },
  { value: '160', label: '^' }, { value: '161', label: 'Dead' }, { value: '163', label: '#' },
  { value: '164', label: '$' }, { value: '166', label: 'BrowserBack' }, { value: '167', label: 'BrowserForward' },
  { value: '168', label: 'BrowserRefresh' }, { value: '169', label: ')' }, { value: '170', label: '*' },
  { value: '171', label: '+' }, { value: '172', label: '|' }, { value: '173', label: '-' },
  { value: '174', label: 'AudioVolumeDown' }, { value: '175', label: 'AudioVolumeUp' },
  { value: '176', label: 'MediaTrackNext' }, { value: '177', label: 'MediaTrackPrevious' },
  { value: '178', label: 'MediaStop' }, { value: '179', label: 'MediaPlayPause' },
  { value: '180', label: 'LaunchMail' }, { value: '181', label: 'AudioVolumeMute' },
  { value: '182', label: 'AudioVolumeDown' }, { value: '183', label: 'AudioVolumeUp' },
  { value: '186', label: ';' }, { value: '187', label: '=' }, { value: '188', label: ',' },
  { value: '189', label: '-' }, { value: '190', label: '.' }, { value: '191', label: '/' },
  { value: '192', label: '`' }, { value: '193', label: '/' }, { value: '194', label: '.' },
  { value: '219', label: '[' }, { value: '220', label: '\\' }, { value: '221', label: ']' },
  { value: '222', label: "'" }, { value: '223', label: '`' }, { value: '224', label: 'Meta' },
  { value: '225', label: 'AltGraph' }, { value: '226', label: '\\' }, { value: '229', label: 'Dead' },
  { value: '240', label: 'Alphanumeric' }, { value: '242', label: 'HiraganaKatakana' },
  { value: '243', label: 'ZenkakuHankaku' }, { value: '244', label: 'KanjiMode' }, { value: '255', label: 'WakeUp' },
];

const RANGE_READ_TIP = '<b>Cách điền Range (vùng đọc):</b><br>&bull; <b>Để trống</b>: đọc toàn bộ trang tính<br>&bull; <b>A2</b>: đọc đúng 1 ô, trả về giá trị ô đó<br>&bull; <b>A1:C10</b>: đọc vùng chữ nhật từ A1 đến C10<br>&bull; <b>B:B</b>: đọc nguyên cột B (gồm cả tiêu đề)<br>&bull; <b>A2:A</b>: đọc cột A từ hàng 2 xuống hết<br>&bull; <b>2:2</b>: đọc nguyên hàng 2<br><br>Bật "Chọn hàng đầu tiên làm khóa" khi vùng có dòng tiêu đề để trả về dạng object; tắt nếu chỉ cần danh sách giá trị.';

const CLICK_ON_EL_WHEN = {
  or: [
    { k: 'mode', eq: 'normal' },
    [{ k: 'mode', eq: 'press_hold' }, { k: 'is_click_on_element', eq: true }],
  ],
};

const defs = [
  // ===================================== Chung (6)
  ['doi', 'Đợi', CAT.GENERAL, {
    icon: 'hourglass',
    subtitle: 'Chờ đợi một khoảng thời gian trước khi tiếp tục',
    fields: [
      { t: 'select', k: 'time_type', label: 'Đợi theo thời gian', def: 'random', options: [{ value: 'fixed', label: 'Cố định' }, { value: 'random', label: 'Ngẫu nhiên' }] },
      { t: 'number', k: 'num_seconds', label: 'Thời gian chờ (số giây)', req: true, def: 1, when: { k: 'time_type', eq: 'fixed' } },
      { t: 'number', k: 'num_start', label: 'Số bắt đầu (giây)', def: 1, when: { k: 'time_type', eq: 'random' } },
      { t: 'number', k: 'num_end', label: 'Số kết thúc (giây)', def: 3, when: { k: 'time_type', eq: 'random' } },
    ],
  }],
  ['http_request', 'HTTP Request', CAT.GENERAL, {
    icon: 'globe',
    subtitle: 'Thực hiện một HTTP Request',
    fields: [
      { t: 'text', k: 'url', label: 'URL', req: true, varIns: true },
      { t: 'select', k: 'method', label: 'Method', req: true, def: 'GET', options: [{ value: 'GET', label: 'GET' }, { value: 'POST', label: 'POST' }, { value: 'PUT', label: 'PUT' }, { value: 'DELETE', label: 'DELETE' }, { value: 'PATCH', label: 'PATCH' }, { value: 'HEAD', label: 'HEAD' }, { value: 'OPTIONS', label: 'OPTIONS' }] },
      { t: 'kvlist', k: 'params', label: 'URL Parameter', varIns: true },
      { t: 'kvlist', k: 'headers', label: 'Custom Header', varIns: true },
      { t: 'select', k: 'content_type', label: 'Content Type', req: true, def: 'json', when: { k: 'method', in: ['POST', 'PUT', 'PATCH', 'DELETE'] }, options: [{ value: 'json', label: 'JSON' }, { value: 'form_multipart', label: 'Form-Data' }, { value: 'form_urlencoded', label: 'Form-Urlencoded' }, { value: 'text', label: 'Text' }] },
      { t: 'code', k: 'json_string_data', label: 'Body', varIns: true, jsonSafe: true, rows: 6, when: [{ k: 'method', in: ['POST', 'PUT', 'PATCH', 'DELETE'] }, { k: 'content_type', eq: 'json' }] },
      { t: 'kvlist', k: 'data__form_multipart', label: 'Form-Data', varIns: true, when: [{ k: 'method', in: ['POST', 'PUT', 'PATCH', 'DELETE'] }, { k: 'content_type', eq: 'form_multipart' }] },
      { t: 'kvlist', k: 'data__form_urlencoded', label: 'Form-Urlencoded', varIns: true, when: [{ k: 'method', in: ['POST', 'PUT', 'PATCH', 'DELETE'] }, { k: 'content_type', eq: 'form_urlencoded' }] },
      { t: 'textarea', k: 'data__text', label: 'Text', varIns: true, rows: 4, when: [{ k: 'method', in: ['POST', 'PUT', 'PATCH', 'DELETE'] }, { k: 'content_type', eq: 'text' }] },
      { t: 'select', k: 'response_type', label: 'Response Type', req: true, def: 'json', options: [{ value: 'json', label: 'JSON' }, { value: 'text', label: 'Text' }, { value: 'arraybuffer', label: 'ArrayBuffer' }] },
      { t: 'text', k: 'path_data', label: 'Data Path', varIns: true, when: { k: 'response_type', eq: 'json' } },
      { t: 'text', k: 'variable_name', label: 'Biến nhận dữ liệu', ph: 'Hãy nhập biến để lưu kết quả' },
    ],
  }],
  ['bo_nho_tam', 'Bộ nhớ tạm', CAT.GENERAL, {
    icon: 'clipboard',
    subtitle: 'Thao tác với dữ liệu sao chép được lưu ở bộ nhớ tạm',
    fields: [
      { t: 'select', k: 'action_type', def: 'get', req: true, options: [{ value: 'get', label: 'Lấy dữ liệu' }, { value: 'insert', label: 'Thêm dữ liệu vào' }] },
      { t: 'check', k: 'save_to_var', label: 'Biến nhận dữ liệu', def: false, when: { k: 'action_type', eq: 'get' } },
      { t: 'text', k: 'variable_name', label: 'Biến nhận dữ liệu', ph: 'Hãy nhập biến để lưu kết quả', when: [{ k: 'action_type', eq: 'get' }, { k: 'save_to_var', eq: true }] },
      { t: 'textarea', k: 'text', label: 'Text', varIns: true, rows: 4, when: { k: 'action_type', eq: 'insert' } },
      { t: 'check', k: 'is_from_selection', label: 'Sử dụng văn bản được bôi đen trên trang', def: false, when: { k: 'action_type', eq: 'insert' } },
    ],
  }],
  ['lay_thoi_gian', 'Lấy Thời Gian', CAT.GENERAL, {
    icon: 'clock',
    subtitle: 'Lấy thông tin thời gian ở thời điểm hiện tại',
    fields: [
      { t: 'select', k: 'format_return', label: 'Định dạng trả về', req: true, def: 'timestamp', options: [{ value: 'timestamp', label: 'Timestamp' }, { value: 'DD_MM_YYYY', label: 'DD/MM/YYYY' }, { value: 'DD_MM_YYYY_HH_mm_ss', label: 'DD/MM/YYYY HH:mm:ss' }, { value: 'YYYY_MM_DD', label: 'YYYY-MM-DD' }, { value: 'YYYY_MM_DD_HH_mm_ss', label: 'YYYY-MM-DD HH:mm:ss' }, { value: 'HH_mm_ss', label: 'HH:mm:ss' }] },
      { t: 'text', k: 'variable_name', label: 'Biến nhận dữ liệu', ph: 'Hãy nhập biến để lưu kết quả' },
    ],
  }],
  ['log', 'Log', CAT.GENERAL, {
    icon: 'log',
    subtitle: 'In ra cửa sổ nhật ký các giá trị ở dạng string, number hay object',
    fields: [
      { t: 'text', k: 'message', label: 'Nội dung hiển thị', req: true, varIns: true },
    ],
  }],
  ['code', 'Code', CAT.GENERAL, {
    icon: 'codeTag',
    subtitle: 'Chèn mã Javascript tùy chỉnh (chạy trong sandbox Node)',
    fields: [
      { t: 'code', k: 'js_code', req: true, varIns: false, rows: 10 },
    ],
  }],

  // ===================================== Trình duyệt (15)
  ['mo_url', 'Mở URL', CAT.BROWSER, {
    icon: 'link',
    subtitle: 'Mở URL được chỉ định trên tab hiện tại',
    fields: [
      { t: 'text', k: 'url', label: 'Địa chỉ URL', req: true, varIns: true },
      { t: 'select', k: 'wait_until', label: 'Đợi đến khi sự kiện được kích hoạt', req: true, def: 'domcontentloaded', options: [{ value: 'load', label: 'Load' }, { value: 'domcontentloaded', label: 'Dom Content Loaded' }, { value: 'networkidle0', label: 'Networkidle0' }, { value: 'networkidle2', label: 'Networkidle2' }] },
      { t: 'number', k: 'timeout', label: 'Thời gian chờ tối đa (số giây)', req: true, def: 0, hint: '* Thời gian chờ mặc định 0 là chờ đến khi trang được tải.' },
    ],
  }],
  ['mo_tab_moi', 'Mở tab mới', CAT.BROWSER, {
    icon: 'browserPlus',
    subtitle: 'Mở tab mới với URL được chỉ định',
    fields: [
      { t: 'text', k: 'url', label: 'Địa chỉ URL', varIns: true },
      { t: 'select', k: 'wait_until', label: 'Đợi đến khi sự kiện được kích hoạt', req: true, def: 'domcontentloaded', options: [{ value: 'load', label: 'Load' }, { value: 'domcontentloaded', label: 'Dom Content Loaded' }, { value: 'networkidle0', label: 'Networkidle0' }, { value: 'networkidle2', label: 'Networkidle2' }] },
      { t: 'number', k: 'timeout', label: 'Thời gian chờ tối đa (số giây)', req: true, def: 0, hint: '* Thời gian chờ mặc định 0 là chờ đến khi trang được tải.' },
    ],
  }],
  ['chuyen_tab', 'Chuyển tab', CAT.BROWSER, {
    icon: 'swap',
    subtitle: 'Chuyển sang tab được chỉ định',
    fields: [
      { t: 'select', k: 'find_by', label: 'Chuyển theo', req: true, def: 'match_pattern', options: [{ value: 'match_pattern', label: 'Khớp với mẫu' }, { value: 'match_tile', label: 'Tiêu đề tab' }, { value: 'next_tab', label: 'Tab bên phải' }, { value: 'previous_tab', label: 'Tab bên trái' }, { value: 'tab_order', label: 'Thứ tự tab' }] },
      { t: 'text', k: 'pattern', label: 'Mẫu', varIns: true, when: { k: 'find_by', eq: 'match_pattern' } },
      { t: 'text', k: 'title', label: 'Tiêu đề', varIns: true, when: { k: 'find_by', eq: 'match_tile' } },
      { t: 'number', k: 'order_number', label: 'Thứ tự', req: true, when: { k: 'find_by', eq: 'tab_order' } },
      { t: 'check', k: 'is_active', label: 'Đặt làm tab hoạt động', def: true },
    ],
  }],
  ['dong_tab', 'Đóng tab', CAT.BROWSER, {
    icon: 'windowX',
    subtitle: 'Đóng tab được chỉ định',
    fields: [
      { t: 'select', k: 'close_type', label: 'Đóng theo', req: true, def: 'current', options: [{ value: 'current', label: 'Tab đang hoạt động' }, { value: 'match_pattern', label: 'Tab khớp với mẫu' }, { value: 'match_title', label: 'Tab khớp với tiêu đề' }, { value: 'order', label: 'Tab có thứ tự' }, { value: 'other_tabs', label: 'Trừ tab đang hoạt động' }] },
      { t: 'text', k: 'pattern', label: 'Mẫu', req: true, varIns: true, when: { k: 'close_type', eq: 'match_pattern' } },
      { t: 'text', k: 'title', label: 'Tiêu đề', req: true, varIns: true, when: { k: 'close_type', eq: 'match_title' } },
      { t: 'number', k: 'number_order', label: 'Thứ tự', req: true, when: { k: 'close_type', eq: 'order' } },
    ],
  }],
  ['quay_lai', 'Quay lại', CAT.BROWSER, { icon: 'arrowLeft', subtitle: 'Quay lại trang trước đó', fields: [] }],
  ['tien_len', 'Tiến lên', CAT.BROWSER, { icon: 'arrowRight', subtitle: 'Tiến lên trang sau đó', fields: [] }],
  ['tai_lai_trang', 'Tải lại trang', CAT.BROWSER, { icon: 'refresh', subtitle: 'Tải lại trang', fields: [] }],
  ['chup_man_hinh', 'Chụp màn hình', CAT.BROWSER, {
    icon: 'camera',
    subtitle: 'Chụp ảnh màn hình của tab đang hoạt động',
    fields: [
      { t: 'text', k: 'file_name', label: 'Tên tệp ảnh', req: true, varIns: true },
      { t: 'text', k: 'folder_output', label: 'Đường dẫn lưu trữ', req: true, varIns: true, folder: true },
    ],
  }],
  ['lay_url', 'Lấy URL', CAT.BROWSER, {
    icon: 'link',
    subtitle: 'Lấy URL của tab đang hoạt động',
    fields: [
      { t: 'text', k: 'variable_name', label: 'Biến nhận dữ liệu', req: true, ph: 'Hãy nhập biến để lưu kết quả' },
    ],
  }],
  ['chay_ma_javascript', 'Chạy mã Javascript', CAT.BROWSER, {
    icon: 'sourceCode',
    subtitle: 'Thực thi mã Javascript trên trang đang hoạt động',
    fields: [
      {
        t: 'code',
        k: 'script',
        req: true,
        varIns: false,
        rows: 13,
        def: '/*\n  Sử dụng mẫu này để trả về dữ liệu\n  và lưu vào "Biến nhận dữ liệu"\n*/\n(() => {\n  const brand = "CGT-Login";\n  const title = document.title;\n  const result = brand + " - " + title;\n\n  return result;\n})()',
      },
      { t: 'text', k: 'variable_name', label: 'Biến nhận dữ liệu', ph: 'Hãy nhập biến để lưu kết quả' },
    ],
  }],
  ['cookies', 'Cookies', CAT.BROWSER, {
    icon: 'cookie',
    subtitle: 'Thao tác với cookies: nhập cookie, xuất cookie, xóa cookie',
    fields: [
      { t: 'select', k: 'action_type', label: 'Hành động', def: 'import', req: true, options: [{ value: 'import', label: 'Nhập' }, { value: 'export', label: 'Xuất' }, { value: 'clear', label: 'Xóa' }] },
      { t: 'text', k: 'cookie_str', label: 'Chuỗi cookie', req: true, varIns: true, when: { k: 'action_type', eq: 'import' } },
      { t: 'text', k: 'variable_name', label: 'Biến nhận dữ liệu', req: true, ph: 'Hãy nhập biến để lưu kết quả', when: { k: 'action_type', eq: 'export' } },
    ],
  }],
  ['lay_noi_dung_html', 'Lấy nội dung HTML', CAT.BROWSER, {
    icon: 'fileCode',
    subtitle: 'Lấy đầy đủ nội dung HTML của trang web',
    fields: [
      { t: 'text', k: 'variable_name', label: 'Biến nhận giá trị', req: true, ph: 'Hãy nhập biến để lưu kết quả' },
    ],
  }],
  ['cho_tai_trang', 'Chờ tải trang', CAT.BROWSER, {
    icon: 'loader',
    subtitle: 'Chờ tải trang đến sự kiện được chỉ định phát ra',
    fields: [
      { t: 'select', k: 'wait_until', label: 'Đợi đến khi sự kiện được kích hoạt', req: true, def: 'load', options: [{ value: 'load', label: 'Load' }, { value: 'domcontentloaded', label: 'Dom Content Loaded' }, { value: 'networkidle0', label: 'Networkidle0' }, { value: 'networkidle2', label: 'Networkidle2' }] },
      { t: 'number', k: 'timeout', label: 'Thời gian chờ tối đa (số giây)', req: true, def: 30 },
    ],
  }],
  ['chuyen_frame', 'Chuyển Frame', CAT.BROWSER, {
    icon: 'appWindow',
    subtitle: 'Chuyển Frame được chỉ định',
    fields: [
      { t: 'select', k: 'frame_type', label: 'Loại Frame', req: true, def: 'sub', options: [{ value: 'sub', label: 'Frame con' }, { value: 'main', label: 'Frame chính' }] },
      { t: 'select', k: 'choose_type', label: 'Kiểu chọn', req: true, def: 'url', options: [{ value: 'url', label: 'URL' }, { value: 'order', label: 'Thứ tự' }, { value: 'selector', label: 'Bộ chọn' }], when: { k: 'frame_type', eq: 'sub' } },
      { t: 'text', k: 'url_char', label: 'Chuỗi URL', req: true, varIns: true, when: [{ k: 'frame_type', eq: 'sub' }, { k: 'choose_type', eq: 'url' }] },
      { t: 'number', k: 'order_val', label: 'Số thứ tự', req: true, def: 1, when: [{ k: 'frame_type', eq: 'sub' }, { k: 'choose_type', eq: 'order' }] },
      { t: 'select', k: 'selector_type', label: 'Kiểu chọn', req: true, def: 'css', options: [{ value: 'css', label: 'CSS' }, { value: 'xpath', label: 'Xpath' }], when: [{ k: 'frame_type', eq: 'sub' }, { k: 'choose_type', eq: 'selector' }] },
      { t: 'text', k: 'selector_val', label: 'Bộ chọn', req: true, varIns: true, when: [{ k: 'frame_type', eq: 'sub' }, { k: 'choose_type', eq: 'selector' }] },
    ],
  }],
  ['dong_trinh_duyet', 'Đóng trình duyệt', CAT.BROWSER, { icon: 'power', subtitle: 'Đóng cửa sổ trình duyệt', fields: [] }],

  // ===================================== Tương tác Web (9)
  ['nhan_chuot', 'Nhấn chuột', CAT.WEB, {
    icon: 'cursorClick',
    subtitle: 'Click chuột vào phần tử được chỉ định',
    fields: [
      { t: 'select', k: 'mode', label: 'Chế độ', req: true, def: 'normal', options: [{ value: 'normal', label: 'Nhấp chuột' }, { value: 'press_hold', label: 'Nhấn giữ' }] },
      { t: 'select', k: 'button', label: 'Nút nhấn', req: true, def: 'left', options: [{ value: 'left', label: 'Trái' }, { value: 'right', label: 'Phải' }, { value: 'middle', label: 'Giữa' }], when: { k: 'mode', in: ['normal', 'press_hold'] } },
      { t: 'number', k: 'press_time', label: 'Thời gian nhấn giữ (số giây)', req: true, def: 0, when: { k: 'mode', eq: 'press_hold' } },
      { t: 'check', k: 'is_click_on_element', label: 'Nhấn trên phần tử', req: true, def: false, when: { k: 'mode', eq: 'press_hold' } },
      { t: 'select', k: 'select_by', label: 'Kiểu chọn', req: true, def: 'selector', options: [{ value: 'selector', label: 'Bộ chọn' }, { value: 'coordinates', label: 'Tọa độ' }], when: CLICK_ON_EL_WHEN },
      { t: 'select', k: 'selector_type', label: 'Loại bộ chọn', req: true, def: 'xpath', options: [{ value: 'css', label: 'CSS' }, { value: 'xpath', label: 'Xpath' }], when: [CLICK_ON_EL_WHEN, { k: 'select_by', eq: 'selector' }] },
      { t: 'text', k: 'selector', label: 'Bộ chọn của phần tử', req: true, varIns: true, when: [CLICK_ON_EL_WHEN, { k: 'select_by', eq: 'selector' }] },
      { t: 'number', k: 'timeout', label: 'Thời gian chờ tối đa (số giây)', def: 10, when: [CLICK_ON_EL_WHEN, { k: 'select_by', eq: 'selector' }] },
      { t: 'number', k: 'x_coordinates', label: 'Tọa độ X', req: true, def: 0, when: [CLICK_ON_EL_WHEN, { k: 'select_by', eq: 'coordinates' }] },
      { t: 'number', k: 'y_coordinates', label: 'Tọa độ Y', req: true, def: 0, when: [CLICK_ON_EL_WHEN, { k: 'select_by', eq: 'coordinates' }] },
    ],
  }],
  ['lay_van_ban', 'Lấy văn bản', CAT.WEB, {
    icon: 'fileText',
    subtitle: 'Lấy nội dung văn bản của một phần tử trong trang web',
    fields: [
      { t: 'select', k: 'selector_type', label: 'Loại bộ chọn', req: true, def: 'xpath', options: [{ value: 'css', label: 'CSS' }, { value: 'xpath', label: 'Xpath' }] },
      { t: 'text', k: 'selector', label: 'Bộ chọn', req: true, varIns: true },
      { t: 'text', k: 'variable_name', label: 'Biến nhận dữ liệu', req: true, ph: 'Hãy nhập biến để lưu kết quả' },
    ],
  }],
  ['nhap_van_ban', 'Nhập văn bản', CAT.WEB, {
    icon: 'forms',
    subtitle: 'Gõ văn bản',
    fields: [
      { t: 'select', k: 'selector_type', label: 'Loại bộ chọn (tùy chọn)', options: [{ value: 'css', label: 'CSS' }, { value: 'xpath', label: 'Xpath' }], hint: '* Nếu không chọn "Loại bộ chọn", ứng dụng sẽ nhập văn bản vào vị trí con trỏ hiện tại trên trình duyệt.' },
      { t: 'text', k: 'selector', label: 'Bộ chọn phần tử', req: true, varIns: true, when: { k: 'selector_type', in: ['css', 'xpath'] } },
      { t: 'textarea', k: 'text', label: 'Văn bản', req: true, varIns: true, rows: 4 },
      { t: 'number', k: 'speed', label: 'Khoảng thời gian giữa các lần gõ (số giây)', req: true, def: 0.1 },
    ],
  }],
  ['nhan_phim', 'Nhấn phím', CAT.WEB, {
    icon: 'keyboard',
    subtitle: 'Thao tác nhấn phím',
    fields: [
      { t: 'checks', k: 'keys', label: 'Phím nhấn', req: true, options: KEY_OPTIONS },
    ],
  }],
  ['cuon_chuot', 'Cuộn chuột', CAT.WEB, {
    icon: 'mouse',
    subtitle: 'Cuộn chuột theo tọa độ hoặc phần tử được chọn',
    fields: [
      { t: 'select', k: 'scroll_type', label: 'Cuộn chuột theo', req: true, def: 'coordinates', options: [{ value: 'coordinates', label: 'Tọa độ' }, { value: 'css_selector', label: 'Css selector' }, { value: 'xpath', label: 'XPath' }] },
      { t: 'text', k: 'element_selector', label: 'Bộ chọn phần tử', req: true, varIns: true, when: { k: 'scroll_type', in: ['css_selector', 'xpath'] } },
      { t: 'number', k: 'timeout__css_selector', label: 'Thời gian chờ tìm phần tử tối đa (số giây)', req: true, def: 30, when: { k: 'scroll_type', eq: 'css_selector' } },
      { t: 'number', k: 'timeout__xpath', label: 'Thời gian chờ tìm phần tử tối đa (số giây)', req: true, def: 30, when: { k: 'scroll_type', eq: 'xpath' } },
      { t: 'select', k: 'direction', label: 'Hướng cuộn', req: true, def: 'down', options: [{ value: 'down', label: 'Cuộn xuống' }, { value: 'up', label: 'Cuộn lên' }], when: { k: 'scroll_type', eq: 'coordinates' } },
      { t: 'text', k: 'x_coordinates', label: 'Tọa độ X', req: true, varIns: true, when: { k: 'scroll_type', eq: 'coordinates' } },
      { t: 'text', k: 'y_coordinates', label: 'Tọa độ Y', req: true, varIns: true, when: { k: 'scroll_type', eq: 'coordinates' } },
      { t: 'number', k: 'speed', label: 'Tốc độ cuộn', req: true, def: 5, when: { k: 'scroll_type', eq: 'coordinates' } },
    ],
  }],
  ['luu_media', 'Lưu media', CAT.WEB, {
    icon: 'download',
    subtitle: 'Tải ảnh/video/tệp media qua đường mạng trình duyệt',
    fields: [
      { t: 'select', k: 'media_type', label: 'Media lấy từ', req: true, def: 'url', options: [{ value: 'url', label: 'URL' }, { value: 'element', label: 'Phần tử' }] },
      { t: 'text', k: 'url_string', label: 'URL chứa Media', req: true, varIns: true, when: { k: 'media_type', eq: 'url' } },
      { t: 'select', k: 'selector_type', label: 'Loại bộ chọn', def: 'xpath', options: [{ value: 'css', label: 'CSS' }, { value: 'xpath', label: 'XPATH' }], when: { k: 'media_type', eq: 'element' } },
      { t: 'text', k: 'selector', label: 'Bộ chọn phần tử', varIns: true, when: { k: 'media_type', eq: 'element' } },
      { t: 'number', k: 'timeout', label: 'Thời gian chờ tìm phần tử tối đa (số giây)', req: true, def: 30, when: { k: 'media_type', eq: 'element' } },
      { t: 'text', k: 'file_name', label: 'Tên tệp (Tùy chọn)', varIns: true },
      { t: 'text', k: 'output_path', label: 'Đường dẫn lưu trữ', req: true, varIns: true, folder: true },
    ],
  }],
  ['tai_tep_len', 'Tải tệp lên', CAT.WEB, {
    icon: 'upload',
    subtitle: 'Tải tệp lên trang web',
    fields: [
      { t: 'select', k: 'selector_type', label: 'Loại bộ chọn', req: true, def: 'xpath', options: [{ value: 'xpath', label: 'Xpath' }, { value: 'css', label: 'CSS' }] },
      { t: 'text', k: 'selector', label: 'Bộ chọn của phần tử', req: true, varIns: true },
      { t: 'check', k: 'is_upload_folder', label: 'Tải tệp trong thư mục', def: false },
      { t: 'text', k: 'path', label: 'Đường dẫn tệp / thư mục', req: true, varIns: true, folder: true },
      { t: 'text', k: 'file_count', label: 'Số lượng tệp tải lên', varIns: true, when: { k: 'is_upload_folder', eq: true }, hint: 'Nếu không nhập số lượng tệp thì sẽ tải lên tất cả các tệp trong thư mục, nếu có sẽ tải lên ngẫu nhiên theo số lượng tệp' },
      { t: 'check', k: 'is_upload_by_dialog', label: 'Tải lên bằng dialog', def: false },
      { t: 'number', k: 'timeout', label: 'Thời gian chờ tìm phần tử tối đa (số giây)', req: true, def: 30 },
    ],
  }],
  ['di_chuyen_chuot', 'Di chuyển chuột', CAT.WEB, {
    icon: 'pointer',
    subtitle: 'Di chuyển chuột đến phần tử hoặc tọa độ chỉ định',
    fields: [
      { t: 'select', k: 'target', label: 'Đích di chuyển', req: true, def: 'element', options: [{ value: 'element', label: 'Phần tử' }, { value: 'coordinates', label: 'Tọa độ' }] },
      { t: 'select', k: 'selector_type', label: 'Loại bộ chọn', req: true, def: 'xpath', options: [{ value: 'css', label: 'CSS' }, { value: 'xpath', label: 'Xpath' }], when: { k: 'target', eq: 'element' } },
      { t: 'text', k: 'selector', label: 'Bộ chọn của phần tử', req: true, varIns: true, when: { k: 'target', eq: 'element' } },
      { t: 'number', k: 'timeout', label: 'Thời gian chờ tối đa (số giây)', def: 10, when: { k: 'target', eq: 'element' } },
      { t: 'text', k: 'x_coordinates', label: 'Tọa độ X', req: true, def: 0, varIns: true, when: { k: 'target', eq: 'coordinates' } },
      { t: 'text', k: 'y_coordinates', label: 'Tọa độ Y', req: true, def: 0, varIns: true, when: { k: 'target', eq: 'coordinates' } },
    ],
  }],
  ['chon_tuy_chon', 'Chọn tùy chọn', CAT.WEB, {
    icon: 'select',
    subtitle: 'Chọn một tùy chọn từ menu dropdown',
    fields: [
      { t: 'select', k: 'selector_type', label: 'Loại bộ chọn', req: true, def: 'xpath', options: [{ value: 'css', label: 'CSS' }, { value: 'xpath', label: 'Xpath' }] },
      { t: 'text', k: 'selector', label: 'Bộ chọn phần tử', req: true, varIns: true, when: { k: 'selector_type', in: ['css', 'xpath'] } },
      { t: 'text', k: 'value', label: 'Giá trị', req: true, varIns: true },
      { t: 'number', k: 'timeout', label: 'Thời gian chờ tối đa (số giây)', def: 10 },
    ],
  }],

  // ===================================== Dữ liệu (6)
  ['bang_tinh', 'Bảng tính', CAT.DATA, {
    icon: 'table',
    subtitle: 'Đọc ghi file CSV hoặc Google Sheets',
    fields: [
      { t: 'select', k: 'spreadsheet_type', label: 'Loại bảng tính', req: true, def: 'excel', options: [{ value: 'excel', label: 'Excel (CSV)' }, { value: 'google_sheet', label: 'Google Sheets' }] },
      { t: 'text', k: 'file_path', label: 'File Excel (CSV)', req: true, varIns: true, file: true, fileFilters: [{ name: 'Bảng tính CSV', extensions: ['csv'] }, { name: 'Tất cả tệp', extensions: ['*'] }], when: { k: 'spreadsheet_type', eq: 'excel' } },
      { t: 'text', k: 'sheet_name', label: 'Tên trang tính (Tùy chọn)', varIns: true },
      { t: 'select', k: 'action_type__excel', label: 'Hành động', req: true, def: 'read', options: [{ value: 'read', label: 'Đọc' }, { value: 'write', label: 'Ghi' }, { value: 'append', label: 'Ghi thêm' }, { value: 'update', label: 'Cập nhật' }, { value: 'clear', label: 'Xóa giá trị ô' }, { value: 'delete_row', label: 'Xóa hàng' }], when: { k: 'spreadsheet_type', eq: 'excel' } },
      { t: 'text', k: 'credentials_json', label: 'Đường dẫn file json xác thực', req: true, varIns: true, file: true, fileFilters: [{ name: 'Tệp JSON xác thực', extensions: ['json'] }, { name: 'Tất cả tệp', extensions: ['*'] }], when: { k: 'spreadsheet_type', eq: 'google_sheet' } },
      { t: 'text', k: 'email_share', label: 'Email chia sẻ', req: false, when: { k: 'spreadsheet_type', eq: 'google_sheet' } },
      { t: 'text', k: 'sheet_id', label: 'ID Bảng tính', req: true, varIns: true, when: { k: 'spreadsheet_type', eq: 'google_sheet' } },
      { t: 'select', k: 'action_type__google_sheet', label: 'Hành động', req: true, def: 'read', options: [{ value: 'read', label: 'Đọc' }, { value: 'find_row', label: 'Tìm kiếm' }, { value: 'write', label: 'Ghi' }, { value: 'append', label: 'Ghi thêm' }, { value: 'update', label: 'Cập nhật' }, { value: 'clear', label: 'Xóa giá trị ô' }, { value: 'delete_row', label: 'Xóa hàng' }], when: { k: 'spreadsheet_type', eq: 'google_sheet' } },
      { t: 'text', k: 'range__read', label: 'Range (Tùy chọn)', varIns: true, labelTip: RANGE_READ_TIP, when: { or: [[{ k: 'spreadsheet_type', eq: 'excel' }, { k: 'action_type__excel', eq: 'read' }], [{ k: 'spreadsheet_type', eq: 'google_sheet' }, { k: 'action_type__google_sheet', eq: 'read' }]] } },
      { t: 'check', k: 'is_choose_first_rows_as_key__read', label: 'Chọn hàng đầu tiên làm khóa', def: true, when: { or: [[{ k: 'spreadsheet_type', eq: 'excel' }, { k: 'action_type__excel', eq: 'read' }], [{ k: 'spreadsheet_type', eq: 'google_sheet' }, { k: 'action_type__google_sheet', eq: 'read' }]] } },
      { t: 'text', k: 'variable_name__read', label: 'Biến nhận dữ liệu', req: true, ph: 'Hãy nhập biến để lưu kết quả', when: { or: [[{ k: 'spreadsheet_type', eq: 'excel' }, { k: 'action_type__excel', eq: 'read' }], [{ k: 'spreadsheet_type', eq: 'google_sheet' }, { k: 'action_type__google_sheet', eq: 'read' }]] } },
      { t: 'text', k: 'search_field__find_row', label: 'Thuộc tính tìm kiếm', req: true, varIns: true, when: [{ k: 'spreadsheet_type', eq: 'google_sheet' }, { k: 'action_type__google_sheet', eq: 'find_row' }] },
      { t: 'text', k: 'search_value__find_row', label: 'Giá trị tìm kiếm', req: true, varIns: true, when: [{ k: 'spreadsheet_type', eq: 'google_sheet' }, { k: 'action_type__google_sheet', eq: 'find_row' }] },
      { t: 'text', k: 'variable_name__find_row', label: 'Biến nhận dữ liệu', req: true, ph: 'Hãy nhập biến để lưu kết quả', when: [{ k: 'spreadsheet_type', eq: 'google_sheet' }, { k: 'action_type__google_sheet', eq: 'find_row' }] },
      { t: 'select', k: 'data__write', label: 'Biến dữ liệu', req: true, options: [], varsrc: true, ph: 'Hãy chọn biến', when: { or: [[{ k: 'spreadsheet_type', eq: 'excel' }, { k: 'action_type__excel', eq: 'write' }], [{ k: 'spreadsheet_type', eq: 'google_sheet' }, { k: 'action_type__google_sheet', eq: 'write' }]] } },
      { t: 'text', k: 'range__write', label: 'Range (Tùy chọn)', varIns: true, when: [{ k: 'spreadsheet_type', eq: 'google_sheet' }, { k: 'action_type__google_sheet', eq: 'write' }] },
      { t: 'check', k: 'is_choose_first_rows_as_key__write', label: 'Chọn hàng đầu tiên làm khóa', def: true, when: { or: [[{ k: 'spreadsheet_type', eq: 'excel' }, { k: 'action_type__excel', eq: 'write' }], [{ k: 'spreadsheet_type', eq: 'google_sheet' }, { k: 'action_type__google_sheet', eq: 'write' }]] } },
      { t: 'select', k: 'data__append', label: 'Biến dữ liệu', req: true, options: [], varsrc: true, ph: 'Hãy chọn biến', when: { or: [[{ k: 'spreadsheet_type', eq: 'excel' }, { k: 'action_type__excel', eq: 'append' }], [{ k: 'spreadsheet_type', eq: 'google_sheet' }, { k: 'action_type__google_sheet', eq: 'append' }]] } },
      { t: 'check', k: 'is_choose_first_rows_as_key__append', label: 'Chọn hàng đầu tiên làm khóa', def: true, when: { or: [[{ k: 'spreadsheet_type', eq: 'excel' }, { k: 'action_type__excel', eq: 'append' }], [{ k: 'spreadsheet_type', eq: 'google_sheet' }, { k: 'action_type__google_sheet', eq: 'append' }]] } },
      { t: 'text', k: 'search_field__update', label: 'Thuộc tính tìm kiếm', req: true, varIns: true, when: { or: [[{ k: 'spreadsheet_type', eq: 'excel' }, { k: 'action_type__excel', eq: 'update' }], [{ k: 'spreadsheet_type', eq: 'google_sheet' }, { k: 'action_type__google_sheet', eq: 'update' }]] } },
      { t: 'text', k: 'search_value__update', label: 'Giá trị tìm kiếm', req: true, varIns: true, when: { or: [[{ k: 'spreadsheet_type', eq: 'excel' }, { k: 'action_type__excel', eq: 'update' }], [{ k: 'spreadsheet_type', eq: 'google_sheet' }, { k: 'action_type__google_sheet', eq: 'update' }]] } },
      { t: 'textarea', k: 'data_update__update', label: 'Dữ liệu cập nhật', varIns: true, jsonSafe: true, rows: 3, when: { or: [[{ k: 'spreadsheet_type', eq: 'excel' }, { k: 'action_type__excel', eq: 'update' }], [{ k: 'spreadsheet_type', eq: 'google_sheet' }, { k: 'action_type__google_sheet', eq: 'update' }]] } },
      { t: 'text', k: 'range__clear', label: 'Range', req: true, varIns: true, when: { or: [[{ k: 'spreadsheet_type', eq: 'excel' }, { k: 'action_type__excel', eq: 'clear' }], [{ k: 'spreadsheet_type', eq: 'google_sheet' }, { k: 'action_type__google_sheet', eq: 'clear' }]] } },
      { t: 'text', k: 'search_field__delete_row', label: 'Thuộc tính tìm kiếm', req: true, varIns: true, when: { or: [[{ k: 'spreadsheet_type', eq: 'excel' }, { k: 'action_type__excel', eq: 'delete_row' }], [{ k: 'spreadsheet_type', eq: 'google_sheet' }, { k: 'action_type__google_sheet', eq: 'delete_row' }]] } },
      { t: 'text', k: 'search_value__delete_row', label: 'Giá trị tìm kiếm', req: true, varIns: true, when: { or: [[{ k: 'spreadsheet_type', eq: 'excel' }, { k: 'action_type__excel', eq: 'delete_row' }], [{ k: 'spreadsheet_type', eq: 'google_sheet' }, { k: 'action_type__google_sheet', eq: 'delete_row' }]] } },
    ],
  }],
  ['ngau_nhien', 'Ngẫu nhiên', CAT.DATA, {
    icon: 'shuffle',
    subtitle: 'Tạo dữ liệu ngẫu nhiên',
    fields: [
      { t: 'select', k: 'random_type', label: 'Loại dữ liệu', req: true, def: 'number', options: [{ value: 'number', label: 'Số' }, { value: 'string', label: 'Chuỗi ký tự' }] },
      { t: 'number', k: 'min', label: 'Số tối thiểu', req: true, def: 0, varIns: true, when: { k: 'random_type', eq: 'number' } },
      { t: 'number', k: 'max', label: 'Số tối đa', req: true, def: 10, varIns: true, when: { k: 'random_type', eq: 'number' } },
      { t: 'number', k: 'length', label: 'Độ dài', req: true, def: 10, varIns: true, when: { k: 'random_type', eq: 'string' } },
      { t: 'check', k: 'has_upper_case', label: 'A-Z', def: true, when: { k: 'random_type', eq: 'string' } },
      { t: 'check', k: 'has_lower_case', label: 'a-z', def: true, when: { k: 'random_type', eq: 'string' } },
      { t: 'check', k: 'has_number', label: '0-9', def: true, when: { k: 'random_type', eq: 'string' } },
      { t: 'check', k: 'has_special', label: 'Ký tự đặc biệt', def: false, when: { k: 'random_type', eq: 'string' } },
      { t: 'text', k: 'variable_name', label: 'Biến nhận dữ liệu', req: true, ph: 'Hãy nhập biến để lưu kết quả' },
    ],
  }],
  ['xu_ly_bien', 'Xử lý biến', CAT.DATA, {
    icon: 'variable',
    subtitle: 'Xử lý giá trị của biến',
    fields: [
      { t: 'select', k: 'variable', label: 'Biến chứa dữ liệu', req: true, options: [], varsrc: true, ph: 'Hãy chọn biến' },
      {
        t: 'select',
        k: 'method',
        label: 'Phương thức',
        req: true,
        def: 's_length',
        options: [
          { value: 's_length', label: 'Lấy độ dài' },
          { value: 's_to_upper', label: 'Chuyển tất cả thành chữ in hoa' },
          { value: 's_capitalize', label: 'Chuyển chữ cái đầu của mỗi từ thành chữ in hoa' },
          { value: 's_to_lower', label: 'Chuyển thành chữ thường' },
          { value: 's_trim', label: 'Loại bỏ khoảng trắng ở đầu và cuối chuỗi' },
          { value: 's_substring', label: 'Lấy một phần của chuỗi' },
          { value: 's_replace', label: 'Thay thế chuỗi' },
          { value: 's_split', label: 'Tách chuỗi' },
          { value: 's_concat', label: 'Nối chuỗi' },
          { value: 's_json_parse', label: 'Chuyển JSON String sang Javascript Object' },
          { value: 's_regex', label: 'Regex' },
          { value: 'a_length', label: 'Lấy số lượng phần tử' },
          { value: 'a_random', label: 'Lấy phần tử ngẫu nhiên' },
          { value: 'a_get_order', label: 'Lấy phần tử theo thứ tự' },
          { value: 'a_shuffle', label: 'Xáo trộn' },
          { value: 'a_slice', label: 'Lấy một phần của danh sách' },
          { value: 'a_search', label: 'Tìm kiếm' },
          { value: 'a_filter', label: 'Bộ lọc' },
          { value: 'o_get_property', label: 'Lấy thuộc tính' },
        ],
      },
      { t: 'number', k: 'sub_start', label: 'Vị trí bắt đầu', req: true, def: 1, varIns: true, when: { k: 'method', eq: 's_substring' } },
      { t: 'number', k: 'sub_end', label: 'Vị trí kết thúc', varIns: true, when: { k: 'method', eq: 's_substring' } },
      { t: 'text', k: 'search_value', label: 'Chuỗi cần thay thế', varIns: true, when: { k: 'method', eq: 's_replace' } },
      { t: 'text', k: 'new_value', label: 'Chuỗi được thay thế', varIns: true, when: { k: 'method', eq: 's_replace' } },
      { t: 'check', k: 'replace_all', label: 'Thay thế tất cả', def: false, when: { k: 'method', eq: 's_replace' } },
      { t: 'text', k: 'split_separator', label: 'Ký tự phân tách', varIns: true, when: { k: 'method', eq: 's_split' } },
      { t: 'textarea', k: 'concat_strings', label: 'Danh sách chuỗi', varIns: true, jsonSafe: true, rows: 3, when: { k: 'method', eq: 's_concat' } },
      { t: 'text', k: 'concat_separator', label: 'Ký tự nối', varIns: true, when: { k: 'method', eq: 's_concat' } },
      { t: 'select', k: 'regex_action', def: 'match', options: [{ value: 'match', label: 'Match' }, { value: 'match_all', label: 'Match All' }, { value: 'search', label: 'Search' }, { value: 'replace', label: 'Replace' }, { value: 'replace_all', label: 'Replace All' }, { value: 'split', label: 'Split' }], when: { k: 'method', eq: 's_regex' } },
      { t: 'text', k: 'regex_pattern', ph: 'Biểu thức chính quy', varIns: true, when: { k: 'method', eq: 's_regex' } },
      { t: 'text', k: 'regex_replacement', ph: 'Chuỗi được thay thế', varIns: true, when: [{ k: 'method', eq: 's_regex' }, { k: 'regex_action', in: ['replace', 'replace_all'] }] },
      { t: 'number', k: 'order_number', label: 'Số thứ tự', varIns: true, when: { k: 'method', eq: 'a_get_order' } },
      { t: 'number', k: 'slice_start', label: 'Vị trí bắt đầu', req: true, def: 1, varIns: true, when: { k: 'method', eq: 'a_slice' } },
      { t: 'number', k: 'slice_end', label: 'Vị trí kết thúc', varIns: true, when: { k: 'method', eq: 'a_slice' } },
      { t: 'info', k: 'cond_help', label: 'Điều kiện', text: 'Sử dụng ${ITEM} để lấy ra giá trị của item để so sánh. Nếu ITEM là đối tượng bạn có thể truy cập thuộc tính bằng cách sử dụng: ${ITEM.ten_thuoc_tinh}', when: { k: 'method', in: ['a_search', 'a_filter'] } },
      { t: 'text', k: 'path', label: 'Đường dẫn đến thuộc tính', varIns: true, when: { k: 'method', eq: 'o_get_property' } },
      { t: 'check', k: 'is_return_default', label: 'Trả về giá trị mặc định nếu không tìm thấy thuộc tính', def: false, when: { k: 'method', eq: 'o_get_property' } },
      { t: 'select', k: 'default_type', label: 'Kiểu dữ liệu', options: [{ value: 'string', label: 'String' }, { value: 'number', label: 'Number' }, { value: 'object', label: 'Object' }, { value: 'list', label: 'List' }], when: [{ k: 'method', eq: 'o_get_property' }, { k: 'is_return_default', eq: true }] },
      { t: 'text', k: 'default_value', label: 'Giá trị', varIns: true, when: [{ k: 'method', eq: 'o_get_property' }, { k: 'is_return_default', eq: true }] },
      { t: 'text', k: 'variable_output', label: 'Biến nhận dữ liệu', req: true, ph: 'Hãy nhập biến để lưu kết quả' },
    ],
  }],
  ['du_lieu_phan_tu', 'Dữ liệu phần tử', CAT.DATA, {
    icon: 'brackets',
    subtitle: 'Lấy các dữ liệu về phần tử',
    fields: [
      { t: 'select', k: 'selector_type', label: 'Loại bộ chọn', req: true, def: 'xpath', options: [{ value: 'xpath', label: 'Xpath' }, { value: 'css', label: 'CSS' }] },
      { t: 'text', k: 'selector', label: 'Bộ chọn của phần tử', req: true, varIns: true },
      { t: 'checks', k: 'data_types', label: 'Dữ liệu cần lấy', req: true, options: [{ value: 'position', label: 'Tọa độ vị trí' }, { value: 'size', label: 'Kích thước' }, { value: 'attribute', label: 'Thuộc tính' }, { value: 'count', label: 'Số lượng phần tử' }] },
      { t: 'text', k: 'data_path', label: 'Data Path', varIns: true },
      { t: 'text', k: 'variable_name', label: 'Biến nhận dữ liệu', req: true, ph: 'Hãy nhập biến để lưu kết quả' },
      { t: 'number', k: 'timeout', label: 'Thời gian chờ tìm phần tử (số giây)', req: true, def: 30, varIns: true },
    ],
  }],
  ['gan_bien', 'Gán biến', CAT.DATA, {
    icon: 'variablePlus',
    subtitle: 'Gán biến với nhiều toán tử',
    fields: [
      { t: 'select', k: 'variable_name', label: 'Biến', req: true, varsrc: true, ph: 'Biến' },
      { t: 'select', k: 'operator', label: 'Toán tử', req: true, def: '=', options: [{ value: '=', label: '=' }, { value: '+', label: '+=' }, { value: '-', label: '-=' }, { value: '*', label: '*=' }, { value: '/', label: '/=' }] },
      { t: 'text', k: 'value_two', label: 'Giá trị', req: true, varIns: true, ph: 'Giá trị' },
    ],
  }],
  ['math', 'Toán học', CAT.DATA, {
    icon: 'math',
    subtitle: 'Thực hiện các phép toán học',
    fields: [
      { t: 'select', k: 'method', label: 'Phương thức', req: true, ph: 'Phương thức', options: [{ value: 'round', label: 'Làm tròn gần nhất' }, { value: 'floor', label: 'Làm tròn xuống' }, { value: 'ceil', label: 'Làm tròn lên' }, { value: 'trunc', label: 'Bỏ phần thập phân, giữ nguyên dấu' }, { value: 'max', label: 'Số lớn nhất' }, { value: 'min', label: 'Số nhỏ nhất' }] },
      { t: 'text', k: 'value', label: 'Nhập giá trị', req: true, varIns: true },
      { t: 'text', k: 'variable_name', label: 'Biến nhận dữ liệu', req: true, ph: 'Hãy nhập biến để lưu kết quả' },
    ],
  }],

  // ===================================== Luồng điều khiển (6)
  ['lap_co_dieu_kien', 'Lặp có điều kiện', CAT.FLOW, {
    icon: 'rotateClockwise',
    subtitle: 'Lặp lại chuỗi bước khi điều kiện còn đúng',
    fields: [
      { t: 'text', k: 'loop_id', label: 'ID', req: true, varIns: true },
      { t: 'conds', k: 'conditions', label: 'Điều kiện lặp', req: true, hint: 'Còn thỏa mãn thì còn lặp tiếp.' },
    ],
  }],
  ['lap_du_lieu', 'Lặp dữ liệu', CAT.FLOW, {
    icon: 'repeat',
    subtitle: 'Lặp theo dãy số, biến mảng hoặc danh sách phần tử HTML',
    fields: [
      { t: 'text', k: 'loop_id', label: 'ID', req: true, varIns: true },
      { t: 'select', k: 'loop_through', label: 'Dữ liệu lặp', def: 'number', options: [{ value: 'number', label: 'Số' }, { value: 'variable', label: 'Biến' }, { value: 'element', label: 'Danh sách phần tử HTML' }] },
      { t: 'number', k: 'from', label: 'Số bắt đầu', def: 1, varIns: true, when: { k: 'loop_through', eq: 'number' } },
      { t: 'number', k: 'to', label: 'Số kết thúc', def: 10, varIns: true, when: { k: 'loop_through', eq: 'number' } },
      { t: 'text', k: 'refererce_key', label: 'Biến chứa dữ liệu', varIns: true, ph: 'Biến chứa dữ liệu', when: { k: 'loop_through', eq: 'variable' } },
      { t: 'selector', k: 'element_selector', label: 'Bộ chọn phần tử', varIns: true, when: { k: 'loop_through', eq: 'element' } },
      { t: 'check', k: 'selector_switch', label: 'Chờ phần tử', def: false, when: { k: 'loop_through', eq: 'element' } },
      { t: 'number', k: 'selector_timeout', label: 'Thời gian chờ tối đa (giây)', def: 30, varIns: true, when: [{ k: 'loop_through', eq: 'element' }, { k: 'selector_switch', eq: true }] },
      { t: 'number', k: 'max_loop', label: 'Số lần lặp tối đa, mặc định 0 (không sử dụng)', def: 0, varIns: true, when: { k: 'loop_through', in: ['variable', 'element'] } },
      { t: 'number', k: 'index_start', label: 'Thứ tự bắt đầu', def: 1, varIns: true, when: { k: 'loop_through', in: ['variable', 'element'] } },
      { t: 'loopexpr', k: 'data', label: 'Lấy dữ liệu', exprSuffix: 'data', hint: 'Dùng biểu thức này để lấy dữ liệu của vòng lặp hiện tại' },
      { t: 'loopexpr', k: 'loop_order', label: 'Lấy số thứ tự', exprSuffix: 'loop_order', hint: 'Dùng biểu thức này để lấy số thứ tự của vòng lặp hiện tại' },
    ],
  }],
  ['diem_cuoi_vong_lap', 'Điểm cuối vòng lặp', CAT.FLOW, {
    icon: 'circleDot',
    subtitle: 'Đánh dấu kết thúc thân vòng lặp theo Loop ID',
    fields: [
      { t: 'text', k: 'loop_id', label: 'Loop ID', req: true, varIns: true },
    ],
  }],
  ['dieu_kien', 'Điều kiện', CAT.FLOW, {
    icon: 'branch',
    subtitle: 'Rẽ nhánh luồng theo điều kiện đúng (if) hoặc sai (else)',
    branches: ['if', 'else'],
    fields: [
      { t: 'conds', k: 'conditions', label: 'Điều kiện', req: true, hint: 'Thỏa mãn -> đi nhánh "if", không thỏa mãn -> đi nhánh "else".' },
      { t: 'check', k: 'retry', label: 'Thử lại nếu điều kiện chưa thỏa mãn', def: false },
      { t: 'number', k: 'try_for', label: 'Số lần thử lại', def: 10, varIns: true, when: { k: 'retry', eq: true } },
      { t: 'number', k: 'timeout', label: 'Giãn cách mỗi lần thử (ms)', def: 1000, varIns: true, when: { k: 'retry', eq: true } },
    ],
  }],
  ['dung_vong_lap', 'Dừng vòng lặp', CAT.FLOW, { icon: 'stop', subtitle: 'Thoát khỏi vòng lặp hiện tại (break)', fields: [] }],
  ['tiep_tuc_vong_lap', 'Tiếp tục vòng lặp', CAT.FLOW, { icon: 'play', subtitle: 'Bỏ qua các bước tiếp theo và tiếp tục vòng lặp mới (continue)', fields: [] }],

  // ===================================== Xử lý tệp & thư mục (4)
  ['ghi_tep', 'Ghi tệp', CAT.FILE, {
    icon: 'filePencil',
    subtitle: 'Ghi dữ liệu vào tệp',
    fields: [
      { t: 'text', k: 'file_path', label: 'Đường dẫn tệp', req: true, varIns: true, folder: true },
      { t: 'textarea', k: 'input_data', label: 'Nội dung', req: true, varIns: true, rows: 4 },
      { t: 'select', k: 'write_mode', label: 'Chế độ ghi', req: true, def: 'owrite', options: [{ value: 'owrite', label: 'Ghi đè' }, { value: 'append', label: 'Thêm vào' }, { value: 'create', label: 'Tạo mới nguyên tử (wx)' }] },
      { t: 'select', k: 'append_type', label: 'Kiểu thêm', def: 'new_line', options: [{ value: 'new_line', label: 'Dòng mới' }, { value: 'same_line', label: 'Cùng một dòng' }], when: { k: 'write_mode', eq: 'append' } },
      { t: 'text', k: 'delimiter', label: 'Dấu phân cách', varIns: true, when: [{ k: 'write_mode', eq: 'append' }, { k: 'append_type', eq: 'same_line' }] },
    ],
  }],
  ['xoa_tep', 'Xóa tệp', CAT.FILE, {
    icon: 'trashLine',
    subtitle: 'Xóa tệp được chỉ định',
    fields: [
      { t: 'text', k: 'file_path', label: 'Đường dẫn tệp', req: true, varIns: true, folder: true },
    ],
  }],
  ['doc_tep_txt', 'Đọc tệp txt', CAT.FILE, {
    icon: 'fileText',
    subtitle: 'Đọc tệp có định dạng txt',
    fields: [
      { t: 'text', k: 'file_path', label: 'Đường dẫn tệp', req: true, varIns: true, folder: true },
      { t: 'select', k: 'mode', label: 'Chế độ đọc', req: true, def: 'all_line', options: [{ value: 'one_line', label: 'Đọc một dòng' }, { value: 'all_line', label: 'Đọc tất cả' }] },
      { t: 'select', k: 'line_position', label: 'Vị trí đọc dòng', req: true, def: 'random', options: [{ value: 'random', label: 'Ngẫu nhiên' }, { value: 'first', label: 'Đầu tiên' }, { value: 'last', label: 'Cuối cùng' }], when: { k: 'mode', eq: 'one_line' } },
      { t: 'check', k: 'is_delete_after_read', label: 'Xóa dòng sau khi đọc', def: true, when: { k: 'mode', eq: 'one_line' } },
      { t: 'text', k: 'variable_name', label: 'Biến nhận dữ liệu', req: true, ph: 'Hãy nhập biến để lưu kết quả' },
    ],
  }],
  ['doc_thu_muc', 'Đọc thư mục', CAT.FILE, {
    icon: 'folder',
    subtitle: 'Lấy tất cả đường dẫn của tệp trong thư mục',
    fields: [
      { t: 'text', k: 'folder_path', label: 'Đường dẫn thư mục', req: true, varIns: true, folder: true, ph: 'Đường dẫn thư mục' },
      { t: 'check', k: 'include_subdirectories', label: 'Bao gồm thư mục con', def: false },
      { t: 'text', k: 'variable_name', label: 'Biến nhận dữ liệu', req: true, ph: 'Hãy nhập biến để lưu kết quả' },
    ],
  }],

  // ===================================== API (2)
  ['lay_ma_otp_2fa', 'Lấy mã OTP 2FA', CAT.API, {
    icon: 'shieldCheck',
    subtitle: 'Lấy mã OTP 6 số (RFC-6238 TOTP) từ khóa bí mật 2FA',
    fields: [
      { t: 'text', k: 'two_fa', label: 'Mã 2FA', req: true, varIns: true },
      { t: 'text', k: 'variable_name', label: 'Biến nhận giá trị', req: true, ph: 'Hãy nhập biến để lưu kết quả' },
    ],
  }],
  ['facebook_api', 'Facebook API', CAT.API, {
    icon: 'brandFacebook',
    subtitle: 'Sử dụng các API có sẵn của Facebook',
    fields: [
      { t: 'select', k: 'api_type', label: 'Gói API', req: true, options: [{ value: 'changeLanguage', label: 'Đổi ngôn ngữ' }, { value: 'switchProfilePage', label: 'Chuyển sang Trang hoặc Trang cá nhân' }, { value: 'getCurrentUserData', label: 'Lấy dữ liệu người dùng hiện tại' }, { value: 'fetchReelPosts', label: 'Quét video xu hướng trên Reels' }, { value: 'fetchNewGroupMember', label: 'Quét thành viên mới tham gia nhóm' }, { value: 'fetchPagesByKeyword', label: 'Quét trang theo từ khóa' }, { value: 'fetchGroupsByKeyword', label: 'Quét nhóm theo từ khóa' }, { value: 'fetchPostsInGroup', label: 'Quét bài viết trong nhóm' }, { value: 'fetchPostInteractions', label: 'Quét người tương tác bài viết' }, { value: 'fetchPostOnPage', label: 'Quét bài viết trên tường cá nhân hoặc trang' }, { value: 'fetchPagesOnAccount', label: 'Quét danh sách trang của tài khoản' }, { value: 'autoAcceptFriendRequest', label: 'Tự động chấp nhận lời mời kết bạn' }, { value: 'fetchFollowingOfAccount', label: 'Quét danh sách tài khoản đang theo dõi của tài khoản' }, { value: 'addFriendByUid', label: 'Kết bạn theo UID' }, { value: 'fetchJoinedGroupsOfAccount', label: 'Quét danh sách nhóm mà tài khoản đã tham gia' }, { value: 'logoutSessionOtherDevice', label: 'Đăng xuất tài khoản trên các thiết bị khác, trừ thiết bị hiện tại ra' }, { value: 'renameAccount', label: 'Đổi tên tài khoản' }, { value: 'createPage', label: 'Tạo trang' }, { value: 'fetchNewPostsByKeyWord', label: 'Quét bài viết mới nhất theo từ khóa' }, { value: 'fetchFriendsOfAccount', label: 'Quét bạn bè của tài khoản' }, { value: 'inviteFriendsJoinGroup', label: 'Mời bạn bè tham gia nhóm' }] },
      { t: 'select', k: 'lang', label: 'Ngôn ngữ', req: true, def: 'en_US', options: [{ value: 'en_US', label: 'Tiếng Anh - Mỹ' }, { value: 'vi_VN', label: 'Tiếng Việt' }], when: { k: 'api_type', eq: 'changeLanguage' } },
      { t: 'text', k: 'profile_id', label: 'ID Trang hoặc Trang Cá Nhân', varIns: true, when: { k: 'api_type', eq: 'switchProfilePage' } },
      { t: 'number', k: 'max_post__fetchreelposts', label: 'Số lượng bài viết quét tối đa', req: true, def: 30, varIns: true, when: { k: 'api_type', eq: 'fetchReelPosts' } },
      { t: 'info', k: 'delayhdr__fetchreelposts', text: 'Khoảng cách ngẫu nhiên giữa các lần quét', when: { k: 'api_type', eq: 'fetchReelPosts' } },
      { t: 'number', k: 'min_delay__fetchreelposts', label: 'Số giây tối thiểu', req: true, def: 3, varIns: true, when: { k: 'api_type', eq: 'fetchReelPosts' } },
      { t: 'number', k: 'max_delay__fetchreelposts', label: 'Số giây tối đa', req: true, def: 8, varIns: true, when: { k: 'api_type', eq: 'fetchReelPosts' } },
      { t: 'text', k: 'group_id__fetchnewgroupmember', label: 'ID Nhóm', req: true, varIns: true, when: { k: 'api_type', eq: 'fetchNewGroupMember' } },
      { t: 'number', k: 'max_member', label: 'Số lượng thành viên quét tối đa', req: true, def: 50, varIns: true, when: { k: 'api_type', eq: 'fetchNewGroupMember' } },
      { t: 'info', k: 'delayhdr__fetchnewgroupmember', text: 'Khoảng cách ngẫu nhiên giữa các lần quét', when: { k: 'api_type', eq: 'fetchNewGroupMember' } },
      { t: 'number', k: 'min_delay__fetchnewgroupmember', label: 'Số giây tối thiểu', req: true, def: 3, varIns: true, when: { k: 'api_type', eq: 'fetchNewGroupMember' } },
      { t: 'number', k: 'max_delay__fetchnewgroupmember', label: 'Số giây tối đa', req: true, def: 8, varIns: true, when: { k: 'api_type', eq: 'fetchNewGroupMember' } },
      { t: 'text', k: 'keyword', label: 'Từ khóa', req: true, varIns: true, when: { k: 'api_type', in: ['fetchPagesByKeyword', 'fetchGroupsByKeyword', 'fetchNewPostsByKeyWord'] } },
      { t: 'text', k: 'location', label: 'Vị trí', varIns: true, when: { k: 'api_type', in: ['fetchPagesByKeyword', 'fetchGroupsByKeyword'] } },
      { t: 'number', k: 'max_page', label: 'Số lượng trang quét tối đa', req: true, def: 50, varIns: true, when: { k: 'api_type', eq: 'fetchPagesByKeyword' } },
      { t: 'info', k: 'delayhdr__fetchpagesbykeyword', text: 'Khoảng cách ngẫu nhiên giữa các lần quét', when: { k: 'api_type', eq: 'fetchPagesByKeyword' } },
      { t: 'number', k: 'min_delay__fetchpagesbykeyword', label: 'Số giây tối thiểu', req: true, def: 3, varIns: true, when: { k: 'api_type', eq: 'fetchPagesByKeyword' } },
      { t: 'number', k: 'max_delay__fetchpagesbykeyword', label: 'Số giây tối đa', req: true, def: 5, varIns: true, when: { k: 'api_type', eq: 'fetchPagesByKeyword' } },
      { t: 'check', k: 'near_me', label: 'Gần tôi', def: false, when: { k: 'api_type', eq: 'fetchGroupsByKeyword' } },
      { t: 'check', k: 'public_group', label: 'Nhóm công khai', def: false, when: { k: 'api_type', eq: 'fetchGroupsByKeyword' } },
      { t: 'number', k: 'max_group__fetchgroupsbykeyword', label: 'Số lượng nhóm quét tối đa', req: true, def: 50, varIns: true, when: { k: 'api_type', eq: 'fetchGroupsByKeyword' } },
      { t: 'info', k: 'delayhdr__fetchgroupsbykeyword', text: 'Khoảng cách ngẫu nhiên giữa các lần quét', when: { k: 'api_type', eq: 'fetchGroupsByKeyword' } },
      { t: 'number', k: 'min_delay__fetchgroupsbykeyword', label: 'Số giây tối thiểu', req: true, def: 3, varIns: true, when: { k: 'api_type', eq: 'fetchGroupsByKeyword' } },
      { t: 'number', k: 'max_delay__fetchgroupsbykeyword', label: 'Số giây tối đa', req: true, def: 10, varIns: true, when: { k: 'api_type', eq: 'fetchGroupsByKeyword' } },
      { t: 'text', k: 'group_id__fetchpostsingroup', label: 'ID Nhóm', req: true, varIns: true, when: { k: 'api_type', eq: 'fetchPostsInGroup' } },
      { t: 'number', k: 'max_post__fetchpostsingroup', label: 'Số lượng bài viết quét tối đa', req: true, def: 30, varIns: true, when: { k: 'api_type', eq: 'fetchPostsInGroup' } },
      { t: 'info', k: 'delayhdr__fetchpostsingroup', text: 'Khoảng cách ngẫu nhiên giữa các lần quét', when: { k: 'api_type', eq: 'fetchPostsInGroup' } },
      { t: 'number', k: 'min_delay__fetchpostsingroup', label: 'Số giây tối thiểu', req: true, def: 10, varIns: true, when: { k: 'api_type', eq: 'fetchPostsInGroup' } },
      { t: 'number', k: 'max_delay__fetchpostsingroup', label: 'Số giây tối đa', req: true, def: 15, varIns: true, when: { k: 'api_type', eq: 'fetchPostsInGroup' } },
      { t: 'text', k: 'post_id', label: 'ID Bài viết', req: true, varIns: true, when: { k: 'api_type', eq: 'fetchPostInteractions' } },
      { t: 'number', k: 'max_reaction', label: 'Số lượng quét tối đa', req: true, def: 50, varIns: true, when: { k: 'api_type', eq: 'fetchPostInteractions' } },
      { t: 'info', k: 'delayhdr__fetchpostinteractions', text: 'Khoảng cách ngẫu nhiên giữa các lần quét', when: { k: 'api_type', eq: 'fetchPostInteractions' } },
      { t: 'number', k: 'min_delay__fetchpostinteractions', label: 'Số giây tối thiểu', req: true, def: 10, varIns: true, when: { k: 'api_type', eq: 'fetchPostInteractions' } },
      { t: 'number', k: 'max_delay__fetchpostinteractions', label: 'Số giây tối đa', req: true, def: 15, varIns: true, when: { k: 'api_type', eq: 'fetchPostInteractions' } },
      { t: 'text', k: 'page_profile_id', label: 'ID Trang', req: true, varIns: true, when: { k: 'api_type', eq: 'fetchPostOnPage' } },
      { t: 'number', k: 'max_post_on_page', label: 'Số lượng bài viết quét tối đa', req: true, def: 20, varIns: true, when: { k: 'api_type', eq: 'fetchPostOnPage' } },
      { t: 'info', k: 'delayhdr__fetchpostonpage', text: 'Khoảng cách ngẫu nhiên giữa các lần quét', when: { k: 'api_type', eq: 'fetchPostOnPage' } },
      { t: 'number', k: 'min_delay__fetchpostonpage', label: 'Số giây tối thiểu', req: true, def: 10, varIns: true, when: { k: 'api_type', eq: 'fetchPostOnPage' } },
      { t: 'number', k: 'max_delay__fetchpostonpage', label: 'Số giây tối đa', req: true, def: 15, varIns: true, when: { k: 'api_type', eq: 'fetchPostOnPage' } },
      { t: 'number', k: 'max_accept', label: 'Số lượng chấp nhận tối đa', req: true, def: 10, varIns: true, when: { k: 'api_type', eq: 'autoAcceptFriendRequest' } },
      { t: 'info', k: 'delayhdr__autoacceptfriendrequest', text: 'Khoảng cách ngẫu nhiên giữa các lần chấp nhận', when: { k: 'api_type', eq: 'autoAcceptFriendRequest' } },
      { t: 'number', k: 'min_delay__autoacceptfriendrequest', label: 'Số giây tối thiểu', req: true, def: 10, varIns: true, when: { k: 'api_type', eq: 'autoAcceptFriendRequest' } },
      { t: 'number', k: 'max_delay__autoacceptfriendrequest', label: 'Số giây tối đa', req: true, def: 15, varIns: true, when: { k: 'api_type', eq: 'autoAcceptFriendRequest' } },
      { t: 'number', k: 'max_account', label: 'Số lượng quét tối đa', req: true, def: 1000, varIns: true, when: { k: 'api_type', eq: 'fetchFollowingOfAccount' } },
      { t: 'info', k: 'delayhdr__fetchfollowingofaccount', text: 'Khoảng cách ngẫu nhiên giữa các lần quét', when: { k: 'api_type', eq: 'fetchFollowingOfAccount' } },
      { t: 'number', k: 'min_delay__fetchfollowingofaccount', label: 'Số giây tối thiểu', req: true, def: 10, varIns: true, when: { k: 'api_type', eq: 'fetchFollowingOfAccount' } },
      { t: 'number', k: 'max_delay__fetchfollowingofaccount', label: 'Số giây tối đa', req: true, def: 15, varIns: true, when: { k: 'api_type', eq: 'fetchFollowingOfAccount' } },
      { t: 'text', k: 'uid', label: 'UID', req: true, varIns: true, when: { k: 'api_type', eq: 'addFriendByUid' } },
      { t: 'number', k: 'max_group__fetchjoinedgroupsofaccount', label: 'Số lượng nhóm quét tối đa', req: true, def: 50, varIns: true, when: { k: 'api_type', eq: 'fetchJoinedGroupsOfAccount' } },
      { t: 'info', k: 'delayhdr__fetchjoinedgroupsofaccount', text: 'Khoảng cách ngẫu nhiên giữa các lần quét', when: { k: 'api_type', eq: 'fetchJoinedGroupsOfAccount' } },
      { t: 'number', k: 'min_delay__fetchjoinedgroupsofaccount', label: 'Số giây tối thiểu', req: true, def: 10, varIns: true, when: { k: 'api_type', eq: 'fetchJoinedGroupsOfAccount' } },
      { t: 'number', k: 'max_delay__fetchjoinedgroupsofaccount', label: 'Số giây tối đa', req: true, def: 15, varIns: true, when: { k: 'api_type', eq: 'fetchJoinedGroupsOfAccount' } },
      { t: 'text', k: 'last_name', label: 'Họ', req: true, varIns: true, when: { k: 'api_type', eq: 'renameAccount' } },
      { t: 'text', k: 'first_name', label: 'Tên', req: true, varIns: true, when: { k: 'api_type', eq: 'renameAccount' } },
      { t: 'text', k: 'name', label: 'Tên trang', req: true, varIns: true, when: { k: 'api_type', eq: 'createPage' } },
      { t: 'check', k: 'is_random_category', label: 'Lấy danh mục ngẫu nhiên', def: false, when: { k: 'api_type', eq: 'createPage' } },
      { t: 'text', k: 'category_ids', label: 'Danh mục trang', ph: 'Danh mục trang', when: [{ k: 'api_type', eq: 'createPage' }, { k: 'is_random_category', ne: true }] },
      { t: 'textarea', k: 'description', label: 'Mô tả trang', varIns: true, rows: 4, when: { k: 'api_type', eq: 'createPage' } },
      { t: 'number', k: 'max_post__fetchnewpostsbykeyword', label: 'Số lượng bài viết quét tối đa', req: true, def: 30, varIns: true, when: { k: 'api_type', eq: 'fetchNewPostsByKeyWord' } },
      { t: 'info', k: 'delayhdr__fetchnewpostsbykeyword', text: 'Khoảng cách ngẫu nhiên giữa các lần quét', when: { k: 'api_type', eq: 'fetchNewPostsByKeyWord' } },
      { t: 'number', k: 'min_delay__fetchnewpostsbykeyword', label: 'Số giây tối thiểu', req: true, def: 10, varIns: true, when: { k: 'api_type', eq: 'fetchNewPostsByKeyWord' } },
      { t: 'number', k: 'max_delay__fetchnewpostsbykeyword', label: 'Số giây tối đa', req: true, def: 15, varIns: true, when: { k: 'api_type', eq: 'fetchNewPostsByKeyWord' } },
      { t: 'number', k: 'max_friend', label: 'Số lượng bạn bè quét tối đa', req: true, def: 200, varIns: true, when: { k: 'api_type', eq: 'fetchFriendsOfAccount' } },
      { t: 'info', k: 'delayhdr__fetchfriendsofaccount', text: 'Khoảng cách ngẫu nhiên giữa các lần quét', when: { k: 'api_type', eq: 'fetchFriendsOfAccount' } },
      { t: 'number', k: 'min_delay__fetchfriendsofaccount', label: 'Số giây tối thiểu', req: true, def: 5, varIns: true, when: { k: 'api_type', eq: 'fetchFriendsOfAccount' } },
      { t: 'number', k: 'max_delay__fetchfriendsofaccount', label: 'Số giây tối đa', req: true, def: 10, varIns: true, when: { k: 'api_type', eq: 'fetchFriendsOfAccount' } },
      { t: 'number', k: 'group_id__invitefriendsjoingroup', label: 'ID Nhóm', req: true, varIns: true, when: { k: 'api_type', eq: 'inviteFriendsJoinGroup' } },
      { t: 'select', k: 'friend_ids', label: 'Biến chứa danh sách UID bạn bè', req: true, options: [], varsrc: true, ph: 'Hãy chọn biến', when: { k: 'api_type', eq: 'inviteFriendsJoinGroup' } },
      { t: 'number', k: 'num_friend_per_invite', label: 'Số lượng bạn bè mỗi lần mời', req: true, def: 10, varIns: true, when: { k: 'api_type', eq: 'inviteFriendsJoinGroup' } },
      { t: 'info', k: 'delayhdr__invitefriendsjoingroup', text: 'Khoảng cách ngẫu nhiên giữa các lần mời', when: { k: 'api_type', eq: 'inviteFriendsJoinGroup' } },
      { t: 'number', k: 'min_delay__invitefriendsjoingroup', label: 'Số giây tối thiểu', req: true, def: 10, varIns: true, when: { k: 'api_type', eq: 'inviteFriendsJoinGroup' } },
      { t: 'number', k: 'max_delay__invitefriendsjoingroup', label: 'Số giây tối đa', req: true, def: 15, varIns: true, when: { k: 'api_type', eq: 'inviteFriendsJoinGroup' } },
      { t: 'text', k: 'variable_name', label: 'Biến nhận dữ liệu', req: true, ph: 'Hãy nhập biến để lưu kết quả', when: { k: 'api_type', in: ['getCurrentUserData', 'fetchReelPosts', 'fetchNewGroupMember', 'fetchPagesByKeyword', 'fetchGroupsByKeyword', 'fetchPostsInGroup', 'fetchPostInteractions', 'fetchPostOnPage', 'fetchPagesOnAccount', 'fetchFollowingOfAccount', 'fetchJoinedGroupsOfAccount', 'fetchNewPostsByKeyWord', 'fetchFriendsOfAccount'] } },
    ],
  }],

  // ===================================== AI (2)
  ['chatgpt', 'ChatGPT', CAT.AI, {
    icon: 'brandOpenai',
    subtitle: 'Sử dụng ChatGPT để yêu cầu trả lời câu hỏi, viết nội dung hoặc tạo ảnh.',
    fields: [
      { t: 'text', k: 'api_key', label: 'API Key', req: true, varIns: true },
      { t: 'radio', k: 'output_type', label: 'Dữ liệu trả về', def: 'text', options: [{ value: 'text', label: 'Văn bản' }, { value: 'image', label: 'Hình ảnh' }] },
      { t: 'select', k: 'model', label: 'Model', req: true, def: 'gpt-4o-mini', options: [{ value: 'gpt-5.2', label: 'GPT-5.2' }, { value: 'gpt-5.1', label: 'GPT-5.1' }, { value: 'gpt-5', label: 'GPT-5' }, { value: 'gpt-5-mini', label: 'GPT-5 Mini' }, { value: 'gpt-4.1', label: 'GPT-4.1' }, { value: 'gpt-4.1-mini', label: 'GPT-4.1 Mini' }, { value: 'gpt-4o', label: 'GPT-4o' }, { value: 'gpt-4o-mini', label: 'GPT-4o Mini' }, { value: 'custom', label: 'Tùy chỉnh' }], when: { k: 'output_type', eq: 'text' } },
      { t: 'text', k: 'model_custom', label: 'Model tùy chỉnh', varIns: true, when: [{ k: 'output_type', eq: 'text' }, { k: 'model', eq: 'custom' }] },
      { t: 'textarea', k: 'prompt__text', label: 'Văn bản lệnh', req: true, varIns: true, rows: 4, when: { k: 'output_type', eq: 'text' } },
      { t: 'textarea', k: 'prompt__image', label: 'Văn bản lệnh', req: true, varIns: true, rows: 4, when: { k: 'output_type', eq: 'image' } },
      { t: 'select', k: 'image_size', label: 'Kích thước hình ảnh', req: true, def: '1024x1024', options: [{ value: '1024x1024', label: '1024 X 1024' }, { value: '1792x1024', label: '1792 X 1024' }, { value: '1024x1792', label: '1024 X 1792' }], when: { k: 'output_type', eq: 'image' } },
      { t: 'radio', k: 'response_type', label: 'Kiểu trả về', def: 'url', options: [{ value: 'url', label: 'URL' }, { value: 'base64', label: 'Base64' }], when: { k: 'output_type', eq: 'image' } },
      { t: 'text', k: 'variable_output', label: 'Biến nhận giá trị', req: true, ph: 'Hãy nhập biến để lưu kết quả', when: { k: 'output_type', in: ['text', 'image'] } },
    ],
  }],
  ['gemini', 'Gemini', CAT.AI, {
    icon: 'sparkles',
    subtitle: 'Sử dụng Google Gemini (Text & Vision) để trả lời câu hỏi, viết nội dung.',
    fields: [
      { t: 'text', k: 'api_key', label: 'API Key', req: true, varIns: true },
      { t: 'select', k: 'model', label: 'Model', req: true, def: 'gemini-2.5-flash', options: [{ value: 'gemini-2.5-pro', label: 'Gemini 2.5 Pro' }, { value: 'gemini-2.5-flash', label: 'Gemini 2.5 Flash' }, { value: 'gemini-2.5-flash-lite', label: 'Gemini 2.5 Flash-Lite' }, { value: 'gemini-2.0-flash', label: 'Gemini 2.0 Flash' }, { value: 'gemini-2.0-flash-lite', label: 'Gemini 2.0 Flash-Lite' }, { value: 'custom', label: 'Tùy chỉnh' }] },
      { t: 'text', k: 'model_custom', label: 'Model tùy chỉnh', varIns: true, when: { k: 'model', eq: 'custom' } },
      { t: 'textarea', k: 'prompt', label: 'Văn bản lệnh', req: true, varIns: true, rows: 4 },
      { t: 'text', k: 'image_attachment', label: 'Tệp hình ảnh đính kèm (tùy chọn)', varIns: true, folder: true },
      { t: 'text', k: 'variable_output', label: 'Biến nhận giá trị', req: true, ph: 'Hãy nhập biến để lưu kết quả' },
    ],
  }],

  // ===================================== Khác (2)
  ['commandCmd', 'Lệnh cmd', CAT.OTHER, {
    icon: 'terminal2',
    subtitle: 'Thực thi lệnh CMD',
    fields: [
      { t: 'text', k: 'command', label: 'Lệnh cmd', req: true, varIns: true },
      { t: 'check', k: 'waitForOutput', label: 'Đợi kết quả', def: false },
    ],
  }],
  ['note', 'Ghi chú', CAT.OTHER, {
    icon: 'notes',
    subtitle: 'Ghi chú trên bản vẽ quy trình',
    fields: [
      { t: 'textarea', k: 'note', label: 'Nội dung', ph: 'Ghi chú...', rows: 4 },
      { t: 'switch', k: 'pin', label: 'Ghim', def: false },
      { t: 'select', k: 'color', label: 'Màu', def: 'amber', options: [{ value: 'green', label: 'Xanh lá' }, { value: 'purple', label: 'Tím' }, { value: 'cyan', label: 'Lơ' }, { value: 'emerald', label: 'Xanh lục' }, { value: 'amber', label: 'Vàng' }, { value: 'red', label: 'Đỏ' }] },
    ],
  }],
];

function fieldDefault(f) {
  if (!f) return '';
  if (f.t === 'switch' || f.t === 'check') return f.def != null ? f.def : false;
  if (f.t === 'checks') return [];
  if (f.t === 'conds') return { logic: 'AND', conditions: [{ left: '', op: 'Bằng', right: '' }] };
  if (f.t === 'number') return f.def != null ? f.def : '';
  return f.def != null ? f.def : '';
}

function normalizeField(f) {
  const out = { ...f };
  if (f.when && !out.onlyWhen) out.onlyWhen = f.when;
  if (out.default === undefined) out.default = fieldDefault(f);
  return out;
}

const START_NODE = {
  type: 'start',
  title: 'Bắt đầu quy trình',
  category: CAT.FLOW,
  color: COL_START,
  icon: 'play',
  subtitle: 'Điểm bắt đầu thực thi quy trình',
  learn: false,
  fields: [],
  branches: null,
  container: false,
  test: false,
  gear: false,
  isStart: true,
  hiddenFromPalette: true,
};

// 52 configurable nodes shown in the editor palette & MCP node catalog
const NODES = defs.map(([type, title, category, opts]) => ({
  type,
  title,
  category,
  color: CAT_COLOR[category],
  icon: opts.icon || '',
  subtitle: opts.subtitle || '',
  learn: false,
  fields: (opts.fields || []).map(normalizeField),
  branches: opts.branches || null,
  container: false,
  test: false,
  gear: false,
}));

// Complete 53-node catalog (`start` + 52 configurable nodes)
const NODE_CATALOG = [START_NODE, ...NODES];

const byType = new Map(NODE_CATALOG.map((n) => [n.type, n]));

function getNodeDef(type) {
  return byType.get(String(type || '')) || null;
}

// Alias for PolyLogin compatibility
const find = getNodeDef;

function byCategory(cat) {
  return NODES.filter((n) => n.category === cat);
}

function listCategories() {
  return CATEGORIES.map(([id, label]) => ({
    id,
    key: id,
    name: label,
    label,
    color: CAT_COLOR[id],
    count: byCategory(id).length,
  }));
}

function initial(title) {
  const t = String(title || '').trim();
  return t ? t[0].toUpperCase() : '?';
}

function clauseOk(def, params, w) {
  if (!w || typeof w !== 'object') return true;
  if ('or' in w) {
    return (w.or || []).some((sub) => (Array.isArray(sub)
      ? sub.every((s) => clauseOk(def, params, s))
      : clauseOk(def, params, sub)));
  }
  const ctrl = def && Array.isArray(def.fields) ? def.fields.find((x) => x.k === w.k) : null;
  let cur = params ? params[w.k] : undefined;
  if (cur == null || cur === '') cur = ctrl ? ctrl.def : undefined;
  if ('eq' in w) return cur === w.eq;
  if ('ne' in w) return cur !== w.ne;
  if ('in' in w) return Array.isArray(w.in) && w.in.includes(cur);
  if ('notIn' in w) return !(Array.isArray(w.notIn) && w.notIn.includes(cur));
  return true;
}

function fieldVisible(def, params, f) {
  const rule = f && (f.when || f.onlyWhen);
  if (!rule) return true;
  const arr = Array.isArray(rule) ? rule : [rule];
  return arr.every((w) => clauseOk(def, params || {}, w));
}

function makeDefaultParams(typeOrDef) {
  const def = typeof typeOrDef === 'string' ? getNodeDef(typeOrDef) : typeOrDef;
  const out = {};
  if (!def || !Array.isArray(def.fields)) return out;
  for (const f of def.fields) {
    if (f.k && f.t !== 'info') out[f.k] = fieldDefault(f);
  }
  return out;
}

module.exports = {
  CAT,
  CAT_COLOR,
  COL_START,
  CATEGORIES,
  OPS,
  VAR_TYPES,
  SYS_VARS,
  VAR_OUT_KEYS,
  COND_OPS,
  COND_OP_SYMBOLS,
  COND_OPS_UNARY,
  COND_OPS_LIST,
  COND_OP_HINTS,
  START_NODE,
  NODES,
  NODE_CATALOG,
  getNodeDef,
  find,
  byCategory,
  listCategories,
  initial,
  fieldDefault,
  clauseOk,
  fieldVisible,
  makeDefaultParams,
};
